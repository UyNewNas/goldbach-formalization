#!/usr/bin/env python3
"""Archive existing P1 evidence only after validating the real final receipt.

Preparation of this script is not verification.  Running it never invokes Lean,
the checker, the receipt producer, CI, or Git.  It fails before publishing either
output if the current six targets, 689 local records, replay, or five-module
census do not match the actual successful receipt.  Historical failures remain
historical failures in separate archive paths.  Binaries and dependency sources
are hashed where needed but never copied into the archive.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import sys
import tarfile

sys.dont_write_bytecode = True
import prepare_p1_key_types as gates


EXPECTED_LOCAL_MODULES = 689
CHECKPOINT = "70ad4d737a2ff4a77413a5975af2fb41bdfb7d66"
TEXT_SUFFIXES = {".log", ".json", ".jsonl", ".txt", ".md", ".lean", ".py", ".ok"}


def require(condition, message):
    if not condition:
        raise gates.VerificationError(message)


def encoded(value):
    return (json.dumps(value, indent=2, ensure_ascii=False, sort_keys=True) + "\n").encode()


def references(value):
    if isinstance(value, dict):
        if {"path", "sha256", "bytes"} <= value.keys():
            yield value
        for child in value.values():
            yield from references(child)
    elif isinstance(value, list):
        for child in value:
            yield from references(child)


class Inputs:
    def __init__(self, scratch, repo, runtime):
        self.scratch, self.repo, self.runtime = scratch, repo, runtime
        self.files, self.watched, self.omitted = {}, {}, {}

    def watch(self, path, expected=None, size=None):
        path = Path(path).absolute()
        require(not path.is_symlink() and path.is_file(), f"Missing/nonregular input: {path}")
        require(path.is_relative_to(self.scratch), f"Input outside task workspace: {path}")
        with path.open("rb") as stream:
            digest = hashlib.file_digest(stream, "sha256").hexdigest()
        actual_size = path.stat().st_size
        require(expected is None or digest == expected, f"Stale input hash: {path}")
        require(size is None or actual_size == size, f"Stale input size: {path}")
        record = {"sha256": digest, "bytes": actual_size}
        require(path not in self.watched or self.watched[path] == record, f"Input changed: {path}")
        self.watched[path] = record
        return path, record

    def include(self, path, category):
        path, record = self.watch(path)
        if path in self.files:
            return
        data = path.read_bytes()
        require(gates.sha256(data) == record["sha256"], f"Input changed while reading: {path}")
        require(b"\0" not in data, f"Refusing binary archive member: {path}")
        data.decode("utf-8")
        for root, prefix in [(self.repo, "repo"), (self.runtime, "runtime"), (self.scratch, "scratch")]:
            if path.is_relative_to(root):
                member = prefix + "/" + path.relative_to(root).as_posix()
                break
        self.files[path] = {**record, "original_path": str(path), "member": member,
                            "category": category, "data": data}

    def reference(self, ref, category, embed=True):
        gates.validated_reference(ref, category)
        path, record = self.watch(ref["path"], ref["sha256"], ref["bytes"])
        if embed:
            self.include(path, category)
        else:
            self.omitted[path] = {"original_path": str(path), **record,
                                  "reason": category, "member": None}

    def tree(self, path, category):
        require(path.is_dir(), f"Missing evidence directory: {path}")
        for entry in sorted(path.rglob("*")):
            if entry.is_file() and entry.suffix in TEXT_SUFFIXES:
                self.include(entry, category)

    def recheck(self):
        for path, record in list(self.watched.items()):
            self.watch(path, record["sha256"], record["bytes"])


def prepare(args):
    scratch = Path(__file__).resolve().parent
    repo, runtime = args.repo.resolve(), args.runtime.resolve()
    receipt_path = runtime / "part1-final-receipt.json"
    require(receipt_path.is_file(), "The real part1-final-receipt.json does not exist; no archive created")
    require(args.summary.resolve().is_relative_to(scratch) and
            not args.summary.resolve().is_relative_to(repo), "Summary must remain in scratch outside the repository")
    require(args.output.resolve() == repo / "verification/parts/p1/EVIDENCE.tar.gz",
            "Archive output must be the owned P1 EVIDENCE.tar.gz path")
    inputs = Inputs(scratch, repo, runtime)
    inputs.include(receipt_path, "current-final-receipt")
    receipt = json.loads(inputs.files[receipt_path]["data"])
    snapshot = gates.source_snapshot(repo)
    _, audit = gates.validate_final_receipt(repo, receipt, snapshot)
    targets = set(gates.TARGET_MODULE_PATHS)
    probe = json.loads((runtime / "runtime-probe.json").read_text())
    toolroot = Path(probe["toolroot"])
    packages = json.loads((repo / "lake-manifest.json").read_text())["packages"]
    roots = [repo] + [repo / ".lake/packages" / p["name"] for p in packages]

    def object_path(module):
        require(re.fullmatch(r"[A-Za-z_][A-Za-z0-9_.]*", module), f"Malformed module name: {module}")
        relative = Path(*module.split("."))
        for root in roots:
            if (root / relative.with_suffix(".lean")).is_file():
                return root / ".lake/build/lib/lean" / relative.with_suffix(".olean")
        return toolroot / "lib/lean" / relative.with_suffix(".olean")

    logroot = runtime / "logs"
    closure = receipt["closure"]
    inputs.reference(closure["plan"], "current-closure-plan")
    inputs.reference(closure["state"], "current-closure-state")
    plan = json.loads(inputs.files[Path(closure["plan"]["path"])]["data"])
    state = json.loads(inputs.files[Path(closure["state"]["path"])]["data"])
    result_path = logroot / "closure/result.json"
    inputs.include(result_path, "current-closure-result")
    result = json.loads(inputs.files[result_path]["data"])
    local = plan["local_modules"]
    require(len(local) == len(set(local)) == EXPECTED_LOCAL_MODULES and set(state) == set(local),
            "Current closure must contain exactly 689 unique completed local records")
    require(set(plan["targets"]) == set(result["targets"]) == targets and
            len(plan["targets"]) == len(result["targets"]) == 6, "Stale target graph")
    require(result == closure["final_execution_result"] and result["returncode"] == 0 and
            not result["failures"] and result["complete_local_modules"] == result["total_local_modules"] == len(local),
            "Current closure result is incomplete or differs from the final receipt")
    require(closure["compiled_local_modules"] == len(local) and
            len(closure["source_order"]) == len(set(closure["source_order"])) == plan["source_modules"] == closure["source_modules"] and
            set(local) <= set(closure["source_order"]) and
            closure["official_cached_source_modules"] == plan["official_cached_modules"] == plan["source_modules"] - len(local),
            "Closure census differs from the final receipt")
    require(plan["workers"] == 1 and plan["trustLevel"] == result["trustLevel"] == 0 and
            plan["metadata_adapter"] is result["metadata_adapter"] is False and
            set(plan["strict_modules"]) == targets and
            closure["final_graph_includes_repository_probe"] is True and
            closure["audit_direct_import_includes_repository_probe"] is True,
            "Wrong final graph, strict scope, or compilation mode")

    for module in local:
        record = state[module]
        source = Path(record["source"])
        require(record["module"] == module and record["returncode"] == record["trustLevel"] == 0 and
                record["metadata_adapter"] is False and record["strict"] is (module in targets) and
                record["source_sha256_before"] == record["source_sha256_after"],
                f"Unsuccessful/stale local compilation record: {module}")
        inputs.watch(source, record["source_sha256_after"])
        output = object_path(module)
        inputs.watch(output, record["olean_sha256"])
        for imported, digest in record["import_olean_sha256"].items():
            inputs.watch(object_path(imported), digest)
        logfile = logroot / "closure" / (module + ".log")
        require(Path(record["log"]) == logfile, f"Wrong current log path: {module}")
        inputs.include(logfile, "current-local-compile-log")
        lines = inputs.files[logfile]["data"].decode().splitlines()
        header = json.loads(lines[0])
        command = [str(toolroot / "bin/lake"), "-d", str(runtime / "frontend-driver"),
                   "-f", "lakefile.lean", "script", "run", "compileOne", str(source),
                   module, str(output), "strict" if module in targets else "normal"]
        require(header["command"] == command and header["source_sha256_before"] == record["source_sha256_after"] and
                header["trustLevel"] == 0 and header["metadata_adapter"] is False and
                lines.count("FRONTEND_OK module=" + module + " trustLevel=0") == 1,
                f"Raw compile log does not bind the current success record: {module}")
        if module in targets:
            require(lines.count("P1_SCHEDULER_SERIAL_BEGIN module=" + module) == 1,
                    f"Missing actual serialized target entry: {module}")
            target = receipt["targets"][module]
            require(all(target[k] == v for k, v in record.items() if k not in {"source", "log"}),
                    f"Target differs from current state: {module}")

    for module, target in receipt["targets"].items():
        inputs.reference(target["source"], "current-six-target-source")
        inputs.reference(target["log"], "current-local-compile-log")
        for defined_module, refs in [(module, target["artifact_parts"]), *target["direct_import_artifact_parts"].items()]:
            output = object_path(defined_module)
            require(set(refs) == {p.name for p in output.parent.glob(output.name + "*") if p.is_file()},
                    f"Current target/direct-import object part inventory changed: {defined_module}")
            for name, ref in refs.items():
                require(Path(ref["path"]) == output.parent / name, f"Wrong recorded artifact path: {defined_module}")
                inputs.reference(ref, "Target/direct-import object; digest retained, binary omitted", embed=False)

    replay = receipt["replay"]
    replay_result = logroot / "replay/results.json"
    inputs.include(replay_result, "current-original-replay-result")
    require(json.loads(inputs.files[replay_result]["data"]) == replay, "Replay results differ from receipt")
    require(replay["commands"] == [[str(toolroot / "bin/leanchecker"), "--verbose", m]
                                   for m in replay["observed_replay_lines"]], "Unexpected checker executable")
    for item in [replay, *replay["calls"]]:
        inputs.watch(item["log"], item["log_sha256"])
        inputs.include(item["log"], "current-original-replay-log")
    for ref in receipt["dependencies"]["project_pin_files"].values():
        require(ref["matches_initial_sha256"] is True, "Changed project configuration")
        inputs.reference(ref, "unchanged-project-configuration")
    for name, ref in receipt["toolchain"]["original_executables_rechecked"].items():
        require(ref["matches_initial_sha256"] is True, f"Changed original executable: {name}")
        inputs.reference(ref, "Original toolchain executable; hash record only, binary omitted", embed=False)
    inputs.watch(toolroot / "bin/leanchecker", replay["original_leanchecker_sha256"])
    inputs.watch(replay["semantics"]["source_path"], replay["semantics"]["source_sha256"])
    for ref in receipt["scratch_drivers"].values():
        inputs.reference(ref, "actual-verification-driver-source")
        require(Path(ref["path"]).read_text() == ref["text"], "Embedded driver source differs from current source")
    for path in [runtime / "runtime-probe.json", runtime / "cache-driver/lake-manifest.json",
                 runtime / "cache-driver/roots.txt", Path(__file__).resolve(), Path(gates.__file__).resolve(),
                 repo / ".github/workflows/lean.yml", repo / ".github/workflows/variable-envelope.yml"]:
        inputs.include(path, "configuration-or-evidence-collector-source")
    for path in sorted((runtime / "frontend-smoke").glob("*.lean")):
        inputs.include(path, "historical-smoke-source-no-reconstructed-output")
    for relative in ["LeanChecker.lean", "Lean/Elab/Tactic/Decide.lean", "Init/Data/Rat/Basic.lean"]:
        inputs.include(toolroot / "src/lean" / relative, "original-toolchain-explanatory-source")

    # Includes all original attempts verbatim.  Their unsuccessful diagnostics,
    # including any error-recovery sorryAx, are not parsed as current success.
    attempts = sorted(logroot.glob("closure-attempt-*"))
    require(attempts and (attempts[0] / "attempt.json").is_file(), "Missing archived initial graph failure")
    inputs.tree(logroot, "runtime-record-see-original-path-for-current-or-historical-scope")
    for ref in references(receipt):
        path = Path(ref["path"])
        embed = path in inputs.files or (path.is_relative_to(logroot) and path.suffix in TEXT_SUFFIXES)
        inputs.reference(ref, "receipt-reference-rechecked; unembedded dependencies/executables retained by hash", embed=embed)
    require(json.loads((logroot / "cache/result.json").read_text()) == receipt["dependencies"]["cache_result"],
            "Cache result differs from the final receipt")
    require(sum(path.parent == logroot / "closure" and path.suffix == ".log" for path in inputs.files) == len(local),
            "Archive inventory does not contain exactly the 689 current raw compile logs")
    ci_names = ["p1-source-checkpoint-variable-envelope-ci.log", "p1-source-checkpoint-ci-scope.json",
                "p1-source-checkpoint-core-ci.log", "p1-source-checkpoint-core-ci-metadata.json",
                "p1-source-checkpoint-core-ci-scope.json"]
    for name in ci_names:
        inputs.include(scratch / name, "historical-70ad-ci-not-six-target-proof-evidence")
    ci_scope = json.loads(inputs.files[scratch / ci_names[1]]["data"])
    require(ci_scope["source_checkpoint"]["commit"] == CHECKPOINT and
            ci_scope["new_p1_exclusion"]["compilation_of_new_p1_targets_established"] is False,
            "Incorrect source-checkpoint CI scope")
    inputs.reference(ci_scope["raw_log"], "historical-variable-envelope-ci-raw-log")
    core_scope = json.loads(inputs.files[scratch / ci_names[4]]["data"])
    require(core_scope["source_checkpoint"] == CHECKPOINT and
            core_scope["not_established"]["new_p1_six_target_proof_success_from_this_ci"] is False,
            "Incorrect cancelled core CI scope")
    for ref in core_scope["evidence_files"].values():
        actual = dict(ref)
        if not Path(actual["path"]).is_absolute():
            actual["path"] = str(repo / actual["path"])
        inputs.reference(actual, "historical-core-ci-reference")
    refresh = scratch / "p1-final-head-refresh"
    if refresh.exists():
        inputs.tree(refresh, "read-only-external-part-intake; not-new-P1-proof-evidence")

    manifest = {
        "schema": "p1-evidence-archive-v1", "proof_baseline": gates.PROOF_BASELINE,
        "source_checkpoint": CHECKPOINT, "final_receipt_sha256": gates.sha256(inputs.files[receipt_path]["data"]),
        "validated_scope": {"targets": sorted(targets), "compiled_local_modules": len(local),
                            "audited_defining_modules": audit["module_counts"], "audited_declarations": audit["total"],
                            "original_checker_calls": 6, "original_checker_aggregate_returncode": replay["returncode"]},
        "notes": ["The existing real receipt and current inputs passed validation before this archive was written.",
                  "No compiler, checker, CI or receipt generation is performed by the archiver.",
                  "Historical failed attempts and both source-checkpoint CI logs retain their original scope and outcomes.",
                  "Absolute original paths map to members below; omitted object/executable references retain hashes only.",
                  "For archived attempts, internal old execution paths retain their original spelling; use the historical prefix maps.",
                  "MANIFEST.json is generated metadata; it has no original source path or circular self-hash."],
        "historical_path_prefix_maps": [{"archived_input_prefix": str(p / "closure"),
                                         "original_execution_prefix": str(logroot / "closure"),
                                         "archive_member_prefix": "runtime/logs/" + p.name + "/closure/",
                                         "scope": "historical attempt only; not the current receipt"}
                                        for p in attempts if (p / "closure").is_dir()],
        "files": [{k: v for k, v in item.items() if k != "data"}
                  for item in sorted(inputs.files.values(), key=lambda item: item["member"])],
        "omitted_referenced_binaries": sorted(inputs.omitted.values(), key=lambda item: item["original_path"]),
    }
    return inputs, manifest


def main():
    scratch = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, default=scratch / "goldbach-formalization")
    parser.add_argument("--runtime", type=Path, default=scratch / "lean-runtime")
    parser.add_argument("--output", type=Path, default=scratch / "goldbach-formalization/verification/parts/p1/EVIDENCE.tar.gz")
    parser.add_argument("--summary", type=Path, default=scratch / "p1-evidence-archive-summary.json")
    args = parser.parse_args()
    temporary = scratch / ("p1-evidence-pending-" + str(os.getpid()) + ".tar.gz")
    summary_temporary = scratch / ("p1-evidence-summary-pending-" + str(os.getpid()) + ".json")
    try:
        inputs, manifest = prepare(args)
        members = {item["member"]: item["data"] for item in inputs.files.values()}
        members["MANIFEST.json"] = encoded(manifest)
        with temporary.open("wb") as raw:
            with gzip.GzipFile(filename="", fileobj=raw, mode="wb", mtime=0, compresslevel=9) as zipped:
                with tarfile.open(fileobj=zipped, mode="w", format=tarfile.PAX_FORMAT) as archive:
                    for name, data in sorted(members.items()):
                        info = tarfile.TarInfo(name)
                        info.size, info.mode, info.mtime = len(data), 0o644, 0
                        info.uid = info.gid = 0
                        info.uname = info.gname = ""
                        archive.addfile(info, io.BytesIO(data))
        with tarfile.open(temporary, "r:gz") as archive:
            require(archive.getnames() == sorted(members), "Archive member inventory changed")
            for member in archive:
                require(member.isfile() and archive.extractfile(member).read() == members[member.name],
                        f"Archive bytes differ from the captured evidence: {member.name}")
        inputs.recheck()
        with temporary.open("rb") as stream:
            digest = hashlib.file_digest(stream, "sha256").hexdigest()
        summary = {"status": "ARCHIVED_VALIDATED_EXISTING_FINAL_RECEIPT", "archive": str(args.output.resolve()),
                   "sha256": digest, "bytes": temporary.stat().st_size, "member_count": len(members),
                   "payload_bytes": sum(map(len, members.values())), "manifest_sha256": gates.sha256(members["MANIFEST.json"]),
                   "receipt_sha256": manifest["final_receipt_sha256"], **manifest["validated_scope"],
                   "historical_ci_is_not_six_target_proof_evidence": True}
        summary_temporary.write_bytes(encoded(summary))
        args.output.parent.mkdir(parents=True, exist_ok=True)
        temporary.replace(args.output)
        summary_temporary.replace(args.summary)
        print(json.dumps(summary, ensure_ascii=False, sort_keys=True))
        return 0
    except (OSError, ValueError, KeyError, TypeError, gates.VerificationError) as exc:
        print("Evidence archive refused: " + str(exc), file=sys.stderr)
        return 1
    finally:
        temporary.unlink(missing_ok=True)
        summary_temporary.unlink(missing_ok=True)


if __name__ == "__main__":
    raise SystemExit(main())
