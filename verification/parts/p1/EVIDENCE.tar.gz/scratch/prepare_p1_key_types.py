#!/usr/bin/env python3
"""Extract P1 source declaration headers and bind them to a successful Lean audit.

The ``extract`` command creates a source-only snapshot, explicitly unverified.
The ``render`` command refuses to create KEY_THEOREM_TYPES.md until it receives
the verifier's actual ``part1-final-receipt.json``, produced only after all six
targets have passed strict original frontend compilation and original checker
replay.  It checks the receipt against current source bytes, original logs, all
five defining-module census counts, and the 14 named theorem declarations.

The accepted receipt is produced by ``lean-runtime/finalize_receipt.py`` from
actual process records.  This script does not create or modify that receipt.
The source hashes identify the sources used to produce the imported audit
objects, not merely a later checkout.  This program validates those bindings;
it does not rerun Lean, kernel replay, a full build, or CI.  A source-only
snapshot is not a compilation claim.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import sys
from typing import Any


PROOF_BASELINE = "1a80c1bcce67886f699d097fc37fd245cd3620bf"
AUDIT_MODULE = "verification.parts.p1.Part1HistoryAudit"
AUDIT_DRIVER = "verification/parts/p1/Part1HistoryAudit.lean"
MODULE_PATHS = {
    "ImbalancedChen.OrdinaryLowerFourFrontier":
        "ImbalancedChen/OrdinaryLowerFourFrontier.lean",
    "ImbalancedChen.ActualSelectedPrefixLowerCellSum":
        "ImbalancedChen/ActualSelectedPrefixLowerCellSum.lean",
    "ImbalancedChen.ActualSelectedPrefixLowerOwnCubeIntegral":
        "ImbalancedChen/ActualSelectedPrefixLowerOwnCubeIntegral.lean",
    "ImbalancedChen.HistoricalPrefixCertificate":
        "ImbalancedChen/HistoricalPrefixCertificate.lean",
}
AUDITED_MODULE_PATHS = {
    **MODULE_PATHS,
    "verification.parts.p1.LevelCheckProbe":
        "verification/parts/p1/LevelCheckProbe.lean",
}
TARGET_MODULE_PATHS = {**AUDITED_MODULE_PATHS, AUDIT_MODULE: AUDIT_DRIVER}

# Full Lean name, defining module, short purpose.  Source headers are extracted
# verbatim; no hand-maintained type transcription is used.
KEY_THEOREMS = [
    (
        "ImbalancedChen.mem_ordinaryLowerFourFrontierTuples_iff_log",
        "ImbalancedChen.OrdinaryLowerFourFrontier",
        "实际下第四候选的父门控、排序、目标删素数与严格端点",
    ),
    (
        "ImbalancedChen.actualSelectedPrefixLowerOwnCubeSum_eq_cells",
        "ImbalancedChen.ActualSelectedPrefixLowerCellSum",
        "带 log N / singularSeries N 归一化的精确有限分解",
    ),
    (
        "ImbalancedChen.selectedPrefixLowerRestorationIntegral_eq_integrals",
        "ImbalancedChen.ActualSelectedPrefixLowerOwnCubeIntegral",
        "两个严格 own-cube 指示函数所在的同域真实积分",
    ),
    (
        "ImbalancedChen.tendsto_actualSelectedPrefixLowerOwnCubeSum",
        "ImbalancedChen.ActualSelectedPrefixLowerOwnCubeIntegral",
        "实际归一化素数修正和收敛到真实积分",
    ),
    (
        "ImbalancedChen.tendsto_actualSelectedPrefixLowerDensity_restoration",
        "ImbalancedChen.ActualSelectedPrefixLowerOwnCubeIntegral",
        "b ≤ old 下连接同一个实际下筛树",
    ),
    (
        "ImbalancedChen.tendsto_actualSelectedPrefixLowerDensity_ceil_normalized",
        "ImbalancedChen.ActualSelectedPrefixLowerOwnCubeIntegral",
        "规范 ceiling 枚举下的完整归一化极限",
    ),
    (
        "ImbalancedChen.historicalPrefixAncestorCell_unique",
        "ImbalancedChen.HistoricalPrefixCertificate",
        "共用半开网格中祖先盒归属的唯一性",
    ),
    (
        "ImbalancedChen.primeHistoryLogCoordinates_eq_historicalPrefixProject",
        "ImbalancedChen.HistoricalPrefixCertificate",
        "反向存储历史与处理顺序坐标投影对齐",
    ),
    (
        "ImbalancedChen.HistoricalPrefixCapData.level4_outside",
        "ImbalancedChen.HistoricalPrefixCertificate",
        "第四层盒外精确继承第三祖先 level",
    ),
    (
        "ImbalancedChen.HistoricalPrefixCapData.level5_outside",
        "ImbalancedChen.HistoricalPrefixCertificate",
        "第五层盒外精确继承第四祖先 level",
    ),
    (
        "ImbalancedChen.HistoricalPrefixCapData.levelCheck_of_selectedBoxCapChecks",
        "ImbalancedChen.HistoricalPrefixCertificate",
        "实际 inherited old cap 的整盒检查供应有限 level 条件",
    ),
    (
        "ImbalancedChen.HistoricalPrefixCapData.upperThirdToFifthSaving_eq",
        "ImbalancedChen.HistoricalPrefixCertificate",
        "实际 ordinary-base 历史树的第三至第五层 telescope",
    ),
    (
        "ImbalancedChen.HistoricalPrefixCapData.exponent5_apply_sub",
        "ImbalancedChen.HistoricalPrefixCertificate",
        "共同第五层盒中的新旧任意 cap 函数精确分解",
    ),
    (
        "ImbalancedChen.HistoricalPrefixCapData.upperFifthPolicy_eq_oddFirstExitPolicy",
        "ImbalancedChen.HistoricalPrefixCertificate",
        "raw odd-policy 接口；不声称 boxed support 或 factorization license",
    ),
]

ALLOWED_AXIOMS = {"propext", "Classical.choice", "Quot.sound"}
HEX256 = re.compile(r"[0-9a-f]{64}\Z")


class VerificationError(Exception):
    """An input is incomplete, inconsistent, or not a successful audit."""


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def read_utf8(path: Path) -> tuple[bytes, str]:
    data = path.read_bytes()
    return data, data.decode("utf-8")


def mask_lean_comments_and_strings(source: str) -> str:
    """Preserve source offsets while hiding nested comments and strings.

    The fixed target files contain ordinary theorem declarations.  This scanner
    deliberately rejects duplicate/missing declarations and malformed comments;
    it is not used as a substitute for Lean's declaration inventory.
    """
    masked = list(source)
    i = 0
    while i < len(source):
        if source.startswith("--", i):
            end = source.find("\n", i)
            if end == -1:
                end = len(source)
            for j in range(i, end):
                masked[j] = " "
            i = end
        elif source.startswith("/-", i):
            start = i
            depth = 1
            i += 2
            while i < len(source) and depth:
                if source.startswith("/-", i):
                    depth += 1
                    i += 2
                elif source.startswith("-/", i):
                    depth -= 1
                    i += 2
                else:
                    i += 1
            if depth:
                raise VerificationError("Unclosed Lean block comment in source")
            for j in range(start, i):
                if source[j] != "\n":
                    masked[j] = " "
        elif source[i] == '"':
            start = i
            i += 1
            closed = False
            while i < len(source):
                if source[i] == "\\":
                    i += 2
                elif source[i] == '"':
                    i += 1
                    closed = True
                    break
                else:
                    i += 1
            if not closed:
                raise VerificationError("Unclosed Lean string in source")
            for j in range(start, min(i, len(source))):
                if source[j] != "\n":
                    masked[j] = " "
        else:
            i += 1
    return "".join(masked)


def extract_theorem_header(source: str, short_name: str) -> str:
    masked = mask_lean_comments_and_strings(source)
    pattern = re.compile(
        rf"(?m)^[ \t]*theorem[ \t]+{re.escape(short_name)}(?=\s|[({{])"
    )
    matches = list(pattern.finditer(masked))
    if len(matches) != 1:
        raise VerificationError(
            f"Expected exactly one source theorem {short_name}, found {len(matches)}"
        )
    start = matches[0].start()
    i = matches[0].end()
    stack: list[str] = []
    opening = {"(": ")", "[": "]", "{": "}", "⦃": "⦄"}
    closing = set(opening.values())
    saw_result_colon = False
    while i < len(masked):
        if not stack and masked.startswith(":=", i):
            if not saw_result_colon:
                raise VerificationError(f"No result type found for {short_name}")
            return source[start:i].rstrip()
        ch = masked[i]
        if ch in opening:
            stack.append(opening[ch])
        elif ch in closing:
            if not stack or stack.pop() != ch:
                raise VerificationError(f"Unbalanced declaration header: {short_name}")
        elif ch == ":" and not stack:
            saw_result_colon = True
        i += 1
    raise VerificationError(f"No proof assignment found for {short_name}")


def source_snapshot(repo: Path) -> dict[str, Any]:
    files: dict[str, dict[str, Any]] = {}
    source_text: dict[str, str] = {}
    for path in TARGET_MODULE_PATHS.values():
        raw, content = read_utf8(repo / path)
        files[path] = {"sha256": sha256(raw), "bytes": len(raw)}
        source_text[path] = content
    declarations = []
    for name, module, purpose in KEY_THEOREMS:
        path = MODULE_PATHS[module]
        header = extract_theorem_header(source_text[path], name.rsplit(".", 1)[-1])
        declarations.append({
            "name": name,
            "module": module,
            "source_path": path,
            "source_sha256": files[path]["sha256"],
            "source_header_sha256": sha256(header.encode("utf-8")),
            "source_header": header,
            "purpose": purpose,
        })
    return {
        "schema": "p1-key-types-source-snapshot-v1",
        "verification_status": "SOURCE_ONLY_NOT_COMPILED",
        "proof_baseline": PROOF_BASELINE,
        "files": files,
        "declarations": declarations,
    }


def parse_audit_log(text: str) -> dict[str, Any]:
    declarations: dict[str, dict[str, Any]] = {}
    module_counts: dict[str, int] = {}
    totals: list[int] = []
    for line_no, line in enumerate(text.splitlines(), start=1):
        if re.match(r"^.+:\d+:\d+: error:", line):
            raise VerificationError(f"Lean error diagnostic in audit log at line {line_no}")
        stripped = line.strip()
        record: dict[str, Any] | None = None
        record_kind: str | None = None
        if stripped.startswith("PART1_HISTORY_AUDIT_DECL "):
            record = json.loads(stripped.removeprefix("PART1_HISTORY_AUDIT_DECL "))
            record_kind = "declaration"
        elif stripped.startswith("PART1_HISTORY_AUDIT_MODULE "):
            record = json.loads(stripped.removeprefix("PART1_HISTORY_AUDIT_MODULE "))
            record_kind = "module"
        elif stripped.startswith("PART1_HISTORY_AUDIT_COUNT "):
            value = stripped.removeprefix("PART1_HISTORY_AUDIT_COUNT ")
            if not value.isdecimal():
                raise VerificationError(f"Malformed final audit count at line {line_no}")
            totals.append(int(value))
            continue
        elif stripped.startswith("{"):
            # Also accept losslessly extracted JSONL records when final/module
            # records are retained.  The evidence hash binds these exact bytes.
            try:
                possible = json.loads(stripped)
            except json.JSONDecodeError:
                continue
            if isinstance(possible, dict):
                if {"name", "module", "type", "axioms"} <= possible.keys():
                    record, record_kind = possible, "declaration"
                elif {"module", "count"} <= possible.keys():
                    record, record_kind = possible, "module"
                elif possible.get("record") == "PART1_HISTORY_AUDIT_COUNT":
                    value = possible.get("count")
                    if type(value) is not int or value < 0:
                        raise VerificationError(f"Malformed JSONL count at line {line_no}")
                    totals.append(value)
                    continue
        if record_kind == "declaration":
            assert record is not None
            name = record.get("name")
            module = record.get("module")
            if not isinstance(name, str) or not name:
                raise VerificationError(f"Missing audit declaration name at line {line_no}")
            if name in declarations:
                raise VerificationError(f"Duplicate audited declaration: {name}")
            if module not in AUDITED_MODULE_PATHS:
                raise VerificationError(f"Unexpected defining module for {name}: {module}")
            if not isinstance(record.get("type"), str) or not record["type"].strip():
                raise VerificationError(f"Missing Lean type for {name}")
            axioms = record.get("axioms")
            if not isinstance(axioms, list) or not all(isinstance(x, str) for x in axioms):
                raise VerificationError(f"Malformed axiom list for {name}")
            extra = set(axioms) - ALLOWED_AXIOMS
            if extra:
                raise VerificationError(f"Forbidden axioms in {name}: {sorted(extra)}")
            if record.get("kind") == "axiom" or record.get("unsafe") is True:
                raise VerificationError(f"Unsafe or axiomatic audited declaration: {name}")
            declarations[name] = record
        elif record_kind == "module":
            assert record is not None
            module = record.get("module")
            count = record.get("count")
            if module not in AUDITED_MODULE_PATHS or module in module_counts:
                raise VerificationError(f"Unexpected/duplicate audit module marker: {module}")
            if type(count) is not int or count <= 0:
                raise VerificationError(f"Invalid declaration count for {module}")
            module_counts[module] = count
    if len(totals) != 1:
        raise VerificationError(f"Expected one final successful audit count, found {len(totals)}")
    if set(module_counts) != set(AUDITED_MODULE_PATHS):
        raise VerificationError("Audit does not contain all five defining-module success markers")
    if totals[0] != len(declarations) or totals[0] != sum(module_counts.values()):
        raise VerificationError("Final/module/declaration audit counts do not agree")
    for module, count in module_counts.items():
        actual = sum(record["module"] == module for record in declarations.values())
        if actual != count:
            raise VerificationError(f"Declaration inventory mismatch in {module}")
    return {"declarations": declarations, "module_counts": module_counts, "total": totals[0]}


def validated_reference(
    reference: Any, label: str, expected_path: Path | None = None
) -> bytes:
    if not isinstance(reference, dict):
        raise VerificationError(f"Missing verifier file reference: {label}")
    path_value, digest, size = (reference.get(key) for key in ("path", "sha256", "bytes"))
    if not isinstance(path_value, str) or not path_value:
        raise VerificationError(f"Missing recorded path: {label}")
    if not isinstance(digest, str) or not HEX256.fullmatch(digest):
        raise VerificationError(f"Missing/invalid recorded SHA-256: {label}")
    if type(size) is not int or size < 0:
        raise VerificationError(f"Missing/invalid recorded byte count: {label}")
    path = Path(path_value).resolve()
    if expected_path is not None and path != expected_path.resolve():
        raise VerificationError(f"Recorded file path does not match the source: {label}")
    data = path.read_bytes()
    if sha256(data) != digest or len(data) != size:
        raise VerificationError(f"File bytes differ from successful verifier record: {label}")
    return data


def validate_final_receipt(
    repo: Path, receipt: dict[str, Any], snapshot: dict[str, Any]
) -> tuple[bytes, dict[str, Any]]:
    """Require the actual six-target final receipt and check its log bindings."""
    if not isinstance(receipt, dict):
        raise VerificationError("The final verifier receipt must be a JSON object")
    if receipt.get("repository_path") != str(repo):
        raise VerificationError("The final receipt refers to a different repository")
    verification = receipt.get("verification")
    if not isinstance(verification, dict):
        raise VerificationError("Missing real verification mode in final receipt")
    required_mode = {
        "actual_original_frontend_compilation": True,
        "frontend_api": "Lean.Elab.runFrontend",
        "trustLevel": 0,
        "target_warning_as_error": True,
        "metadata_adapter_during_compilation_or_replay": False,
        "original_leanchecker_six_sequential_calls_aggregate_exit_code": 0,
    }
    for field, expected in required_mode.items():
        actual = verification.get(field)
        if type(actual) is not type(expected) or actual != expected:
            raise VerificationError(f"Missing successful original strict verification field: {field}")
    individual_exits = verification.get("original_leanchecker_individual_exit_codes")
    if not isinstance(individual_exits, dict) or set(individual_exits) != set(TARGET_MODULE_PATHS) or any(
        type(code) is not int or code != 0 for code in individual_exits.values()
    ):
        raise VerificationError("Original checker individual exit codes must be zero for all six targets")
    targets = receipt.get("targets")
    if not isinstance(targets, dict) or set(targets) != set(TARGET_MODULE_PATHS):
        raise VerificationError("Final receipt must contain exactly the six expected targets")
    replay = receipt.get("replay")
    if not isinstance(replay, dict):
        raise VerificationError("Missing original checker replay result")
    if replay.get("verified") is not True or type(replay.get("returncode")) is not int or replay["returncode"] != 0:
        raise VerificationError("Original checker replay did not genuinely pass")
    observed = replay.get("observed_replay_lines")
    if not isinstance(observed, list) or len(observed) != 6 or set(observed) != set(TARGET_MODULE_PATHS):
        raise VerificationError("Original checker replay did not cover exactly all six targets")
    if replay.get("metadata_adapter") is not False:
        raise VerificationError("Unexpected metadata adapter in original checker replay")

    audit_bytes: bytes | None = None
    for module, relative_path in TARGET_MODULE_PATHS.items():
        record = targets[module]
        if not isinstance(record, dict):
            raise VerificationError(f"Missing target compilation record: {module}")
        if type(record.get("returncode")) is not int or record["returncode"] != 0:
            raise VerificationError(f"Target compilation did not pass: {module}")
        if type(record.get("trustLevel")) is not int or record["trustLevel"] != 0 or record.get("strict") is not True:
            raise VerificationError(f"Target was not compiled strictly at trustLevel zero: {module}")
        if record.get("metadata_adapter") is not False:
            raise VerificationError(f"Unexpected metadata adapter during target compilation: {module}")
        if record.get("original_checker_replayed_defined_declarations") is not True:
            raise VerificationError(f"Original checker coverage not confirmed: {module}")
        source_bytes = validated_reference(record.get("source"), module + " source", repo / relative_path)
        digest = sha256(source_bytes)
        if digest != snapshot["files"][relative_path]["sha256"]:
            raise VerificationError(f"Source changed during report generation: {relative_path}")
        for field in ("source_sha256_before", "source_sha256_after"):
            if record.get(field) != digest:
                raise VerificationError(f"Compiled-source hash mismatch in {field}: {module}")
            replay_hashes = replay.get(field)
            if not isinstance(replay_hashes, dict) or replay_hashes.get(module) != digest:
                raise VerificationError(f"Replay-source hash mismatch in {field}: {module}")

        log_bytes = validated_reference(record.get("log"), module + " compilation log")
        lines = log_bytes.decode("utf-8").splitlines()
        command = record.get("command")
        if not isinstance(command, list) or not command or not all(isinstance(part, str) for part in command):
            raise VerificationError(f"Missing actual compilation argv: {module}")
        if not lines or not lines[0].startswith("{"):
            raise VerificationError(f"Missing original compiler log command record: {module}")
        header = json.loads(lines[0])
        if header.get("command") != command or header.get("source_sha256_before") != digest:
            raise VerificationError(f"Original command/source log header does not match receipt: {module}")
        if header.get("trustLevel") != 0 or header.get("metadata_adapter") is not False:
            raise VerificationError(f"Unexpected original frontend mode in raw log: {module}")
        marker = "FRONTEND_OK module=" + module + " trustLevel=0"
        if lines.count(marker) != 1:
            raise VerificationError(f"Missing or duplicate real frontend success marker: {module}")

        parts = record.get("artifact_parts")
        if not isinstance(parts, dict) or not parts:
            raise VerificationError(f"Missing replayed target artifact references: {module}")
        artifact_hashes = {}
        for part_name, reference in parts.items():
            artifact_hashes[part_name] = sha256(validated_reference(reference, module + " artifact " + part_name))
        for field in ("artifacts_sha256_before", "artifacts_sha256_after"):
            replay_parts = replay.get(field)
            if not isinstance(replay_parts, dict) or replay_parts.get(module) != artifact_hashes:
                raise VerificationError(f"Replayed artifact hashes differ in {field}: {module}")
        if module == AUDIT_MODULE:
            audit_bytes = log_bytes

    replay_log_path = replay.get("log")
    if not isinstance(replay_log_path, str):
        raise VerificationError("Missing actual original checker raw log path")
    replay_bytes, replay_text = read_utf8(Path(replay_log_path))
    if replay.get("log_sha256") != sha256(replay_bytes):
        raise VerificationError("Aggregate original checker log differs from its receipt hash")
    replay_lines = replay_text.splitlines()
    commands, calls = replay.get("commands"), replay.get("calls")
    if not isinstance(commands, list) or len(commands) != 6 or not isinstance(calls, list) or len(calls) != 6:
        raise VerificationError("Original checker receipt must contain six sequential single-target calls")
    if not replay_lines or json.loads(replay_lines[0]).get("commands") != commands:
        raise VerificationError("Original checker aggregate argv records do not match receipt")
    if replay.get("LEAN_NUM_THREADS") != "1" or json.loads(replay_lines[0]).get("LEAN_NUM_THREADS") != "1":
        raise VerificationError("Sequential checker replay must record LEAN_NUM_THREADS=1")
    call_modules = []
    for command, call in zip(commands, calls):
        module = call.get("module") if isinstance(call, dict) else None
        if module not in TARGET_MODULE_PATHS or module in call_modules:
            raise VerificationError(f"Missing, unexpected, or duplicate single-target replay: {module}")
        call_modules.append(module)
        if not isinstance(command, list) or not all(isinstance(arg, str) for arg in command) or len(command) != 3:
            raise VerificationError(f"Malformed original checker argv: {module}")
        if Path(command[0]).name != "leanchecker" or command[1:] != ["--verbose", module] or call.get("command") != command:
            raise VerificationError(f"Original checker call is not the recorded single target: {module}")
        if call.get("verified") is not True or type(call.get("returncode")) is not int or call["returncode"] != 0:
            raise VerificationError(f"Original single-target checker call did not pass: {module}")
        call_path = call.get("log")
        if not isinstance(call_path, str):
            raise VerificationError(f"Missing original single-target checker log: {module}")
        call_bytes, call_text = read_utf8(Path(call_path))
        if call.get("log_sha256") != sha256(call_bytes) or call_text not in replay_text:
            raise VerificationError(f"Original single-target log/hash differs from the aggregate: {module}")
        call_lines = call_text.splitlines()
        header = json.loads(call_lines[0]) if call_lines else {}
        if header.get("module") != module or header.get("command") != command or header.get("LEAN_NUM_THREADS") != "1":
            raise VerificationError(f"Original single-target log header differs from receipt: {module}")
        if header.get("metadata_adapter") is not False or header.get("source_sha256") != replay["source_sha256_before"][module]:
            raise VerificationError(f"Original single-target source/mode differs from receipt: {module}")
        if header.get("artifacts_sha256_before") != replay["artifacts_sha256_before"][module]:
            raise VerificationError(f"Original single-target artifact record differs from receipt: {module}")
        call_replayed = [match.group(1) for line in call_lines
                         if (match := re.fullmatch(r"replaying (\S+)\s*", line))]
        if call_replayed != [module] or call.get("observed_replay_lines") != [module]:
            raise VerificationError(f"Original checker call does not replay exactly its target: {module}")
    raw_replayed = [match.group(1) for line in replay_lines
                    if (match := re.fullmatch(r"replaying (\S+)\s*", line))]
    if raw_replayed != observed or raw_replayed != call_modules:
        raise VerificationError("Original checker raw replay lines differ from receipt")

    if audit_bytes is None:
        raise VerificationError("Missing successful raw audit log")
    audit = parse_audit_log(audit_bytes.decode("utf-8"))
    recorded_audit = receipt.get("audit")
    if not isinstance(recorded_audit, dict):
        raise VerificationError("Missing final defining-module audit census")
    if set(recorded_audit.get("audited_defining_modules", [])) != set(AUDITED_MODULE_PATHS):
        raise VerificationError("Receipt defining-module inventory does not include all five modules")
    if recorded_audit.get("declaration_count") != audit["total"] or recorded_audit.get("module_counts") != audit["module_counts"]:
        raise VerificationError("Receipt audit declaration/module counts differ from the actual log")
    full_types_bytes = validated_reference(recorded_audit.get("full_types_in_raw_audit_log"), "audit full-types log")
    if full_types_bytes != audit_bytes:
        raise VerificationError("Receipt full-types reference points to a different log")
    recorded_declarations = recorded_audit.get("declarations")
    if not isinstance(recorded_declarations, list) or len(recorded_declarations) != audit["total"]:
        raise VerificationError("Receipt declaration census is missing or incomplete")
    seen = set()
    for entry in recorded_declarations:
        name = entry.get("name") if isinstance(entry, dict) else None
        if name in seen or name not in audit["declarations"]:
            raise VerificationError(f"Receipt declaration name is duplicate or absent in raw log: {name}")
        seen.add(name)
        original = audit["declarations"][name]
        if entry != {key: original[key] for key in ("name", "module", "kind", "axioms")}:
            raise VerificationError(f"Receipt declaration record differs from actual audit: {name}")
    return audit_bytes, audit


def fenced(text: str, language: str = "lean") -> str:
    longest = max((len(m.group()) for m in re.finditer(r"`+", text)), default=0)
    fence = "`" * max(3, longest + 1)
    return f"{fence}{language}\n{text}\n{fence}"


def render_markdown(
    snapshot: dict[str, Any], audit: dict[str, Any], receipt: dict[str, Any],
    audit_hash: str, receipt_hash: str,
) -> str:
    matches = []
    for source in snapshot["declarations"]:
        record = audit["declarations"].get(source["name"])
        if record is None:
            raise VerificationError(f"Key theorem absent from successful audit: {source['name']}")
        if record["module"] != source["module"] or record.get("kind") != "theorem":
            raise VerificationError(f"Defining-module/kind mismatch for {source['name']}")
        matches.append((source, record))

    out = [
        "# Part 1 关键定理：完整源码声明头与 Lean 审计类型",
        "",
        "## 证据与展示范围",
        "",
        f"- 共同证明基线：`{PROOF_BASELINE}`。",
        f"- 本文逐项匹配了实际成功审计中的 **{len(matches)} 条关键定理**；四个生产模块加 `LevelCheckProbe`，共五个定义模块的完整审计库存为 **{audit['total']} 条声明**。",
        "- 实际编译方式：原版 `Lean.Elab.runFrontend`，`trustLevel = 0`，六个目标均以 strict 模式通过；实际审计由 `verification.parts.p1.Part1HistoryAudit` 的 Lean 环境库存及 `Lean.collectAxioms` 产生。",
        f"- 审计编译进程的独立记录退出码：`{receipt['targets'][AUDIT_MODULE]['returncode']}`；原版 `leanchecker` 六次顺序单目标 replay 的汇总退出码：`{receipt['replay']['returncode']}`（每次 `LEAN_NUM_THREADS=1`，六次均退出 `0` 并分别覆盖对应目标模块的定义声明）。",
        f"- 审计日志 SHA-256：`{audit_hash}`。",
        f"- 实际最终回执 JSON SHA-256：`{receipt_hash}`。",
    ]
    out.extend([
        "",
        "本文件只转录已经成功的声明库存、类型和传递公理报告，并核对定义模块、实际编译源码、编译日志及 replay 对象的哈希。提取脚本不自行运行编译或 replay，也不创建成功回执。上述原版 frontend API 编译不等同于已运行标准 `lake build`；原版检查器的六模块 replay 不声称重放了全部导入依赖；本记录不声称全仓 CI 已通过。最终交付 Git SHA 由主交付记录提供。",
        "",
        "Lean 的 `Meta.ppExpr` 生成可读类型，可能隐藏隐式或实例实参，以及 proof-irrelevant 的证明实参；pretty-printed 文本不是内核表达式的完全展开序列化。本文件同时原样保留每条定理的完整源码声明头，包含源码中的全部绑定和假设，只去掉证明体。完整名称、定义模块和源码 SHA-256 将这两个视图绑定到同一项实际审计结果。",
        "",
        "本里程碑的范围是普通父树的 lower fourth 积分与有限 upper third/fourth/fifth 历史 level 接口。raw odd-policy 等式不代表 boxed support、factorization license、完整历史第五层积分、K/c 数值界或主定理已经完成。",
        "",
        "## 经验证据绑定的源码",
        "",
        "| 源码路径 | SHA-256 |",
        "| --- | --- |",
    ])
    for path, info in snapshot["files"].items():
        out.append(f"| `{path}` | `{info['sha256']}` |")
    out.extend([
        "", "## 实际声明库存", "",
        "| 定义模块 | 审计声明数 |", "| --- | ---: |",
    ])
    for module, count in audit["module_counts"].items():
        out.append(f"| `{module}` | {count} |")
    out.extend([
        "", "实际 Audit 编译的原始 argv：", "",
        fenced(json.dumps(receipt["targets"][AUDIT_MODULE]["command"], ensure_ascii=False, indent=2), "json"),
    ])
    out.extend(["", "## 关键声明目录", "", "| 序号 | 完整名称 | 用途 |", "| --- | --- | --- |"])
    for index, (source, _record) in enumerate(matches, start=1):
        out.append(f"| {index} | `{source['name']}` | {source['purpose']} |")
    for index, (source, record) in enumerate(matches, start=1):
        axioms = ", ".join(f"`{name}`" for name in record["axioms"]) or "无"
        out.extend([
            "", f"## {index}. {source['name']}", "",
            source["purpose"] + "。", "",
            f"- 定义模块：`{source['module']}`。",
            f"- 源码路径：`{source['source_path']}`。",
            f"- 整个源码文件 SHA-256：`{source['source_sha256']}`。",
            f"- 此声明头 SHA-256：`{source['source_header_sha256']}`。",
            f"- 实际传递公理：{axioms}。", "",
            "### 完整源码声明头", "",
            fenced(source["source_header"]), "",
            "### 实际 Lean 审计输出的类型", "",
            fenced(record["type"]),
        ])
    return "\n".join(out) + "\n"


def atomic_write(path: Path, data: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + f".tmp-{os.getpid()}")
    try:
        temporary.write_text(data, encoding="utf-8")
        temporary.replace(path)
    finally:
        temporary.unlink(missing_ok=True)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    commands = parser.add_subparsers(dest="mode", required=True)
    extract = commands.add_parser("extract", help="Write source-only, explicitly unverified declaration headers")
    extract.add_argument("--repo", type=Path, required=True)
    extract.add_argument("--output", type=Path, required=True)
    render = commands.add_parser("render", help="Create key types only after matching the actual six-target final receipt")
    render.add_argument("--repo", type=Path, required=True)
    render.add_argument("--receipt", type=Path, required=True)
    render.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    try:
        snapshot = source_snapshot(args.repo.resolve())
        if args.mode == "extract":
            atomic_write(args.output, json.dumps(snapshot, ensure_ascii=False, indent=2) + "\n")
            print(json.dumps({
                "status": "SOURCE_ONLY_NOT_COMPILED",
                "theorem_count": len(snapshot["declarations"]),
                "output": str(args.output.resolve()),
            }))
            return 0
        receipt_bytes, receipt_text = read_utf8(args.receipt)
        receipt = json.loads(receipt_text)
        audit_bytes, audit = validate_final_receipt(args.repo.resolve(), receipt, snapshot)
        markdown = render_markdown(snapshot, audit, receipt, sha256(audit_bytes), sha256(receipt_bytes))
        if source_snapshot(args.repo.resolve()) != snapshot:
            raise VerificationError("Audited sources changed while preparing the final report")
        # The deliverable is written only after all success, inventory and source
        # bindings have passed.  Failures cannot leave a partial success report.
        atomic_write(args.output, markdown)
        print(json.dumps({
            "status": "MATCHED_SUCCESSFUL_AUDIT",
            "key_theorem_count": len(KEY_THEOREMS),
            "audited_declaration_count": audit["total"],
            "output": str(args.output.resolve()),
            "output_sha256": sha256(markdown.encode("utf-8")),
        }))
        return 0
    except (OSError, UnicodeError, ValueError, TypeError, KeyError, VerificationError) as error:
        print(f"REFUSED: {error}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
