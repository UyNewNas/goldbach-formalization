import Init
namespace P1FrontendSmoke

theorem add_zero (n : Nat) : n + 0 = n := by
  exact Nat.add_zero n

end P1FrontendSmoke
