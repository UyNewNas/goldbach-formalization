import Lake
import Lean.Elab.Frontend

open Lake DSL

package frontendSmoke

script compileSmoke do
  let some root ← IO.getEnv "LEAN_SYSROOT"
    | throw <| IO.userError "LEAN_SYSROOT must be explicitly set"
  Lean.initSearchPath root
  unsafe Lean.enableInitializersExecution
  let dir := System.FilePath.mk "/workspace/scratch/127408f63891/lean-runtime/frontend-smoke"
  let source := dir / "P1FrontendSmoke.lean"
  let input ← IO.FS.readFile source
  let opts := Lean.Options.empty.setBool `warningAsError true
  let result ← Lean.Elab.runFrontend input opts source.toString `P1FrontendSmoke
    (trustLevel := 0) (oleanFileName? := some (dir / "P1FrontendSmoke.olean"))
  match result with
  | none => return 1
  | some env =>
    unless env.contains `P1FrontendSmoke.add_zero do
      throw <| IO.userError "Expected theorem missing from compiler environment"
    IO.println s!"FRONTEND_SMOKE_OK trustLevel=0 Lean.githash={Lean.githash}"
    return 0

script rejectSmoke do
  let some root ← IO.getEnv "LEAN_SYSROOT"
    | throw <| IO.userError "LEAN_SYSROOT must be explicitly set"
  Lean.initSearchPath root
  unsafe Lean.enableInitializersExecution
  let opts := Lean.Options.empty.setBool `warningAsError true
  let result ← Lean.Elab.runFrontend
    "import Init\ntheorem invalidSmoke : (0 : Nat) = 1 := by rfl\n"
    opts "RejectedSmoke.lean" `RejectedSmoke (trustLevel := 0)
  match result with
  | none =>
    IO.println "NEGATIVE_CONTROL_REJECTED trustLevel=0"
    return 0
  | some _ =>
    IO.eprintln "ERROR: invalid theorem unexpectedly accepted"
    return 1
