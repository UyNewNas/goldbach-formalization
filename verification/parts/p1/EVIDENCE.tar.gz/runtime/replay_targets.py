"""Sequentially replay all six actual targets with the original leanchecker.

Default replayFromImports imports dependencies and replays the declarations
defined by each selected module (including its most private data part).  This
does not claim to replay every declaration of the imported dependency closure.
"""
import json
import re
import subprocess
import time
import compile_driver as d

TARGETS = [
    "ImbalancedChen.OrdinaryLowerFourFrontier",
    "ImbalancedChen.ActualSelectedPrefixLowerCellSum",
    "ImbalancedChen.ActualSelectedPrefixLowerOwnCubeIntegral",
    "ImbalancedChen.HistoricalPrefixCertificate",
    "verification.parts.p1.LevelCheckProbe",
    "verification.parts.p1.Part1HistoryAudit",
]

def artifact_hashes(module):
    output = d.olean(module)
    return {p.name:d.digest(p) for p in sorted(output.parent.glob(output.name+"*")) if p.is_file()}

def main():
    state = json.loads((d.RUNTIME/"logs/closure/state.json").read_text())
    logdir = d.RUNTIME/"logs/replay"
    logdir.mkdir(parents=True,exist_ok=True)
    before = {}
    source_hashes = {}
    for module in TARGETS:
        record = state[module]
        source_hashes[module] = d.digest(d.INDEX[module][0])
        if not record["strict"] or record["source_sha256_after"] != source_hashes[module]:
            raise RuntimeError("Actual strict compilation is missing or stale: "+module)
        if record["olean_sha256"] != d.digest(d.olean(module)):
            raise RuntimeError("Compiled object changed before replay: "+module)
        before[module] = artifact_hashes(module)
    source = d.TOOLROOT/"src/lean/LeanChecker.lean"
    semantics = {"source_path":str(source),"source_sha256":d.digest(source),
                 "source_permalink":"https://github.com/leanprover/lean4/blob/62eed1db4d67327ec8120be05f1a1b0847d74561/src/LeanChecker.lean",
                 "functions":["replayFromImports","main"],
                 "coverage":"Declarations defined by the six selected modules, from their most-private data parts. Imported dependencies are loaded; their full declaration closure is not replayed by default.",
                 "selection":"Each of six sequential original CLI calls selects one exact module prefix and runs replayFromImports. Each call must print exactly its own expected replay line; the aggregate must contain all six.",
                 "scheduling":"Six sequential single-module processes, with LEAN_NUM_THREADS=1; no assumption about multi-target IO.asTask concurrency is required.",
                 "fresh_flag":False}
    (logdir/"checker-semantics.json").write_text(json.dumps(semantics,indent=2)+"\n")
    commands = [[str(d.TOOLROOT/"bin/leanchecker"),"--verbose",module] for module in TARGETS]
    log = logdir/"six-targets.log"
    env = d.environment(False)
    env["LEAN_NUM_THREADS"] = "1"
    started = time.monotonic()
    calls = []
    print("REPLAY_START_SEQUENTIAL "+json.dumps(TARGETS),flush=True)
    with log.open("w") as aggregate:
        aggregate.write(json.dumps({"commands":commands,"artifacts_sha256_before":before,
                                   "source_sha256":source_hashes,"metadata_adapter":False,
                                   "LEAN_NUM_THREADS":env["LEAN_NUM_THREADS"],
                                   "checker_source_sha256":semantics["source_sha256"]})+"\n")
        aggregate.flush()
        for module, command in zip(TARGETS, commands):
            call_log = logdir/(module+".log")
            call_started = time.monotonic()
            print("REPLAY_MODULE_START "+module,flush=True)
            with call_log.open("w") as handle:
                handle.write(json.dumps({"module":module,"command":command,
                                         "source_sha256":source_hashes[module],
                                         "artifacts_sha256_before":before[module],
                                         "metadata_adapter":False,
                                         "LEAN_NUM_THREADS":env["LEAN_NUM_THREADS"]})+"\n")
                handle.flush()
                completed = subprocess.run(command,cwd=d.REPO,env=env,stdout=handle,
                                           stderr=subprocess.STDOUT)
            raw = call_log.read_text()
            call_observed = re.findall(r"^replaying (\S+)\s*$",raw,re.MULTILINE)
            call = {"module":module,"command":command,"returncode":completed.returncode,
                    "elapsed_seconds":round(time.monotonic()-call_started,3),
                    "log":str(call_log),"log_sha256":d.digest(call_log),
                    "observed_replay_lines":call_observed,
                    "verified":completed.returncode==0 and call_observed==[module]}
            calls.append(call)
            aggregate.write(raw)
            aggregate.write("REPLAY_MODULE_RESULT "+json.dumps(call)+"\n")
            aggregate.flush()
            (logdir/"calls-progress.json").write_text(json.dumps(calls,indent=2)+"\n")
            print("REPLAY_MODULE_RESULT "+json.dumps(call),flush=True)
            if not call["verified"]:
                break
    after = {module:artifact_hashes(module) for module in TARGETS}
    source_after = {module:d.digest(d.INDEX[module][0]) for module in TARGETS}
    observed = re.findall(r"^replaying (\S+)\s*$",log.read_text(),re.MULTILINE)
    success = len(calls)==len(TARGETS) and all(call["verified"] for call in calls) \
              and len(observed)==len(TARGETS) and set(observed)==set(TARGETS) \
              and before==after and source_hashes==source_after
    aggregate_code = next((call["returncode"] or 1 for call in calls if not call["verified"]),
                          0 if len(calls)==len(TARGETS) else 1)
    result={"returncode":aggregate_code,"verified":success,"elapsed_seconds":round(time.monotonic()-started,3),
            "returncode_semantics":"Zero requires all six original single-module processes to exit zero with exact coverage; otherwise the first failed call code or an incomplete-coverage error is reported.",
            "commands":commands,"calls":calls,"log":str(log),"log_sha256":d.digest(log),
            "expected_targets":TARGETS,"observed_replay_lines":observed,
            "artifacts_sha256_before":before,"artifacts_sha256_after":after,
            "source_sha256_before":source_hashes,"source_sha256_after":source_after,
            "original_leanchecker_sha256":d.digest(d.TOOLROOT/"bin/leanchecker"),
            "semantics":semantics,"LEAN_NUM_THREADS":env["LEAN_NUM_THREADS"],"metadata_adapter":False}
    (logdir/"results.json").write_text(json.dumps(result,indent=2)+"\n")
    print("REPLAY_RESULT "+json.dumps({k:v for k,v in result.items() if k not in ("artifacts_sha256_before","artifacts_sha256_after","semantics")}),flush=True)
    if not success:
        raise RuntimeError("Replay failed, missed a target, or an artifact/source changed")
    print("REPLAY_ALL_SIX_OK",flush=True)

if __name__=="__main__":
    main()
