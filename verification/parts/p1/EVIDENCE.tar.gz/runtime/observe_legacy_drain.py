"""Open the scratch scheduling gate only after actual legacy subprocess exits.

This watcher never starts Lean, sends process signals, or changes proof sources.
"""
from datetime import datetime, timezone
from pathlib import Path
import json
import time

runtime = Path("/workspace/scratch/127408f63891/lean-runtime")
control = runtime / "logs/resource-adjustment-01"
transition = json.loads((control / "transition.json").read_text())
modules = transition["legacy_modules"]
state_path = runtime / "logs/closure/state.json"
results_path = runtime / "logs/closure/results.jsonl"

while True:
    try:
        state = json.loads(state_path.read_text())
    except (OSError, json.JSONDecodeError):
        state = {}
    failures = []
    for line in results_path.read_text().splitlines():
        try:
            result = json.loads(line)
        except json.JSONDecodeError:
            continue
        if result.get("module") in modules and result.get("returncode") != 0:
            failures.append(result)
    if failures:
        record = {"recorded_utc": datetime.now(timezone.utc).isoformat(),
                  "successful_natural_drain": False, "failures": failures,
                  "new_frontends_may_start": False}
        (control / "drain-result.json").write_text(json.dumps(record, indent=2) + "\n")
        (control / "legacy-drain.failed").write_text("A legacy frontend exited unsuccessfully.\n")
        print(json.dumps(record), flush=True)
        raise SystemExit(1)
    if all(module in state and state[module]["returncode"] == 0
           and state[module]["trustLevel"] == 0
           and state[module]["source_sha256_before"] == state[module]["source_sha256_after"]
           for module in modules):
        record = {"recorded_utc": datetime.now(timezone.utc).isoformat(),
                  "successful_natural_drain": True,
                  "legacy_actual_success_records": {module: state[module] for module in modules},
                  "new_frontends_may_start": True,
                  "exclusive_file_lock_required": True,
                  "legacy_processes_signaled_or_restarted": False}
        (control / "drain-result.json").write_text(json.dumps(record, indent=2) + "\n")
        (control / "legacy-drained.ok").write_text("Both legacy subprocesses exited successfully; serialize all new frontend bodies.\n")
        print(json.dumps({key: value for key, value in record.items()
                          if key != "legacy_actual_success_records"}), flush=True)
        raise SystemExit(0)
    time.sleep(1)
