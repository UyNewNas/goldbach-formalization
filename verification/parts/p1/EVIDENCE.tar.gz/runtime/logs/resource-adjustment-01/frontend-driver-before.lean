import Lake
import Lean.Elab.Frontend

open Lake DSL

package p1FrontendDriver

/-- Invoke the unchanged Lean frontend API at trust level zero. -/
script compileOne (args) do
  let [sourceName, moduleName, outputName, strictName] := args
    | throw <| IO.userError "usage: compileOne SOURCE MODULE OUTPUT strict|normal"
  unless strictName == "strict" || strictName == "normal" do
    throw <| IO.userError "invalid diagnostics mode"
  let some root ← IO.getEnv "LEAN_SYSROOT"
    | throw <| IO.userError "LEAN_SYSROOT must be explicitly set"
  Lean.initSearchPath root
  unsafe Lean.enableInitializersExecution
  let source := System.FilePath.mk sourceName
  let output := System.FilePath.mk outputName
  if let some parent := output.parent then
    IO.FS.createDirAll parent
  let input ← IO.FS.readFile source
  let opts := Lean.Options.empty.setBool `warningAsError (strictName == "strict")
  IO.println s!"FRONTEND_START module={moduleName} trustLevel=0 strict={strictName} Lean.githash={Lean.githash}"
  let result ← Lean.Elab.runFrontend input opts sourceName moduleName.toName
    (trustLevel := 0) (oleanFileName? := some output)
  match result with
  | none =>
    IO.eprintln s!"FRONTEND_FAILED module={moduleName}"
    return 1
  | some _ =>
    IO.println s!"FRONTEND_OK module={moduleName} trustLevel=0"
    return 0
