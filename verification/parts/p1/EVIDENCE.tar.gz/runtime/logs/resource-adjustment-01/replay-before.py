"""Use one original leanchecker invocation for all six actual Part 1 targets.

Default replayFromImports imports dependencies and replays the declarations
defined by each selected module (including its most private data part).  This
does not claim to replay every declaration of the imported dependency closure.
"""
import json
import re
import subprocess
import time
import compile_driver as d

TARGETS = [
    "ImbalancedChen.OrdinaryLowerFourFrontier",
    "ImbalancedChen.ActualSelectedPrefixLowerCellSum",
    "ImbalancedChen.ActualSelectedPrefixLowerOwnCubeIntegral",
    "ImbalancedChen.HistoricalPrefixCertificate",
    "verification.parts.p1.LevelCheckProbe",
    "verification.parts.p1.Part1HistoryAudit",
]

def artifact_hashes(module):
    output = d.olean(module)
    return {p.name:d.digest(p) for p in sorted(output.parent.glob(output.name+"*")) if p.is_file()}

def main():
    state = json.loads((d.RUNTIME/"logs/closure/state.json").read_text())
    logdir = d.RUNTIME/"logs/replay"
    logdir.mkdir(parents=True,exist_ok=True)
    before = {}
    source_hashes = {}
    for module in TARGETS:
        record = state[module]
        source_hashes[module] = d.digest(d.INDEX[module][0])
        if not record["strict"] or record["source_sha256_after"] != source_hashes[module]:
            raise RuntimeError("Actual strict compilation is missing or stale: "+module)
        if record["olean_sha256"] != d.digest(d.olean(module)):
            raise RuntimeError("Compiled object changed before replay: "+module)
        before[module] = artifact_hashes(module)
    source = d.TOOLROOT/"src/lean/LeanChecker.lean"
    semantics = {"source_path":str(source),"source_sha256":d.digest(source),
                 "source_permalink":"https://github.com/leanprover/lean4/blob/62eed1db4d67327ec8120be05f1a1b0847d74561/src/LeanChecker.lean",
                 "functions":["replayFromImports","main"],
                 "coverage":"Declarations defined by the six selected modules, from their most-private data parts. Imported dependencies are loaded; their full declaration closure is not replayed by default.",
                 "selection":"Original multi-target CLI selects matching module prefixes, deduplicates them, and runs replayFromImports for each. This record requires exactly the six expected replay lines.",
                 "fresh_flag":False}
    (logdir/"checker-semantics.json").write_text(json.dumps(semantics,indent=2)+"\n")
    command = [str(d.TOOLROOT/"bin/leanchecker"),"--verbose"]+TARGETS
    log = logdir/"six-targets.log"
    env = d.environment(False)
    started = time.monotonic()
    print("REPLAY_START "+json.dumps(TARGETS),flush=True)
    with log.open("w") as f:
        f.write(json.dumps({"command":command,"artifacts_sha256_before":before,"source_sha256":source_hashes,
                            "metadata_adapter":False,"LEAN_NUM_THREADS":env["LEAN_NUM_THREADS"],
                            "checker_source_sha256":semantics["source_sha256"]})+"\n")
        f.flush()
        completed=subprocess.run(command,cwd=d.REPO,env=env,stdout=f,stderr=subprocess.STDOUT)
    after = {module:artifact_hashes(module) for module in TARGETS}
    source_after = {module:d.digest(d.INDEX[module][0]) for module in TARGETS}
    observed = re.findall(r"^replaying (\S+)\s*$",log.read_text(),re.MULTILINE)
    success = completed.returncode == 0 and len(observed)==len(TARGETS) and set(observed)==set(TARGETS) \
              and before==after and source_hashes==source_after
    result={"returncode":completed.returncode,"verified":success,"elapsed_seconds":round(time.monotonic()-started,3),
            "command":command,"log":str(log),"expected_targets":TARGETS,"observed_replay_lines":observed,
            "artifacts_sha256_before":before,"artifacts_sha256_after":after,
            "source_sha256_before":source_hashes,"source_sha256_after":source_after,
            "original_leanchecker_sha256":d.digest(d.TOOLROOT/"bin/leanchecker"),
            "semantics":semantics,"LEAN_NUM_THREADS":env["LEAN_NUM_THREADS"],"metadata_adapter":False}
    (logdir/"results.json").write_text(json.dumps(result,indent=2)+"\n")
    print("REPLAY_RESULT "+json.dumps({k:v for k,v in result.items() if k not in ("artifacts_sha256_before","artifacts_sha256_after","semantics")}),flush=True)
    if not success:
        raise RuntimeError("Replay failed, missed a target, or an artifact/source changed")
    print("REPLAY_ALL_SIX_OK",flush=True)

if __name__=="__main__":
    main()
