"""Hold the ordinary frontend mutex until every pre-gate invocation drains.

The original observer's fixed list is retained as historical evidence.  This
observer closes the natural-completion race by inspecting the actual in-flight
log set; an invocation counts as gated only after its flushed gate marker.
No process signal, Lean invocation, proof edit, or result fabrication occurs.
"""
from datetime import datetime, timezone
from pathlib import Path
import fcntl
import json
import re
import time

runtime = Path("/workspace/scratch/127408f63891/lean-runtime")
control = runtime / "logs/resource-adjustment-01"
mainlog = runtime / "logs/closure-run.log"
ever_legacy = set()
ever_gated = set()
started = datetime.now(timezone.utc).isoformat()

with (control / "frontend.lock").open("a") as handle:
    fcntl.flock(handle, fcntl.LOCK_EX)
    (control / "external-drain-lock-acquired.json").write_text(json.dumps({
        "recorded_utc": datetime.now(timezone.utc).isoformat(),
        "ordinary_file_mutex_acquired": True,
        "effect": "New gated frontend bodies cannot begin until this observer releases the mutex.",
    }, indent=2) + "\n")
    while True:
        text = mainlog.read_text()
        starts = re.findall(r"^COMPILING (\S+)", text, re.MULTILINE)
        records = {}
        for line in text.splitlines():
            if not line.startswith("RESULT "):
                continue
            try:
                result = json.loads(line[len("RESULT "):])
            except json.JSONDecodeError:
                continue
            records[result["module"]] = result
        inflight = [module for module in starts if module not in records]
        legacy = []
        gated = []
        for module in inflight:
            path = runtime / "logs/closure" / (module + ".log")
            log = path.read_text() if path.exists() else ""
            if "P1_SCHEDULER_WAIT_DRAIN module=" + module in log:
                gated.append(module)
                ever_gated.add(module)
            else:
                legacy.append(module)
                ever_legacy.add(module)
        failures = [record for module, record in records.items()
                    if module in ever_legacy and
                    (record["returncode"] != 0 or
                     record["source_sha256_before"] != record["source_sha256_after"])]
        status = {
            "started_utc": started,
            "recorded_utc": datetime.now(timezone.utc).isoformat(),
            "legacy_or_not_yet_identified_inflight": legacy,
            "gated_waiting_inflight": gated,
            "ever_observed_legacy_or_unidentified": sorted(ever_legacy),
            "ever_observed_gated": sorted(ever_gated),
            "failed_legacy_records": failures,
            "file_mutex_held": True,
            "no_process_was_signaled": True,
        }
        (control / "all-legacy-drain-status.json").write_text(json.dumps(status, indent=2) + "\n")
        if failures:
            (control / "legacy-drain.failed").write_text("An actual legacy compilation failed.\n")
            (control / "all-legacy-drain-result.json").write_text(json.dumps({
                **status, "successful_natural_drain": False,
            }, indent=2) + "\n")
            raise SystemExit(1)
        if not legacy and ever_gated:
            completed = {module: records[module] for module in ever_legacy
                         if module in records}
            final = {**status, "successful_natural_drain": True,
                     "legacy_actual_success_records": completed,
                     "ordinary_file_mutex_released_after_record": True,
                     "subsequent_frontend_bodies_require_exclusive_mutex": True}
            (control / "all-legacy-drain-result.json").write_text(json.dumps(final, indent=2) + "\n")
            print(json.dumps({key: value for key, value in final.items()
                              if key != "legacy_actual_success_records"}), flush=True)
            break
        time.sleep(0.5)
    fcntl.flock(handle, fcntl.LOCK_UN)
