"""Produce a receipt only after actual strict compilation and original replay.

This script is a scratch evidence collector.  It does not edit project proofs,
change dependency pins, invoke a compiler, or turn an incomplete run into a pass.
"""
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import re
import subprocess

import compile_driver as d
from compile_closure import LOCAL_ROOTS, TARGETS


def read_json(path):
    return json.loads(path.read_text())


def reference(path):
    return {"path": str(path), "sha256": d.digest(path), "bytes": path.stat().st_size}


def artifact_parts(module):
    output = d.olean(module)
    return {
        p.name: reference(p)
        for p in sorted(output.parent.glob(output.name + "*"))
        if p.is_file()
    }


def git_read(root, *args):
    completed = subprocess.run(
        ["git", "-C", str(root), *args],
        capture_output=True, text=True, check=True,
    )
    return completed.stdout.strip()


def main():
    logroot = d.RUNTIME / "logs"
    final = read_json(logroot / "closure/result.json")
    plan = read_json(logroot / "closure/plan.json")
    state = read_json(logroot / "closure/state.json")
    replay = read_json(logroot / "replay/results.json")
    if final["returncode"] != 0 or final["failures"]:
        raise RuntimeError("The latest closure did not pass")
    if set(final["targets"]) != set(TARGETS) or set(plan["targets"]) != set(TARGETS):
        raise RuntimeError("The latest graph does not contain all six targets")
    if not replay["verified"] or replay["returncode"] != 0:
        raise RuntimeError("Original six-target replay did not pass")
    if len(replay["observed_replay_lines"]) != 6 or set(replay["observed_replay_lines"]) != set(TARGETS):
        raise RuntimeError("Original replay coverage does not match the six targets")
    replay_targets = replay["expected_targets"]
    if len(replay_targets) != 6 or set(replay_targets) != set(TARGETS):
        raise RuntimeError("Original replay target list does not match")
    commands = [[str(d.TOOLROOT / "bin/leanchecker"), "--verbose", module]
                for module in replay_targets]
    if replay["commands"] != commands or len(replay["calls"]) != 6:
        raise RuntimeError("Replay did not use six sequential original single-module calls")
    if replay["LEAN_NUM_THREADS"] != "1" or replay["metadata_adapter"]:
        raise RuntimeError("Unexpected replay execution environment")
    checker_source = d.TOOLROOT / "src/lean/LeanChecker.lean"
    if replay["semantics"]["source_path"] != str(checker_source) or \
       replay["semantics"]["source_sha256"] != d.digest(checker_source) or \
       replay["original_leanchecker_sha256"] != d.digest(d.TOOLROOT / "bin/leanchecker"):
        raise RuntimeError("The original checker or its recorded semantics source changed")
    if replay["source_sha256_before"] != replay["source_sha256_after"] or \
       replay["artifacts_sha256_before"] != replay["artifacts_sha256_after"]:
        raise RuntimeError("Replay source or artifact hashes changed")
    replay_log = Path(replay["log"])
    replay_raw = replay_log.read_text()
    replay_header = json.loads(replay_raw.splitlines()[0])
    if d.digest(replay_log) != replay["log_sha256"] or replay_header["commands"] != commands:
        raise RuntimeError("Aggregate replay log hash or command header changed")
    if replay_header["source_sha256"] != replay["source_sha256_before"] or \
       replay_header["artifacts_sha256_before"] != replay["artifacts_sha256_before"]:
        raise RuntimeError("Aggregate replay header does not bind the actual inputs")
    for module, command, call in zip(replay_targets, commands, replay["calls"]):
        call_log = Path(call["log"])
        raw = call_log.read_text()
        header = json.loads(raw.splitlines()[0])
        observed = re.findall(r"^replaying (\S+)\s*$", raw, re.MULTILINE)
        if call["module"] != module or call["command"] != command or \
           call["returncode"] != 0 or not call["verified"]:
            raise RuntimeError("An original per-module replay did not pass: " + module)
        if d.digest(call_log) != call["log_sha256"] or raw not in replay_raw or \
           observed != [module] or call["observed_replay_lines"] != [module]:
            raise RuntimeError("Raw replay coverage or log hash is inconsistent: " + module)
        if header["module"] != module or header["command"] != command or \
           header["metadata_adapter"] or header["LEAN_NUM_THREADS"] != "1" or \
           header["source_sha256"] != replay["source_sha256_before"][module] or \
           header["artifacts_sha256_before"] != replay["artifacts_sha256_before"][module]:
            raise RuntimeError("Original replay command or input binding is inconsistent: " + module)
    if re.findall(r"^replaying (\S+)\s*$", replay_raw, re.MULTILINE) != replay_targets:
        raise RuntimeError("Raw sequential replay lines are not exactly the six targets")

    order = d.closure(TARGETS)
    local = [m for m in order if d.INDEX[m][1] in LOCAL_ROOTS]
    cached = [m for m in order if d.INDEX[m][1] not in LOCAL_ROOTS]
    if plan["source_modules"] != len(order) or plan["local_modules"] != local:
        raise RuntimeError("The final source graph is stale")
    if final["complete_local_modules"] != len(local) or final["total_local_modules"] != len(local):
        raise RuntimeError("Some required local modules were not completed")
    if plan["workers"] != 1:
        raise RuntimeError("The final graph pass did not use the agreed single worker")
    local_records = {}
    for module in local:
        record = state[module]
        current_imports = {dep: d.digest(d.olean(dep)) for dep in d.imports(module)}
        if record["returncode"] != 0 or record["trustLevel"] != 0 or record["metadata_adapter"]:
            raise RuntimeError("Unexpected compilation mode or result: " + module)
        if record["source_sha256_after"] != d.digest(d.INDEX[module][0]):
            raise RuntimeError("A compiled source changed: " + module)
        if record["olean_sha256"] != d.digest(d.olean(module)):
            raise RuntimeError("A compiled object changed: " + module)
        if record["import_olean_sha256"] != current_imports:
            raise RuntimeError("Compiled direct imports changed: " + module)
        if record["strict"] != (module in TARGETS):
            raise RuntimeError("Unexpected strict diagnostics scope: " + module)
        local_records[module] = record
    if any(not d.olean(m).is_file() for m in cached):
        raise RuntimeError("A required official cached object is missing")

    audit_module = "verification.parts.p1.Part1HistoryAudit"
    probe_module = "verification.parts.p1.LevelCheckProbe"
    if probe_module not in state[audit_module]["import_olean_sha256"]:
        raise RuntimeError("Audit was not compiled against the repository Probe artifact")
    targets = {}
    for module in TARGETS:
        record = state[module]
        logfile = Path(record["log"])
        lines = logfile.read_text().splitlines()
        header = json.loads(lines[0])
        marker = "FRONTEND_OK module=" + module + " trustLevel=0"
        if marker not in lines:
            raise RuntimeError("Target is missing the real frontend success marker: " + module)
        if "P1_SCHEDULER_SERIAL_BEGIN module=" + module not in lines:
            raise RuntimeError("Target does not have its actual serialized-entry marker: " + module)
        parts = artifact_parts(module)
        if {name: item["sha256"] for name, item in parts.items()} != replay["artifacts_sha256_after"][module]:
            raise RuntimeError("A target artifact part changed after replay: " + module)
        if d.digest(d.INDEX[module][0]) != replay["source_sha256_after"][module]:
            raise RuntimeError("A target source changed after replay: " + module)
        targets[module] = {
            **record,
            "command": header["command"],
            "source": reference(d.INDEX[module][0]),
            "artifact_parts": parts,
            "direct_import_artifact_parts": {
                dep: artifact_parts(dep) for dep in d.imports(module)
            },
            "log": reference(logfile),
            "original_checker_replayed_defined_declarations": True,
        }

    audit_lines = Path(state[audit_module]["log"]).read_text().splitlines()
    declarations = [json.loads(line.removeprefix("PART1_HISTORY_AUDIT_DECL "))
                    for line in audit_lines if line.startswith("PART1_HISTORY_AUDIT_DECL ")]
    module_lines = [json.loads(line.removeprefix("PART1_HISTORY_AUDIT_MODULE "))
                    for line in audit_lines if line.startswith("PART1_HISTORY_AUDIT_MODULE ")]
    totals = [int(line.removeprefix("PART1_HISTORY_AUDIT_COUNT "))
              for line in audit_lines if line.startswith("PART1_HISTORY_AUDIT_COUNT ")]
    expected_audited = set(TARGETS) - {audit_module}
    counts = Counter(item["module"] for item in declarations)
    if len(totals) != 1 or totals[0] != len(declarations):
        raise RuntimeError("Audit declaration census is missing or inconsistent")
    if set(counts) != expected_audited or len({item["name"] for item in declarations}) != len(declarations):
        raise RuntimeError("Audit module/name census is inconsistent")
    if dict(counts) != {item["module"]: item["count"] for item in module_lines}:
        raise RuntimeError("Audit module counts disagree")
    allowed = {"propext", "Classical.choice", "Quot.sound"}
    observed_axioms = {axiom for item in declarations for axiom in item["axioms"]}
    if not observed_axioms <= allowed:
        raise RuntimeError("Audit reported a forbidden transitive axiom")

    pins = []
    for package in d.PACKAGES:
        root = d.REPO / ".lake/packages" / package["name"]
        actual = git_read(root, "rev-parse", "HEAD")
        changes = git_read(root, "status", "--porcelain", "--untracked-files=no").splitlines()
        item = {"package": package["name"], "expected_rev": package["rev"],
                "actual_head": actual, "exact_pin": actual == package["rev"],
                "tracked_changes": changes}
        if not item["exact_pin"] or changes:
            raise RuntimeError("A dependency pin/source changed: " + package["name"])
        pins.append(item)

    binary_original = read_json(logroot / "toolchain-binary-hashes.json")
    binary_final = {}
    for name, initial in binary_original["binaries"].items():
        path = Path(initial["path"])
        current = reference(path)
        current["matches_initial_sha256"] = current["sha256"] == initial["sha256"]
        if not current["matches_initial_sha256"]:
            raise RuntimeError("An original executable changed: " + name)
        binary_final[name] = current

    runtime_probe_path = d.RUNTIME / "runtime-probe.json"
    runtime_probe = read_json(runtime_probe_path)
    project_pin_files = {}
    for filename, original_hash in runtime_probe["project_pin_file_sha256"].items():
        info = reference(d.REPO / filename)
        info["matches_initial_sha256"] = info["sha256"] == original_hash
        if not info["matches_initial_sha256"]:
            raise RuntimeError("A project dependency/toolchain configuration changed: " + filename)
        project_pin_files[filename] = info

    transition_dir = logroot / "resource-adjustment-01"
    transition_path = transition_dir / "transition.json"
    transition = read_json(transition_path)
    drain_path = transition_dir / "all-legacy-drain-result.json"
    drain = read_json(drain_path)
    if not drain["successful_natural_drain"] or drain["failed_legacy_records"] or \
       drain["legacy_or_not_yet_identified_inflight"]:
        raise RuntimeError("The recorded natural drain did not complete successfully")
    before_driver = transition_dir / "frontend-driver-before.lean"
    after_driver = transition_dir / "frontend-driver-after.lean"
    if d.digest(before_driver) != transition["original_driver_sha256"] or \
       d.digest(after_driver) != transition["serialized_driver_sha256"] or \
       d.digest(d.RUNTIME / "frontend-driver/lakefile.lean") != transition["serialized_driver_sha256"]:
        raise RuntimeError("The scheduler transition driver hashes changed")
    before_body = before_driver.read_text().split("script compileOne (args) do\n", 1)[1]
    after_body = after_driver.read_text().split(
        "def compileOneBody (args : List String) : IO UInt32 := do\n", 1
    )[1].split("\n/-- Scheduling only:", 1)[0]
    if before_body != after_body or before_body != transition["common_actual_frontend_body_text"] or \
       hashlib.sha256(before_body.encode()).hexdigest() != transition["common_actual_frontend_body_sha256"]:
        raise RuntimeError("The actual compiler body was not identical across scheduling versions")
    legacy_success = {}
    for module in transition["old_entry_modules_to_confirm_final_success"]:
        record = local_records[module]
        if record["returncode"] != 0 or record["source_sha256_before"] != record["source_sha256_after"]:
            raise RuntimeError("An old-entry compiler did not naturally finish successfully: " + module)
        legacy_success[module] = record
    scheduling = {
        "transition": {**reference(transition_path), "record": transition},
        "authoritative_natural_drain": {**reference(drain_path), "record": drain},
        "initial_fixed_list_drain_is_historical_only": reference(transition_dir / "drain-result.json"),
        "old_entry_modules_actual_success": legacy_success,
        "common_actual_compiler_body_byte_identity_rechecked": True,
        "transient_overlap_recorded_without_claiming_early_serialization": True,
        "final_graph_outer_workers": plan["workers"],
        "target_frontend_entry_mutex_markers_checked": True,
        "replay": "Six sequential original single-module leanchecker processes, each with LEAN_NUM_THREADS=1 and complete selected-module replay.",
    }

    script_files = [
        d.RUNTIME / "frontend-driver/lakefile.lean",
        d.RUNTIME / "compile_driver.py",
        d.RUNTIME / "compile_closure.py",
        d.RUNTIME / "replay_targets.py",
        d.RUNTIME / "cache-driver/lakefile.lean",
        d.RUNTIME / "cache-metadata-bin/lean",
        d.RUNTIME / "observe_legacy_drain.py",
        d.RUNTIME / "observe_all_legacy_drain.py",
        before_driver,
        after_driver,
        transition_dir / "replay-before.py",
        Path(__file__),
    ]
    scripts = {str(path.relative_to(d.RUNTIME)): {**reference(path), "text": path.read_text()}
               for path in script_files}
    receipt = {
        "recorded_utc": datetime.now(timezone.utc).isoformat(),
        "receipt_kind": "Actual Part 1 six-target strict frontend compilation, defining-module axiom audit, and original leanchecker replay",
        "repository_path": str(d.REPO),
        "delivery_commit_status": "This scratch receipt is generated before the parent creates the delivery commit; it does not assert a delivery SHA.",
        "verification": {
            "actual_original_frontend_compilation": True,
            "frontend_api": "Lean.Elab.runFrontend",
            "trustLevel": 0,
            "normal_initializer_lifecycle": "Lean.enableInitializersExecution",
            "target_warning_as_error": True,
            "baseline_and_supplier_warning_as_error": False,
            "metadata_adapter_during_compilation_or_replay": False,
            "metadata_adapter_scope_note": "The preceding field describes project and supplier source-closure compilation and the six target replays. A narrow --print-prefix metadata adapter was used only for unchanged pinned Cache bootstrap/setup; its source and the raw bootstrap/cache records are preserved separately.",
            "original_leanchecker_six_sequential_calls_aggregate_exit_code": replay["returncode"],
            "original_leanchecker_individual_exit_codes": {call["module"]: call["returncode"] for call in replay["calls"]},
            "standard_lake_build_executed": False,
            "github_actions_verification_of_these_six_targets_executed": False,
            "external_ci_scope_note": "External source-checkpoint CI is recorded separately by the parent; it is not evidence for these six Part1 targets.",
            "normal_lean_cli_startup": {
                "historical_failure": runtime_probe["checks"][0],
                "historical_record": reference(runtime_probe_path),
                "historical_record_status_note": "Its initial no-compilation status describes the early probe only; actual compilation and replay results below supersede that status.",
            },
            "early_smoke_evidence": {
                "positive_nat_theorem_accepted": "Observed in original session tool output; no separately archived stdout log.",
                "false_zero_eq_one_rejected": "Observed in original session tool output; no separately archived stdout log.",
                "original_checker_smoke_exit_zero": "Observed in original session tool output; no separately archived stdout log.",
                "preserved_scratch_sources": [reference(path) for path in sorted((d.RUNTIME / "frontend-smoke").glob("*.lean"))],
                "no_rerun_for_log_fabrication": True,
            },
        },
        "targets": targets,
        "closure": {
            "source_modules": len(order), "compiled_local_modules": len(local),
            "official_cached_source_modules": len(cached),
            "source_module_counts_by_root": dict(Counter(str(d.INDEX[m][1]) for m in order)),
            "final_graph_includes_repository_probe": probe_module in order,
            "audit_direct_import_includes_repository_probe": True,
            "all_local_source_object_and_direct_import_hashes_rechecked": True,
            "final_execution_result": final,
            "plan": reference(logroot / "closure/plan.json"),
            "state": reference(logroot / "closure/state.json"),
            "source_order": order,
        },
        "audit": {
            "mechanism": "Lean environment defining-module metadata, including private and generated declarations; bundled transitive Lean.collectAxioms; rejects unsafe declarations, axiom declarations, and dependencies outside the standard three-axiom allowlist.",
            "audited_defining_modules": sorted(expected_audited),
            "declaration_count": len(declarations), "module_counts": dict(counts),
            "allowed_axioms": sorted(allowed), "observed_axioms": sorted(observed_axioms),
            "declarations": [{key: item[key] for key in ("name", "module", "kind", "axioms")}
                             for item in declarations],
            "full_types_in_raw_audit_log": reference(Path(state[audit_module]["log"])),
        },
        "replay": replay,
        "resource_scheduling_transition": scheduling,
        "dependencies": {"pins_rechecked": pins, "project_pin_files": project_pin_files,
                         "cache_result": read_json(logroot / "cache/result.json"),
                         "cache_raw_log": reference(logroot / "cache/get.log"),
                         "elaboration_configuration_audit": reference(logroot / "config-elaboration-audit.json")},
        "toolchain": {**{key: value for key, value in binary_original.items() if key != "binaries"},
                      "original_executables_rechecked": binary_final,
                      "original_hash_record": reference(logroot / "toolchain-binary-hashes.json")},
        "scratch_drivers": scripts,
        "scope_limits": [
            "The original frontend API invocation is real Lean compilation with trustLevel zero, but it is not a standard lake build invocation.",
            "The original checker replays declarations defined by all six selected modules, including private data; its default mode does not replay every declaration in imported dependency modules.",
            "Official cached Mathlib dependencies were validated by the unchanged pinned official Cache implementation; source-compiled local dependencies are recorded separately.",
            "This receipt verifies the stated six-module milestone. It does not assert that the complete manuscript policy, inherited fifth integral, all downstream parts, or repository CI are complete.",
        ],
    }
    destination = d.RUNTIME / "part1-final-receipt.json"
    destination.write_text(json.dumps(receipt, indent=2, ensure_ascii=False) + "\n")
    print(json.dumps({"receipt": str(destination), "sha256": d.digest(destination),
                      "targets": len(TARGETS), "audit_declarations": len(declarations),
                      "local_modules": len(local), "source_modules": len(order),
                      "verified": True}, ensure_ascii=False))


if __name__ == "__main__":
    main()
