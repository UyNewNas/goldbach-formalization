"""Compile the exact source closure via original Lean frontend, with resumable logs.

The cache must have completed its official checks before this script starts.
No repository source or dependency pin is modified.  No CLI metadata adapter
is exposed during compilation.  All compilation uses trustLevel=0.
"""
from pathlib import Path
import concurrent.futures as futures
import json
import sys
import time
import compile_driver as d

TARGETS = [
    "ImbalancedChen.HistoricalPrefixCertificate",
    "ImbalancedChen.OrdinaryLowerFourFrontier",
    "ImbalancedChen.ActualSelectedPrefixLowerCellSum",
    "ImbalancedChen.ActualSelectedPrefixLowerOwnCubeIntegral",
    "verification.parts.p1.LevelCheckProbe",
    "verification.parts.p1.Part1HistoryAudit",
]
STRICT = set(TARGETS)
LOGDIR = d.RUNTIME / "logs/closure"
STATEFILE = LOGDIR / "state.json"
LOCAL_ROOTS = {d.REPO, d.REPO / ".lake/packages/goldbach", d.REPO / ".lake/packages/LeanArchitect"}

def inputs(module):
    return {dep: d.digest(d.olean(dep)) for dep in d.imports(module)}

def main():
    workers = int(sys.argv[1]) if len(sys.argv) > 1 else 2
    if workers not in (1, 2):
        raise RuntimeError("Only one or two frontend processes are supported")
    cache_result = json.loads((d.RUNTIME / "logs/cache/result.json").read_text())
    if cache_result["exit_code"] != 0:
        raise RuntimeError("Official cache did not finish successfully")
    LOGDIR.mkdir(parents=True, exist_ok=True)
    order = d.closure(TARGETS)
    deps = {m: set(d.imports(m)) for m in order}
    local = [m for m in order if d.INDEX[m][1] in LOCAL_ROOTS]
    cached = [m for m in order if d.INDEX[m][1] not in LOCAL_ROOTS]
    missing = [m for m in cached if not d.olean(m).is_file()]
    if missing:
        raise RuntimeError("Missing official cached imports: " + ", ".join(missing))
    state = json.loads(STATEFILE.read_text()) if STATEFILE.exists() else {}
    completed = set(cached)
    completed.update(dep for m in order for dep in deps[m] if dep not in d.INDEX)
    pending = list(local)
    running = {}
    failed = []
    started = time.monotonic()
    plan = {"targets": TARGETS, "source_modules": len(order), "official_cached_modules": len(cached),
            "local_modules": local, "trustLevel": 0, "strict_modules": sorted(STRICT),
            "metadata_adapter": False, "workers": workers}
    (LOGDIR / "plan.json").write_text(json.dumps(plan, indent=2) + "\n")
    print("CLOSURE_START " + json.dumps({k:v for k,v in plan.items() if k != "local_modules"}), flush=True)
    with futures.ThreadPoolExecutor(max_workers=workers) as executor:
        while pending or running:
            if not failed:
                for module in list(pending):
                    if len(running) >= workers:
                        break
                    if not deps[module] <= completed:
                        continue
                    current_inputs = inputs(module)
                    old = state.get(module)
                    if old and old.get("source_sha256_after") == d.digest(d.INDEX[module][0]) and \
                       old.get("import_olean_sha256") == current_inputs and \
                       old.get("strict") == (module in STRICT) and d.olean(module).is_file() and \
                       old.get("olean_sha256") == d.digest(d.olean(module)):
                        completed.add(module)
                        pending.remove(module)
                        print("RESUME_VERIFIED " + module, flush=True)
                        continue
                    future = executor.submit(d.compile_module, module, LOGDIR, module in STRICT, False)
                    running[future] = (module, current_inputs)
                    pending.remove(module)
            if not running:
                if failed:
                    break
                if pending:
                    raise RuntimeError("No ready module; unsatisfied dependencies: " + repr({m:sorted(deps[m]-completed) for m in pending[:8]}))
                break
            ready, _ = futures.wait(running, return_when=futures.FIRST_COMPLETED, timeout=30)
            for future in ready:
                module, current_inputs = running.pop(future)
                try:
                    record = future.result()
                    if current_inputs != inputs(module):
                        raise RuntimeError("Imported object changed during compilation: " + module)
                    record["import_olean_sha256"] = current_inputs
                    state[module] = record
                    STATEFILE.write_text(json.dumps(state, indent=2) + "\n")
                    completed.add(module)
                    print("CLOSURE_PROGRESS " + json.dumps({"module": module, "complete": len(completed.intersection(local)), "total": len(local), "elapsed_seconds": round(time.monotonic()-started, 1)}), flush=True)
                except Exception as exc:
                    failed.append({"module":module,"error":str(exc),"log":str(LOGDIR/(module+".log"))})
                    print("CLOSURE_ERROR " + json.dumps(failed[-1]), flush=True)
    result = {"returncode": 1 if failed else 0, "failures":failed,
              "complete_local_modules":len(completed.intersection(local)), "total_local_modules":len(local),
              "elapsed_seconds":round(time.monotonic()-started, 3), "targets":TARGETS,
              "trustLevel":0,"metadata_adapter":False}
    (LOGDIR/"result.json").write_text(json.dumps(result, indent=2)+"\n")
    print("CLOSURE_RESULT " + json.dumps(result), flush=True)
    return result["returncode"]

if __name__ == "__main__":
    raise SystemExit(main())
