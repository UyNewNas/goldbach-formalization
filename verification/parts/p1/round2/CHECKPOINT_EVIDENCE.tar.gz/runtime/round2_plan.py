"""Exact source graph for the four explicitly requested round2 targets."""
from collections import Counter
import json
import compile_driver as d

TARGETS = [
    'ImbalancedChen.HistoricalUpperFiveCellGeometry',
    'ImbalancedChen.ActualHistoricalFifthCellIntegral',
    'verification.parts.p1.round2.HistoricalCellProbe',
    'verification.parts.p1.round2.Part1HistoricalCellAudit',
]
LOCAL_ROOTS = {d.REPO, d.REPO / '.lake/packages/goldbach',
               d.REPO / '.lake/packages/LeanArchitect'}

def make_plan():
    order = d.closure(TARGETS)
    local = [m for m in order if d.INDEX[m][1] in LOCAL_ROOTS]
    cached = [m for m in order if d.INDEX[m][1] not in LOCAL_ROOTS]
    roots = sorted({dep for m in local for dep in d.imports(m)
                    if dep in d.INDEX and d.INDEX[dep][1] not in LOCAL_ROOTS})
    return {'targets': TARGETS, 'source_module_count': len(order),
            'local_module_count': len(local), 'cached_source_module_count': len(cached),
            'source_order': order, 'local_modules': local, 'cached_modules': cached,
            'module_counts_by_source_root': dict(Counter(str(d.INDEX[m][1]) for m in order)),
            'official_cache_root_modules': roots,
            'target_source_sha256': {m: d.digest(d.INDEX[m][0]) for m in TARGETS},
            'surviving_local_objects': [m for m in local if d.olean(m).exists()],
            'missing_local_objects': [m for m in local if not d.olean(m).exists()],
            'frontend_process_limit': 1, 'proof_or_replay_result': False}

if __name__ == '__main__':
    plan = make_plan()
    folder = d.RUNTIME / 'logs/round2'
    folder.mkdir(parents=True, exist_ok=True)
    (folder / 'source-plan.json').write_text(json.dumps(plan, indent=2) + '\n')
    (folder / 'cache-roots.txt').write_text('\n'.join(plan['official_cache_root_modules']) + '\n')
    print(json.dumps({k: plan[k] for k in ['targets', 'source_module_count',
        'local_module_count', 'cached_source_module_count', 'module_counts_by_source_root',
        'target_source_sha256']}, indent=2))
    print('CACHE_ROOT_COUNT', len(plan['official_cache_root_modules']),
          'SURVIVING_LOCAL', len(plan['surviving_local_objects']),
          'MISSING_LOCAL', len(plan['missing_local_objects']))
