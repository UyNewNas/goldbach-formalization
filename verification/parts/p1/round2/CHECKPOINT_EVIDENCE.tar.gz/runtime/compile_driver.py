from pathlib import Path
import os, re, json, sys, hashlib, subprocess, time
from functools import lru_cache
BASE=Path("/workspace/scratch/127408f63891")
REPO=BASE/"goldbach-formalization"
RUNTIME=BASE/"lean-runtime"
TOOLROOT=RUNTIME/"lean-4.33.0-rc1-linux"
DRIVER=RUNTIME/"frontend-driver"
PACKAGES=json.loads((REPO/"lake-manifest.json").read_text())["packages"]
SOURCE_ROOTS=[REPO]+[REPO/".lake/packages"/p["name"] for p in PACKAGES]
INDEX={}
for root in SOURCE_ROOTS:
    for source in root.rglob("*.lean"):
        rel=source.relative_to(root)
        if any(part.startswith(".") for part in rel.parts): continue
        name=".".join(rel.with_suffix("").parts)
        INDEX.setdefault(name,(source,root))
def strip_comments(text):
    result=[]; i=0; depth=0; string=False
    while i<len(text):
        if depth:
            if text[i:i+2]=="/-":depth+=1;i+=2
            elif text[i:i+2]=="-/":depth-=1;i+=2
            else:
                if text[i]=="\n":result.append("\n")
                i+=1
        elif string:
            result.append(text[i])
            if text[i]=="\\" and i+1<len(text):result.append(text[i+1]);i+=2
            else:
                if text[i]=='"':string=False
                i+=1
        elif text[i:i+2]=="/-":depth=1;i+=2
        elif text[i:i+2]=="--":
            j=text.find("\n",i);i=len(text) if j<0 else j
        else:
            result.append(text[i]);string=text[i]=='"';i+=1
    return "".join(result)
@lru_cache(maxsize=None)
def imports(module):
    source,_=INDEX[module]; result=[]
    text=strip_comments(source.read_text())
    for line in text.splitlines():
        line=line.strip()
        if not line or line in ("module","prelude"):continue
        m=re.match(r"^(?:(?:public|private|meta)\s+)*import\s+(?:all\s+)?(.+)$",line)
        if m:
            result.extend(re.findall(r"[A-Za-z_][A-Za-z0-9_.]*",m[1]));continue
        break
    return result
def olean(module):
    if module in INDEX:
        _,root=INDEX[module]
        return root/".lake/build/lib/lean"/Path(*module.split(".")).with_suffix(".olean")
    return TOOLROOT/"lib/lean"/Path(*module.split(".")).with_suffix(".olean")
def closure(targets):
    order=[];seen=set();active=set()
    def visit(module):
        if module in seen:return
        if module in active:raise RuntimeError("Import cycle: "+module)
        if module not in INDEX:
            if not olean(module).exists():raise RuntimeError("Unknown import: "+module)
            seen.add(module);return
        active.add(module)
        for dep in imports(module):visit(dep)
        active.remove(module);seen.add(module);order.append(module)
    for target in targets:visit(target)
    return order

def environment(metadata=False):
    env=os.environ.copy()
    env["LEAN_SYSROOT"]=str(TOOLROOT);env["LAKE_HOME"]=str(TOOLROOT);env["LEAN_NUM_THREADS"]="2"
    env["LEAN_PATH"]=os.pathsep.join(str(r/".lake/build/lib/lean") for r in SOURCE_ROOTS)
    env["LEAN_SRC_PATH"]=os.pathsep.join(map(str,SOURCE_ROOTS+[TOOLROOT/"src/lean/lake",TOOLROOT/"src/lean"]))
    env["PATH"]=os.pathsep.join(([str(RUNTIME/"cache-metadata-bin")] if metadata else [])+[str(TOOLROOT/"bin"),env.get("PATH","")])
    env["MATHLIB_CACHE_DIR"]=str(RUNTIME/"mathlib-download-cache")
    return env

def digest(path):
    with path.open("rb") as f:return hashlib.file_digest(f,"sha256").hexdigest()

def compile_module(module,logdir,strict=False,metadata=False):
    source,root=INDEX[module]; output=olean(module); output.parent.mkdir(parents=True,exist_ok=True)
    cmd=[str(TOOLROOT/"bin/lake"),"-d",str(DRIVER),"-f","lakefile.lean","script","run","compileOne",str(source),module,str(output),"strict" if strict else "normal"]
    logdir.mkdir(parents=True,exist_ok=True)
    log=logdir/(module+".log"); started=time.monotonic(); before=digest(source)
    print("COMPILING",module,"strict="+str(strict),flush=True)
    with log.open("w") as f:
        f.write(json.dumps({"command":cmd,"source_sha256_before":before,"trustLevel":0,"metadata_adapter":metadata})+"\n");f.flush()
        result=subprocess.run(cmd,cwd=REPO,env=environment(metadata),stdout=f,stderr=subprocess.STDOUT)
    after=digest(source)
    record={"module":module,"source":str(source),"source_sha256_before":before,"source_sha256_after":after,"returncode":result.returncode,"elapsed_seconds":round(time.monotonic()-started,3),"log":str(log),"trustLevel":0,"strict":strict,"metadata_adapter":metadata}
    if result.returncode==0:
        if not output.exists():raise RuntimeError("Frontend did not emit object: "+module)
        record["olean_sha256"]=digest(output)
    with (logdir/"results.jsonl").open("a") as f:f.write(json.dumps(record)+"\n")
    print("RESULT",json.dumps(record),flush=True)
    if result.returncode or before!=after:
        print(log.read_text(),flush=True)
        raise RuntimeError("Compilation failed or source changed: "+module)
    return record

if __name__=="__main__":
    action=sys.argv[1];targets=sys.argv[2:]
    if action=="plan":
        order=closure(targets);out=RUNTIME/"project-closure.json"
        out.write_text(json.dumps({"targets":targets,"ordered_modules":order,"module_sources":{m:str(INDEX[m][0]) for m in order}},indent=2)+"\n")
        groups={}
        for m in order:groups[str(INDEX[m][1])]=groups.get(str(INDEX[m][1]),0)+1
        print(json.dumps({"targets":targets,"count":len(order),"groups":groups,"plan":str(out)},indent=2))
    elif action=="bootstrap":
        order=closure(targets);print("BOOTSTRAP_ORDER",json.dumps(order),flush=True)
        for module in order:compile_module(module,RUNTIME/"logs/bootstrap",metadata=True)
    else:raise RuntimeError("Unknown action")
