"""One frontend at a time for the exact round2 dependency graph.

Old successful artifacts are explicitly recorded as reuse; they are never
reported as newly compiled. Current round results have separate raw logs.
"""
from datetime import datetime, timezone
from pathlib import Path
from collections import Counter
import json
import subprocess
import time
import traceback
import compile_driver as d
from round2_plan import TARGETS, LOCAL_ROOTS, make_plan

ROOT = d.RUNTIME / 'logs/round2/closure'
ARCHIVE = d.BASE / 'p1-round2-recovered-evidence/runtime'
ACTIVE_ATTEMPT = None
OLD_TARGETS = {
    'ImbalancedChen.HistoricalPrefixCertificate',
    'ImbalancedChen.OrdinaryLowerFourFrontier',
    'ImbalancedChen.ActualSelectedPrefixLowerCellSum',
    'ImbalancedChen.ActualSelectedPrefixLowerOwnCubeIntegral',
    'verification.parts.p1.LevelCheckProbe',
    'verification.parts.p1.Part1HistoryAudit',
}

def read(path, fallback=None):
    return json.loads(path.read_text()) if path.exists() else fallback

def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n')

def direct_hashes(module):
    return {dep: d.digest(d.olean(dep)) for dep in d.imports(module)}

def matches(module, record, imports):
    if not record or record.get('returncode') != 0 or record.get('trustLevel') != 0 \
            or record.get('metadata_adapter'):
        return False
    source = d.INDEX[module][0]
    output = d.olean(module)
    return output.is_file() and record['source_sha256_before'] == record['source_sha256_after'] \
        == d.digest(source) and record.get('olean_sha256') == d.digest(output) \
        and record.get('import_olean_sha256') == imports

def old_six_bindings():
    receipt = read(ARCHIVE / 'part1-final-receipt.json')
    bindings = {}
    for module in sorted(OLD_TARGETS):
        previous = receipt['targets'][module]
        source = d.INDEX[module][0]
        output = d.olean(module)
        parts = {p.name: d.digest(p) for p in sorted(output.parent.glob(output.name + '*'))
                 if p.is_file()}
        expected_parts = {name: info['sha256'] for name, info in previous['artifact_parts'].items()}
        source_hash = d.digest(source)
        if source_hash != previous['source']['sha256'] or parts != expected_parts:
            raise RuntimeError('An old six-target source or artifact no longer matches its receipt: ' + module)
        bindings[module] = {'source_sha256': source_hash, 'artifact_parts_sha256': parts,
            'matched_archived_receipt': True, 'compiled_in_round2': False,
            'replayed_in_round2': False}
    write(ROOT / 'old-six-bindings.json', bindings)
    return bindings

def main():
    global ACTIVE_ATTEMPT
    ROOT.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    attempt = ROOT / ('attempt-' + stamp)
    ACTIVE_ATTEMPT = attempt
    attempt.mkdir()
    started = time.monotonic()
    initial = {'status': 'RUNNING', 'returncode': None, 'targets': TARGETS,
        'attempt': str(attempt), 'started_utc': datetime.now(timezone.utc).isoformat(),
        'complete_local_modules': 0, 'new_target_actual_compilation_records': {},
        'note': 'This attempt invalidates any previous top-level success before preflight.'}
    write(ROOT / 'result.json', initial)
    write(attempt / 'result.json', initial)
    try:
        cache = read(d.RUNTIME / 'logs/round2/cache/result.json')
        if not cache or not cache['verified']:
            raise RuntimeError('The required official cache restore has not succeeded')
        plan = make_plan()
        if any(not d.olean(m).exists() for m in plan['cached_modules']):
            raise RuntimeError('The current graph needs additional official cached modules')
        previous_plan = read(d.RUNTIME / 'logs/round2/source-plan.json')
        if set(previous_plan['cached_modules']) != set(plan['cached_modules']):
            raise RuntimeError('The cached source graph changed; restore the exact new cache closure first')
        write(attempt / 'previous-source-plan.json', previous_plan)
        write(ROOT / 'plan.json', plan)
        write(attempt / 'plan.json', plan)
        write(d.RUNTIME / 'logs/round2/source-plan.json', plan)
        old_six_bindings()
        prior = read(ARCHIVE / 'logs/closure/state.json')
        state = read(ROOT / 'state.json', {})
    except Exception as error:
        result = {**initial, 'status': 'FAILED', 'returncode': 1, 'failure_stage': 'PREFLIGHT',
            'failures': [{'module': None, 'type': type(error).__name__, 'error': str(error)}],
            'elapsed_seconds': round(time.monotonic() - started, 3)}
        write(attempt / 'result.json', result)
        write(ROOT / 'result.json', result)
        print('ROUND2_CLOSURE_RESULT ' + json.dumps(result), flush=True)
        traceback.print_exc()
        raise SystemExit(1)
    complete = []
    outcomes = Counter()
    failures = []
    print('ROUND2_CLOSURE_START ' + json.dumps({'targets': TARGETS,
        'source_modules': plan['source_module_count'], 'local_modules': plan['local_module_count'],
        'frontend_process_limit': 1, 'attempt': str(attempt)}), flush=True)
    try:
        for module in plan['local_modules']:
            imports = direct_hashes(module)
            current = state.get(module)
            old = prior.get(module)
            if matches(module, current, imports) and (module not in TARGETS or current['strict']):
                outcome = 'REUSED_CURRENT_ROUND_SUCCESS'
                record = current
            elif module not in TARGETS and matches(module, old, imports):
                outcome = 'REUSED_ARCHIVED_SUCCESS'
                record = {**old, 'origin': 'ARCHIVED_FIRST_ROUND_ACTUAL_COMPILATION',
                    'compiled_in_round2': False,
                    'archived_record_source': str(ARCHIVE / 'logs/closure/state.json'),
                    'archived_raw_log': str(ARCHIVE / 'logs/closure' / (module + '.log'))}
            else:
                if module in OLD_TARGETS:
                    raise RuntimeError('Old strict target would require refresh; no automatic recompile: ' + module)
                if module in TARGETS:
                    snapshot = attempt / 'target-sources' / (module + '.lean')
                    snapshot.parent.mkdir(parents=True, exist_ok=True)
                    snapshot.write_bytes(d.INDEX[module][0].read_bytes())
                    print('ROUND2_TARGET_START ' + module, flush=True)
                record = d.compile_module(module, attempt / 'modules', strict=module in TARGETS, metadata=False)
                record.update({'import_olean_sha256': imports,
                    'origin': 'CURRENT_ROUND_ACTUAL_COMPILATION', 'compiled_in_round2': True})
                outcome = 'COMPILED_CURRENT_ROUND'
                if module in TARGETS:
                    print('ROUND2_TARGET_OK ' + json.dumps(record), flush=True)
            state[module] = record
            write(ROOT / 'state.json', state)
            complete.append(module)
            outcomes[outcome] += 1
            event = {'module': module, 'outcome': outcome, 'complete': len(complete),
                'total': plan['local_module_count'], 'elapsed_seconds': round(time.monotonic() - started, 3)}
            with (attempt / 'events.jsonl').open('a') as handle:
                handle.write(json.dumps(event) + '\n')
            if len(complete) % 10 == 0 or module in TARGETS:
                print('ROUND2_CLOSURE_PROGRESS ' + json.dumps(event), flush=True)
    except Exception as error:
        failure = {'module': module if 'module' in locals() else None,
                   'error': str(error), 'type': type(error).__name__}
        failures.append(failure)
        print('ROUND2_CLOSURE_ERROR ' + json.dumps(failure), flush=True)
        traceback.print_exc()
    new_records = {m: state[m] for m in TARGETS
                   if m in state and state[m].get('compiled_in_round2')}
    if not failures and len(new_records) != len(TARGETS):
        failures.append({'module': None, 'type': 'MissingCurrentTargetCompilation',
            'error': 'A new target is missing actual current-round strict compilation'})
    if not failures:
        try:
            old_six_bindings()
        except Exception as error:
            failures.append({'module': None, 'type': type(error).__name__, 'error': str(error)})
    result = {'status': 'FAILED' if failures else 'SUCCEEDED',
        'returncode': 1 if failures else 0, 'failures': failures,
        'targets': TARGETS, 'complete_local_modules': len(complete),
        'total_local_modules': plan['local_module_count'], 'source_modules': plan['source_module_count'],
        'outcome_counts': dict(outcomes), 'frontend_process_limit': 1,
        'strict_targets': TARGETS, 'trustLevel': 0, 'metadata_adapter': False,
        'attempt': str(attempt), 'elapsed_seconds': round(time.monotonic() - started, 3),
        'new_target_actual_compilation_records': new_records}
    write(attempt / 'result.json', result)
    write(ROOT / 'result.json', result)
    print('ROUND2_CLOSURE_RESULT ' + json.dumps(result), flush=True)
    if failures:
        raise SystemExit(1)

if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        # Fail closed also for unexpected errors outside the phase-specific handlers.
        result = {'status': 'FAILED', 'returncode': 1, 'targets': TARGETS,
            'attempt': str(ACTIVE_ATTEMPT) if ACTIVE_ATTEMPT else None,
            'failure_stage': 'UNEXPECTED_EXCEPTION',
            'failures': [{'module': None, 'type': type(error).__name__, 'error': str(error)}]}
        for path in ([ACTIVE_ATTEMPT / 'result.json'] if ACTIVE_ATTEMPT else []) + [ROOT / 'result.json']:
            try:
                write(path, result)
            except Exception as write_error:
                print('ROUND2_FAILURE_RECORD_WRITE_ERROR ' + str(write_error), flush=True)
        print('ROUND2_CLOSURE_RESULT ' + json.dumps(result), flush=True)
        traceback.print_exc()
        raise SystemExit(1)
