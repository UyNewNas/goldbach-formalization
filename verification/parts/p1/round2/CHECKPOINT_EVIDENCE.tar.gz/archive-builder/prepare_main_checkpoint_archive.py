"""Archive stopped round2 work. This script never compiles or replays Lean."""
from collections import Counter
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import subprocess
import tarfile

BASE = Path('/workspace/scratch/127408f63891')
REPO = BASE / 'goldbach-formalization'
RUNTIME = BASE / 'lean-runtime'
RECOVERED = BASE / 'p1-round2-recovered-evidence'
CLOSURE = RUNTIME / 'logs/round2/closure'
ATTEMPT = CLOSURE / 'attempt-20261012T123134033515Z'
DEST = REPO / 'verification/parts/p1/round2'
TARGETS = {
    'ImbalancedChen.HistoricalUpperFiveCellGeometry':
        '0d54b930393ef01dbc9c44fbec5f356bf6be9a645a1a537064179fc12799424b',
    'ImbalancedChen.ActualHistoricalFifthCellIntegral':
        '550602f634e27641bf1f0b811e5e201130f48587bd0760192d032b75c0c405de',
    'verification.parts.p1.round2.HistoricalCellProbe':
        '4b7e3454ecdcb59de7012ff778c55c1a3102126e2b3284f1377ba62b584d3ed5',
    'verification.parts.p1.round2.Part1HistoricalCellAudit':
        '0df5e45188d994da8c2bf415247978de808219cbc274e0c92e84632d017762a5',
}
EXPECTED = {
    'plan.json': '9e302e9f9fffe5c50704d2b65af975254e1b7abd8e6b14b96971315771a6b38b',
    'state.json': '9b373f7ae5e66129e56d45bfd81673a2dc4298454565e7b35a8e803e6daff2b3',
    'result.json': 'b7ba7cf7c4c03bb9b997c977185e035d882acf9f64aadd701510baecc3a9b6d3',
    'stopped-pending.json': 'b7ba7cf7c4c03bb9b997c977185e035d882acf9f64aadd701510baecc3a9b6d3',
    'checkpoint-bindings.json': '29bef4d4033d34488e4c582629159fc8329bbb6f6cd927c31ca3d46ea9d325c6',
}
OLD_ARCHIVE_SHA = 'c56fc707d40ad255fd2d9c8b6c94dc7442c9c62b7238d833188b18cdf10f601d'
PERMIT_ARCHIVE_SHA = '206070fd3bb38c2334d64cead0e58405fa7f73c2400a6d0e77878a065976392a'
COMMIT = '7f894bfb57b7aa561360e335c6d610b7c30614e0'
BASELINE = '1a80c1bcce67886f699d097fc37fd245cd3620bf'
NAMES = ['UNCOMPILED.json', 'CHECKPOINT_EVIDENCE.tar.gz', 'CHECKPOINT_ARTIFACT.json']


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def digest(path):
    return sha(Path(path).read_bytes())


def json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode()


def read_json(path):
    return json.loads(Path(path).read_text())


def rawref(path):
    path = Path(path)
    return {'path': str(path), 'sha256': digest(path), 'bytes': path.stat().st_size}


def main():
    require(all(not (DEST / n).exists() for n in NAMES), 'Refusing to overwrite destination files')
    for rel, expected in EXPECTED.items():
        require(digest(CLOSURE / rel) == expected, f'Changed stopped record: {rel}')
    plan = read_json(CLOSURE / 'plan.json')
    state = read_json(CLOSURE / 'state.json')
    stop = read_json(CLOSURE / 'stopped-pending.json')
    checkpoint = read_json(CLOSURE / 'checkpoint-bindings.json')
    require(plan['targets'] == list(TARGETS), 'Target scope differs')
    require(plan['target_source_sha256'] == TARGETS, 'Target source plan differs')
    require((plan['source_module_count'], plan['local_module_count'],
             plan['cached_source_module_count']) == (9362, 683, 8679), 'Graph counts differ')
    require(len(plan['source_order']) == 9362 and len(plan['local_modules']) == 683
            and len(plan['cached_modules']) == 8679, 'Graph inventory counts differ')
    require(set(plan['local_modules']).isdisjoint(plan['cached_modules'])
            and set(plan['source_order']) == set(plan['local_modules']) | set(plan['cached_modules']),
            'Graph partition differs')
    require(stop['status'] == 'STOPPED_PENDING' and stop['verified'] is False
            and stop['returncode'] == 130 and stop['underlying_lean_exit_code'] is None,
            'Termination evidence differs')
    require(stop['session_id'] == 58228 and stop['phase'] == 'DEPENDENCY_SOURCE_RESTORATION',
            'Stop scope differs')
    require(stop['main_targets'] == list(TARGETS) and stop['main_target_start_markers'] == []
            and stop['main_targets_started'] is False and stop['main_targets_completed'] == [],
            'Unexpected main-target execution')
    require(read_json(ATTEMPT / 'result.json') == stop, 'Attempt stop record differs')
    running = read_json(ATTEMPT / 'original-running-result-before-interruption.json')
    require(running['status'] == 'RUNNING' and running['returncode'] is None
            and running['new_target_actual_compilation_records'] == {}, 'Original RUNNING record differs')
    for key in ['state', 'plan', 'raw_outer_log', 'original_running_result', 'interrupted_module_raw_log']:
        require(rawref(stop[key]['path']) == stop[key], f'Stop reference differs: {key}')
    require(checkpoint['status'] == 'COMPLETED_MODULE_BINDINGS_RECHECKED_ONLY'
            and checkpoint['source_state_sha256'] == EXPECTED['state.json']
            and checkpoint['main_queue_status'] == 'STOPPED_PENDING'
            and checkpoint['main_targets_compiled'] == [] and checkpoint['main_targets_replayed'] == [],
            'Checkpoint scope differs')
    require(len(state) == checkpoint['completed_module_count'] == stop['completed_local_modules'] == 162,
            'Completed count differs')
    require(set(state) == set(checkpoint['bindings']), 'Checkpoint inventory differs')
    origins = dict(Counter(r['origin'] for r in state.values()))
    require(origins == stop['completed_origin_counts'] == {
        'ARCHIVED_FIRST_ROUND_ACTUAL_COMPILATION': 44,
        'CURRENT_ROUND_ACTUAL_COMPILATION': 118}, 'Dependency origin counts differ')
    require(list(state)[-1] == stop['last_completed_module'], 'Last module differs')
    require(not (set(TARGETS) & set(state)), 'Main target entered successful state')
    require(stop['interrupted_module'] not in state and
            checkpoint['interrupted_module'] == stop['interrupted_module'] and
            checkpoint['interrupted_module_artifact_exists'] is False and
            checkpoint['interrupted_module_in_successful_state'] is False,
            'Interrupted module was recorded as successful')
    head = subprocess.run(['git', 'rev-parse', 'HEAD'], cwd=REPO, check=True,
                          capture_output=True, text=True).stdout.strip()
    require(head == COMMIT, 'Parent commit changed before archive snapshot')

    manifest_config = read_json(REPO / 'lake-manifest.json')
    search_roots = [REPO] + [REPO / '.lake/packages' / p['name'] for p in manifest_config['packages']]
    object_cache = {}

    def object_hash(module):
        if module not in object_cache:
            rel = Path(*module.split('.')).with_suffix('.olean')
            candidates = [root / '.lake/build/lib/lean' / rel for root in search_roots]
            candidates.append(RUNTIME / 'lean-4.33.0-rc1-linux/lib/lean' / rel)
            found = [p for p in candidates if p.is_file()]
            require(len(found) == 1, f'Ambiguous or missing object: {module}')
            object_cache[module] = digest(found[0])
        return object_cache[module]

    def target_artifacts(module):
        rel = Path(*module.split('.')).with_suffix('.olean')
        p = REPO / '.lake/build/lib/lean' / rel
        return [str(q) for q in p.parent.glob(p.name + '*') if q.is_file()]

    files = {}
    entries = {}

    def add_data(name, data, role, source_path=None, **extra):
        path = PurePosixPath(name)
        require(not path.is_absolute() and '..' not in path.parts and name not in files,
                f'Unsafe or duplicate archive member: {name}')
        data.decode('utf-8')
        require(b'\0' not in data, f'Non-text archive member: {name}')
        files[name] = data
        entries[name] = {'path': name, 'sha256': sha(data), 'bytes': len(data),
                         'role': role, **({'source_path': str(source_path)} if source_path else {}), **extra}
        return {'archive_member': name, 'sha256': sha(data), 'bytes': len(data)}

    def add_file(path, name, role, **extra):
        path = Path(path)
        require(path.is_file() and not path.is_symlink(), f'Not a regular input: {path}')
        return add_data(name, path.read_bytes(), role, source_path=path, **extra)

    source_records = []
    raw_outer = Path(stop['raw_outer_log']['path']).read_text()
    all_current_logs = list((ATTEMPT / 'modules').glob('*.log'))
    current_log_text = '\n'.join(p.read_text() for p in all_current_logs)
    for module, expected in TARGETS.items():
        rel = Path(*module.split('.')).with_suffix('.lean')
        source = REPO / rel
        require(digest(source) == expected, f'Candidate source changed: {module}')
        require(f'COMPILING {module} ' not in raw_outer and
                f'FRONTEND_START module={module} ' not in current_log_text,
                f'Unexpected target start marker: {module}')
        require(target_artifacts(module) == [], f'Unexpected target artifact: {module}')
        ref = add_file(source, 'source-only/' + rel.as_posix(), 'UNCOMPILED_CANDIDATE_SOURCE_SNAPSHOT',
                       module=module, compiled=False, replayed=False,
                       snapshot_stage='ARCHIVE_TIME_SOURCE_ONLY; no compiler attempt started')
        source_records.append({'module': module, 'source': rel.as_posix(), 'source_sha256': expected,
                               'status': 'UNCOMPILED_CANDIDATE', 'frontend_started': False,
                               'compiled': False, 'replayed': False, 'audit_executed': False,
                               'frontend_returncode': None, 'checker_returncode': None,
                               'object_sha256': None, 'target_artifacts_observed': [],
                               'local_topological_position_one_based': plan['local_modules'].index(module) + 1,
                               'source_snapshot': ref})

    completed_logs = []
    for module, record in state.items():
        binding = checkpoint['bindings'][module]
        require(record['module'] == module and record['returncode'] == 0 and record['trustLevel'] == 0,
                f'Invalid completed dependency record: {module}')
        require(record['source_sha256_before'] == record['source_sha256_after'] ==
                binding['source_sha256'] == digest(Path(record['source'])), f'Changed completed source: {module}')
        require(record['olean_sha256'] == binding['olean_sha256'] == object_hash(module),
                f'Changed completed object: {module}')
        require(record['import_olean_sha256'] == binding['direct_import_olean_sha256']
                and record['origin'] == binding['origin'], f'Changed import or origin record: {module}')
        for imported, expected in binding['direct_import_olean_sha256'].items():
            require(object_hash(imported) == expected, f'Changed direct import of {module}: {imported}')
        archived = record['origin'] == 'ARCHIVED_FIRST_ROUND_ACTUAL_COMPILATION'
        require(record['compiled_in_round2'] is (not archived), f'Changed provenance: {module}')
        path = Path(record['archived_raw_log'] if archived else record['log'])
        name = ('prior_verified_evidence/runtime/' + path.relative_to(RECOVERED / 'runtime').as_posix()
                if archived else 'runtime/' + path.relative_to(RUNTIME).as_posix())
        lines = path.read_text().splitlines()
        header = json.loads(lines[0])
        require(header['source_sha256_before'] == binding['source_sha256'] and header['trustLevel'] == 0,
                f'Log header differs: {module}')
        require(sum(l == f'FRONTEND_OK module={module} trustLevel=0' for l in lines) == 1,
                f'Completed dependency lacks one success marker: {module}')
        ref = add_file(path, name, 'COMPLETED_DEPENDENCY_RAW_LOG', module=module,
                       origin=record['origin'], compiled_in_round2=not archived,
                       main_target=False, recorded_subprocess_exit_code=record['returncode'])
        completed_logs.append({'module': module, 'origin': record['origin'],
                               'compiled_in_round2': not archived, 'log': ref,
                               'source_sha256': binding['source_sha256'],
                               'object_sha256': binding['olean_sha256'],
                               'direct_import_object_sha256': binding['direct_import_olean_sha256']})

    interrupted = stop['interrupted_module']
    rel = Path(*interrupted.split('.')).with_suffix('.olean')
    require(not any((p / '.lake/build/lib/lean' / rel).exists() for p in search_roots),
            'Interrupted dependency has an unexpected object')
    events = [json.loads(x) for x in (ATTEMPT / 'events.jsonl').read_text().splitlines() if x]
    require(len(events) == 162 and [e['module'] for e in events] == list(state), 'Event inventory differs')
    require([e['complete'] for e in events] == list(range(1, 163)), 'Event completion indices differ')
    current_results = [json.loads(x) for x in (ATTEMPT / 'modules/results.jsonl').read_text().splitlines() if x]
    require(len(current_results) == 118 and all(r['returncode'] == 0 for r in current_results),
            'Current raw result count or exits differ')
    require({r['module'] for r in current_results} ==
            {m for m, r in state.items() if r['compiled_in_round2']}, 'Current result scope differs')
    require(len(all_current_logs) == 119, 'Unexpected main attempt raw-log inventory')
    raw_records = {}
    raw_paths = [CLOSURE / x for x in EXPECTED] + [
        ATTEMPT / 'plan.json', ATTEMPT / 'previous-source-plan.json',
        ATTEMPT / 'events.jsonl', ATTEMPT / 'result.json',
        ATTEMPT / 'original-running-result-before-interruption.json',
        ATTEMPT / 'modules/results.jsonl', Path(stop['raw_outer_log']['path']),
        Path(stop['interrupted_module_raw_log']['path']),
    ]
    for path in raw_paths:
        name = 'runtime/' + path.relative_to(RUNTIME).as_posix()
        raw_records[path.relative_to(RUNTIME).as_posix()] = add_file(path, name, 'RAW_MAIN_QUEUE_RECORD')

    drivers = {}
    for rel in ['frontend-driver/lakefile.lean', 'compile_driver.py',
                'round2_compile_closure.py', 'round2_plan.py']:
        drivers[rel] = add_file(RUNTIME / rel, 'runtime/' + rel, 'ACTUALLY_USED_ROUND2_DRIVER_SOURCE')
    drivers['archive_builder'] = add_file(Path(__file__), 'archive-builder/prepare_main_checkpoint_archive.py',
                                         'ARCHIVE_BUILDER_ONLY; never compiles or replays Lean')
    pin_refs = {}
    for rel in ['lean-toolchain', 'lake-manifest.json', 'lakefile.toml']:
        pin_refs[rel] = add_file(REPO / rel, 'project-pins/' + rel, 'UNCHANGED_PROJECT_PIN_OR_CONFIGURATION')
    old_archive = REPO / 'verification/parts/p1/EVIDENCE.tar.gz'
    require(digest(old_archive) == OLD_ARCHIVE_SHA, 'Prior verified evidence archive changed')
    external_sources = [
        {'repo_path': 'verification/parts/p1/EVIDENCE.tar.gz', 'sha256': OLD_ARCHIVE_SHA,
         'bytes': old_archive.stat().st_size,
         'verified_delivery_commit': 'b09d5361e0b30f3e85cb912a03c7bfb85a99bf8f',
         'role': 'Prior verified source/object/import records and original compilation logs for 44 reused dependencies',
         'hash_validation': 'Read-only SHA256 recomputation by this archive builder'},
        {'repo_path': 'verification/parts/p1/round2/permit/EVIDENCE.tar.gz', 'sha256': PERMIT_ARCHIVE_SHA,
         'bytes': 4696213, 'members': 130, 'payload_bytes': 33141080,
         'role': 'Independent verified permit archive; contains current toolchain and official-cache restoration evidence',
         'hash_validation': 'Parent reported its completed readback and hash verification; this archive builder did not open or modify permit files',
         'scope_note': 'Permit success does not compile, replay, or audit the four main targets'},
    ]
    now = datetime.now(timezone.utc).isoformat()
    report = {
        'schema_version': 1, 'status': 'STOPPED_PENDING', 'verified': False,
        'scope': 'Four main round2 source candidates; no main target frontend, checker, or declaration audit was executed',
        'recorded_utc': now, 'repository': 'https://github.com/UyNewNas/goldbach-formalization',
        'source_parent_commit': COMMIT, 'common_mathematical_baseline': BASELINE,
        'targets': source_records,
        'main_target_frontends_started': [], 'main_target_compilations_completed': [],
        'main_target_replays_completed': [], 'main_declaration_audit_completed': False,
        'termination': {'status': 'STOPPED_PENDING', 'phase': stop['phase'],
                        'session_id': stop['session_id'], 'observed_exec_session_exit_code': 130,
                        'underlying_lake_or_lean_subprocess_exit_code': None,
                        'termination_observation': stop['termination_observation'],
                        'reason': stop['reason'], 'stopped_recorded_utc': stop['recorded_utc'],
                        'last_completed_module': stop['last_completed_module'],
                        'interrupted_module': interrupted,
                        'interrupted_module_completed': False,
                        'interrupted_module_artifact_observed': False,
                        'shared_frontend_lock_released_after_interrupt':
                            stop['shared_frontend_lock_nonblocking_acquisition_after_interrupt'],
                        'interpretation': 'The larger dependency restoration was stopped at the independently verified permit milestone. This is neither a main target pass nor a Lean theorem failure.'},
        'source_graph': {key: plan[key] for key in ['source_module_count', 'local_module_count',
            'cached_source_module_count', 'module_counts_by_source_root', 'frontend_process_limit']},
        'completed_dependency_checkpoints': {
            'count': 162, 'origin_counts': origins, 'new_main_targets_in_this_count': 0,
            'binding_scope': 'Current source, main .olean, and direct-import .olean hashes of the 162 already completed dependency records',
            'original_binding_check_record': raw_records['logs/round2/closure/checkpoint-bindings.json'],
            'source_state_sha256': EXPECTED['state.json'],
            'read_only_binding_recheck_at_archive_time': True,
            'unique_objects_rehashed': len(object_cache),
            'objects_included_in_archive': False,
            'dependency_replay_claim': False,
        },
        'execution_method': {
            'actual_command': ['python', str(RUNTIME / 'round2_compile_closure.py')],
            'stdout_stderr_redirect': str(RUNTIME / 'logs/round2/closure-run-01.log'),
            'source_compilation': 'Original same-version Lake calling the official Lean.Elab.runFrontend API',
            'trustLevel': 0, 'frontend_process_limit': 1,
            'normal_stock_lean_cli_build_executed': False,
            'new_target_strict_warning_mode_planned_but_not_executed': True,
            'main_replay_script_executed': False, 'main_final_receipt_collector_executed': False,
            'drivers': drivers,
        },
        'raw_records': raw_records,
        'pin_records': pin_refs,
        'dependency_pins': {p['name']: p['rev'] for p in manifest_config['packages']},
        'external_sources': external_sources,
        'archive_policy': 'Text-only pending-work checkpoint; no executable, object, library, cache binary, or main target success record is included',
        'resume_requirement': 'Recover the exact dependency pins and matching completed objects, finish the remaining dependency closure, then actually compile all four targets under strict trustLevel 0, replay their declarations, and execute the defining-module audit before claiming validation.',
    }
    uncompiled = json_bytes(report)
    add_data('UNCOMPILED.json', uncompiled, 'PENDING_WORK_SCOPE_AND_SOURCE_HASHES')
    add_data('CHECKPOINT_INDEX.json', json_bytes({'schema_version': 1,
        'status': 'DEPENDENCY_CHECKPOINT_LOG_INDEX_ONLY',
        'main_targets_verified': False, 'completed_module_log_count': len(completed_logs),
        'completed_module_logs': completed_logs}), 'ALL_162_COMPLETED_DEPENDENCY_LOG_BINDINGS')
    manifest = {'schema_version': 1, 'archive_status': 'PENDING_WORK_CHECKPOINT',
                'main_targets_verified': False,
                'manifest_self_hash_location': 'CHECKPOINT_ARTIFACT.json beside the archive',
                'payload_member_count': len(files),
                'payload_bytes_excluding_manifest': sum(len(v) for v in files.values()),
                'files': [entries[n] for n in sorted(entries)]}
    manifest_data = json_bytes(manifest)
    payload = dict(files)
    payload['MANIFEST.json'] = manifest_data
    stage = RUNTIME / 'main-checkpoint-archive-stage'
    stage.mkdir(exist_ok=True)
    archive_path = stage / 'CHECKPOINT_EVIDENCE.tar.gz'
    with archive_path.open('wb') as raw:
        with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as tf:
                for name in sorted(payload):
                    info = tarfile.TarInfo(name)
                    info.size = len(payload[name]); info.mode = 0o644; info.mtime = 0
                    info.uid = info.gid = 0; info.uname = info.gname = ''
                    tf.addfile(info, io.BytesIO(payload[name]))
    with tarfile.open(archive_path, 'r:gz') as tf:
        members = tf.getmembers()
        require(len(members) == len(payload) and len({m.name for m in members}) == len(payload),
                'Archive readback count or uniqueness failure')
        require(set(m.name for m in members) == set(payload), 'Archive readback member set differs')
        for member in members:
            require(member.isfile(), f'Non-regular archive member: {member.name}')
            actual = tf.extractfile(member).read()
            require(actual == payload[member.name], f'Archive readback bytes differ: {member.name}')
            actual.decode('utf-8')
        restored_manifest = json.loads(tf.extractfile('MANIFEST.json').read())
        require(restored_manifest == manifest, 'Manifest readback differs')
        for entry in restored_manifest['files']:
            actual = tf.extractfile(entry['path']).read()
            require(sha(actual) == entry['sha256'] and len(actual) == entry['bytes'],
                    f'Manifest hash mismatch: {entry["path"]}')
    artifact = {
        'schema_version': 1, 'status': 'PENDING_WORK_ARCHIVE_READBACK_VERIFIED',
        'main_queue_status': 'STOPPED_PENDING', 'main_targets_verified': False,
        'main_targets_compiled': [], 'main_targets_replayed': [],
        'archive': {'repo_path': 'verification/parts/p1/round2/CHECKPOINT_EVIDENCE.tar.gz',
                    'sha256': digest(archive_path), 'bytes': archive_path.stat().st_size,
                    'member_count': len(payload), 'payload_bytes': sum(len(v) for v in payload.values()),
                    'manifest_sha256': sha(manifest_data), 'manifest_bytes': len(manifest_data)},
        'uncompiled_record': {'repo_path': 'verification/parts/p1/round2/UNCOMPILED.json',
                              'sha256': sha(uncompiled), 'bytes': len(uncompiled)},
        'readback': {'all_members_present_exactly_once': True, 'all_member_bytes_match': True,
                     'all_manifest_hashes_match': True, 'all_members_regular_files': True,
                     'all_members_utf8_text_without_null_bytes': True,
                     'contains_binaries': False, 'payload_member_hashes_checked': len(entries)},
        'source_parent_commit': COMMIT, 'common_mathematical_baseline': BASELINE,
        'pending_target_source_sha256': TARGETS,
        'completed_dependency_origin_counts': origins,
        'completed_dependency_checkpoint_count': 162,
        'unique_source_or_import_objects_rehashed': len(object_cache),
        'observed_exec_session_exit_code': 130,
        'underlying_lake_or_lean_subprocess_exit_code': None,
        'external_sources': external_sources,
        'archive_builder': drivers['archive_builder'],
        'scope_note': 'Readback verification concerns only this text evidence package and its 162 completed dependency bindings. It provides no compilation, replay, or audit success for the four main candidates.',
    }
    (stage / 'UNCOMPILED.json').write_bytes(uncompiled)
    (stage / 'CHECKPOINT_ARTIFACT.json').write_bytes(json_bytes(artifact))
    require(all(not (DEST / n).exists() for n in NAMES), 'Destination appeared while archiving')
    for name in NAMES:
        (stage / name).replace(DEST / name)
    for name in NAMES:
        print(json.dumps({'file': str(DEST / name), 'sha256': digest(DEST / name),
                          'bytes': (DEST / name).stat().st_size}))
    print(json.dumps({'status': artifact['status'], 'main_targets_verified': False,
                      'completed_dependency_origin_counts': origins,
                      'member_count': len(payload), 'payload_bytes': sum(len(v) for v in payload.values()),
                      'objects_rehashed': len(object_cache)}))


if __name__ == '__main__':
    main()
