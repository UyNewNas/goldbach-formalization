"""Restore only the official cache required by the actual round2 source graph."""
from pathlib import Path
from datetime import datetime, timezone
import json
import re
import subprocess
import time
import compile_driver as d

root = d.RUNTIME / 'logs/round2'
folder = root / 'cache'
folder.mkdir(parents=True, exist_ok=True)
plan = json.loads((root / 'source-plan.json').read_text())
pin_names = ['lean-toolchain', 'lake-manifest.json', 'lakefile.toml']
pins_before = {name: d.digest(d.REPO / name) for name in pin_names}
roots_file = root / 'cache-roots.txt'
if roots_file.read_text().splitlines() != plan['official_cache_root_modules']:
    raise RuntimeError('The official cache roots do not match the current source graph')
command = [str(d.TOOLROOT / 'bin/lake'), '-d', str(d.RUNTIME / 'cache-driver'),
           '-f', 'lakefile.lean', 'script', 'run', 'getPinnedClosure', str(roots_file)]
logfile = folder / 'get.log'
print('ROUND2_OFFICIAL_CACHE_START ' + json.dumps({'roots': len(plan['official_cache_root_modules']),
      'expected_source_modules': plan['cached_source_module_count'], 'command': command}), flush=True)
started = time.monotonic()
with logfile.open('w') as handle:
    handle.write(json.dumps({'command': command, 'metadata_adapter': 'exact --print-prefix only',
        'cache_driver_sha256': d.digest(d.RUNTIME / 'cache-driver/lakefile.lean'),
        'metadata_adapter_sha256': d.digest(d.RUNTIME / 'cache-metadata-bin/lean'),
        'expected_cache_module_count': plan['cached_source_module_count'],
        'project_pin_sha256_before': pins_before}) + '\n')
    handle.flush()
    completed = subprocess.run(command, cwd=d.REPO, env=d.environment(True),
                               stdout=handle, stderr=subprocess.STDOUT)
raw = logfile.read_text()
counts = [int(x) for x in re.findall(r'CACHE_ACTUAL_HASH_CLOSURE modules=(\d+)', raw)]
missing = [m for m in plan['cached_modules'] if not d.olean(m).is_file()]
pins_after = {name: d.digest(d.REPO / name) for name in pin_names}
result = {'recorded_utc': datetime.now(timezone.utc).isoformat(), 'command': command,
    'returncode': completed.returncode, 'elapsed_seconds': round(time.monotonic() - started, 3),
    'log': str(logfile), 'log_sha256': d.digest(logfile),
    'expected_cache_module_count': plan['cached_source_module_count'],
    'observed_hash_closure_counts': counts,
    'official_api_complete_marker': 'CACHE_API_COMPLETE' in raw,
    'missing_required_objects': missing, 'project_pin_sha256_before': pins_before,
    'project_pin_sha256_after': pins_after,
    'metadata_adapter_scope': 'Only the unchanged pinned Cache API metadata query; not project or supplier compilation or replay'}
result['verified'] = completed.returncode == 0 and counts == [plan['cached_source_module_count']] \
    and result['official_api_complete_marker'] and not missing and pins_before == pins_after
(folder / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
print('ROUND2_OFFICIAL_CACHE_RESULT ' + json.dumps(result), flush=True)
if not result['verified']:
    raise RuntimeError('Official cache restore failed or did not cover the required source graph')
