"""Restore only the official cache required by the actual round2 source graph."""
from pathlib import Path
from datetime import datetime, timezone
import json
import os
import re
import shutil
import subprocess
import time
import traceback
import compile_driver as d

root = d.RUNTIME / 'logs/round2'
folder = root / 'cache'
folder.mkdir(parents=True, exist_ok=True)
attempt = folder / ('attempt-' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'))
attempt.mkdir()
started = time.monotonic()
result = {'status': 'RUNNING', 'verified': False, 'returncode': None,
    'attempt': str(attempt), 'started_utc': datetime.now(timezone.utc).isoformat()}

def save_result():
    for destination in [attempt / 'result.json', folder / 'result.json']:
        destination.write_text(json.dumps(result, indent=2) + '\n')

save_result()
try:
    plan = json.loads((root / 'source-plan.json').read_text())
    pin_names = ['lean-toolchain', 'lake-manifest.json', 'lakefile.toml']
    pins_before = {name: d.digest(d.REPO / name) for name in pin_names}
    roots_file = root / 'cache-roots.txt'
    if roots_file.read_text().splitlines() != plan['official_cache_root_modules']:
        raise RuntimeError('The official cache roots do not match the current source graph')
    config_home = d.RUNTIME / 'curl-config/round2-cache'
    config_file = config_home / '.curlrc'
    expected_config = 'connect-timeout = 20\nmax-time = 120\nretry-max-time = 180\nparallel-max = 4\n'
    if config_file.read_text() != expected_config:
        raise RuntimeError('Unexpected task-local curl configuration')
    for source, name in [(root / 'source-plan.json', 'source-plan.json'),
                         (roots_file, 'cache-roots.txt'), (config_file, 'curlrc'),
                         (Path(__file__), 'round2_get_cache.py')]:
        shutil.copyfile(source, attempt / name)
    command = [str(d.TOOLROOT / 'bin/lake'), '-d', str(d.RUNTIME / 'cache-driver'),
               '-f', 'lakefile.lean', 'script', 'run', 'getPinnedClosure', str(roots_file)]
    logfile = attempt / 'get.log'
    live_log = folder / 'get.log'
    if live_log.exists() or live_log.is_symlink():
        live_log.unlink()
    live_log.symlink_to(logfile)
    environment = d.environment(True)
    environment['CURL_HOME'] = str(config_home)
    print('ROUND2_OFFICIAL_CACHE_START ' + json.dumps({'roots': len(plan['official_cache_root_modules']),
          'expected_source_modules': plan['cached_source_module_count'], 'command': command,
          'attempt': str(attempt), 'curl_configuration': expected_config}), flush=True)
    with logfile.open('w') as handle:
        handle.write(json.dumps({'command': command, 'metadata_adapter': 'exact --print-prefix only',
        'cache_driver_sha256': d.digest(d.RUNTIME / 'cache-driver/lakefile.lean'),
        'metadata_adapter_sha256': d.digest(d.RUNTIME / 'cache-metadata-bin/lean'),
        'expected_cache_module_count': plan['cached_source_module_count'],
        'project_pin_sha256_before': pins_before, 'CURL_HOME': str(config_home),
        'curlrc_sha256': d.digest(config_file), 'curlrc_text': expected_config}) + '\n')
        handle.flush()
        completed = subprocess.run(command, cwd=d.REPO, env=environment,
                                   stdout=handle, stderr=subprocess.STDOUT)
    raw = logfile.read_text()
    counts = [int(x) for x in re.findall(r'CACHE_ACTUAL_HASH_CLOSURE modules=(\d+)', raw)]
    missing = [m for m in plan['cached_modules'] if not d.olean(m).is_file()]
    pins_after = {name: d.digest(d.REPO / name) for name in pin_names}
    result.update({'recorded_utc': datetime.now(timezone.utc).isoformat(), 'command': command,
        'returncode': completed.returncode, 'elapsed_seconds': round(time.monotonic() - started, 3),
        'log': str(logfile), 'log_sha256': d.digest(logfile),
        'expected_cache_module_count': plan['cached_source_module_count'],
        'observed_hash_closure_counts': counts,
        'official_api_complete_marker': 'CACHE_API_COMPLETE' in raw,
        'missing_required_objects': missing, 'project_pin_sha256_before': pins_before,
        'project_pin_sha256_after': pins_after, 'CURL_HOME': str(config_home),
        'curlrc_sha256': d.digest(config_file), 'curlrc_text': expected_config,
        'metadata_adapter_scope': 'Only the unchanged pinned Cache API metadata query; not project or supplier compilation or replay'})
    result['verified'] = completed.returncode == 0 and counts == [plan['cached_source_module_count']] \
        and result['official_api_complete_marker'] and not missing and pins_before == pins_after
    result['status'] = 'SUCCEEDED' if result['verified'] else 'FAILED'
    save_result()
    print('ROUND2_OFFICIAL_CACHE_RESULT ' + json.dumps(result), flush=True)
    if not result['verified']:
        raise SystemExit(1)
except (Exception, KeyboardInterrupt) as error:
    result.update({'status': 'FAILED', 'verified': False,
        'wrapper_returncode': 130 if isinstance(error, KeyboardInterrupt) else 1,
        'error_type': type(error).__name__, 'error': str(error),
        'elapsed_seconds': round(time.monotonic() - started, 3)})
    save_result()
    traceback.print_exc()
    raise SystemExit(result['wrapper_returncode'])
