import Lake
import Cache.Requests

open Lake DSL

package p1CacheDriver

/-- Use unchanged pinned Mathlib cache APIs with explicit source paths. -/
script getPinnedClosure (args) do
  let [rootsFile] := args
    | throw <| IO.userError "usage: getPinnedClosure ROOTS_FILE"
  let some rawPath ← IO.getEnv "LEAN_SRC_PATH"
    | throw <| IO.userError "LEAN_SRC_PATH must be explicitly set"
  let ctx : Cache.IO.CacheM.Context := {
    mathlibDepPath := "/workspace/scratch/127408f63891/goldbach-formalization/.lake/packages/mathlib"
    srcSearchPath := System.SearchPath.parse rawPath
  }
  IO.Process.setCurrentDir "/workspace/scratch/127408f63891/goldbach-formalization"
  let names := ((← IO.FS.readFile rootsFile).splitOn "\n").map (·.trimAscii.toString) |>.filter (!·.isEmpty)
  unless !names.isEmpty do
    throw <| IO.userError "Empty root list is forbidden"
  IO.println s!"CACHE_API_START repo=leanprover-community/mathlib4 metadata_adapter=print-prefix-only roots={names}"
  let action : Cache.IO.CacheM Unit := do
    let roots ← Cache.IO.parseArgs ("get" :: names)
    let memo ← Cache.Hashing.getHashMemo roots
    let hashes ← memo.filterByRootModules roots.keys
    IO.println s!"CACHE_ACTUAL_HASH_CLOSURE modules={hashes.size}"
    let goodCurl ← Cache.IO.validateCurl
    Cache.Requests.getFiles "leanprover-community/mathlib4" hashes false false goodCurl true
    IO.println "CACHE_API_COMPLETE"
  ReaderT.run action ctx
  return 0
