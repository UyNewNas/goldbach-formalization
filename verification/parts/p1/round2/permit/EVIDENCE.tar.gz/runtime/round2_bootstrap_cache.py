"""Compile unchanged pinned Cache prerequisites, reusing only bound old objects."""
from pathlib import Path
import json
import compile_driver as d

logdir = d.RUNTIME / 'logs/round2/bootstrap'
logdir.mkdir(parents=True, exist_ok=True)
old = d.BASE / 'p1-round2-recovered-evidence/runtime/logs/bootstrap/results.jsonl'
old_records = {}
if old.exists():
    for line in old.read_text().splitlines():
        record = json.loads(line)
        if record.get('returncode') == 0:
            old_records[record['module']] = record
order = d.closure(['Cache.Requests'])
print('ROUND2_CACHE_BOOTSTRAP_ORDER ' + json.dumps(order), flush=True)
records = []
for module in order:
    source = d.INDEX[module][0]
    output = d.olean(module)
    previous = old_records.get(module)
    if previous and output.exists() and d.digest(source) == previous['source_sha256_after'] \
            and d.digest(output) == previous.get('olean_sha256'):
        record = {'module': module, 'status': 'REUSED_ARCHIVED_COMPILE_OBJECT',
                  'source_sha256': d.digest(source), 'olean_sha256': d.digest(output),
                  'prior_record': previous, 'compiled_in_round2': False}
        print('ROUND2_CACHE_BOOTSTRAP_REUSED ' + json.dumps({'module': module,
              'olean_sha256': record['olean_sha256']}), flush=True)
    else:
        record = d.compile_module(module, logdir, metadata=True)
        record['compiled_in_round2'] = True
    records.append(record)
    (logdir / 'bootstrap-records.json').write_text(json.dumps(records, indent=2) + '\n')
print('ROUND2_CACHE_BOOTSTRAP_OK ' + json.dumps({'modules': len(order),
      'compiled_in_round2': sum(r['compiled_in_round2'] for r in records),
      'reused_from_previous_round': sum(not r['compiled_in_round2'] for r in records)}), flush=True)
