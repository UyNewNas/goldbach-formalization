"""Gated evidence collection for the independent stored-cap permit milestone.

No compiler/checker is invoked here.  A successful receipt requires the three
real strict compilations, three real original checker calls, and the complete
two-module declaration inventory.  Dependency reuse and cache use are explicit.
"""
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import re
import subprocess
import traceback

import compile_driver as d
from permit_compile_targets import TARGETS, ROOT, ARCHIVE, LOCK, DRIVER_SHA256, matches, source_plan

DESTINATION = d.RUNTIME / 'part1-permit-final-receipt.json'
AUDIT = TARGETS[-1]
OLD_RECEIPT_SHA256 = '2a23599ce539e7768a938e729b9beb7516210ff49221f6a8fd8a0938107765a1'
INHERITED_COMMIT = '7f894bfb57b7aa561360e335c6d610b7c30614e0'
ALLOWED = {'propext', 'Classical.choice', 'Quot.sound'}


def read(path):
    return json.loads(path.read_text())


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n')


def ref(path):
    return {'path': str(path), 'sha256': d.digest(path), 'bytes': path.stat().st_size}


def need(condition, message):
    if not condition:
        raise RuntimeError(message)


def parts(module):
    output = d.olean(module)
    return {p.name: ref(p) for p in sorted(output.parent.glob(output.name + '*')) if p.is_file()}


def part_hashes(value):
    return {name: item['sha256'] for name, item in value.items()}


def direct_imports(module):
    return {dep: d.digest(d.olean(dep)) for dep in d.imports(module)}


def git(root, *args):
    return subprocess.run(['git', '--no-optional-locks', '-C', str(root), *args],
        check=True, capture_output=True, text=True).stdout.strip()


def collect(attempt):
    compilation = read(ROOT / 'compile/result.json')
    plan = read(ROOT / 'compile/plan.json')
    state = read(ROOT / 'compile/state.json')
    replay = read(ROOT / 'replay/result.json')
    need(compilation.get('status') == 'SUCCEEDED' and compilation.get('returncode') == 0
        and compilation['targets'] == TARGETS and compilation['strict_targets'] == TARGETS
        and compilation['trustLevel'] == 0 and not compilation['metadata_adapter'],
        'The latest three-target strict permit compilation did not pass')
    current_plan = source_plan()
    need(current_plan == plan and compilation['complete_local_modules'] == plan['local_module_count'],
        'The permit source graph changed or was not fully completed')
    need(d.digest(d.RUNTIME / 'frontend-driver/lakefile.lean') == DRIVER_SHA256,
        'The original serialized compiler API driver changed')

    cache_path = d.RUNTIME / 'logs/round2/cache/result.json'
    cache = read(cache_path)
    need(cache.get('verified') and cache.get('returncode') == 0
        and cache.get('status') == 'SUCCEEDED' and cache.get('official_api_complete_marker')
        and not cache.get('missing_required_objects'), 'The official cache did not succeed')
    cache_plan = read(Path(cache['attempt']) / 'source-plan.json')
    need(set(plan['cached_modules']) <= set(cache_plan['cached_modules']),
        'The permit cached dependencies are outside the restored official closure')
    need(d.digest(Path(cache['log'])) == cache['log_sha256']
        and 'CACHE_API_COMPLETE' in Path(cache['log']).read_text(), 'The official cache raw log changed')

    old_receipt_path = ARCHIVE / 'part1-final-receipt.json'
    need(d.digest(old_receipt_path) == OLD_RECEIPT_SHA256, 'The previous verified receipt changed')
    old_receipt = read(old_receipt_path)
    prior = read(ARCHIVE / 'logs/closure/state.json')
    old_six = {}
    for module, old in old_receipt['targets'].items():
        source = ref(d.INDEX[module][0])
        artifact_parts = parts(module)
        need(source['sha256'] == old['source']['sha256']
            and part_hashes(artifact_parts) == part_hashes(old['artifact_parts']),
            'A previous strict target source or object changed: ' + module)
        old_six[module] = {'source': source, 'artifact_parts': artifact_parts,
            'matched_previous_receipt': True, 'compiled_in_permit': False, 'replayed_in_permit': False}
    need(len(old_six) == 6 and not set(old_six) & set(TARGETS), 'Unexpected old/new target overlap')

    need(replay.get('status') == 'SUCCEEDED' and replay.get('verified')
        and replay.get('returncode') == 0 and replay['expected_targets'] == TARGETS
        and replay['observed_replay_lines'] == TARGETS, 'Original permit replay is incomplete')
    commands = [[str(d.TOOLROOT / 'bin/leanchecker'), '--verbose', module] for module in TARGETS]
    need(replay['commands'] == commands and len(replay['calls']) == 3
        and replay['LEAN_NUM_THREADS'] == '1' and not replay['metadata_adapter'],
        'The replay did not use three sequential original single-target commands')
    need(replay['compile_result_sha256'] == d.digest(ROOT / 'compile/result.json')
        and replay['compile_state_sha256'] == d.digest(ROOT / 'compile/state.json'),
        'The compilation state changed after replay began')
    need(replay['source_sha256_before'] == replay['source_sha256_after']
        and replay['artifacts_sha256_before'] == replay['artifacts_sha256_after']
        and replay['direct_import_olean_sha256_before'] == replay['direct_import_olean_sha256_after'],
        'A replay input changed during the checker phase')
    checker_source = d.TOOLROOT / 'src/lean/LeanChecker.lean'
    need(replay['original_leanchecker_sha256'] == d.digest(d.TOOLROOT / 'bin/leanchecker')
        == 'ed46f21c763051c26f89481096cbaaf5db9665d674d602e3daf3391613ba0e6a'
        and replay['semantics']['source_sha256'] == d.digest(checker_source)
        == 'eb5dee411837629f09c5c18d63cc833d30335a46048bc586642742e90aa65d5f',
        'The original checker or its defining source changed')
    locking = replay['scheduling']
    need(locking['path'] == str(LOCK) and locking['compatibility_source_sha256']
        == d.digest(Path(locking['compatibility_source']))
        == '7dd91cc0c7ebd7a1ed69ac9b870634b6ae251f28e96ba54384b5ba6e8ce20efd'
        and locking['requested_utc'] <= locking['acquired_utc'] <= locking['released_utc'],
        'The shared resource lock record is inconsistent')
    aggregate_path = Path(replay['log'])
    aggregate_raw = aggregate_path.read_text()
    aggregate_header = json.loads(aggregate_raw.splitlines()[0])
    need(d.digest(aggregate_path) == replay['log_sha256']
        and aggregate_header['commands'] == commands
        and aggregate_header['source_sha256'] == replay['source_sha256_before']
        and aggregate_header['artifacts_sha256_before'] == replay['artifacts_sha256_before']
        and aggregate_header['direct_import_olean_sha256_before'] == replay['direct_import_olean_sha256_before']
        and re.findall(r'^replaying (\S+)\s*$', aggregate_raw, re.MULTILINE) == TARGETS,
        'The aggregate replay raw log does not bind the recorded inputs and coverage')
    for module, command, call in zip(TARGETS, commands, replay['calls']):
        path = Path(call['log'])
        raw = path.read_text()
        header = json.loads(raw.splitlines()[0])
        need(call['module'] == module and call['command'] == command and call['returncode'] == 0
            and call['verified'] and call['observed_replay_lines'] == [module]
            and d.digest(path) == call['log_sha256'] and raw in aggregate_raw
            and re.findall(r'^replaying (\S+)\s*$', raw, re.MULTILINE) == [module],
            'An individual original checker call did not pass: ' + module)
        need(header['module'] == module and header['command'] == command
            and header['source_sha256'] == replay['source_sha256_before'][module]
            and header['artifacts_sha256_before'] == replay['artifacts_sha256_before'][module]
            and header['direct_import_olean_sha256_before'] == replay['direct_import_olean_sha256_before'][module]
            and header['LEAN_NUM_THREADS'] == '1' and not header['metadata_adapter']
            and header['shared_lock_held'] == str(LOCK)
            and locking['acquired_utc'] <= call['started_utc'] <= call['finished_utc'] <= locking['released_utc'],
            'A checker input/lock interval is inconsistent: ' + module)

    targets = {}
    for module in TARGETS:
        record = state[module]
        need(matches(module, record) and record == compilation['new_target_records'][module]
            and record['strict'] and record['compiled_in_permit']
            and record['origin'] == 'CURRENT_PERMIT_ACTUAL_COMPILATION',
            'A target lacks actual current strict compilation: ' + module)
        path = Path(record['log'])
        lines = path.read_text().splitlines()
        header = json.loads(lines[0])
        source = d.INDEX[module][0]
        command = [str(d.TOOLROOT / 'bin/lake'), '-d', str(d.RUNTIME / 'frontend-driver'),
            '-f', 'lakefile.lean', 'script', 'run', 'compileOne', str(source), module,
            str(d.olean(module)), 'strict']
        need(header['command'] == command and header['source_sha256_before'] == record['source_sha256_before']
            and header['trustLevel'] == 0 and not header['metadata_adapter']
            and 'P1_SCHEDULER_SERIAL_BEGIN module=' + module in lines
            and 'FRONTEND_START module=' + module + ' trustLevel=0 strict=strict Lean.githash=62eed1db4d67327ec8120be05f1a1b0847d74561' in lines
            and 'FRONTEND_OK module=' + module + ' trustLevel=0' in lines,
            'A target raw log lacks the expected actual compiler command/success: ' + module)
        snapshot = path.parent.parent / 'target-sources' / (module + '.lean')
        need(snapshot.is_file() and d.digest(snapshot) == d.digest(source), 'The attempt source snapshot changed')
        artifact_parts = parts(module)
        need(part_hashes(artifact_parts) == replay['artifacts_sha256_after'][module]
            and d.digest(source) == replay['source_sha256_after'][module]
            and direct_imports(module) == replay['direct_import_olean_sha256_after'][module],
            'A target source/object/import changed after replay: ' + module)
        targets[module] = {**record, 'source': ref(source), 'command': command,
            'attempt_source_snapshot': ref(snapshot), 'artifact_parts': artifact_parts,
            'direct_import_artifact_parts': {dep: parts(dep) for dep in d.imports(module)},
            'log': ref(path), 'original_checker_replayed_defined_declarations': True}

    audit_lines = Path(state[AUDIT]['log']).read_text().splitlines()
    declarations = [json.loads(line.removeprefix('PART1_STORED_CAP_AUDIT_DECL '))
        for line in audit_lines if line.startswith('PART1_STORED_CAP_AUDIT_DECL ')]
    module_lines = [json.loads(line.removeprefix('PART1_STORED_CAP_AUDIT_MODULE '))
        for line in audit_lines if line.startswith('PART1_STORED_CAP_AUDIT_MODULE ')]
    totals = [int(line.removeprefix('PART1_STORED_CAP_AUDIT_COUNT '))
        for line in audit_lines if line.startswith('PART1_STORED_CAP_AUDIT_COUNT ')]
    defining = set(TARGETS) - {AUDIT}
    counts = Counter(item['module'] for item in declarations)
    observed_axioms = {axiom for item in declarations for axiom in item['axioms']}
    need(len(totals) == 1 and totals[0] == len(declarations)
        and len({item['name'] for item in declarations}) == len(declarations)
        and set(counts) == defining and len(module_lines) == len(defining)
        and len({item['module'] for item in module_lines}) == len(defining)
        and dict(counts) == {item['module']: item['count'] for item in module_lines},
        'The complete defining-module declaration census is inconsistent')
    need(defining <= set(state[AUDIT]['import_olean_sha256']) and observed_axioms <= ALLOWED
        and all(item['kind'] != 'axiom' for item in declarations), 'The audit imported stale inputs or found a forbidden axiom')

    bindings = {'kind': 'Exact permit dependency source/object snapshot after successful target replay',
        'targets': TARGETS, 'source_module_count': plan['source_module_count'],
        'local_modules': {}, 'cached_modules': {}}
    for module in plan['local_modules']:
        record = state[module]
        need(matches(module, record), 'A local permit binding changed: ' + module)
        if module not in TARGETS:
            need(record['origin'] == 'ARCHIVED_FIRST_ROUND_ACTUAL_COMPILATION'
                and not record['compiled_in_permit']
                and all(record.get(key) == value for key, value in prior[module].items()),
                'An archived supplier record was incorrectly promoted or modified: ' + module)
            raw_path = ARCHIVE / Path(prior[module]['log']).relative_to(d.RUNTIME)
        else:
            raw_path = Path(record['log'])
        bindings['local_modules'][module] = {'source': ref(d.INDEX[module][0]),
            'artifact_parts': parts(module), 'direct_import_olean_sha256': direct_imports(module),
            'origin': record['origin'], 'compiled_in_permit': record['compiled_in_permit'],
            'raw_compile_log': ref(raw_path)}
    print('PERMIT_HASH_CACHED_DEPENDENCIES ' + str(len(plan['cached_modules'])), flush=True)
    for module in plan['cached_modules']:
        need(d.olean(module).is_file(), 'A required cached object is missing: ' + module)
        bindings['cached_modules'][module] = {'source': ref(d.INDEX[module][0]),
            'artifact_parts': parts(module), 'origin': 'OFFICIAL_PINNED_MATHLIB_CACHE',
            'compiled_in_permit': False}

    restored = read(d.RUNTIME / 'recovery/toolchain-restoration.json')
    binaries = {}
    for name, old in restored['binaries'].items():
        current = ref(Path(old['path']))
        need(current['sha256'] == old['sha256'] == old['expected_sha256'] and old['matches'],
            'An original tool executable changed: ' + name)
        binaries[name] = current
    restore_deps = read(d.RUNTIME / 'recovery/dependencies/results.json')
    pin_files = {}
    for name, expected in restore_deps['project_pin_sha256_before'].items():
        current = ref(d.REPO / name)
        need(current['sha256'] == expected == cache['project_pin_sha256_before'][name]
            == cache['project_pin_sha256_after'][name], 'A project pin/configuration changed: ' + name)
        pin_files[name] = current
    pins = []
    for package in d.PACKAGES:
        package_root = d.REPO / '.lake/packages' / package['name']
        actual = git(package_root, 'rev-parse', 'HEAD')
        need(actual == package['rev'] and not git(package_root, 'status', '--porcelain', '--untracked-files=no'),
            'A dependency no longer matches its exact unchanged pin: ' + package['name'])
        pins.append({'package': package['name'], 'expected_rev': package['rev'],
            'actual_head': actual, 'exact_pin': True, 'tracked_changes': []})
    inherited = {}
    for line in git(d.REPO, 'ls-tree', '-r', INHERITED_COMMIT).splitlines():
        metadata, name = line.split('\t', 1)
        if not name.endswith('.lean'):
            continue
        content = (d.REPO / name).read_bytes()
        actual = hashlib.sha1(b'blob ' + str(len(content)).encode() + b'\x00' + content).hexdigest()
        need(actual == metadata.split()[2], 'An inherited Lean source changed: ' + name)
        inherited[name] = actual
    old_archive = d.REPO / 'verification/parts/p1/EVIDENCE.tar.gz'
    need(d.digest(old_archive) == 'c56fc707d40ad255fd2d9c8b6c94dc7442c9c62b7238d833188b18cdf10f601d',
        'The previously delivered evidence archive changed')

    binding_path = attempt / 'dependency-bindings.json'
    write(binding_path, bindings)
    write(ROOT / 'dependency-bindings.json', bindings)
    scripts = {}
    for relative in ['frontend-driver/lakefile.lean', 'compile_driver.py',
            'permit_compile_targets.py', 'permit_replay_targets.py', 'permit_finalize_receipt.py']:
        path = d.RUNTIME / relative
        scripts[relative] = {**ref(path), 'text': path.read_text()}
    return {'recorded_utc': datetime.now(timezone.utc).isoformat(), 'status': 'VERIFIED',
        'receipt_kind': 'Independent stored historical cap permit: three actual strict compilations, three original checker calls, complete two-module axiom census',
        'repository_path': str(d.REPO), 'repository_head_at_collection': git(d.REPO, 'rev-parse', 'HEAD'),
        'mathematical_baseline_commit': '1a80c1bcce67886f699d097fc37fd245cd3620bf',
        'prior_verified_part1_commit': 'b09d5361e0b30f3e85cb912a03c7bfb85a99bf8f',
        'inherited_source_commit': INHERITED_COMMIT,
        'delivery_commit_status': 'This scratch receipt precedes the parent delivery commit and does not assert its later SHA.',
        'verification': {'actual_original_frontend_compilation': True,
            'frontend_api': 'Lean.Elab.runFrontend', 'trustLevel': 0,
            'normal_initializer_lifecycle': 'Lean.enableInitializersExecution',
            'target_warning_as_error': True, 'metadata_adapter_during_compilation_or_replay': False,
            'original_leanchecker_three_sequential_calls_aggregate_exit_code': replay['returncode'],
            'original_leanchecker_individual_exit_codes': {c['module']: c['returncode'] for c in replay['calls']},
            'standard_lake_build_executed': False, 'full_repository_build_or_replay_executed': False,
            'normal_lean_cli_startup': ref(d.RUNTIME / 'recovery/toolchain-startup-observations.json'),
            'scheduling': 'One actual frontend or original checker at a time, under the unchanged shared OS file lock. The independent main supplier loop was not extended by this permit graph.'},
        'targets': targets,
        'closure': {'source_modules': plan['source_module_count'],
            'local_source_modules': plan['local_module_count'],
            'official_cached_source_modules': plan['cached_module_count'],
            'newly_compiled_local_modules': len(TARGETS),
            'reused_archived_local_modules': len(plan['local_modules']) - len(TARGETS),
            'plan': ref(ROOT / 'compile/plan.json'), 'state': ref(ROOT / 'compile/state.json'),
            'result': ref(ROOT / 'compile/result.json'), 'execution_result': compilation,
            'dependency_bindings': ref(binding_path),
            'all_local_source_object_and_direct_import_hashes_rechecked': True,
            'all_cached_source_and_artifact_part_hashes_recorded': True},
        'audit': {'mechanism': 'Complete Lean environment inventory by defining-module metadata, including private/generated declarations; bundled transitive collectAxioms; unsafe/axiom declarations and axioms outside the standard three are rejected.',
            'audited_defining_modules': sorted(defining), 'declaration_count': len(declarations),
            'module_counts': dict(counts), 'allowed_axioms': sorted(ALLOWED),
            'observed_axioms': sorted(observed_axioms), 'declarations': declarations,
            'full_types_in_raw_audit_log': ref(Path(state[AUDIT]['log']))},
        'replay': replay,
        'historical_reuse': {'old_six_targets': old_six, 'old_receipt': ref(old_receipt_path),
            'old_archive': ref(old_archive), 'old_state': ref(ARCHIVE / 'logs/closure/state.json'),
            'scope_note': 'The previous six targets retain matching source/object hashes; they were not recompiled or replayed as permit targets.'},
        'cache': {'result': {**ref(cache_path), 'record': cache},
            'coverage': 'The 3368 permit cached modules are an exact subset of the restored 8679-module official cache closure.',
            'initial_terminated_attempt': ref(d.RUNTIME / 'logs/round2/cache/attempt-01-terminated/result.json')},
        'toolchain': {'restoration': ref(d.RUNTIME / 'recovery/toolchain-restoration.json'),
            'binaries_rechecked': binaries, 'archive_sha256': restored['archive_sha256'],
            'original_driver_restoration': ref(d.RUNTIME / 'recovery/restored-drivers.json'),
            'lock_implementation_source': ref(Path(locking['compatibility_source'])),
            'lock_implementation_source_record': ref(d.RUNTIME / 'recovery/official-io-lock-source.json')},
        'dependency_pins': pins, 'project_pin_files': pin_files,
        'inherited_lean_git_blob_sha1': inherited, 'scripts': scripts,
        'attempt_results': {str(path.relative_to(ROOT)): {**ref(path), 'record': read(path)}
            for pattern in ['compile/attempt-*/result.json', 'replay/attempt-*/result.json']
            for path in sorted(ROOT.glob(pattern))},
        'scope_limits': ['This validates the stored-cap permit interface and its finite probes.',
            'The four larger round2 geometry/integral targets have separate unfinished verification and are not certified by this receipt.',
            'The full adopted multilevel policy, complete historical integral combination, and final K/c bounds are not asserted.']}


def main():
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    attempt = ROOT / 'receipt' / ('attempt-' + stamp)
    attempt.mkdir(parents=True)
    if DESTINATION.exists():
        DESTINATION.rename(attempt / 'superseded-receipt.json')
    result_path = attempt / 'result.json'
    write(result_path, {'status': 'RUNNING', 'returncode': None})
    try:
        receipt = collect(attempt)
        write(DESTINATION, receipt)
        result = {'status': 'SUCCEEDED', 'returncode': 0, 'receipt': ref(DESTINATION),
            'targets': TARGETS, 'audit_declaration_count': receipt['audit']['declaration_count']}
        write(result_path, result)
        print('PERMIT_FINAL_RECEIPT_OK ' + json.dumps(result), flush=True)
    except (Exception, KeyboardInterrupt) as error:
        rejected = None
        if DESTINATION.exists():
            rejected = attempt / 'unaccepted-receipt.json'
            DESTINATION.rename(rejected)
        write(result_path, {'status': 'FAILED', 'returncode': 130 if isinstance(error, KeyboardInterrupt) else 1,
            'error_type': type(error).__name__, 'error': str(error), 'receipt_created': False,
            'unaccepted_receipt': str(rejected) if rejected else None})
        traceback.print_exc()
        raise SystemExit(130 if isinstance(error, KeyboardInterrupt) else 1)


if __name__ == '__main__':
    main()
