"""Restore the exact, unchanged official release; no project compilation."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import subprocess
import time

RUNTIME = Path('/workspace/scratch/127408f63891/lean-runtime')
URL = 'https://github.com/leanprover/lean4/releases/download/v4.33.0-rc1/lean-4.33.0-rc1-linux.tar.zst'
EXPECTED_ARCHIVE = '25e7b3e18ec75a4e2529fc23194be8e3cc3183df99b553f870d8a111c7488210'
BINARIES = {
    'lean': 'e8baaa71855a616dc351028f3ad2200051b0671f423a1696a100e809302d5550',
    'lake': '60330ab6f07dce20f3fa9ebb08e8b984ea9549eac172afeb15d9d2227060e2b3',
    'leanchecker': 'ed46f21c763051c26f89481096cbaaf5db9665d674d602e3daf3391613ba0e6a',
    'leantar': '06d613dffd2a6fd996b095bfd835c2bb720886f9eb7e13ed2adddd7df4507bf3',
}

def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(8 * 1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()

def main():
    logs = RUNTIME / 'recovery'
    downloads = RUNTIME / 'downloads'
    downloads.mkdir(parents=True, exist_ok=True)
    archive = downloads / 'lean-4.33.0-rc1-linux.tar.zst'
    toolroot = RUNTIME / 'lean-4.33.0-rc1-linux'
    result_path = logs / 'toolchain-restoration.json'
    result = {
        'started_utc': datetime.now(timezone.utc).isoformat(),
        'official_release_url': URL,
        'expected_archive_sha256': EXPECTED_ARCHIVE,
        'archive': str(archive),
        'toolroot': str(toolroot),
        'project_or_dependency_source_modified': False,
        'project_compilation_started': False,
        'status': 'STARTED',
    }
    def save():
        result_path.write_text(json.dumps(result, indent=2) + '\n')
    save()
    command = ['curl', '--fail', '--location', '--retry', '3', '--silent',
               '--show-error', '--output', str(archive), '--write-out',
               '{"http_code":%{http_code},"size_download":%{size_download},"time_total":%{time_total}}\n', URL]
    started = time.monotonic()
    with (logs / 'toolchain-download.log').open('w') as handle:
        handle.write(json.dumps({'command': command}) + '\n')
        handle.flush()
        completed = subprocess.run(command, stdout=handle, stderr=subprocess.STDOUT)
    result['download'] = {'command': command, 'returncode': completed.returncode,
                          'elapsed_seconds': round(time.monotonic() - started, 3),
                          'log': str(logs / 'toolchain-download.log')}
    save()
    if completed.returncode != 0:
        raise RuntimeError('Official release download failed')
    actual = digest(archive)
    result['archive_sha256'] = actual
    result['archive_bytes'] = archive.stat().st_size
    result['archive_hash_matches'] = actual == EXPECTED_ARCHIVE
    save()
    if actual != EXPECTED_ARCHIVE:
        raise RuntimeError('Official release archive hash mismatch; not extracting')
    print('OFFICIAL_ARCHIVE_HASH_OK ' + json.dumps({'sha256': actual, 'bytes': archive.stat().st_size}), flush=True)
    command = ['tar', '--zstd', '-xf', str(archive), '-C', str(RUNTIME)]
    started = time.monotonic()
    with (logs / 'toolchain-extract.log').open('w') as handle:
        handle.write(json.dumps({'command': command}) + '\n')
        handle.flush()
        completed = subprocess.run(command, stdout=handle, stderr=subprocess.STDOUT)
    result['extract'] = {'command': command, 'returncode': completed.returncode,
                         'elapsed_seconds': round(time.monotonic() - started, 3),
                         'log': str(logs / 'toolchain-extract.log')}
    save()
    if completed.returncode != 0:
        raise RuntimeError('Verified official release extraction failed')
    result['binaries'] = {}
    for name, expected in BINARIES.items():
        path = toolroot / 'bin' / name
        actual = digest(path)
        result['binaries'][name] = {'path': str(path), 'sha256': actual,
                                    'expected_sha256': expected,
                                    'matches': actual == expected,
                                    'bytes': path.stat().st_size}
        if actual != expected:
            save()
            raise RuntimeError('Original binary hash mismatch: ' + name)
    result['status'] = 'EXACT_OFFICIAL_RELEASE_RESTORED'
    result['completed_utc'] = datetime.now(timezone.utc).isoformat()
    save()
    print('OFFICIAL_TOOLCHAIN_RESTORED ' + json.dumps({'result': str(result_path), 'binaries': result['binaries']}), flush=True)

if __name__ == '__main__':
    main()
