"""Repeat extraction using ordinary tar owner handling; keep release bytes exact."""
from datetime import datetime, timezone
from pathlib import Path
import json
import subprocess
import time
from restore_toolchain import RUNTIME, EXPECTED_ARCHIVE, BINARIES, digest

logs = RUNTIME / 'recovery'
result_path = logs / 'toolchain-restoration.json'
old_text = result_path.read_text()
(logs / 'toolchain-restoration-initial-extract-failed.json').write_text(old_text)
result = json.loads(old_text)
archive = Path(result['archive'])
if digest(archive) != EXPECTED_ARCHIVE:
    raise RuntimeError('Archive changed before retry')
result['extract_attempts'] = [result.pop('extract')]
result['owner_metadata_note'] = 'Initial tar attempted archived uid/gid 1001 and received Invalid argument. Retry uses standard --no-same-owner; content and modes are unchanged.'
command = ['tar', '--no-same-owner', '--zstd', '-xf', str(archive), '-C', str(RUNTIME)]
started = time.monotonic()
logfile = logs / 'toolchain-extract-no-same-owner.log'
with logfile.open('w') as handle:
    handle.write(json.dumps({'command': command}) + '\n')
    handle.flush()
    completed = subprocess.run(command, stdout=handle, stderr=subprocess.STDOUT)
result['extract_attempts'].append({'command': command, 'returncode': completed.returncode,
    'elapsed_seconds': round(time.monotonic() - started, 3), 'log': str(logfile)})
result_path.write_text(json.dumps(result, indent=2) + '\n')
if completed.returncode != 0:
    raise RuntimeError('Normal owner-preserving extraction retry failed')
toolroot = Path(result['toolroot'])
result['binaries'] = {}
for name, expected in BINARIES.items():
    path = toolroot / 'bin' / name
    actual = digest(path)
    result['binaries'][name] = {'path': str(path), 'sha256': actual,
        'expected_sha256': expected, 'matches': actual == expected, 'bytes': path.stat().st_size}
    if actual != expected:
        result_path.write_text(json.dumps(result, indent=2) + '\n')
        raise RuntimeError('Original binary hash mismatch: ' + name)
result['status'] = 'EXACT_OFFICIAL_RELEASE_RESTORED'
result['completed_utc'] = datetime.now(timezone.utc).isoformat()
result_path.write_text(json.dumps(result, indent=2) + '\n')
print('OFFICIAL_TOOLCHAIN_RESTORED ' + json.dumps({'result': str(result_path), 'binaries': result['binaries']}), flush=True)
