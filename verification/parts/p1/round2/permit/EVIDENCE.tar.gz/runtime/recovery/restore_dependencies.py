"""Restore exact manifest commits while retaining surviving untracked build objects."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess
import time

BASE = Path('/workspace/scratch/127408f63891')
REPO = BASE / 'goldbach-formalization'
LOGS = BASE / 'lean-runtime/recovery/dependencies'
MANIFEST = REPO / 'lake-manifest.json'

def digest(path):
    with path.open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()

def object_hashes(root):
    build = root / '.lake/build/lib/lean'
    if not build.exists():
        return {}
    return {str(p.relative_to(root)): digest(p) for p in sorted(build.rglob('*'))
            if p.is_file() and (p.name.endswith('.olean') or
                p.name.endswith('.olean.private') or p.name.endswith('.olean.server'))}

def main():
    LOGS.mkdir(parents=True, exist_ok=True)
    pins_before = {name: digest(REPO / name) for name in
                   ['lean-toolchain', 'lake-manifest.json', 'lakefile.toml']}
    packages = json.loads(MANIFEST.read_text())['packages']
    summary = {'started_utc': datetime.now(timezone.utc).isoformat(),
               'project_pin_sha256_before': pins_before,
               'method': 'Exact SHA fetch and checkout within each dependency; no lake update',
               'packages': [], 'status': 'RESTORING'}
    result_file = LOGS / 'results.json'
    def save():
        result_file.write_text(json.dumps(summary, indent=2) + '\n')
    save()
    for package in packages:
        name, rev, url = package['name'], package['rev'], package['url']
        root = REPO / '.lake/packages' / name
        root.mkdir(parents=True, exist_ok=True)
        existing = object_hashes(root)
        item = {'package': name, 'expected_rev': rev, 'url': url,
                'surviving_artifact_sha256_before': existing, 'commands': []}
        summary['packages'].append(item)
        print('DEPENDENCY_RESTORE_START ' + json.dumps({'package': name, 'rev': rev,
              'surviving_artifact_parts': len(existing)}), flush=True)
        log = LOGS / (name + '.log')
        started = time.monotonic()
        with log.open('w') as handle:
            def run(args):
                command = ['git', '--no-optional-locks', '-C', str(root), *args]
                handle.write(json.dumps({'command': command}) + '\n')
                handle.flush()
                completed = subprocess.run(command, capture_output=True, text=True)
                handle.write(completed.stdout)
                handle.write(completed.stderr)
                handle.flush()
                item['commands'].append({'command': command, 'returncode': completed.returncode})
                save()
                if completed.returncode != 0:
                    raise RuntimeError('Exact dependency restore command failed: ' + name)
                return completed.stdout.strip()
            if not (root / '.git').exists():
                run(['init', '--quiet'])
                run(['remote', 'add', 'origin', url])
            else:
                origin = run(['remote', 'get-url', 'origin'])
                if origin != url:
                    raise RuntimeError('Dependency origin differs from manifest: ' + name)
            current = subprocess.run(['git', '--no-optional-locks', '-C', str(root),
                                      'rev-parse', '--verify', 'HEAD'], capture_output=True, text=True)
            if current.returncode != 0 or current.stdout.strip() != rev:
                run(['fetch', '--depth=1', 'origin', rev])
                fetched = run(['rev-parse', 'FETCH_HEAD'])
                if fetched != rev:
                    raise RuntimeError('Fetched commit differs from exact manifest pin: ' + name)
                run(['-c', 'core.autocrlf=false', 'checkout', '--force', '--detach', rev])
            actual = run(['rev-parse', 'HEAD'])
            status = run(['status', '--porcelain', '--untracked-files=no'])
            if actual != rev or status:
                raise RuntimeError('Dependency source pin/status is not exact: ' + name)
            after = object_hashes(root)
            if existing != after:
                raise RuntimeError('A surviving dependency artifact changed: ' + name)
            item.update({'actual_head': actual, 'tracked_status': status,
                         'surviving_artifact_sha256_after': after,
                         'surviving_artifacts_unchanged': True,
                         'log': str(log), 'returncode': 0,
                         'elapsed_seconds': round(time.monotonic() - started, 3)})
            save()
            print('DEPENDENCY_RESTORE_OK ' + json.dumps({'package': name, 'rev': rev,
                  'elapsed_seconds': item['elapsed_seconds'], 'surviving_artifact_parts': len(after)}), flush=True)
    pins_after = {name: digest(REPO / name) for name in pins_before}
    if pins_before != pins_after:
        raise RuntimeError('A project pin/configuration file changed during recovery')
    summary['project_pin_sha256_after'] = pins_after
    summary['status'] = 'ALL_EXACT_PINS_RESTORED'
    summary['completed_utc'] = datetime.now(timezone.utc).isoformat()
    save()
    print('DEPENDENCIES_ALL_RESTORED ' + json.dumps({'result': str(result_file), 'count': len(packages)}), flush=True)

if __name__ == '__main__':
    main()
