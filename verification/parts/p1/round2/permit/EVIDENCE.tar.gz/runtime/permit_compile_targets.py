"""Compile the separate stored-cap permit milestone without changing round2's graph.

The original compileOne driver takes the same OS file lock as the ongoing
supplier worker.  Only one actual runFrontend body runs at a time.
"""
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
import json
import time
import traceback

import compile_driver as d

TARGETS = ['ImbalancedChen.StoredHistoricalBoxPermit',
    'verification.parts.p1.round2.permit.StoredCapProbe',
    'verification.parts.p1.round2.permit.StoredCapAudit']
ROOT = d.RUNTIME / 'logs/round2/permit'
ARCHIVE = d.BASE / 'p1-round2-recovered-evidence/runtime'
LOCAL_ROOTS = {d.REPO, d.REPO / '.lake/packages/goldbach', d.REPO / '.lake/packages/LeanArchitect'}
DRIVER_SHA256 = '062343a0b51ea248770a139e38e0069db53f73094de088da3e291a15cc0bf3a1'
LOCK = d.RUNTIME / 'logs/resource-adjustment-01/frontend.lock'


def read(path, fallback=None):
    return json.loads(path.read_text()) if path.exists() else fallback


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n')


def imports(module):
    return {dep: d.digest(d.olean(dep)) for dep in d.imports(module)}


def matches(module, record):
    return bool(record) and record.get('returncode') == 0 and record.get('trustLevel') == 0 \
        and not record.get('metadata_adapter') and d.olean(module).is_file() \
        and record['source_sha256_before'] == record['source_sha256_after'] == d.digest(d.INDEX[module][0]) \
        and record.get('olean_sha256') == d.digest(d.olean(module)) \
        and record.get('import_olean_sha256') == imports(module)


def source_plan():
    order = d.closure(TARGETS)
    local = [m for m in order if d.INDEX[m][1] in LOCAL_ROOTS]
    cached = [m for m in order if d.INDEX[m][1] not in LOCAL_ROOTS]
    return {'targets': TARGETS, 'source_order': order, 'local_modules': local,
        'cached_modules': cached, 'source_module_count': len(order),
        'local_module_count': len(local), 'cached_module_count': len(cached),
        'target_source_sha256': {m: d.digest(d.INDEX[m][0]) for m in TARGETS},
        'shared_global_lock': str(LOCK), 'actual_frontend_bodies_active_at_once': 1,
        'round2_four_target_graph_modified': False}


def main():
    folder = ROOT / 'compile'
    attempt = folder / ('attempt-' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'))
    attempt.mkdir(parents=True)
    started = time.monotonic()
    result = {'status': 'RUNNING', 'returncode': None, 'targets': TARGETS,
        'attempt': str(attempt), 'new_target_records': {}, 'complete_local_modules': 0}

    def save():
        write(attempt / 'result.json', result)
        write(folder / 'result.json', result)

    save()
    try:
        if d.digest(d.RUNTIME / 'frontend-driver/lakefile.lean') != DRIVER_SHA256:
            raise RuntimeError('The original serialized frontend driver changed')
        plan = source_plan()
        write(attempt / 'plan.json', plan)
        write(folder / 'plan.json', plan)
        cache = read(d.RUNTIME / 'logs/round2/cache/result.json')
        cache_plan = read(Path(cache['attempt']) / 'source-plan.json') if cache else None
        if not cache or not cache.get('verified') or cache.get('returncode') != 0:
            raise RuntimeError('The official source cache has not been restored successfully')
        if not set(plan['cached_modules']) <= set(cache_plan['cached_modules']):
            raise RuntimeError('The permit needs official cached modules outside the restored closure')
        if any(not d.olean(module).is_file() for module in plan['cached_modules']):
            raise RuntimeError('A required permit cached object is missing')
        prior = read(ARCHIVE / 'logs/closure/state.json')
        state = read(folder / 'state.json', {})
        # Do all supplier checks before entering the compile loop.  This milestone
        # never starts extra supplier compilation or extends the main graph.
        for module in plan['local_modules']:
            if module not in TARGETS and not matches(module, prior.get(module)):
                raise RuntimeError('A permit supplier lacks matching archived source/object/import evidence: ' + module)
        result.update({'plan_sha256': d.digest(attempt / 'plan.json'),
            'source_module_count': plan['source_module_count'],
            'local_module_count': plan['local_module_count'],
            'cached_module_count': plan['cached_module_count'],
            'shared_global_lock': str(LOCK), 'driver_sha256': DRIVER_SHA256})
        save()
        print('PERMIT_COMPILE_START ' + json.dumps(result), flush=True)
        counts = Counter()
        for module in plan['local_modules']:
            if module not in TARGETS:
                old = prior[module]
                record = {**old, 'origin': 'ARCHIVED_FIRST_ROUND_ACTUAL_COMPILATION',
                    'compiled_in_permit': False,
                    'archived_raw_log': str(ARCHIVE / Path(old['log']).relative_to(d.RUNTIME))}
                outcome = 'REUSED_ARCHIVED_SUCCESS'
            elif matches(module, state.get(module)) and state[module].get('strict') \
                    and state[module].get('compiled_in_permit'):
                record = state[module]
                outcome = 'REUSED_CURRENT_PERMIT_SUCCESS'
            else:
                snapshot = attempt / 'target-sources' / (module + '.lean')
                snapshot.parent.mkdir(parents=True, exist_ok=True)
                snapshot.write_bytes(d.INDEX[module][0].read_bytes())
                before_imports = imports(module)
                print('PERMIT_TARGET_START ' + module, flush=True)
                record = d.compile_module(module, attempt / 'modules', strict=True, metadata=False)
                record.update({'origin': 'CURRENT_PERMIT_ACTUAL_COMPILATION',
                    'compiled_in_permit': True, 'import_olean_sha256': before_imports})
                if not matches(module, record):
                    raise RuntimeError('Permit imports changed during actual compilation: ' + module)
                outcome = 'COMPILED_CURRENT_PERMIT'
                print('PERMIT_TARGET_OK ' + json.dumps(record), flush=True)
            state[module] = record
            write(folder / 'state.json', state)
            counts[outcome] += 1
            result['complete_local_modules'] += 1
            with (attempt / 'events.jsonl').open('a') as handle:
                handle.write(json.dumps({'module': module, 'outcome': outcome}) + '\n')
        for module in TARGETS:
            record = state[module]
            if not record.get('compiled_in_permit') or not record['strict'] or not matches(module, record):
                raise RuntimeError('A permit target lacks current actual strict compilation: ' + module)
        result.update({'status': 'SUCCEEDED', 'returncode': 0,
            'new_target_records': {m: state[m] for m in TARGETS},
            'outcome_counts': dict(counts), 'trustLevel': 0, 'strict_targets': TARGETS,
            'metadata_adapter': False, 'elapsed_seconds': round(time.monotonic() - started, 3)})
        save()
        print('PERMIT_COMPILE_RESULT ' + json.dumps(result), flush=True)
    except (Exception, KeyboardInterrupt) as error:
        result.update({'status': 'FAILED', 'returncode': 130 if isinstance(error, KeyboardInterrupt) else 1,
            'error_type': type(error).__name__, 'error': str(error),
            'failed_module': module if 'module' in locals() else None,
            'elapsed_seconds': round(time.monotonic() - started, 3)})
        save()
        traceback.print_exc()
        print('PERMIT_COMPILE_FAILED ' + json.dumps(result), flush=True)
        raise SystemExit(result['returncode'])


if __name__ == '__main__':
    main()
