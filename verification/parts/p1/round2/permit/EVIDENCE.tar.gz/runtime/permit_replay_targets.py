"""Three original checker calls under the existing frontend resource lock.

The lock controls scheduling only.  Checker executable, arguments, inputs and
default selected-module replay semantics are unchanged.
"""
from datetime import datetime, timezone
from pathlib import Path
import fcntl
import json
import re
import subprocess
import time
import traceback

import compile_driver as d
from permit_compile_targets import TARGETS, ROOT, LOCK, matches, read, write, imports

CHECKER_SHA256 = 'ed46f21c763051c26f89481096cbaaf5db9665d674d602e3daf3391613ba0e6a'
CHECKER_SOURCE_SHA256 = 'eb5dee411837629f09c5c18d63cc833d30335a46048bc586642742e90aa65d5f'
LOCK_SOURCE_SHA256 = '7dd91cc0c7ebd7a1ed69ac9b870634b6ae251f28e96ba54384b5ba6e8ce20efd'


def parts(module):
    output = d.olean(module)
    return {p.name: d.digest(p) for p in sorted(output.parent.glob(output.name + '*')) if p.is_file()}


def main():
    folder = ROOT / 'replay'
    attempt = folder / ('attempt-' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'))
    attempt.mkdir(parents=True)
    started = time.monotonic()
    result = {'status': 'RUNNING', 'verified': False, 'returncode': None,
        'attempt': str(attempt), 'expected_targets': TARGETS, 'calls': []}

    def save():
        write(attempt / 'result.json', result)
        write(folder / 'result.json', result)

    save()
    try:
        compilation = read(ROOT / 'compile/result.json')
        state = read(ROOT / 'compile/state.json')
        if compilation.get('status') != 'SUCCEEDED' or compilation.get('returncode') != 0 \
                or compilation.get('targets') != TARGETS:
            raise RuntimeError('The current permit compilation has not succeeded')
        for module in TARGETS:
            record = state[module]
            if not matches(module, record) or not record['strict'] \
                    or not record.get('compiled_in_permit') \
                    or record.get('origin') != 'CURRENT_PERMIT_ACTUAL_COMPILATION':
                raise RuntimeError('A permit target lacks current actual strict compilation: ' + module)
        checker = d.TOOLROOT / 'bin/leanchecker'
        checker_source = d.TOOLROOT / 'src/lean/LeanChecker.lean'
        lock_source = d.RUNTIME / 'recovery/official-io-lock.cpp'
        if d.digest(checker) != CHECKER_SHA256 or d.digest(checker_source) != CHECKER_SOURCE_SHA256 \
                or d.digest(lock_source) != LOCK_SOURCE_SHA256:
            raise RuntimeError('An original checker or recorded scheduling source changed')
        environment = d.environment(False)
        environment['LEAN_NUM_THREADS'] = '1'
        commands = [[str(checker), '--verbose', module] for module in TARGETS]
        log = attempt / 'three-targets.log'
        semantics = {'source_path': str(checker_source), 'source_sha256': CHECKER_SOURCE_SHA256,
            'source_permalink': 'https://github.com/leanprover/lean4/blob/62eed1db4d67327ec8120be05f1a1b0847d74561/src/LeanChecker.lean',
            'functions': ['replayFromImports', 'main'], 'fresh_flag': False,
            'coverage': 'Declarations defined by the three selected permit modules, including their most-private data parts; imported dependencies are loaded, not fully replayed.'}
        locking = {'path': str(LOCK), 'method': 'Python fcntl.flock LOCK_EX on the existing file',
            'compatibility_source': str(lock_source), 'compatibility_source_sha256': LOCK_SOURCE_SHA256,
            'compatibility_source_url': 'https://raw.githubusercontent.com/leanprover/lean4/62eed1db4d67327ec8120be05f1a1b0847d74561/src/runtime/io.cpp',
            'compatibility_reason': 'The unchanged Linux Lean Handle.lock implementation calls flock(fd, LOCK_EX).',
            'scope': 'All three sequential checker calls share one lock lease, mutually exclusive with actual runFrontend bodies.',
            'requested_utc': datetime.now(timezone.utc).isoformat()}
        result.update({'commands': commands, 'semantics': semantics, 'scheduling': locking,
            'log': str(log), 'original_leanchecker_sha256': CHECKER_SHA256,
            'LEAN_NUM_THREADS': '1', 'metadata_adapter': False,
            'compile_result_sha256': d.digest(ROOT / 'compile/result.json'),
            'compile_state_sha256': d.digest(ROOT / 'compile/state.json')})
        save()
        print('PERMIT_REPLAY_WAIT_LOCK ' + json.dumps(locking), flush=True)
        with LOCK.open('a') as lock_handle:
            fcntl.flock(lock_handle, fcntl.LOCK_EX)
            locking['acquired_utc'] = datetime.now(timezone.utc).isoformat()
            try:
                print('PERMIT_REPLAY_SERIAL_BEGIN ' + json.dumps(locking), flush=True)
                for module in TARGETS:
                    if not matches(module, state[module]):
                        raise RuntimeError('A permit input changed while waiting for the lock: ' + module)
                source_before = {m: d.digest(d.INDEX[m][0]) for m in TARGETS}
                parts_before = {m: parts(m) for m in TARGETS}
                imports_before = {m: imports(m) for m in TARGETS}
                result.update({'source_sha256_before': source_before,
                    'artifacts_sha256_before': parts_before,
                    'direct_import_olean_sha256_before': imports_before})
                save()
                with log.open('w') as aggregate:
                    aggregate.write(json.dumps({'commands': commands, 'source_sha256': source_before,
                        'artifacts_sha256_before': parts_before,
                        'direct_import_olean_sha256_before': imports_before,
                        'LEAN_NUM_THREADS': '1', 'metadata_adapter': False, 'scheduling': locking,
                        'checker_source_sha256': CHECKER_SOURCE_SHA256}) + '\n')
                    aggregate.flush()
                    for module, command in zip(TARGETS, commands):
                        raw_path = attempt / (module + '.log')
                        call_started = time.monotonic()
                        call_started_utc = datetime.now(timezone.utc).isoformat()
                        print('PERMIT_REPLAY_MODULE_START ' + module, flush=True)
                        with raw_path.open('w') as handle:
                            handle.write(json.dumps({'module': module, 'command': command,
                                'source_sha256': source_before[module],
                                'artifacts_sha256_before': parts_before[module],
                                'direct_import_olean_sha256_before': imports_before[module],
                                'LEAN_NUM_THREADS': '1', 'metadata_adapter': False,
                                'shared_lock_held': str(LOCK), 'started_utc': call_started_utc}) + '\n')
                            handle.flush()
                            completed = subprocess.run(command, cwd=d.REPO, env=environment,
                                stdout=handle, stderr=subprocess.STDOUT)
                        raw = raw_path.read_text()
                        observed = re.findall(r'^replaying (\S+)\s*$', raw, re.MULTILINE)
                        call = {'module': module, 'command': command, 'returncode': completed.returncode,
                            'started_utc': call_started_utc, 'finished_utc': datetime.now(timezone.utc).isoformat(),
                            'elapsed_seconds': round(time.monotonic() - call_started, 3),
                            'log': str(raw_path), 'log_sha256': d.digest(raw_path),
                            'observed_replay_lines': observed,
                            'verified': completed.returncode == 0 and observed == [module]}
                        result['calls'].append(call)
                        aggregate.write(raw)
                        aggregate.write('PERMIT_REPLAY_MODULE_RESULT ' + json.dumps(call) + '\n')
                        aggregate.flush()
                        save()
                        print('PERMIT_REPLAY_MODULE_RESULT ' + json.dumps(call), flush=True)
                        if not call['verified']:
                            break
                source_after = {m: d.digest(d.INDEX[m][0]) for m in TARGETS}
                parts_after = {m: parts(m) for m in TARGETS}
                imports_after = {m: imports(m) for m in TARGETS}
                result.update({'source_sha256_after': source_after,
                    'artifacts_sha256_after': parts_after,
                    'direct_import_olean_sha256_after': imports_after})
            finally:
                locking['released_utc'] = datetime.now(timezone.utc).isoformat()
                fcntl.flock(lock_handle, fcntl.LOCK_UN)
        observed = re.findall(r'^replaying (\S+)\s*$', log.read_text(), re.MULTILINE)
        verified = len(result['calls']) == len(TARGETS) and all(c['verified'] for c in result['calls']) \
            and observed == TARGETS and source_before == source_after \
            and parts_before == parts_after and imports_before == imports_after
        code = next((c['returncode'] or 1 for c in result['calls'] if not c['verified']), 1)
        result.update({'status': 'SUCCEEDED' if verified else 'FAILED', 'verified': verified,
            'returncode': 0 if verified else code, 'observed_replay_lines': observed,
            'log_sha256': d.digest(log), 'elapsed_seconds': round(time.monotonic() - started, 3)})
        save()
        print('PERMIT_REPLAY_RESULT ' + json.dumps(result), flush=True)
        if not verified:
            raise SystemExit(result['returncode'])
    except (Exception, KeyboardInterrupt) as error:
        result.update({'status': 'FAILED', 'verified': False,
            'returncode': 130 if isinstance(error, KeyboardInterrupt) else 1,
            'error_type': type(error).__name__, 'error': str(error),
            'elapsed_seconds': round(time.monotonic() - started, 3)})
        save()
        traceback.print_exc()
        raise SystemExit(result['returncode'])


if __name__ == '__main__':
    main()
