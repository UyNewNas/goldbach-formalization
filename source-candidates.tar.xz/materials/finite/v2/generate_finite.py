"""Freeze Cell06 finite SOURCE_CANDIDATE owners; never execute Lean."""
from fractions import Fraction
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
REPO = Path('/workspace/p26-proof-continuation-20261127')
RAW = Path('/workspace/goldbach-research')
GNAME = 'eighth-third-minorant-extension-20261009-a23-s23_low-06-cell.witness.json'
MNAME = 'eighth-third-moment-refinement-20261009-a23-low-06.witness.json'
EXPECTED = {
    GNAME: (335849, '377bbf9f0c96cfd537e34072b7e283760b3f44f3b4a7d55f47fa4c7a95517e9b'),
    MNAME: (58376, '7654ebb59737bd765340a9edbd3984a4a72fe0f5b4cd9bf8f42266d7a7e724e9'),
}
TEMPLATE = REPO / 'ImbalancedChen/P2OriginalSaving19Cell01Row001Finite.lean'
PURE_HELPER = REPO / 'tools/p26/generate_cell01_row000_pilot.py'
spec = importlib.util.spec_from_file_location('existing_p26_pure_literals', PURE_HELPER)
pure = importlib.util.module_from_spec(spec)
spec.loader.exec_module(pure)


def pin(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def load_inputs():
    parsed, pins = [], []
    for name in [GNAME, MNAME]:
        path = RAW / name
        info = pin(path)
        assert (info['bytes'], info['sha256']) == EXPECTED[name]
        data = path.read_bytes()
        assert data.endswith(b'\r\n') and data.isascii()
        parsed.append(json.loads(data))
        pins.append(info)
    geometry, moments = parsed
    assert len(geometry['vertices']) == 33
    assert len(geometry['simplices']) == len(moments['records']) == 113
    assert geometry['dimension'] == moments['dimension'] == 8
    assert moments['cell_id'] == 6 and moments['source_witness'] == GNAME
    assert (moments['log_degree'], moments['exp_degree']) == (6, 3)
    assert int(moments['log_floor_denominator']) == 2**80
    assert int(moments['final_floor_denominator']) == 2**96
    for r, (row, record) in enumerate(zip(geometry['simplices'], moments['records'])):
        assert row['simplex_id'] == record['simplex_id'] == r
        ids = row['vertex_ids']
        assert len(ids) == len(set(ids)) == 9 and all(0 <= v < 33 for v in ids)
        assert len(row['factor_maxima']) == len(row['gap_weighted_means']) == 10
        assert len(record['log_gap_factor_floors_Q80']) == 10
    return geometry, moments, pins


def compute_literals(geometry, moments, r):
    row, record = geometry['simplices'][r], moments['records'][r]
    assert row['simplex_id'] == record['simplex_id'] == r
    vertices = [[Fraction(x) for x in geometry['vertices'][v]] for v in row['vertex_ids']]
    gaps = [pure.new_cap(v) - pure.comparison(v) for v in vertices]
    tops = list(map(Fraction, row['factor_maxima']))
    deviations = [[1 - pure.factors(v)[j] / tops[j] for v in vertices] for j in range(10)]
    scale = math.lcm(*(q.denominator for q in gaps))
    g = [int(q * scale) for q in gaps]
    d = [math.lcm(*(q.denominator for q in ds)) for ds in deviations]
    z = [[int(q * denominator) for q in ds] for ds, denominator in zip(deviations, d)]
    assert scale > 0 and sum(g) > 0 and all(x >= 0 for x in g)
    assert all(denominator > 0 for denominator in d)
    assert all(x >= 0 for zs in z for x in zs)
    values = []
    for zs, denominator in zip(z, d):
        table = pure.host_prefix(zs)
        values.append([Fraction(sum(table[k-q] * sum(a * y**q for a, y in zip(g, zs))
                                    for q in range(k+1)),
                                sum(g) * math.comb(9+k, k) * denominator**k)
                       for k in range(1, 7)])
    gap_values = [sum((ms[k-1] - ms[0]**k) / k for k in range(2, 7)) for ms in values]
    floors = [math.floor(q * 2**80) for q in gap_values]
    assert floors == list(map(int, record['log_gap_factor_floors_Q80']))
    means = list(map(Fraction, row['gap_weighted_means']))
    old_evaluator = 4 * Fraction(row['physical_volume']) * Fraction(row['mean_gap']) / math.prod(means)
    assert old_evaluator == Fraction(row['jensen_bound'])
    old_q96 = math.floor(old_evaluator * 2**96)
    assert old_q96 == int(record['old_floor_Q96'])
    saved_total = sum(floors)
    total = Fraction(saved_total, 2**80)
    uncapped_new = math.floor(old_evaluator * (1 + total * (1 + total * (Fraction(1, 2) + total/6))) * 2**96)
    assert max(old_q96, uncapped_new) == int(record['new_floor_Q96'])
    return {'row': r, 'vertex_ids': row['vertex_ids'], 'gap_scale': scale, 'gap_nats': g,
            'deviation_denominators': d, 'deviation_nats': z, 'moments': values,
            'gap_values': gap_values, 'saved_total': saved_total,
            'old_q96': old_q96, 'uncapped_new_q96': uncapped_new}


def once(text, pattern, replacement):
    assert len(list(re.finditer(pattern, text, flags=re.S))) == 1, pattern
    return re.sub(pattern, replacement, text, flags=re.S)


def render(template, value):
    r = value['row']
    text = template.replace('P2OriginalSaving19Cell01Row001', f'P2OriginalSaving19Cell06Row{r:03d}')
    text = text.replace('P26_CELL01_ROW001', f'P26_CELL06_ROW{r:03d}')
    text = text.replace('open P2OriginalSaving19Geometry01Decoding\n'
                        'open P2OriginalSaving19Geometry01DirectDecoding\n',
                        'open P2OriginalSaving19Geometry06ScalableDecoding\n'
                        'open P2OriginalSaving19Geometry06ScalableDecoding.Complete\n')
    text = text.replace('Geometry01', 'Geometry06').replace('Moment01', 'Moment06')
    text = text.replace('concreteGeometry01', 'concreteGeometry06').replace('momentConcrete01', 'momentConcrete06')
    text = text.replace('(1 : Fin 144)', f'({r} : Fin 113)')
    assert 'Fin 144' not in text
    text = text.replace('concreteGeometry06.rows[1]!', f'concreteGeometry06.rows[{r}]!')
    text = text.replace('momentConcrete06.rows[1]!', f'momentConcrete06.rows[{r}]!')
    text = text.replace('P2OriginalSaving19Moment06Shape.row_bound 1)',
                        f'P2OriginalSaving19Moment06Shape.row_bound {r})')
    assert text.count('geometryRowsTyped001') == text.count('momentTypedRecord001') == 1
    text = text.replace('geometryRowsTyped001', f'geometryRowsTyped{r:03d}')
    text = text.replace('momentTypedRecord001', f'momentTypedRecord{r:03d}')
    vertices = 'noncomputable def vertices : Fin 9 → QPoint :=\n  !['
    vertices += ',\n    '.join(f'(fun j => geometryVerticesTyped{v:03d}[j.val]!)' for v in value['vertex_ids'])
    vertices += ']\n\n'
    text = once(text, r'noncomputable def vertices : Fin 9 → QPoint :=.*?\n\n', lambda _: vertices)
    encoding = f"def gapScale : Nat := {value['gap_scale']}\n\n"
    encoding += f"def gapNats : Fin 9 → Nat := {pure.vec(value['gap_nats'])}\n\n"
    encoding += f"def deviationDenominators : Fin 10 → Nat := {pure.vec(value['deviation_denominators'])}\n\n"
    encoding += 'def deviationNats : Fin 10 → Fin 9 → Nat :=\n  !['
    encoding += ',\n    '.join(pure.vec(zs) for zs in value['deviation_nats']) + ']\n\n'
    text = once(text, r'def gapScale : Nat :=.*?(?=def prefixMoment)', lambda _: encoding)
    for j in range(10):
        for k, q in enumerate(value['moments'][j], 1):
            pattern = rf'(theorem factor{j:02d}_moment{k} : prefixMoment \({j} : Fin 10\) {k} = ).*?( := by)'
            text = once(text, pattern, lambda m, q=q: m[1] + pure.rat(q) + m[2])
        pattern = rf'(theorem factor{j:02d}_gap_value :\s*gapEvaluator \(prefixMoment \({j} : Fin 10\)\) = ).*?( := by)'
        text = once(text, pattern, lambda m, j=j: m[1] + pure.rat(value['gap_values'][j]) + m[2])
    prior_total = re.search(r'theorem total_Q80_value :\s*totalLowerQ80 prefixMoment = \((\d+) : ℚ\)', text)[1]
    assert text.count(prior_total) == 2
    text = text.replace(prior_total, str(value['saved_total']))
    text = once(text, r'(theorem new_Q96_value :\s*newFloorQ96 \(massOf row\) \(meansOf row\) prefixMoment = )\d+( := by)',
                lambda m: m[1] + str(value['uncapped_new_q96']) + m[2])
    text = text.replace('Cell01 row 1', f'Cell06 row {r}').replace('cell01 row1', f'cell06 row{r}')
    text = text.replace('cell01 owner', 'cell06 owner')
    text = text.replace('actual original row 1 ', f'actual original row {r} ')
    text = text.replace('Twenty-one accepted row000 source bodies', 'Twenty-one existing donor source bodies')
    text = text.replace('moment row1', f'moment row{r}').replace('geometry row1', f'geometry row{r}')
    return text


def code_body(text):
    return re.sub(r'--[^\n]*', '', re.sub(r'/\-.*?\-/', '', text, flags=re.S))


def main():
    geometry, moments, inputs = load_inputs()
    frozen = [pin(TEMPLATE), pin(PURE_HELPER)] + inputs
    template = TEMPLATE.read_text()
    expected_theorems = re.findall(r'^theorem (\w+)', template, re.M)
    expected_sections = re.findall(r'^-- BEGIN DONOR (\w+)', template, re.M)
    assert len(expected_theorems) == 148 and len(expected_sections) == 21
    output = ROOT / 'project/ImbalancedChen'
    output.mkdir(parents=True, exist_ok=False)
    generated = []
    for r in range(113):
        value = compute_literals(geometry, moments, r)
        text = render(template, value)
        body = code_body(text)
        assert not re.search(r'\b(?:axiom|sorry|admit|native_decide|unsafe)\b', body)
        assert not re.search(r'(?:Cell01|CELL01|Geometry01|Moment01|Fin 144)', body)
        assert re.findall(r'^theorem (\w+)', text, re.M) == expected_theorems
        assert re.findall(r'^-- BEGIN DONOR (\w+)', text, re.M) == expected_sections
        assert re.findall(r'^-- END DONOR (\w+)', text, re.M) == expected_sections
        assert body.count('theorem saved_new_Q96_max :') == 1
        assert body.count(f'geometryRowsTyped{r:03d}') == 1
        assert body.count(f'momentTypedRecord{r:03d}') == 1
        name = f'P2OriginalSaving19Cell06Row{r:03d}Finite'
        path = output / (name + '.lean')
        with path.open('x') as f: f.write(text)
        generated.append({'module': 'ImbalancedChen.' + name, 'source': pin(path), 'row': r,
                          'vertex_ids': value['vertex_ids'], 'imports': re.findall(r'^import ([\w.]+)', text, re.M),
                          'theorems': expected_theorems, 'status': 'source_candidate_not_compiled'})
    for info in frozen: assert pin(Path(info['path'])) == info
    manifest = {'schema': 'p26_cell06_finite_source_candidate_v1', 'candidate_revision': 2,
                'prior_source_candidate': pin(ROOT.parent / 'SOURCE_MANIFEST.json'), 'formal_acceptance': False,
                'P2_6_complete': False, 'degree': 6, 'exp_degree': 3,
                'raw_inputs': inputs, 'read_only_templates': frozen[:2],
                'generator_source': pin(Path(__file__)), 'original_rows': 113,
                'original_vertices': 33, 'generated': generated,
                'normal_builds': 0, 'kernel_checks': 0, 'full_owned_audits': 0,
                'missing_prerequisites': ['actual Cell06 geometry/moment acceptance',
                                          'Geometry06BoundedAccess candidate and acceptance'],
                'saved_max_old_new_retained': True, 'host_literal_consistency_only': True}
    with (ROOT / 'SOURCE_MANIFEST.json').open('x') as f:
        json.dump(manifest, f, indent=2); f.write('\n')
    print(json.dumps({'source_candidates': len(generated), 'formal_acceptance': False,
                      'manifest': str(ROOT / 'SOURCE_MANIFEST.json')}))


if __name__ == '__main__':
    main()
