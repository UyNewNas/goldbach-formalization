"""Host candidate regression only; no Lean proof credit."""
import unittest
from fractions import Fraction

import generate_finite as gen


class OriginalLiteralRegression(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.geometry, cls.moments, _ = gen.load_inputs()

    def test_original_zero_endpoint(self):
        value = gen.compute_literals(self.geometry, self.moments, 0)
        self.assertEqual(value['vertex_ids'], [32, 20, 6, 5, 4, 3, 2, 1, 0])
        self.assertEqual(value['gap_scale'], 4307213680000000)
        self.assertEqual(value['gap_nats'], [0, 0, 28731231537470, 29341716223820,
                                           28167259970080, 29341716223820,
                                           29073633818075, 28838377829360,
                                           28444858720964])
        self.assertEqual(value['saved_total'], 1044785129804146077745)
        self.assertEqual(value['old_q96'], 6678443759985)
        self.assertEqual(value['uncapped_new_q96'], 6684217939485)

    def test_original_last_endpoint(self):
        value = gen.compute_literals(self.geometry, self.moments, 112)
        self.assertEqual(value['vertex_ids'], [32, 31, 19, 17, 16, 14, 12, 11, 7])
        self.assertEqual(value['gap_scale'], 88000000)
        self.assertEqual(value['gap_nats'], [0] * 8 + [546807])
        self.assertEqual(value['saved_total'], 3945650625330349155445)
        self.assertEqual(value['old_q96'], 21332090180324)
        self.assertEqual(value['uncapped_new_q96'], 21401826864684)

    def test_every_original_record_rejects_inconsistent_saved_fields(self):
        # The original fields, not another renderer's output, are the oracle.
        for r in range(113):
            value = gen.compute_literals(self.geometry, self.moments, r)
            self.assertEqual(value['row'], r)
            self.assertEqual(max(value['old_q96'], value['uncapped_new_q96']),
                             int(self.moments['records'][r]['new_floor_Q96']))
            self.assertEqual(len(value['moments']), 10)
            self.assertTrue(all(len(ms) == 6 for ms in value['moments']))
            self.assertTrue(all(isinstance(q, Fraction) for ms in value['moments'] for q in ms))


if __name__ == '__main__':
    unittest.main()
