# Moment06 原始解析/解码源候选

状态：`SOURCE_CANDIDATE_HOST_CHECKED_NOT_COMPILED`。`formal_acceptance:false`，`P2_6_complete:false`。

v3静态header修正：v2全部保留；仅将65个新源import前新增的`/-!`模块文档标记改为普通`/-`注释，旧Data06源字节不变。Host检查66源的第一个实际command均为import，并逐源验证v2→v3只有上述一字节差异。这是静态发现后的源候选修正，未运行Lean。

已生成66个Lean源：65个新Moment06目标和1个逐字复制的旧ArchiveMomentData06源。旧Data06恢复对象仅在manifest记录其pin；未复制或重新编译该对象，恢复对象的当前context qualification仍未验证。

原输入58376bytes、113records，SHA256 `7654ebb59737bd765340a9edbd3984a4a72fe0f5b4cd9bf8f42266d7a7e724e9`。完整原件按字节复制到 `goldbach-research/eighth-third-moment-refinement-20261009-a23-low-06.witness.json`，保留CRLF，使未来以本目录 `project` 为cwd时原loader相对路径有效。没有改动原JSON。

parser和typed-list各29块；Block000..027各四行，Block028仅row112。末块没有padding，没有四行整块断言。parser singleton append-normalization使用rfl。metadata采用现有Moment05的已清理simp结构。最终parse/bind复用原MomentParseDecodeBridge；reader、decoder、helper、Q80/Q96、degree6/expdegree3定义未改。

Host检查已通过：66源和65新目标的exact模块集合、全DAG、113个raw span及原AST tokens、113条typed record全部decimal tokens、整文件字节重建、末块消耗原数组关闭符、metadata分母/次数/行界，以及禁止sorry/admit/native_decide/newaxiom/unsafe。原件/模板/恢复源与对象的pin在生成前后核对。没有执行Fraction算术replay。

原始root need162、records need151，root结束58374、array结束58371；parseChars初始fuel58377，通用root实例58215。这些都是host候选plan，尚非Lean证明。

入口：`python -B generate_moment06_v3.py --check-only`只读重建内存候选并核对现有artifact；所有初次输出均为exclusive-create，默认再执行生成会拒绝替换现有manifest。所有实际写入只发生本隔离目录。生成器从实际归档中选择函数定义，不执行旧初始化器、旧main或旧save。

完整清单：`MANIFEST.json`。Lean新目标顺序：manifest的 `new_compile_targets_topological`（65项）；`normal_compile_excluded_modules`列出已恢复Data06，禁止旧normal重编。已有公共供应者仅pin源码，没有移植或伪造其接受context。8个项目supplier源位于清单中。

未验证事项：

- 65个新目标的Lean语法、elaboration、每条原parser/decoder等式、全部shape和lookup定理均未编译。
- 未运行独立leanchecker或完整owned/environment/private/generated声明审计；未产生任何新olean或编译信用。
- 旧Data06 exact object/source尚需在实际当前accepted context中qualification；本源候选不授予它新接受信用。
- 保存Q80/Q96有限算术正确性、Geometry06、Archive aliases、OriginalFloorTransport及积分终点均不由本候选认证。
