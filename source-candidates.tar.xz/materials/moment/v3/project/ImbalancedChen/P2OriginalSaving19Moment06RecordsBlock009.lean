/- SOURCE_CANDIDATE: original Cell06 source only. No Lean compilation,
independent kernel replay, full-owned audit or formal acceptance is claimed. -/

import ImbalancedChen.P2OriginalSaving19Moment06RecordsBlock008

/-! Original moment records block 9. Small arbitrary-tail/accumulator parser equations and one exact packed-input binding.
Candidate quotations preserve exact original raw bytes. The Lean equations bind
them to the production-compatible packed input and run the unchanged reader.
This local input resolves inside this private project, not the P1 filesystem. -/
namespace ImbalancedChen.P2OriginalSaving19Moment06Parsing
set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false
open ImbalancedChen.P2OriginalSaving19Archive

noncomputable def momentRecordsChunk036Chars : List Char := ['\r', '\n', ' ', ' ', ' ', ' ', '{', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 's', 'i', 'm', 'p', 'l', 'e', 'x', '_', 'i', 'd', '"', ':', ' ', '3', '6', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'l', 'o', 'g', '_', 'g', 'a', 'p', '_', 'f', 'a', 'c', 't', 'o', 'r', '_', 'f', 'l', 'o', 'o', 'r', 's', '_', 'Q', '8', '0', '"', ':', ' ', '[', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '7', '5', '8', '4', '7', '1', '1', '2', '6', '4', '6', '3', '3', '8', '9', '1', '9', '7', '6', '5', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '3', '0', '6', '0', '0', '0', '5', '2', '5', '4', '8', '0', '2', '1', '4', '3', '8', '9', '4', '4', '5', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '3', '2', '1', '2', '0', '5', '8', '1', '0', '9', '1', '7', '4', '1', '7', '9', '7', '5', '6', '6', '5', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '1', '7', '8', '7', '6', '8', '4', '9', '8', '3', '7', '6', '8', '0', '5', '5', '7', '8', '2', '5', '9', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '1', '3', '9', '9', '9', '1', '8', '8', '4', '8', '7', '8', '5', '2', '0', '2', '7', '1', '0', '7', '3', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '1', '7', '5', '6', '8', '0', '9', '6', '3', '7', '9', '9', '6', '1', '4', '1', '4', '6', '2', '0', '9', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '4', '5', '6', '6', '4', '0', '4', '4', '8', '7', '9', '4', '2', '1', '8', '4', '9', '2', '5', '2', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '1', '6', '5', '6', '4', '6', '1', '6', '6', '8', '4', '0', '3', '8', '1', '7', '6', '1', '0', '3', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '3', '9', '5', '6', '2', '5', '7', '6', '6', '4', '5', '7', '3', '6', '6', '6', '3', '2', '8', '4', '9', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '1', '4', '7', '7', '4', '6', '1', '9', '7', '1', '8', '2', '4', '7', '9', '0', '0', '1', '9', '4', '2', '"', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ']', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'o', 'l', 'd', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6', '"', ':', ' ', '"', '3', '9', '3', '9', '3', '4', '1', '6', '1', '0', '4', '3', '8', '1', '4', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'n', 'e', 'w', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6', '"', ':', ' ', '"', '3', '9', '4', '7', '1', '7', '9', '9', '9', '7', '7', '9', '5', '1', '6', '"', '\r', '\n', ' ', ' ', ' ', ' ', '}', ',']
noncomputable def momentRecordsChunk036Push (acc : List SourceJson) : List SourceJson :=
  (.obj [(String.ofList ['s', 'i', 'm', 'p', 'l', 'e', 'x', '_', 'i', 'd'], .number (String.ofList ['3', '6'])), (String.ofList ['l', 'o', 'g', '_', 'g', 'a', 'p', '_', 'f', 'a', 'c', 't', 'o', 'r', '_', 'f', 'l', 'o', 'o', 'r', 's', '_', 'Q', '8', '0'], .arr [.str (String.ofList ['2', '7', '5', '8', '4', '7', '1', '1', '2', '6', '4', '6', '3', '3', '8', '9', '1', '9', '7', '6', '5']), .str (String.ofList ['3', '0', '6', '0', '0', '0', '5', '2', '5', '4', '8', '0', '2', '1', '4', '3', '8', '9', '4', '4', '5']), .str (String.ofList ['3', '2', '1', '2', '0', '5', '8', '1', '0', '9', '1', '7', '4', '1', '7', '9', '7', '5', '6', '6', '5']), .str (String.ofList ['1', '7', '8', '7', '6', '8', '4', '9', '8', '3', '7', '6', '8', '0', '5', '5', '7', '8', '2', '5', '9']), .str (String.ofList ['1', '3', '9', '9', '9', '1', '8', '8', '4', '8', '7', '8', '5', '2', '0', '2', '7', '1', '0', '7', '3']), .str (String.ofList ['1', '7', '5', '6', '8', '0', '9', '6', '3', '7', '9', '9', '6', '1', '4', '1', '4', '6', '2', '0', '9']), .str (String.ofList ['2', '4', '5', '6', '6', '4', '0', '4', '4', '8', '7', '9', '4', '2', '1', '8', '4', '9', '2', '5', '2']), .str (String.ofList ['2', '1', '6', '5', '6', '4', '6', '1', '6', '6', '8', '4', '0', '3', '8', '1', '7', '6', '1', '0', '3']), .str (String.ofList ['3', '9', '5', '6', '2', '5', '7', '6', '6', '4', '5', '7', '3', '6', '6', '6', '3', '2', '8', '4', '9']), .str (String.ofList ['1', '4', '7', '7', '4', '6', '1', '9', '7', '1', '8', '2', '4', '7', '9', '0', '0', '1', '9', '4', '2'])]), (String.ofList ['o', 'l', 'd', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6'], .str (String.ofList ['3', '9', '3', '9', '3', '4', '1', '6', '1', '0', '4', '3', '8', '1', '4'])), (String.ofList ['n', 'e', 'w', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6'], .str (String.ofList ['3', '9', '4', '7', '1', '7', '9', '9', '9', '7', '7', '9', '5', '1', '6']))]) :: (acc)

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_chunk_036_before_generic"
  err.flush

theorem array_moment_records_chunk_036 (fuel : Nat) (tail : List Char) (acc : List SourceJson) :
    SourceJson.array (fuel + 114)
      (SourceJson.white (momentRecordsChunk036Chars ++ tail)) acc =
      SourceJson.array (fuel + 113) (SourceJson.white tail) (momentRecordsChunk036Push acc) := by rfl

noncomputable def momentRecordsAcc037 : List SourceJson := momentRecordsChunk036Push momentRecordsAcc036

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_chunk_036_generic_complete"
  err.flush

noncomputable def momentRecordsChunk037Chars : List Char := ['\r', '\n', ' ', ' ', ' ', ' ', '{', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 's', 'i', 'm', 'p', 'l', 'e', 'x', '_', 'i', 'd', '"', ':', ' ', '3', '7', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'l', 'o', 'g', '_', 'g', 'a', 'p', '_', 'f', 'a', 'c', 't', 'o', 'r', '_', 'f', 'l', 'o', 'o', 'r', 's', '_', 'Q', '8', '0', '"', ':', ' ', '[', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '4', '2', '3', '6', '9', '4', '0', '6', '7', '5', '6', '4', '6', '2', '2', '2', '3', '8', '2', '0', '7', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '3', '7', '6', '4', '2', '6', '1', '8', '4', '0', '2', '9', '9', '9', '6', '5', '4', '3', '6', '5', '3', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '3', '0', '0', '5', '5', '0', '4', '7', '0', '2', '8', '6', '3', '8', '1', '1', '7', '8', '0', '8', '0', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '6', '6', '3', '5', '4', '1', '8', '8', '2', '7', '9', '3', '0', '9', '0', '7', '4', '4', '2', '0', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '2', '0', '1', '2', '6', '1', '1', '7', '9', '5', '7', '6', '6', '4', '3', '0', '0', '4', '2', '3', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '4', '1', '6', '1', '9', '5', '9', '1', '9', '3', '4', '2', '1', '8', '2', '5', '8', '5', '0', '1', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '3', '9', '6', '3', '1', '7', '3', '0', '9', '5', '5', '7', '5', '3', '9', '4', '4', '5', '5', '6', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '0', '5', '3', '8', '4', '4', '2', '5', '7', '3', '1', '2', '3', '0', '5', '4', '4', '9', '3', '9', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '3', '9', '7', '4', '9', '6', '9', '5', '3', '2', '1', '7', '2', '4', '4', '8', '9', '8', '4', '0', '6', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '1', '9', '7', '6', '7', '3', '3', '8', '0', '0', '4', '9', '5', '1', '6', '9', '4', '4', '2', '8', '7', '"', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ']', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'o', 'l', 'd', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6', '"', ':', ' ', '"', '1', '0', '7', '6', '7', '2', '8', '4', '0', '3', '2', '4', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'n', 'e', 'w', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6', '"', ':', ' ', '"', '1', '0', '7', '9', '2', '8', '6', '6', '7', '0', '9', '9', '"', '\r', '\n', ' ', ' ', ' ', ' ', '}', ',']
noncomputable def momentRecordsChunk037Push (acc : List SourceJson) : List SourceJson :=
  (.obj [(String.ofList ['s', 'i', 'm', 'p', 'l', 'e', 'x', '_', 'i', 'd'], .number (String.ofList ['3', '7'])), (String.ofList ['l', 'o', 'g', '_', 'g', 'a', 'p', '_', 'f', 'a', 'c', 't', 'o', 'r', '_', 'f', 'l', 'o', 'o', 'r', 's', '_', 'Q', '8', '0'], .arr [.str (String.ofList ['4', '2', '3', '6', '9', '4', '0', '6', '7', '5', '6', '4', '6', '2', '2', '2', '3', '8', '2', '0', '7']), .str (String.ofList ['3', '7', '6', '4', '2', '6', '1', '8', '4', '0', '2', '9', '9', '9', '6', '5', '4', '3', '6', '5', '3']), .str (String.ofList ['3', '0', '0', '5', '5', '0', '4', '7', '0', '2', '8', '6', '3', '8', '1', '1', '7', '8', '0', '8', '0']), .str (String.ofList ['2', '6', '6', '3', '5', '4', '1', '8', '8', '2', '7', '9', '3', '0', '9', '0', '7', '4', '4', '2', '0']), .str (String.ofList ['2', '2', '0', '1', '2', '6', '1', '1', '7', '9', '5', '7', '6', '6', '4', '3', '0', '0', '4', '2', '3']), .str (String.ofList ['2', '4', '1', '6', '1', '9', '5', '9', '1', '9', '3', '4', '2', '1', '8', '2', '5', '8', '5', '0', '1']), .str (String.ofList ['2', '3', '9', '6', '3', '1', '7', '3', '0', '9', '5', '5', '7', '5', '3', '9', '4', '4', '5', '5', '6']), .str (String.ofList ['2', '0', '5', '3', '8', '4', '4', '2', '5', '7', '3', '1', '2', '3', '0', '5', '4', '4', '9', '3', '9']), .str (String.ofList ['3', '9', '7', '4', '9', '6', '9', '5', '3', '2', '1', '7', '2', '4', '4', '8', '9', '8', '4', '0', '6']), .str (String.ofList ['1', '9', '7', '6', '7', '3', '3', '8', '0', '0', '4', '9', '5', '1', '6', '9', '4', '4', '2', '8', '7'])]), (String.ofList ['o', 'l', 'd', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6'], .str (String.ofList ['1', '0', '7', '6', '7', '2', '8', '4', '0', '3', '2', '4'])), (String.ofList ['n', 'e', 'w', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6'], .str (String.ofList ['1', '0', '7', '9', '2', '8', '6', '6', '7', '0', '9', '9']))]) :: (acc)

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_chunk_037_before_generic"
  err.flush

theorem array_moment_records_chunk_037 (fuel : Nat) (tail : List Char) (acc : List SourceJson) :
    SourceJson.array (fuel + 113)
      (SourceJson.white (momentRecordsChunk037Chars ++ tail)) acc =
      SourceJson.array (fuel + 112) (SourceJson.white tail) (momentRecordsChunk037Push acc) := by rfl

noncomputable def momentRecordsAcc038 : List SourceJson := momentRecordsChunk037Push momentRecordsAcc037

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_chunk_037_generic_complete"
  err.flush

noncomputable def momentRecordsChunk038Chars : List Char := ['\r', '\n', ' ', ' ', ' ', ' ', '{', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 's', 'i', 'm', 'p', 'l', 'e', 'x', '_', 'i', 'd', '"', ':', ' ', '3', '8', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'l', 'o', 'g', '_', 'g', 'a', 'p', '_', 'f', 'a', 'c', 't', 'o', 'r', '_', 'f', 'l', 'o', 'o', 'r', 's', '_', 'Q', '8', '0', '"', ':', ' ', '[', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '4', '3', '0', '7', '4', '5', '4', '4', '0', '8', '8', '1', '4', '0', '2', '3', '9', '5', '2', '6', '2', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '3', '7', '4', '8', '3', '6', '5', '6', '2', '6', '6', '4', '9', '3', '9', '6', '0', '0', '9', '6', '5', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '7', '8', '2', '6', '2', '4', '5', '5', '9', '0', '3', '2', '7', '5', '0', '1', '3', '9', '5', '6', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '3', '1', '2', '0', '3', '9', '1', '4', '8', '4', '4', '2', '1', '3', '3', '9', '4', '1', '4', '5', '4', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '5', '9', '6', '4', '0', '4', '0', '0', '2', '0', '5', '8', '3', '5', '1', '3', '2', '5', '4', '0', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '5', '1', '2', '3', '2', '8', '7', '7', '0', '2', '2', '7', '0', '8', '7', '3', '3', '5', '8', '2', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '7', '8', '6', '6', '7', '4', '5', '3', '4', '9', '0', '4', '7', '9', '9', '9', '7', '0', '8', '0', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '4', '7', '8', '2', '4', '0', '3', '3', '9', '1', '6', '0', '3', '0', '5', '7', '0', '6', '3', '9', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '4', '4', '9', '8', '3', '3', '9', '3', '8', '4', '1', '9', '4', '1', '1', '8', '4', '1', '4', '6', '2', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '1', '9', '8', '5', '6', '5', '7', '7', '2', '1', '5', '9', '5', '0', '8', '2', '7', '3', '5', '8', '8', '"', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ']', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'o', 'l', 'd', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6', '"', ':', ' ', '"', '7', '1', '7', '0', '4', '5', '1', '2', '8', '8', '6', '3', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'n', 'e', 'w', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6', '"', ':', ' ', '"', '7', '1', '8', '8', '7', '5', '2', '6', '5', '5', '2', '7', '"', '\r', '\n', ' ', ' ', ' ', ' ', '}', ',']
noncomputable def momentRecordsChunk038Push (acc : List SourceJson) : List SourceJson :=
  (.obj [(String.ofList ['s', 'i', 'm', 'p', 'l', 'e', 'x', '_', 'i', 'd'], .number (String.ofList ['3', '8'])), (String.ofList ['l', 'o', 'g', '_', 'g', 'a', 'p', '_', 'f', 'a', 'c', 't', 'o', 'r', '_', 'f', 'l', 'o', 'o', 'r', 's', '_', 'Q', '8', '0'], .arr [.str (String.ofList ['4', '3', '0', '7', '4', '5', '4', '4', '0', '8', '8', '1', '4', '0', '2', '3', '9', '5', '2', '6', '2']), .str (String.ofList ['3', '7', '4', '8', '3', '6', '5', '6', '2', '6', '6', '4', '9', '3', '9', '6', '0', '0', '9', '6', '5']), .str (String.ofList ['2', '7', '8', '2', '6', '2', '4', '5', '5', '9', '0', '3', '2', '7', '5', '0', '1', '3', '9', '5', '6']), .str (String.ofList ['3', '1', '2', '0', '3', '9', '1', '4', '8', '4', '4', '2', '1', '3', '3', '9', '4', '1', '4', '5', '4']), .str (String.ofList ['2', '5', '9', '6', '4', '0', '4', '0', '0', '2', '0', '5', '8', '3', '5', '1', '3', '2', '5', '4', '0']), .str (String.ofList ['2', '5', '1', '2', '3', '2', '8', '7', '7', '0', '2', '2', '7', '0', '8', '7', '3', '3', '5', '8', '2']), .str (String.ofList ['2', '7', '8', '6', '6', '7', '4', '5', '3', '4', '9', '0', '4', '7', '9', '9', '9', '7', '0', '8', '0']), .str (String.ofList ['2', '4', '7', '8', '2', '4', '0', '3', '3', '9', '1', '6', '0', '3', '0', '5', '7', '0', '6', '3', '9']), .str (String.ofList ['4', '4', '9', '8', '3', '3', '9', '3', '8', '4', '1', '9', '4', '1', '1', '8', '4', '1', '4', '6', '2']), .str (String.ofList ['1', '9', '8', '5', '6', '5', '7', '7', '2', '1', '5', '9', '5', '0', '8', '2', '7', '3', '5', '8', '8'])]), (String.ofList ['o', 'l', 'd', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6'], .str (String.ofList ['7', '1', '7', '0', '4', '5', '1', '2', '8', '8', '6', '3'])), (String.ofList ['n', 'e', 'w', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6'], .str (String.ofList ['7', '1', '8', '8', '7', '5', '2', '6', '5', '5', '2', '7']))]) :: (acc)

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_chunk_038_before_generic"
  err.flush

theorem array_moment_records_chunk_038 (fuel : Nat) (tail : List Char) (acc : List SourceJson) :
    SourceJson.array (fuel + 112)
      (SourceJson.white (momentRecordsChunk038Chars ++ tail)) acc =
      SourceJson.array (fuel + 111) (SourceJson.white tail) (momentRecordsChunk038Push acc) := by rfl

noncomputable def momentRecordsAcc039 : List SourceJson := momentRecordsChunk038Push momentRecordsAcc038

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_chunk_038_generic_complete"
  err.flush

noncomputable def momentRecordsChunk039Chars : List Char := ['\r', '\n', ' ', ' ', ' ', ' ', '{', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 's', 'i', 'm', 'p', 'l', 'e', 'x', '_', 'i', 'd', '"', ':', ' ', '3', '9', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'l', 'o', 'g', '_', 'g', 'a', 'p', '_', 'f', 'a', 'c', 't', 'o', 'r', '_', 'f', 'l', 'o', 'o', 'r', 's', '_', 'Q', '8', '0', '"', ':', ' ', '[', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '4', '3', '0', '7', '4', '9', '8', '6', '2', '3', '4', '4', '9', '4', '1', '0', '4', '2', '9', '8', '6', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '3', '7', '4', '8', '0', '5', '0', '5', '9', '6', '8', '4', '1', '3', '2', '7', '0', '4', '0', '9', '3', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '5', '7', '8', '6', '3', '4', '1', '7', '0', '9', '0', '0', '3', '2', '8', '8', '3', '6', '8', '3', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '3', '5', '9', '2', '7', '3', '6', '6', '4', '5', '7', '7', '2', '8', '3', '3', '8', '2', '2', '3', '0', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '9', '9', '8', '6', '9', '3', '0', '7', '4', '1', '5', '0', '9', '2', '5', '1', '0', '9', '4', '2', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '3', '1', '9', '2', '0', '7', '1', '6', '8', '8', '6', '3', '6', '2', '2', '5', '3', '1', '0', '6', '9', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '1', '1', '5', '6', '3', '0', '0', '1', '5', '5', '9', '8', '8', '2', '4', '4', '2', '3', '9', '0', '8', '4', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '8', '8', '8', '1', '9', '5', '7', '5', '0', '4', '3', '2', '8', '2', '1', '3', '9', '0', '9', '9', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '4', '7', '0', '1', '9', '3', '2', '8', '7', '5', '1', '3', '9', '3', '3', '3', '8', '9', '1', '6', '3', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '1', '9', '9', '0', '1', '2', '2', '0', '3', '2', '1', '9', '3', '5', '2', '2', '9', '1', '2', '5', '1', '"', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ']', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'o', 'l', 'd', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6', '"', ':', ' ', '"', '5', '6', '5', '4', '1', '0', '5', '5', '2', '6', '6', '2', '0', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'n', 'e', 'w', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6', '"', ':', ' ', '"', '5', '6', '7', '3', '5', '7', '6', '8', '8', '8', '0', '2', '5', '"', '\r', '\n', ' ', ' ', ' ', ' ', '}', ',']
noncomputable def momentRecordsChunk039Push (acc : List SourceJson) : List SourceJson :=
  (.obj [(String.ofList ['s', 'i', 'm', 'p', 'l', 'e', 'x', '_', 'i', 'd'], .number (String.ofList ['3', '9'])), (String.ofList ['l', 'o', 'g', '_', 'g', 'a', 'p', '_', 'f', 'a', 'c', 't', 'o', 'r', '_', 'f', 'l', 'o', 'o', 'r', 's', '_', 'Q', '8', '0'], .arr [.str (String.ofList ['4', '3', '0', '7', '4', '9', '8', '6', '2', '3', '4', '4', '9', '4', '1', '0', '4', '2', '9', '8', '6']), .str (String.ofList ['3', '7', '4', '8', '0', '5', '0', '5', '9', '6', '8', '4', '1', '3', '2', '7', '0', '4', '0', '9', '3']), .str (String.ofList ['2', '5', '7', '8', '6', '3', '4', '1', '7', '0', '9', '0', '0', '3', '2', '8', '8', '3', '6', '8', '3']), .str (String.ofList ['3', '5', '9', '2', '7', '3', '6', '6', '4', '5', '7', '7', '2', '8', '3', '3', '8', '2', '2', '3', '0']), .str (String.ofList ['2', '9', '9', '8', '6', '9', '3', '0', '7', '4', '1', '5', '0', '9', '2', '5', '1', '0', '9', '4', '2']), .str (String.ofList ['3', '1', '9', '2', '0', '7', '1', '6', '8', '8', '6', '3', '6', '2', '2', '5', '3', '1', '0', '6', '9']), .str (String.ofList ['1', '1', '5', '6', '3', '0', '0', '1', '5', '5', '9', '8', '8', '2', '4', '4', '2', '3', '9', '0', '8', '4']), .str (String.ofList ['2', '8', '8', '8', '1', '9', '5', '7', '5', '0', '4', '3', '2', '8', '2', '1', '3', '9', '0', '9', '9']), .str (String.ofList ['4', '7', '0', '1', '9', '3', '2', '8', '7', '5', '1', '3', '9', '3', '3', '3', '8', '9', '1', '6', '3']), .str (String.ofList ['1', '9', '9', '0', '1', '2', '2', '0', '3', '2', '1', '9', '3', '5', '2', '2', '9', '1', '2', '5', '1'])]), (String.ofList ['o', 'l', 'd', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6'], .str (String.ofList ['5', '6', '5', '4', '1', '0', '5', '5', '2', '6', '6', '2', '0'])), (String.ofList ['n', 'e', 'w', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6'], .str (String.ofList ['5', '6', '7', '3', '5', '7', '6', '8', '8', '8', '0', '2', '5']))]) :: (acc)

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_chunk_039_before_generic"
  err.flush

theorem array_moment_records_chunk_039 (fuel : Nat) (tail : List Char) (acc : List SourceJson) :
    SourceJson.array (fuel + 111)
      (SourceJson.white (momentRecordsChunk039Chars ++ tail)) acc =
      SourceJson.array (fuel + 110) (SourceJson.white tail) (momentRecordsChunk039Push acc) := by rfl

noncomputable def momentRecordsAcc040 : List SourceJson := momentRecordsChunk039Push momentRecordsAcc039

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_chunk_039_generic_complete"
  err.flush

noncomputable def momentRecordsBlock009Chars : List Char := momentRecordsChunk036Chars ++ momentRecordsChunk037Chars ++ momentRecordsChunk038Chars ++ momentRecordsChunk039Chars
noncomputable def momentRecordsBlock009Push (acc : List SourceJson) : List SourceJson := momentRecordsChunk039Push (momentRecordsChunk038Push (momentRecordsChunk037Push (momentRecordsChunk036Push (acc))))

theorem array_moment_records_block_009 (fuel : Nat) (tail : List Char) (acc : List SourceJson) :
    SourceJson.array (fuel + 114)
      (SourceJson.white (momentRecordsBlock009Chars ++ tail)) acc =
      SourceJson.array (fuel + 110) (SourceJson.white tail) (momentRecordsBlock009Push acc) := by
  have hinput : momentRecordsBlock009Chars ++ tail = momentRecordsChunk036Chars ++ (momentRecordsChunk037Chars ++ (momentRecordsChunk038Chars ++ (momentRecordsChunk039Chars ++ (tail)))) := by
    simp only [momentRecordsBlock009Chars, List.append_assoc]
  calc
    SourceJson.array (fuel + 114) (SourceJson.white (momentRecordsBlock009Chars ++ tail)) acc =
        SourceJson.array (fuel + 114) (SourceJson.white (momentRecordsChunk036Chars ++ (momentRecordsChunk037Chars ++ (momentRecordsChunk038Chars ++ (momentRecordsChunk039Chars ++ (tail)))))) acc :=
      congrArg (fun s => SourceJson.array (fuel + 114) (SourceJson.white s) acc) hinput
    _ = SourceJson.array (fuel + 113) (SourceJson.white (momentRecordsChunk037Chars ++ (momentRecordsChunk038Chars ++ (momentRecordsChunk039Chars ++ (tail))))) (momentRecordsChunk036Push (acc)) := array_moment_records_chunk_036 fuel (momentRecordsChunk037Chars ++ (momentRecordsChunk038Chars ++ (momentRecordsChunk039Chars ++ (tail)))) (acc)
    _ = SourceJson.array (fuel + 112) (SourceJson.white (momentRecordsChunk038Chars ++ (momentRecordsChunk039Chars ++ (tail)))) (momentRecordsChunk037Push (momentRecordsChunk036Push (acc))) := array_moment_records_chunk_037 fuel (momentRecordsChunk038Chars ++ (momentRecordsChunk039Chars ++ (tail))) (momentRecordsChunk036Push (acc))
    _ = SourceJson.array (fuel + 111) (SourceJson.white (momentRecordsChunk039Chars ++ (tail))) (momentRecordsChunk038Push (momentRecordsChunk037Push (momentRecordsChunk036Push (acc)))) := array_moment_records_chunk_038 fuel (momentRecordsChunk039Chars ++ (tail)) (momentRecordsChunk037Push (momentRecordsChunk036Push (acc)))
    _ = SourceJson.array (fuel + 110) (SourceJson.white tail) (momentRecordsBlock009Push acc) := array_moment_records_chunk_039 fuel (tail) (momentRecordsChunk038Push (momentRecordsChunk037Push (momentRecordsChunk036Push (acc))))

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_block_009_before_raw_binding"
  err.flush

theorem moment_records_block_009_prefix :
    (momentRest06 18814).take 2033 = momentRecordsBlock009Chars := by rfl

theorem moment_records_block_009_split :
    momentRest06 18814 = momentRecordsBlock009Chars ++ momentRest06 20847 := by
  calc
    momentRest06 18814 =
        (momentRest06 18814).take 2033 ++ (momentRest06 18814).drop 2033 :=
      (List.take_append_drop 2033 (momentRest06 18814)).symm
    _ = momentRecordsBlock009Chars ++ (momentRest06 18814).drop 2033 :=
      congrArg (fun p => p ++ (momentRest06 18814).drop 2033) moment_records_block_009_prefix
    _ = momentRecordsBlock009Chars ++ momentRest06 20847 :=
      congrArg (fun rest => momentRecordsBlock009Chars ++ rest) (momentRest06_drop 18814 2033)

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_block_009_after_raw_binding"
  err.flush

theorem array_moment_records_original_block_009 (fuel : Nat) (acc : List SourceJson) :
    SourceJson.array (fuel + 114)
      (SourceJson.white (momentRest06 18814)) acc =
      SourceJson.array (fuel + 110) (SourceJson.white (momentRest06 20847)) (momentRecordsBlock009Push acc) := by
  exact (congrArg (fun s => SourceJson.array (fuel + 114) (SourceJson.white s) acc)
      moment_records_block_009_split).trans (array_moment_records_block_009 fuel (momentRest06 20847) acc)

theorem moment_records_through_block_009 (fuel : Nat) :
    SourceJson.array (fuel + 150)
      (SourceJson.white (momentRest06 364)) [] =
      SourceJson.array (fuel + 110) (SourceJson.white (momentRest06 20847)) momentRecordsAcc040 := by
  exact (moment_records_through_block_008 fuel).trans (array_moment_records_original_block_009 fuel momentRecordsAcc036)

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_block_009_complete"
  err.flush

#print axioms array_moment_records_chunk_036
#print axioms array_moment_records_chunk_037
#print axioms array_moment_records_chunk_038
#print axioms array_moment_records_chunk_039
#print axioms array_moment_records_block_009
#print axioms moment_records_block_009_prefix
#print axioms moment_records_block_009_split
#print axioms array_moment_records_original_block_009
#print axioms moment_records_through_block_009

end ImbalancedChen.P2OriginalSaving19Moment06Parsing
