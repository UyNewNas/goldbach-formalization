/- SOURCE_CANDIDATE: original Cell06 source only. No Lean compilation,
independent kernel replay, full-owned audit or formal acceptance is claimed. -/

import ImbalancedChen.P2OriginalSaving19Moment06DecodedBlock021
import ImbalancedChen.P2OriginalSaving19Moment06RecordsBlock022

/-! Original typed moment records 88 through 91; each concrete value is checked by original decodeMomentRecord.
Candidate quotations preserve exact original raw bytes. The Lean equations bind
them to the production-compatible packed input and run the unchanged reader.
This local input resolves inside this private project, not the P1 filesystem. -/
namespace ImbalancedChen.P2OriginalSaving19Moment06Decoding
set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false
open ImbalancedChen.P2OriginalSaving19Archive

open ImbalancedChen.P2OriginalSaving19Moment06Parsing

noncomputable def momentJsonRecord088 : SourceJson :=
  (momentRecordsChunk088Push []).head (List.cons_ne_nil _ _)

theorem moment_record_088_push_eq (acc : List SourceJson) :
    momentRecordsChunk088Push acc = momentJsonRecord088 :: acc := by rfl

noncomputable def momentTypedRecord088 : MomentRecord :=
  { simplexId := 88,
    factorFloorsQ80 := #[(247541418852056997758 : Int), (298549138033135414249 : Int), (226657884815264618120 : Int), (243048737513552724739 : Int), (213973741323338929966 : Int), (150914525143393160944 : Int), (531760805656008990588 : Int), (540330438466954365768 : Int), (806402889255247071447 : Int), (232872040283261609761 : Int)],
    oldFloorQ96 := (70357986945755238 : Int),
    newFloorQ96 := (70561513837259533 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_088_before_decode"
  err.flush

theorem decode_moment_record_088 :
    decodeMomentRecord momentJsonRecord088 = .ok momentTypedRecord088 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_088_decoded"
  err.flush

noncomputable def momentJsonRecord089 : SourceJson :=
  (momentRecordsChunk089Push []).head (List.cons_ne_nil _ _)

theorem moment_record_089_push_eq (acc : List SourceJson) :
    momentRecordsChunk089Push acc = momentJsonRecord089 :: acc := by rfl

noncomputable def momentTypedRecord089 : MomentRecord :=
  { simplexId := 89,
    factorFloorsQ80 := #[(141372722430598007173 : Int), (334869040131663865405 : Int), (269057533326260015679 : Int), (81763776400492306256 : Int), (63009796797319627592 : Int), (83246237229870937146 : Int), (483452327376659167684 : Int), (430299742211590453432 : Int), (370106775578198910009 : Int), (254995132067982208876 : Int)],
    oldFloorQ96 := (9603861497790494 : Int),
    newFloorQ96 := (9623839272336174 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_089_before_decode"
  err.flush

theorem decode_moment_record_089 :
    decodeMomentRecord momentJsonRecord089 = .ok momentTypedRecord089 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_089_decoded"
  err.flush

noncomputable def momentJsonRecord090 : SourceJson :=
  (momentRecordsChunk090Push []).head (List.cons_ne_nil _ _)

theorem moment_record_090_push_eq (acc : List SourceJson) :
    momentRecordsChunk090Push acc = momentJsonRecord090 :: acc := by rfl

noncomputable def momentTypedRecord090 : MomentRecord :=
  { simplexId := 90,
    factorFloorsQ80 := #[(143168637343760786379 : Int), (225547916856783209820 : Int), (210298814414954032851 : Int), (147465400763190297850 : Int), (127362277953312047959 : Int), (116514811347257265863 : Int), (519378398471091976924 : Int), (458949127549333273720 : Int), (817440204298780548606 : Int), (202588617040878270076 : Int)],
    oldFloorQ96 := (55211351960696715 : Int),
    newFloorQ96 := (55347099032020733 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_090_before_decode"
  err.flush

theorem decode_moment_record_090 :
    decodeMomentRecord momentJsonRecord090 = .ok momentTypedRecord090 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_090_decoded"
  err.flush

noncomputable def momentJsonRecord091 : SourceJson :=
  (momentRecordsChunk091Push []).head (List.cons_ne_nil _ _)

theorem moment_record_091_push_eq (acc : List SourceJson) :
    momentRecordsChunk091Push acc = momentJsonRecord091 :: acc := by rfl

noncomputable def momentTypedRecord091 : MomentRecord :=
  { simplexId := 91,
    factorFloorsQ80 := #[(113325279674886758724 : Int), (276347758734896126840 : Int), (324725046762505585726 : Int), (126712808010940475897 : Int), (157262670420234825978 : Int), (145104005749913537396 : Int), (153703956226844285432 : Int), (140412465738096067220 : Int), (373159565804955887914 : Int), (182061298481051264098 : Int)],
    oldFloorQ96 := (129360226763938 : Int),
    newFloorQ96 := (129573642316658 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_091_before_decode"
  err.flush

theorem decode_moment_record_091 :
    decodeMomentRecord momentJsonRecord091 = .ok momentTypedRecord091 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_091_decoded"
  err.flush

noncomputable def momentJsonRecordsBlock022 : List SourceJson := [momentJsonRecord088, momentJsonRecord089, momentJsonRecord090, momentJsonRecord091]
noncomputable def momentTypedRecordsBlock022 : List MomentRecord := [momentTypedRecord088, momentTypedRecord089, momentTypedRecord090, momentTypedRecord091]

theorem moment_records_block_022_push_eq (acc : List SourceJson) :
    momentRecordsBlock022Push acc = [momentJsonRecord091, momentJsonRecord090, momentJsonRecord089, momentJsonRecord088] ++ acc := by rfl

theorem moment_records_block_022_reverse (acc : List SourceJson) :
    (momentRecordsBlock022Push acc).reverse = acc.reverse ++ momentJsonRecordsBlock022 := by
  rw [moment_records_block_022_push_eq, List.reverse_append]
  rfl

theorem decode_moment_records_block_022 :
    momentJsonRecordsBlock022.mapM decodeMomentRecord = .ok momentTypedRecordsBlock022 := by
  simp only [momentJsonRecordsBlock022, momentTypedRecordsBlock022, List.mapM_cons, List.mapM_nil,
    decode_moment_record_088, decode_moment_record_089, decode_moment_record_090, decode_moment_record_091]
  rfl

noncomputable def momentTypedRowsThroughBlock022 : List MomentRecord := momentTypedRowsThroughBlock021 ++ momentTypedRecordsBlock022

theorem decode_moment_records_through_block_022 :
    momentRecordsAcc092.reverse.mapM decodeMomentRecord = .ok momentTypedRowsThroughBlock022 := by
  change (momentRecordsBlock022Push momentRecordsAcc088).reverse.mapM decodeMomentRecord = _
  rw [moment_records_block_022_reverse]
  rw [List.mapM_append, decode_moment_records_through_block_021, decode_moment_records_block_022]
  rfl

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_block_022_complete"
  err.flush

#print axioms moment_record_088_push_eq
#print axioms decode_moment_record_088
#print axioms moment_record_089_push_eq
#print axioms decode_moment_record_089
#print axioms moment_record_090_push_eq
#print axioms decode_moment_record_090
#print axioms moment_record_091_push_eq
#print axioms decode_moment_record_091
#print axioms moment_records_block_022_push_eq
#print axioms moment_records_block_022_reverse
#print axioms decode_moment_records_block_022
#print axioms decode_moment_records_through_block_022

end ImbalancedChen.P2OriginalSaving19Moment06Decoding
