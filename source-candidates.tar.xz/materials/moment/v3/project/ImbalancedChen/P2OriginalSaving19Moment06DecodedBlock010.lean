/- SOURCE_CANDIDATE: original Cell06 source only. No Lean compilation,
independent kernel replay, full-owned audit or formal acceptance is claimed. -/

import ImbalancedChen.P2OriginalSaving19Moment06DecodedBlock009
import ImbalancedChen.P2OriginalSaving19Moment06RecordsBlock010

/-! Original typed moment records 40 through 43; each concrete value is checked by original decodeMomentRecord.
Candidate quotations preserve exact original raw bytes. The Lean equations bind
them to the production-compatible packed input and run the unchanged reader.
This local input resolves inside this private project, not the P1 filesystem. -/
namespace ImbalancedChen.P2OriginalSaving19Moment06Decoding
set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false
open ImbalancedChen.P2OriginalSaving19Archive

open ImbalancedChen.P2OriginalSaving19Moment06Parsing

noncomputable def momentJsonRecord040 : SourceJson :=
  (momentRecordsChunk040Push []).head (List.cons_ne_nil _ _)

theorem moment_record_040_push_eq (acc : List SourceJson) :
    momentRecordsChunk040Push acc = momentJsonRecord040 :: acc := by rfl

noncomputable def momentTypedRecord040 : MomentRecord :=
  { simplexId := 40,
    factorFloorsQ80 := #[(492496204789496361322 : Int), (460210706668787290603 : Int), (244423018998882763355 : Int), (378406238145059226202 : Int), (313287552595914094010 : Int), (400966322761271422721 : Int), (1247860539400783734276 : Int), (528170690076028424726 : Int), (744544896038888159729 : Int), (313215814263477310889 : Int)],
    oldFloorQ96 := (27717992458766 : Int),
    newFloorQ96 := (27835714133108 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_040_before_decode"
  err.flush

theorem decode_moment_record_040 :
    decodeMomentRecord momentJsonRecord040 = .ok momentTypedRecord040 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_040_decoded"
  err.flush

noncomputable def momentJsonRecord041 : SourceJson :=
  (momentRecordsChunk041Push []).head (List.cons_ne_nil _ _)

theorem moment_record_041_push_eq (acc : List SourceJson) :
    momentRecordsChunk041Push acc = momentJsonRecord041 :: acc := by rfl

noncomputable def momentTypedRecord041 : MomentRecord :=
  { simplexId := 41,
    factorFloorsQ80 := #[(342478795149312639998 : Int), (326725510548652188636 : Int), (299974798785432580302 : Int), (245044199370132664128 : Int), (199783072250239595278 : Int), (194554939239336538769 : Int), (285155312611560122554 : Int), (260221531282824412126 : Int), (384182451401731265898 : Int), (158956701359742476106 : Int)],
    oldFloorQ96 := (3137934754608285 : Int),
    newFloorQ96 := (3144943208020345 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_041_before_decode"
  err.flush

theorem decode_moment_record_041 :
    decodeMomentRecord momentJsonRecord041 = .ok momentTypedRecord041 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_041_decoded"
  err.flush

noncomputable def momentJsonRecord042 : SourceJson :=
  (momentRecordsChunk042Push []).head (List.cons_ne_nil _ _)

theorem moment_record_042_push_eq (acc : List SourceJson) :
    momentRecordsChunk042Push acc = momentJsonRecord042 :: acc := by rfl

noncomputable def momentTypedRecord042 : MomentRecord :=
  { simplexId := 42,
    factorFloorsQ80 := #[(351387125802271376855 : Int), (327229831784192013333 : Int), (280782523252227846617 : Int), (301560176385051292848 : Int), (249626061920572718406 : Int), (279673895741597126434 : Int), (1132911510665055826859 : Int), (310837141658258570281 : Int), (371089861356896105850 : Int), (159365151296015345248 : Int)],
    oldFloorQ96 := (19940170014524425 : Int),
    newFloorQ96 := (20002358304756129 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_042_before_decode"
  err.flush

theorem decode_moment_record_042 :
    decodeMomentRecord momentJsonRecord042 = .ok momentTypedRecord042 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_042_decoded"
  err.flush

noncomputable def momentJsonRecord043 : SourceJson :=
  (momentRecordsChunk043Push []).head (List.cons_ne_nil _ _)

theorem moment_record_043_push_eq (acc : List SourceJson) :
    momentRecordsChunk043Push acc = momentJsonRecord043 :: acc := by rfl

noncomputable def momentTypedRecord043 : MomentRecord :=
  { simplexId := 43,
    factorFloorsQ80 := #[(360851097072906748964 : Int), (320267760485038331551 : Int), (260699237213857999867 : Int), (349381977966451826600 : Int), (290468188149365752865 : Int), (342835130087986181476 : Int), (1718134515544220975103 : Int), (339128158627632157633 : Int), (392405442233034033048 : Int), (158231661424980936226 : Int)],
    oldFloorQ96 := (4544470225292 : Int),
    newFloorQ96 := (4561539949617 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_043_before_decode"
  err.flush

theorem decode_moment_record_043 :
    decodeMomentRecord momentJsonRecord043 = .ok momentTypedRecord043 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_043_decoded"
  err.flush

noncomputable def momentJsonRecordsBlock010 : List SourceJson := [momentJsonRecord040, momentJsonRecord041, momentJsonRecord042, momentJsonRecord043]
noncomputable def momentTypedRecordsBlock010 : List MomentRecord := [momentTypedRecord040, momentTypedRecord041, momentTypedRecord042, momentTypedRecord043]

theorem moment_records_block_010_push_eq (acc : List SourceJson) :
    momentRecordsBlock010Push acc = [momentJsonRecord043, momentJsonRecord042, momentJsonRecord041, momentJsonRecord040] ++ acc := by rfl

theorem moment_records_block_010_reverse (acc : List SourceJson) :
    (momentRecordsBlock010Push acc).reverse = acc.reverse ++ momentJsonRecordsBlock010 := by
  rw [moment_records_block_010_push_eq, List.reverse_append]
  rfl

theorem decode_moment_records_block_010 :
    momentJsonRecordsBlock010.mapM decodeMomentRecord = .ok momentTypedRecordsBlock010 := by
  simp only [momentJsonRecordsBlock010, momentTypedRecordsBlock010, List.mapM_cons, List.mapM_nil,
    decode_moment_record_040, decode_moment_record_041, decode_moment_record_042, decode_moment_record_043]
  rfl

noncomputable def momentTypedRowsThroughBlock010 : List MomentRecord := momentTypedRowsThroughBlock009 ++ momentTypedRecordsBlock010

theorem decode_moment_records_through_block_010 :
    momentRecordsAcc044.reverse.mapM decodeMomentRecord = .ok momentTypedRowsThroughBlock010 := by
  change (momentRecordsBlock010Push momentRecordsAcc040).reverse.mapM decodeMomentRecord = _
  rw [moment_records_block_010_reverse]
  rw [List.mapM_append, decode_moment_records_through_block_009, decode_moment_records_block_010]
  rfl

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_block_010_complete"
  err.flush

#print axioms moment_record_040_push_eq
#print axioms decode_moment_record_040
#print axioms moment_record_041_push_eq
#print axioms decode_moment_record_041
#print axioms moment_record_042_push_eq
#print axioms decode_moment_record_042
#print axioms moment_record_043_push_eq
#print axioms decode_moment_record_043
#print axioms moment_records_block_010_push_eq
#print axioms moment_records_block_010_reverse
#print axioms decode_moment_records_block_010
#print axioms decode_moment_records_through_block_010

end ImbalancedChen.P2OriginalSaving19Moment06Decoding
