/- SOURCE_CANDIDATE: original Cell06 source only. No Lean compilation,
independent kernel replay, full-owned audit or formal acceptance is claimed. -/

import ImbalancedChen.P2OriginalSaving19Moment06DecodedBlock018
import ImbalancedChen.P2OriginalSaving19Moment06RecordsBlock019

/-! Original typed moment records 76 through 79; each concrete value is checked by original decodeMomentRecord.
Candidate quotations preserve exact original raw bytes. The Lean equations bind
them to the production-compatible packed input and run the unchanged reader.
This local input resolves inside this private project, not the P1 filesystem. -/
namespace ImbalancedChen.P2OriginalSaving19Moment06Decoding
set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false
open ImbalancedChen.P2OriginalSaving19Archive

open ImbalancedChen.P2OriginalSaving19Moment06Parsing

noncomputable def momentJsonRecord076 : SourceJson :=
  (momentRecordsChunk076Push []).head (List.cons_ne_nil _ _)

theorem moment_record_076_push_eq (acc : List SourceJson) :
    momentRecordsChunk076Push acc = momentJsonRecord076 :: acc := by rfl

noncomputable def momentTypedRecord076 : MomentRecord :=
  { simplexId := 76,
    factorFloorsQ80 := #[(162226410157818762065 : Int), (285612225074740735100 : Int), (233889348993541488320 : Int), (129910682460847689122 : Int), (112044093645931149925 : Int), (283434910980991466607 : Int), (792743305328919972965 : Int), (955749800555433940124 : Int), (1126632745388638630747 : Int), (352369586149382552817 : Int)],
    oldFloorQ96 := (14768152861116 : Int),
    newFloorQ96 := (14822425263983 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_076_before_decode"
  err.flush

theorem decode_moment_record_076 :
    decodeMomentRecord momentJsonRecord076 = .ok momentTypedRecord076 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_076_decoded"
  err.flush

noncomputable def momentJsonRecord077 : SourceJson :=
  (momentRecordsChunk077Push []).head (List.cons_ne_nil _ _)

theorem moment_record_077_push_eq (acc : List SourceJson) :
    momentRecordsChunk077Push acc = momentJsonRecord077 :: acc := by rfl

noncomputable def momentTypedRecord077 : MomentRecord :=
  { simplexId := 77,
    factorFloorsQ80 := #[(216304921276071555012 : Int), (321719106936268484791 : Int), (304328749555454763365 : Int), (174213316470637089691 : Int), (146772398069123711161 : Int), (116540625106902779063 : Int), (490221622166521556974 : Int), (519744073742938004178 : Int), (692186249472886700315 : Int), (235902837970967051993 : Int)],
    oldFloorQ96 := (17523591781056870 : Int),
    newFloorQ96 := (17570298431881636 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_077_before_decode"
  err.flush

theorem decode_moment_record_077 :
    decodeMomentRecord momentJsonRecord077 = .ok momentTypedRecord077 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_077_decoded"
  err.flush

noncomputable def momentJsonRecord078 : SourceJson :=
  (momentRecordsChunk078Push []).head (List.cons_ne_nil _ _)

theorem moment_record_078_push_eq (acc : List SourceJson) :
    momentRecordsChunk078Push acc = momentJsonRecord078 :: acc := by rfl

noncomputable def momentTypedRecord078 : MomentRecord :=
  { simplexId := 78,
    factorFloorsQ80 := #[(252916538978804716379 : Int), (323094127485087349409 : Int), (277226289799480599816 : Int), (254166872722816037635 : Int), (220912896135865162113 : Int), (232021576897153728672 : Int), (582682392177966284065 : Int), (685846497199043924424 : Int), (595647740195113481228 : Int), (237050193903315473376 : Int)],
    oldFloorQ96 := (99099186484721698 : Int),
    newFloorQ96 := (99399790692203187 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_078_before_decode"
  err.flush

theorem decode_moment_record_078 :
    decodeMomentRecord momentJsonRecord078 = .ok momentTypedRecord078 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_078_decoded"
  err.flush

noncomputable def momentJsonRecord079 : SourceJson :=
  (momentRecordsChunk079Push []).head (List.cons_ne_nil _ _)

theorem moment_record_079_push_eq (acc : List SourceJson) :
    momentRecordsChunk079Push acc = momentJsonRecord079 :: acc := by rfl

noncomputable def momentTypedRecord079 : MomentRecord :=
  { simplexId := 79,
    factorFloorsQ80 := #[(273545183021605377911 : Int), (317628269341332369819 : Int), (262966375726432881837 : Int), (299795785186983103850 : Int), (261936649749136080324 : Int), (366585818569518001256 : Int), (689779036698813138180 : Int), (880164192025965336022 : Int), (1089732816924512020016 : Int), (275811868229376092967 : Int)],
    oldFloorQ96 := (211095496223991202 : Int),
    newFloorQ96 := (211920925734923177 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_079_before_decode"
  err.flush

theorem decode_moment_record_079 :
    decodeMomentRecord momentJsonRecord079 = .ok momentTypedRecord079 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_079_decoded"
  err.flush

noncomputable def momentJsonRecordsBlock019 : List SourceJson := [momentJsonRecord076, momentJsonRecord077, momentJsonRecord078, momentJsonRecord079]
noncomputable def momentTypedRecordsBlock019 : List MomentRecord := [momentTypedRecord076, momentTypedRecord077, momentTypedRecord078, momentTypedRecord079]

theorem moment_records_block_019_push_eq (acc : List SourceJson) :
    momentRecordsBlock019Push acc = [momentJsonRecord079, momentJsonRecord078, momentJsonRecord077, momentJsonRecord076] ++ acc := by rfl

theorem moment_records_block_019_reverse (acc : List SourceJson) :
    (momentRecordsBlock019Push acc).reverse = acc.reverse ++ momentJsonRecordsBlock019 := by
  rw [moment_records_block_019_push_eq, List.reverse_append]
  rfl

theorem decode_moment_records_block_019 :
    momentJsonRecordsBlock019.mapM decodeMomentRecord = .ok momentTypedRecordsBlock019 := by
  simp only [momentJsonRecordsBlock019, momentTypedRecordsBlock019, List.mapM_cons, List.mapM_nil,
    decode_moment_record_076, decode_moment_record_077, decode_moment_record_078, decode_moment_record_079]
  rfl

noncomputable def momentTypedRowsThroughBlock019 : List MomentRecord := momentTypedRowsThroughBlock018 ++ momentTypedRecordsBlock019

theorem decode_moment_records_through_block_019 :
    momentRecordsAcc080.reverse.mapM decodeMomentRecord = .ok momentTypedRowsThroughBlock019 := by
  change (momentRecordsBlock019Push momentRecordsAcc076).reverse.mapM decodeMomentRecord = _
  rw [moment_records_block_019_reverse]
  rw [List.mapM_append, decode_moment_records_through_block_018, decode_moment_records_block_019]
  rfl

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_block_019_complete"
  err.flush

#print axioms moment_record_076_push_eq
#print axioms decode_moment_record_076
#print axioms moment_record_077_push_eq
#print axioms decode_moment_record_077
#print axioms moment_record_078_push_eq
#print axioms decode_moment_record_078
#print axioms moment_record_079_push_eq
#print axioms decode_moment_record_079
#print axioms moment_records_block_019_push_eq
#print axioms moment_records_block_019_reverse
#print axioms decode_moment_records_block_019
#print axioms decode_moment_records_through_block_019

end ImbalancedChen.P2OriginalSaving19Moment06Decoding
