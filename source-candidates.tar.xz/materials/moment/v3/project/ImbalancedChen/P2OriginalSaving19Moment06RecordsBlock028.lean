/- SOURCE_CANDIDATE: original Cell06 source only. No Lean compilation,
independent kernel replay, full-owned audit or formal acceptance is claimed. -/

import ImbalancedChen.P2OriginalSaving19Moment06RecordsBlock027

/-! Original moment records block 28. Small arbitrary-tail/accumulator parser equations and one exact packed-input binding.
Candidate quotations preserve exact original raw bytes. The Lean equations bind
them to the production-compatible packed input and run the unchanged reader.
This local input resolves inside this private project, not the P1 filesystem. -/
namespace ImbalancedChen.P2OriginalSaving19Moment06Parsing
set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false
open ImbalancedChen.P2OriginalSaving19Archive

noncomputable def momentRecordsChunk112Chars : List Char := ['\r', '\n', ' ', ' ', ' ', ' ', '{', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 's', 'i', 'm', 'p', 'l', 'e', 'x', '_', 'i', 'd', '"', ':', ' ', '1', '1', '2', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'l', 'o', 'g', '_', 'g', 'a', 'p', '_', 'f', 'a', 'c', 't', 'o', 'r', '_', 'f', 'l', 'o', 'o', 'r', 's', '_', 'Q', '8', '0', '"', ':', ' ', '[', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '4', '4', '0', '7', '0', '9', '7', '7', '1', '2', '8', '7', '2', '3', '6', '1', '8', '3', '9', '7', '5', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '4', '6', '9', '0', '4', '5', '8', '1', '7', '6', '8', '0', '1', '3', '5', '2', '3', '4', '7', '0', '1', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '1', '9', '5', '9', '2', '3', '8', '3', '4', '7', '8', '3', '2', '1', '0', '8', '0', '3', '8', '6', '8', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '3', '2', '2', '1', '7', '1', '1', '2', '8', '9', '5', '2', '4', '8', '7', '5', '1', '5', '4', '2', '3', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '3', '7', '3', '3', '0', '7', '3', '5', '7', '8', '4', '7', '8', '0', '3', '1', '9', '3', '6', '7', '4', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '3', '4', '1', '8', '6', '0', '6', '1', '5', '2', '4', '1', '0', '2', '0', '0', '0', '7', '7', '4', '6', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '9', '2', '7', '8', '4', '5', '6', '1', '2', '5', '6', '4', '1', '0', '6', '7', '1', '2', '5', '2', '8', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '4', '1', '3', '0', '4', '4', '6', '0', '7', '7', '2', '3', '2', '4', '1', '7', '8', '4', '8', '8', '4', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '3', '0', '8', '6', '8', '6', '9', '7', '1', '0', '0', '6', '2', '3', '4', '7', '5', '7', '2', '0', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '3', '0', '8', '7', '3', '1', '8', '2', '1', '5', '0', '4', '8', '4', '2', '4', '2', '9', '2', '6', '"', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ']', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'o', 'l', 'd', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6', '"', ':', ' ', '"', '2', '1', '3', '3', '2', '0', '9', '0', '1', '8', '0', '3', '2', '4', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'n', 'e', 'w', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6', '"', ':', ' ', '"', '2', '1', '4', '0', '1', '8', '2', '6', '8', '6', '4', '6', '8', '4', '"', '\r', '\n', ' ', ' ', ' ', ' ', '}', '\r', '\n', ' ', ' ', ']']
noncomputable def momentRecordsChunk112Push (acc : List SourceJson) : List SourceJson :=
  (.obj [(String.ofList ['s', 'i', 'm', 'p', 'l', 'e', 'x', '_', 'i', 'd'], .number (String.ofList ['1', '1', '2'])), (String.ofList ['l', 'o', 'g', '_', 'g', 'a', 'p', '_', 'f', 'a', 'c', 't', 'o', 'r', '_', 'f', 'l', 'o', 'o', 'r', 's', '_', 'Q', '8', '0'], .arr [.str (String.ofList ['4', '4', '0', '7', '0', '9', '7', '7', '1', '2', '8', '7', '2', '3', '6', '1', '8', '3', '9', '7', '5']), .str (String.ofList ['4', '6', '9', '0', '4', '5', '8', '1', '7', '6', '8', '0', '1', '3', '5', '2', '3', '4', '7', '0', '1']), .str (String.ofList ['1', '9', '5', '9', '2', '3', '8', '3', '4', '7', '8', '3', '2', '1', '0', '8', '0', '3', '8', '6', '8']), .str (String.ofList ['3', '2', '2', '1', '7', '1', '1', '2', '8', '9', '5', '2', '4', '8', '7', '5', '1', '5', '4', '2', '3']), .str (String.ofList ['3', '7', '3', '3', '0', '7', '3', '5', '7', '8', '4', '7', '8', '0', '3', '1', '9', '3', '6', '7', '4']), .str (String.ofList ['3', '4', '1', '8', '6', '0', '6', '1', '5', '2', '4', '1', '0', '2', '0', '0', '0', '7', '7', '4', '6']), .str (String.ofList ['9', '2', '7', '8', '4', '5', '6', '1', '2', '5', '6', '4', '1', '0', '6', '7', '1', '2', '5', '2', '8']), .str (String.ofList ['4', '1', '3', '0', '4', '4', '6', '0', '7', '7', '2', '3', '2', '4', '1', '7', '8', '4', '8', '8', '4']), .str (String.ofList ['2', '3', '0', '8', '6', '8', '6', '9', '7', '1', '0', '0', '6', '2', '3', '4', '7', '5', '7', '2', '0']), .str (String.ofList ['2', '3', '0', '8', '7', '3', '1', '8', '2', '1', '5', '0', '4', '8', '4', '2', '4', '2', '9', '2', '6'])]), (String.ofList ['o', 'l', 'd', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6'], .str (String.ofList ['2', '1', '3', '3', '2', '0', '9', '0', '1', '8', '0', '3', '2', '4'])), (String.ofList ['n', 'e', 'w', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6'], .str (String.ofList ['2', '1', '4', '0', '1', '8', '2', '6', '8', '6', '4', '6', '8', '4']))]) :: (acc)

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_chunk_112_before_generic"
  err.flush

theorem array_moment_records_chunk_112 (fuel : Nat) (tail : List Char) (acc : List SourceJson) :
    SourceJson.array (fuel + 38)
      (SourceJson.white (momentRecordsChunk112Chars ++ tail)) acc =
      .ok (.arr ((momentRecordsChunk112Push acc).reverse), tail) := by rfl

noncomputable def momentRecordsAcc113 : List SourceJson := momentRecordsChunk112Push momentRecordsAcc112

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_chunk_112_generic_complete"
  err.flush

noncomputable def momentRecordsBlock028Chars : List Char := momentRecordsChunk112Chars
noncomputable def momentRecordsBlock028Push (acc : List SourceJson) : List SourceJson := momentRecordsChunk112Push (acc)

theorem array_moment_records_block_028 (fuel : Nat) (tail : List Char) (acc : List SourceJson) :
    SourceJson.array (fuel + 38)
      (SourceJson.white (momentRecordsBlock028Chars ++ tail)) acc =
      .ok (.arr ((momentRecordsBlock028Push acc).reverse), tail) := by
  have hinput : momentRecordsBlock028Chars ++ tail = momentRecordsChunk112Chars ++ (tail) := by
    rfl
  calc
    SourceJson.array (fuel + 38) (SourceJson.white (momentRecordsBlock028Chars ++ tail)) acc =
        SourceJson.array (fuel + 38) (SourceJson.white (momentRecordsChunk112Chars ++ (tail))) acc :=
      congrArg (fun s => SourceJson.array (fuel + 38) (SourceJson.white s) acc) hinput
    _ = .ok (.arr ((momentRecordsBlock028Push acc).reverse), tail) := array_moment_records_chunk_112 fuel (tail) (acc)

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_block_028_before_raw_binding"
  err.flush

theorem moment_records_block_028_prefix :
    (momentRest06 57856).take 515 = momentRecordsBlock028Chars := by rfl

theorem moment_records_block_028_split :
    momentRest06 57856 = momentRecordsBlock028Chars ++ momentRest06 58371 := by
  calc
    momentRest06 57856 =
        (momentRest06 57856).take 515 ++ (momentRest06 57856).drop 515 :=
      (List.take_append_drop 515 (momentRest06 57856)).symm
    _ = momentRecordsBlock028Chars ++ (momentRest06 57856).drop 515 :=
      congrArg (fun p => p ++ (momentRest06 57856).drop 515) moment_records_block_028_prefix
    _ = momentRecordsBlock028Chars ++ momentRest06 58371 :=
      congrArg (fun rest => momentRecordsBlock028Chars ++ rest) (momentRest06_drop 57856 515)

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_block_028_after_raw_binding"
  err.flush

theorem array_moment_records_original_block_028 (fuel : Nat) (acc : List SourceJson) :
    SourceJson.array (fuel + 38)
      (SourceJson.white (momentRest06 57856)) acc =
      .ok (.arr ((momentRecordsBlock028Push acc).reverse), momentRest06 58371) := by
  exact (congrArg (fun s => SourceJson.array (fuel + 38) (SourceJson.white s) acc)
      moment_records_block_028_split).trans (array_moment_records_block_028 fuel (momentRest06 58371) acc)

noncomputable def momentRecordsArrayValue : SourceJson := .arr (momentRecordsAcc113.reverse)

theorem moment_records_through_block_028 (fuel : Nat) :
    SourceJson.array (fuel + 150)
      (SourceJson.white (momentRest06 364)) [] =
      .ok (momentRecordsArrayValue, momentRest06 58371) := by
  exact (moment_records_through_block_027 fuel).trans (array_moment_records_original_block_028 fuel momentRecordsAcc112)

theorem value_moment_records_original (fuel : Nat) :
    SourceJson.value (fuel + 151) (momentRest06 363) =
      .ok (momentRecordsArrayValue, momentRest06 58371) := by
  exact (value_moment_records_open fuel).trans (moment_records_through_block_028 fuel)

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_block_028_complete"
  err.flush

#print axioms array_moment_records_chunk_112
#print axioms array_moment_records_block_028
#print axioms moment_records_block_028_prefix
#print axioms moment_records_block_028_split
#print axioms array_moment_records_original_block_028
#print axioms moment_records_through_block_028
#print axioms value_moment_records_original

end ImbalancedChen.P2OriginalSaving19Moment06Parsing
