/- SOURCE_CANDIDATE: original Cell06 source only. No Lean compilation,
independent kernel replay, full-owned audit or formal acceptance is claimed. -/

import ImbalancedChen.P2OriginalSaving19Moment06RecordsBlock023

/-! Original moment records block 24. Small arbitrary-tail/accumulator parser equations and one exact packed-input binding.
Candidate quotations preserve exact original raw bytes. The Lean equations bind
them to the production-compatible packed input and run the unchanged reader.
This local input resolves inside this private project, not the P1 filesystem. -/
namespace ImbalancedChen.P2OriginalSaving19Moment06Parsing
set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false
open ImbalancedChen.P2OriginalSaving19Archive

noncomputable def momentRecordsChunk096Chars : List Char := ['\r', '\n', ' ', ' ', ' ', ' ', '{', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 's', 'i', 'm', 'p', 'l', 'e', 'x', '_', 'i', 'd', '"', ':', ' ', '9', '6', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'l', 'o', 'g', '_', 'g', 'a', 'p', '_', 'f', 'a', 'c', 't', 'o', 'r', '_', 'f', 'l', 'o', 'o', 'r', 's', '_', 'Q', '8', '0', '"', ':', ' ', '[', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '3', '2', '5', '5', '2', '2', '8', '0', '9', '0', '0', '4', '5', '6', '9', '8', '2', '7', '0', '2', '1', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '3', '9', '2', '0', '6', '5', '8', '1', '9', '3', '4', '7', '8', '4', '8', '6', '6', '1', '2', '6', '7', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '3', '4', '2', '9', '6', '1', '8', '1', '5', '1', '0', '0', '9', '6', '4', '7', '4', '6', '2', '2', '2', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '2', '0', '1', '1', '7', '4', '9', '4', '6', '9', '9', '9', '4', '4', '3', '1', '2', '8', '6', '8', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '1', '4', '1', '7', '5', '2', '7', '1', '0', '4', '6', '1', '5', '0', '8', '9', '8', '3', '2', '4', '9', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '1', '9', '4', '1', '8', '8', '9', '5', '2', '9', '9', '5', '6', '9', '0', '6', '7', '8', '6', '2', '3', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '4', '4', '3', '9', '6', '3', '8', '7', '8', '8', '3', '3', '0', '0', '2', '2', '0', '7', '1', '7', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '0', '8', '6', '6', '4', '3', '7', '9', '0', '4', '8', '7', '4', '5', '6', '5', '5', '4', '5', '3', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '3', '9', '7', '7', '5', '4', '5', '5', '3', '3', '0', '6', '6', '6', '3', '5', '0', '9', '1', '3', '9', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '7', '0', '4', '2', '5', '6', '9', '8', '0', '2', '1', '2', '8', '9', '5', '1', '5', '7', '7', '4', '"', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ']', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'o', 'l', 'd', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6', '"', ':', ' ', '"', '1', '2', '5', '5', '6', '2', '2', '4', '9', '4', '7', '4', '2', '8', '3', '8', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'n', 'e', 'w', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6', '"', ':', ' ', '"', '1', '2', '5', '8', '4', '6', '9', '3', '2', '1', '5', '6', '2', '4', '6', '9', '"', '\r', '\n', ' ', ' ', ' ', ' ', '}', ',']
noncomputable def momentRecordsChunk096Push (acc : List SourceJson) : List SourceJson :=
  (.obj [(String.ofList ['s', 'i', 'm', 'p', 'l', 'e', 'x', '_', 'i', 'd'], .number (String.ofList ['9', '6'])), (String.ofList ['l', 'o', 'g', '_', 'g', 'a', 'p', '_', 'f', 'a', 'c', 't', 'o', 'r', '_', 'f', 'l', 'o', 'o', 'r', 's', '_', 'Q', '8', '0'], .arr [.str (String.ofList ['3', '2', '5', '5', '2', '2', '8', '0', '9', '0', '0', '4', '5', '6', '9', '8', '2', '7', '0', '2', '1']), .str (String.ofList ['3', '9', '2', '0', '6', '5', '8', '1', '9', '3', '4', '7', '8', '4', '8', '6', '6', '1', '2', '6', '7']), .str (String.ofList ['3', '4', '2', '9', '6', '1', '8', '1', '5', '1', '0', '0', '9', '6', '4', '7', '4', '6', '2', '2', '2']), .str (String.ofList ['2', '2', '0', '1', '1', '7', '4', '9', '4', '6', '9', '9', '9', '4', '4', '3', '1', '2', '8', '6', '8']), .str (String.ofList ['1', '4', '1', '7', '5', '2', '7', '1', '0', '4', '6', '1', '5', '0', '8', '9', '8', '3', '2', '4', '9']), .str (String.ofList ['1', '9', '4', '1', '8', '8', '9', '5', '2', '9', '9', '5', '6', '9', '0', '6', '7', '8', '6', '2', '3']), .str (String.ofList ['2', '4', '4', '3', '9', '6', '3', '8', '7', '8', '8', '3', '3', '0', '0', '2', '2', '0', '7', '1', '7']), .str (String.ofList ['2', '0', '8', '6', '6', '4', '3', '7', '9', '0', '4', '8', '7', '4', '5', '6', '5', '5', '4', '5', '3']), .str (String.ofList ['3', '9', '7', '7', '5', '4', '5', '5', '3', '3', '0', '6', '6', '6', '3', '5', '0', '9', '1', '3', '9']), .str (String.ofList ['2', '7', '0', '4', '2', '5', '6', '9', '8', '0', '2', '1', '2', '8', '9', '5', '1', '5', '7', '7', '4'])]), (String.ofList ['o', 'l', 'd', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6'], .str (String.ofList ['1', '2', '5', '5', '6', '2', '2', '4', '9', '4', '7', '4', '2', '8', '3', '8'])), (String.ofList ['n', 'e', 'w', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6'], .str (String.ofList ['1', '2', '5', '8', '4', '6', '9', '3', '2', '1', '5', '6', '2', '4', '6', '9']))]) :: (acc)

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_chunk_096_before_generic"
  err.flush

theorem array_moment_records_chunk_096 (fuel : Nat) (tail : List Char) (acc : List SourceJson) :
    SourceJson.array (fuel + 54)
      (SourceJson.white (momentRecordsChunk096Chars ++ tail)) acc =
      SourceJson.array (fuel + 53) (SourceJson.white tail) (momentRecordsChunk096Push acc) := by rfl

noncomputable def momentRecordsAcc097 : List SourceJson := momentRecordsChunk096Push momentRecordsAcc096

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_chunk_096_generic_complete"
  err.flush

noncomputable def momentRecordsChunk097Chars : List Char := ['\r', '\n', ' ', ' ', ' ', ' ', '{', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 's', 'i', 'm', 'p', 'l', 'e', 'x', '_', 'i', 'd', '"', ':', ' ', '9', '7', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'l', 'o', 'g', '_', 'g', 'a', 'p', '_', 'f', 'a', 'c', 't', 'o', 'r', '_', 'f', 'l', 'o', 'o', 'r', 's', '_', 'Q', '8', '0', '"', ':', ' ', '[', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '3', '5', '3', '9', '8', '4', '2', '7', '8', '3', '3', '6', '4', '0', '5', '3', '3', '7', '7', '6', '5', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '3', '8', '6', '9', '1', '9', '8', '6', '5', '9', '8', '5', '9', '8', '6', '9', '6', '7', '2', '5', '0', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '3', '1', '5', '4', '3', '2', '4', '4', '7', '6', '1', '0', '4', '9', '4', '5', '4', '8', '3', '6', '9', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '8', '5', '1', '1', '5', '2', '8', '9', '0', '8', '7', '5', '6', '1', '2', '5', '5', '3', '9', '5', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '1', '9', '3', '5', '7', '3', '6', '3', '2', '9', '6', '9', '6', '6', '3', '7', '8', '6', '8', '7', '5', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '1', '3', '3', '2', '8', '9', '1', '0', '5', '6', '8', '9', '8', '6', '4', '9', '3', '0', '9', '4', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '8', '4', '9', '9', '4', '9', '4', '5', '9', '5', '9', '2', '1', '0', '1', '1', '8', '4', '9', '2', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '5', '2', '6', '1', '9', '5', '1', '4', '6', '4', '6', '6', '8', '1', '6', '5', '6', '6', '3', '3', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '4', '5', '1', '7', '1', '9', '3', '1', '3', '0', '3', '4', '6', '4', '7', '5', '6', '4', '2', '2', '3', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '6', '8', '1', '4', '8', '3', '2', '5', '2', '3', '3', '5', '2', '4', '4', '9', '1', '4', '2', '6', '"', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ']', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'o', 'l', 'd', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6', '"', ':', ' ', '"', '8', '3', '5', '7', '4', '6', '0', '2', '6', '9', '0', '7', '7', '0', '9', '5', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'n', 'e', 'w', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6', '"', ':', ' ', '"', '8', '3', '7', '8', '2', '6', '5', '8', '5', '9', '4', '9', '4', '4', '6', '5', '"', '\r', '\n', ' ', ' ', ' ', ' ', '}', ',']
noncomputable def momentRecordsChunk097Push (acc : List SourceJson) : List SourceJson :=
  (.obj [(String.ofList ['s', 'i', 'm', 'p', 'l', 'e', 'x', '_', 'i', 'd'], .number (String.ofList ['9', '7'])), (String.ofList ['l', 'o', 'g', '_', 'g', 'a', 'p', '_', 'f', 'a', 'c', 't', 'o', 'r', '_', 'f', 'l', 'o', 'o', 'r', 's', '_', 'Q', '8', '0'], .arr [.str (String.ofList ['3', '5', '3', '9', '8', '4', '2', '7', '8', '3', '3', '6', '4', '0', '5', '3', '3', '7', '7', '6', '5']), .str (String.ofList ['3', '8', '6', '9', '1', '9', '8', '6', '5', '9', '8', '5', '9', '8', '6', '9', '6', '7', '2', '5', '0']), .str (String.ofList ['3', '1', '5', '4', '3', '2', '4', '4', '7', '6', '1', '0', '4', '9', '4', '5', '4', '8', '3', '6', '9']), .str (String.ofList ['2', '8', '5', '1', '1', '5', '2', '8', '9', '0', '8', '7', '5', '6', '1', '2', '5', '5', '3', '9', '5']), .str (String.ofList ['1', '9', '3', '5', '7', '3', '6', '3', '2', '9', '6', '9', '6', '6', '3', '7', '8', '6', '8', '7', '5']), .str (String.ofList ['2', '1', '3', '3', '2', '8', '9', '1', '0', '5', '6', '8', '9', '8', '6', '4', '9', '3', '0', '9', '4']), .str (String.ofList ['2', '8', '4', '9', '9', '4', '9', '4', '5', '9', '5', '9', '2', '1', '0', '1', '1', '8', '4', '9', '2']), .str (String.ofList ['2', '5', '2', '6', '1', '9', '5', '1', '4', '6', '4', '6', '6', '8', '1', '6', '5', '6', '6', '3', '3']), .str (String.ofList ['4', '5', '1', '7', '1', '9', '3', '1', '3', '0', '3', '4', '6', '4', '7', '5', '6', '4', '2', '2', '3']), .str (String.ofList ['2', '6', '8', '1', '4', '8', '3', '2', '5', '2', '3', '3', '5', '2', '4', '4', '9', '1', '4', '2', '6'])]), (String.ofList ['o', 'l', 'd', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6'], .str (String.ofList ['8', '3', '5', '7', '4', '6', '0', '2', '6', '9', '0', '7', '7', '0', '9', '5'])), (String.ofList ['n', 'e', 'w', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6'], .str (String.ofList ['8', '3', '7', '8', '2', '6', '5', '8', '5', '9', '4', '9', '4', '4', '6', '5']))]) :: (acc)

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_chunk_097_before_generic"
  err.flush

theorem array_moment_records_chunk_097 (fuel : Nat) (tail : List Char) (acc : List SourceJson) :
    SourceJson.array (fuel + 53)
      (SourceJson.white (momentRecordsChunk097Chars ++ tail)) acc =
      SourceJson.array (fuel + 52) (SourceJson.white tail) (momentRecordsChunk097Push acc) := by rfl

noncomputable def momentRecordsAcc098 : List SourceJson := momentRecordsChunk097Push momentRecordsAcc097

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_chunk_097_generic_complete"
  err.flush

noncomputable def momentRecordsChunk098Chars : List Char := ['\r', '\n', ' ', ' ', ' ', ' ', '{', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 's', 'i', 'm', 'p', 'l', 'e', 'x', '_', 'i', 'd', '"', ':', ' ', '9', '8', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'l', 'o', 'g', '_', 'g', 'a', 'p', '_', 'f', 'a', 'c', 't', 'o', 'r', '_', 'f', 'l', 'o', 'o', 'r', 's', '_', 'Q', '8', '0', '"', ':', ' ', '[', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '3', '7', '6', '6', '3', '2', '5', '8', '9', '3', '9', '4', '7', '6', '3', '5', '7', '6', '6', '7', '0', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '3', '8', '6', '2', '0', '1', '3', '2', '6', '6', '1', '7', '0', '1', '7', '6', '9', '9', '9', '5', '8', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '9', '0', '9', '3', '0', '0', '6', '3', '6', '1', '4', '8', '2', '3', '5', '8', '0', '0', '3', '7', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '3', '5', '4', '3', '2', '2', '4', '2', '5', '1', '6', '5', '9', '7', '6', '4', '3', '9', '0', '4', '8', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '4', '7', '8', '2', '5', '6', '9', '4', '5', '6', '5', '2', '0', '7', '4', '6', '5', '7', '2', '8', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '3', '0', '9', '7', '8', '0', '5', '2', '9', '4', '3', '7', '8', '9', '3', '3', '6', '4', '7', '1', '0', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '1', '1', '7', '3', '7', '8', '2', '9', '7', '3', '5', '4', '7', '2', '1', '6', '3', '6', '3', '2', '9', '9', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '9', '0', '3', '6', '9', '0', '1', '7', '7', '1', '4', '4', '1', '0', '0', '1', '8', '2', '0', '9', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '4', '6', '8', '5', '6', '8', '5', '0', '3', '0', '4', '3', '2', '3', '2', '9', '5', '0', '0', '0', '0', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '6', '7', '9', '8', '3', '1', '7', '3', '9', '4', '8', '4', '1', '8', '9', '5', '7', '5', '3', '5', '"', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ']', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'o', 'l', 'd', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6', '"', ':', ' ', '"', '6', '5', '8', '5', '0', '7', '1', '1', '7', '1', '1', '5', '6', '9', '1', '2', '2', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'n', 'e', 'w', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6', '"', ':', ' ', '"', '6', '6', '0', '7', '8', '0', '4', '8', '6', '3', '5', '2', '5', '7', '2', '5', '8', '"', '\r', '\n', ' ', ' ', ' ', ' ', '}', ',']
noncomputable def momentRecordsChunk098Push (acc : List SourceJson) : List SourceJson :=
  (.obj [(String.ofList ['s', 'i', 'm', 'p', 'l', 'e', 'x', '_', 'i', 'd'], .number (String.ofList ['9', '8'])), (String.ofList ['l', 'o', 'g', '_', 'g', 'a', 'p', '_', 'f', 'a', 'c', 't', 'o', 'r', '_', 'f', 'l', 'o', 'o', 'r', 's', '_', 'Q', '8', '0'], .arr [.str (String.ofList ['3', '7', '6', '6', '3', '2', '5', '8', '9', '3', '9', '4', '7', '6', '3', '5', '7', '6', '6', '7', '0']), .str (String.ofList ['3', '8', '6', '2', '0', '1', '3', '2', '6', '6', '1', '7', '0', '1', '7', '6', '9', '9', '9', '5', '8']), .str (String.ofList ['2', '9', '0', '9', '3', '0', '0', '6', '3', '6', '1', '4', '8', '2', '3', '5', '8', '0', '0', '3', '7']), .str (String.ofList ['3', '5', '4', '3', '2', '2', '4', '2', '5', '1', '6', '5', '9', '7', '6', '4', '3', '9', '0', '4', '8']), .str (String.ofList ['2', '4', '7', '8', '2', '5', '6', '9', '4', '5', '6', '5', '2', '0', '7', '4', '6', '5', '7', '2', '8']), .str (String.ofList ['3', '0', '9', '7', '8', '0', '5', '2', '9', '4', '3', '7', '8', '9', '3', '3', '6', '4', '7', '1', '0']), .str (String.ofList ['1', '1', '7', '3', '7', '8', '2', '9', '7', '3', '5', '4', '7', '2', '1', '6', '3', '6', '3', '2', '9', '9']), .str (String.ofList ['2', '9', '0', '3', '6', '9', '0', '1', '7', '7', '1', '4', '4', '1', '0', '0', '1', '8', '2', '0', '9']), .str (String.ofList ['4', '6', '8', '5', '6', '8', '5', '0', '3', '0', '4', '3', '2', '3', '2', '9', '5', '0', '0', '0', '0']), .str (String.ofList ['2', '6', '7', '9', '8', '3', '1', '7', '3', '9', '4', '8', '4', '1', '8', '9', '5', '7', '5', '3', '5'])]), (String.ofList ['o', 'l', 'd', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6'], .str (String.ofList ['6', '5', '8', '5', '0', '7', '1', '1', '7', '1', '1', '5', '6', '9', '1', '2', '2'])), (String.ofList ['n', 'e', 'w', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6'], .str (String.ofList ['6', '6', '0', '7', '8', '0', '4', '8', '6', '3', '5', '2', '5', '7', '2', '5', '8']))]) :: (acc)

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_chunk_098_before_generic"
  err.flush

theorem array_moment_records_chunk_098 (fuel : Nat) (tail : List Char) (acc : List SourceJson) :
    SourceJson.array (fuel + 52)
      (SourceJson.white (momentRecordsChunk098Chars ++ tail)) acc =
      SourceJson.array (fuel + 51) (SourceJson.white tail) (momentRecordsChunk098Push acc) := by rfl

noncomputable def momentRecordsAcc099 : List SourceJson := momentRecordsChunk098Push momentRecordsAcc098

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_chunk_098_generic_complete"
  err.flush

noncomputable def momentRecordsChunk099Chars : List Char := ['\r', '\n', ' ', ' ', ' ', ' ', '{', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 's', 'i', 'm', 'p', 'l', 'e', 'x', '_', 'i', 'd', '"', ':', ' ', '9', '9', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'l', 'o', 'g', '_', 'g', 'a', 'p', '_', 'f', 'a', 'c', 't', 'o', 'r', '_', 'f', 'l', 'o', 'o', 'r', 's', '_', 'Q', '8', '0', '"', ':', ' ', '[', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '4', '1', '6', '2', '9', '9', '0', '2', '5', '5', '2', '4', '5', '6', '5', '4', '5', '0', '4', '8', '4', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '4', '2', '9', '4', '9', '0', '4', '5', '7', '2', '6', '2', '7', '4', '6', '7', '3', '4', '3', '0', '6', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '7', '5', '3', '8', '2', '7', '8', '0', '2', '1', '7', '0', '3', '5', '4', '4', '6', '2', '9', '7', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '3', '9', '1', '5', '0', '5', '5', '3', '1', '0', '8', '8', '7', '6', '0', '9', '0', '8', '6', '2', '7', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '7', '2', '7', '9', '8', '0', '4', '5', '3', '5', '1', '8', '2', '5', '7', '5', '7', '8', '7', '3', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '4', '2', '3', '5', '2', '9', '3', '0', '5', '3', '0', '9', '4', '1', '0', '2', '6', '9', '2', '8', '3', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '1', '2', '6', '7', '9', '2', '4', '8', '4', '6', '8', '3', '7', '7', '0', '9', '5', '4', '7', '6', '9', '7', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '5', '3', '5', '0', '4', '6', '1', '7', '1', '9', '7', '2', '1', '9', '8', '6', '0', '8', '6', '2', '6', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '7', '4', '8', '6', '2', '1', '8', '1', '4', '3', '0', '0', '8', '2', '9', '3', '9', '0', '8', '1', '4', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '3', '4', '4', '9', '5', '9', '5', '3', '7', '3', '6', '6', '6', '6', '0', '4', '7', '9', '6', '8', '9', '"', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ']', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'o', 'l', 'd', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6', '"', ':', ' ', '"', '3', '2', '2', '9', '3', '5', '7', '4', '2', '2', '1', '3', '8', '7', '1', '1', '8', '7', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'n', 'e', 'w', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6', '"', ':', ' ', '"', '3', '2', '4', '3', '0', '2', '4', '5', '4', '2', '4', '1', '4', '5', '2', '5', '5', '4', '"', '\r', '\n', ' ', ' ', ' ', ' ', '}', ',']
noncomputable def momentRecordsChunk099Push (acc : List SourceJson) : List SourceJson :=
  (.obj [(String.ofList ['s', 'i', 'm', 'p', 'l', 'e', 'x', '_', 'i', 'd'], .number (String.ofList ['9', '9'])), (String.ofList ['l', 'o', 'g', '_', 'g', 'a', 'p', '_', 'f', 'a', 'c', 't', 'o', 'r', '_', 'f', 'l', 'o', 'o', 'r', 's', '_', 'Q', '8', '0'], .arr [.str (String.ofList ['4', '1', '6', '2', '9', '9', '0', '2', '5', '5', '2', '4', '5', '6', '5', '4', '5', '0', '4', '8', '4']), .str (String.ofList ['4', '2', '9', '4', '9', '0', '4', '5', '7', '2', '6', '2', '7', '4', '6', '7', '3', '4', '3', '0', '6']), .str (String.ofList ['2', '7', '5', '3', '8', '2', '7', '8', '0', '2', '1', '7', '0', '3', '5', '4', '4', '6', '2', '9', '7']), .str (String.ofList ['3', '9', '1', '5', '0', '5', '5', '3', '1', '0', '8', '8', '7', '6', '0', '9', '0', '8', '6', '2', '7']), .str (String.ofList ['2', '7', '2', '7', '9', '8', '0', '4', '5', '3', '5', '1', '8', '2', '5', '7', '5', '7', '8', '7', '3']), .str (String.ofList ['4', '2', '3', '5', '2', '9', '3', '0', '5', '3', '0', '9', '4', '1', '0', '2', '6', '9', '2', '8', '3']), .str (String.ofList ['1', '2', '6', '7', '9', '2', '4', '8', '4', '6', '8', '3', '7', '7', '0', '9', '5', '4', '7', '6', '9', '7']), .str (String.ofList ['5', '3', '5', '0', '4', '6', '1', '7', '1', '9', '7', '2', '1', '9', '8', '6', '0', '8', '6', '2', '6']), .str (String.ofList ['7', '4', '8', '6', '2', '1', '8', '1', '4', '3', '0', '0', '8', '2', '9', '3', '9', '0', '8', '1', '4']), .str (String.ofList ['3', '4', '4', '9', '5', '9', '5', '3', '7', '3', '6', '6', '6', '6', '0', '4', '7', '9', '6', '8', '9'])]), (String.ofList ['o', 'l', 'd', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6'], .str (String.ofList ['3', '2', '2', '9', '3', '5', '7', '4', '2', '2', '1', '3', '8', '7', '1', '1', '8', '7'])), (String.ofList ['n', 'e', 'w', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6'], .str (String.ofList ['3', '2', '4', '3', '0', '2', '4', '5', '4', '2', '4', '1', '4', '5', '2', '5', '5', '4']))]) :: (acc)

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_chunk_099_before_generic"
  err.flush

theorem array_moment_records_chunk_099 (fuel : Nat) (tail : List Char) (acc : List SourceJson) :
    SourceJson.array (fuel + 51)
      (SourceJson.white (momentRecordsChunk099Chars ++ tail)) acc =
      SourceJson.array (fuel + 50) (SourceJson.white tail) (momentRecordsChunk099Push acc) := by rfl

noncomputable def momentRecordsAcc100 : List SourceJson := momentRecordsChunk099Push momentRecordsAcc099

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_chunk_099_generic_complete"
  err.flush

noncomputable def momentRecordsBlock024Chars : List Char := momentRecordsChunk096Chars ++ momentRecordsChunk097Chars ++ momentRecordsChunk098Chars ++ momentRecordsChunk099Chars
noncomputable def momentRecordsBlock024Push (acc : List SourceJson) : List SourceJson := momentRecordsChunk099Push (momentRecordsChunk098Push (momentRecordsChunk097Push (momentRecordsChunk096Push (acc))))

theorem array_moment_records_block_024 (fuel : Nat) (tail : List Char) (acc : List SourceJson) :
    SourceJson.array (fuel + 54)
      (SourceJson.white (momentRecordsBlock024Chars ++ tail)) acc =
      SourceJson.array (fuel + 50) (SourceJson.white tail) (momentRecordsBlock024Push acc) := by
  have hinput : momentRecordsBlock024Chars ++ tail = momentRecordsChunk096Chars ++ (momentRecordsChunk097Chars ++ (momentRecordsChunk098Chars ++ (momentRecordsChunk099Chars ++ (tail)))) := by
    simp only [momentRecordsBlock024Chars, List.append_assoc]
  calc
    SourceJson.array (fuel + 54) (SourceJson.white (momentRecordsBlock024Chars ++ tail)) acc =
        SourceJson.array (fuel + 54) (SourceJson.white (momentRecordsChunk096Chars ++ (momentRecordsChunk097Chars ++ (momentRecordsChunk098Chars ++ (momentRecordsChunk099Chars ++ (tail)))))) acc :=
      congrArg (fun s => SourceJson.array (fuel + 54) (SourceJson.white s) acc) hinput
    _ = SourceJson.array (fuel + 53) (SourceJson.white (momentRecordsChunk097Chars ++ (momentRecordsChunk098Chars ++ (momentRecordsChunk099Chars ++ (tail))))) (momentRecordsChunk096Push (acc)) := array_moment_records_chunk_096 fuel (momentRecordsChunk097Chars ++ (momentRecordsChunk098Chars ++ (momentRecordsChunk099Chars ++ (tail)))) (acc)
    _ = SourceJson.array (fuel + 52) (SourceJson.white (momentRecordsChunk098Chars ++ (momentRecordsChunk099Chars ++ (tail)))) (momentRecordsChunk097Push (momentRecordsChunk096Push (acc))) := array_moment_records_chunk_097 fuel (momentRecordsChunk098Chars ++ (momentRecordsChunk099Chars ++ (tail))) (momentRecordsChunk096Push (acc))
    _ = SourceJson.array (fuel + 51) (SourceJson.white (momentRecordsChunk099Chars ++ (tail))) (momentRecordsChunk098Push (momentRecordsChunk097Push (momentRecordsChunk096Push (acc)))) := array_moment_records_chunk_098 fuel (momentRecordsChunk099Chars ++ (tail)) (momentRecordsChunk097Push (momentRecordsChunk096Push (acc)))
    _ = SourceJson.array (fuel + 50) (SourceJson.white tail) (momentRecordsBlock024Push acc) := array_moment_records_chunk_099 fuel (tail) (momentRecordsChunk098Push (momentRecordsChunk097Push (momentRecordsChunk096Push (acc))))

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_block_024_before_raw_binding"
  err.flush

theorem moment_records_block_024_prefix :
    (momentRest06 49624).take 2064 = momentRecordsBlock024Chars := by rfl

theorem moment_records_block_024_split :
    momentRest06 49624 = momentRecordsBlock024Chars ++ momentRest06 51688 := by
  calc
    momentRest06 49624 =
        (momentRest06 49624).take 2064 ++ (momentRest06 49624).drop 2064 :=
      (List.take_append_drop 2064 (momentRest06 49624)).symm
    _ = momentRecordsBlock024Chars ++ (momentRest06 49624).drop 2064 :=
      congrArg (fun p => p ++ (momentRest06 49624).drop 2064) moment_records_block_024_prefix
    _ = momentRecordsBlock024Chars ++ momentRest06 51688 :=
      congrArg (fun rest => momentRecordsBlock024Chars ++ rest) (momentRest06_drop 49624 2064)

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_block_024_after_raw_binding"
  err.flush

theorem array_moment_records_original_block_024 (fuel : Nat) (acc : List SourceJson) :
    SourceJson.array (fuel + 54)
      (SourceJson.white (momentRest06 49624)) acc =
      SourceJson.array (fuel + 50) (SourceJson.white (momentRest06 51688)) (momentRecordsBlock024Push acc) := by
  exact (congrArg (fun s => SourceJson.array (fuel + 54) (SourceJson.white s) acc)
      moment_records_block_024_split).trans (array_moment_records_block_024 fuel (momentRest06 51688) acc)

theorem moment_records_through_block_024 (fuel : Nat) :
    SourceJson.array (fuel + 150)
      (SourceJson.white (momentRest06 364)) [] =
      SourceJson.array (fuel + 50) (SourceJson.white (momentRest06 51688)) momentRecordsAcc100 := by
  exact (moment_records_through_block_023 fuel).trans (array_moment_records_original_block_024 fuel momentRecordsAcc096)

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_block_024_complete"
  err.flush

#print axioms array_moment_records_chunk_096
#print axioms array_moment_records_chunk_097
#print axioms array_moment_records_chunk_098
#print axioms array_moment_records_chunk_099
#print axioms array_moment_records_block_024
#print axioms moment_records_block_024_prefix
#print axioms moment_records_block_024_split
#print axioms array_moment_records_original_block_024
#print axioms moment_records_through_block_024

end ImbalancedChen.P2OriginalSaving19Moment06Parsing
