/- SOURCE_CANDIDATE: original Cell06 source only. No Lean compilation,
independent kernel replay, full-owned audit or formal acceptance is claimed. -/

import ImbalancedChen.P2OriginalSaving19Moment06DecodedBlock017
import ImbalancedChen.P2OriginalSaving19Moment06RecordsBlock018

/-! Original typed moment records 72 through 75; each concrete value is checked by original decodeMomentRecord.
Candidate quotations preserve exact original raw bytes. The Lean equations bind
them to the production-compatible packed input and run the unchanged reader.
This local input resolves inside this private project, not the P1 filesystem. -/
namespace ImbalancedChen.P2OriginalSaving19Moment06Decoding
set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false
open ImbalancedChen.P2OriginalSaving19Archive

open ImbalancedChen.P2OriginalSaving19Moment06Parsing

noncomputable def momentJsonRecord072 : SourceJson :=
  (momentRecordsChunk072Push []).head (List.cons_ne_nil _ _)

theorem moment_record_072_push_eq (acc : List SourceJson) :
    momentRecordsChunk072Push acc = momentJsonRecord072 :: acc := by rfl

noncomputable def momentTypedRecord072 : MomentRecord :=
  { simplexId := 72,
    factorFloorsQ80 := #[(184803688761533760254 : Int), (255022812170743438954 : Int), (282075117707995360053 : Int), (240386292669816077968 : Int), (207853001420816652834 : Int), (229401666312115923368 : Int), (1255591023991142896332 : Int), (697800753330063137216 : Int), (822826093354899269699 : Int), (190675868812977367307 : Int)],
    oldFloorQ96 := (4610988958948 : Int),
    newFloorQ96 := (4627673186109 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_072_before_decode"
  err.flush

theorem decode_moment_record_072 :
    decodeMomentRecord momentJsonRecord072 = .ok momentTypedRecord072 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_072_decoded"
  err.flush

noncomputable def momentJsonRecord073 : SourceJson :=
  (momentRecordsChunk073Push []).head (List.cons_ne_nil _ _)

theorem moment_record_073_push_eq (acc : List SourceJson) :
    momentRecordsChunk073Push acc = momentJsonRecord073 :: acc := by rfl

noncomputable def momentTypedRecord073 : MomentRecord :=
  { simplexId := 73,
    factorFloorsQ80 := #[(203830256414141659669 : Int), (259101487761199542286 : Int), (265449841885732460591 : Int), (287108584742765437358 : Int), (249863913205518922888 : Int), (364200617174908952685 : Int), (1282944135981821756635 : Int), (1036113142408593508039 : Int), (1203731225763027861314 : Int), (232806111996912394653 : Int)],
    oldFloorQ96 := (22596243686302 : Int),
    newFloorQ96 := (22697122968700 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_073_before_decode"
  err.flush

theorem decode_moment_record_073 :
    decodeMomentRecord momentJsonRecord073 = .ok momentTypedRecord073 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_073_decoded"
  err.flush

noncomputable def momentJsonRecord074 : SourceJson :=
  (momentRecordsChunk074Push []).head (List.cons_ne_nil _ _)

theorem moment_record_074_push_eq (acc : List SourceJson) :
    momentRecordsChunk074Push acc = momentJsonRecord074 :: acc := by rfl

noncomputable def momentTypedRecord074 : MomentRecord :=
  { simplexId := 74,
    factorFloorsQ80 := #[(140442025692269742014 : Int), (240715992749187704892 : Int), (267213913950948871952 : Int), (154100174583201770726 : Int), (130603799233155244027 : Int), (120117694582002179823 : Int), (691556007042900264608 : Int), (700399829364226820623 : Int), (842753072414769298533 : Int), (203528911424459681046 : Int)],
    oldFloorQ96 := (3049426663732 : Int),
    newFloorQ96 := (3058246272847 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_074_before_decode"
  err.flush

theorem decode_moment_record_074 :
    decodeMomentRecord momentJsonRecord074 = .ok momentTypedRecord074 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_074_decoded"
  err.flush

noncomputable def momentJsonRecord075 : SourceJson :=
  (momentRecordsChunk075Push []).head (List.cons_ne_nil _ _)

theorem moment_record_075_push_eq (acc : List SourceJson) :
    momentRecordsChunk075Push acc = momentJsonRecord075 :: acc := by rfl

noncomputable def momentTypedRecord075 : MomentRecord :=
  { simplexId := 75,
    factorFloorsQ80 := #[(148270713021285678938 : Int), (224983061741475687054 : Int), (251715819562141461703 : Int), (209282867405550565449 : Int), (181535997873575752426 : Int), (300671639422981812739 : Int), (794045496729768592239 : Int), (995962430486031282752 : Int), (1174093636697800843572 : Int), (228161982211731777149 : Int)],
    oldFloorQ96 := (15485710485448 : Int),
    newFloorQ96 := (15543572720727 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_075_before_decode"
  err.flush

theorem decode_moment_record_075 :
    decodeMomentRecord momentJsonRecord075 = .ok momentTypedRecord075 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_075_decoded"
  err.flush

noncomputable def momentJsonRecordsBlock018 : List SourceJson := [momentJsonRecord072, momentJsonRecord073, momentJsonRecord074, momentJsonRecord075]
noncomputable def momentTypedRecordsBlock018 : List MomentRecord := [momentTypedRecord072, momentTypedRecord073, momentTypedRecord074, momentTypedRecord075]

theorem moment_records_block_018_push_eq (acc : List SourceJson) :
    momentRecordsBlock018Push acc = [momentJsonRecord075, momentJsonRecord074, momentJsonRecord073, momentJsonRecord072] ++ acc := by rfl

theorem moment_records_block_018_reverse (acc : List SourceJson) :
    (momentRecordsBlock018Push acc).reverse = acc.reverse ++ momentJsonRecordsBlock018 := by
  rw [moment_records_block_018_push_eq, List.reverse_append]
  rfl

theorem decode_moment_records_block_018 :
    momentJsonRecordsBlock018.mapM decodeMomentRecord = .ok momentTypedRecordsBlock018 := by
  simp only [momentJsonRecordsBlock018, momentTypedRecordsBlock018, List.mapM_cons, List.mapM_nil,
    decode_moment_record_072, decode_moment_record_073, decode_moment_record_074, decode_moment_record_075]
  rfl

noncomputable def momentTypedRowsThroughBlock018 : List MomentRecord := momentTypedRowsThroughBlock017 ++ momentTypedRecordsBlock018

theorem decode_moment_records_through_block_018 :
    momentRecordsAcc076.reverse.mapM decodeMomentRecord = .ok momentTypedRowsThroughBlock018 := by
  change (momentRecordsBlock018Push momentRecordsAcc072).reverse.mapM decodeMomentRecord = _
  rw [moment_records_block_018_reverse]
  rw [List.mapM_append, decode_moment_records_through_block_017, decode_moment_records_block_018]
  rfl

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_block_018_complete"
  err.flush

#print axioms moment_record_072_push_eq
#print axioms decode_moment_record_072
#print axioms moment_record_073_push_eq
#print axioms decode_moment_record_073
#print axioms moment_record_074_push_eq
#print axioms decode_moment_record_074
#print axioms moment_record_075_push_eq
#print axioms decode_moment_record_075
#print axioms moment_records_block_018_push_eq
#print axioms moment_records_block_018_reverse
#print axioms decode_moment_records_block_018
#print axioms decode_moment_records_through_block_018

end ImbalancedChen.P2OriginalSaving19Moment06Decoding
