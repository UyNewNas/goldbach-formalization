/- SOURCE_CANDIDATE: original Cell06 source only. No Lean compilation,
independent kernel replay, full-owned audit or formal acceptance is claimed. -/

import ImbalancedChen.P2OriginalSaving19MomentParseDecodeBridge
import ImbalancedChen.P2OriginalSaving19Moment06DecodeFromRows
import ImbalancedChen.P2OriginalSaving19Moment06DecodedBlock028

/-! Complete original moment06 parse followed by the unchanged decodeMoments returns this concrete Moments value.
Candidate quotations preserve exact original raw bytes. The Lean equations bind
them to the production-compatible packed input and run the unchanged reader.
This local input resolves inside this private project, not the P1 filesystem. -/
namespace ImbalancedChen.P2OriginalSaving19Moment06Decoding
set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false
open ImbalancedChen.P2OriginalSaving19Archive

open ImbalancedChen.P2OriginalSaving19Moment06Parsing

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_whole_before_concrete_value"
  err.flush

noncomputable def momentConcrete06 : Moments :=
  momentMomentsWithRows momentTypedRowsThroughBlock028.toArray

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_whole_after_concrete_value"
  err.flush

theorem decode_momentRootValue : decodeMoments momentRootValue = .ok momentConcrete06 :=
  decodeMoments_of_records_decode momentRecordsAcc113.reverse momentTypedRowsThroughBlock028
    decode_moment_records_through_block_028

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_whole_after_opaque_decoder_application"
  err.flush

theorem momentPacked06_parse_decode :
    (SourceJson.parse (String.ofList momentPacked06.toList) >>= decodeMoments) =
      .ok momentConcrete06 :=
  P2OriginalSaving19MomentParseDecodeBridge.parse_decode_of_parse_and_decode
    (String.ofList momentPacked06.toList) momentRootValue momentConcrete06
    momentPacked06_parse decode_momentRootValue

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 whole_original_typed_moments_complete"
  err.flush

#print axioms decode_momentRootValue
#print axioms momentPacked06_parse_decode

end ImbalancedChen.P2OriginalSaving19Moment06Decoding
