/- SOURCE_CANDIDATE: original Cell06 source only. No Lean compilation,
independent kernel replay, full-owned audit or formal acceptance is claimed. -/

import ImbalancedChen.P2OriginalSaving19Moment06DecodedBlock006
import ImbalancedChen.P2OriginalSaving19Moment06RecordsBlock007

/-! Original typed moment records 28 through 31; each concrete value is checked by original decodeMomentRecord.
Candidate quotations preserve exact original raw bytes. The Lean equations bind
them to the production-compatible packed input and run the unchanged reader.
This local input resolves inside this private project, not the P1 filesystem. -/
namespace ImbalancedChen.P2OriginalSaving19Moment06Decoding
set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false
open ImbalancedChen.P2OriginalSaving19Archive

open ImbalancedChen.P2OriginalSaving19Moment06Parsing

noncomputable def momentJsonRecord028 : SourceJson :=
  (momentRecordsChunk028Push []).head (List.cons_ne_nil _ _)

theorem moment_record_028_push_eq (acc : List SourceJson) :
    momentRecordsChunk028Push acc = momentJsonRecord028 :: acc := by rfl

noncomputable def momentTypedRecord028 : MomentRecord :=
  { simplexId := 28,
    factorFloorsQ80 := #[(416629525658277382260 : Int), (393044582261200082716 : Int), (205066282584041927837 : Int), (315761759105920564472 : Int), (301256874882388674706 : Int), (359532883741162338083 : Int), (1347114062452630385072 : Int), (504657508482250239084 : Int), (727767319489508507187 : Int), (258225966240188484454 : Int)],
    oldFloorQ96 := (33562888435999 : Int),
    newFloorQ96 := (33697223587488 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_028_before_decode"
  err.flush

theorem decode_moment_record_028 :
    decodeMomentRecord momentJsonRecord028 = .ok momentTypedRecord028 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_028_decoded"
  err.flush

noncomputable def momentJsonRecord029 : SourceJson :=
  (momentRecordsChunk029Push []).head (List.cons_ne_nil _ _)

theorem moment_record_029_push_eq (acc : List SourceJson) :
    momentRecordsChunk029Push acc = momentJsonRecord029 :: acc := by rfl

noncomputable def momentTypedRecord029 : MomentRecord :=
  { simplexId := 29,
    factorFloorsQ80 := #[(351623540741439210474 : Int), (323445190798211584152 : Int), (214814314140420932737 : Int), (305791664012494755504 : Int), (305022475255297970170 : Int), (308880778209079438624 : Int), (905174232367662624626 : Int), (355589003650336039457 : Int), (444591011282857917408 : Int), (153003163360837069089 : Int)],
    oldFloorQ96 := (229707602799475887 : Int),
    newFloorQ96 := (230405604357765325 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_029_before_decode"
  err.flush

theorem decode_moment_record_029 :
    decodeMomentRecord momentJsonRecord029 = .ok momentTypedRecord029 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_029_decoded"
  err.flush

noncomputable def momentJsonRecord030 : SourceJson :=
  (momentRecordsChunk030Push []).head (List.cons_ne_nil _ _)

theorem moment_record_030_push_eq (acc : List SourceJson) :
    momentRecordsChunk030Push acc = momentJsonRecord030 :: acc := by rfl

noncomputable def momentTypedRecord030 : MomentRecord :=
  { simplexId := 30,
    factorFloorsQ80 := #[(416632594277129589595 : Int), (393046581641850706008 : Int), (205066038916369448725 : Int), (315762608159756645349 : Int), (301257540912861908279 : Int), (359531923272999950439 : Int), (922320976211752459470 : Int), (484273257900605220738 : Int), (727783505246095785949 : Int), (258226491947034679527 : Int)],
    oldFloorQ96 := (490605778859655787 : Int),
    newFloorQ96 := (492388081576948986 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_030_before_decode"
  err.flush

theorem decode_moment_record_030 :
    decodeMomentRecord momentJsonRecord030 = .ok momentTypedRecord030 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_030_decoded"
  err.flush

noncomputable def momentJsonRecord031 : SourceJson :=
  (momentRecordsChunk031Push []).head (List.cons_ne_nil _ _)

theorem moment_record_031_push_eq (acc : List SourceJson) :
    momentRecordsChunk031Push acc = momentJsonRecord031 :: acc := by rfl

noncomputable def momentTypedRecord031 : MomentRecord :=
  { simplexId := 31,
    factorFloorsQ80 := #[(324642967318898525910 : Int), (339675870243440935224 : Int), (205596251933408582235 : Int), (301517521301172741142 : Int), (296462316739076473355 : Int), (310546377985712368790 : Int), (908011976233680048721 : Int), (354588873858575389392 : Int), (375982418008682318780 : Int), (152409304464295663995 : Int)],
    oldFloorQ96 := (160281659616764541 : Int),
    newFloorQ96 := (160755601203006773 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_031_before_decode"
  err.flush

theorem decode_moment_record_031 :
    decodeMomentRecord momentJsonRecord031 = .ok momentTypedRecord031 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_031_decoded"
  err.flush

noncomputable def momentJsonRecordsBlock007 : List SourceJson := [momentJsonRecord028, momentJsonRecord029, momentJsonRecord030, momentJsonRecord031]
noncomputable def momentTypedRecordsBlock007 : List MomentRecord := [momentTypedRecord028, momentTypedRecord029, momentTypedRecord030, momentTypedRecord031]

theorem moment_records_block_007_push_eq (acc : List SourceJson) :
    momentRecordsBlock007Push acc = [momentJsonRecord031, momentJsonRecord030, momentJsonRecord029, momentJsonRecord028] ++ acc := by rfl

theorem moment_records_block_007_reverse (acc : List SourceJson) :
    (momentRecordsBlock007Push acc).reverse = acc.reverse ++ momentJsonRecordsBlock007 := by
  rw [moment_records_block_007_push_eq, List.reverse_append]
  rfl

theorem decode_moment_records_block_007 :
    momentJsonRecordsBlock007.mapM decodeMomentRecord = .ok momentTypedRecordsBlock007 := by
  simp only [momentJsonRecordsBlock007, momentTypedRecordsBlock007, List.mapM_cons, List.mapM_nil,
    decode_moment_record_028, decode_moment_record_029, decode_moment_record_030, decode_moment_record_031]
  rfl

noncomputable def momentTypedRowsThroughBlock007 : List MomentRecord := momentTypedRowsThroughBlock006 ++ momentTypedRecordsBlock007

theorem decode_moment_records_through_block_007 :
    momentRecordsAcc032.reverse.mapM decodeMomentRecord = .ok momentTypedRowsThroughBlock007 := by
  change (momentRecordsBlock007Push momentRecordsAcc028).reverse.mapM decodeMomentRecord = _
  rw [moment_records_block_007_reverse]
  rw [List.mapM_append, decode_moment_records_through_block_006, decode_moment_records_block_007]
  rfl

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_block_007_complete"
  err.flush

#print axioms moment_record_028_push_eq
#print axioms decode_moment_record_028
#print axioms moment_record_029_push_eq
#print axioms decode_moment_record_029
#print axioms moment_record_030_push_eq
#print axioms decode_moment_record_030
#print axioms moment_record_031_push_eq
#print axioms decode_moment_record_031
#print axioms moment_records_block_007_push_eq
#print axioms moment_records_block_007_reverse
#print axioms decode_moment_records_block_007
#print axioms decode_moment_records_through_block_007

end ImbalancedChen.P2OriginalSaving19Moment06Decoding
