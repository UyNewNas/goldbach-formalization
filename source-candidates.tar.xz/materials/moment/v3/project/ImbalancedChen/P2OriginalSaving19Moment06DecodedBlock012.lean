/- SOURCE_CANDIDATE: original Cell06 source only. No Lean compilation,
independent kernel replay, full-owned audit or formal acceptance is claimed. -/

import ImbalancedChen.P2OriginalSaving19Moment06DecodedBlock011
import ImbalancedChen.P2OriginalSaving19Moment06RecordsBlock012

/-! Original typed moment records 48 through 51; each concrete value is checked by original decodeMomentRecord.
Candidate quotations preserve exact original raw bytes. The Lean equations bind
them to the production-compatible packed input and run the unchanged reader.
This local input resolves inside this private project, not the P1 filesystem. -/
namespace ImbalancedChen.P2OriginalSaving19Moment06Decoding
set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false
open ImbalancedChen.P2OriginalSaving19Archive

open ImbalancedChen.P2OriginalSaving19Moment06Parsing

noncomputable def momentJsonRecord048 : SourceJson :=
  (momentRecordsChunk048Push []).head (List.cons_ne_nil _ _)

theorem moment_record_048_push_eq (acc : List SourceJson) :
    momentRecordsChunk048Push acc = momentJsonRecord048 :: acc := by rfl

noncomputable def momentTypedRecord048 : MomentRecord :=
  { simplexId := 48,
    factorFloorsQ80 := #[(355578606123941076276 : Int), (320458748813885203526 : Int), (278561708196421008866 : Int), (291852924223594617627 : Int), (240533013159751132841 : Int), (207443950858057497543 : Int), (312848127913143541571 : Int), (290402603753937069532 : Int), (461421998550779492636 : Int), (157929847228648675929 : Int)],
    oldFloorQ96 := (5866808700330998 : Int),
    newFloorQ96 := (5880981885455468 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_048_before_decode"
  err.flush

theorem decode_moment_record_048 :
    decodeMomentRecord momentJsonRecord048 = .ok momentTypedRecord048 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_048_decoded"
  err.flush

noncomputable def momentJsonRecord049 : SourceJson :=
  (momentRecordsChunk049Push []).head (List.cons_ne_nil _ _)

theorem moment_record_049_push_eq (acc : List SourceJson) :
    momentRecordsChunk049Push acc = momentJsonRecord049 :: acc := by rfl

noncomputable def momentTypedRecord049 : MomentRecord :=
  { simplexId := 49,
    factorFloorsQ80 := #[(360848457830188206577 : Int), (320266673133081333452 : Int), (258213324296644979570 : Int), (340459786151043131746 : Int), (282190502742302572129 : Int), (284588474648588712064 : Int), (1129471920501532647654 : Int), (349357427141325778222 : Int), (473698510250468647440 : Int), (158231944326749876566 : Int)],
    oldFloorQ96 := (46270793998468233 : Int),
    newFloorQ96 := (46422506108155505 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_049_before_decode"
  err.flush

theorem decode_moment_record_049 :
    decodeMomentRecord momentJsonRecord049 = .ok momentTypedRecord049 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_049_decoded"
  err.flush

noncomputable def momentJsonRecord050 : SourceJson :=
  (momentRecordsChunk050Push []).head (List.cons_ne_nil _ _)

theorem moment_record_050_push_eq (acc : List SourceJson) :
    momentRecordsChunk050Push acc = momentJsonRecord050 :: acc := by rfl

noncomputable def momentTypedRecord050 : MomentRecord :=
  { simplexId := 50,
    factorFloorsQ80 := #[(417369691433872027144 : Int), (395714087636648829459 : Int), (244798866146284697607 : Int), (360732467240258726279 : Int), (296794387255727050775 : Int), (376664980624001336795 : Int), (1206888877506838011411 : Int), (559720476570904100722 : Int), (761224191820376953820 : Int), (263531596380157980757 : Int)],
    oldFloorQ96 := (226907734806533548 : Int),
    newFloorQ96 := (227826179326572170 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_050_before_decode"
  err.flush

theorem decode_moment_record_050 :
    decodeMomentRecord momentJsonRecord050 = .ok momentTypedRecord050 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_050_decoded"
  err.flush

noncomputable def momentJsonRecord051 : SourceJson :=
  (momentRecordsChunk051Push []).head (List.cons_ne_nil _ _)

theorem moment_record_051_push_eq (acc : List SourceJson) :
    momentRecordsChunk051Push acc = momentJsonRecord051 :: acc := by rfl

noncomputable def momentTypedRecord051 : MomentRecord :=
  { simplexId := 51,
    factorFloorsQ80 := #[(275944335116654897998 : Int), (302065344805804428208 : Int), (338972317031080166404 : Int), (191627149497688360200 : Int), (158252593008416597074 : Int), (189918288097343649917 : Int), (361422258762058166306 : Int), (317803273027814890199 : Int), (491637080691995522307 : Int), (160618179515623109106 : Int)],
    oldFloorQ96 := (114418656162 : Int),
    newFloorQ96 := (114682855369 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_051_before_decode"
  err.flush

theorem decode_moment_record_051 :
    decodeMomentRecord momentJsonRecord051 = .ok momentTypedRecord051 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_051_decoded"
  err.flush

noncomputable def momentJsonRecordsBlock012 : List SourceJson := [momentJsonRecord048, momentJsonRecord049, momentJsonRecord050, momentJsonRecord051]
noncomputable def momentTypedRecordsBlock012 : List MomentRecord := [momentTypedRecord048, momentTypedRecord049, momentTypedRecord050, momentTypedRecord051]

theorem moment_records_block_012_push_eq (acc : List SourceJson) :
    momentRecordsBlock012Push acc = [momentJsonRecord051, momentJsonRecord050, momentJsonRecord049, momentJsonRecord048] ++ acc := by rfl

theorem moment_records_block_012_reverse (acc : List SourceJson) :
    (momentRecordsBlock012Push acc).reverse = acc.reverse ++ momentJsonRecordsBlock012 := by
  rw [moment_records_block_012_push_eq, List.reverse_append]
  rfl

theorem decode_moment_records_block_012 :
    momentJsonRecordsBlock012.mapM decodeMomentRecord = .ok momentTypedRecordsBlock012 := by
  simp only [momentJsonRecordsBlock012, momentTypedRecordsBlock012, List.mapM_cons, List.mapM_nil,
    decode_moment_record_048, decode_moment_record_049, decode_moment_record_050, decode_moment_record_051]
  rfl

noncomputable def momentTypedRowsThroughBlock012 : List MomentRecord := momentTypedRowsThroughBlock011 ++ momentTypedRecordsBlock012

theorem decode_moment_records_through_block_012 :
    momentRecordsAcc052.reverse.mapM decodeMomentRecord = .ok momentTypedRowsThroughBlock012 := by
  change (momentRecordsBlock012Push momentRecordsAcc048).reverse.mapM decodeMomentRecord = _
  rw [moment_records_block_012_reverse]
  rw [List.mapM_append, decode_moment_records_through_block_011, decode_moment_records_block_012]
  rfl

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_block_012_complete"
  err.flush

#print axioms moment_record_048_push_eq
#print axioms decode_moment_record_048
#print axioms moment_record_049_push_eq
#print axioms decode_moment_record_049
#print axioms moment_record_050_push_eq
#print axioms decode_moment_record_050
#print axioms moment_record_051_push_eq
#print axioms decode_moment_record_051
#print axioms moment_records_block_012_push_eq
#print axioms moment_records_block_012_reverse
#print axioms decode_moment_records_block_012
#print axioms decode_moment_records_through_block_012

end ImbalancedChen.P2OriginalSaving19Moment06Decoding
