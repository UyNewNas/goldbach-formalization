/- SOURCE_CANDIDATE: original Cell06 source only. No Lean compilation,
independent kernel replay, full-owned audit or formal acceptance is claimed. -/

import ImbalancedChen.P2OriginalSaving19Moment06RecordsBlock016

/-! Original moment records block 17. Small arbitrary-tail/accumulator parser equations and one exact packed-input binding.
Candidate quotations preserve exact original raw bytes. The Lean equations bind
them to the production-compatible packed input and run the unchanged reader.
This local input resolves inside this private project, not the P1 filesystem. -/
namespace ImbalancedChen.P2OriginalSaving19Moment06Parsing
set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false
open ImbalancedChen.P2OriginalSaving19Archive

noncomputable def momentRecordsChunk068Chars : List Char := ['\r', '\n', ' ', ' ', ' ', ' ', '{', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 's', 'i', 'm', 'p', 'l', 'e', 'x', '_', 'i', 'd', '"', ':', ' ', '6', '8', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'l', 'o', 'g', '_', 'g', 'a', 'p', '_', 'f', 'a', 'c', 't', 'o', 'r', '_', 'f', 'l', 'o', 'o', 'r', 's', '_', 'Q', '8', '0', '"', ':', ' ', '[', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '2', '9', '9', '2', '4', '7', '0', '8', '4', '5', '5', '2', '2', '5', '0', '2', '2', '1', '4', '2', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '7', '7', '4', '8', '1', '7', '6', '4', '2', '6', '9', '0', '0', '1', '8', '3', '6', '3', '8', '2', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '9', '8', '1', '9', '5', '0', '8', '4', '0', '6', '3', '3', '9', '8', '2', '5', '6', '2', '2', '9', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '2', '9', '9', '8', '8', '3', '2', '8', '4', '0', '9', '1', '2', '2', '2', '1', '3', '9', '2', '2', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '1', '9', '1', '9', '8', '7', '2', '3', '2', '0', '6', '6', '2', '5', '2', '5', '8', '0', '5', '3', '2', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '1', '4', '1', '3', '7', '3', '5', '2', '3', '6', '5', '3', '9', '7', '7', '6', '2', '1', '3', '4', '9', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '5', '0', '6', '0', '3', '9', '1', '0', '2', '3', '5', '1', '6', '3', '2', '7', '7', '0', '9', '3', '6', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '5', '6', '2', '5', '3', '1', '9', '1', '3', '8', '4', '5', '6', '3', '9', '7', '7', '3', '6', '3', '2', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '6', '7', '8', '2', '0', '4', '8', '9', '6', '8', '3', '8', '7', '3', '4', '4', '5', '8', '8', '5', '7', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '1', '6', '8', '7', '0', '9', '7', '8', '4', '2', '2', '3', '4', '3', '8', '3', '5', '0', '0', '2', '8', '"', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ']', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'o', 'l', 'd', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6', '"', ':', ' ', '"', '4', '4', '9', '9', '3', '5', '9', '4', '3', '7', '5', '3', '1', '0', '1', '0', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'n', 'e', 'w', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6', '"', ':', ' ', '"', '4', '5', '1', '1', '6', '0', '0', '0', '1', '6', '7', '1', '4', '7', '1', '5', '"', '\r', '\n', ' ', ' ', ' ', ' ', '}', ',']
noncomputable def momentRecordsChunk068Push (acc : List SourceJson) : List SourceJson :=
  (.obj [(String.ofList ['s', 'i', 'm', 'p', 'l', 'e', 'x', '_', 'i', 'd'], .number (String.ofList ['6', '8'])), (String.ofList ['l', 'o', 'g', '_', 'g', 'a', 'p', '_', 'f', 'a', 'c', 't', 'o', 'r', '_', 'f', 'l', 'o', 'o', 'r', 's', '_', 'Q', '8', '0'], .arr [.str (String.ofList ['2', '2', '9', '9', '2', '4', '7', '0', '8', '4', '5', '5', '2', '2', '5', '0', '2', '2', '1', '4', '2']), .str (String.ofList ['2', '7', '7', '4', '8', '1', '7', '6', '4', '2', '6', '9', '0', '0', '1', '8', '3', '6', '3', '8', '2']), .str (String.ofList ['2', '9', '8', '1', '9', '5', '0', '8', '4', '0', '6', '3', '3', '9', '8', '2', '5', '6', '2', '2', '9']), .str (String.ofList ['2', '2', '9', '9', '8', '8', '3', '2', '8', '4', '0', '9', '1', '2', '2', '2', '1', '3', '9', '2', '2']), .str (String.ofList ['1', '9', '1', '9', '8', '7', '2', '3', '2', '0', '6', '6', '2', '5', '2', '5', '8', '0', '5', '3', '2']), .str (String.ofList ['1', '4', '1', '3', '7', '3', '5', '2', '3', '6', '5', '3', '9', '7', '7', '6', '2', '1', '3', '4', '9']), .str (String.ofList ['5', '0', '6', '0', '3', '9', '1', '0', '2', '3', '5', '1', '6', '3', '2', '7', '7', '0', '9', '3', '6']), .str (String.ofList ['5', '6', '2', '5', '3', '1', '9', '1', '3', '8', '4', '5', '6', '3', '9', '7', '7', '3', '6', '3', '2']), .str (String.ofList ['6', '7', '8', '2', '0', '4', '8', '9', '6', '8', '3', '8', '7', '3', '4', '4', '5', '8', '8', '5', '7']), .str (String.ofList ['1', '6', '8', '7', '0', '9', '7', '8', '4', '2', '2', '3', '4', '3', '8', '3', '5', '0', '0', '2', '8'])]), (String.ofList ['o', 'l', 'd', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6'], .str (String.ofList ['4', '4', '9', '9', '3', '5', '9', '4', '3', '7', '5', '3', '1', '0', '1', '0'])), (String.ofList ['n', 'e', 'w', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6'], .str (String.ofList ['4', '5', '1', '1', '6', '0', '0', '0', '1', '6', '7', '1', '4', '7', '1', '5']))]) :: (acc)

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_chunk_068_before_generic"
  err.flush

theorem array_moment_records_chunk_068 (fuel : Nat) (tail : List Char) (acc : List SourceJson) :
    SourceJson.array (fuel + 82)
      (SourceJson.white (momentRecordsChunk068Chars ++ tail)) acc =
      SourceJson.array (fuel + 81) (SourceJson.white tail) (momentRecordsChunk068Push acc) := by rfl

noncomputable def momentRecordsAcc069 : List SourceJson := momentRecordsChunk068Push momentRecordsAcc068

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_chunk_068_generic_complete"
  err.flush

noncomputable def momentRecordsChunk069Chars : List Char := ['\r', '\n', ' ', ' ', ' ', ' ', '{', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 's', 'i', 'm', 'p', 'l', 'e', 'x', '_', 'i', 'd', '"', ':', ' ', '6', '9', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'l', 'o', 'g', '_', 'g', 'a', 'p', '_', 'f', 'a', 'c', 't', 'o', 'r', '_', 'f', 'l', 'o', 'o', 'r', 's', '_', 'Q', '8', '0', '"', ':', ' ', '[', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '5', '6', '2', '4', '2', '7', '8', '7', '1', '1', '3', '9', '6', '8', '1', '8', '2', '8', '2', '7', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '7', '6', '6', '5', '0', '9', '0', '0', '9', '4', '8', '7', '5', '3', '7', '9', '4', '8', '6', '2', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '7', '4', '6', '6', '5', '3', '0', '0', '8', '7', '0', '6', '8', '8', '0', '5', '5', '1', '3', '8', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '9', '6', '0', '9', '1', '8', '5', '8', '7', '9', '5', '9', '3', '9', '4', '7', '3', '4', '2', '8', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '5', '1', '7', '8', '6', '7', '3', '2', '9', '1', '4', '2', '1', '2', '0', '9', '7', '7', '4', '6', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '4', '1', '9', '3', '0', '6', '9', '8', '7', '9', '9', '2', '8', '1', '0', '4', '3', '6', '0', '7', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '1', '1', '8', '4', '2', '7', '9', '1', '9', '4', '0', '0', '1', '5', '6', '0', '1', '2', '7', '4', '2', '3', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '5', '9', '5', '4', '8', '5', '9', '1', '3', '2', '1', '6', '6', '1', '7', '1', '3', '7', '9', '5', '1', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '6', '5', '9', '1', '0', '6', '0', '3', '6', '0', '3', '9', '9', '6', '5', '8', '7', '0', '9', '1', '3', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '1', '6', '8', '4', '4', '2', '1', '5', '8', '7', '3', '9', '4', '2', '9', '9', '9', '3', '9', '3', '3', '"', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ']', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'o', 'l', 'd', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6', '"', ':', ' ', '"', '3', '5', '5', '1', '7', '3', '3', '4', '3', '5', '4', '7', '6', '3', '2', '5', '5', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'n', 'e', 'w', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6', '"', ':', ' ', '"', '3', '5', '6', '4', '1', '0', '7', '9', '8', '1', '8', '0', '7', '0', '5', '8', '9', '"', '\r', '\n', ' ', ' ', ' ', ' ', '}', ',']
noncomputable def momentRecordsChunk069Push (acc : List SourceJson) : List SourceJson :=
  (.obj [(String.ofList ['s', 'i', 'm', 'p', 'l', 'e', 'x', '_', 'i', 'd'], .number (String.ofList ['6', '9'])), (String.ofList ['l', 'o', 'g', '_', 'g', 'a', 'p', '_', 'f', 'a', 'c', 't', 'o', 'r', '_', 'f', 'l', 'o', 'o', 'r', 's', '_', 'Q', '8', '0'], .arr [.str (String.ofList ['2', '5', '6', '2', '4', '2', '7', '8', '7', '1', '1', '3', '9', '6', '8', '1', '8', '2', '8', '2', '7']), .str (String.ofList ['2', '7', '6', '6', '5', '0', '9', '0', '0', '9', '4', '8', '7', '5', '3', '7', '9', '4', '8', '6', '2']), .str (String.ofList ['2', '7', '4', '6', '6', '5', '3', '0', '0', '8', '7', '0', '6', '8', '8', '0', '5', '5', '1', '3', '8']), .str (String.ofList ['2', '9', '6', '0', '9', '1', '8', '5', '8', '7', '9', '5', '9', '3', '9', '4', '7', '3', '4', '2', '8']), .str (String.ofList ['2', '5', '1', '7', '8', '6', '7', '3', '2', '9', '1', '4', '2', '1', '2', '0', '9', '7', '7', '4', '6']), .str (String.ofList ['2', '4', '1', '9', '3', '0', '6', '9', '8', '7', '9', '9', '2', '8', '1', '0', '4', '3', '6', '0', '7']), .str (String.ofList ['1', '1', '8', '4', '2', '7', '9', '1', '9', '4', '0', '0', '1', '5', '6', '0', '1', '2', '7', '4', '2', '3']), .str (String.ofList ['5', '9', '5', '4', '8', '5', '9', '1', '3', '2', '1', '6', '6', '1', '7', '1', '3', '7', '9', '5', '1']), .str (String.ofList ['6', '5', '9', '1', '0', '6', '0', '3', '6', '0', '3', '9', '9', '6', '5', '8', '7', '0', '9', '1', '3']), .str (String.ofList ['1', '6', '8', '4', '4', '2', '1', '5', '8', '7', '3', '9', '4', '2', '9', '9', '9', '3', '9', '3', '3'])]), (String.ofList ['o', 'l', 'd', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6'], .str (String.ofList ['3', '5', '5', '1', '7', '3', '3', '4', '3', '5', '4', '7', '6', '3', '2', '5', '5'])), (String.ofList ['n', 'e', 'w', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6'], .str (String.ofList ['3', '5', '6', '4', '1', '0', '7', '9', '8', '1', '8', '0', '7', '0', '5', '8', '9']))]) :: (acc)

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_chunk_069_before_generic"
  err.flush

theorem array_moment_records_chunk_069 (fuel : Nat) (tail : List Char) (acc : List SourceJson) :
    SourceJson.array (fuel + 81)
      (SourceJson.white (momentRecordsChunk069Chars ++ tail)) acc =
      SourceJson.array (fuel + 80) (SourceJson.white tail) (momentRecordsChunk069Push acc) := by rfl

noncomputable def momentRecordsAcc070 : List SourceJson := momentRecordsChunk069Push momentRecordsAcc069

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_chunk_069_generic_complete"
  err.flush

noncomputable def momentRecordsChunk070Chars : List Char := ['\r', '\n', ' ', ' ', ' ', ' ', '{', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 's', 'i', 'm', 'p', 'l', 'e', 'x', '_', 'i', 'd', '"', ':', ' ', '7', '0', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'l', 'o', 'g', '_', 'g', 'a', 'p', '_', 'f', 'a', 'c', 't', 'o', 'r', '_', 'f', 'l', 'o', 'o', 'r', 's', '_', 'Q', '8', '0', '"', ':', ' ', '[', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '9', '2', '1', '5', '8', '9', '9', '7', '2', '8', '1', '7', '1', '6', '4', '6', '1', '7', '0', '6', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '3', '1', '2', '8', '1', '7', '1', '7', '0', '1', '1', '4', '3', '0', '8', '9', '8', '1', '3', '8', '6', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '5', '9', '6', '1', '8', '1', '6', '1', '2', '6', '8', '6', '8', '2', '7', '4', '3', '2', '7', '7', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '3', '3', '0', '7', '6', '5', '2', '8', '6', '8', '4', '2', '8', '9', '7', '3', '1', '8', '4', '4', '9', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '8', '1', '3', '1', '2', '7', '9', '2', '1', '4', '3', '8', '3', '5', '3', '4', '3', '4', '6', '9', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '3', '6', '0', '3', '2', '6', '2', '4', '3', '3', '4', '0', '8', '6', '2', '1', '9', '5', '8', '6', '3', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '1', '2', '2', '9', '3', '7', '4', '8', '4', '8', '1', '1', '8', '6', '8', '9', '4', '8', '4', '2', '9', '7', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '8', '5', '0', '2', '1', '5', '7', '1', '4', '0', '5', '5', '1', '8', '5', '0', '9', '2', '0', '2', '2', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '9', '9', '8', '5', '9', '2', '6', '7', '6', '5', '5', '5', '3', '5', '5', '2', '1', '2', '8', '0', '3', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '3', '8', '9', '2', '9', '9', '1', '0', '8', '7', '2', '5', '1', '7', '6', '9', '7', '8', '7', '5', '"', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ']', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'o', 'l', 'd', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6', '"', ':', ' ', '"', '1', '7', '4', '1', '4', '4', '0', '3', '0', '0', '8', '0', '6', '2', '5', '1', '2', '9', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'n', 'e', 'w', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6', '"', ':', ' ', '"', '1', '7', '4', '8', '8', '8', '0', '5', '7', '3', '9', '8', '5', '2', '0', '6', '9', '8', '"', '\r', '\n', ' ', ' ', ' ', ' ', '}', ',']
noncomputable def momentRecordsChunk070Push (acc : List SourceJson) : List SourceJson :=
  (.obj [(String.ofList ['s', 'i', 'm', 'p', 'l', 'e', 'x', '_', 'i', 'd'], .number (String.ofList ['7', '0'])), (String.ofList ['l', 'o', 'g', '_', 'g', 'a', 'p', '_', 'f', 'a', 'c', 't', 'o', 'r', '_', 'f', 'l', 'o', 'o', 'r', 's', '_', 'Q', '8', '0'], .arr [.str (String.ofList ['2', '9', '2', '1', '5', '8', '9', '9', '7', '2', '8', '1', '7', '1', '6', '4', '6', '1', '7', '0', '6']), .str (String.ofList ['3', '1', '2', '8', '1', '7', '1', '7', '0', '1', '1', '4', '3', '0', '8', '9', '8', '1', '3', '8', '6']), .str (String.ofList ['2', '5', '9', '6', '1', '8', '1', '6', '1', '2', '6', '8', '6', '8', '2', '7', '4', '3', '2', '7', '7']), .str (String.ofList ['3', '3', '0', '7', '6', '5', '2', '8', '6', '8', '4', '2', '8', '9', '7', '3', '1', '8', '4', '4', '9']), .str (String.ofList ['2', '8', '1', '3', '1', '2', '7', '9', '2', '1', '4', '3', '8', '3', '5', '3', '4', '3', '4', '6', '9']), .str (String.ofList ['3', '6', '0', '3', '2', '6', '2', '4', '3', '3', '4', '0', '8', '6', '2', '1', '9', '5', '8', '6', '3']), .str (String.ofList ['1', '2', '2', '9', '3', '7', '4', '8', '4', '8', '1', '1', '8', '6', '8', '9', '4', '8', '4', '2', '9', '7']), .str (String.ofList ['8', '5', '0', '2', '1', '5', '7', '1', '4', '0', '5', '5', '1', '8', '5', '0', '9', '2', '0', '2', '2']), .str (String.ofList ['9', '9', '8', '5', '9', '2', '6', '7', '6', '5', '5', '5', '3', '5', '5', '2', '1', '2', '8', '0', '3']), .str (String.ofList ['2', '3', '8', '9', '2', '9', '9', '1', '0', '8', '7', '2', '5', '1', '7', '6', '9', '7', '8', '7', '5'])]), (String.ofList ['o', 'l', 'd', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6'], .str (String.ofList ['1', '7', '4', '1', '4', '4', '0', '3', '0', '0', '8', '0', '6', '2', '5', '1', '2', '9'])), (String.ofList ['n', 'e', 'w', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6'], .str (String.ofList ['1', '7', '4', '8', '8', '8', '0', '5', '7', '3', '9', '8', '5', '2', '0', '6', '9', '8']))]) :: (acc)

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_chunk_070_before_generic"
  err.flush

theorem array_moment_records_chunk_070 (fuel : Nat) (tail : List Char) (acc : List SourceJson) :
    SourceJson.array (fuel + 80)
      (SourceJson.white (momentRecordsChunk070Chars ++ tail)) acc =
      SourceJson.array (fuel + 79) (SourceJson.white tail) (momentRecordsChunk070Push acc) := by rfl

noncomputable def momentRecordsAcc071 : List SourceJson := momentRecordsChunk070Push momentRecordsAcc070

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_chunk_070_generic_complete"
  err.flush

noncomputable def momentRecordsChunk071Chars : List Char := ['\r', '\n', ' ', ' ', ' ', ' ', '{', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 's', 'i', 'm', 'p', 'l', 'e', 'x', '_', 'i', 'd', '"', ':', ' ', '7', '1', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'l', 'o', 'g', '_', 'g', 'a', 'p', '_', 'f', 'a', 'c', 't', 'o', 'r', '_', 'f', 'l', 'o', 'o', 'r', 's', '_', 'Q', '8', '0', '"', ':', ' ', '[', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '1', '4', '1', '2', '6', '9', '0', '3', '3', '5', '7', '3', '3', '4', '4', '6', '5', '2', '5', '0', '5', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '5', '6', '3', '7', '4', '2', '5', '1', '4', '4', '3', '4', '1', '5', '9', '0', '6', '0', '3', '1', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '3', '0', '8', '6', '8', '1', '9', '5', '8', '6', '3', '8', '8', '6', '6', '0', '3', '1', '6', '2', '2', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '1', '5', '9', '6', '5', '6', '7', '4', '9', '6', '7', '7', '6', '5', '4', '4', '8', '7', '7', '6', '7', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '1', '3', '2', '8', '8', '7', '4', '7', '7', '1', '5', '4', '7', '6', '3', '3', '5', '2', '7', '4', '6', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '1', '1', '4', '2', '2', '6', '6', '8', '2', '6', '2', '4', '0', '0', '7', '7', '3', '9', '4', '8', '0', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '6', '5', '3', '0', '5', '9', '3', '2', '0', '4', '4', '3', '0', '2', '1', '8', '7', '8', '2', '7', '5', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '7', '1', '6', '0', '3', '3', '5', '0', '7', '6', '2', '1', '1', '2', '5', '8', '4', '0', '3', '3', '9', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '8', '6', '7', '1', '5', '0', '5', '1', '7', '7', '2', '8', '9', '3', '4', '5', '5', '3', '7', '5', '6', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '1', '9', '1', '4', '0', '6', '5', '1', '5', '5', '0', '4', '6', '2', '7', '0', '0', '1', '3', '3', '4', '"', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ']', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'o', 'l', 'd', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6', '"', ':', ' ', '"', '5', '8', '3', '7', '0', '2', '8', '4', '8', '3', '5', '0', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'n', 'e', 'w', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6', '"', ':', ' ', '"', '5', '8', '5', '4', '1', '4', '9', '2', '4', '5', '0', '2', '"', '\r', '\n', ' ', ' ', ' ', ' ', '}', ',']
noncomputable def momentRecordsChunk071Push (acc : List SourceJson) : List SourceJson :=
  (.obj [(String.ofList ['s', 'i', 'm', 'p', 'l', 'e', 'x', '_', 'i', 'd'], .number (String.ofList ['7', '1'])), (String.ofList ['l', 'o', 'g', '_', 'g', 'a', 'p', '_', 'f', 'a', 'c', 't', 'o', 'r', '_', 'f', 'l', 'o', 'o', 'r', 's', '_', 'Q', '8', '0'], .arr [.str (String.ofList ['1', '4', '1', '2', '6', '9', '0', '3', '3', '5', '7', '3', '3', '4', '4', '6', '5', '2', '5', '0', '5']), .str (String.ofList ['2', '5', '6', '3', '7', '4', '2', '5', '1', '4', '4', '3', '4', '1', '5', '9', '0', '6', '0', '3', '1']), .str (String.ofList ['3', '0', '8', '6', '8', '1', '9', '5', '8', '6', '3', '8', '8', '6', '6', '0', '3', '1', '6', '2', '2']), .str (String.ofList ['1', '5', '9', '6', '5', '6', '7', '4', '9', '6', '7', '7', '6', '5', '4', '4', '8', '7', '7', '6', '7']), .str (String.ofList ['1', '3', '2', '8', '8', '7', '4', '7', '7', '1', '5', '4', '7', '6', '3', '3', '5', '2', '7', '4', '6']), .str (String.ofList ['1', '1', '4', '2', '2', '6', '6', '8', '2', '6', '2', '4', '0', '0', '7', '7', '3', '9', '4', '8', '0']), .str (String.ofList ['6', '5', '3', '0', '5', '9', '3', '2', '0', '4', '4', '3', '0', '2', '1', '8', '7', '8', '2', '7', '5']), .str (String.ofList ['7', '1', '6', '0', '3', '3', '5', '0', '7', '6', '2', '1', '1', '2', '5', '8', '4', '0', '3', '3', '9']), .str (String.ofList ['8', '6', '7', '1', '5', '0', '5', '1', '7', '7', '2', '8', '9', '3', '4', '5', '5', '3', '7', '5', '6']), .str (String.ofList ['1', '9', '1', '4', '0', '6', '5', '1', '5', '5', '0', '4', '6', '2', '7', '0', '0', '1', '3', '3', '4'])]), (String.ofList ['o', 'l', 'd', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6'], .str (String.ofList ['5', '8', '3', '7', '0', '2', '8', '4', '8', '3', '5', '0'])), (String.ofList ['n', 'e', 'w', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6'], .str (String.ofList ['5', '8', '5', '4', '1', '4', '9', '2', '4', '5', '0', '2']))]) :: (acc)

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_chunk_071_before_generic"
  err.flush

theorem array_moment_records_chunk_071 (fuel : Nat) (tail : List Char) (acc : List SourceJson) :
    SourceJson.array (fuel + 79)
      (SourceJson.white (momentRecordsChunk071Chars ++ tail)) acc =
      SourceJson.array (fuel + 78) (SourceJson.white tail) (momentRecordsChunk071Push acc) := by rfl

noncomputable def momentRecordsAcc072 : List SourceJson := momentRecordsChunk071Push momentRecordsAcc071

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_chunk_071_generic_complete"
  err.flush

noncomputable def momentRecordsBlock017Chars : List Char := momentRecordsChunk068Chars ++ momentRecordsChunk069Chars ++ momentRecordsChunk070Chars ++ momentRecordsChunk071Chars
noncomputable def momentRecordsBlock017Push (acc : List SourceJson) : List SourceJson := momentRecordsChunk071Push (momentRecordsChunk070Push (momentRecordsChunk069Push (momentRecordsChunk068Push (acc))))

theorem array_moment_records_block_017 (fuel : Nat) (tail : List Char) (acc : List SourceJson) :
    SourceJson.array (fuel + 82)
      (SourceJson.white (momentRecordsBlock017Chars ++ tail)) acc =
      SourceJson.array (fuel + 78) (SourceJson.white tail) (momentRecordsBlock017Push acc) := by
  have hinput : momentRecordsBlock017Chars ++ tail = momentRecordsChunk068Chars ++ (momentRecordsChunk069Chars ++ (momentRecordsChunk070Chars ++ (momentRecordsChunk071Chars ++ (tail)))) := by
    simp only [momentRecordsBlock017Chars, List.append_assoc]
  calc
    SourceJson.array (fuel + 82) (SourceJson.white (momentRecordsBlock017Chars ++ tail)) acc =
        SourceJson.array (fuel + 82) (SourceJson.white (momentRecordsChunk068Chars ++ (momentRecordsChunk069Chars ++ (momentRecordsChunk070Chars ++ (momentRecordsChunk071Chars ++ (tail)))))) acc :=
      congrArg (fun s => SourceJson.array (fuel + 82) (SourceJson.white s) acc) hinput
    _ = SourceJson.array (fuel + 81) (SourceJson.white (momentRecordsChunk069Chars ++ (momentRecordsChunk070Chars ++ (momentRecordsChunk071Chars ++ (tail))))) (momentRecordsChunk068Push (acc)) := array_moment_records_chunk_068 fuel (momentRecordsChunk069Chars ++ (momentRecordsChunk070Chars ++ (momentRecordsChunk071Chars ++ (tail)))) (acc)
    _ = SourceJson.array (fuel + 80) (SourceJson.white (momentRecordsChunk070Chars ++ (momentRecordsChunk071Chars ++ (tail)))) (momentRecordsChunk069Push (momentRecordsChunk068Push (acc))) := array_moment_records_chunk_069 fuel (momentRecordsChunk070Chars ++ (momentRecordsChunk071Chars ++ (tail))) (momentRecordsChunk068Push (acc))
    _ = SourceJson.array (fuel + 79) (SourceJson.white (momentRecordsChunk071Chars ++ (tail))) (momentRecordsChunk070Push (momentRecordsChunk069Push (momentRecordsChunk068Push (acc)))) := array_moment_records_chunk_070 fuel (momentRecordsChunk071Chars ++ (tail)) (momentRecordsChunk069Push (momentRecordsChunk068Push (acc)))
    _ = SourceJson.array (fuel + 78) (SourceJson.white tail) (momentRecordsBlock017Push acc) := array_moment_records_chunk_071 fuel (tail) (momentRecordsChunk070Push (momentRecordsChunk069Push (momentRecordsChunk068Push (acc))))

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_block_017_before_raw_binding"
  err.flush

theorem moment_records_block_017_prefix :
    (momentRest06 35211).take 2056 = momentRecordsBlock017Chars := by rfl

theorem moment_records_block_017_split :
    momentRest06 35211 = momentRecordsBlock017Chars ++ momentRest06 37267 := by
  calc
    momentRest06 35211 =
        (momentRest06 35211).take 2056 ++ (momentRest06 35211).drop 2056 :=
      (List.take_append_drop 2056 (momentRest06 35211)).symm
    _ = momentRecordsBlock017Chars ++ (momentRest06 35211).drop 2056 :=
      congrArg (fun p => p ++ (momentRest06 35211).drop 2056) moment_records_block_017_prefix
    _ = momentRecordsBlock017Chars ++ momentRest06 37267 :=
      congrArg (fun rest => momentRecordsBlock017Chars ++ rest) (momentRest06_drop 35211 2056)

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_block_017_after_raw_binding"
  err.flush

theorem array_moment_records_original_block_017 (fuel : Nat) (acc : List SourceJson) :
    SourceJson.array (fuel + 82)
      (SourceJson.white (momentRest06 35211)) acc =
      SourceJson.array (fuel + 78) (SourceJson.white (momentRest06 37267)) (momentRecordsBlock017Push acc) := by
  exact (congrArg (fun s => SourceJson.array (fuel + 82) (SourceJson.white s) acc)
      moment_records_block_017_split).trans (array_moment_records_block_017 fuel (momentRest06 37267) acc)

theorem moment_records_through_block_017 (fuel : Nat) :
    SourceJson.array (fuel + 150)
      (SourceJson.white (momentRest06 364)) [] =
      SourceJson.array (fuel + 78) (SourceJson.white (momentRest06 37267)) momentRecordsAcc072 := by
  exact (moment_records_through_block_016 fuel).trans (array_moment_records_original_block_017 fuel momentRecordsAcc068)

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_block_017_complete"
  err.flush

#print axioms array_moment_records_chunk_068
#print axioms array_moment_records_chunk_069
#print axioms array_moment_records_chunk_070
#print axioms array_moment_records_chunk_071
#print axioms array_moment_records_block_017
#print axioms moment_records_block_017_prefix
#print axioms moment_records_block_017_split
#print axioms array_moment_records_original_block_017
#print axioms moment_records_through_block_017

end ImbalancedChen.P2OriginalSaving19Moment06Parsing
