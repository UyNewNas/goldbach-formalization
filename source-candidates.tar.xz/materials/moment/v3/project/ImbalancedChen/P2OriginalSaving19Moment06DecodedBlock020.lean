/- SOURCE_CANDIDATE: original Cell06 source only. No Lean compilation,
independent kernel replay, full-owned audit or formal acceptance is claimed. -/

import ImbalancedChen.P2OriginalSaving19Moment06DecodedBlock019
import ImbalancedChen.P2OriginalSaving19Moment06RecordsBlock020

/-! Original typed moment records 80 through 83; each concrete value is checked by original decodeMomentRecord.
Candidate quotations preserve exact original raw bytes. The Lean equations bind
them to the production-compatible packed input and run the unchanged reader.
This local input resolves inside this private project, not the P1 filesystem. -/
namespace ImbalancedChen.P2OriginalSaving19Moment06Decoding
set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false
open ImbalancedChen.P2OriginalSaving19Archive

open ImbalancedChen.P2OriginalSaving19Moment06Parsing

noncomputable def momentJsonRecord080 : SourceJson :=
  (momentRecordsChunk080Push []).head (List.cons_ne_nil _ _)

theorem moment_record_080_push_eq (acc : List SourceJson) :
    momentRecordsChunk080Push acc = momentJsonRecord080 :: acc := by rfl

noncomputable def momentTypedRecord080 : MomentRecord :=
  { simplexId := 80,
    factorFloorsQ80 := #[(263736049823433153422 : Int), (374168926285779702699 : Int), (264355419731459363552 : Int), (261052296395642693496 : Int), (226362497027391949555 : Int), (230809878739016231120 : Int), (582442636460646942575 : Int), (682610291544503480217 : Int), (375671860899793805732 : Int), (267527444110602139644 : Int)],
    oldFloorQ96 := (69162680038738949 : Int),
    newFloorQ96 := (69364854118196224 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_080_before_decode"
  err.flush

theorem decode_moment_record_080 :
    decodeMomentRecord momentJsonRecord080 = .ok momentTypedRecord080 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_080_decoded"
  err.flush

noncomputable def momentJsonRecord081 : SourceJson :=
  (momentRecordsChunk081Push []).head (List.cons_ne_nil _ _)

theorem moment_record_081_push_eq (acc : List SourceJson) :
    momentRecordsChunk081Push acc = momentJsonRecord081 :: acc := by rfl

noncomputable def momentTypedRecord081 : MomentRecord :=
  { simplexId := 81,
    factorFloorsQ80 := #[(249172530031358444605 : Int), (303053165426591968672 : Int), (273363177812657444290 : Int), (242329460521329643282 : Int), (209608460446923828891 : Int), (140431088125159868800 : Int), (505664026451862493458 : Int), (561790348963213899353 : Int), (840069929652926822974 : Int), (224351422948053824880 : Int)],
    oldFloorQ96 := (28955735144839083 : Int),
    newFloorQ96 := (29040884373091861 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_081_before_decode"
  err.flush

theorem decode_moment_record_081 :
    decodeMomentRecord momentJsonRecord081 = .ok momentTypedRecord081 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_081_decoded"
  err.flush

noncomputable def momentJsonRecord082 : SourceJson :=
  (momentRecordsChunk082Push []).head (List.cons_ne_nil _ _)

theorem moment_record_082_push_eq (acc : List SourceJson) :
    momentRecordsChunk082Push acc = momentJsonRecord082 :: acc := by rfl

noncomputable def momentTypedRecord082 : MomentRecord :=
  { simplexId := 82,
    factorFloorsQ80 := #[(273538831712319505902 : Int), (317623223222841520439 : Int), (258974257552896015152 : Int), (288471003906480182036 : Int), (251163891821890309570 : Int), (294111761645104267557 : Int), (630933745247695426765 : Int), (777877433466699496181 : Int), (1178587643000533397537 : Int), (275808628674619061830 : Int)],
    oldFloorQ96 := (147072943630413524 : Int),
    newFloorQ96 := (147627165584715144 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_082_before_decode"
  err.flush

theorem decode_moment_record_082 :
    decodeMomentRecord momentJsonRecord082 = .ok momentTypedRecord082 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_082_decoded"
  err.flush

noncomputable def momentJsonRecord083 : SourceJson :=
  (momentRecordsChunk083Push []).head (List.cons_ne_nil _ _)

theorem moment_record_083_push_eq (acc : List SourceJson) :
    momentRecordsChunk083Push acc = momentJsonRecord083 :: acc := by rfl

noncomputable def momentTypedRecord083 : MomentRecord :=
  { simplexId := 83,
    factorFloorsQ80 := #[(140439530595744481172 : Int), (240712057384262269762 : Int), (267214483338300775707 : Int), (154100174583201770726 : Int), (130603799233155244027 : Int), (120117754122056312871 : Int), (506505564622243837395 : Int), (497089925209801971195 : Int), (842783294330338296350 : Int), (203523714736020293196 : Int)],
    oldFloorQ96 := (35678922153147055 : Int),
    newFloorQ96 := (35770621022818203 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_083_before_decode"
  err.flush

theorem decode_moment_record_083 :
    decodeMomentRecord momentJsonRecord083 = .ok momentTypedRecord083 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_083_decoded"
  err.flush

noncomputable def momentJsonRecordsBlock020 : List SourceJson := [momentJsonRecord080, momentJsonRecord081, momentJsonRecord082, momentJsonRecord083]
noncomputable def momentTypedRecordsBlock020 : List MomentRecord := [momentTypedRecord080, momentTypedRecord081, momentTypedRecord082, momentTypedRecord083]

theorem moment_records_block_020_push_eq (acc : List SourceJson) :
    momentRecordsBlock020Push acc = [momentJsonRecord083, momentJsonRecord082, momentJsonRecord081, momentJsonRecord080] ++ acc := by rfl

theorem moment_records_block_020_reverse (acc : List SourceJson) :
    (momentRecordsBlock020Push acc).reverse = acc.reverse ++ momentJsonRecordsBlock020 := by
  rw [moment_records_block_020_push_eq, List.reverse_append]
  rfl

theorem decode_moment_records_block_020 :
    momentJsonRecordsBlock020.mapM decodeMomentRecord = .ok momentTypedRecordsBlock020 := by
  simp only [momentJsonRecordsBlock020, momentTypedRecordsBlock020, List.mapM_cons, List.mapM_nil,
    decode_moment_record_080, decode_moment_record_081, decode_moment_record_082, decode_moment_record_083]
  rfl

noncomputable def momentTypedRowsThroughBlock020 : List MomentRecord := momentTypedRowsThroughBlock019 ++ momentTypedRecordsBlock020

theorem decode_moment_records_through_block_020 :
    momentRecordsAcc084.reverse.mapM decodeMomentRecord = .ok momentTypedRowsThroughBlock020 := by
  change (momentRecordsBlock020Push momentRecordsAcc080).reverse.mapM decodeMomentRecord = _
  rw [moment_records_block_020_reverse]
  rw [List.mapM_append, decode_moment_records_through_block_019, decode_moment_records_block_020]
  rfl

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_block_020_complete"
  err.flush

#print axioms moment_record_080_push_eq
#print axioms decode_moment_record_080
#print axioms moment_record_081_push_eq
#print axioms decode_moment_record_081
#print axioms moment_record_082_push_eq
#print axioms decode_moment_record_082
#print axioms moment_record_083_push_eq
#print axioms decode_moment_record_083
#print axioms moment_records_block_020_push_eq
#print axioms moment_records_block_020_reverse
#print axioms decode_moment_records_block_020
#print axioms decode_moment_records_through_block_020

end ImbalancedChen.P2OriginalSaving19Moment06Decoding
