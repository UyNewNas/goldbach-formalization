/- SOURCE_CANDIDATE: original Cell06 source only. No Lean compilation,
independent kernel replay, full-owned audit or formal acceptance is claimed. -/

import ImbalancedChen.P2OriginalSaving19Moment06Metadata
import ImbalancedChen.P2OriginalSaving19Moment06RecordsBlock028
import ImbalancedChen.P2OriginalSaving19ParseFromValue00

/-! Whole original moment06 pure SourceJson parse, assembled from checked compact-input spans. No typed decode claim.
Candidate quotations preserve exact original raw bytes. The Lean equations bind
them to the production-compatible packed input and run the unchanged reader.
This local input resolves inside this private project, not the P1 filesystem. -/
namespace ImbalancedChen.P2OriginalSaving19Moment06Parsing
set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false
open ImbalancedChen.P2OriginalSaving19Archive

noncomputable def momentRecordsHeaderChars : List Char := ['\r', '\n', ' ', ' ', '"', 'r', 'e', 'c', 'o', 'r', 'd', 's', '"', ':', ' ']
noncomputable def momentRecordsFieldKey : String := String.ofList ['r', 'e', 'c', 'o', 'r', 'd', 's']
noncomputable def momentRecordsFieldAcc : List (String × SourceJson) :=
  (momentRecordsFieldKey, momentRecordsArrayValue) :: momentMetadataAcc009
noncomputable def momentRootValue : SourceJson := .obj (momentRecordsFieldAcc.reverse)
noncomputable def momentRecordsSeparatorChars : List Char := ['\r', '\n', '}']
noncomputable def momentTrailingChars : List Char := ['\r', '\n']

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 whole_before_last_header_binding"
  err.flush

theorem moment_records_header_prefix :
    (momentRest06 348).take 15 = momentRecordsHeaderChars := by rfl

theorem moment_records_header_split :
    momentRest06 348 = momentRecordsHeaderChars ++ momentRest06 363 := by
  calc
    momentRest06 348 =
        (momentRest06 348).take 15 ++ (momentRest06 348).drop 15 :=
      (List.take_append_drop 15 (momentRest06 348)).symm
    _ = momentRecordsHeaderChars ++ (momentRest06 348).drop 15 :=
      congrArg (fun p => p ++ (momentRest06 348).drop 15) moment_records_header_prefix
    _ = momentRecordsHeaderChars ++ momentRest06 363 :=
      congrArg (fun rest => momentRecordsHeaderChars ++ rest) (momentRest06_drop 348 15)

theorem moment_records_separator_prefix :
    (momentRest06 58371).take 3 = momentRecordsSeparatorChars := by rfl

theorem moment_records_separator_split :
    momentRest06 58371 = momentRecordsSeparatorChars ++ momentRest06 58374 := by
  calc
    momentRest06 58371 =
        (momentRest06 58371).take 3 ++ (momentRest06 58371).drop 3 :=
      (List.take_append_drop 3 (momentRest06 58371)).symm
    _ = momentRecordsSeparatorChars ++ (momentRest06 58371).drop 3 :=
      congrArg (fun p => p ++ (momentRest06 58371).drop 3) moment_records_separator_prefix
    _ = momentRecordsSeparatorChars ++ momentRest06 58374 :=
      congrArg (fun rest => momentRecordsSeparatorChars ++ rest) (momentRest06_drop 58371 3)

theorem moment_trailing_prefix :
    (momentRest06 58374).take 2 = momentTrailingChars := by rfl

theorem moment_trailing_split :
    momentRest06 58374 = momentTrailingChars ++ momentRest06 58376 := by
  calc
    momentRest06 58374 =
        (momentRest06 58374).take 2 ++ (momentRest06 58374).drop 2 :=
      (List.take_append_drop 2 (momentRest06 58374)).symm
    _ = momentTrailingChars ++ (momentRest06 58374).drop 2 :=
      congrArg (fun p => p ++ (momentRest06 58374).drop 2) moment_trailing_prefix
    _ = momentTrailingChars ++ momentRest06 58376 :=
      congrArg (fun rest => momentTrailingChars ++ rest) (momentRest06_drop 58374 2)

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 whole_after_last_raw_bindings"
  err.flush

noncomputable def momentRecordsAfterValue (fuel : Nat) (result : SourceJson × List Char) :
    Except String (SourceJson × List Char) :=
  match SourceJson.white result.2 with
  | '}' :: ending =>
      .ok (.obj (((momentRecordsFieldKey, result.1) :: momentMetadataAcc009).reverse), ending)
  | ',' :: ending =>
      SourceJson.object fuel (SourceJson.white ending)
        ((momentRecordsFieldKey, result.1) :: momentMetadataAcc009)
  | _ => .error "object separator missing"

theorem object_moment_records_header (fuel : Nat) (rest : List Char) :
    SourceJson.object (fuel + 152) (SourceJson.white (momentRecordsHeaderChars ++ rest)) momentMetadataAcc009 =
      (SourceJson.value (fuel + 151) rest).bind (momentRecordsAfterValue (fuel + 151)) := by rfl

theorem moment_records_after_value_separator (fuel : Nat) (tail : List Char) :
    (Except.ok (momentRecordsArrayValue, momentRecordsSeparatorChars ++ tail)).bind
      (momentRecordsAfterValue (fuel + 151)) = .ok (momentRootValue, tail) := by rfl

theorem object_moment_records_original (fuel : Nat) :
    SourceJson.object (fuel + 152) (SourceJson.white (momentRest06 348)) momentMetadataAcc009 =
      .ok (momentRootValue, momentRest06 58374) := by
  calc
    SourceJson.object (fuel + 152) (SourceJson.white (momentRest06 348)) momentMetadataAcc009 =
        SourceJson.object (fuel + 152)
          (SourceJson.white (momentRecordsHeaderChars ++ momentRest06 363)) momentMetadataAcc009 :=
      congrArg (fun rest => SourceJson.object (fuel + 152) (SourceJson.white rest) momentMetadataAcc009)
        moment_records_header_split
    _ = (SourceJson.value (fuel + 151) (momentRest06 363)).bind
        (momentRecordsAfterValue (fuel + 151)) :=
      object_moment_records_header fuel (momentRest06 363)
    _ = (Except.ok (momentRecordsArrayValue, momentRest06 58371)).bind
        (momentRecordsAfterValue (fuel + 151)) :=
      congrArg (fun result => result.bind (momentRecordsAfterValue (fuel + 151)))
        (value_moment_records_original fuel)
    _ = (Except.ok (momentRecordsArrayValue,
          momentRecordsSeparatorChars ++ momentRest06 58374)).bind
        (momentRecordsAfterValue (fuel + 151)) :=
      congrArg (fun rest => (Except.ok (momentRecordsArrayValue, rest)).bind
        (momentRecordsAfterValue (fuel + 151))) moment_records_separator_split
    _ = .ok (momentRootValue, momentRest06 58374) :=
      moment_records_after_value_separator fuel (momentRest06 58374)

theorem value_moment06_original (fuel : Nat) :
    SourceJson.value (fuel + 162) momentChars06 =
      .ok (momentRootValue, momentRest06 58374) := by
  exact (momentChars06_through_metadata fuel).trans (object_moment_records_original fuel)

theorem momentTrailing_white : SourceJson.white (momentRest06 58374) = [] := by
  calc
    SourceJson.white (momentRest06 58374) =
        SourceJson.white (momentTrailingChars ++ momentRest06 58376) :=
      congrArg SourceJson.white moment_trailing_split
    _ = SourceJson.white (momentTrailingChars ++ []) :=
      congrArg (fun rest => SourceJson.white (momentTrailingChars ++ rest)) momentRest06_end
    _ = [] := by rfl

theorem momentChars06_parseChars : SourceJson.parseChars momentChars06 = .ok momentRootValue := by
  apply SourceJson.parseChars_of_value_eq (tail := momentRest06 58374)
  · rw [momentChars06_length]
    exact value_moment06_original 58215
  · exact momentTrailing_white

theorem momentPacked06_parseChars :
    SourceJson.parseChars momentPacked06.toList = .ok momentRootValue :=
  momentChars06_parseChars

theorem momentPacked06_parse :
    SourceJson.parse (String.ofList momentPacked06.toList) = .ok momentRootValue :=
  (SourceJson.parse_ofList momentPacked06.toList).trans momentPacked06_parseChars

theorem momentPacked06_parse_success :
    (SourceJson.parse (String.ofList momentPacked06.toList)).toOption.isSome = true := by
  rw [momentPacked06_parse]
  rfl

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 whole_original_parser_complete"
  err.flush

#print axioms moment_records_header_prefix
#print axioms moment_records_header_split
#print axioms moment_records_separator_prefix
#print axioms moment_records_separator_split
#print axioms moment_trailing_prefix
#print axioms moment_trailing_split
#print axioms object_moment_records_header
#print axioms moment_records_after_value_separator
#print axioms object_moment_records_original
#print axioms value_moment06_original
#print axioms momentTrailing_white
#print axioms momentChars06_parseChars
#print axioms momentPacked06_parseChars
#print axioms momentPacked06_parse
#print axioms momentPacked06_parse_success

end ImbalancedChen.P2OriginalSaving19Moment06Parsing
