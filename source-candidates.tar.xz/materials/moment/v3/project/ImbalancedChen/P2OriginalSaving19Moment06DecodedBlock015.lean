/- SOURCE_CANDIDATE: original Cell06 source only. No Lean compilation,
independent kernel replay, full-owned audit or formal acceptance is claimed. -/

import ImbalancedChen.P2OriginalSaving19Moment06DecodedBlock014
import ImbalancedChen.P2OriginalSaving19Moment06RecordsBlock015

/-! Original typed moment records 60 through 63; each concrete value is checked by original decodeMomentRecord.
Candidate quotations preserve exact original raw bytes. The Lean equations bind
them to the production-compatible packed input and run the unchanged reader.
This local input resolves inside this private project, not the P1 filesystem. -/
namespace ImbalancedChen.P2OriginalSaving19Moment06Decoding
set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false
open ImbalancedChen.P2OriginalSaving19Archive

open ImbalancedChen.P2OriginalSaving19Moment06Parsing

noncomputable def momentJsonRecord060 : SourceJson :=
  (momentRecordsChunk060Push []).head (List.cons_ne_nil _ _)

theorem moment_record_060_push_eq (acc : List SourceJson) :
    momentRecordsChunk060Push acc = momentJsonRecord060 :: acc := by rfl

noncomputable def momentTypedRecord060 : MomentRecord :=
  { simplexId := 60,
    factorFloorsQ80 := #[(189245388456165892726 : Int), (296545621640660464123 : Int), (241522077302353928418 : Int), (129910682460847689122 : Int), (112044093645931149925 : Int), (294491989968881247638 : Int), (828651390879817376204 : Int), (829117064747548884385 : Int), (1006773311734729774995 : Int), (341275920534779275752 : Int)],
    oldFloorQ96 := (14786517202897 : Int),
    newFloorQ96 := (14838831244267 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_060_before_decode"
  err.flush

theorem decode_moment_record_060 :
    decodeMomentRecord momentJsonRecord060 = .ok momentTypedRecord060 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_060_decoded"
  err.flush

noncomputable def momentJsonRecord061 : SourceJson :=
  (momentRecordsChunk061Push []).head (List.cons_ne_nil _ _)

theorem moment_record_061_push_eq (acc : List SourceJson) :
    momentRecordsChunk061Push acc = momentJsonRecord061 :: acc := by rfl

noncomputable def momentTypedRecord061 : MomentRecord :=
  { simplexId := 61,
    factorFloorsQ80 := #[(200374728411957407347 : Int), (290487797251144269954 : Int), (323574100282777844985 : Int), (167971264126158675818 : Int), (135468412259118956935 : Int), (119954107220470571694 : Int), (494223554485707774297 : Int), (522207295191626974757 : Int), (573014268286188039545 : Int), (175757484832715589626 : Int)],
    oldFloorQ96 := (2408026213537243 : Int),
    newFloorQ96 := (2414015308230431 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_061_before_decode"
  err.flush

theorem decode_moment_record_061 :
    decodeMomentRecord momentJsonRecord061 = .ok momentTypedRecord061 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_061_decoded"
  err.flush

noncomputable def momentJsonRecord062 : SourceJson :=
  (momentRecordsChunk062Push []).head (List.cons_ne_nil _ _)

theorem moment_record_062_push_eq (acc : List SourceJson) :
    momentRecordsChunk062Push acc = momentJsonRecord062 :: acc := by rfl

noncomputable def momentTypedRecord062 : MomentRecord :=
  { simplexId := 62,
    factorFloorsQ80 := #[(231682222560068262096 : Int), (291112259722329799766 : Int), (301092657267449335678 : Int), (241209897201807446702 : Int), (202653814068286519764 : Int), (228837287644580190652 : Int), (1201184491121362315767 : Int), (546087911549738478261 : Int), (525115025537293786520 : Int), (176274158213531536815 : Int)],
    oldFloorQ96 := (15315582630223407 : Int),
    newFloorQ96 := (15365645668806800 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_062_before_decode"
  err.flush

theorem decode_moment_record_062 :
    decodeMomentRecord momentJsonRecord062 = .ok momentTypedRecord062 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_062_decoded"
  err.flush

noncomputable def momentJsonRecord063 : SourceJson :=
  (momentRecordsChunk063Push []).head (List.cons_ne_nil _ _)

theorem moment_record_063_push_eq (acc : List SourceJson) :
    momentRecordsChunk063Push acc = momentJsonRecord063 :: acc := by rfl

noncomputable def momentTypedRecord063 : MomentRecord :=
  { simplexId := 63,
    factorFloorsQ80 := #[(256247401191048545895 : Int), (276653755028354661227 : Int), (277817364781222173190 : Int), (306612949396257347386 : Int), (261725371689208529862 : Int), (314463511511966078155 : Int), (1669591554532388270433 : Int), (544996120308767219566 : Int), (529674254151280277678 : Int), (168443452779895180220 : Int)],
    oldFloorQ96 := (3493456627441 : Int),
    newFloorQ96 := (3506792718491 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_063_before_decode"
  err.flush

theorem decode_moment_record_063 :
    decodeMomentRecord momentJsonRecord063 = .ok momentTypedRecord063 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_063_decoded"
  err.flush

noncomputable def momentJsonRecordsBlock015 : List SourceJson := [momentJsonRecord060, momentJsonRecord061, momentJsonRecord062, momentJsonRecord063]
noncomputable def momentTypedRecordsBlock015 : List MomentRecord := [momentTypedRecord060, momentTypedRecord061, momentTypedRecord062, momentTypedRecord063]

theorem moment_records_block_015_push_eq (acc : List SourceJson) :
    momentRecordsBlock015Push acc = [momentJsonRecord063, momentJsonRecord062, momentJsonRecord061, momentJsonRecord060] ++ acc := by rfl

theorem moment_records_block_015_reverse (acc : List SourceJson) :
    (momentRecordsBlock015Push acc).reverse = acc.reverse ++ momentJsonRecordsBlock015 := by
  rw [moment_records_block_015_push_eq, List.reverse_append]
  rfl

theorem decode_moment_records_block_015 :
    momentJsonRecordsBlock015.mapM decodeMomentRecord = .ok momentTypedRecordsBlock015 := by
  simp only [momentJsonRecordsBlock015, momentTypedRecordsBlock015, List.mapM_cons, List.mapM_nil,
    decode_moment_record_060, decode_moment_record_061, decode_moment_record_062, decode_moment_record_063]
  rfl

noncomputable def momentTypedRowsThroughBlock015 : List MomentRecord := momentTypedRowsThroughBlock014 ++ momentTypedRecordsBlock015

theorem decode_moment_records_through_block_015 :
    momentRecordsAcc064.reverse.mapM decodeMomentRecord = .ok momentTypedRowsThroughBlock015 := by
  change (momentRecordsBlock015Push momentRecordsAcc060).reverse.mapM decodeMomentRecord = _
  rw [moment_records_block_015_reverse]
  rw [List.mapM_append, decode_moment_records_through_block_014, decode_moment_records_block_015]
  rfl

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_block_015_complete"
  err.flush

#print axioms moment_record_060_push_eq
#print axioms decode_moment_record_060
#print axioms moment_record_061_push_eq
#print axioms decode_moment_record_061
#print axioms moment_record_062_push_eq
#print axioms decode_moment_record_062
#print axioms moment_record_063_push_eq
#print axioms decode_moment_record_063
#print axioms moment_records_block_015_push_eq
#print axioms moment_records_block_015_reverse
#print axioms decode_moment_records_block_015
#print axioms decode_moment_records_through_block_015

end ImbalancedChen.P2OriginalSaving19Moment06Decoding
