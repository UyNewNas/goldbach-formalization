/- SOURCE_CANDIDATE: original Cell06 source only. No Lean compilation,
independent kernel replay, full-owned audit or formal acceptance is claimed. -/

import ImbalancedChen.P2OriginalSaving19Moment06DecodedBlock015
import ImbalancedChen.P2OriginalSaving19Moment06RecordsBlock016

/-! Original typed moment records 64 through 67; each concrete value is checked by original decodeMomentRecord.
Candidate quotations preserve exact original raw bytes. The Lean equations bind
them to the production-compatible packed input and run the unchanged reader.
This local input resolves inside this private project, not the P1 filesystem. -/
namespace ImbalancedChen.P2OriginalSaving19Moment06Decoding
set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false
open ImbalancedChen.P2OriginalSaving19Archive

open ImbalancedChen.P2OriginalSaving19Moment06Parsing

noncomputable def momentJsonRecord064 : SourceJson :=
  (momentRecordsChunk064Push []).head (List.cons_ne_nil _ _)

theorem moment_record_064_push_eq (acc : List SourceJson) :
    momentRecordsChunk064Push acc = momentJsonRecord064 :: acc := by rfl

noncomputable def momentTypedRecord064 : MomentRecord :=
  { simplexId := 64,
    factorFloorsQ80 := #[(292164209446860379830 : Int), (312821161004691494645 : Int), (262891195946218748028 : Int), (340706396189999944343 : Int), (290648323830804683161 : Int), (416030654781334329526 : Int), (1663243948367214794550 : Int), (854692610007332987020 : Int), (932825325972399585593 : Int), (238932213608540709137 : Int)],
    oldFloorQ96 := (17123027686157 : Int),
    newFloorQ96 := (17202599684654 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_064_before_decode"
  err.flush

theorem decode_moment_record_064 :
    decodeMomentRecord momentJsonRecord064 = .ok momentTypedRecord064 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_064_decoded"
  err.flush

noncomputable def momentJsonRecord065 : SourceJson :=
  (momentRecordsChunk065Push []).head (List.cons_ne_nil _ _)

theorem moment_record_065_push_eq (acc : List SourceJson) :
    momentRecordsChunk065Push acc = momentJsonRecord065 :: acc := by rfl

noncomputable def momentTypedRecord065 : MomentRecord :=
  { simplexId := 65,
    factorFloorsQ80 := #[(256193138201097420464 : Int), (292374563312737918990 : Int), (275602082617322108986 : Int), (306794865965653328058 : Int), (261765855125412762588 : Int), (315255457881273293734 : Int), (1228058622836580602526 : Int), (746580535590450337631 : Int), (478220364016592098630 : Int), (177319052770713356139 : Int)],
    oldFloorQ96 := (117275578854386821 : Int),
    newFloorQ96 := (117697171867918802 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_065_before_decode"
  err.flush

theorem decode_moment_record_065 :
    decodeMomentRecord momentJsonRecord065 = .ok momentTypedRecord065 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_065_decoded"
  err.flush

noncomputable def momentJsonRecord066 : SourceJson :=
  (momentRecordsChunk066Push []).head (List.cons_ne_nil _ _)

theorem moment_record_066_push_eq (acc : List SourceJson) :
    momentRecordsChunk066Push acc = momentJsonRecord066 :: acc := by rfl

noncomputable def momentTypedRecord066 : MomentRecord :=
  { simplexId := 66,
    factorFloorsQ80 := #[(292169421553141677178 : Int), (312825151840342039197 : Int), (262890799226528091714 : Int), (340707563355486468324 : Int), (290649423485340168161 : Int), (416029279588049144087 : Int), (1241856082315545549540 : Int), (963993638152140828713 : Int), (932835279052451743361 : Int), (238934516295675653411 : Int)],
    oldFloorQ96 := (249984860095215916 : Int),
    newFloorQ96 := (251081737452588454 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_066_before_decode"
  err.flush

theorem decode_moment_record_066 :
    decodeMomentRecord momentJsonRecord066 = .ok momentTypedRecord066 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_066_decoded"
  err.flush

noncomputable def momentJsonRecord067 : SourceJson :=
  (momentRecordsChunk067Push []).head (List.cons_ne_nil _ _)

theorem moment_record_067_push_eq (acc : List SourceJson) :
    momentRecordsChunk067Push acc = momentJsonRecord067 :: acc := by rfl

noncomputable def momentTypedRecord067 : MomentRecord :=
  { simplexId := 67,
    factorFloorsQ80 := #[(253944379195025004129 : Int), (331413495576711343439 : Int), (263984060189630513503 : Int), (310001821280466336255 : Int), (263408336895687642269 : Int), (315208978387317872942 : Int), (1231036407681052674732 : Int), (742549824283658492065 : Int), (286800121292349527687 : Int), (197100682610875348878 : Int)],
    oldFloorQ96 := (81856700657599620 : Int),
    newFloorQ96 := (82141269102139677 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_067_before_decode"
  err.flush

theorem decode_moment_record_067 :
    decodeMomentRecord momentJsonRecord067 = .ok momentTypedRecord067 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_067_decoded"
  err.flush

noncomputable def momentJsonRecordsBlock016 : List SourceJson := [momentJsonRecord064, momentJsonRecord065, momentJsonRecord066, momentJsonRecord067]
noncomputable def momentTypedRecordsBlock016 : List MomentRecord := [momentTypedRecord064, momentTypedRecord065, momentTypedRecord066, momentTypedRecord067]

theorem moment_records_block_016_push_eq (acc : List SourceJson) :
    momentRecordsBlock016Push acc = [momentJsonRecord067, momentJsonRecord066, momentJsonRecord065, momentJsonRecord064] ++ acc := by rfl

theorem moment_records_block_016_reverse (acc : List SourceJson) :
    (momentRecordsBlock016Push acc).reverse = acc.reverse ++ momentJsonRecordsBlock016 := by
  rw [moment_records_block_016_push_eq, List.reverse_append]
  rfl

theorem decode_moment_records_block_016 :
    momentJsonRecordsBlock016.mapM decodeMomentRecord = .ok momentTypedRecordsBlock016 := by
  simp only [momentJsonRecordsBlock016, momentTypedRecordsBlock016, List.mapM_cons, List.mapM_nil,
    decode_moment_record_064, decode_moment_record_065, decode_moment_record_066, decode_moment_record_067]
  rfl

noncomputable def momentTypedRowsThroughBlock016 : List MomentRecord := momentTypedRowsThroughBlock015 ++ momentTypedRecordsBlock016

theorem decode_moment_records_through_block_016 :
    momentRecordsAcc068.reverse.mapM decodeMomentRecord = .ok momentTypedRowsThroughBlock016 := by
  change (momentRecordsBlock016Push momentRecordsAcc064).reverse.mapM decodeMomentRecord = _
  rw [moment_records_block_016_reverse]
  rw [List.mapM_append, decode_moment_records_through_block_015, decode_moment_records_block_016]
  rfl

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_block_016_complete"
  err.flush

#print axioms moment_record_064_push_eq
#print axioms decode_moment_record_064
#print axioms moment_record_065_push_eq
#print axioms decode_moment_record_065
#print axioms moment_record_066_push_eq
#print axioms decode_moment_record_066
#print axioms moment_record_067_push_eq
#print axioms decode_moment_record_067
#print axioms moment_records_block_016_push_eq
#print axioms moment_records_block_016_reverse
#print axioms decode_moment_records_block_016
#print axioms decode_moment_records_through_block_016

end ImbalancedChen.P2OriginalSaving19Moment06Decoding
