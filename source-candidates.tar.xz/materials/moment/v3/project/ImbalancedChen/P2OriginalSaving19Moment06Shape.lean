/- SOURCE_CANDIDATE: original Cell06 source only. No Lean compilation,
independent kernel replay, full-owned audit or formal acceptance is claimed. -/

import ImbalancedChen.P2OriginalSaving19Moment06Decoded

/-! Exact shape of the already decoded original moment cell06.
All 113 original rows are included. The assertions only bind metadata,
row IDs, array sizes and bounded lookups; no saved floor validity is asserted. -/
namespace ImbalancedChen.P2OriginalSaving19Moment06Shape
set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false
open ImbalancedChen.P2OriginalSaving19Moment06Decoding

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06_SHAPE before_metadata"
  err.flush

theorem metadata :
    momentConcrete06.cellId = 6 ∧
    momentConcrete06.sourceWitness =
      "eighth-third-minorant-extension-20261009-a23-s23_low-06-cell.witness.json" ∧
    momentConcrete06.dimension = 8 ∧
    momentConcrete06.verticesPerSimplex = 9 ∧
    momentConcrete06.factorCount = 10 ∧
    momentConcrete06.logDegree = 6 ∧
    momentConcrete06.expDegree = 3 ∧
    momentConcrete06.logDenominator = 2^80 ∧
    momentConcrete06.finalDenominator = 2^96 := by
  decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06_SHAPE metadata_complete"
  err.flush

theorem row_count : momentConcrete06.rows.size = 113 := by rfl

theorem row_bound (i : Fin 113) : i.val < momentConcrete06.rows.size := by
  rw [row_count]
  exact i.isLt

theorem row_lookup_no_fallback (i : Fin 113) :
    momentConcrete06.rows[i.val]! = momentConcrete06.rows[i.val]'(row_bound i) :=
  getElem!_pos momentConcrete06.rows i.val (row_bound i)

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06_SHAPE before_all_row_ids_and_sizes"
  err.flush

theorem row_ids_and_floor_sizes : ∀ i : Fin 113,
    (momentConcrete06.rows[i.val]!).simplexId = i.val ∧
    (momentConcrete06.rows[i.val]!).factorFloorsQ80.size = 10 := by
  decide +kernel

theorem row_ids_and_floor_sizes_bounded (i : Fin 113) :
    (momentConcrete06.rows[i.val]'(row_bound i)).simplexId = i.val ∧
    (momentConcrete06.rows[i.val]'(row_bound i)).factorFloorsQ80.size = 10 := by
  rw [← row_lookup_no_fallback]
  exact row_ids_and_floor_sizes i

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06_SHAPE all_113_rows_complete"
  err.flush

#print axioms metadata
#print axioms row_count
#print axioms row_bound
#print axioms row_lookup_no_fallback
#print axioms row_ids_and_floor_sizes
#print axioms row_ids_and_floor_sizes_bounded
end ImbalancedChen.P2OriginalSaving19Moment06Shape
