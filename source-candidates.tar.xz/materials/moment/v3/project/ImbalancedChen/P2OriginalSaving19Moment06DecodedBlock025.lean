/- SOURCE_CANDIDATE: original Cell06 source only. No Lean compilation,
independent kernel replay, full-owned audit or formal acceptance is claimed. -/

import ImbalancedChen.P2OriginalSaving19Moment06DecodedBlock024
import ImbalancedChen.P2OriginalSaving19Moment06RecordsBlock025

/-! Original typed moment records 100 through 103; each concrete value is checked by original decodeMomentRecord.
Candidate quotations preserve exact original raw bytes. The Lean equations bind
them to the production-compatible packed input and run the unchanged reader.
This local input resolves inside this private project, not the P1 filesystem. -/
namespace ImbalancedChen.P2OriginalSaving19Moment06Decoding
set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false
open ImbalancedChen.P2OriginalSaving19Archive

open ImbalancedChen.P2OriginalSaving19Moment06Parsing

noncomputable def momentJsonRecord100 : SourceJson :=
  (momentRecordsChunk100Push []).head (List.cons_ne_nil _ _)

theorem moment_record_100_push_eq (acc : List SourceJson) :
    momentRecordsChunk100Push acc = momentJsonRecord100 :: acc := by rfl

noncomputable def momentTypedRecord100 : MomentRecord :=
  { simplexId := 100,
    factorFloorsQ80 := #[(161589381756020769829 : Int), (286767105626302481346 : Int), (323886629736770541185 : Int), (183658239007438275947 : Int), (120834502847288814498 : Int), (126187626123181867246 : Int), (515920137912367905278 : Int), (498982994758791299634 : Int), (673950725164575053091 : Int), (228154601203725480207 : Int)],
    oldFloorQ96 := (6424640822514088 : Int),
    newFloorQ96 := (6441242609716772 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_100_before_decode"
  err.flush

theorem decode_moment_record_100 :
    decodeMomentRecord momentJsonRecord100 = .ok momentTypedRecord100 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_100_decoded"
  err.flush

noncomputable def momentJsonRecord101 : SourceJson :=
  (momentRecordsChunk101Push []).head (List.cons_ne_nil _ _)

theorem moment_record_101_push_eq (acc : List SourceJson) :
    momentRecordsChunk101Push acc = momentJsonRecord101 :: acc := by rfl

noncomputable def momentTypedRecord101 : MomentRecord :=
  { simplexId := 101,
    factorFloorsQ80 := #[(207711585926139108326 : Int), (285337950433274549176 : Int), (296396745128261020980 : Int), (268311750557590533330 : Int), (191925830852792889994 : Int), (247498640606951228044 : Int), (1258526626055756115707 : Int), (508484185884302727132 : Int), (659945907765061381380 : Int), (227355689029192802692 : Int)],
    oldFloorQ96 := (50667842637066258 : Int),
    newFloorQ96 := (50842136932897051 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_101_before_decode"
  err.flush

theorem decode_moment_record_101 :
    decodeMomentRecord momentJsonRecord101 = .ok momentTypedRecord101 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_101_decoded"
  err.flush

noncomputable def momentJsonRecord102 : SourceJson :=
  (momentRecordsChunk102Push []).head (List.cons_ne_nil _ _)

theorem moment_record_102_push_eq (acc : List SourceJson) :
    momentRecordsChunk102Push acc = momentJsonRecord102 :: acc := by rfl

noncomputable def momentTypedRecord102 : MomentRecord :=
  { simplexId := 102,
    factorFloorsQ80 := #[(224253585872302458282 : Int), (284694059289137554422 : Int), (279317478787243127512 : Int), (318237701371550031156 : Int), (230765767048299966116 : Int), (389173186341016846507 : Int), (1318495568954055579512 : Int), (800745630747789991368 : Int), (991221930394778368244 : Int), (265375032488989578698 : Int)],
    oldFloorQ96 := (248445974088188872 : Int),
    newFloorQ96 := (249496757929942516 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_102_before_decode"
  err.flush

theorem decode_moment_record_102 :
    decodeMomentRecord momentJsonRecord102 = .ok momentTypedRecord102 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_102_decoded"
  err.flush

noncomputable def momentJsonRecord103 : SourceJson :=
  (momentRecordsChunk103Push []).head (List.cons_ne_nil _ _)

theorem moment_record_103_push_eq (acc : List SourceJson) :
    momentRecordsChunk103Push acc = momentJsonRecord103 :: acc := by rfl

noncomputable def momentTypedRecord103 : MomentRecord :=
  { simplexId := 103,
    factorFloorsQ80 := #[(159588120046900738464 : Int), (267652307483266374428 : Int), (279151871813281334375 : Int), (175877992278383136613 : Int), (120754434318177818855 : Int), (128795545149154868362 : Int), (521618844412524686127 : Int), (492687478062739380692 : Int), (659741852644988077328 : Int), (237259974553882339399 : Int)],
    oldFloorQ96 := (33571565147069136 : Int),
    newFloorQ96 := (33656178506257168 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_103_before_decode"
  err.flush

theorem decode_moment_record_103 :
    decodeMomentRecord momentJsonRecord103 = .ok momentTypedRecord103 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_103_decoded"
  err.flush

noncomputable def momentJsonRecordsBlock025 : List SourceJson := [momentJsonRecord100, momentJsonRecord101, momentJsonRecord102, momentJsonRecord103]
noncomputable def momentTypedRecordsBlock025 : List MomentRecord := [momentTypedRecord100, momentTypedRecord101, momentTypedRecord102, momentTypedRecord103]

theorem moment_records_block_025_push_eq (acc : List SourceJson) :
    momentRecordsBlock025Push acc = [momentJsonRecord103, momentJsonRecord102, momentJsonRecord101, momentJsonRecord100] ++ acc := by rfl

theorem moment_records_block_025_reverse (acc : List SourceJson) :
    (momentRecordsBlock025Push acc).reverse = acc.reverse ++ momentJsonRecordsBlock025 := by
  rw [moment_records_block_025_push_eq, List.reverse_append]
  rfl

theorem decode_moment_records_block_025 :
    momentJsonRecordsBlock025.mapM decodeMomentRecord = .ok momentTypedRecordsBlock025 := by
  simp only [momentJsonRecordsBlock025, momentTypedRecordsBlock025, List.mapM_cons, List.mapM_nil,
    decode_moment_record_100, decode_moment_record_101, decode_moment_record_102, decode_moment_record_103]
  rfl

noncomputable def momentTypedRowsThroughBlock025 : List MomentRecord := momentTypedRowsThroughBlock024 ++ momentTypedRecordsBlock025

theorem decode_moment_records_through_block_025 :
    momentRecordsAcc104.reverse.mapM decodeMomentRecord = .ok momentTypedRowsThroughBlock025 := by
  change (momentRecordsBlock025Push momentRecordsAcc100).reverse.mapM decodeMomentRecord = _
  rw [moment_records_block_025_reverse]
  rw [List.mapM_append, decode_moment_records_through_block_024, decode_moment_records_block_025]
  rfl

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_block_025_complete"
  err.flush

#print axioms moment_record_100_push_eq
#print axioms decode_moment_record_100
#print axioms moment_record_101_push_eq
#print axioms decode_moment_record_101
#print axioms moment_record_102_push_eq
#print axioms decode_moment_record_102
#print axioms moment_record_103_push_eq
#print axioms decode_moment_record_103
#print axioms moment_records_block_025_push_eq
#print axioms moment_records_block_025_reverse
#print axioms decode_moment_records_block_025
#print axioms decode_moment_records_through_block_025

end ImbalancedChen.P2OriginalSaving19Moment06Decoding
