/- SOURCE_CANDIDATE: original Cell06 source only. No Lean compilation,
independent kernel replay, full-owned audit or formal acceptance is claimed. -/

import ImbalancedChen.P2OriginalSaving19Moment06DecodedBlock010
import ImbalancedChen.P2OriginalSaving19Moment06RecordsBlock011

/-! Original typed moment records 44 through 47; each concrete value is checked by original decodeMomentRecord.
Candidate quotations preserve exact original raw bytes. The Lean equations bind
them to the production-compatible packed input and run the unchanged reader.
This local input resolves inside this private project, not the P1 filesystem. -/
namespace ImbalancedChen.P2OriginalSaving19Moment06Decoding
set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false
open ImbalancedChen.P2OriginalSaving19Archive

open ImbalancedChen.P2OriginalSaving19Moment06Parsing

noncomputable def momentJsonRecord044 : SourceJson :=
  (momentRecordsChunk044Push []).head (List.cons_ne_nil _ _)

theorem moment_record_044_push_eq (acc : List SourceJson) :
    momentRecordsChunk044Push acc = momentJsonRecord044 :: acc := by rfl

noncomputable def momentTypedRecord044 : MomentRecord :=
  { simplexId := 44,
    factorFloorsQ80 := #[(417372854325066722260 : Int), (395716174420899825356 : Int), (247412203972090239191 : Int), (369003542241619632285 : Int), (304395426943313792779 : Int), (419165581430651400875 : Int), (1738711793118235856465 : Int), (599637195280324773574 : Int), (737995010657048127464 : Int), (263532199783935384782 : Int)],
    oldFloorQ96 := (22279424406424 : Int),
    newFloorQ96 := (22380884752518 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_044_before_decode"
  err.flush

theorem decode_moment_record_044 :
    decodeMomentRecord momentJsonRecord044 = .ok momentTypedRecord044 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_044_decoded"
  err.flush

noncomputable def momentJsonRecord045 : SourceJson :=
  (momentRecordsChunk045Push []).head (List.cons_ne_nil _ _)

theorem moment_record_045_push_eq (acc : List SourceJson) :
    momentRecordsChunk045Push acc = momentJsonRecord045 :: acc := by rfl

noncomputable def momentTypedRecord045 : MomentRecord :=
  { simplexId := 45,
    factorFloorsQ80 := #[(353623242171439060846 : Int), (328249823560565642978 : Int), (258698960318105909654 : Int), (349165000847255755197 : Int), (290095864977949832519 : Int), (344970408048637001603 : Int), (1184729667818012906712 : Int), (474702468275579938538 : Int), (355936862671294487282 : Int), (160191763671750056707 : Int)],
    oldFloorQ96 := (152767895950099605 : Int),
    newFloorQ96 := (153286924894246425 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_045_before_decode"
  err.flush

theorem decode_moment_record_045 :
    decodeMomentRecord momentJsonRecord045 = .ok momentTypedRecord045 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_045_decoded"
  err.flush

noncomputable def momentJsonRecord046 : SourceJson :=
  (momentRecordsChunk046Push []).head (List.cons_ne_nil _ _)

theorem moment_record_046_push_eq (acc : List SourceJson) :
    momentRecordsChunk046Push acc = momentJsonRecord046 :: acc := by rfl

noncomputable def momentTypedRecord046 : MomentRecord :=
  { simplexId := 46,
    factorFloorsQ80 := #[(417376017164142248562 : Int), (395718261156680025859 : Int), (247411880930901118074 : Int), (369004523462115004655 : Int), (304396333435271302340 : Int), (419164425558127438621 : Int), (1239957895489837844214 : Int), (654919130628675811297 : Int), (738007545660316331257 : Int), (263532803144409909605 : Int)],
    oldFloorQ96 := (325634834991937307 : Int),
    newFloorQ96 := (326997803817881160 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_046_before_decode"
  err.flush

theorem decode_moment_record_046 :
    decodeMomentRecord momentJsonRecord046 = .ok momentTypedRecord046 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_046_decoded"
  err.flush

noncomputable def momentJsonRecord047 : SourceJson :=
  (momentRecordsChunk047Push []).head (List.cons_ne_nil _ _)

theorem moment_record_047_push_eq (acc : List SourceJson) :
    momentRecordsChunk047Push acc = momentJsonRecord047 :: acc := by rfl

noncomputable def momentTypedRecord047 : MomentRecord :=
  { simplexId := 47,
    factorFloorsQ80 := #[(327717682623911933764 : Int), (345479142972089273138 : Int), (248233934500368380853 : Int), (347963819236581706194 : Int), (287175554402808887899 : Int), (345835549599213622668 : Int), (1186288621273940630070 : Int), (471938516951854667382 : Int), (216608110381129824436 : Int), (160486450929404924270 : Int)],
    oldFloorQ96 := (106649940162014075 : Int),
    newFloorQ96 := (106997887961804284 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_047_before_decode"
  err.flush

theorem decode_moment_record_047 :
    decodeMomentRecord momentJsonRecord047 = .ok momentTypedRecord047 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_047_decoded"
  err.flush

noncomputable def momentJsonRecordsBlock011 : List SourceJson := [momentJsonRecord044, momentJsonRecord045, momentJsonRecord046, momentJsonRecord047]
noncomputable def momentTypedRecordsBlock011 : List MomentRecord := [momentTypedRecord044, momentTypedRecord045, momentTypedRecord046, momentTypedRecord047]

theorem moment_records_block_011_push_eq (acc : List SourceJson) :
    momentRecordsBlock011Push acc = [momentJsonRecord047, momentJsonRecord046, momentJsonRecord045, momentJsonRecord044] ++ acc := by rfl

theorem moment_records_block_011_reverse (acc : List SourceJson) :
    (momentRecordsBlock011Push acc).reverse = acc.reverse ++ momentJsonRecordsBlock011 := by
  rw [moment_records_block_011_push_eq, List.reverse_append]
  rfl

theorem decode_moment_records_block_011 :
    momentJsonRecordsBlock011.mapM decodeMomentRecord = .ok momentTypedRecordsBlock011 := by
  simp only [momentJsonRecordsBlock011, momentTypedRecordsBlock011, List.mapM_cons, List.mapM_nil,
    decode_moment_record_044, decode_moment_record_045, decode_moment_record_046, decode_moment_record_047]
  rfl

noncomputable def momentTypedRowsThroughBlock011 : List MomentRecord := momentTypedRowsThroughBlock010 ++ momentTypedRecordsBlock011

theorem decode_moment_records_through_block_011 :
    momentRecordsAcc048.reverse.mapM decodeMomentRecord = .ok momentTypedRowsThroughBlock011 := by
  change (momentRecordsBlock011Push momentRecordsAcc044).reverse.mapM decodeMomentRecord = _
  rw [moment_records_block_011_reverse]
  rw [List.mapM_append, decode_moment_records_through_block_010, decode_moment_records_block_011]
  rfl

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_block_011_complete"
  err.flush

#print axioms moment_record_044_push_eq
#print axioms decode_moment_record_044
#print axioms moment_record_045_push_eq
#print axioms decode_moment_record_045
#print axioms moment_record_046_push_eq
#print axioms decode_moment_record_046
#print axioms moment_record_047_push_eq
#print axioms decode_moment_record_047
#print axioms moment_records_block_011_push_eq
#print axioms moment_records_block_011_reverse
#print axioms decode_moment_records_block_011
#print axioms decode_moment_records_through_block_011

end ImbalancedChen.P2OriginalSaving19Moment06Decoding
