/- SOURCE_CANDIDATE: original Cell06 source only. No Lean compilation,
independent kernel replay, full-owned audit or formal acceptance is claimed. -/

import ImbalancedChen.P2OriginalSaving19Moment06DecodedBlock013
import ImbalancedChen.P2OriginalSaving19Moment06RecordsBlock014

/-! Original typed moment records 56 through 59; each concrete value is checked by original decodeMomentRecord.
Candidate quotations preserve exact original raw bytes. The Lean equations bind
them to the production-compatible packed input and run the unchanged reader.
This local input resolves inside this private project, not the P1 filesystem. -/
namespace ImbalancedChen.P2OriginalSaving19Moment06Decoding
set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false
open ImbalancedChen.P2OriginalSaving19Archive

open ImbalancedChen.P2OriginalSaving19Moment06Parsing

noncomputable def momentJsonRecord056 : SourceJson :=
  (momentRecordsChunk056Push []).head (List.cons_ne_nil _ _)

theorem moment_record_056_push_eq (acc : List SourceJson) :
    momentRecordsChunk056Push acc = momentJsonRecord056 :: acc := by rfl

noncomputable def momentTypedRecord056 : MomentRecord :=
  { simplexId := 56,
    factorFloorsQ80 := #[(172428495663255211363 : Int), (223426777140657338512 : Int), (293278411382421629618 : Int), (240386292669816077968 : Int), (207853001420816652834 : Int), (242886622327007880499 : Int), (1467090870356604951577 : Int), (586814085223858544463 : Int), (719956799265307368962 : Int), (142339966212921324013 : Int)],
    oldFloorQ96 := (4613777029315 : Int),
    newFloorQ96 := (4630203331723 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_056_before_decode"
  err.flush

theorem decode_moment_record_056 :
    decodeMomentRecord momentJsonRecord056 = .ok momentTypedRecord056 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_056_decoded"
  err.flush

noncomputable def momentJsonRecord057 : SourceJson :=
  (momentRecordsChunk057Push []).head (List.cons_ne_nil _ _)

theorem moment_record_057_push_eq (acc : List SourceJson) :
    momentRecordsChunk057Push acc = momentJsonRecord057 :: acc := by rfl

noncomputable def momentTypedRecord057 : MomentRecord :=
  { simplexId := 57,
    factorFloorsQ80 := #[(197942298806707207776 : Int), (239830401828380073816 : Int), (276286541399647061319 : Int), (287108584742765437358 : Int), (249863913205518922888 : Int), (383274009546682185009 : Int), (1539084250631671079837 : Int), (910404107477262232218 : Int), (1084947837707061304259 : Int), (195286025289647840594 : Int)],
    oldFloorQ96 := (22599297520213 : Int),
    newFloorQ96 := (22699793840848 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_057_before_decode"
  err.flush

theorem decode_moment_record_057 :
    decodeMomentRecord momentJsonRecord057 = .ok momentTypedRecord057 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_057_decoded"
  err.flush

noncomputable def momentJsonRecord058 : SourceJson :=
  (momentRecordsChunk058Push []).head (List.cons_ne_nil _ _)

theorem moment_record_058_push_eq (acc : List SourceJson) :
    momentRecordsChunk058Push acc = momentJsonRecord058 :: acc := by rfl

noncomputable def momentTypedRecord058 : MomentRecord :=
  { simplexId := 58,
    factorFloorsQ80 := #[(137793366194442634532 : Int), (217918540963876809051 : Int), (276491750116015254454 : Int), (154100174583201770726 : Int), (130603799233155244027 : Int), (125945679970485614640 : Int), (665927984082298000480 : Int), (583643819574856256743 : Int), (733523950813206468594 : Int), (162930963102594980862 : Int)],
    oldFloorQ96 := (3056911156168 : Int),
    newFloorQ96 := (3064985258633 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_058_before_decode"
  err.flush

theorem decode_moment_record_058 :
    decodeMomentRecord momentJsonRecord058 = .ok momentTypedRecord058 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_058_decoded"
  err.flush

noncomputable def momentJsonRecord059 : SourceJson :=
  (momentRecordsChunk059Push []).head (List.cons_ne_nil _ _)

theorem moment_record_059_push_eq (acc : List SourceJson) :
    momentRecordsChunk059Push acc = momentJsonRecord059 :: acc := by rfl

noncomputable def momentTypedRecord059 : MomentRecord :=
  { simplexId := 59,
    factorFloorsQ80 := #[(152764715466014814478 : Int), (215274988433190521066 : Int), (260689223657700588295 : Int), (209282867405550565449 : Int), (181535997873575752426 : Int), (313033601127334400539 : Int), (845332670331043694509 : Int), (866838497522984809847 : Int), (1051520463336469268278 : Int), (199056167675949621278 : Int)],
    oldFloorQ96 := (15512359534894 : Int),
    newFloorQ96 := (15567573179704 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_059_before_decode"
  err.flush

theorem decode_moment_record_059 :
    decodeMomentRecord momentJsonRecord059 = .ok momentTypedRecord059 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_059_decoded"
  err.flush

noncomputable def momentJsonRecordsBlock014 : List SourceJson := [momentJsonRecord056, momentJsonRecord057, momentJsonRecord058, momentJsonRecord059]
noncomputable def momentTypedRecordsBlock014 : List MomentRecord := [momentTypedRecord056, momentTypedRecord057, momentTypedRecord058, momentTypedRecord059]

theorem moment_records_block_014_push_eq (acc : List SourceJson) :
    momentRecordsBlock014Push acc = [momentJsonRecord059, momentJsonRecord058, momentJsonRecord057, momentJsonRecord056] ++ acc := by rfl

theorem moment_records_block_014_reverse (acc : List SourceJson) :
    (momentRecordsBlock014Push acc).reverse = acc.reverse ++ momentJsonRecordsBlock014 := by
  rw [moment_records_block_014_push_eq, List.reverse_append]
  rfl

theorem decode_moment_records_block_014 :
    momentJsonRecordsBlock014.mapM decodeMomentRecord = .ok momentTypedRecordsBlock014 := by
  simp only [momentJsonRecordsBlock014, momentTypedRecordsBlock014, List.mapM_cons, List.mapM_nil,
    decode_moment_record_056, decode_moment_record_057, decode_moment_record_058, decode_moment_record_059]
  rfl

noncomputable def momentTypedRowsThroughBlock014 : List MomentRecord := momentTypedRowsThroughBlock013 ++ momentTypedRecordsBlock014

theorem decode_moment_records_through_block_014 :
    momentRecordsAcc060.reverse.mapM decodeMomentRecord = .ok momentTypedRowsThroughBlock014 := by
  change (momentRecordsBlock014Push momentRecordsAcc056).reverse.mapM decodeMomentRecord = _
  rw [moment_records_block_014_reverse]
  rw [List.mapM_append, decode_moment_records_through_block_013, decode_moment_records_block_014]
  rfl

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_block_014_complete"
  err.flush

#print axioms moment_record_056_push_eq
#print axioms decode_moment_record_056
#print axioms moment_record_057_push_eq
#print axioms decode_moment_record_057
#print axioms moment_record_058_push_eq
#print axioms decode_moment_record_058
#print axioms moment_record_059_push_eq
#print axioms decode_moment_record_059
#print axioms moment_records_block_014_push_eq
#print axioms moment_records_block_014_reverse
#print axioms decode_moment_records_block_014
#print axioms decode_moment_records_through_block_014

end ImbalancedChen.P2OriginalSaving19Moment06Decoding
