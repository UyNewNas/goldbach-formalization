/- SOURCE_CANDIDATE: original Cell06 source only. No Lean compilation,
independent kernel replay, full-owned audit or formal acceptance is claimed. -/

import ImbalancedChen.P2OriginalSaving19Moment06DecodedBlock022
import ImbalancedChen.P2OriginalSaving19Moment06RecordsBlock023

/-! Original typed moment records 92 through 95; each concrete value is checked by original decodeMomentRecord.
Candidate quotations preserve exact original raw bytes. The Lean equations bind
them to the production-compatible packed input and run the unchanged reader.
This local input resolves inside this private project, not the P1 filesystem. -/
namespace ImbalancedChen.P2OriginalSaving19Moment06Decoding
set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false
open ImbalancedChen.P2OriginalSaving19Archive

open ImbalancedChen.P2OriginalSaving19Moment06Parsing

noncomputable def momentJsonRecord092 : SourceJson :=
  (momentRecordsChunk092Push []).head (List.cons_ne_nil _ _)

theorem moment_record_092_push_eq (acc : List SourceJson) :
    momentRecordsChunk092Push acc = momentJsonRecord092 :: acc := by rfl

noncomputable def momentTypedRecord092 : MomentRecord :=
  { simplexId := 92,
    factorFloorsQ80 := #[(328882356366610342003 : Int), (390016328131178779457 : Int), (303972523529312841035 : Int), (227772860942254407162 : Int), (229982289905363149360 : Int), (216321474063022734088 : Int), (160425786314418915628 : Int), (142964099994504227944 : Int), (368480170491222140898 : Int), (265670113001413444423 : Int)],
    oldFloorQ96 := (1312114757657134 : Int),
    newFloorQ96 := (1314977232540229 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_092_before_decode"
  err.flush

theorem decode_moment_record_092 :
    decodeMomentRecord momentJsonRecord092 = .ok momentTypedRecord092 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_092_decoded"
  err.flush

noncomputable def momentJsonRecord093 : SourceJson :=
  (momentRecordsChunk093Push []).head (List.cons_ne_nil _ _)

theorem moment_record_093_push_eq (acc : List SourceJson) :
    momentRecordsChunk093Push acc = momentJsonRecord093 :: acc := by rfl

noncomputable def momentTypedRecord093 : MomentRecord :=
  { simplexId := 93,
    factorFloorsQ80 := #[(356324997129545263680 : Int), (385039143501039785598 : Int), (280566396003444657316 : Int), (283139645637457030911 : Int), (263493751531543992577 : Int), (228072016473471998317 : Int), (181781955275868647591 : Int), (168259235708437748512 : Int), (402390466060895060262 : Int), (263542847330233874182 : Int)],
    oldFloorQ96 := (8740632067390666 : Int),
    newFloorQ96 := (8760991143766105 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_093_before_decode"
  err.flush

theorem decode_moment_record_093 :
    decodeMomentRecord momentJsonRecord093 = .ok momentTypedRecord093 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_093_decoded"
  err.flush

noncomputable def momentJsonRecord094 : SourceJson :=
  (momentRecordsChunk094Push []).head (List.cons_ne_nil _ _)

theorem moment_record_094_push_eq (acc : List SourceJson) :
    momentRecordsChunk094Push acc = momentJsonRecord094 :: acc := by rfl

noncomputable def momentTypedRecord094 : MomentRecord :=
  { simplexId := 94,
    factorFloorsQ80 := #[(377896357621637566655 : Int), (384353208647597549197 : Int), (259292653019548066825 : Int), (341396457064299066430 : Int), (296887091451177932016 : Int), (302427486300971091145 : Int), (932085906392515893695 : Int), (245779855389123231490 : Int), (462298366261105994417 : Int), (263406657554842890070 : Int)],
    oldFloorQ96 := (68920676858986160 : Int),
    newFloorQ96 := (69141419648770012 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_094_before_decode"
  err.flush

theorem decode_moment_record_094 :
    decodeMomentRecord momentJsonRecord094 = .ok momentTypedRecord094 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_094_decoded"
  err.flush

noncomputable def momentJsonRecord095 : SourceJson :=
  (momentRecordsChunk095Push []).head (List.cons_ne_nil _ _)

theorem moment_record_095_push_eq (acc : List SourceJson) :
    momentRecordsChunk095Push acc = momentJsonRecord095 :: acc := by rfl

noncomputable def momentTypedRecord095 : MomentRecord :=
  { simplexId := 95,
    factorFloorsQ80 := #[(418612906749323422701 : Int), (429642047347732073352 : Int), (245403632597509554669 : Int), (369594731026959215584 : Int), (304691980043682516687 : Int), (391364109754332389606 : Int), (994266323437779538391 : Int), (424760223290406568624 : Int), (671973053125903768198 : Int), (342146483168529003900 : Int)],
    oldFloorQ96 := (338593931310758467 : Int),
    newFloorQ96 := (339882624785807990 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_095_before_decode"
  err.flush

theorem decode_moment_record_095 :
    decodeMomentRecord momentJsonRecord095 = .ok momentTypedRecord095 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_095_decoded"
  err.flush

noncomputable def momentJsonRecordsBlock023 : List SourceJson := [momentJsonRecord092, momentJsonRecord093, momentJsonRecord094, momentJsonRecord095]
noncomputable def momentTypedRecordsBlock023 : List MomentRecord := [momentTypedRecord092, momentTypedRecord093, momentTypedRecord094, momentTypedRecord095]

theorem moment_records_block_023_push_eq (acc : List SourceJson) :
    momentRecordsBlock023Push acc = [momentJsonRecord095, momentJsonRecord094, momentJsonRecord093, momentJsonRecord092] ++ acc := by rfl

theorem moment_records_block_023_reverse (acc : List SourceJson) :
    (momentRecordsBlock023Push acc).reverse = acc.reverse ++ momentJsonRecordsBlock023 := by
  rw [moment_records_block_023_push_eq, List.reverse_append]
  rfl

theorem decode_moment_records_block_023 :
    momentJsonRecordsBlock023.mapM decodeMomentRecord = .ok momentTypedRecordsBlock023 := by
  simp only [momentJsonRecordsBlock023, momentTypedRecordsBlock023, List.mapM_cons, List.mapM_nil,
    decode_moment_record_092, decode_moment_record_093, decode_moment_record_094, decode_moment_record_095]
  rfl

noncomputable def momentTypedRowsThroughBlock023 : List MomentRecord := momentTypedRowsThroughBlock022 ++ momentTypedRecordsBlock023

theorem decode_moment_records_through_block_023 :
    momentRecordsAcc096.reverse.mapM decodeMomentRecord = .ok momentTypedRowsThroughBlock023 := by
  change (momentRecordsBlock023Push momentRecordsAcc092).reverse.mapM decodeMomentRecord = _
  rw [moment_records_block_023_reverse]
  rw [List.mapM_append, decode_moment_records_through_block_022, decode_moment_records_block_023]
  rfl

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_block_023_complete"
  err.flush

#print axioms moment_record_092_push_eq
#print axioms decode_moment_record_092
#print axioms moment_record_093_push_eq
#print axioms decode_moment_record_093
#print axioms moment_record_094_push_eq
#print axioms decode_moment_record_094
#print axioms moment_record_095_push_eq
#print axioms decode_moment_record_095
#print axioms moment_records_block_023_push_eq
#print axioms moment_records_block_023_reverse
#print axioms decode_moment_records_block_023
#print axioms decode_moment_records_through_block_023

end ImbalancedChen.P2OriginalSaving19Moment06Decoding
