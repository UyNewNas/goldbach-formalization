/- SOURCE_CANDIDATE: original Cell06 source only. No Lean compilation,
independent kernel replay, full-owned audit or formal acceptance is claimed. -/

import ImbalancedChen.P2OriginalSaving19Moment06DecodedBlock003
import ImbalancedChen.P2OriginalSaving19Moment06RecordsBlock004

/-! Original typed moment records 16 through 19; each concrete value is checked by original decodeMomentRecord.
Candidate quotations preserve exact original raw bytes. The Lean equations bind
them to the production-compatible packed input and run the unchanged reader.
This local input resolves inside this private project, not the P1 filesystem. -/
namespace ImbalancedChen.P2OriginalSaving19Moment06Decoding
set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false
open ImbalancedChen.P2OriginalSaving19Archive

open ImbalancedChen.P2OriginalSaving19Moment06Parsing

noncomputable def momentJsonRecord016 : SourceJson :=
  (momentRecordsChunk016Push []).head (List.cons_ne_nil _ _)

theorem moment_record_016_push_eq (acc : List SourceJson) :
    momentRecordsChunk016Push acc = momentJsonRecord016 :: acc := by rfl

noncomputable def momentTypedRecord016 : MomentRecord :=
  { simplexId := 16,
    factorFloorsQ80 := #[(391613210077557707080 : Int), (358695883897764198314 : Int), (140101420206554893455 : Int), (242766914292379224874 : Int), (282565529353651491939 : Int), (242785442438562136029 : Int), (794022137261633986418 : Int), (390692178897238565474 : Int), (447898357023344315036 : Int), (485147876967109622259 : Int)],
    oldFloorQ96 := (486726412118222759 : Int),
    newFloorQ96 := (488249163321960289 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_016_before_decode"
  err.flush

theorem decode_moment_record_016 :
    decodeMomentRecord momentJsonRecord016 = .ok momentTypedRecord016 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_016_decoded"
  err.flush

noncomputable def momentJsonRecord017 : SourceJson :=
  (momentRecordsChunk017Push []).head (List.cons_ne_nil _ _)

theorem moment_record_017_push_eq (acc : List SourceJson) :
    momentRecordsChunk017Push acc = momentJsonRecord017 :: acc := by rfl

noncomputable def momentTypedRecord017 : MomentRecord :=
  { simplexId := 17,
    factorFloorsQ80 := #[(278734802259614492796 : Int), (300496189549836248069 : Int), (122727205572442694455 : Int), (267650604114702273877 : Int), (295001756571310659292 : Int), (222687218144263360704 : Int), (776117283425315495483 : Int), (365049014888002244498 : Int), (454751726158346044149 : Int), (432350498747667115773 : Int)],
    oldFloorQ96 := (26702026308929 : Int),
    newFloorQ96 := (26779789035109 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_017_before_decode"
  err.flush

theorem decode_moment_record_017 :
    decodeMomentRecord momentJsonRecord017 = .ok momentTypedRecord017 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_017_decoded"
  err.flush

noncomputable def momentJsonRecord018 : SourceJson :=
  (momentRecordsChunk018Push []).head (List.cons_ne_nil _ _)

theorem moment_record_018_push_eq (acc : List SourceJson) :
    momentRecordsChunk018Push acc = momentJsonRecord018 :: acc := by rfl

noncomputable def momentTypedRecord018 : MomentRecord :=
  { simplexId := 18,
    factorFloorsQ80 := #[(285119874130988105629 : Int), (295765089217807278733 : Int), (122727205572442694455 : Int), (227662035069001176117 : Int), (295001756571310659292 : Int), (222687218144263360704 : Int), (776117283425315495483 : Int), (365049014888002244498 : Int), (370473783734692506719 : Int), (280137829579409949235 : Int)],
    oldFloorQ96 := (278721470275462488 : Int),
    newFloorQ96 := (279469635190827225 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_018_before_decode"
  err.flush

theorem decode_moment_record_018 :
    decodeMomentRecord momentJsonRecord018 = .ok momentTypedRecord018 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_018_decoded"
  err.flush

noncomputable def momentJsonRecord019 : SourceJson :=
  (momentRecordsChunk019Push []).head (List.cons_ne_nil _ _)

theorem moment_record_019_push_eq (acc : List SourceJson) :
    momentRecordsChunk019Push acc = momentJsonRecord019 :: acc := by rfl

noncomputable def momentTypedRecord019 : MomentRecord :=
  { simplexId := 19,
    factorFloorsQ80 := #[(88378100284953292706 : Int), (212037190952082011931 : Int), (277134948692250113417 : Int), (84551999063535835519 : Int), (151581010622950055193 : Int), (124744452111641330157 : Int), (131965612951926771088 : Int), (123308373718289294512 : Int), (367978283289269988705 : Int), (78943362900830949543 : Int)],
    oldFloorQ96 := (55861303567887 : Int),
    newFloorQ96 := (55937163948827 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_019_before_decode"
  err.flush

theorem decode_moment_record_019 :
    decodeMomentRecord momentJsonRecord019 = .ok momentTypedRecord019 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_019_decoded"
  err.flush

noncomputable def momentJsonRecordsBlock004 : List SourceJson := [momentJsonRecord016, momentJsonRecord017, momentJsonRecord018, momentJsonRecord019]
noncomputable def momentTypedRecordsBlock004 : List MomentRecord := [momentTypedRecord016, momentTypedRecord017, momentTypedRecord018, momentTypedRecord019]

theorem moment_records_block_004_push_eq (acc : List SourceJson) :
    momentRecordsBlock004Push acc = [momentJsonRecord019, momentJsonRecord018, momentJsonRecord017, momentJsonRecord016] ++ acc := by rfl

theorem moment_records_block_004_reverse (acc : List SourceJson) :
    (momentRecordsBlock004Push acc).reverse = acc.reverse ++ momentJsonRecordsBlock004 := by
  rw [moment_records_block_004_push_eq, List.reverse_append]
  rfl

theorem decode_moment_records_block_004 :
    momentJsonRecordsBlock004.mapM decodeMomentRecord = .ok momentTypedRecordsBlock004 := by
  simp only [momentJsonRecordsBlock004, momentTypedRecordsBlock004, List.mapM_cons, List.mapM_nil,
    decode_moment_record_016, decode_moment_record_017, decode_moment_record_018, decode_moment_record_019]
  rfl

noncomputable def momentTypedRowsThroughBlock004 : List MomentRecord := momentTypedRowsThroughBlock003 ++ momentTypedRecordsBlock004

theorem decode_moment_records_through_block_004 :
    momentRecordsAcc020.reverse.mapM decodeMomentRecord = .ok momentTypedRowsThroughBlock004 := by
  change (momentRecordsBlock004Push momentRecordsAcc016).reverse.mapM decodeMomentRecord = _
  rw [moment_records_block_004_reverse]
  rw [List.mapM_append, decode_moment_records_through_block_003, decode_moment_records_block_004]
  rfl

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_block_004_complete"
  err.flush

#print axioms moment_record_016_push_eq
#print axioms decode_moment_record_016
#print axioms moment_record_017_push_eq
#print axioms decode_moment_record_017
#print axioms moment_record_018_push_eq
#print axioms decode_moment_record_018
#print axioms moment_record_019_push_eq
#print axioms decode_moment_record_019
#print axioms moment_records_block_004_push_eq
#print axioms moment_records_block_004_reverse
#print axioms decode_moment_records_block_004
#print axioms decode_moment_records_through_block_004

end ImbalancedChen.P2OriginalSaving19Moment06Decoding
