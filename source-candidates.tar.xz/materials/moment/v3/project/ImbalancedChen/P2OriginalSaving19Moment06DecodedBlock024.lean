/- SOURCE_CANDIDATE: original Cell06 source only. No Lean compilation,
independent kernel replay, full-owned audit or formal acceptance is claimed. -/

import ImbalancedChen.P2OriginalSaving19Moment06DecodedBlock023
import ImbalancedChen.P2OriginalSaving19Moment06RecordsBlock024

/-! Original typed moment records 96 through 99; each concrete value is checked by original decodeMomentRecord.
Candidate quotations preserve exact original raw bytes. The Lean equations bind
them to the production-compatible packed input and run the unchanged reader.
This local input resolves inside this private project, not the P1 filesystem. -/
namespace ImbalancedChen.P2OriginalSaving19Moment06Decoding
set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false
open ImbalancedChen.P2OriginalSaving19Archive

open ImbalancedChen.P2OriginalSaving19Moment06Parsing

noncomputable def momentJsonRecord096 : SourceJson :=
  (momentRecordsChunk096Push []).head (List.cons_ne_nil _ _)

theorem moment_record_096_push_eq (acc : List SourceJson) :
    momentRecordsChunk096Push acc = momentJsonRecord096 :: acc := by rfl

noncomputable def momentTypedRecord096 : MomentRecord :=
  { simplexId := 96,
    factorFloorsQ80 := #[(325522809004569827021 : Int), (392065819347848661267 : Int), (342961815100964746222 : Int), (220117494699944312868 : Int), (141752710461508983249 : Int), (194188952995690678623 : Int), (244396387883300220717 : Int), (208664379048745655453 : Int), (397754553306663509139 : Int), (270425698021289515774 : Int)],
    oldFloorQ96 := (1255622494742838 : Int),
    newFloorQ96 := (1258469321562469 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_096_before_decode"
  err.flush

theorem decode_moment_record_096 :
    decodeMomentRecord momentJsonRecord096 = .ok momentTypedRecord096 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_096_decoded"
  err.flush

noncomputable def momentJsonRecord097 : SourceJson :=
  (momentRecordsChunk097Push []).head (List.cons_ne_nil _ _)

theorem moment_record_097_push_eq (acc : List SourceJson) :
    momentRecordsChunk097Push acc = momentJsonRecord097 :: acc := by rfl

noncomputable def momentTypedRecord097 : MomentRecord :=
  { simplexId := 97,
    factorFloorsQ80 := #[(353984278336405337765 : Int), (386919865985986967250 : Int), (315432447610494548369 : Int), (285115289087561255395 : Int), (193573632969663786875 : Int), (213328910568986493094 : Int), (284994945959210118492 : Int), (252619514646681656633 : Int), (451719313034647564223 : Int), (268148325233524491426 : Int)],
    oldFloorQ96 := (8357460269077095 : Int),
    newFloorQ96 := (8378265859494465 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_097_before_decode"
  err.flush

theorem decode_moment_record_097 :
    decodeMomentRecord momentJsonRecord097 = .ok momentTypedRecord097 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_097_decoded"
  err.flush

noncomputable def momentJsonRecord098 : SourceJson :=
  (momentRecordsChunk098Push []).head (List.cons_ne_nil _ _)

theorem moment_record_098_push_eq (acc : List SourceJson) :
    momentRecordsChunk098Push acc = momentJsonRecord098 :: acc := by rfl

noncomputable def momentTypedRecord098 : MomentRecord :=
  { simplexId := 98,
    factorFloorsQ80 := #[(376632589394763576670 : Int), (386201326617017699958 : Int), (290930063614823580037 : Int), (354322425165976439048 : Int), (247825694565207465728 : Int), (309780529437893364710 : Int), (1173782973547216363299 : Int), (290369017714410018209 : Int), (468568503043232950000 : Int), (267983173948418957535 : Int)],
    oldFloorQ96 := (65850711711569122 : Int),
    newFloorQ96 := (66078048635257258 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_098_before_decode"
  err.flush

theorem decode_moment_record_098 :
    decodeMomentRecord momentJsonRecord098 = .ok momentTypedRecord098 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_098_decoded"
  err.flush

noncomputable def momentJsonRecord099 : SourceJson :=
  (momentRecordsChunk099Push []).head (List.cons_ne_nil _ _)

theorem moment_record_099_push_eq (acc : List SourceJson) :
    momentRecordsChunk099Push acc = momentJsonRecord099 :: acc := by rfl

noncomputable def momentTypedRecord099 : MomentRecord :=
  { simplexId := 99,
    factorFloorsQ80 := #[(416299025524565450484 : Int), (429490457262746734306 : Int), (275382780217035446297 : Int), (391505531088760908627 : Int), (272798045351825757873 : Int), (423529305309410269283 : Int), (1267924846837709547697 : Int), (535046171972198608626 : Int), (748621814300829390814 : Int), (344959537366660479689 : Int)],
    oldFloorQ96 := (322935742213871187 : Int),
    newFloorQ96 := (324302454241452554 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_099_before_decode"
  err.flush

theorem decode_moment_record_099 :
    decodeMomentRecord momentJsonRecord099 = .ok momentTypedRecord099 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_099_decoded"
  err.flush

noncomputable def momentJsonRecordsBlock024 : List SourceJson := [momentJsonRecord096, momentJsonRecord097, momentJsonRecord098, momentJsonRecord099]
noncomputable def momentTypedRecordsBlock024 : List MomentRecord := [momentTypedRecord096, momentTypedRecord097, momentTypedRecord098, momentTypedRecord099]

theorem moment_records_block_024_push_eq (acc : List SourceJson) :
    momentRecordsBlock024Push acc = [momentJsonRecord099, momentJsonRecord098, momentJsonRecord097, momentJsonRecord096] ++ acc := by rfl

theorem moment_records_block_024_reverse (acc : List SourceJson) :
    (momentRecordsBlock024Push acc).reverse = acc.reverse ++ momentJsonRecordsBlock024 := by
  rw [moment_records_block_024_push_eq, List.reverse_append]
  rfl

theorem decode_moment_records_block_024 :
    momentJsonRecordsBlock024.mapM decodeMomentRecord = .ok momentTypedRecordsBlock024 := by
  simp only [momentJsonRecordsBlock024, momentTypedRecordsBlock024, List.mapM_cons, List.mapM_nil,
    decode_moment_record_096, decode_moment_record_097, decode_moment_record_098, decode_moment_record_099]
  rfl

noncomputable def momentTypedRowsThroughBlock024 : List MomentRecord := momentTypedRowsThroughBlock023 ++ momentTypedRecordsBlock024

theorem decode_moment_records_through_block_024 :
    momentRecordsAcc100.reverse.mapM decodeMomentRecord = .ok momentTypedRowsThroughBlock024 := by
  change (momentRecordsBlock024Push momentRecordsAcc096).reverse.mapM decodeMomentRecord = _
  rw [moment_records_block_024_reverse]
  rw [List.mapM_append, decode_moment_records_through_block_023, decode_moment_records_block_024]
  rfl

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_block_024_complete"
  err.flush

#print axioms moment_record_096_push_eq
#print axioms decode_moment_record_096
#print axioms moment_record_097_push_eq
#print axioms decode_moment_record_097
#print axioms moment_record_098_push_eq
#print axioms decode_moment_record_098
#print axioms moment_record_099_push_eq
#print axioms decode_moment_record_099
#print axioms moment_records_block_024_push_eq
#print axioms moment_records_block_024_reverse
#print axioms decode_moment_records_block_024
#print axioms decode_moment_records_through_block_024

end ImbalancedChen.P2OriginalSaving19Moment06Decoding
