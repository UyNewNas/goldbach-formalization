/- SOURCE_CANDIDATE: original Cell06 source only. No Lean compilation,
independent kernel replay, full-owned audit or formal acceptance is claimed. -/

import ImbalancedChen.P2OriginalSaving19Moment06DecodedBlock005
import ImbalancedChen.P2OriginalSaving19Moment06RecordsBlock006

/-! Original typed moment records 24 through 27; each concrete value is checked by original decodeMomentRecord.
Candidate quotations preserve exact original raw bytes. The Lean equations bind
them to the production-compatible packed input and run the unchanged reader.
This local input resolves inside this private project, not the P1 filesystem. -/
namespace ImbalancedChen.P2OriginalSaving19Moment06Decoding
set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false
open ImbalancedChen.P2OriginalSaving19Archive

open ImbalancedChen.P2OriginalSaving19Moment06Parsing

noncomputable def momentJsonRecord024 : SourceJson :=
  (momentRecordsChunk024Push []).head (List.cons_ne_nil _ _)

theorem moment_record_024_push_eq (acc : List SourceJson) :
    momentRecordsChunk024Push acc = momentJsonRecord024 :: acc := by rfl

noncomputable def momentTypedRecord024 : MomentRecord :=
  { simplexId := 24,
    factorFloorsQ80 := #[(490824432254427463002 : Int), (456674300444438082817 : Int), (202931646173012711981 : Int), (324265202548427870109 : Int), (308519012387260021850 : Int), (345382011639592469930 : Int), (970460443540950666426 : Int), (412601775921865393565 : Int), (662148136654088010975 : Int), (307134994551511538975 : Int)],
    oldFloorQ96 := (41749314174839 : Int),
    newFloorQ96 := (41904347165638 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_024_before_decode"
  err.flush

theorem decode_moment_record_024 :
    decodeMomentRecord momentJsonRecord024 = .ok momentTypedRecord024 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_024_decoded"
  err.flush

noncomputable def momentJsonRecord025 : SourceJson :=
  (momentRecordsChunk025Push []).head (List.cons_ne_nil _ _)

theorem moment_record_025_push_eq (acc : List SourceJson) :
    momentRecordsChunk025Push acc = momentJsonRecord025 :: acc := by rfl

noncomputable def momentTypedRecord025 : MomentRecord :=
  { simplexId := 25,
    factorFloorsQ80 := #[(342521522612602496543 : Int), (321937724716166290589 : Int), (248865551164882938874 : Int), (226143413576811777922 : Int), (259298637957504166438 : Int), (198296550979068687391 : Int), (161936942931812108126 : Int), (153941918434455145625 : Int), (381027456926184884424 : Int), (151783241061764927728 : Int)],
    oldFloorQ96 := (4711496048645113 : Int),
    newFloorQ96 := (4721037427620835 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_025_before_decode"
  err.flush

theorem decode_moment_record_025 :
    decodeMomentRecord momentJsonRecord025 = .ok momentTypedRecord025 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_025_decoded"
  err.flush

noncomputable def momentJsonRecord026 : SourceJson :=
  (momentRecordsChunk026Push []).head (List.cons_ne_nil _ _)

theorem moment_record_026_push_eq (acc : List SourceJson) :
    momentRecordsChunk026Push acc = momentJsonRecord026 :: acc := by rfl

noncomputable def momentTypedRecord026 : MomentRecord :=
  { simplexId := 26,
    factorFloorsQ80 := #[(350405082168440592707 : Int), (322436461933996557237 : Int), (233221064311510640728 : Int), (270850724221927261505 : Int), (287656375830657103580 : Int), (262311244788450979222 : Int), (876517261144001301179 : Int), (242399546357272573572 : Int), (416074439488462585295 : Int), (152186672877864440182 : Int)],
    oldFloorQ96 := (29960377335743016 : Int),
    newFloorQ96 := (30045106321694561 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_026_before_decode"
  err.flush

theorem decode_moment_record_026 :
    decodeMomentRecord momentJsonRecord026 = .ok momentTypedRecord026 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_026_decoded"
  err.flush

noncomputable def momentJsonRecord027 : SourceJson :=
  (momentRecordsChunk027Push []).head (List.cons_ne_nil _ _)

theorem moment_record_027_push_eq (acc : List SourceJson) :
    momentRecordsChunk027Push acc = momentJsonRecord027 :: acc := by rfl

noncomputable def momentTypedRecord027 : MomentRecord :=
  { simplexId := 27,
    factorFloorsQ80 := #[(359177561570142772420 : Int), (315817900727703000734 : Int), (216582018105126658989 : Int), (306286454164662773427 : Int), (305904826352282287919 : Int), (305567792730585166912 : Int), (1350935253890891517936 : Int), (311893868061583989099 : Int), (460631896635442571323 : Int), (151358815476466103466 : Int)],
    oldFloorQ96 := (6833775939130 : Int),
    newFloorQ96 := (6856901764809 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_027_before_decode"
  err.flush

theorem decode_moment_record_027 :
    decodeMomentRecord momentJsonRecord027 = .ok momentTypedRecord027 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_027_decoded"
  err.flush

noncomputable def momentJsonRecordsBlock006 : List SourceJson := [momentJsonRecord024, momentJsonRecord025, momentJsonRecord026, momentJsonRecord027]
noncomputable def momentTypedRecordsBlock006 : List MomentRecord := [momentTypedRecord024, momentTypedRecord025, momentTypedRecord026, momentTypedRecord027]

theorem moment_records_block_006_push_eq (acc : List SourceJson) :
    momentRecordsBlock006Push acc = [momentJsonRecord027, momentJsonRecord026, momentJsonRecord025, momentJsonRecord024] ++ acc := by rfl

theorem moment_records_block_006_reverse (acc : List SourceJson) :
    (momentRecordsBlock006Push acc).reverse = acc.reverse ++ momentJsonRecordsBlock006 := by
  rw [moment_records_block_006_push_eq, List.reverse_append]
  rfl

theorem decode_moment_records_block_006 :
    momentJsonRecordsBlock006.mapM decodeMomentRecord = .ok momentTypedRecordsBlock006 := by
  simp only [momentJsonRecordsBlock006, momentTypedRecordsBlock006, List.mapM_cons, List.mapM_nil,
    decode_moment_record_024, decode_moment_record_025, decode_moment_record_026, decode_moment_record_027]
  rfl

noncomputable def momentTypedRowsThroughBlock006 : List MomentRecord := momentTypedRowsThroughBlock005 ++ momentTypedRecordsBlock006

theorem decode_moment_records_through_block_006 :
    momentRecordsAcc028.reverse.mapM decodeMomentRecord = .ok momentTypedRowsThroughBlock006 := by
  change (momentRecordsBlock006Push momentRecordsAcc024).reverse.mapM decodeMomentRecord = _
  rw [moment_records_block_006_reverse]
  rw [List.mapM_append, decode_moment_records_through_block_005, decode_moment_records_block_006]
  rfl

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_block_006_complete"
  err.flush

#print axioms moment_record_024_push_eq
#print axioms decode_moment_record_024
#print axioms moment_record_025_push_eq
#print axioms decode_moment_record_025
#print axioms moment_record_026_push_eq
#print axioms decode_moment_record_026
#print axioms moment_record_027_push_eq
#print axioms decode_moment_record_027
#print axioms moment_records_block_006_push_eq
#print axioms moment_records_block_006_reverse
#print axioms decode_moment_records_block_006
#print axioms decode_moment_records_through_block_006

end ImbalancedChen.P2OriginalSaving19Moment06Decoding
