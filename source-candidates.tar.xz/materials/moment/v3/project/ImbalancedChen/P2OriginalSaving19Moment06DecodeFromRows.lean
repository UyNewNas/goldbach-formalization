/- SOURCE_CANDIDATE: original Cell06 source only. No Lean compilation,
independent kernel replay, full-owned audit or formal acceptance is claimed. -/

import ImbalancedChen.P2OriginalSaving19Moment06DecodeMetadata

/-! Abstract monadic composition of the original decoder. No concrete record list is reduced here.
Candidate quotations preserve exact original raw bytes. The Lean equations bind
them to the production-compatible packed input and run the unchanged reader.
This local input resolves inside this private project, not the P1 filesystem. -/
namespace ImbalancedChen.P2OriginalSaving19Moment06Decoding
set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false
open ImbalancedChen.P2OriginalSaving19Archive

open ImbalancedChen.P2OriginalSaving19Moment06Parsing

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 abstract_rows_before_glue"
  err.flush

theorem decodeMoments_of_records_decode
    (sourceRecords : List SourceJson) (typedRecords : List MomentRecord)
    (hrecords : sourceRecords.mapM decodeMomentRecord = .ok typedRecords) :
    decodeMoments (momentObjectWithRecords sourceRecords) =
      .ok (momentMomentsWithRows typedRecords.toArray) := by
  rw [decodeMoments_momentObjectWithRecords, List.mapM_toArray, hrecords]
  rfl

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 abstract_rows_glue_complete"
  err.flush

#print axioms decodeMoments_of_records_decode

end ImbalancedChen.P2OriginalSaving19Moment06Decoding
