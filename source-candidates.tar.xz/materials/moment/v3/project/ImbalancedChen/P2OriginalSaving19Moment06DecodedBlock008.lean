/- SOURCE_CANDIDATE: original Cell06 source only. No Lean compilation,
independent kernel replay, full-owned audit or formal acceptance is claimed. -/

import ImbalancedChen.P2OriginalSaving19Moment06DecodedBlock007
import ImbalancedChen.P2OriginalSaving19Moment06RecordsBlock008

/-! Original typed moment records 32 through 35; each concrete value is checked by original decodeMomentRecord.
Candidate quotations preserve exact original raw bytes. The Lean equations bind
them to the production-compatible packed input and run the unchanged reader.
This local input resolves inside this private project, not the P1 filesystem. -/
namespace ImbalancedChen.P2OriginalSaving19Moment06Decoding
set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false
open ImbalancedChen.P2OriginalSaving19Archive

open ImbalancedChen.P2OriginalSaving19Moment06Parsing

noncomputable def momentJsonRecord032 : SourceJson :=
  (momentRecordsChunk032Push []).head (List.cons_ne_nil _ _)

theorem moment_record_032_push_eq (acc : List SourceJson) :
    momentRecordsChunk032Push acc = momentJsonRecord032 :: acc := by rfl

noncomputable def momentTypedRecord032 : MomentRecord :=
  { simplexId := 32,
    factorFloorsQ80 := #[(354867450950107526161 : Int), (315979778338301137725 : Int), (231728664524685557485 : Int), (262224056807776873226 : Int), (280520264047031800207 : Int), (203649952202494514217 : Int), (174875606861144030122 : Int), (170036470855083462339 : Int), (419776066188154007959 : Int), (151031153608087087369 : Int)],
    oldFloorQ96 := (8816873837687714 : Int),
    newFloorQ96 := (8835598349856911 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_032_before_decode"
  err.flush

theorem decode_moment_record_032 :
    decodeMomentRecord momentJsonRecord032 = .ok momentTypedRecord032 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_032_decoded"
  err.flush

noncomputable def momentJsonRecord033 : SourceJson :=
  (momentRecordsChunk033Push []).head (List.cons_ne_nil _ _)

theorem moment_record_033_push_eq (acc : List SourceJson) :
    momentRecordsChunk033Push acc = momentJsonRecord033 :: acc := by rfl

noncomputable def momentTypedRecord033 : MomentRecord :=
  { simplexId := 33,
    factorFloorsQ80 := #[(359175013027834108296 : Int), (315816894224171577094 : Int), (214813363514967390434 : Int), (298501947683552377067 : Int), (299693462116939699595 : Int), (260016756399377606652 : Int), (860825192161835738779 : Int), (265923135191083763171 : Int), (475770516857541036687 : Int), (151359170234062783569 : Int)],
    oldFloorQ96 := (69588021493291886 : Int),
    newFloorQ96 := (69789889350819085 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_033_before_decode"
  err.flush

theorem decode_moment_record_033 :
    decodeMomentRecord momentJsonRecord033 = .ok momentTypedRecord033 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_033_decoded"
  err.flush

noncomputable def momentJsonRecord034 : SourceJson :=
  (momentRecordsChunk034Push []).head (List.cons_ne_nil _ _)

theorem moment_record_034_push_eq (acc : List SourceJson) :
    momentRecordsChunk034Push acc = momentJsonRecord034 :: acc := by rfl

noncomputable def momentTypedRecord034 : MomentRecord :=
  { simplexId := 34,
    factorFloorsQ80 := #[(416626456987624465326 : Int), (393042582832375086419 : Int), (203163383474961331002 : Int), (308676370424716457807 : Int), (295814107612500191698 : Int), (328740965203884043654 : Int), (908200665763130657090 : Int), (414702129210494092404 : Int), (691971869039757607415 : Int), (258225440490304291610 : Int)],
    oldFloorQ96 := (341857767421876536 : Int),
    newFloorQ96 := (343052939032461133 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_034_before_decode"
  err.flush

theorem decode_moment_record_034 :
    decodeMomentRecord momentJsonRecord034 = .ok momentTypedRecord034 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_034_decoded"
  err.flush

noncomputable def momentJsonRecord035 : SourceJson :=
  (momentRecordsChunk035Push []).head (List.cons_ne_nil _ _)

theorem moment_record_035_push_eq (acc : List SourceJson) :
    momentRecordsChunk035Push acc = momentJsonRecord035 :: acc := by rfl

noncomputable def momentTypedRecord035 : MomentRecord :=
  { simplexId := 35,
    factorFloorsQ80 := #[(327840389350172725089 : Int), (346791751168331123033 : Int), (178737176258149031680 : Int), (303333955956475506540 : Int), (332445930230599049219 : Int), (306769048662986764432 : Int), (888541421986250747383 : Int), (386812612818458591778 : Int), (359017014964052442524 : Int), (154174745737552687401 : Int)],
    oldFloorQ96 := (195936481291147887 : Int),
    newFloorQ96 := (196518294906374783 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_035_before_decode"
  err.flush

theorem decode_moment_record_035 :
    decodeMomentRecord momentJsonRecord035 = .ok momentTypedRecord035 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_035_decoded"
  err.flush

noncomputable def momentJsonRecordsBlock008 : List SourceJson := [momentJsonRecord032, momentJsonRecord033, momentJsonRecord034, momentJsonRecord035]
noncomputable def momentTypedRecordsBlock008 : List MomentRecord := [momentTypedRecord032, momentTypedRecord033, momentTypedRecord034, momentTypedRecord035]

theorem moment_records_block_008_push_eq (acc : List SourceJson) :
    momentRecordsBlock008Push acc = [momentJsonRecord035, momentJsonRecord034, momentJsonRecord033, momentJsonRecord032] ++ acc := by rfl

theorem moment_records_block_008_reverse (acc : List SourceJson) :
    (momentRecordsBlock008Push acc).reverse = acc.reverse ++ momentJsonRecordsBlock008 := by
  rw [moment_records_block_008_push_eq, List.reverse_append]
  rfl

theorem decode_moment_records_block_008 :
    momentJsonRecordsBlock008.mapM decodeMomentRecord = .ok momentTypedRecordsBlock008 := by
  simp only [momentJsonRecordsBlock008, momentTypedRecordsBlock008, List.mapM_cons, List.mapM_nil,
    decode_moment_record_032, decode_moment_record_033, decode_moment_record_034, decode_moment_record_035]
  rfl

noncomputable def momentTypedRowsThroughBlock008 : List MomentRecord := momentTypedRowsThroughBlock007 ++ momentTypedRecordsBlock008

theorem decode_moment_records_through_block_008 :
    momentRecordsAcc036.reverse.mapM decodeMomentRecord = .ok momentTypedRowsThroughBlock008 := by
  change (momentRecordsBlock008Push momentRecordsAcc032).reverse.mapM decodeMomentRecord = _
  rw [moment_records_block_008_reverse]
  rw [List.mapM_append, decode_moment_records_through_block_007, decode_moment_records_block_008]
  rfl

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_block_008_complete"
  err.flush

#print axioms moment_record_032_push_eq
#print axioms decode_moment_record_032
#print axioms moment_record_033_push_eq
#print axioms decode_moment_record_033
#print axioms moment_record_034_push_eq
#print axioms decode_moment_record_034
#print axioms moment_record_035_push_eq
#print axioms decode_moment_record_035
#print axioms moment_records_block_008_push_eq
#print axioms moment_records_block_008_reverse
#print axioms decode_moment_records_block_008
#print axioms decode_moment_records_through_block_008

end ImbalancedChen.P2OriginalSaving19Moment06Decoding
