/- SOURCE_CANDIDATE: original Cell06 source only. No Lean compilation,
independent kernel replay, full-owned audit or formal acceptance is claimed. -/

import ImbalancedChen.P2OriginalSaving19Moment06RecordsBlock018

/-! Original moment records block 19. Small arbitrary-tail/accumulator parser equations and one exact packed-input binding.
Candidate quotations preserve exact original raw bytes. The Lean equations bind
them to the production-compatible packed input and run the unchanged reader.
This local input resolves inside this private project, not the P1 filesystem. -/
namespace ImbalancedChen.P2OriginalSaving19Moment06Parsing
set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false
open ImbalancedChen.P2OriginalSaving19Archive

noncomputable def momentRecordsChunk076Chars : List Char := ['\r', '\n', ' ', ' ', ' ', ' ', '{', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 's', 'i', 'm', 'p', 'l', 'e', 'x', '_', 'i', 'd', '"', ':', ' ', '7', '6', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'l', 'o', 'g', '_', 'g', 'a', 'p', '_', 'f', 'a', 'c', 't', 'o', 'r', '_', 'f', 'l', 'o', 'o', 'r', 's', '_', 'Q', '8', '0', '"', ':', ' ', '[', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '1', '6', '2', '2', '2', '6', '4', '1', '0', '1', '5', '7', '8', '1', '8', '7', '6', '2', '0', '6', '5', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '8', '5', '6', '1', '2', '2', '2', '5', '0', '7', '4', '7', '4', '0', '7', '3', '5', '1', '0', '0', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '3', '3', '8', '8', '9', '3', '4', '8', '9', '9', '3', '5', '4', '1', '4', '8', '8', '3', '2', '0', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '1', '2', '9', '9', '1', '0', '6', '8', '2', '4', '6', '0', '8', '4', '7', '6', '8', '9', '1', '2', '2', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '1', '1', '2', '0', '4', '4', '0', '9', '3', '6', '4', '5', '9', '3', '1', '1', '4', '9', '9', '2', '5', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '8', '3', '4', '3', '4', '9', '1', '0', '9', '8', '0', '9', '9', '1', '4', '6', '6', '6', '0', '7', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '7', '9', '2', '7', '4', '3', '3', '0', '5', '3', '2', '8', '9', '1', '9', '9', '7', '2', '9', '6', '5', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '9', '5', '5', '7', '4', '9', '8', '0', '0', '5', '5', '5', '4', '3', '3', '9', '4', '0', '1', '2', '4', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '1', '1', '2', '6', '6', '3', '2', '7', '4', '5', '3', '8', '8', '6', '3', '8', '6', '3', '0', '7', '4', '7', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '3', '5', '2', '3', '6', '9', '5', '8', '6', '1', '4', '9', '3', '8', '2', '5', '5', '2', '8', '1', '7', '"', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ']', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'o', 'l', 'd', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6', '"', ':', ' ', '"', '1', '4', '7', '6', '8', '1', '5', '2', '8', '6', '1', '1', '1', '6', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'n', 'e', 'w', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6', '"', ':', ' ', '"', '1', '4', '8', '2', '2', '4', '2', '5', '2', '6', '3', '9', '8', '3', '"', '\r', '\n', ' ', ' ', ' ', ' ', '}', ',']
noncomputable def momentRecordsChunk076Push (acc : List SourceJson) : List SourceJson :=
  (.obj [(String.ofList ['s', 'i', 'm', 'p', 'l', 'e', 'x', '_', 'i', 'd'], .number (String.ofList ['7', '6'])), (String.ofList ['l', 'o', 'g', '_', 'g', 'a', 'p', '_', 'f', 'a', 'c', 't', 'o', 'r', '_', 'f', 'l', 'o', 'o', 'r', 's', '_', 'Q', '8', '0'], .arr [.str (String.ofList ['1', '6', '2', '2', '2', '6', '4', '1', '0', '1', '5', '7', '8', '1', '8', '7', '6', '2', '0', '6', '5']), .str (String.ofList ['2', '8', '5', '6', '1', '2', '2', '2', '5', '0', '7', '4', '7', '4', '0', '7', '3', '5', '1', '0', '0']), .str (String.ofList ['2', '3', '3', '8', '8', '9', '3', '4', '8', '9', '9', '3', '5', '4', '1', '4', '8', '8', '3', '2', '0']), .str (String.ofList ['1', '2', '9', '9', '1', '0', '6', '8', '2', '4', '6', '0', '8', '4', '7', '6', '8', '9', '1', '2', '2']), .str (String.ofList ['1', '1', '2', '0', '4', '4', '0', '9', '3', '6', '4', '5', '9', '3', '1', '1', '4', '9', '9', '2', '5']), .str (String.ofList ['2', '8', '3', '4', '3', '4', '9', '1', '0', '9', '8', '0', '9', '9', '1', '4', '6', '6', '6', '0', '7']), .str (String.ofList ['7', '9', '2', '7', '4', '3', '3', '0', '5', '3', '2', '8', '9', '1', '9', '9', '7', '2', '9', '6', '5']), .str (String.ofList ['9', '5', '5', '7', '4', '9', '8', '0', '0', '5', '5', '5', '4', '3', '3', '9', '4', '0', '1', '2', '4']), .str (String.ofList ['1', '1', '2', '6', '6', '3', '2', '7', '4', '5', '3', '8', '8', '6', '3', '8', '6', '3', '0', '7', '4', '7']), .str (String.ofList ['3', '5', '2', '3', '6', '9', '5', '8', '6', '1', '4', '9', '3', '8', '2', '5', '5', '2', '8', '1', '7'])]), (String.ofList ['o', 'l', 'd', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6'], .str (String.ofList ['1', '4', '7', '6', '8', '1', '5', '2', '8', '6', '1', '1', '1', '6'])), (String.ofList ['n', 'e', 'w', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6'], .str (String.ofList ['1', '4', '8', '2', '2', '4', '2', '5', '2', '6', '3', '9', '8', '3']))]) :: (acc)

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_chunk_076_before_generic"
  err.flush

theorem array_moment_records_chunk_076 (fuel : Nat) (tail : List Char) (acc : List SourceJson) :
    SourceJson.array (fuel + 74)
      (SourceJson.white (momentRecordsChunk076Chars ++ tail)) acc =
      SourceJson.array (fuel + 73) (SourceJson.white tail) (momentRecordsChunk076Push acc) := by rfl

noncomputable def momentRecordsAcc077 : List SourceJson := momentRecordsChunk076Push momentRecordsAcc076

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_chunk_076_generic_complete"
  err.flush

noncomputable def momentRecordsChunk077Chars : List Char := ['\r', '\n', ' ', ' ', ' ', ' ', '{', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 's', 'i', 'm', 'p', 'l', 'e', 'x', '_', 'i', 'd', '"', ':', ' ', '7', '7', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'l', 'o', 'g', '_', 'g', 'a', 'p', '_', 'f', 'a', 'c', 't', 'o', 'r', '_', 'f', 'l', 'o', 'o', 'r', 's', '_', 'Q', '8', '0', '"', ':', ' ', '[', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '1', '6', '3', '0', '4', '9', '2', '1', '2', '7', '6', '0', '7', '1', '5', '5', '5', '0', '1', '2', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '3', '2', '1', '7', '1', '9', '1', '0', '6', '9', '3', '6', '2', '6', '8', '4', '8', '4', '7', '9', '1', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '3', '0', '4', '3', '2', '8', '7', '4', '9', '5', '5', '5', '4', '5', '4', '7', '6', '3', '3', '6', '5', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '1', '7', '4', '2', '1', '3', '3', '1', '6', '4', '7', '0', '6', '3', '7', '0', '8', '9', '6', '9', '1', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '1', '4', '6', '7', '7', '2', '3', '9', '8', '0', '6', '9', '1', '2', '3', '7', '1', '1', '1', '6', '1', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '1', '1', '6', '5', '4', '0', '6', '2', '5', '1', '0', '6', '9', '0', '2', '7', '7', '9', '0', '6', '3', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '4', '9', '0', '2', '2', '1', '6', '2', '2', '1', '6', '6', '5', '2', '1', '5', '5', '6', '9', '7', '4', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '5', '1', '9', '7', '4', '4', '0', '7', '3', '7', '4', '2', '9', '3', '8', '0', '0', '4', '1', '7', '8', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '6', '9', '2', '1', '8', '6', '2', '4', '9', '4', '7', '2', '8', '8', '6', '7', '0', '0', '3', '1', '5', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '3', '5', '9', '0', '2', '8', '3', '7', '9', '7', '0', '9', '6', '7', '0', '5', '1', '9', '9', '3', '"', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ']', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'o', 'l', 'd', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6', '"', ':', ' ', '"', '1', '7', '5', '2', '3', '5', '9', '1', '7', '8', '1', '0', '5', '6', '8', '7', '0', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'n', 'e', 'w', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6', '"', ':', ' ', '"', '1', '7', '5', '7', '0', '2', '9', '8', '4', '3', '1', '8', '8', '1', '6', '3', '6', '"', '\r', '\n', ' ', ' ', ' ', ' ', '}', ',']
noncomputable def momentRecordsChunk077Push (acc : List SourceJson) : List SourceJson :=
  (.obj [(String.ofList ['s', 'i', 'm', 'p', 'l', 'e', 'x', '_', 'i', 'd'], .number (String.ofList ['7', '7'])), (String.ofList ['l', 'o', 'g', '_', 'g', 'a', 'p', '_', 'f', 'a', 'c', 't', 'o', 'r', '_', 'f', 'l', 'o', 'o', 'r', 's', '_', 'Q', '8', '0'], .arr [.str (String.ofList ['2', '1', '6', '3', '0', '4', '9', '2', '1', '2', '7', '6', '0', '7', '1', '5', '5', '5', '0', '1', '2']), .str (String.ofList ['3', '2', '1', '7', '1', '9', '1', '0', '6', '9', '3', '6', '2', '6', '8', '4', '8', '4', '7', '9', '1']), .str (String.ofList ['3', '0', '4', '3', '2', '8', '7', '4', '9', '5', '5', '5', '4', '5', '4', '7', '6', '3', '3', '6', '5']), .str (String.ofList ['1', '7', '4', '2', '1', '3', '3', '1', '6', '4', '7', '0', '6', '3', '7', '0', '8', '9', '6', '9', '1']), .str (String.ofList ['1', '4', '6', '7', '7', '2', '3', '9', '8', '0', '6', '9', '1', '2', '3', '7', '1', '1', '1', '6', '1']), .str (String.ofList ['1', '1', '6', '5', '4', '0', '6', '2', '5', '1', '0', '6', '9', '0', '2', '7', '7', '9', '0', '6', '3']), .str (String.ofList ['4', '9', '0', '2', '2', '1', '6', '2', '2', '1', '6', '6', '5', '2', '1', '5', '5', '6', '9', '7', '4']), .str (String.ofList ['5', '1', '9', '7', '4', '4', '0', '7', '3', '7', '4', '2', '9', '3', '8', '0', '0', '4', '1', '7', '8']), .str (String.ofList ['6', '9', '2', '1', '8', '6', '2', '4', '9', '4', '7', '2', '8', '8', '6', '7', '0', '0', '3', '1', '5']), .str (String.ofList ['2', '3', '5', '9', '0', '2', '8', '3', '7', '9', '7', '0', '9', '6', '7', '0', '5', '1', '9', '9', '3'])]), (String.ofList ['o', 'l', 'd', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6'], .str (String.ofList ['1', '7', '5', '2', '3', '5', '9', '1', '7', '8', '1', '0', '5', '6', '8', '7', '0'])), (String.ofList ['n', 'e', 'w', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6'], .str (String.ofList ['1', '7', '5', '7', '0', '2', '9', '8', '4', '3', '1', '8', '8', '1', '6', '3', '6']))]) :: (acc)

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_chunk_077_before_generic"
  err.flush

theorem array_moment_records_chunk_077 (fuel : Nat) (tail : List Char) (acc : List SourceJson) :
    SourceJson.array (fuel + 73)
      (SourceJson.white (momentRecordsChunk077Chars ++ tail)) acc =
      SourceJson.array (fuel + 72) (SourceJson.white tail) (momentRecordsChunk077Push acc) := by rfl

noncomputable def momentRecordsAcc078 : List SourceJson := momentRecordsChunk077Push momentRecordsAcc077

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_chunk_077_generic_complete"
  err.flush

noncomputable def momentRecordsChunk078Chars : List Char := ['\r', '\n', ' ', ' ', ' ', ' ', '{', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 's', 'i', 'm', 'p', 'l', 'e', 'x', '_', 'i', 'd', '"', ':', ' ', '7', '8', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'l', 'o', 'g', '_', 'g', 'a', 'p', '_', 'f', 'a', 'c', 't', 'o', 'r', '_', 'f', 'l', 'o', 'o', 'r', 's', '_', 'Q', '8', '0', '"', ':', ' ', '[', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '5', '2', '9', '1', '6', '5', '3', '8', '9', '7', '8', '8', '0', '4', '7', '1', '6', '3', '7', '9', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '3', '2', '3', '0', '9', '4', '1', '2', '7', '4', '8', '5', '0', '8', '7', '3', '4', '9', '4', '0', '9', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '7', '7', '2', '2', '6', '2', '8', '9', '7', '9', '9', '4', '8', '0', '5', '9', '9', '8', '1', '6', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '5', '4', '1', '6', '6', '8', '7', '2', '7', '2', '2', '8', '1', '6', '0', '3', '7', '6', '3', '5', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '2', '0', '9', '1', '2', '8', '9', '6', '1', '3', '5', '8', '6', '5', '1', '6', '2', '1', '1', '3', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '3', '2', '0', '2', '1', '5', '7', '6', '8', '9', '7', '1', '5', '3', '7', '2', '8', '6', '7', '2', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '5', '8', '2', '6', '8', '2', '3', '9', '2', '1', '7', '7', '9', '6', '6', '2', '8', '4', '0', '6', '5', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '6', '8', '5', '8', '4', '6', '4', '9', '7', '1', '9', '9', '0', '4', '3', '9', '2', '4', '4', '2', '4', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '5', '9', '5', '6', '4', '7', '7', '4', '0', '1', '9', '5', '1', '1', '3', '4', '8', '1', '2', '2', '8', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '3', '7', '0', '5', '0', '1', '9', '3', '9', '0', '3', '3', '1', '5', '4', '7', '3', '3', '7', '6', '"', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ']', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'o', 'l', 'd', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6', '"', ':', ' ', '"', '9', '9', '0', '9', '9', '1', '8', '6', '4', '8', '4', '7', '2', '1', '6', '9', '8', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'n', 'e', 'w', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6', '"', ':', ' ', '"', '9', '9', '3', '9', '9', '7', '9', '0', '6', '9', '2', '2', '0', '3', '1', '8', '7', '"', '\r', '\n', ' ', ' ', ' ', ' ', '}', ',']
noncomputable def momentRecordsChunk078Push (acc : List SourceJson) : List SourceJson :=
  (.obj [(String.ofList ['s', 'i', 'm', 'p', 'l', 'e', 'x', '_', 'i', 'd'], .number (String.ofList ['7', '8'])), (String.ofList ['l', 'o', 'g', '_', 'g', 'a', 'p', '_', 'f', 'a', 'c', 't', 'o', 'r', '_', 'f', 'l', 'o', 'o', 'r', 's', '_', 'Q', '8', '0'], .arr [.str (String.ofList ['2', '5', '2', '9', '1', '6', '5', '3', '8', '9', '7', '8', '8', '0', '4', '7', '1', '6', '3', '7', '9']), .str (String.ofList ['3', '2', '3', '0', '9', '4', '1', '2', '7', '4', '8', '5', '0', '8', '7', '3', '4', '9', '4', '0', '9']), .str (String.ofList ['2', '7', '7', '2', '2', '6', '2', '8', '9', '7', '9', '9', '4', '8', '0', '5', '9', '9', '8', '1', '6']), .str (String.ofList ['2', '5', '4', '1', '6', '6', '8', '7', '2', '7', '2', '2', '8', '1', '6', '0', '3', '7', '6', '3', '5']), .str (String.ofList ['2', '2', '0', '9', '1', '2', '8', '9', '6', '1', '3', '5', '8', '6', '5', '1', '6', '2', '1', '1', '3']), .str (String.ofList ['2', '3', '2', '0', '2', '1', '5', '7', '6', '8', '9', '7', '1', '5', '3', '7', '2', '8', '6', '7', '2']), .str (String.ofList ['5', '8', '2', '6', '8', '2', '3', '9', '2', '1', '7', '7', '9', '6', '6', '2', '8', '4', '0', '6', '5']), .str (String.ofList ['6', '8', '5', '8', '4', '6', '4', '9', '7', '1', '9', '9', '0', '4', '3', '9', '2', '4', '4', '2', '4']), .str (String.ofList ['5', '9', '5', '6', '4', '7', '7', '4', '0', '1', '9', '5', '1', '1', '3', '4', '8', '1', '2', '2', '8']), .str (String.ofList ['2', '3', '7', '0', '5', '0', '1', '9', '3', '9', '0', '3', '3', '1', '5', '4', '7', '3', '3', '7', '6'])]), (String.ofList ['o', 'l', 'd', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6'], .str (String.ofList ['9', '9', '0', '9', '9', '1', '8', '6', '4', '8', '4', '7', '2', '1', '6', '9', '8'])), (String.ofList ['n', 'e', 'w', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6'], .str (String.ofList ['9', '9', '3', '9', '9', '7', '9', '0', '6', '9', '2', '2', '0', '3', '1', '8', '7']))]) :: (acc)

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_chunk_078_before_generic"
  err.flush

theorem array_moment_records_chunk_078 (fuel : Nat) (tail : List Char) (acc : List SourceJson) :
    SourceJson.array (fuel + 72)
      (SourceJson.white (momentRecordsChunk078Chars ++ tail)) acc =
      SourceJson.array (fuel + 71) (SourceJson.white tail) (momentRecordsChunk078Push acc) := by rfl

noncomputable def momentRecordsAcc079 : List SourceJson := momentRecordsChunk078Push momentRecordsAcc078

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_chunk_078_generic_complete"
  err.flush

noncomputable def momentRecordsChunk079Chars : List Char := ['\r', '\n', ' ', ' ', ' ', ' ', '{', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 's', 'i', 'm', 'p', 'l', 'e', 'x', '_', 'i', 'd', '"', ':', ' ', '7', '9', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'l', 'o', 'g', '_', 'g', 'a', 'p', '_', 'f', 'a', 'c', 't', 'o', 'r', '_', 'f', 'l', 'o', 'o', 'r', 's', '_', 'Q', '8', '0', '"', ':', ' ', '[', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '7', '3', '5', '4', '5', '1', '8', '3', '0', '2', '1', '6', '0', '5', '3', '7', '7', '9', '1', '1', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '3', '1', '7', '6', '2', '8', '2', '6', '9', '3', '4', '1', '3', '3', '2', '3', '6', '9', '8', '1', '9', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '6', '2', '9', '6', '6', '3', '7', '5', '7', '2', '6', '4', '3', '2', '8', '8', '1', '8', '3', '7', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '9', '9', '7', '9', '5', '7', '8', '5', '1', '8', '6', '9', '8', '3', '1', '0', '3', '8', '5', '0', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '6', '1', '9', '3', '6', '6', '4', '9', '7', '4', '9', '1', '3', '6', '0', '8', '0', '3', '2', '4', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '3', '6', '6', '5', '8', '5', '8', '1', '8', '5', '6', '9', '5', '1', '8', '0', '0', '1', '2', '5', '6', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '6', '8', '9', '7', '7', '9', '0', '3', '6', '6', '9', '8', '8', '1', '3', '1', '3', '8', '1', '8', '0', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '8', '8', '0', '1', '6', '4', '1', '9', '2', '0', '2', '5', '9', '6', '5', '3', '3', '6', '0', '2', '2', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '1', '0', '8', '9', '7', '3', '2', '8', '1', '6', '9', '2', '4', '5', '1', '2', '0', '2', '0', '0', '1', '6', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '7', '5', '8', '1', '1', '8', '6', '8', '2', '2', '9', '3', '7', '6', '0', '9', '2', '9', '6', '7', '"', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ']', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'o', 'l', 'd', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6', '"', ':', ' ', '"', '2', '1', '1', '0', '9', '5', '4', '9', '6', '2', '2', '3', '9', '9', '1', '2', '0', '2', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'n', 'e', 'w', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6', '"', ':', ' ', '"', '2', '1', '1', '9', '2', '0', '9', '2', '5', '7', '3', '4', '9', '2', '3', '1', '7', '7', '"', '\r', '\n', ' ', ' ', ' ', ' ', '}', ',']
noncomputable def momentRecordsChunk079Push (acc : List SourceJson) : List SourceJson :=
  (.obj [(String.ofList ['s', 'i', 'm', 'p', 'l', 'e', 'x', '_', 'i', 'd'], .number (String.ofList ['7', '9'])), (String.ofList ['l', 'o', 'g', '_', 'g', 'a', 'p', '_', 'f', 'a', 'c', 't', 'o', 'r', '_', 'f', 'l', 'o', 'o', 'r', 's', '_', 'Q', '8', '0'], .arr [.str (String.ofList ['2', '7', '3', '5', '4', '5', '1', '8', '3', '0', '2', '1', '6', '0', '5', '3', '7', '7', '9', '1', '1']), .str (String.ofList ['3', '1', '7', '6', '2', '8', '2', '6', '9', '3', '4', '1', '3', '3', '2', '3', '6', '9', '8', '1', '9']), .str (String.ofList ['2', '6', '2', '9', '6', '6', '3', '7', '5', '7', '2', '6', '4', '3', '2', '8', '8', '1', '8', '3', '7']), .str (String.ofList ['2', '9', '9', '7', '9', '5', '7', '8', '5', '1', '8', '6', '9', '8', '3', '1', '0', '3', '8', '5', '0']), .str (String.ofList ['2', '6', '1', '9', '3', '6', '6', '4', '9', '7', '4', '9', '1', '3', '6', '0', '8', '0', '3', '2', '4']), .str (String.ofList ['3', '6', '6', '5', '8', '5', '8', '1', '8', '5', '6', '9', '5', '1', '8', '0', '0', '1', '2', '5', '6']), .str (String.ofList ['6', '8', '9', '7', '7', '9', '0', '3', '6', '6', '9', '8', '8', '1', '3', '1', '3', '8', '1', '8', '0']), .str (String.ofList ['8', '8', '0', '1', '6', '4', '1', '9', '2', '0', '2', '5', '9', '6', '5', '3', '3', '6', '0', '2', '2']), .str (String.ofList ['1', '0', '8', '9', '7', '3', '2', '8', '1', '6', '9', '2', '4', '5', '1', '2', '0', '2', '0', '0', '1', '6']), .str (String.ofList ['2', '7', '5', '8', '1', '1', '8', '6', '8', '2', '2', '9', '3', '7', '6', '0', '9', '2', '9', '6', '7'])]), (String.ofList ['o', 'l', 'd', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6'], .str (String.ofList ['2', '1', '1', '0', '9', '5', '4', '9', '6', '2', '2', '3', '9', '9', '1', '2', '0', '2'])), (String.ofList ['n', 'e', 'w', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6'], .str (String.ofList ['2', '1', '1', '9', '2', '0', '9', '2', '5', '7', '3', '4', '9', '2', '3', '1', '7', '7']))]) :: (acc)

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_chunk_079_before_generic"
  err.flush

theorem array_moment_records_chunk_079 (fuel : Nat) (tail : List Char) (acc : List SourceJson) :
    SourceJson.array (fuel + 71)
      (SourceJson.white (momentRecordsChunk079Chars ++ tail)) acc =
      SourceJson.array (fuel + 70) (SourceJson.white tail) (momentRecordsChunk079Push acc) := by rfl

noncomputable def momentRecordsAcc080 : List SourceJson := momentRecordsChunk079Push momentRecordsAcc079

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_chunk_079_generic_complete"
  err.flush

noncomputable def momentRecordsBlock019Chars : List Char := momentRecordsChunk076Chars ++ momentRecordsChunk077Chars ++ momentRecordsChunk078Chars ++ momentRecordsChunk079Chars
noncomputable def momentRecordsBlock019Push (acc : List SourceJson) : List SourceJson := momentRecordsChunk079Push (momentRecordsChunk078Push (momentRecordsChunk077Push (momentRecordsChunk076Push (acc))))

theorem array_moment_records_block_019 (fuel : Nat) (tail : List Char) (acc : List SourceJson) :
    SourceJson.array (fuel + 74)
      (SourceJson.white (momentRecordsBlock019Chars ++ tail)) acc =
      SourceJson.array (fuel + 70) (SourceJson.white tail) (momentRecordsBlock019Push acc) := by
  have hinput : momentRecordsBlock019Chars ++ tail = momentRecordsChunk076Chars ++ (momentRecordsChunk077Chars ++ (momentRecordsChunk078Chars ++ (momentRecordsChunk079Chars ++ (tail)))) := by
    simp only [momentRecordsBlock019Chars, List.append_assoc]
  calc
    SourceJson.array (fuel + 74) (SourceJson.white (momentRecordsBlock019Chars ++ tail)) acc =
        SourceJson.array (fuel + 74) (SourceJson.white (momentRecordsChunk076Chars ++ (momentRecordsChunk077Chars ++ (momentRecordsChunk078Chars ++ (momentRecordsChunk079Chars ++ (tail)))))) acc :=
      congrArg (fun s => SourceJson.array (fuel + 74) (SourceJson.white s) acc) hinput
    _ = SourceJson.array (fuel + 73) (SourceJson.white (momentRecordsChunk077Chars ++ (momentRecordsChunk078Chars ++ (momentRecordsChunk079Chars ++ (tail))))) (momentRecordsChunk076Push (acc)) := array_moment_records_chunk_076 fuel (momentRecordsChunk077Chars ++ (momentRecordsChunk078Chars ++ (momentRecordsChunk079Chars ++ (tail)))) (acc)
    _ = SourceJson.array (fuel + 72) (SourceJson.white (momentRecordsChunk078Chars ++ (momentRecordsChunk079Chars ++ (tail)))) (momentRecordsChunk077Push (momentRecordsChunk076Push (acc))) := array_moment_records_chunk_077 fuel (momentRecordsChunk078Chars ++ (momentRecordsChunk079Chars ++ (tail))) (momentRecordsChunk076Push (acc))
    _ = SourceJson.array (fuel + 71) (SourceJson.white (momentRecordsChunk079Chars ++ (tail))) (momentRecordsChunk078Push (momentRecordsChunk077Push (momentRecordsChunk076Push (acc)))) := array_moment_records_chunk_078 fuel (momentRecordsChunk079Chars ++ (tail)) (momentRecordsChunk077Push (momentRecordsChunk076Push (acc)))
    _ = SourceJson.array (fuel + 70) (SourceJson.white tail) (momentRecordsBlock019Push acc) := array_moment_records_chunk_079 fuel (tail) (momentRecordsChunk078Push (momentRecordsChunk077Push (momentRecordsChunk076Push (acc))))

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_block_019_before_raw_binding"
  err.flush

theorem moment_records_block_019_prefix :
    (momentRest06 39308).take 2062 = momentRecordsBlock019Chars := by rfl

theorem moment_records_block_019_split :
    momentRest06 39308 = momentRecordsBlock019Chars ++ momentRest06 41370 := by
  calc
    momentRest06 39308 =
        (momentRest06 39308).take 2062 ++ (momentRest06 39308).drop 2062 :=
      (List.take_append_drop 2062 (momentRest06 39308)).symm
    _ = momentRecordsBlock019Chars ++ (momentRest06 39308).drop 2062 :=
      congrArg (fun p => p ++ (momentRest06 39308).drop 2062) moment_records_block_019_prefix
    _ = momentRecordsBlock019Chars ++ momentRest06 41370 :=
      congrArg (fun rest => momentRecordsBlock019Chars ++ rest) (momentRest06_drop 39308 2062)

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_block_019_after_raw_binding"
  err.flush

theorem array_moment_records_original_block_019 (fuel : Nat) (acc : List SourceJson) :
    SourceJson.array (fuel + 74)
      (SourceJson.white (momentRest06 39308)) acc =
      SourceJson.array (fuel + 70) (SourceJson.white (momentRest06 41370)) (momentRecordsBlock019Push acc) := by
  exact (congrArg (fun s => SourceJson.array (fuel + 74) (SourceJson.white s) acc)
      moment_records_block_019_split).trans (array_moment_records_block_019 fuel (momentRest06 41370) acc)

theorem moment_records_through_block_019 (fuel : Nat) :
    SourceJson.array (fuel + 150)
      (SourceJson.white (momentRest06 364)) [] =
      SourceJson.array (fuel + 70) (SourceJson.white (momentRest06 41370)) momentRecordsAcc080 := by
  exact (moment_records_through_block_018 fuel).trans (array_moment_records_original_block_019 fuel momentRecordsAcc076)

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_block_019_complete"
  err.flush

#print axioms array_moment_records_chunk_076
#print axioms array_moment_records_chunk_077
#print axioms array_moment_records_chunk_078
#print axioms array_moment_records_chunk_079
#print axioms array_moment_records_block_019
#print axioms moment_records_block_019_prefix
#print axioms moment_records_block_019_split
#print axioms array_moment_records_original_block_019
#print axioms moment_records_through_block_019

end ImbalancedChen.P2OriginalSaving19Moment06Parsing
