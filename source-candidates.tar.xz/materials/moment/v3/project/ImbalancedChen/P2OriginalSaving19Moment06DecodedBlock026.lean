/- SOURCE_CANDIDATE: original Cell06 source only. No Lean compilation,
independent kernel replay, full-owned audit or formal acceptance is claimed. -/

import ImbalancedChen.P2OriginalSaving19Moment06DecodedBlock025
import ImbalancedChen.P2OriginalSaving19Moment06RecordsBlock026

/-! Original typed moment records 104 through 107; each concrete value is checked by original decodeMomentRecord.
Candidate quotations preserve exact original raw bytes. The Lean equations bind
them to the production-compatible packed input and run the unchanged reader.
This local input resolves inside this private project, not the P1 filesystem. -/
namespace ImbalancedChen.P2OriginalSaving19Moment06Decoding
set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false
open ImbalancedChen.P2OriginalSaving19Archive

open ImbalancedChen.P2OriginalSaving19Moment06Parsing

noncomputable def momentJsonRecord104 : SourceJson :=
  (momentRecordsChunk104Push []).head (List.cons_ne_nil _ _)

theorem moment_record_104_push_eq (acc : List SourceJson) :
    momentRecordsChunk104Push acc = momentJsonRecord104 :: acc := by rfl

noncomputable def momentTypedRecord104 : MomentRecord :=
  { simplexId := 104,
    factorFloorsQ80 := #[(164670298642805981135 : Int), (246885718751633658137 : Int), (263276733489205321772 : Int), (233954591529960538328 : Int), (168830508969113043720 : Int), (317390187291324144489 : Int), (679880117141910332012 : Int), (749505423129377399787 : Int), (949391957768650582290 : Int), (257507524485292506757 : Int)],
    oldFloorQ96 := (170540309596309879 : Int),
    newFloorQ96 := (171109943810089302 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_104_before_decode"
  err.flush

theorem decode_moment_record_104 :
    decodeMomentRecord momentJsonRecord104 = .ok momentTypedRecord104 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_104_decoded"
  err.flush

noncomputable def momentJsonRecord105 : SourceJson :=
  (momentRecordsChunk105Push []).head (List.cons_ne_nil _ _)

theorem moment_record_105_push_eq (acc : List SourceJson) :
    momentRecordsChunk105Push acc = momentJsonRecord105 :: acc := by rfl

noncomputable def momentTypedRecord105 : MomentRecord :=
  { simplexId := 105,
    factorFloorsQ80 := #[(169942538090960130250 : Int), (299597326574921183332 : Int), (243790384618467962347 : Int), (147860276926101268937 : Int), (105981870386619066492 : Int), (298548268650694451774 : Int), (667341720841241968540 : Int), (717083541126412716991 : Int), (910373202758553862773 : Int), (374863566880653548143 : Int)],
    oldFloorQ96 := (162672699424695317 : Int),
    newFloorQ96 := (163203106192264819 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_105_before_decode"
  err.flush

theorem decode_moment_record_105 :
    decodeMomentRecord momentJsonRecord105 = .ok momentTypedRecord105 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_105_decoded"
  err.flush

noncomputable def momentJsonRecord106 : SourceJson :=
  (momentRecordsChunk106Push []).head (List.cons_ne_nil _ _)

theorem moment_record_106_push_eq (acc : List SourceJson) :
    momentRecordsChunk106Push acc = momentJsonRecord106 :: acc := by rfl

noncomputable def momentTypedRecord106 : MomentRecord :=
  { simplexId := 106,
    factorFloorsQ80 := #[(197405353293187419565 : Int), (393744437649968657910 : Int), (230932295453454774585 : Int), (72678264539960413886 : Int), (58516863308009872450 : Int), (93941329495677238227 : Int), (512753172857356219665 : Int), (402155145187554377614 : Int), (273931776341000333119 : Int), (273914910416221697875 : Int)],
    oldFloorQ96 := (1627951645430 : Int),
    newFloorQ96 := (1631335112172 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_106_before_decode"
  err.flush

theorem decode_moment_record_106 :
    decodeMomentRecord momentJsonRecord106 = .ok momentTypedRecord106 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_106_decoded"
  err.flush

noncomputable def momentJsonRecord107 : SourceJson :=
  (momentRecordsChunk107Push []).head (List.cons_ne_nil _ _)

theorem moment_record_107_push_eq (acc : List SourceJson) :
    momentRecordsChunk107Push acc = momentJsonRecord107 :: acc := by rfl

noncomputable def momentTypedRecord107 : MomentRecord :=
  { simplexId := 107,
    factorFloorsQ80 := #[(311084763035970297342 : Int), (441865574098509167818 : Int), (213901194761921948461 : Int), (179429300761500232270 : Int), (158886755629464058741 : Int), (147993053197314654756 : Int), (552813050414288189826 : Int), (487248303635825449527 : Int), (299208149928651310352 : Int), (299192433681030675994 : Int)],
    oldFloorQ96 := (6583544484568 : Int),
    newFloorQ96 := (6600402328426 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_107_before_decode"
  err.flush

theorem decode_moment_record_107 :
    decodeMomentRecord momentJsonRecord107 = .ok momentTypedRecord107 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_107_decoded"
  err.flush

noncomputable def momentJsonRecordsBlock026 : List SourceJson := [momentJsonRecord104, momentJsonRecord105, momentJsonRecord106, momentJsonRecord107]
noncomputable def momentTypedRecordsBlock026 : List MomentRecord := [momentTypedRecord104, momentTypedRecord105, momentTypedRecord106, momentTypedRecord107]

theorem moment_records_block_026_push_eq (acc : List SourceJson) :
    momentRecordsBlock026Push acc = [momentJsonRecord107, momentJsonRecord106, momentJsonRecord105, momentJsonRecord104] ++ acc := by rfl

theorem moment_records_block_026_reverse (acc : List SourceJson) :
    (momentRecordsBlock026Push acc).reverse = acc.reverse ++ momentJsonRecordsBlock026 := by
  rw [moment_records_block_026_push_eq, List.reverse_append]
  rfl

theorem decode_moment_records_block_026 :
    momentJsonRecordsBlock026.mapM decodeMomentRecord = .ok momentTypedRecordsBlock026 := by
  simp only [momentJsonRecordsBlock026, momentTypedRecordsBlock026, List.mapM_cons, List.mapM_nil,
    decode_moment_record_104, decode_moment_record_105, decode_moment_record_106, decode_moment_record_107]
  rfl

noncomputable def momentTypedRowsThroughBlock026 : List MomentRecord := momentTypedRowsThroughBlock025 ++ momentTypedRecordsBlock026

theorem decode_moment_records_through_block_026 :
    momentRecordsAcc108.reverse.mapM decodeMomentRecord = .ok momentTypedRowsThroughBlock026 := by
  change (momentRecordsBlock026Push momentRecordsAcc104).reverse.mapM decodeMomentRecord = _
  rw [moment_records_block_026_reverse]
  rw [List.mapM_append, decode_moment_records_through_block_025, decode_moment_records_block_026]
  rfl

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_block_026_complete"
  err.flush

#print axioms moment_record_104_push_eq
#print axioms decode_moment_record_104
#print axioms moment_record_105_push_eq
#print axioms decode_moment_record_105
#print axioms moment_record_106_push_eq
#print axioms decode_moment_record_106
#print axioms moment_record_107_push_eq
#print axioms decode_moment_record_107
#print axioms moment_records_block_026_push_eq
#print axioms moment_records_block_026_reverse
#print axioms decode_moment_records_block_026
#print axioms decode_moment_records_through_block_026

end ImbalancedChen.P2OriginalSaving19Moment06Decoding
