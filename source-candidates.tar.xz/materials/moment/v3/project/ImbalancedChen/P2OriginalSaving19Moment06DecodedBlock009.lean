/- SOURCE_CANDIDATE: original Cell06 source only. No Lean compilation,
independent kernel replay, full-owned audit or formal acceptance is claimed. -/

import ImbalancedChen.P2OriginalSaving19Moment06DecodedBlock008
import ImbalancedChen.P2OriginalSaving19Moment06RecordsBlock009

/-! Original typed moment records 36 through 39; each concrete value is checked by original decodeMomentRecord.
Candidate quotations preserve exact original raw bytes. The Lean equations bind
them to the production-compatible packed input and run the unchanged reader.
This local input resolves inside this private project, not the P1 filesystem. -/
namespace ImbalancedChen.P2OriginalSaving19Moment06Decoding
set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false
open ImbalancedChen.P2OriginalSaving19Archive

open ImbalancedChen.P2OriginalSaving19Moment06Parsing

noncomputable def momentJsonRecord036 : SourceJson :=
  (momentRecordsChunk036Push []).head (List.cons_ne_nil _ _)

theorem moment_record_036_push_eq (acc : List SourceJson) :
    momentRecordsChunk036Push acc = momentJsonRecord036 :: acc := by rfl

noncomputable def momentTypedRecord036 : MomentRecord :=
  { simplexId := 36,
    factorFloorsQ80 := #[(275847112646338919765 : Int), (306000525480214389445 : Int), (321205810917417975665 : Int), (178768498376805578259 : Int), (139991884878520271073 : Int), (175680963799614146209 : Int), (245664044879421849252 : Int), (216564616684038176103 : Int), (395625766457366632849 : Int), (147746197182479001942 : Int)],
    oldFloorQ96 := (393934161043814 : Int),
    newFloorQ96 := (394717999779516 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_036_before_decode"
  err.flush

theorem decode_moment_record_036 :
    decodeMomentRecord momentJsonRecord036 = .ok momentTypedRecord036 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_036_decoded"
  err.flush

noncomputable def momentJsonRecord037 : SourceJson :=
  (momentRecordsChunk037Push []).head (List.cons_ne_nil _ _)

theorem moment_record_037_push_eq (acc : List SourceJson) :
    momentRecordsChunk037Push acc = momentJsonRecord037 :: acc := by rfl

noncomputable def momentTypedRecord037 : MomentRecord :=
  { simplexId := 37,
    factorFloorsQ80 := #[(423694067564622238207 : Int), (376426184029996543653 : Int), (300550470286381178080 : Int), (266354188279309074420 : Int), (220126117957664300423 : Int), (241619591934218258501 : Int), (239631730955753944556 : Int), (205384425731230544939 : Int), (397496953217244898406 : Int), (197673380049516944287 : Int)],
    oldFloorQ96 := (107672840324 : Int),
    newFloorQ96 := (107928667099 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_037_before_decode"
  err.flush

theorem decode_moment_record_037 :
    decodeMomentRecord momentJsonRecord037 = .ok momentTypedRecord037 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_037_decoded"
  err.flush

noncomputable def momentJsonRecord038 : SourceJson :=
  (momentRecordsChunk038Push []).head (List.cons_ne_nil _ _)

theorem moment_record_038_push_eq (acc : List SourceJson) :
    momentRecordsChunk038Push acc = momentJsonRecord038 :: acc := by rfl

noncomputable def momentTypedRecord038 : MomentRecord :=
  { simplexId := 38,
    factorFloorsQ80 := #[(430745440881402395262 : Int), (374836562664939600965 : Int), (278262455903275013956 : Int), (312039148442133941454 : Int), (259640400205835132540 : Int), (251232877022708733582 : Int), (278667453490479997080 : Int), (247824033916030570639 : Int), (449833938419411841462 : Int), (198565772159508273588 : Int)],
    oldFloorQ96 := (717045128863 : Int),
    newFloorQ96 := (718875265527 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_038_before_decode"
  err.flush

theorem decode_moment_record_038 :
    decodeMomentRecord momentJsonRecord038 = .ok momentTypedRecord038 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_038_decoded"
  err.flush

noncomputable def momentJsonRecord039 : SourceJson :=
  (momentRecordsChunk039Push []).head (List.cons_ne_nil _ _)

theorem moment_record_039_push_eq (acc : List SourceJson) :
    momentRecordsChunk039Push acc = momentJsonRecord039 :: acc := by rfl

noncomputable def momentTypedRecord039 : MomentRecord :=
  { simplexId := 39,
    factorFloorsQ80 := #[(430749862344941042986 : Int), (374805059684132704093 : Int), (257863417090032883683 : Int), (359273664577283382230 : Int), (299869307415092510942 : Int), (319207168863622531069 : Int), (1156300155988244239084 : Int), (288819575043282139099 : Int), (470193287513933389163 : Int), (199012203219352291251 : Int)],
    oldFloorQ96 := (5654105526620 : Int),
    newFloorQ96 := (5673576888025 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_039_before_decode"
  err.flush

theorem decode_moment_record_039 :
    decodeMomentRecord momentJsonRecord039 = .ok momentTypedRecord039 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_039_decoded"
  err.flush

noncomputable def momentJsonRecordsBlock009 : List SourceJson := [momentJsonRecord036, momentJsonRecord037, momentJsonRecord038, momentJsonRecord039]
noncomputable def momentTypedRecordsBlock009 : List MomentRecord := [momentTypedRecord036, momentTypedRecord037, momentTypedRecord038, momentTypedRecord039]

theorem moment_records_block_009_push_eq (acc : List SourceJson) :
    momentRecordsBlock009Push acc = [momentJsonRecord039, momentJsonRecord038, momentJsonRecord037, momentJsonRecord036] ++ acc := by rfl

theorem moment_records_block_009_reverse (acc : List SourceJson) :
    (momentRecordsBlock009Push acc).reverse = acc.reverse ++ momentJsonRecordsBlock009 := by
  rw [moment_records_block_009_push_eq, List.reverse_append]
  rfl

theorem decode_moment_records_block_009 :
    momentJsonRecordsBlock009.mapM decodeMomentRecord = .ok momentTypedRecordsBlock009 := by
  simp only [momentJsonRecordsBlock009, momentTypedRecordsBlock009, List.mapM_cons, List.mapM_nil,
    decode_moment_record_036, decode_moment_record_037, decode_moment_record_038, decode_moment_record_039]
  rfl

noncomputable def momentTypedRowsThroughBlock009 : List MomentRecord := momentTypedRowsThroughBlock008 ++ momentTypedRecordsBlock009

theorem decode_moment_records_through_block_009 :
    momentRecordsAcc040.reverse.mapM decodeMomentRecord = .ok momentTypedRowsThroughBlock009 := by
  change (momentRecordsBlock009Push momentRecordsAcc036).reverse.mapM decodeMomentRecord = _
  rw [moment_records_block_009_reverse]
  rw [List.mapM_append, decode_moment_records_through_block_008, decode_moment_records_block_009]
  rfl

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_block_009_complete"
  err.flush

#print axioms moment_record_036_push_eq
#print axioms decode_moment_record_036
#print axioms moment_record_037_push_eq
#print axioms decode_moment_record_037
#print axioms moment_record_038_push_eq
#print axioms decode_moment_record_038
#print axioms moment_record_039_push_eq
#print axioms decode_moment_record_039
#print axioms moment_records_block_009_push_eq
#print axioms moment_records_block_009_reverse
#print axioms decode_moment_records_block_009
#print axioms decode_moment_records_through_block_009

end ImbalancedChen.P2OriginalSaving19Moment06Decoding
