/- SOURCE_CANDIDATE: original Cell06 source only. No Lean compilation,
independent kernel replay, full-owned audit or formal acceptance is claimed. -/

import ImbalancedChen.P2OriginalSaving19Moment06DecodedBlock016
import ImbalancedChen.P2OriginalSaving19Moment06RecordsBlock017

/-! Original typed moment records 68 through 71; each concrete value is checked by original decodeMomentRecord.
Candidate quotations preserve exact original raw bytes. The Lean equations bind
them to the production-compatible packed input and run the unchanged reader.
This local input resolves inside this private project, not the P1 filesystem. -/
namespace ImbalancedChen.P2OriginalSaving19Moment06Decoding
set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false
open ImbalancedChen.P2OriginalSaving19Archive

open ImbalancedChen.P2OriginalSaving19Moment06Parsing

noncomputable def momentJsonRecord068 : SourceJson :=
  (momentRecordsChunk068Push []).head (List.cons_ne_nil _ _)

theorem moment_record_068_push_eq (acc : List SourceJson) :
    momentRecordsChunk068Push acc = momentJsonRecord068 :: acc := by rfl

noncomputable def momentTypedRecord068 : MomentRecord :=
  { simplexId := 68,
    factorFloorsQ80 := #[(229924708455225022142 : Int), (277481764269001836382 : Int), (298195084063398256229 : Int), (229988328409122213922 : Int), (191987232066252580532 : Int), (141373523653977621349 : Int), (506039102351632770936 : Int), (562531913845639773632 : Int), (678204896838734458857 : Int), (168709784223438350028 : Int)],
    oldFloorQ96 := (4499359437531010 : Int),
    newFloorQ96 := (4511600016714715 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_068_before_decode"
  err.flush

theorem decode_moment_record_068 :
    decodeMomentRecord momentJsonRecord068 = .ok momentTypedRecord068 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_068_decoded"
  err.flush

noncomputable def momentJsonRecord069 : SourceJson :=
  (momentRecordsChunk069Push []).head (List.cons_ne_nil _ _)

theorem moment_record_069_push_eq (acc : List SourceJson) :
    momentRecordsChunk069Push acc = momentJsonRecord069 :: acc := by rfl

noncomputable def momentTypedRecord069 : MomentRecord :=
  { simplexId := 69,
    factorFloorsQ80 := #[(256242787113968182827 : Int), (276650900948753794862 : Int), (274665300870688055138 : Int), (296091858795939473428 : Int), (251786732914212097746 : Int), (241930698799281043607 : Int), (1184279194001560127423 : Int), (595485913216617137951 : Int), (659106036039965870913 : Int), (168442158739429993933 : Int)],
    oldFloorQ96 := (35517334354763255 : Int),
    newFloorQ96 := (35641079818070589 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_069_before_decode"
  err.flush

theorem decode_moment_record_069 :
    decodeMomentRecord momentJsonRecord069 = .ok momentTypedRecord069 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_069_decoded"
  err.flush

noncomputable def momentJsonRecord070 : SourceJson :=
  (momentRecordsChunk070Push []).head (List.cons_ne_nil _ _)

theorem moment_record_070_push_eq (acc : List SourceJson) :
    momentRecordsChunk070Push acc = momentJsonRecord070 :: acc := by rfl

noncomputable def momentTypedRecord070 : MomentRecord :=
  { simplexId := 70,
    factorFloorsQ80 := #[(292158997281716461706 : Int), (312817170114308981386 : Int), (259618161268682743277 : Int), (330765286842897318449 : Int), (281312792143835343469 : Int), (360326243340862195863 : Int), (1229374848118689484297 : Int), (850215714055185092022 : Int), (998592676555355212803 : Int), (238929910872517697875 : Int)],
    oldFloorQ96 := (174144030080625129 : Int),
    newFloorQ96 := (174888057398520698 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_070_before_decode"
  err.flush

theorem decode_moment_record_070 :
    decodeMomentRecord momentJsonRecord070 = .ok momentTypedRecord070 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_070_decoded"
  err.flush

noncomputable def momentJsonRecord071 : SourceJson :=
  (momentRecordsChunk071Push []).head (List.cons_ne_nil _ _)

theorem moment_record_071_push_eq (acc : List SourceJson) :
    momentRecordsChunk071Push acc = momentJsonRecord071 :: acc := by rfl

noncomputable def momentTypedRecord071 : MomentRecord :=
  { simplexId := 71,
    factorFloorsQ80 := #[(141269033573344652505 : Int), (256374251443415906031 : Int), (308681958638866031622 : Int), (159656749677654487767 : Int), (132887477154763352746 : Int), (114226682624007739480 : Int), (653059320443021878275 : Int), (716033507621125840339 : Int), (867150517728934553756 : Int), (191406515504627001334 : Int)],
    oldFloorQ96 := (583702848350 : Int),
    newFloorQ96 := (585414924502 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_071_before_decode"
  err.flush

theorem decode_moment_record_071 :
    decodeMomentRecord momentJsonRecord071 = .ok momentTypedRecord071 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_071_decoded"
  err.flush

noncomputable def momentJsonRecordsBlock017 : List SourceJson := [momentJsonRecord068, momentJsonRecord069, momentJsonRecord070, momentJsonRecord071]
noncomputable def momentTypedRecordsBlock017 : List MomentRecord := [momentTypedRecord068, momentTypedRecord069, momentTypedRecord070, momentTypedRecord071]

theorem moment_records_block_017_push_eq (acc : List SourceJson) :
    momentRecordsBlock017Push acc = [momentJsonRecord071, momentJsonRecord070, momentJsonRecord069, momentJsonRecord068] ++ acc := by rfl

theorem moment_records_block_017_reverse (acc : List SourceJson) :
    (momentRecordsBlock017Push acc).reverse = acc.reverse ++ momentJsonRecordsBlock017 := by
  rw [moment_records_block_017_push_eq, List.reverse_append]
  rfl

theorem decode_moment_records_block_017 :
    momentJsonRecordsBlock017.mapM decodeMomentRecord = .ok momentTypedRecordsBlock017 := by
  simp only [momentJsonRecordsBlock017, momentTypedRecordsBlock017, List.mapM_cons, List.mapM_nil,
    decode_moment_record_068, decode_moment_record_069, decode_moment_record_070, decode_moment_record_071]
  rfl

noncomputable def momentTypedRowsThroughBlock017 : List MomentRecord := momentTypedRowsThroughBlock016 ++ momentTypedRecordsBlock017

theorem decode_moment_records_through_block_017 :
    momentRecordsAcc072.reverse.mapM decodeMomentRecord = .ok momentTypedRowsThroughBlock017 := by
  change (momentRecordsBlock017Push momentRecordsAcc068).reverse.mapM decodeMomentRecord = _
  rw [moment_records_block_017_reverse]
  rw [List.mapM_append, decode_moment_records_through_block_016, decode_moment_records_block_017]
  rfl

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_block_017_complete"
  err.flush

#print axioms moment_record_068_push_eq
#print axioms decode_moment_record_068
#print axioms moment_record_069_push_eq
#print axioms decode_moment_record_069
#print axioms moment_record_070_push_eq
#print axioms decode_moment_record_070
#print axioms moment_record_071_push_eq
#print axioms decode_moment_record_071
#print axioms moment_records_block_017_push_eq
#print axioms moment_records_block_017_reverse
#print axioms decode_moment_records_block_017
#print axioms decode_moment_records_through_block_017

end ImbalancedChen.P2OriginalSaving19Moment06Decoding
