/- SOURCE_CANDIDATE: original Cell06 source only. No Lean compilation,
independent kernel replay, full-owned audit or formal acceptance is claimed. -/

import ImbalancedChen.P2OriginalSaving19Moment06DecodedBlock026
import ImbalancedChen.P2OriginalSaving19Moment06RecordsBlock027

/-! Original typed moment records 108 through 111; each concrete value is checked by original decodeMomentRecord.
Candidate quotations preserve exact original raw bytes. The Lean equations bind
them to the production-compatible packed input and run the unchanged reader.
This local input resolves inside this private project, not the P1 filesystem. -/
namespace ImbalancedChen.P2OriginalSaving19Moment06Decoding
set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false
open ImbalancedChen.P2OriginalSaving19Archive

open ImbalancedChen.P2OriginalSaving19Moment06Parsing

noncomputable def momentJsonRecord108 : SourceJson :=
  (momentRecordsChunk108Push []).head (List.cons_ne_nil _ _)

theorem moment_record_108_push_eq (acc : List SourceJson) :
    momentRecordsChunk108Push acc = momentJsonRecord108 :: acc := by rfl

noncomputable def momentTypedRecord108 : MomentRecord :=
  { simplexId := 108,
    factorFloorsQ80 := #[(348607735503524181919 : Int), (464888266341444661329 : Int), (242034940488488685403 : Int), (271492483145490208206 : Int), (241638053735346435283 : Int), (277773268774781357627 : Int), (645152721250345026501 : Int), (698683100062405089631 : Int), (285391685858079862873 : Int), (285377862555833828482 : Int)],
    oldFloorQ96 := (8669748468316 : Int),
    newFloorQ96 := (8696762570794 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_108_before_decode"
  err.flush

theorem decode_moment_record_108 :
    decodeMomentRecord momentJsonRecord108 = .ok momentTypedRecord108 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_108_decoded"
  err.flush

noncomputable def momentJsonRecord109 : SourceJson :=
  (momentRecordsChunk109Push []).head (List.cons_ne_nil _ _)

theorem moment_record_109_push_eq (acc : List SourceJson) :
    momentRecordsChunk109Push acc = momentJsonRecord109 :: acc := by rfl

noncomputable def momentTypedRecord109 : MomentRecord :=
  { simplexId := 109,
    factorFloorsQ80 := #[(354297593482085118550 : Int), (447459893252068503305 : Int), (260640474530858889840 : Int), (332950001155190932303 : Int), (291609292954923944567 : Int), (380494251492794508194 : Int), (1344300642147241657248 : Int), (746250782722606560788 : Int), (210102088919074619102 : Int), (210091278289674977370 : Int)],
    oldFloorQ96 := (10246990474980 : Int),
    newFloorQ96 := (10285869349421 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_109_before_decode"
  err.flush

theorem decode_moment_record_109 :
    decodeMomentRecord momentJsonRecord109 = .ok momentTypedRecord109 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_109_decoded"
  err.flush

noncomputable def momentJsonRecord110 : SourceJson :=
  (momentRecordsChunk110Push []).head (List.cons_ne_nil _ _)

theorem moment_record_110_push_eq (acc : List SourceJson) :
    momentRecordsChunk110Push acc = momentJsonRecord110 :: acc := by rfl

noncomputable def momentTypedRecord110 : MomentRecord :=
  { simplexId := 110,
    factorFloorsQ80 := #[(456224357151152121721 : Int), (507689204050033706250 : Int), (262247143912995495017 : Int), (385856277764689109108 : Int), (330822233386825931901 : Int), (425358003733979735185 : Int), (1277373590864776149414 : Int), (495045338499321891031 : Int), (164626380024580199359 : Int), (164621055884860261750 : Int)],
    oldFloorQ96 := (13331673461998 : Int),
    newFloorQ96 := (13381057023440 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_110_before_decode"
  err.flush

theorem decode_moment_record_110 :
    decodeMomentRecord momentJsonRecord110 = .ok momentTypedRecord110 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_110_decoded"
  err.flush

noncomputable def momentJsonRecord111 : SourceJson :=
  (momentRecordsChunk111Push []).head (List.cons_ne_nil _ _)

theorem moment_record_111_push_eq (acc : List SourceJson) :
    momentRecordsChunk111Push acc = momentJsonRecord111 :: acc := by rfl

noncomputable def momentTypedRecord111 : MomentRecord :=
  { simplexId := 111,
    factorFloorsQ80 := #[(476061106403856751122 : Int), (513330568108426747984 : Int), (238228195147441130468 : Int), (359777091687275425754 : Int), (359146751610386497073 : Int), (402429647934955507015 : Int), (1018567599645454818307 : Int), (405076063898556790243 : Int), (134510372975896177854 : Int), (134506920915886343953 : Int)],
    oldFloorQ96 := (15028869869176 : Int),
    newFloorQ96 := (15079197889478 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_111_before_decode"
  err.flush

theorem decode_moment_record_111 :
    decodeMomentRecord momentJsonRecord111 = .ok momentTypedRecord111 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_111_decoded"
  err.flush

noncomputable def momentJsonRecordsBlock027 : List SourceJson := [momentJsonRecord108, momentJsonRecord109, momentJsonRecord110, momentJsonRecord111]
noncomputable def momentTypedRecordsBlock027 : List MomentRecord := [momentTypedRecord108, momentTypedRecord109, momentTypedRecord110, momentTypedRecord111]

theorem moment_records_block_027_push_eq (acc : List SourceJson) :
    momentRecordsBlock027Push acc = [momentJsonRecord111, momentJsonRecord110, momentJsonRecord109, momentJsonRecord108] ++ acc := by rfl

theorem moment_records_block_027_reverse (acc : List SourceJson) :
    (momentRecordsBlock027Push acc).reverse = acc.reverse ++ momentJsonRecordsBlock027 := by
  rw [moment_records_block_027_push_eq, List.reverse_append]
  rfl

theorem decode_moment_records_block_027 :
    momentJsonRecordsBlock027.mapM decodeMomentRecord = .ok momentTypedRecordsBlock027 := by
  simp only [momentJsonRecordsBlock027, momentTypedRecordsBlock027, List.mapM_cons, List.mapM_nil,
    decode_moment_record_108, decode_moment_record_109, decode_moment_record_110, decode_moment_record_111]
  rfl

noncomputable def momentTypedRowsThroughBlock027 : List MomentRecord := momentTypedRowsThroughBlock026 ++ momentTypedRecordsBlock027

theorem decode_moment_records_through_block_027 :
    momentRecordsAcc112.reverse.mapM decodeMomentRecord = .ok momentTypedRowsThroughBlock027 := by
  change (momentRecordsBlock027Push momentRecordsAcc108).reverse.mapM decodeMomentRecord = _
  rw [moment_records_block_027_reverse]
  rw [List.mapM_append, decode_moment_records_through_block_026, decode_moment_records_block_027]
  rfl

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_block_027_complete"
  err.flush

#print axioms moment_record_108_push_eq
#print axioms decode_moment_record_108
#print axioms moment_record_109_push_eq
#print axioms decode_moment_record_109
#print axioms moment_record_110_push_eq
#print axioms decode_moment_record_110
#print axioms moment_record_111_push_eq
#print axioms decode_moment_record_111
#print axioms moment_records_block_027_push_eq
#print axioms moment_records_block_027_reverse
#print axioms decode_moment_records_block_027
#print axioms decode_moment_records_through_block_027

end ImbalancedChen.P2OriginalSaving19Moment06Decoding
