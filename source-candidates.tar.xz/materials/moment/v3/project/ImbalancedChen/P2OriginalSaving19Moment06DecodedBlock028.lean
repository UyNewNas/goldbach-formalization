/- SOURCE_CANDIDATE: original Cell06 source only. No Lean compilation,
independent kernel replay, full-owned audit or formal acceptance is claimed. -/

import ImbalancedChen.P2OriginalSaving19Moment06DecodedBlock027
import ImbalancedChen.P2OriginalSaving19Moment06RecordsBlock028

/-! Original typed moment records 112 through 112; each concrete value is checked by original decodeMomentRecord.
Candidate quotations preserve exact original raw bytes. The Lean equations bind
them to the production-compatible packed input and run the unchanged reader.
This local input resolves inside this private project, not the P1 filesystem. -/
namespace ImbalancedChen.P2OriginalSaving19Moment06Decoding
set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false
open ImbalancedChen.P2OriginalSaving19Archive

open ImbalancedChen.P2OriginalSaving19Moment06Parsing

noncomputable def momentJsonRecord112 : SourceJson :=
  (momentRecordsChunk112Push []).head (List.cons_ne_nil _ _)

theorem moment_record_112_push_eq (acc : List SourceJson) :
    momentRecordsChunk112Push acc = momentJsonRecord112 :: acc := by rfl

noncomputable def momentTypedRecord112 : MomentRecord :=
  { simplexId := 112,
    factorFloorsQ80 := #[(440709771287236183975 : Int), (469045817680135234701 : Int), (195923834783210803868 : Int), (322171128952487515423 : Int), (373307357847803193674 : Int), (341860615241020007746 : Int), (927845612564106712528 : Int), (413044607723241784884 : Int), (230868697100623475720 : Int), (230873182150484242926 : Int)],
    oldFloorQ96 := (21332090180324 : Int),
    newFloorQ96 := (21401826864684 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_112_before_decode"
  err.flush

theorem decode_moment_record_112 :
    decodeMomentRecord momentJsonRecord112 = .ok momentTypedRecord112 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_112_decoded"
  err.flush

noncomputable def momentJsonRecordsBlock028 : List SourceJson := [momentJsonRecord112]
noncomputable def momentTypedRecordsBlock028 : List MomentRecord := [momentTypedRecord112]

theorem moment_records_block_028_push_eq (acc : List SourceJson) :
    momentRecordsBlock028Push acc = [momentJsonRecord112] ++ acc := by rfl

theorem moment_records_block_028_reverse (acc : List SourceJson) :
    (momentRecordsBlock028Push acc).reverse = acc.reverse ++ momentJsonRecordsBlock028 := by
  rw [moment_records_block_028_push_eq, List.reverse_append]
  rfl

theorem decode_moment_records_block_028 :
    momentJsonRecordsBlock028.mapM decodeMomentRecord = .ok momentTypedRecordsBlock028 := by
  simp only [momentJsonRecordsBlock028, momentTypedRecordsBlock028, List.mapM_cons, List.mapM_nil,
    decode_moment_record_112]
  rfl

noncomputable def momentTypedRowsThroughBlock028 : List MomentRecord := momentTypedRowsThroughBlock027 ++ momentTypedRecordsBlock028

theorem decode_moment_records_through_block_028 :
    momentRecordsAcc113.reverse.mapM decodeMomentRecord = .ok momentTypedRowsThroughBlock028 := by
  change (momentRecordsBlock028Push momentRecordsAcc112).reverse.mapM decodeMomentRecord = _
  rw [moment_records_block_028_reverse]
  rw [List.mapM_append, decode_moment_records_through_block_027, decode_moment_records_block_028]
  rfl

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_block_028_complete"
  err.flush

#print axioms moment_record_112_push_eq
#print axioms decode_moment_record_112
#print axioms moment_records_block_028_push_eq
#print axioms moment_records_block_028_reverse
#print axioms decode_moment_records_block_028
#print axioms decode_moment_records_through_block_028

end ImbalancedChen.P2OriginalSaving19Moment06Decoding
