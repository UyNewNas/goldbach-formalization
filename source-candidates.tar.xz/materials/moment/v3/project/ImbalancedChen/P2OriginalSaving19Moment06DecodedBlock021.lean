/- SOURCE_CANDIDATE: original Cell06 source only. No Lean compilation,
independent kernel replay, full-owned audit or formal acceptance is claimed. -/

import ImbalancedChen.P2OriginalSaving19Moment06DecodedBlock020
import ImbalancedChen.P2OriginalSaving19Moment06RecordsBlock021

/-! Original typed moment records 84 through 87; each concrete value is checked by original decodeMomentRecord.
Candidate quotations preserve exact original raw bytes. The Lean equations bind
them to the production-compatible packed input and run the unchanged reader.
This local input resolves inside this private project, not the P1 filesystem. -/
namespace ImbalancedChen.P2OriginalSaving19Moment06Decoding
set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false
open ImbalancedChen.P2OriginalSaving19Archive

open ImbalancedChen.P2OriginalSaving19Moment06Parsing

noncomputable def momentJsonRecord084 : SourceJson :=
  (momentRecordsChunk084Push []).head (List.cons_ne_nil _ _)

theorem moment_record_084_push_eq (acc : List SourceJson) :
    momentRecordsChunk084Push acc = momentJsonRecord084 :: acc := by rfl

noncomputable def momentTypedRecord084 : MomentRecord :=
  { simplexId := 84,
    factorFloorsQ80 := #[(148268726585253510208 : Int), (224980058584513272424 : Int), (251716366471699026971 : Int), (209282867405550565449 : Int), (181535997873575752426 : Int), (300672194578611167073 : Int), (657175713525788209171 : Int), (744495591601170196427 : Int), (1174126695249609765338 : Int), (228157599662390129533 : Int)],
    oldFloorQ96 := (181195217587625483 : Int),
    newFloorQ96 := (181813843374165711 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_084_before_decode"
  err.flush

theorem decode_moment_record_084 :
    decodeMomentRecord momentJsonRecord084 = .ok momentTypedRecord084 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_084_decoded"
  err.flush

noncomputable def momentJsonRecord085 : SourceJson :=
  (momentRecordsChunk085Push []).head (List.cons_ne_nil _ _)

theorem moment_record_085_push_eq (acc : List SourceJson) :
    momentRecordsChunk085Push acc = momentJsonRecord085 :: acc := by rfl

noncomputable def momentTypedRecord085 : MomentRecord :=
  { simplexId := 85,
    factorFloorsQ80 := #[(162226030688168586350 : Int), (285610689427133436297 : Int), (233889796766194531433 : Int), (129910682460847689122 : Int), (112044093645931149925 : Int), (283435367001022788788 : Int), (646145631296244055412 : Int), (713969468387533584514 : Int), (1126665223976817120975 : Int), (352366476850713313852 : Int)],
    oldFloorQ96 := (172797296023244064 : Int),
    newFloorQ96 := (173376615911333206 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_085_before_decode"
  err.flush

theorem decode_moment_record_085 :
    decodeMomentRecord momentJsonRecord085 = .ok momentTypedRecord085 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_085_decoded"
  err.flush

noncomputable def momentJsonRecord086 : SourceJson :=
  (momentRecordsChunk086Push []).head (List.cons_ne_nil _ _)

theorem moment_record_086_push_eq (acc : List SourceJson) :
    momentRecordsChunk086Push acc = momentJsonRecord086 :: acc := by rfl

noncomputable def momentTypedRecord086 : MomentRecord :=
  { simplexId := 86,
    factorFloorsQ80 := #[(216240015976555103625 : Int), (319692389629819805779 : Int), (263512252820993416522 : Int), (170583503175447643600 : Int), (146665595016218011950 : Int), (122114204610905029503 : Int), (511426085543748453365 : Int), (493047756014152941632 : Int), (602913737956789827662 : Int), (246522698596824571023 : Int)],
    oldFloorQ96 := (57291130933710664 : Int),
    newFloorQ96 := (57437882832767978 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_086_before_decode"
  err.flush

theorem decode_moment_record_086 :
    decodeMomentRecord momentJsonRecord086 = .ok momentTypedRecord086 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_086_decoded"
  err.flush

noncomputable def momentJsonRecord087 : SourceJson :=
  (momentRecordsChunk087Push []).head (List.cons_ne_nil _ _)

theorem moment_record_087_push_eq (acc : List SourceJson) :
    momentRecordsChunk087Push acc = momentJsonRecord087 :: acc := by rfl

noncomputable def momentTypedRecord087 : MomentRecord :=
  { simplexId := 87,
    factorFloorsQ80 := #[(236107312027817799108 : Int), (367282870134249146993 : Int), (254224685584419443072 : Int), (179091608968606345180 : Int), (154055426267196795105 : Int), (126129206336329984696 : Int), (513705226350631651347 : Int), (500800621233328989447 : Int), (397993287399571637810 : Int), (278283696691798766865 : Int)],
    oldFloorQ96 := (52450041482790115 : Int),
    newFloorQ96 := (52580693850949927 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_087_before_decode"
  err.flush

theorem decode_moment_record_087 :
    decodeMomentRecord momentJsonRecord087 = .ok momentTypedRecord087 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_087_decoded"
  err.flush

noncomputable def momentJsonRecordsBlock021 : List SourceJson := [momentJsonRecord084, momentJsonRecord085, momentJsonRecord086, momentJsonRecord087]
noncomputable def momentTypedRecordsBlock021 : List MomentRecord := [momentTypedRecord084, momentTypedRecord085, momentTypedRecord086, momentTypedRecord087]

theorem moment_records_block_021_push_eq (acc : List SourceJson) :
    momentRecordsBlock021Push acc = [momentJsonRecord087, momentJsonRecord086, momentJsonRecord085, momentJsonRecord084] ++ acc := by rfl

theorem moment_records_block_021_reverse (acc : List SourceJson) :
    (momentRecordsBlock021Push acc).reverse = acc.reverse ++ momentJsonRecordsBlock021 := by
  rw [moment_records_block_021_push_eq, List.reverse_append]
  rfl

theorem decode_moment_records_block_021 :
    momentJsonRecordsBlock021.mapM decodeMomentRecord = .ok momentTypedRecordsBlock021 := by
  simp only [momentJsonRecordsBlock021, momentTypedRecordsBlock021, List.mapM_cons, List.mapM_nil,
    decode_moment_record_084, decode_moment_record_085, decode_moment_record_086, decode_moment_record_087]
  rfl

noncomputable def momentTypedRowsThroughBlock021 : List MomentRecord := momentTypedRowsThroughBlock020 ++ momentTypedRecordsBlock021

theorem decode_moment_records_through_block_021 :
    momentRecordsAcc088.reverse.mapM decodeMomentRecord = .ok momentTypedRowsThroughBlock021 := by
  change (momentRecordsBlock021Push momentRecordsAcc084).reverse.mapM decodeMomentRecord = _
  rw [moment_records_block_021_reverse]
  rw [List.mapM_append, decode_moment_records_through_block_020, decode_moment_records_block_021]
  rfl

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_block_021_complete"
  err.flush

#print axioms moment_record_084_push_eq
#print axioms decode_moment_record_084
#print axioms moment_record_085_push_eq
#print axioms decode_moment_record_085
#print axioms moment_record_086_push_eq
#print axioms decode_moment_record_086
#print axioms moment_record_087_push_eq
#print axioms decode_moment_record_087
#print axioms moment_records_block_021_push_eq
#print axioms moment_records_block_021_reverse
#print axioms decode_moment_records_block_021
#print axioms decode_moment_records_through_block_021

end ImbalancedChen.P2OriginalSaving19Moment06Decoding
