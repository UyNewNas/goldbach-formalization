/- SOURCE_CANDIDATE: original Cell06 source only. No Lean compilation,
independent kernel replay, full-owned audit or formal acceptance is claimed. -/

import ImbalancedChen.P2OriginalSaving19Moment06DecodedBlock004
import ImbalancedChen.P2OriginalSaving19Moment06RecordsBlock005

/-! Original typed moment records 20 through 23; each concrete value is checked by original decodeMomentRecord.
Candidate quotations preserve exact original raw bytes. The Lean equations bind
them to the production-compatible packed input and run the unchanged reader.
This local input resolves inside this private project, not the P1 filesystem. -/
namespace ImbalancedChen.P2OriginalSaving19Moment06Decoding
set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false
open ImbalancedChen.P2OriginalSaving19Archive

open ImbalancedChen.P2OriginalSaving19Moment06Parsing

noncomputable def momentJsonRecord020 : SourceJson :=
  (momentRecordsChunk020Push []).head (List.cons_ne_nil _ _)

theorem moment_record_020_push_eq (acc : List SourceJson) :
    momentRecordsChunk020Push acc = momentJsonRecord020 :: acc := by rfl

noncomputable def momentTypedRecord020 : MomentRecord :=
  { simplexId := 20,
    factorFloorsQ80 := #[(277709477302224764388 : Int), (301771881545417308312 : Int), (265050201649747382508 : Int), (171308951190153250418 : Int), (220268109146362767601 : Int), (187413932945354306028 : Int), (142193871131659733109 : Int), (129958129460523574462 : Int), (363955462594217262250 : Int), (141071377875577986720 : Int)],
    oldFloorQ96 := (591200985083106 : Int),
    newFloorQ96 := (592278174218496 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_020_before_decode"
  err.flush

theorem decode_moment_record_020 :
    decodeMomentRecord momentJsonRecord020 = .ok momentTypedRecord020 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_020_decoded"
  err.flush

noncomputable def momentJsonRecord021 : SourceJson :=
  (momentRecordsChunk021Push []).head (List.cons_ne_nil _ _)

theorem moment_record_021_push_eq (acc : List SourceJson) :
    momentRecordsChunk021Push acc = momentJsonRecord021 :: acc := by rfl

noncomputable def momentTypedRecord021 : MomentRecord :=
  { simplexId := 21,
    factorFloorsQ80 := #[(422937542711317452866 : Int), (370997197219340736407 : Int), (249485600097028384024 : Int), (245764078171435595933 : Int), (276600432603600156907 : Int), (235661830729700508013 : Int), (150172722299781311159 : Int), (134001719595468782985 : Int), (362051660728716600692 : Int), (189924665352873950558 : Int)],
    oldFloorQ96 := (161636841272 : Int),
    newFloorQ96 := (161989880583 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_021_before_decode"
  err.flush

theorem decode_moment_record_021 :
    decodeMomentRecord momentJsonRecord021 = .ok momentTypedRecord021 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_021_decoded"
  err.flush

noncomputable def momentJsonRecord022 : SourceJson :=
  (momentRecordsChunk022Push []).head (List.cons_ne_nil _ _)

theorem moment_record_022_push_eq (acc : List SourceJson) :
    momentRecordsChunk022Push acc = momentJsonRecord022 :: acc := by rfl

noncomputable def momentTypedRecord022 : MomentRecord :=
  { simplexId := 22,
    factorFloorsQ80 := #[(429107315789351370467 : Int), (369554102946343485055 : Int), (231577535979514107799 : Int), (280516910177333071929 : Int), (296205905061657214362 : Int), (238542101627301757761 : Int), (170168492601428549076 : Int), (157976966370186941422 : Int), (394542652204352831187 : Int), (190947309036348039135 : Int)],
    oldFloorQ96 := (1077304949803 : Int),
    newFloorQ96 := (1079766497858 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_022_before_decode"
  err.flush

theorem decode_moment_record_022 :
    decodeMomentRecord momentJsonRecord022 = .ok momentTypedRecord022 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_022_decoded"
  err.flush

noncomputable def momentJsonRecord023 : SourceJson :=
  (momentRecordsChunk023Push []).head (List.cons_ne_nil _ _)

theorem moment_record_023_push_eq (acc : List SourceJson) :
    momentRecordsChunk023Push acc = momentJsonRecord023 :: acc := by rfl

noncomputable def momentTypedRecord023 : MomentRecord :=
  { simplexId := 23,
    factorFloorsQ80 := #[(428180575231520543285 : Int), (369550861507216350376 : Int), (214608938047706831029 : Int), (315316597036449172480 : Int), (313748137814832990383 : Int), (286324778133792664734 : Int), (910551962238698214718 : Int), (238286635314180258011 : Int), (457469614633257987149 : Int), (191418826436208944206 : Int)],
    oldFloorQ96 := (8501158290232 : Int),
    newFloorQ96 := (8527396085196 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_023_before_decode"
  err.flush

theorem decode_moment_record_023 :
    decodeMomentRecord momentJsonRecord023 = .ok momentTypedRecord023 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_023_decoded"
  err.flush

noncomputable def momentJsonRecordsBlock005 : List SourceJson := [momentJsonRecord020, momentJsonRecord021, momentJsonRecord022, momentJsonRecord023]
noncomputable def momentTypedRecordsBlock005 : List MomentRecord := [momentTypedRecord020, momentTypedRecord021, momentTypedRecord022, momentTypedRecord023]

theorem moment_records_block_005_push_eq (acc : List SourceJson) :
    momentRecordsBlock005Push acc = [momentJsonRecord023, momentJsonRecord022, momentJsonRecord021, momentJsonRecord020] ++ acc := by rfl

theorem moment_records_block_005_reverse (acc : List SourceJson) :
    (momentRecordsBlock005Push acc).reverse = acc.reverse ++ momentJsonRecordsBlock005 := by
  rw [moment_records_block_005_push_eq, List.reverse_append]
  rfl

theorem decode_moment_records_block_005 :
    momentJsonRecordsBlock005.mapM decodeMomentRecord = .ok momentTypedRecordsBlock005 := by
  simp only [momentJsonRecordsBlock005, momentTypedRecordsBlock005, List.mapM_cons, List.mapM_nil,
    decode_moment_record_020, decode_moment_record_021, decode_moment_record_022, decode_moment_record_023]
  rfl

noncomputable def momentTypedRowsThroughBlock005 : List MomentRecord := momentTypedRowsThroughBlock004 ++ momentTypedRecordsBlock005

theorem decode_moment_records_through_block_005 :
    momentRecordsAcc024.reverse.mapM decodeMomentRecord = .ok momentTypedRowsThroughBlock005 := by
  change (momentRecordsBlock005Push momentRecordsAcc020).reverse.mapM decodeMomentRecord = _
  rw [moment_records_block_005_reverse]
  rw [List.mapM_append, decode_moment_records_through_block_004, decode_moment_records_block_005]
  rfl

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_block_005_complete"
  err.flush

#print axioms moment_record_020_push_eq
#print axioms decode_moment_record_020
#print axioms moment_record_021_push_eq
#print axioms decode_moment_record_021
#print axioms moment_record_022_push_eq
#print axioms decode_moment_record_022
#print axioms moment_record_023_push_eq
#print axioms decode_moment_record_023
#print axioms moment_records_block_005_push_eq
#print axioms moment_records_block_005_reverse
#print axioms decode_moment_records_block_005
#print axioms decode_moment_records_through_block_005

end ImbalancedChen.P2OriginalSaving19Moment06Decoding
