/- SOURCE_CANDIDATE: original Cell06 source only. No Lean compilation,
independent kernel replay, full-owned audit or formal acceptance is claimed. -/

import ImbalancedChen.P2OriginalSaving19Moment06RecordsBlock021

/-! Original moment records block 22. Small arbitrary-tail/accumulator parser equations and one exact packed-input binding.
Candidate quotations preserve exact original raw bytes. The Lean equations bind
them to the production-compatible packed input and run the unchanged reader.
This local input resolves inside this private project, not the P1 filesystem. -/
namespace ImbalancedChen.P2OriginalSaving19Moment06Parsing
set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false
open ImbalancedChen.P2OriginalSaving19Archive

noncomputable def momentRecordsChunk088Chars : List Char := ['\r', '\n', ' ', ' ', ' ', ' ', '{', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 's', 'i', 'm', 'p', 'l', 'e', 'x', '_', 'i', 'd', '"', ':', ' ', '8', '8', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'l', 'o', 'g', '_', 'g', 'a', 'p', '_', 'f', 'a', 'c', 't', 'o', 'r', '_', 'f', 'l', 'o', 'o', 'r', 's', '_', 'Q', '8', '0', '"', ':', ' ', '[', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '4', '7', '5', '4', '1', '4', '1', '8', '8', '5', '2', '0', '5', '6', '9', '9', '7', '7', '5', '8', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '9', '8', '5', '4', '9', '1', '3', '8', '0', '3', '3', '1', '3', '5', '4', '1', '4', '2', '4', '9', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '2', '6', '6', '5', '7', '8', '8', '4', '8', '1', '5', '2', '6', '4', '6', '1', '8', '1', '2', '0', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '4', '3', '0', '4', '8', '7', '3', '7', '5', '1', '3', '5', '5', '2', '7', '2', '4', '7', '3', '9', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '1', '3', '9', '7', '3', '7', '4', '1', '3', '2', '3', '3', '3', '8', '9', '2', '9', '9', '6', '6', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '1', '5', '0', '9', '1', '4', '5', '2', '5', '1', '4', '3', '3', '9', '3', '1', '6', '0', '9', '4', '4', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '5', '3', '1', '7', '6', '0', '8', '0', '5', '6', '5', '6', '0', '0', '8', '9', '9', '0', '5', '8', '8', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '5', '4', '0', '3', '3', '0', '4', '3', '8', '4', '6', '6', '9', '5', '4', '3', '6', '5', '7', '6', '8', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '8', '0', '6', '4', '0', '2', '8', '8', '9', '2', '5', '5', '2', '4', '7', '0', '7', '1', '4', '4', '7', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '3', '2', '8', '7', '2', '0', '4', '0', '2', '8', '3', '2', '6', '1', '6', '0', '9', '7', '6', '1', '"', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ']', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'o', 'l', 'd', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6', '"', ':', ' ', '"', '7', '0', '3', '5', '7', '9', '8', '6', '9', '4', '5', '7', '5', '5', '2', '3', '8', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'n', 'e', 'w', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6', '"', ':', ' ', '"', '7', '0', '5', '6', '1', '5', '1', '3', '8', '3', '7', '2', '5', '9', '5', '3', '3', '"', '\r', '\n', ' ', ' ', ' ', ' ', '}', ',']
noncomputable def momentRecordsChunk088Push (acc : List SourceJson) : List SourceJson :=
  (.obj [(String.ofList ['s', 'i', 'm', 'p', 'l', 'e', 'x', '_', 'i', 'd'], .number (String.ofList ['8', '8'])), (String.ofList ['l', 'o', 'g', '_', 'g', 'a', 'p', '_', 'f', 'a', 'c', 't', 'o', 'r', '_', 'f', 'l', 'o', 'o', 'r', 's', '_', 'Q', '8', '0'], .arr [.str (String.ofList ['2', '4', '7', '5', '4', '1', '4', '1', '8', '8', '5', '2', '0', '5', '6', '9', '9', '7', '7', '5', '8']), .str (String.ofList ['2', '9', '8', '5', '4', '9', '1', '3', '8', '0', '3', '3', '1', '3', '5', '4', '1', '4', '2', '4', '9']), .str (String.ofList ['2', '2', '6', '6', '5', '7', '8', '8', '4', '8', '1', '5', '2', '6', '4', '6', '1', '8', '1', '2', '0']), .str (String.ofList ['2', '4', '3', '0', '4', '8', '7', '3', '7', '5', '1', '3', '5', '5', '2', '7', '2', '4', '7', '3', '9']), .str (String.ofList ['2', '1', '3', '9', '7', '3', '7', '4', '1', '3', '2', '3', '3', '3', '8', '9', '2', '9', '9', '6', '6']), .str (String.ofList ['1', '5', '0', '9', '1', '4', '5', '2', '5', '1', '4', '3', '3', '9', '3', '1', '6', '0', '9', '4', '4']), .str (String.ofList ['5', '3', '1', '7', '6', '0', '8', '0', '5', '6', '5', '6', '0', '0', '8', '9', '9', '0', '5', '8', '8']), .str (String.ofList ['5', '4', '0', '3', '3', '0', '4', '3', '8', '4', '6', '6', '9', '5', '4', '3', '6', '5', '7', '6', '8']), .str (String.ofList ['8', '0', '6', '4', '0', '2', '8', '8', '9', '2', '5', '5', '2', '4', '7', '0', '7', '1', '4', '4', '7']), .str (String.ofList ['2', '3', '2', '8', '7', '2', '0', '4', '0', '2', '8', '3', '2', '6', '1', '6', '0', '9', '7', '6', '1'])]), (String.ofList ['o', 'l', 'd', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6'], .str (String.ofList ['7', '0', '3', '5', '7', '9', '8', '6', '9', '4', '5', '7', '5', '5', '2', '3', '8'])), (String.ofList ['n', 'e', 'w', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6'], .str (String.ofList ['7', '0', '5', '6', '1', '5', '1', '3', '8', '3', '7', '2', '5', '9', '5', '3', '3']))]) :: (acc)

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_chunk_088_before_generic"
  err.flush

theorem array_moment_records_chunk_088 (fuel : Nat) (tail : List Char) (acc : List SourceJson) :
    SourceJson.array (fuel + 62)
      (SourceJson.white (momentRecordsChunk088Chars ++ tail)) acc =
      SourceJson.array (fuel + 61) (SourceJson.white tail) (momentRecordsChunk088Push acc) := by rfl

noncomputable def momentRecordsAcc089 : List SourceJson := momentRecordsChunk088Push momentRecordsAcc088

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_chunk_088_generic_complete"
  err.flush

noncomputable def momentRecordsChunk089Chars : List Char := ['\r', '\n', ' ', ' ', ' ', ' ', '{', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 's', 'i', 'm', 'p', 'l', 'e', 'x', '_', 'i', 'd', '"', ':', ' ', '8', '9', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'l', 'o', 'g', '_', 'g', 'a', 'p', '_', 'f', 'a', 'c', 't', 'o', 'r', '_', 'f', 'l', 'o', 'o', 'r', 's', '_', 'Q', '8', '0', '"', ':', ' ', '[', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '1', '4', '1', '3', '7', '2', '7', '2', '2', '4', '3', '0', '5', '9', '8', '0', '0', '7', '1', '7', '3', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '3', '3', '4', '8', '6', '9', '0', '4', '0', '1', '3', '1', '6', '6', '3', '8', '6', '5', '4', '0', '5', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '6', '9', '0', '5', '7', '5', '3', '3', '3', '2', '6', '2', '6', '0', '0', '1', '5', '6', '7', '9', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '8', '1', '7', '6', '3', '7', '7', '6', '4', '0', '0', '4', '9', '2', '3', '0', '6', '2', '5', '6', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '6', '3', '0', '0', '9', '7', '9', '6', '7', '9', '7', '3', '1', '9', '6', '2', '7', '5', '9', '2', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '8', '3', '2', '4', '6', '2', '3', '7', '2', '2', '9', '8', '7', '0', '9', '3', '7', '1', '4', '6', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '4', '8', '3', '4', '5', '2', '3', '2', '7', '3', '7', '6', '6', '5', '9', '1', '6', '7', '6', '8', '4', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '4', '3', '0', '2', '9', '9', '7', '4', '2', '2', '1', '1', '5', '9', '0', '4', '5', '3', '4', '3', '2', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '3', '7', '0', '1', '0', '6', '7', '7', '5', '5', '7', '8', '1', '9', '8', '9', '1', '0', '0', '0', '9', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '5', '4', '9', '9', '5', '1', '3', '2', '0', '6', '7', '9', '8', '2', '2', '0', '8', '8', '7', '6', '"', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ']', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'o', 'l', 'd', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6', '"', ':', ' ', '"', '9', '6', '0', '3', '8', '6', '1', '4', '9', '7', '7', '9', '0', '4', '9', '4', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'n', 'e', 'w', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6', '"', ':', ' ', '"', '9', '6', '2', '3', '8', '3', '9', '2', '7', '2', '3', '3', '6', '1', '7', '4', '"', '\r', '\n', ' ', ' ', ' ', ' ', '}', ',']
noncomputable def momentRecordsChunk089Push (acc : List SourceJson) : List SourceJson :=
  (.obj [(String.ofList ['s', 'i', 'm', 'p', 'l', 'e', 'x', '_', 'i', 'd'], .number (String.ofList ['8', '9'])), (String.ofList ['l', 'o', 'g', '_', 'g', 'a', 'p', '_', 'f', 'a', 'c', 't', 'o', 'r', '_', 'f', 'l', 'o', 'o', 'r', 's', '_', 'Q', '8', '0'], .arr [.str (String.ofList ['1', '4', '1', '3', '7', '2', '7', '2', '2', '4', '3', '0', '5', '9', '8', '0', '0', '7', '1', '7', '3']), .str (String.ofList ['3', '3', '4', '8', '6', '9', '0', '4', '0', '1', '3', '1', '6', '6', '3', '8', '6', '5', '4', '0', '5']), .str (String.ofList ['2', '6', '9', '0', '5', '7', '5', '3', '3', '3', '2', '6', '2', '6', '0', '0', '1', '5', '6', '7', '9']), .str (String.ofList ['8', '1', '7', '6', '3', '7', '7', '6', '4', '0', '0', '4', '9', '2', '3', '0', '6', '2', '5', '6']), .str (String.ofList ['6', '3', '0', '0', '9', '7', '9', '6', '7', '9', '7', '3', '1', '9', '6', '2', '7', '5', '9', '2']), .str (String.ofList ['8', '3', '2', '4', '6', '2', '3', '7', '2', '2', '9', '8', '7', '0', '9', '3', '7', '1', '4', '6']), .str (String.ofList ['4', '8', '3', '4', '5', '2', '3', '2', '7', '3', '7', '6', '6', '5', '9', '1', '6', '7', '6', '8', '4']), .str (String.ofList ['4', '3', '0', '2', '9', '9', '7', '4', '2', '2', '1', '1', '5', '9', '0', '4', '5', '3', '4', '3', '2']), .str (String.ofList ['3', '7', '0', '1', '0', '6', '7', '7', '5', '5', '7', '8', '1', '9', '8', '9', '1', '0', '0', '0', '9']), .str (String.ofList ['2', '5', '4', '9', '9', '5', '1', '3', '2', '0', '6', '7', '9', '8', '2', '2', '0', '8', '8', '7', '6'])]), (String.ofList ['o', 'l', 'd', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6'], .str (String.ofList ['9', '6', '0', '3', '8', '6', '1', '4', '9', '7', '7', '9', '0', '4', '9', '4'])), (String.ofList ['n', 'e', 'w', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6'], .str (String.ofList ['9', '6', '2', '3', '8', '3', '9', '2', '7', '2', '3', '3', '6', '1', '7', '4']))]) :: (acc)

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_chunk_089_before_generic"
  err.flush

theorem array_moment_records_chunk_089 (fuel : Nat) (tail : List Char) (acc : List SourceJson) :
    SourceJson.array (fuel + 61)
      (SourceJson.white (momentRecordsChunk089Chars ++ tail)) acc =
      SourceJson.array (fuel + 60) (SourceJson.white tail) (momentRecordsChunk089Push acc) := by rfl

noncomputable def momentRecordsAcc090 : List SourceJson := momentRecordsChunk089Push momentRecordsAcc089

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_chunk_089_generic_complete"
  err.flush

noncomputable def momentRecordsChunk090Chars : List Char := ['\r', '\n', ' ', ' ', ' ', ' ', '{', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 's', 'i', 'm', 'p', 'l', 'e', 'x', '_', 'i', 'd', '"', ':', ' ', '9', '0', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'l', 'o', 'g', '_', 'g', 'a', 'p', '_', 'f', 'a', 'c', 't', 'o', 'r', '_', 'f', 'l', 'o', 'o', 'r', 's', '_', 'Q', '8', '0', '"', ':', ' ', '[', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '1', '4', '3', '1', '6', '8', '6', '3', '7', '3', '4', '3', '7', '6', '0', '7', '8', '6', '3', '7', '9', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '2', '5', '5', '4', '7', '9', '1', '6', '8', '5', '6', '7', '8', '3', '2', '0', '9', '8', '2', '0', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '1', '0', '2', '9', '8', '8', '1', '4', '4', '1', '4', '9', '5', '4', '0', '3', '2', '8', '5', '1', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '1', '4', '7', '4', '6', '5', '4', '0', '0', '7', '6', '3', '1', '9', '0', '2', '9', '7', '8', '5', '0', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '1', '2', '7', '3', '6', '2', '2', '7', '7', '9', '5', '3', '3', '1', '2', '0', '4', '7', '9', '5', '9', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '1', '1', '6', '5', '1', '4', '8', '1', '1', '3', '4', '7', '2', '5', '7', '2', '6', '5', '8', '6', '3', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '5', '1', '9', '3', '7', '8', '3', '9', '8', '4', '7', '1', '0', '9', '1', '9', '7', '6', '9', '2', '4', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '4', '5', '8', '9', '4', '9', '1', '2', '7', '5', '4', '9', '3', '3', '3', '2', '7', '3', '7', '2', '0', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '8', '1', '7', '4', '4', '0', '2', '0', '4', '2', '9', '8', '7', '8', '0', '5', '4', '8', '6', '0', '6', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '0', '2', '5', '8', '8', '6', '1', '7', '0', '4', '0', '8', '7', '8', '2', '7', '0', '0', '7', '6', '"', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ']', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'o', 'l', 'd', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6', '"', ':', ' ', '"', '5', '5', '2', '1', '1', '3', '5', '1', '9', '6', '0', '6', '9', '6', '7', '1', '5', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'n', 'e', 'w', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6', '"', ':', ' ', '"', '5', '5', '3', '4', '7', '0', '9', '9', '0', '3', '2', '0', '2', '0', '7', '3', '3', '"', '\r', '\n', ' ', ' ', ' ', ' ', '}', ',']
noncomputable def momentRecordsChunk090Push (acc : List SourceJson) : List SourceJson :=
  (.obj [(String.ofList ['s', 'i', 'm', 'p', 'l', 'e', 'x', '_', 'i', 'd'], .number (String.ofList ['9', '0'])), (String.ofList ['l', 'o', 'g', '_', 'g', 'a', 'p', '_', 'f', 'a', 'c', 't', 'o', 'r', '_', 'f', 'l', 'o', 'o', 'r', 's', '_', 'Q', '8', '0'], .arr [.str (String.ofList ['1', '4', '3', '1', '6', '8', '6', '3', '7', '3', '4', '3', '7', '6', '0', '7', '8', '6', '3', '7', '9']), .str (String.ofList ['2', '2', '5', '5', '4', '7', '9', '1', '6', '8', '5', '6', '7', '8', '3', '2', '0', '9', '8', '2', '0']), .str (String.ofList ['2', '1', '0', '2', '9', '8', '8', '1', '4', '4', '1', '4', '9', '5', '4', '0', '3', '2', '8', '5', '1']), .str (String.ofList ['1', '4', '7', '4', '6', '5', '4', '0', '0', '7', '6', '3', '1', '9', '0', '2', '9', '7', '8', '5', '0']), .str (String.ofList ['1', '2', '7', '3', '6', '2', '2', '7', '7', '9', '5', '3', '3', '1', '2', '0', '4', '7', '9', '5', '9']), .str (String.ofList ['1', '1', '6', '5', '1', '4', '8', '1', '1', '3', '4', '7', '2', '5', '7', '2', '6', '5', '8', '6', '3']), .str (String.ofList ['5', '1', '9', '3', '7', '8', '3', '9', '8', '4', '7', '1', '0', '9', '1', '9', '7', '6', '9', '2', '4']), .str (String.ofList ['4', '5', '8', '9', '4', '9', '1', '2', '7', '5', '4', '9', '3', '3', '3', '2', '7', '3', '7', '2', '0']), .str (String.ofList ['8', '1', '7', '4', '4', '0', '2', '0', '4', '2', '9', '8', '7', '8', '0', '5', '4', '8', '6', '0', '6']), .str (String.ofList ['2', '0', '2', '5', '8', '8', '6', '1', '7', '0', '4', '0', '8', '7', '8', '2', '7', '0', '0', '7', '6'])]), (String.ofList ['o', 'l', 'd', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6'], .str (String.ofList ['5', '5', '2', '1', '1', '3', '5', '1', '9', '6', '0', '6', '9', '6', '7', '1', '5'])), (String.ofList ['n', 'e', 'w', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6'], .str (String.ofList ['5', '5', '3', '4', '7', '0', '9', '9', '0', '3', '2', '0', '2', '0', '7', '3', '3']))]) :: (acc)

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_chunk_090_before_generic"
  err.flush

theorem array_moment_records_chunk_090 (fuel : Nat) (tail : List Char) (acc : List SourceJson) :
    SourceJson.array (fuel + 60)
      (SourceJson.white (momentRecordsChunk090Chars ++ tail)) acc =
      SourceJson.array (fuel + 59) (SourceJson.white tail) (momentRecordsChunk090Push acc) := by rfl

noncomputable def momentRecordsAcc091 : List SourceJson := momentRecordsChunk090Push momentRecordsAcc090

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_chunk_090_generic_complete"
  err.flush

noncomputable def momentRecordsChunk091Chars : List Char := ['\r', '\n', ' ', ' ', ' ', ' ', '{', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 's', 'i', 'm', 'p', 'l', 'e', 'x', '_', 'i', 'd', '"', ':', ' ', '9', '1', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'l', 'o', 'g', '_', 'g', 'a', 'p', '_', 'f', 'a', 'c', 't', 'o', 'r', '_', 'f', 'l', 'o', 'o', 'r', 's', '_', 'Q', '8', '0', '"', ':', ' ', '[', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '1', '1', '3', '3', '2', '5', '2', '7', '9', '6', '7', '4', '8', '8', '6', '7', '5', '8', '7', '2', '4', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '7', '6', '3', '4', '7', '7', '5', '8', '7', '3', '4', '8', '9', '6', '1', '2', '6', '8', '4', '0', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '3', '2', '4', '7', '2', '5', '0', '4', '6', '7', '6', '2', '5', '0', '5', '5', '8', '5', '7', '2', '6', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '1', '2', '6', '7', '1', '2', '8', '0', '8', '0', '1', '0', '9', '4', '0', '4', '7', '5', '8', '9', '7', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '1', '5', '7', '2', '6', '2', '6', '7', '0', '4', '2', '0', '2', '3', '4', '8', '2', '5', '9', '7', '8', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '1', '4', '5', '1', '0', '4', '0', '0', '5', '7', '4', '9', '9', '1', '3', '5', '3', '7', '3', '9', '6', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '1', '5', '3', '7', '0', '3', '9', '5', '6', '2', '2', '6', '8', '4', '4', '2', '8', '5', '4', '3', '2', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '1', '4', '0', '4', '1', '2', '4', '6', '5', '7', '3', '8', '0', '9', '6', '0', '6', '7', '2', '2', '0', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '3', '7', '3', '1', '5', '9', '5', '6', '5', '8', '0', '4', '9', '5', '5', '8', '8', '7', '9', '1', '4', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '1', '8', '2', '0', '6', '1', '2', '9', '8', '4', '8', '1', '0', '5', '1', '2', '6', '4', '0', '9', '8', '"', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ']', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'o', 'l', 'd', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6', '"', ':', ' ', '"', '1', '2', '9', '3', '6', '0', '2', '2', '6', '7', '6', '3', '9', '3', '8', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'n', 'e', 'w', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6', '"', ':', ' ', '"', '1', '2', '9', '5', '7', '3', '6', '4', '2', '3', '1', '6', '6', '5', '8', '"', '\r', '\n', ' ', ' ', ' ', ' ', '}', ',']
noncomputable def momentRecordsChunk091Push (acc : List SourceJson) : List SourceJson :=
  (.obj [(String.ofList ['s', 'i', 'm', 'p', 'l', 'e', 'x', '_', 'i', 'd'], .number (String.ofList ['9', '1'])), (String.ofList ['l', 'o', 'g', '_', 'g', 'a', 'p', '_', 'f', 'a', 'c', 't', 'o', 'r', '_', 'f', 'l', 'o', 'o', 'r', 's', '_', 'Q', '8', '0'], .arr [.str (String.ofList ['1', '1', '3', '3', '2', '5', '2', '7', '9', '6', '7', '4', '8', '8', '6', '7', '5', '8', '7', '2', '4']), .str (String.ofList ['2', '7', '6', '3', '4', '7', '7', '5', '8', '7', '3', '4', '8', '9', '6', '1', '2', '6', '8', '4', '0']), .str (String.ofList ['3', '2', '4', '7', '2', '5', '0', '4', '6', '7', '6', '2', '5', '0', '5', '5', '8', '5', '7', '2', '6']), .str (String.ofList ['1', '2', '6', '7', '1', '2', '8', '0', '8', '0', '1', '0', '9', '4', '0', '4', '7', '5', '8', '9', '7']), .str (String.ofList ['1', '5', '7', '2', '6', '2', '6', '7', '0', '4', '2', '0', '2', '3', '4', '8', '2', '5', '9', '7', '8']), .str (String.ofList ['1', '4', '5', '1', '0', '4', '0', '0', '5', '7', '4', '9', '9', '1', '3', '5', '3', '7', '3', '9', '6']), .str (String.ofList ['1', '5', '3', '7', '0', '3', '9', '5', '6', '2', '2', '6', '8', '4', '4', '2', '8', '5', '4', '3', '2']), .str (String.ofList ['1', '4', '0', '4', '1', '2', '4', '6', '5', '7', '3', '8', '0', '9', '6', '0', '6', '7', '2', '2', '0']), .str (String.ofList ['3', '7', '3', '1', '5', '9', '5', '6', '5', '8', '0', '4', '9', '5', '5', '8', '8', '7', '9', '1', '4']), .str (String.ofList ['1', '8', '2', '0', '6', '1', '2', '9', '8', '4', '8', '1', '0', '5', '1', '2', '6', '4', '0', '9', '8'])]), (String.ofList ['o', 'l', 'd', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6'], .str (String.ofList ['1', '2', '9', '3', '6', '0', '2', '2', '6', '7', '6', '3', '9', '3', '8'])), (String.ofList ['n', 'e', 'w', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6'], .str (String.ofList ['1', '2', '9', '5', '7', '3', '6', '4', '2', '3', '1', '6', '6', '5', '8']))]) :: (acc)

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_chunk_091_before_generic"
  err.flush

theorem array_moment_records_chunk_091 (fuel : Nat) (tail : List Char) (acc : List SourceJson) :
    SourceJson.array (fuel + 59)
      (SourceJson.white (momentRecordsChunk091Chars ++ tail)) acc =
      SourceJson.array (fuel + 58) (SourceJson.white tail) (momentRecordsChunk091Push acc) := by rfl

noncomputable def momentRecordsAcc092 : List SourceJson := momentRecordsChunk091Push momentRecordsAcc091

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_chunk_091_generic_complete"
  err.flush

noncomputable def momentRecordsBlock022Chars : List Char := momentRecordsChunk088Chars ++ momentRecordsChunk089Chars ++ momentRecordsChunk090Chars ++ momentRecordsChunk091Chars
noncomputable def momentRecordsBlock022Push (acc : List SourceJson) : List SourceJson := momentRecordsChunk091Push (momentRecordsChunk090Push (momentRecordsChunk089Push (momentRecordsChunk088Push (acc))))

theorem array_moment_records_block_022 (fuel : Nat) (tail : List Char) (acc : List SourceJson) :
    SourceJson.array (fuel + 62)
      (SourceJson.white (momentRecordsBlock022Chars ++ tail)) acc =
      SourceJson.array (fuel + 58) (SourceJson.white tail) (momentRecordsBlock022Push acc) := by
  have hinput : momentRecordsBlock022Chars ++ tail = momentRecordsChunk088Chars ++ (momentRecordsChunk089Chars ++ (momentRecordsChunk090Chars ++ (momentRecordsChunk091Chars ++ (tail)))) := by
    simp only [momentRecordsBlock022Chars, List.append_assoc]
  calc
    SourceJson.array (fuel + 62) (SourceJson.white (momentRecordsBlock022Chars ++ tail)) acc =
        SourceJson.array (fuel + 62) (SourceJson.white (momentRecordsChunk088Chars ++ (momentRecordsChunk089Chars ++ (momentRecordsChunk090Chars ++ (momentRecordsChunk091Chars ++ (tail)))))) acc :=
      congrArg (fun s => SourceJson.array (fuel + 62) (SourceJson.white s) acc) hinput
    _ = SourceJson.array (fuel + 61) (SourceJson.white (momentRecordsChunk089Chars ++ (momentRecordsChunk090Chars ++ (momentRecordsChunk091Chars ++ (tail))))) (momentRecordsChunk088Push (acc)) := array_moment_records_chunk_088 fuel (momentRecordsChunk089Chars ++ (momentRecordsChunk090Chars ++ (momentRecordsChunk091Chars ++ (tail)))) (acc)
    _ = SourceJson.array (fuel + 60) (SourceJson.white (momentRecordsChunk090Chars ++ (momentRecordsChunk091Chars ++ (tail)))) (momentRecordsChunk089Push (momentRecordsChunk088Push (acc))) := array_moment_records_chunk_089 fuel (momentRecordsChunk090Chars ++ (momentRecordsChunk091Chars ++ (tail))) (momentRecordsChunk088Push (acc))
    _ = SourceJson.array (fuel + 59) (SourceJson.white (momentRecordsChunk091Chars ++ (tail))) (momentRecordsChunk090Push (momentRecordsChunk089Push (momentRecordsChunk088Push (acc)))) := array_moment_records_chunk_090 fuel (momentRecordsChunk091Chars ++ (tail)) (momentRecordsChunk089Push (momentRecordsChunk088Push (acc)))
    _ = SourceJson.array (fuel + 58) (SourceJson.white tail) (momentRecordsBlock022Push acc) := array_moment_records_chunk_091 fuel (tail) (momentRecordsChunk090Push (momentRecordsChunk089Push (momentRecordsChunk088Push (acc))))

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_block_022_before_raw_binding"
  err.flush

theorem moment_records_block_022_prefix :
    (momentRest06 45507).take 2055 = momentRecordsBlock022Chars := by rfl

theorem moment_records_block_022_split :
    momentRest06 45507 = momentRecordsBlock022Chars ++ momentRest06 47562 := by
  calc
    momentRest06 45507 =
        (momentRest06 45507).take 2055 ++ (momentRest06 45507).drop 2055 :=
      (List.take_append_drop 2055 (momentRest06 45507)).symm
    _ = momentRecordsBlock022Chars ++ (momentRest06 45507).drop 2055 :=
      congrArg (fun p => p ++ (momentRest06 45507).drop 2055) moment_records_block_022_prefix
    _ = momentRecordsBlock022Chars ++ momentRest06 47562 :=
      congrArg (fun rest => momentRecordsBlock022Chars ++ rest) (momentRest06_drop 45507 2055)

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_block_022_after_raw_binding"
  err.flush

theorem array_moment_records_original_block_022 (fuel : Nat) (acc : List SourceJson) :
    SourceJson.array (fuel + 62)
      (SourceJson.white (momentRest06 45507)) acc =
      SourceJson.array (fuel + 58) (SourceJson.white (momentRest06 47562)) (momentRecordsBlock022Push acc) := by
  exact (congrArg (fun s => SourceJson.array (fuel + 62) (SourceJson.white s) acc)
      moment_records_block_022_split).trans (array_moment_records_block_022 fuel (momentRest06 47562) acc)

theorem moment_records_through_block_022 (fuel : Nat) :
    SourceJson.array (fuel + 150)
      (SourceJson.white (momentRest06 364)) [] =
      SourceJson.array (fuel + 58) (SourceJson.white (momentRest06 47562)) momentRecordsAcc092 := by
  exact (moment_records_through_block_021 fuel).trans (array_moment_records_original_block_022 fuel momentRecordsAcc088)

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_block_022_complete"
  err.flush

#print axioms array_moment_records_chunk_088
#print axioms array_moment_records_chunk_089
#print axioms array_moment_records_chunk_090
#print axioms array_moment_records_chunk_091
#print axioms array_moment_records_block_022
#print axioms moment_records_block_022_prefix
#print axioms moment_records_block_022_split
#print axioms array_moment_records_original_block_022
#print axioms moment_records_through_block_022

end ImbalancedChen.P2OriginalSaving19Moment06Parsing
