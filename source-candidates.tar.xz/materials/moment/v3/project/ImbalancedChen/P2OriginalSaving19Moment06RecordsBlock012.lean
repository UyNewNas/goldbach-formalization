/- SOURCE_CANDIDATE: original Cell06 source only. No Lean compilation,
independent kernel replay, full-owned audit or formal acceptance is claimed. -/

import ImbalancedChen.P2OriginalSaving19Moment06RecordsBlock011

/-! Original moment records block 12. Small arbitrary-tail/accumulator parser equations and one exact packed-input binding.
Candidate quotations preserve exact original raw bytes. The Lean equations bind
them to the production-compatible packed input and run the unchanged reader.
This local input resolves inside this private project, not the P1 filesystem. -/
namespace ImbalancedChen.P2OriginalSaving19Moment06Parsing
set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false
open ImbalancedChen.P2OriginalSaving19Archive

noncomputable def momentRecordsChunk048Chars : List Char := ['\r', '\n', ' ', ' ', ' ', ' ', '{', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 's', 'i', 'm', 'p', 'l', 'e', 'x', '_', 'i', 'd', '"', ':', ' ', '4', '8', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'l', 'o', 'g', '_', 'g', 'a', 'p', '_', 'f', 'a', 'c', 't', 'o', 'r', '_', 'f', 'l', 'o', 'o', 'r', 's', '_', 'Q', '8', '0', '"', ':', ' ', '[', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '3', '5', '5', '5', '7', '8', '6', '0', '6', '1', '2', '3', '9', '4', '1', '0', '7', '6', '2', '7', '6', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '3', '2', '0', '4', '5', '8', '7', '4', '8', '8', '1', '3', '8', '8', '5', '2', '0', '3', '5', '2', '6', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '7', '8', '5', '6', '1', '7', '0', '8', '1', '9', '6', '4', '2', '1', '0', '0', '8', '8', '6', '6', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '9', '1', '8', '5', '2', '9', '2', '4', '2', '2', '3', '5', '9', '4', '6', '1', '7', '6', '2', '7', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '4', '0', '5', '3', '3', '0', '1', '3', '1', '5', '9', '7', '5', '1', '1', '3', '2', '8', '4', '1', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '0', '7', '4', '4', '3', '9', '5', '0', '8', '5', '8', '0', '5', '7', '4', '9', '7', '5', '4', '3', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '3', '1', '2', '8', '4', '8', '1', '2', '7', '9', '1', '3', '1', '4', '3', '5', '4', '1', '5', '7', '1', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '9', '0', '4', '0', '2', '6', '0', '3', '7', '5', '3', '9', '3', '7', '0', '6', '9', '5', '3', '2', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '4', '6', '1', '4', '2', '1', '9', '9', '8', '5', '5', '0', '7', '7', '9', '4', '9', '2', '6', '3', '6', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '1', '5', '7', '9', '2', '9', '8', '4', '7', '2', '2', '8', '6', '4', '8', '6', '7', '5', '9', '2', '9', '"', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ']', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'o', 'l', 'd', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6', '"', ':', ' ', '"', '5', '8', '6', '6', '8', '0', '8', '7', '0', '0', '3', '3', '0', '9', '9', '8', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'n', 'e', 'w', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6', '"', ':', ' ', '"', '5', '8', '8', '0', '9', '8', '1', '8', '8', '5', '4', '5', '5', '4', '6', '8', '"', '\r', '\n', ' ', ' ', ' ', ' ', '}', ',']
noncomputable def momentRecordsChunk048Push (acc : List SourceJson) : List SourceJson :=
  (.obj [(String.ofList ['s', 'i', 'm', 'p', 'l', 'e', 'x', '_', 'i', 'd'], .number (String.ofList ['4', '8'])), (String.ofList ['l', 'o', 'g', '_', 'g', 'a', 'p', '_', 'f', 'a', 'c', 't', 'o', 'r', '_', 'f', 'l', 'o', 'o', 'r', 's', '_', 'Q', '8', '0'], .arr [.str (String.ofList ['3', '5', '5', '5', '7', '8', '6', '0', '6', '1', '2', '3', '9', '4', '1', '0', '7', '6', '2', '7', '6']), .str (String.ofList ['3', '2', '0', '4', '5', '8', '7', '4', '8', '8', '1', '3', '8', '8', '5', '2', '0', '3', '5', '2', '6']), .str (String.ofList ['2', '7', '8', '5', '6', '1', '7', '0', '8', '1', '9', '6', '4', '2', '1', '0', '0', '8', '8', '6', '6']), .str (String.ofList ['2', '9', '1', '8', '5', '2', '9', '2', '4', '2', '2', '3', '5', '9', '4', '6', '1', '7', '6', '2', '7']), .str (String.ofList ['2', '4', '0', '5', '3', '3', '0', '1', '3', '1', '5', '9', '7', '5', '1', '1', '3', '2', '8', '4', '1']), .str (String.ofList ['2', '0', '7', '4', '4', '3', '9', '5', '0', '8', '5', '8', '0', '5', '7', '4', '9', '7', '5', '4', '3']), .str (String.ofList ['3', '1', '2', '8', '4', '8', '1', '2', '7', '9', '1', '3', '1', '4', '3', '5', '4', '1', '5', '7', '1']), .str (String.ofList ['2', '9', '0', '4', '0', '2', '6', '0', '3', '7', '5', '3', '9', '3', '7', '0', '6', '9', '5', '3', '2']), .str (String.ofList ['4', '6', '1', '4', '2', '1', '9', '9', '8', '5', '5', '0', '7', '7', '9', '4', '9', '2', '6', '3', '6']), .str (String.ofList ['1', '5', '7', '9', '2', '9', '8', '4', '7', '2', '2', '8', '6', '4', '8', '6', '7', '5', '9', '2', '9'])]), (String.ofList ['o', 'l', 'd', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6'], .str (String.ofList ['5', '8', '6', '6', '8', '0', '8', '7', '0', '0', '3', '3', '0', '9', '9', '8'])), (String.ofList ['n', 'e', 'w', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6'], .str (String.ofList ['5', '8', '8', '0', '9', '8', '1', '8', '8', '5', '4', '5', '5', '4', '6', '8']))]) :: (acc)

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_chunk_048_before_generic"
  err.flush

theorem array_moment_records_chunk_048 (fuel : Nat) (tail : List Char) (acc : List SourceJson) :
    SourceJson.array (fuel + 102)
      (SourceJson.white (momentRecordsChunk048Chars ++ tail)) acc =
      SourceJson.array (fuel + 101) (SourceJson.white tail) (momentRecordsChunk048Push acc) := by rfl

noncomputable def momentRecordsAcc049 : List SourceJson := momentRecordsChunk048Push momentRecordsAcc048

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_chunk_048_generic_complete"
  err.flush

noncomputable def momentRecordsChunk049Chars : List Char := ['\r', '\n', ' ', ' ', ' ', ' ', '{', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 's', 'i', 'm', 'p', 'l', 'e', 'x', '_', 'i', 'd', '"', ':', ' ', '4', '9', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'l', 'o', 'g', '_', 'g', 'a', 'p', '_', 'f', 'a', 'c', 't', 'o', 'r', '_', 'f', 'l', 'o', 'o', 'r', 's', '_', 'Q', '8', '0', '"', ':', ' ', '[', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '3', '6', '0', '8', '4', '8', '4', '5', '7', '8', '3', '0', '1', '8', '8', '2', '0', '6', '5', '7', '7', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '3', '2', '0', '2', '6', '6', '6', '7', '3', '1', '3', '3', '0', '8', '1', '3', '3', '3', '4', '5', '2', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '5', '8', '2', '1', '3', '3', '2', '4', '2', '9', '6', '6', '4', '4', '9', '7', '9', '5', '7', '0', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '3', '4', '0', '4', '5', '9', '7', '8', '6', '1', '5', '1', '0', '4', '3', '1', '3', '1', '7', '4', '6', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '8', '2', '1', '9', '0', '5', '0', '2', '7', '4', '2', '3', '0', '2', '5', '7', '2', '1', '2', '9', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '8', '4', '5', '8', '8', '4', '7', '4', '6', '4', '8', '5', '8', '8', '7', '1', '2', '0', '6', '4', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '1', '1', '2', '9', '4', '7', '1', '9', '2', '0', '5', '0', '1', '5', '3', '2', '6', '4', '7', '6', '5', '4', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '3', '4', '9', '3', '5', '7', '4', '2', '7', '1', '4', '1', '3', '2', '5', '7', '7', '8', '2', '2', '2', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '4', '7', '3', '6', '9', '8', '5', '1', '0', '2', '5', '0', '4', '6', '8', '6', '4', '7', '4', '4', '0', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '1', '5', '8', '2', '3', '1', '9', '4', '4', '3', '2', '6', '7', '4', '9', '8', '7', '6', '5', '6', '6', '"', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ']', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'o', 'l', 'd', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6', '"', ':', ' ', '"', '4', '6', '2', '7', '0', '7', '9', '3', '9', '9', '8', '4', '6', '8', '2', '3', '3', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'n', 'e', 'w', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6', '"', ':', ' ', '"', '4', '6', '4', '2', '2', '5', '0', '6', '1', '0', '8', '1', '5', '5', '5', '0', '5', '"', '\r', '\n', ' ', ' ', ' ', ' ', '}', ',']
noncomputable def momentRecordsChunk049Push (acc : List SourceJson) : List SourceJson :=
  (.obj [(String.ofList ['s', 'i', 'm', 'p', 'l', 'e', 'x', '_', 'i', 'd'], .number (String.ofList ['4', '9'])), (String.ofList ['l', 'o', 'g', '_', 'g', 'a', 'p', '_', 'f', 'a', 'c', 't', 'o', 'r', '_', 'f', 'l', 'o', 'o', 'r', 's', '_', 'Q', '8', '0'], .arr [.str (String.ofList ['3', '6', '0', '8', '4', '8', '4', '5', '7', '8', '3', '0', '1', '8', '8', '2', '0', '6', '5', '7', '7']), .str (String.ofList ['3', '2', '0', '2', '6', '6', '6', '7', '3', '1', '3', '3', '0', '8', '1', '3', '3', '3', '4', '5', '2']), .str (String.ofList ['2', '5', '8', '2', '1', '3', '3', '2', '4', '2', '9', '6', '6', '4', '4', '9', '7', '9', '5', '7', '0']), .str (String.ofList ['3', '4', '0', '4', '5', '9', '7', '8', '6', '1', '5', '1', '0', '4', '3', '1', '3', '1', '7', '4', '6']), .str (String.ofList ['2', '8', '2', '1', '9', '0', '5', '0', '2', '7', '4', '2', '3', '0', '2', '5', '7', '2', '1', '2', '9']), .str (String.ofList ['2', '8', '4', '5', '8', '8', '4', '7', '4', '6', '4', '8', '5', '8', '8', '7', '1', '2', '0', '6', '4']), .str (String.ofList ['1', '1', '2', '9', '4', '7', '1', '9', '2', '0', '5', '0', '1', '5', '3', '2', '6', '4', '7', '6', '5', '4']), .str (String.ofList ['3', '4', '9', '3', '5', '7', '4', '2', '7', '1', '4', '1', '3', '2', '5', '7', '7', '8', '2', '2', '2']), .str (String.ofList ['4', '7', '3', '6', '9', '8', '5', '1', '0', '2', '5', '0', '4', '6', '8', '6', '4', '7', '4', '4', '0']), .str (String.ofList ['1', '5', '8', '2', '3', '1', '9', '4', '4', '3', '2', '6', '7', '4', '9', '8', '7', '6', '5', '6', '6'])]), (String.ofList ['o', 'l', 'd', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6'], .str (String.ofList ['4', '6', '2', '7', '0', '7', '9', '3', '9', '9', '8', '4', '6', '8', '2', '3', '3'])), (String.ofList ['n', 'e', 'w', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6'], .str (String.ofList ['4', '6', '4', '2', '2', '5', '0', '6', '1', '0', '8', '1', '5', '5', '5', '0', '5']))]) :: (acc)

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_chunk_049_before_generic"
  err.flush

theorem array_moment_records_chunk_049 (fuel : Nat) (tail : List Char) (acc : List SourceJson) :
    SourceJson.array (fuel + 101)
      (SourceJson.white (momentRecordsChunk049Chars ++ tail)) acc =
      SourceJson.array (fuel + 100) (SourceJson.white tail) (momentRecordsChunk049Push acc) := by rfl

noncomputable def momentRecordsAcc050 : List SourceJson := momentRecordsChunk049Push momentRecordsAcc049

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_chunk_049_generic_complete"
  err.flush

noncomputable def momentRecordsChunk050Chars : List Char := ['\r', '\n', ' ', ' ', ' ', ' ', '{', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 's', 'i', 'm', 'p', 'l', 'e', 'x', '_', 'i', 'd', '"', ':', ' ', '5', '0', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'l', 'o', 'g', '_', 'g', 'a', 'p', '_', 'f', 'a', 'c', 't', 'o', 'r', '_', 'f', 'l', 'o', 'o', 'r', 's', '_', 'Q', '8', '0', '"', ':', ' ', '[', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '4', '1', '7', '3', '6', '9', '6', '9', '1', '4', '3', '3', '8', '7', '2', '0', '2', '7', '1', '4', '4', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '3', '9', '5', '7', '1', '4', '0', '8', '7', '6', '3', '6', '6', '4', '8', '8', '2', '9', '4', '5', '9', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '4', '4', '7', '9', '8', '8', '6', '6', '1', '4', '6', '2', '8', '4', '6', '9', '7', '6', '0', '7', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '3', '6', '0', '7', '3', '2', '4', '6', '7', '2', '4', '0', '2', '5', '8', '7', '2', '6', '2', '7', '9', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '9', '6', '7', '9', '4', '3', '8', '7', '2', '5', '5', '7', '2', '7', '0', '5', '0', '7', '7', '5', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '3', '7', '6', '6', '6', '4', '9', '8', '0', '6', '2', '4', '0', '0', '1', '3', '3', '6', '7', '9', '5', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '1', '2', '0', '6', '8', '8', '8', '8', '7', '7', '5', '0', '6', '8', '3', '8', '0', '1', '1', '4', '1', '1', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '5', '5', '9', '7', '2', '0', '4', '7', '6', '5', '7', '0', '9', '0', '4', '1', '0', '0', '7', '2', '2', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '7', '6', '1', '2', '2', '4', '1', '9', '1', '8', '2', '0', '3', '7', '6', '9', '5', '3', '8', '2', '0', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '6', '3', '5', '3', '1', '5', '9', '6', '3', '8', '0', '1', '5', '7', '9', '8', '0', '7', '5', '7', '"', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ']', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'o', 'l', 'd', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6', '"', ':', ' ', '"', '2', '2', '6', '9', '0', '7', '7', '3', '4', '8', '0', '6', '5', '3', '3', '5', '4', '8', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'n', 'e', 'w', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6', '"', ':', ' ', '"', '2', '2', '7', '8', '2', '6', '1', '7', '9', '3', '2', '6', '5', '7', '2', '1', '7', '0', '"', '\r', '\n', ' ', ' ', ' ', ' ', '}', ',']
noncomputable def momentRecordsChunk050Push (acc : List SourceJson) : List SourceJson :=
  (.obj [(String.ofList ['s', 'i', 'm', 'p', 'l', 'e', 'x', '_', 'i', 'd'], .number (String.ofList ['5', '0'])), (String.ofList ['l', 'o', 'g', '_', 'g', 'a', 'p', '_', 'f', 'a', 'c', 't', 'o', 'r', '_', 'f', 'l', 'o', 'o', 'r', 's', '_', 'Q', '8', '0'], .arr [.str (String.ofList ['4', '1', '7', '3', '6', '9', '6', '9', '1', '4', '3', '3', '8', '7', '2', '0', '2', '7', '1', '4', '4']), .str (String.ofList ['3', '9', '5', '7', '1', '4', '0', '8', '7', '6', '3', '6', '6', '4', '8', '8', '2', '9', '4', '5', '9']), .str (String.ofList ['2', '4', '4', '7', '9', '8', '8', '6', '6', '1', '4', '6', '2', '8', '4', '6', '9', '7', '6', '0', '7']), .str (String.ofList ['3', '6', '0', '7', '3', '2', '4', '6', '7', '2', '4', '0', '2', '5', '8', '7', '2', '6', '2', '7', '9']), .str (String.ofList ['2', '9', '6', '7', '9', '4', '3', '8', '7', '2', '5', '5', '7', '2', '7', '0', '5', '0', '7', '7', '5']), .str (String.ofList ['3', '7', '6', '6', '6', '4', '9', '8', '0', '6', '2', '4', '0', '0', '1', '3', '3', '6', '7', '9', '5']), .str (String.ofList ['1', '2', '0', '6', '8', '8', '8', '8', '7', '7', '5', '0', '6', '8', '3', '8', '0', '1', '1', '4', '1', '1']), .str (String.ofList ['5', '5', '9', '7', '2', '0', '4', '7', '6', '5', '7', '0', '9', '0', '4', '1', '0', '0', '7', '2', '2']), .str (String.ofList ['7', '6', '1', '2', '2', '4', '1', '9', '1', '8', '2', '0', '3', '7', '6', '9', '5', '3', '8', '2', '0']), .str (String.ofList ['2', '6', '3', '5', '3', '1', '5', '9', '6', '3', '8', '0', '1', '5', '7', '9', '8', '0', '7', '5', '7'])]), (String.ofList ['o', 'l', 'd', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6'], .str (String.ofList ['2', '2', '6', '9', '0', '7', '7', '3', '4', '8', '0', '6', '5', '3', '3', '5', '4', '8'])), (String.ofList ['n', 'e', 'w', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6'], .str (String.ofList ['2', '2', '7', '8', '2', '6', '1', '7', '9', '3', '2', '6', '5', '7', '2', '1', '7', '0']))]) :: (acc)

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_chunk_050_before_generic"
  err.flush

theorem array_moment_records_chunk_050 (fuel : Nat) (tail : List Char) (acc : List SourceJson) :
    SourceJson.array (fuel + 100)
      (SourceJson.white (momentRecordsChunk050Chars ++ tail)) acc =
      SourceJson.array (fuel + 99) (SourceJson.white tail) (momentRecordsChunk050Push acc) := by rfl

noncomputable def momentRecordsAcc051 : List SourceJson := momentRecordsChunk050Push momentRecordsAcc050

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_chunk_050_generic_complete"
  err.flush

noncomputable def momentRecordsChunk051Chars : List Char := ['\r', '\n', ' ', ' ', ' ', ' ', '{', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 's', 'i', 'm', 'p', 'l', 'e', 'x', '_', 'i', 'd', '"', ':', ' ', '5', '1', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'l', 'o', 'g', '_', 'g', 'a', 'p', '_', 'f', 'a', 'c', 't', 'o', 'r', '_', 'f', 'l', 'o', 'o', 'r', 's', '_', 'Q', '8', '0', '"', ':', ' ', '[', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '2', '7', '5', '9', '4', '4', '3', '3', '5', '1', '1', '6', '6', '5', '4', '8', '9', '7', '9', '9', '8', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '3', '0', '2', '0', '6', '5', '3', '4', '4', '8', '0', '5', '8', '0', '4', '4', '2', '8', '2', '0', '8', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '3', '3', '8', '9', '7', '2', '3', '1', '7', '0', '3', '1', '0', '8', '0', '1', '6', '6', '4', '0', '4', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '1', '9', '1', '6', '2', '7', '1', '4', '9', '4', '9', '7', '6', '8', '8', '3', '6', '0', '2', '0', '0', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '1', '5', '8', '2', '5', '2', '5', '9', '3', '0', '0', '8', '4', '1', '6', '5', '9', '7', '0', '7', '4', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '1', '8', '9', '9', '1', '8', '2', '8', '8', '0', '9', '7', '3', '4', '3', '6', '4', '9', '9', '1', '7', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '3', '6', '1', '4', '2', '2', '2', '5', '8', '7', '6', '2', '0', '5', '8', '1', '6', '6', '3', '0', '6', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '3', '1', '7', '8', '0', '3', '2', '7', '3', '0', '2', '7', '8', '1', '4', '8', '9', '0', '1', '9', '9', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '4', '9', '1', '6', '3', '7', '0', '8', '0', '6', '9', '1', '9', '9', '5', '5', '2', '2', '3', '0', '7', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '"', '1', '6', '0', '6', '1', '8', '1', '7', '9', '5', '1', '5', '6', '2', '3', '1', '0', '9', '1', '0', '6', '"', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', ']', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'o', 'l', 'd', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6', '"', ':', ' ', '"', '1', '1', '4', '4', '1', '8', '6', '5', '6', '1', '6', '2', '"', ',', '\r', '\n', ' ', ' ', ' ', ' ', ' ', ' ', '"', 'n', 'e', 'w', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6', '"', ':', ' ', '"', '1', '1', '4', '6', '8', '2', '8', '5', '5', '3', '6', '9', '"', '\r', '\n', ' ', ' ', ' ', ' ', '}', ',']
noncomputable def momentRecordsChunk051Push (acc : List SourceJson) : List SourceJson :=
  (.obj [(String.ofList ['s', 'i', 'm', 'p', 'l', 'e', 'x', '_', 'i', 'd'], .number (String.ofList ['5', '1'])), (String.ofList ['l', 'o', 'g', '_', 'g', 'a', 'p', '_', 'f', 'a', 'c', 't', 'o', 'r', '_', 'f', 'l', 'o', 'o', 'r', 's', '_', 'Q', '8', '0'], .arr [.str (String.ofList ['2', '7', '5', '9', '4', '4', '3', '3', '5', '1', '1', '6', '6', '5', '4', '8', '9', '7', '9', '9', '8']), .str (String.ofList ['3', '0', '2', '0', '6', '5', '3', '4', '4', '8', '0', '5', '8', '0', '4', '4', '2', '8', '2', '0', '8']), .str (String.ofList ['3', '3', '8', '9', '7', '2', '3', '1', '7', '0', '3', '1', '0', '8', '0', '1', '6', '6', '4', '0', '4']), .str (String.ofList ['1', '9', '1', '6', '2', '7', '1', '4', '9', '4', '9', '7', '6', '8', '8', '3', '6', '0', '2', '0', '0']), .str (String.ofList ['1', '5', '8', '2', '5', '2', '5', '9', '3', '0', '0', '8', '4', '1', '6', '5', '9', '7', '0', '7', '4']), .str (String.ofList ['1', '8', '9', '9', '1', '8', '2', '8', '8', '0', '9', '7', '3', '4', '3', '6', '4', '9', '9', '1', '7']), .str (String.ofList ['3', '6', '1', '4', '2', '2', '2', '5', '8', '7', '6', '2', '0', '5', '8', '1', '6', '6', '3', '0', '6']), .str (String.ofList ['3', '1', '7', '8', '0', '3', '2', '7', '3', '0', '2', '7', '8', '1', '4', '8', '9', '0', '1', '9', '9']), .str (String.ofList ['4', '9', '1', '6', '3', '7', '0', '8', '0', '6', '9', '1', '9', '9', '5', '5', '2', '2', '3', '0', '7']), .str (String.ofList ['1', '6', '0', '6', '1', '8', '1', '7', '9', '5', '1', '5', '6', '2', '3', '1', '0', '9', '1', '0', '6'])]), (String.ofList ['o', 'l', 'd', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6'], .str (String.ofList ['1', '1', '4', '4', '1', '8', '6', '5', '6', '1', '6', '2'])), (String.ofList ['n', 'e', 'w', '_', 'f', 'l', 'o', 'o', 'r', '_', 'Q', '9', '6'], .str (String.ofList ['1', '1', '4', '6', '8', '2', '8', '5', '5', '3', '6', '9']))]) :: (acc)

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_chunk_051_before_generic"
  err.flush

theorem array_moment_records_chunk_051 (fuel : Nat) (tail : List Char) (acc : List SourceJson) :
    SourceJson.array (fuel + 99)
      (SourceJson.white (momentRecordsChunk051Chars ++ tail)) acc =
      SourceJson.array (fuel + 98) (SourceJson.white tail) (momentRecordsChunk051Push acc) := by rfl

noncomputable def momentRecordsAcc052 : List SourceJson := momentRecordsChunk051Push momentRecordsAcc051

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_chunk_051_generic_complete"
  err.flush

noncomputable def momentRecordsBlock012Chars : List Char := momentRecordsChunk048Chars ++ momentRecordsChunk049Chars ++ momentRecordsChunk050Chars ++ momentRecordsChunk051Chars
noncomputable def momentRecordsBlock012Push (acc : List SourceJson) : List SourceJson := momentRecordsChunk051Push (momentRecordsChunk050Push (momentRecordsChunk049Push (momentRecordsChunk048Push (acc))))

theorem array_moment_records_block_012 (fuel : Nat) (tail : List Char) (acc : List SourceJson) :
    SourceJson.array (fuel + 102)
      (SourceJson.white (momentRecordsBlock012Chars ++ tail)) acc =
      SourceJson.array (fuel + 98) (SourceJson.white tail) (momentRecordsBlock012Push acc) := by
  have hinput : momentRecordsBlock012Chars ++ tail = momentRecordsChunk048Chars ++ (momentRecordsChunk049Chars ++ (momentRecordsChunk050Chars ++ (momentRecordsChunk051Chars ++ (tail)))) := by
    simp only [momentRecordsBlock012Chars, List.append_assoc]
  calc
    SourceJson.array (fuel + 102) (SourceJson.white (momentRecordsBlock012Chars ++ tail)) acc =
        SourceJson.array (fuel + 102) (SourceJson.white (momentRecordsChunk048Chars ++ (momentRecordsChunk049Chars ++ (momentRecordsChunk050Chars ++ (momentRecordsChunk051Chars ++ (tail)))))) acc :=
      congrArg (fun s => SourceJson.array (fuel + 102) (SourceJson.white s) acc) hinput
    _ = SourceJson.array (fuel + 101) (SourceJson.white (momentRecordsChunk049Chars ++ (momentRecordsChunk050Chars ++ (momentRecordsChunk051Chars ++ (tail))))) (momentRecordsChunk048Push (acc)) := array_moment_records_chunk_048 fuel (momentRecordsChunk049Chars ++ (momentRecordsChunk050Chars ++ (momentRecordsChunk051Chars ++ (tail)))) (acc)
    _ = SourceJson.array (fuel + 100) (SourceJson.white (momentRecordsChunk050Chars ++ (momentRecordsChunk051Chars ++ (tail)))) (momentRecordsChunk049Push (momentRecordsChunk048Push (acc))) := array_moment_records_chunk_049 fuel (momentRecordsChunk050Chars ++ (momentRecordsChunk051Chars ++ (tail))) (momentRecordsChunk048Push (acc))
    _ = SourceJson.array (fuel + 99) (SourceJson.white (momentRecordsChunk051Chars ++ (tail))) (momentRecordsChunk050Push (momentRecordsChunk049Push (momentRecordsChunk048Push (acc)))) := array_moment_records_chunk_050 fuel (momentRecordsChunk051Chars ++ (tail)) (momentRecordsChunk049Push (momentRecordsChunk048Push (acc)))
    _ = SourceJson.array (fuel + 98) (SourceJson.white tail) (momentRecordsBlock012Push acc) := array_moment_records_chunk_051 fuel (tail) (momentRecordsChunk050Push (momentRecordsChunk049Push (momentRecordsChunk048Push (acc))))

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_block_012_before_raw_binding"
  err.flush

theorem moment_records_block_012_prefix :
    (momentRest06 24966).take 2056 = momentRecordsBlock012Chars := by rfl

theorem moment_records_block_012_split :
    momentRest06 24966 = momentRecordsBlock012Chars ++ momentRest06 27022 := by
  calc
    momentRest06 24966 =
        (momentRest06 24966).take 2056 ++ (momentRest06 24966).drop 2056 :=
      (List.take_append_drop 2056 (momentRest06 24966)).symm
    _ = momentRecordsBlock012Chars ++ (momentRest06 24966).drop 2056 :=
      congrArg (fun p => p ++ (momentRest06 24966).drop 2056) moment_records_block_012_prefix
    _ = momentRecordsBlock012Chars ++ momentRest06 27022 :=
      congrArg (fun rest => momentRecordsBlock012Chars ++ rest) (momentRest06_drop 24966 2056)

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_block_012_after_raw_binding"
  err.flush

theorem array_moment_records_original_block_012 (fuel : Nat) (acc : List SourceJson) :
    SourceJson.array (fuel + 102)
      (SourceJson.white (momentRest06 24966)) acc =
      SourceJson.array (fuel + 98) (SourceJson.white (momentRest06 27022)) (momentRecordsBlock012Push acc) := by
  exact (congrArg (fun s => SourceJson.array (fuel + 102) (SourceJson.white s) acc)
      moment_records_block_012_split).trans (array_moment_records_block_012 fuel (momentRest06 27022) acc)

theorem moment_records_through_block_012 (fuel : Nat) :
    SourceJson.array (fuel + 150)
      (SourceJson.white (momentRest06 364)) [] =
      SourceJson.array (fuel + 98) (SourceJson.white (momentRest06 27022)) momentRecordsAcc052 := by
  exact (moment_records_through_block_011 fuel).trans (array_moment_records_original_block_012 fuel momentRecordsAcc048)

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 records_block_012_complete"
  err.flush

#print axioms array_moment_records_chunk_048
#print axioms array_moment_records_chunk_049
#print axioms array_moment_records_chunk_050
#print axioms array_moment_records_chunk_051
#print axioms array_moment_records_block_012
#print axioms moment_records_block_012_prefix
#print axioms moment_records_block_012_split
#print axioms array_moment_records_original_block_012
#print axioms moment_records_through_block_012

end ImbalancedChen.P2OriginalSaving19Moment06Parsing
