/- SOURCE_CANDIDATE: original Cell06 source only. No Lean compilation,
independent kernel replay, full-owned audit or formal acceptance is claimed. -/

import ImbalancedChen.P2OriginalSaving19Moment06DecodedBlock012
import ImbalancedChen.P2OriginalSaving19Moment06RecordsBlock013

/-! Original typed moment records 52 through 55; each concrete value is checked by original decodeMomentRecord.
Candidate quotations preserve exact original raw bytes. The Lean equations bind
them to the production-compatible packed input and run the unchanged reader.
This local input resolves inside this private project, not the P1 filesystem. -/
namespace ImbalancedChen.P2OriginalSaving19Moment06Decoding
set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false
open ImbalancedChen.P2OriginalSaving19Archive

open ImbalancedChen.P2OriginalSaving19Moment06Parsing

noncomputable def momentJsonRecord052 : SourceJson :=
  (momentRecordsChunk052Push []).head (List.cons_ne_nil _ _)

theorem moment_record_052_push_eq (acc : List SourceJson) :
    momentRecordsChunk052Push acc = momentJsonRecord052 :: acc := by rfl

noncomputable def momentTypedRecord052 : MomentRecord :=
  { simplexId := 52,
    factorFloorsQ80 := #[(296743848422413769611 : Int), (298184603266038594691 : Int), (311669789163475744869 : Int), (252816662476376161038 : Int), (213842140140340737487 : Int), (208703028391190404866 : Int), (410318973615890891593 : Int), (369822192297979134358 : Int), (554312407054255060736 : Int), (159458133955652695298 : Int)],
    oldFloorQ96 := (761434262887 : Int),
    newFloorQ96 := (763374047877 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_052_before_decode"
  err.flush

theorem decode_moment_record_052 :
    decodeMomentRecord momentJsonRecord052 = .ok momentTypedRecord052 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_052_decoded"
  err.flush

noncomputable def momentJsonRecord053 : SourceJson :=
  (momentRecordsChunk053Push []).head (List.cons_ne_nil _ _)

theorem moment_record_053_push_eq (acc : List SourceJson) :
    momentRecordsChunk053Push acc = momentJsonRecord053 :: acc := by rfl

noncomputable def momentTypedRecord053 : MomentRecord :=
  { simplexId := 53,
    factorFloorsQ80 := #[(311315775482702628010 : Int), (297709906945859114615 : Int), (287345232844843116533 : Int), (317704311292181647428 : Int), (272374793895020648207 : Int), (304089080527975128323 : Int), (1358125939266899781452 : Int), (390595212376629566533 : Int), (552658492987508707265 : Int), (159507972742379661916 : Int)],
    oldFloorQ96 := (5999319683104 : Int),
    newFloorQ96 := (6020454617947 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_053_before_decode"
  err.flush

theorem decode_moment_record_053 :
    decodeMomentRecord momentJsonRecord053 = .ok momentTypedRecord053 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_053_decoded"
  err.flush

noncomputable def momentJsonRecord054 : SourceJson :=
  (momentRecordsChunk054Push []).head (List.cons_ne_nil _ _)

theorem moment_record_054_push_eq (acc : List SourceJson) :
    momentRecordsChunk054Push acc = momentJsonRecord054 :: acc := by rfl

noncomputable def momentTypedRecord054 : MomentRecord :=
  { simplexId := 54,
    factorFloorsQ80 := #[(358721603404264185155 : Int), (355774998453375070225 : Int), (271889449909430648522 : Int), (351364533321543490771 : Int), (300846412080075678099 : Int), (416643980195608035934 : Int), (1465994780306520467649 : Int), (663724151122683713853 : Int), (863313042024396182299 : Int), (249393727836402931445 : Int)],
    oldFloorQ96 := (29390809563399 : Int),
    newFloorQ96 := (29519886437117 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_054_before_decode"
  err.flush

theorem decode_moment_record_054 :
    decodeMomentRecord momentJsonRecord054 = .ok momentTypedRecord054 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_054_decoded"
  err.flush

noncomputable def momentJsonRecord055 : SourceJson :=
  (momentRecordsChunk055Push []).head (List.cons_ne_nil _ _)

theorem moment_record_055_push_eq (acc : List SourceJson) :
    momentRecordsChunk055Push acc = momentJsonRecord055 :: acc := by rfl

noncomputable def momentTypedRecord055 : MomentRecord :=
  { simplexId := 55,
    factorFloorsQ80 := #[(135569327221097034610 : Int), (224576999476985976638 : Int), (320598366808593756201 : Int), (159656749677654487767 : Int), (132887477154763352746 : Int), (122724696302439084060 : Int), (672153790949091472630 : Int), (596333710001930635596 : Int), (754688138047131507950 : Int), (142892675994600931068 : Int)],
    oldFloorQ96 := (585020331442 : Int),
    newFloorQ96 := (586601041577 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_055_before_decode"
  err.flush

theorem decode_moment_record_055 :
    decodeMomentRecord momentJsonRecord055 = .ok momentTypedRecord055 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_record_055_decoded"
  err.flush

noncomputable def momentJsonRecordsBlock013 : List SourceJson := [momentJsonRecord052, momentJsonRecord053, momentJsonRecord054, momentJsonRecord055]
noncomputable def momentTypedRecordsBlock013 : List MomentRecord := [momentTypedRecord052, momentTypedRecord053, momentTypedRecord054, momentTypedRecord055]

theorem moment_records_block_013_push_eq (acc : List SourceJson) :
    momentRecordsBlock013Push acc = [momentJsonRecord055, momentJsonRecord054, momentJsonRecord053, momentJsonRecord052] ++ acc := by rfl

theorem moment_records_block_013_reverse (acc : List SourceJson) :
    (momentRecordsBlock013Push acc).reverse = acc.reverse ++ momentJsonRecordsBlock013 := by
  rw [moment_records_block_013_push_eq, List.reverse_append]
  rfl

theorem decode_moment_records_block_013 :
    momentJsonRecordsBlock013.mapM decodeMomentRecord = .ok momentTypedRecordsBlock013 := by
  simp only [momentJsonRecordsBlock013, momentTypedRecordsBlock013, List.mapM_cons, List.mapM_nil,
    decode_moment_record_052, decode_moment_record_053, decode_moment_record_054, decode_moment_record_055]
  rfl

noncomputable def momentTypedRowsThroughBlock013 : List MomentRecord := momentTypedRowsThroughBlock012 ++ momentTypedRecordsBlock013

theorem decode_moment_records_through_block_013 :
    momentRecordsAcc056.reverse.mapM decodeMomentRecord = .ok momentTypedRowsThroughBlock013 := by
  change (momentRecordsBlock013Push momentRecordsAcc052).reverse.mapM decodeMomentRecord = _
  rw [moment_records_block_013_reverse]
  rw [List.mapM_append, decode_moment_records_through_block_012, decode_moment_records_block_013]
  rfl

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_MOMENT06 typed_block_013_complete"
  err.flush

#print axioms moment_record_052_push_eq
#print axioms decode_moment_record_052
#print axioms moment_record_053_push_eq
#print axioms decode_moment_record_053
#print axioms moment_record_054_push_eq
#print axioms decode_moment_record_054
#print axioms moment_record_055_push_eq
#print axioms decode_moment_record_055
#print axioms moment_records_block_013_push_eq
#print axioms moment_records_block_013_reverse
#print axioms decode_moment_records_block_013
#print axioms decode_moment_records_through_block_013

end ImbalancedChen.P2OriginalSaving19Moment06Decoding
