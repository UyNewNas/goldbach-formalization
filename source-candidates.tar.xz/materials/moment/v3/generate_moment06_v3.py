#!/usr/bin/env python3
"""Render isolated original Moment06 source candidates; never execute Lean.

Archived renderer function bodies are loaded through AST selection only. Their
old module initializers, save implementations, imports and main guards do not
run. All writes are exclusive creates below this script's isolated root.
"""
from __future__ import annotations

import argparse
import ast
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
import re
import sys
import tarfile
import types

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
ALLOWED_ROOT = Path('/workspace/p26-cell06-source-candidate-20261128/moment/v3')
REPO = Path('/workspace/p26-proof-continuation-20261127')
RECOVERY = Path('/workspace/p26-next-cell06-recovery-20261128')
ARCHIVE = REPO / 'docs/verification/20261125-p26/moment01-parse-decode-shape-local-evidence.tar.xz'
ARCHIVE_SHA = 'd04a4a14f6544961511192ccf4ec4805ca65c040fccba55a0d9dd1ce2a1f2395'
MEMBER_PINS = {
    'raw_planner.py': (7839, '49c74fc7dc61c64a2519fb3fcce7ec571d097530840e0806d6af491f27ac8e18'),
    'generate_moment.py': (16810, '79bcd047c68d7f19e3165b4ca909828740eef37405bd15df107b0ab297fefb63'),
    'generate_typed.py': (6036, '7604c93c32f8f62ddc5a3f8165f250f76e501a8d116075076700d0bc31db4dd0'),
    'generate_complete.py': (6862, 'b924db3cb33631448e8e5fc7337c4c463a7bc8b818058c4ab7e4bec82a1b7caa'),
    'generate_typed_metadata.py': (3610, 'c20d3740d7a436cfa17102b640239f2429c71f367202013c6c299d0d34788a5c'),
    'generate_typed_glue.py': (1285, 'fb131ad1115d352e229c24cc18580acc8be6a1deab184d9aa4db71c4ace7953a'),
}
PREFIX = 'P2OriginalSaving19'
SOURCE_CANDIDATE = ('/- SOURCE_CANDIDATE: original Cell06 source only. No Lean compilation,\n'
                    'independent kernel replay, full-owned audit or formal acceptance is claimed. -/\n\n')
FORBIDDEN = re.compile(r'\b(?:sorry|admit|native_decide|unsafe)\b|(?m:^\s*axiom\b)')


@dataclass(frozen=True)
class Config:
    cell: int = 6
    rows: int = 113
    byte_count: int = 58376
    sha256: str = '7654ebb59737bd765340a9edbd3984a4a72fe0f5b4cd9bf8f42266d7a7e724e9'
    rows_per_block: int = 4

    @property
    def fixture_name(self):
        return f'eighth-third-moment-refinement-20261009-a23-low-{self.cell:02d}.witness.json'

    @property
    def witness_name(self):
        return f'eighth-third-minorant-extension-20261009-a23-s23_low-{self.cell:02d}-cell.witness.json'

    @property
    def tag(self):
        return f'Moment{self.cell:02d}'

    @property
    def blocks(self):
        return (self.rows + self.rows_per_block - 1) // self.rows_per_block


def digest(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def pin(path):
    path = Path(path)
    assert path.is_file() and path.resolve() == path, ('Missing or symlinked input', str(path))
    return {'path': str(path), **digest(path.read_bytes())}


def exclusive_write(path, data):
    path = Path(path)
    assert ROOT == ALLOWED_ROOT and ROOT.resolve() == ROOT
    assert path.is_absolute() and '..' not in path.parts and path.is_relative_to(ROOT)
    ancestor = path.parent
    while ancestor != ROOT.parent:
        assert not ancestor.is_symlink(), ('Symlinked write ancestor', str(ancestor))
        ancestor = ancestor.parent
    path.parent.mkdir(parents=True, exist_ok=True)
    assert not path.is_symlink()
    raw = data.encode('utf-8') if isinstance(data, str) else data
    with path.open('xb') as stream:
        stream.write(raw)
    assert path.read_bytes() == raw
    return pin(path)


def exact_replace(text, old, new, count=None):
    actual = text.count(old)
    assert actual > 0 and (count is None or actual == count), (old, actual, count)
    return text.replace(old, new)


def reword(text, cfg):
    for old, new in [('ArchiveMomentData01', f'ArchiveMomentData{cfg.cell:02d}'),
                     ('Moment01', cfg.tag), ('MOMENT01', cfg.tag.upper()),
                     ('moment01', cfg.tag.lower()), ('cell01', f'cell{cfg.cell:02d}'),
                     ('momentPacked01', f'momentPacked{cfg.cell:02d}'),
                     ('momentChars01', f'momentChars{cfg.cell:02d}'),
                     ('momentRest01', f'momentRest{cfg.cell:02d}'),
                     ('momentConcrete01', f'momentConcrete{cfg.cell:02d}')]:
        text = text.replace(old, new)
    return text


def numeric_rewrite(text, replacements):
    return re.sub(r'\b\d+\b', lambda m: str(replacements.get(int(m[0]), int(m[0]))), text)


def load_archive():
    assert digest(ARCHIVE.read_bytes())['sha256'] == ARCHIVE_SHA
    members = {}
    with tarfile.open(ARCHIVE) as stream:
        for name, (size, sha) in MEMBER_PINS.items():
            info = stream.getmember(name)
            assert info.isfile() and info.name == name
            raw = stream.extractfile(info).read()
            assert digest(raw) == {'bytes': size, 'sha256': sha}
            members[name] = raw.decode('utf-8')
    return members


def load_function_module(name, source, bindings, exclude=()):
    """Compile archived function definitions only, never an old initializer/main."""
    tree = ast.parse(source)
    selected = [node for node in tree.body
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name not in exclude]
    assert selected and not any(node.name == 'main' for node in selected)
    module = types.ModuleType(name)
    module.__dict__.update(bindings)
    exec(compile(ast.fix_missing_locations(ast.Module(body=selected, type_ignores=[])),
                 f'archived-functions:{name}', 'exec'), module.__dict__)
    return module


def render_archived_body(name, source, bindings):
    """Wrap a top-level pure renderer as a fresh explicit function.

    Imported modules and print calls are omitted. The only effectful callback
    retained is the controlled in-memory save callback supplied by this adapter.
    """
    tree = ast.parse(source)
    body = []
    for node in tree.body:
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            continue
        if isinstance(node, ast.Expr) and isinstance(node.value, ast.Constant) and isinstance(node.value.value, str):
            continue
        if isinstance(node, ast.Expr) and isinstance(node.value, ast.Call) and isinstance(node.value.func, ast.Name) and node.value.func.id == 'print':
            continue
        assert not isinstance(node, (ast.If, ast.With, ast.FunctionDef, ast.ClassDef))
        body.append(node)
    wrapper = ast.FunctionDef(name='render', args=ast.arguments(posonlyargs=[], args=[], kwonlyargs=[], kw_defaults=[], defaults=[]),
                              body=body, decorator_list=[])
    namespace = dict(bindings)
    exec(compile(ast.fix_missing_locations(ast.Module(body=[wrapper], type_ignores=[])),
                 f'adapted-renderer:{name}', 'exec'), namespace)
    namespace['render']()


def load_plan(cfg, members):
    origin = Path('/workspace/goldbach-research') / cfg.fixture_name
    raw = origin.read_bytes()
    assert digest(raw) == {'bytes': cfg.byte_count, 'sha256': cfg.sha256}
    assert raw.isascii() and raw.count(b'\r\n') == raw.count(b'\n') and raw.endswith(b'\r\n')
    base = types.ModuleType('cell06_candidate_raw_planner')
    sys.modules[base.__name__] = base
    exec(compile(members['raw_planner.py'], 'archived:raw_planner.py', 'exec'), base.__dict__)
    plan = base.RawPlanner(raw).value(0)
    records = plan.fields[-1].value
    assert [f.key.scalar for f in plan.fields] == [
        'cell_id', 'source_witness', 'dimension', 'vertices_per_simplex', 'factor_count',
        'log_degree', 'exp_degree', 'log_floor_denominator', 'final_floor_denominator', 'records']
    assert plan.kind == 'obj' and plan.fields[-1].separator == '}'
    assert raw[plan.end:] == b'\r\n' and len(records.children) == cfg.rows
    assert (plan.need, records.need, plan.end, records.start, records.end) == (162, 151, 58374, 363, 58371)
    parsed = json.loads(raw)
    assert {k: v for k, v in parsed.items() if k != 'records'} == {
        'cell_id': cfg.cell, 'source_witness': cfg.witness_name, 'dimension': 8,
        'vertices_per_simplex': 9, 'factor_count': 10, 'log_degree': 6, 'exp_degree': 3,
        'log_floor_denominator': str(2**80), 'final_floor_denominator': str(2**96)}
    for i, row in enumerate(parsed['records']):
        assert list(row) == ['simplex_id', 'log_gap_factor_floors_Q80', 'old_floor_Q96', 'new_floor_Q96']
        assert row['simplex_id'] == i and len(row['log_gap_factor_floors_Q80']) == 10
        assert all(re.fullmatch(r'-?(0|[1-9][0-9]*)', s)
                   for s in [*row['log_gap_factor_floors_Q80'], row['old_floor_Q96'], row['new_floor_Q96']])
    return origin, raw, parsed, base, plan, records


def first_header_command(source):
    """Skip whitespace/ordinary comments only, preserving actual doc commands."""
    i = 0
    while i < len(source):
        if source[i].isspace():
            i += 1
            continue
        if source.startswith('--', i):
            end = source.find('\n', i)
            i = len(source) if end < 0 else end + 1
            continue
        if source.startswith('/-', i) and not source.startswith(('/-!', '/--'), i):
            depth = 1
            i += 2
            while depth:
                assert i < len(source), 'Unclosed ordinary comment'
                if source.startswith('/-', i):
                    depth += 1
                    i += 2
                elif source.startswith('-/', i):
                    depth -= 1
                    i += 2
                else:
                    i += 1
            continue
        token = re.match(r'[A-Za-z_][A-Za-z0-9_]*', source[i:])
        return token[0] if token else source[i:i+3]
    return None


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check-only', action='store_true', help='Validate existing exact outputs without writing.')
    args = parser.parse_args()
    assert sys.dont_write_bytecode and ROOT == ALLOWED_ROOT
    cfg = Config()
    members = load_archive()
    origin, raw, parsed, base, plan, records = load_plan(cfg, members)
    initial_inputs = {str(origin): pin(origin), str(ARCHIVE): pin(ARCHIVE), str(Path(__file__).resolve()): pin(Path(__file__).resolve())}
    source_templates = {}

    def template(short):
        path = REPO / 'ImbalancedChen' / (PREFIX + short + '.lean')
        source_templates[str(path)] = pin(path)
        return path.read_text()

    recovery_report_path = RECOVERY / 'RESTORE_REPORT.json'
    recovery_report = json.loads(recovery_report_path.read_text())
    assert recovery_report['formal_acceptance'] is False
    data_module = f'ImbalancedChen.{PREFIX}ArchiveMomentData{cfg.cell:02d}'
    restored_source = next(r for r in recovery_report['restored'] if r['module'] == data_module and r['kind'] == 'source')
    restored_object = next(r for r in recovery_report['restored'] if r['module'] == data_module and r['kind'] == 'object')
    assert pin(restored_source['path']) == {k: restored_source[k] for k in ('path', 'bytes', 'sha256')}
    assert pin(restored_object['path']) == {k: restored_object[k] for k in ('path', 'bytes', 'sha256')}
    data_raw = Path(restored_source['path']).read_bytes()
    assert data_raw == (REPO / (data_module.replace('.', '/') + '.lean')).read_bytes()
    assert cfg.fixture_name.encode() in data_raw
    initial_inputs[str(recovery_report_path)] = pin(recovery_report_path)
    initial_inputs[restored_source['path']] = pin(restored_source['path'])
    initial_inputs[restored_object['path']] = pin(restored_object['path'])

    sources, details = {}, {}

    def save(short, text, scope, obligations):
        short = reword(short, cfg)
        text = reword(text.replace('\ndef ', '\nnoncomputable def '), cfg)
        if short == PREFIX + cfg.tag + 'RecordsBlock028':
            text = exact_replace(text, '    simp only [momentRecordsBlock028Chars, List.append_assoc]', '    rfl', count=1)
        text = SOURCE_CANDIDATE + text
        module = 'ImbalancedChen.' + short
        assert module not in sources and not FORBIDDEN.search(text)
        sources[module] = text.encode('utf-8')
        obligations = dict(obligations)
        if 'last_array_value_proved' in obligations:
            obligations['terminal_array_equation_present_as_candidate'] = obligations.pop('last_array_value_proved')
        details[module] = {'kind': 'generated_source_candidate', 'scope': scope,
                           'planned_obligations': obligations, 'formal_acceptance': False,
                           'normal_kernel_owned_passed': False}
        return {'module': module, 'source': digest(sources[module]), 'planned_obligations': obligations}

    g = load_function_module('cell06_candidate_moment_renderer', members['generate_moment.py'],
        {'Path': Path, 'json': json, 're': re, 'base': base}, exclude=('save', 'write_new', 'fp', 'main'))
    g.ROOT, g.PROJECT = ROOT, ROOT / 'project'
    g.NS = 'ImbalancedChen.' + PREFIX + cfg.tag + 'Parsing'
    g.FIXTURE, g.RAW, g.PLAN, g.RECORDS = origin, raw, plan, records
    g.save = save
    old_chunks_for = g.chunks_for
    g.chunks_for = lambda node, max_items=1, max_bytes=768: old_chunks_for(node, max_items=1, max_bytes=max_bytes)
    chunks = g.chunks_for(records)
    assert len(chunks) == cfg.rows and all(c['first'] == i and c['after'] == i + 1 for i, c in enumerate(chunks))

    sources[data_module] = data_raw
    details[data_module] = {'kind': 'exact_restored_source_copy', 'scope': 'Unmodified old Data06 source, object already recovered separately.',
                            'original_source': restored_source, 'restored_object': restored_object,
                            'normal_recompilation_allowed': False, 'formal_acceptance': False}
    input_source = reword(template('Moment01Input'), cfg)
    input_source = numeric_rewrite(input_source, {75094: len(raw)})
    save(PREFIX + cfg.tag + 'Input', input_source, 'Original packed input count and list/drop interfaces.',
         {'complete_input_bytes': len(raw), 'original_input_sha256': cfg.sha256})
    g.metadata()
    for i in range(cfg.blocks):
        g.records_block(i, block_chunks=cfg.rows_per_block)

    parse_map = {348: plan.fields[-1].prefix_start, 363: records.start,
                 75089: records.end, 75092: plan.end, 75094: len(raw),
                 193: plan.need, 183: plan.need - 10, 182: records.need,
                 74902: len(raw) + 1 - plan.need, 35: cfg.blocks - 1}
    render_archived_body('generate_complete.py', numeric_rewrite(members['generate_complete.py'], parse_map), {'g': g})

    typed_source = exact_replace(members['generate_typed.py'],
        '    assert len(ids)==4', '    assert 1 <= len(ids) <= 4', count=1)
    t = load_function_module('cell06_candidate_typed_renderer', typed_source,
        {'g': g, 'json': json, 're': re}, exclude=('save', 'main'))
    t.NS = 'ImbalancedChen.' + PREFIX + cfg.tag + 'Decoding'
    t.save = lambda short, source, obligations: save(short, source, 'Original typed record-list candidate.', obligations)
    for i in range(cfg.blocks):
        t.block(i)

    metadata_source = exact_replace(members['generate_typed_metadata.py'],
        '    parse_moment_metadata_logDenominator, parse_moment_metadata_finalDenominator,\n'
        '    get_moment_records_field, SourceJson.getArr?, pure_bind]',
        '    get_moment_records_field, SourceJson.getArr?]', count=1)
    render_archived_body('generate_typed_metadata.py', metadata_source, {'g': g, 't': t})
    render_archived_body('generate_typed_glue.py', members['generate_typed_glue.py'], {'g': g, 't': t})

    decoded = template('Moment01Decoded')
    decoded = exact_replace(decoded, 'Block035', f'Block{cfg.blocks - 1:03d}')
    decoded = exact_replace(decoded, 'block_035', f'block_{cfg.blocks - 1:03d}')
    decoded = exact_replace(decoded, 'Acc144', f'Acc{cfg.rows:03d}')
    save(PREFIX + cfg.tag + 'Decoded', decoded, 'Whole original parse followed by unchanged decodeMoments.',
         {'record_count': cfg.rows, 'final_block': cfg.blocks - 1, 'parse_decode_helper_reused_unchanged': True})
    shape = template('Moment01Shape')
    shape = exact_replace(shape, 'momentConcrete01.cellId = 1', f'momentConcrete01.cellId = {cfg.cell}', count=1)
    shape = exact_replace(shape, 'low-01-cell.witness.json', f'low-{cfg.cell:02d}-cell.witness.json', count=1)
    shape = re.sub(r'\b144\b', str(cfg.rows), shape).replace('all_144_rows_complete', f'all_{cfg.rows}_rows_complete')
    save(PREFIX + cfg.tag + 'Shape', shape, 'All original metadata, record IDs, sizes and bounded lookup candidates.',
         {'record_count': cfg.rows, 'factor_slots': 10, 'log_degree': 6, 'exp_degree': 3, 'denominator_bits': [80, 96]})

    cleaned_metadata = template('Moment05DecodeMetadata')
    proof_stem = 'theorem decodeMoments_momentObjectWithRecords'
    cleaned_body = cleaned_metadata.split(proof_stem, 1)[1].split('\nrun_cmd', 1)[0]
    candidate_body = sources['ImbalancedChen.' + PREFIX + cfg.tag + 'DecodeMetadata'].decode().split(proof_stem, 1)[1].split('\nrun_cmd', 1)[0]
    assert candidate_body == cleaned_body, 'Metadata factorization must match the existing cleaned proof body.'
    validation, imports, topological, suppliers = validate_sources(cfg, raw, parsed, base, plan, chunks, sources, details)
    for path in source_templates:
        initial_inputs[path] = source_templates[path]
    for module, item in suppliers.items():
        initial_inputs[item['source']['path']] = item['source']
    for path, expected in initial_inputs.items():
        assert pin(path) == expected, ('Read-only input changed during rendering', path)

    fixture_copy = ROOT / 'goldbach-research' / cfg.fixture_name
    order = sorted(sources)
    file_records = []
    for module in order:
        path = ROOT / 'project' / (module.replace('.', '/') + '.lean')
        item = {'module': module, 'source': {'path': str(path), **digest(sources[module])},
                'imports': imports[module], 'namespace': re.findall(r'^namespace\s+(\S+)', sources[module].decode(), re.M),
                'named_theorems': re.findall(r'^theorem\s+(\w+)', sources[module].decode(), re.M), **details[module]}
        file_records.append(item)
    manifest = {
        'schema': 'p26_cell06_original_moment_source_candidate_v3',
        'candidate_revision': 3,
        'prior_v2_candidate': {'manifest': pin(ROOT.parent / 'MANIFEST.json'),
                               'source_pins': [item['source'] for item in json.loads((ROOT.parent / 'MANIFEST.json').read_text())['sources']],
                               'status': 'preserved_uncompiled_candidate_with_static_header_blocker'},
        'v3_change': 'Only the 65 added leading /-! module-doc markers become ordinary /- comments; restored Data06 bytes unchanged.',
        'header_fix_basis': 'Static Lean parser/header analysis supplied by parent; no Lean execution.',
        'status': 'SOURCE_CANDIDATE_HOST_CHECKED_NOT_COMPILED',
        'formal_acceptance': False, 'P2_6_complete': False, 'Lean_commands': 0,
        'normal_compilations': 0, 'kernel_replays': 0, 'full_owned_audits': 0,
        'old_normal_recompilation_allowed': False, 'host_candidate_checks_are_Lean_proofs': False,
        'generator': pin(Path(__file__).resolve()), 'archive': pin(ARCHIVE),
        'archived_generator_members': [{'archive_member': name, 'bytes': n, 'sha256': sha}
                                      for name, (n, sha) in MEMBER_PINS.items()],
        'existing_Lean_templates': list(source_templates.values()),
        'original_input': pin(origin), 'exact_input_copy': {'path': str(fixture_copy), **digest(raw)},
        'raw_input_copied_without_CRLF_normalization': True,
        'original_restored_data': {'source': restored_source, 'object': restored_object,
                                   'restore_report': pin(recovery_report_path), 'formal_acceptance': False},
        'lexical_plan': {'root_need': plan.need, 'records_need': records.need, 'root_end': plan.end,
                         'records_start': records.start, 'records_end': records.end,
                         'initial_fuel': len(raw) + 1, 'fuel_instantiation': len(raw) + 1 - plan.need,
                         'rows': cfg.rows, 'blocks': cfg.blocks,
                         'final_block_records': [112], 'untrusted_host_plan': True},
        'source_owner_count': len(sources), 'actual_new_target_count': len(sources) - 1,
        'restored_data_source_copies': 1, 'normal_compile_excluded_modules': [data_module],
        'new_compile_targets_topological': [m for m in topological if m != data_module],
        'all_candidate_sources_topological': topological,
        'existing_project_supplier_sources': suppliers,
        'existing_supplier_objects_qualified_by_this_generation': False,
        'input_and_template_pins': list(initial_inputs.values()),
        'adaptations': ['Only archived function definitions are loaded; old main/initializers/save never run.',
                        'Every source and artifact write is exclusive-create within the isolated root.',
                        'Exactly one raw row per chunk; final typed block accepts one through four rows.',
                        'Singleton parser-block append normalization uses rfl.',
                        'Metadata simp uses the existing cleaned Moment05 proof structure.',
                        'The existing abstract MomentParseDecodeBridge is reused without rewriting.'],
        'host_validation': validation, 'sources': file_records,
        'unverified': ['All generated Lean terms, parser equations and decoder equations remain uncompiled.',
                       'No independent leanchecker or full-owned inventory/axiom audit has run.',
                       'Restored Data06 object/source qualification in the current accepted context remains open.',
                       'No saved-floor arithmetic, geometric property, alias wiring or integral bound is certified.']}
    encoded_manifest = json.dumps(manifest, ensure_ascii=False, indent=2) + '\n'
    report = render_report(cfg, manifest, validation)
    if args.check_only:
        assert fixture_copy.read_bytes() == raw
        for item in file_records:
            assert pin(item['source']['path']) == item['source']
        assert (ROOT / 'MANIFEST.json').read_text() == encoded_manifest
        assert (ROOT / 'REPORT.md').read_text() == report
        assert not list(ROOT.rglob('__pycache__')) and not list(ROOT.rglob('*.olean'))
        print(json.dumps({'status': 'HOST_CHECK_ONLY_PASSED', 'sources': len(sources), 'new_targets': 65,
                          'formal_acceptance': False, 'Lean_commands': 0}))
        return
    assert not (ROOT / 'MANIFEST.json').exists(), 'Existing generation is immutable; use --check-only.'
    for item in file_records:
        exclusive_write(Path(item['source']['path']), sources[item['module']])
    exclusive_write(fixture_copy, raw)
    exclusive_write(ROOT / 'MANIFEST.json', encoded_manifest)
    exclusive_write(ROOT / 'REPORT.md', report)
    assert not list(ROOT.rglob('__pycache__')) and not list(ROOT.rglob('*.olean'))
    print(json.dumps({'status': manifest['status'], 'source_owners': 66, 'new_targets': 65,
                      'manifest': str(ROOT / 'MANIFEST.json'), 'report': str(ROOT / 'REPORT.md'),
                      'formal_acceptance': False, 'Lean_commands': 0}, ensure_ascii=False))


def validate_sources(cfg, raw, parsed, base, plan, chunks, sources, details):
    expected = {f'ImbalancedChen.{PREFIX}ArchiveMomentData06'}
    expected |= {f'ImbalancedChen.{PREFIX}Moment06{s}' for s in
                 ['Input', 'Metadata', 'Parse', 'DecodeMetadata', 'DecodeFromRows', 'Decoded', 'Shape']}
    expected |= {f'ImbalancedChen.{PREFIX}Moment06RecordsBlock{i:03d}' for i in range(cfg.blocks)}
    expected |= {f'ImbalancedChen.{PREFIX}Moment06DecodedBlock{i:03d}' for i in range(cfg.blocks)}
    assert set(sources) == expected and len(sources) == 66
    prior_path = ROOT.parent / 'MANIFEST.json'
    prior = json.loads(prior_path.read_text())
    prior_sources = {item['module']: item['source'] for item in prior['sources']}
    assert set(prior_sources) == set(sources)
    for module, source in sources.items():
        previous = prior_sources[module]
        previous_bytes = Path(previous['path']).read_bytes()
        assert digest(previous_bytes) == {k: previous[k] for k in ('bytes', 'sha256')}
        if details[module]['kind'] == 'exact_restored_source_copy':
            assert source == previous_bytes
        else:
            assert previous_bytes.startswith(b'/-! SOURCE_CANDIDATE:')
            assert source == previous_bytes.replace(b'/-! SOURCE_CANDIDATE:', b'/- SOURCE_CANDIDATE:', 1)
    assert all(first_header_command(source.decode()) == 'import' for source in sources.values())
    text = {m: s.decode('utf-8') for m, s in sources.items()}
    assert all(not FORBIDDEN.search(s) for s in text.values())
    assert all(not re.search(r'(?:ArchiveMomentData01|Moment01|MOMENT01|moment(?:Packed|Rest|Chars|Concrete)01|\bFin 144\b|Block035|Acc144)', s)
               for s in text.values())
    assert not any('Geometry06' in s for s in text.values())
    imports = {m: re.findall(r'^(?:public )?import\s+([\w.]+)', s, re.M) for m, s in text.items()}
    assert all(s.startswith(SOURCE_CANDIDATE) for m, s in text.items() if details[m]['kind'] == 'generated_source_candidate')
    char_defs = {}
    for module, source in text.items():
        for match in re.finditer(r'^noncomputable def (\w+Chars) : List Char := (\[[^\n]*\])$', source, re.M):
            name, literal = match.groups()
            assert name not in char_defs
            value = ast.literal_eval(literal)
            assert isinstance(value, list) and all(isinstance(c, str) and len(c) == 1 for c in value)
            char_defs[name] = ''.join(value).encode('ascii')
    metadata = b'{' + b''.join(char_defs[f'momentMetadataField{i:03d}Chars'] for i in range(9))
    all_rows = b''.join(char_defs[f'momentRecordsChunk{i:03d}Chars'] for i in range(cfg.rows))
    reconstructed = (metadata + char_defs['momentRecordsHeaderChars'] + char_defs['momentRecordsOpenChars']
                     + all_rows + char_defs['momentRecordsSeparatorChars'] + char_defs['momentTrailingChars'])
    assert reconstructed == raw
    for c in chunks:
        assert char_defs[f'momentRecordsChunk{c["index"]:03d}Chars'] == raw[c['start']:c['end']]
    typed_checked = []
    for i, row in enumerate(parsed['records']):
        block = i // cfg.rows_per_block
        source = text[f'ImbalancedChen.{PREFIX}Moment06DecodedBlock{block:03d}']
        record = re.search(rf'noncomputable def momentTypedRecord{i:03d} : MomentRecord :=\n(.*?\n    newFloorQ96 := [^\n]*)', source, re.S)[1]
        assert record.strip() == archived_typed_value(base, plan.fields[-1].value.children[i])
        assert f'decodeMomentRecord momentJsonRecord{i:03d} = .ok momentTypedRecord{i:03d} := by decide +kernel' in source
        parser = text[f'ImbalancedChen.{PREFIX}Moment06RecordsBlock{block:03d}']
        push = re.search(rf'noncomputable def momentRecordsChunk{i:03d}Push \(acc : List SourceJson\) : List SourceJson :=\n  ([^\n]*)', parser)[1]
        assert push == f'({base.lean_node(plan.fields[-1].value.children[i])}) :: (acc)'
        typed_checked.append(i)
    last_parser = text[f'ImbalancedChen.{PREFIX}Moment06RecordsBlock028']
    last_typed = text[f'ImbalancedChen.{PREFIX}Moment06DecodedBlock028']
    assert re.findall(r'^theorem array_moment_records_chunk_(\d+)', last_parser, re.M) == ['112']
    assert re.findall(r'^noncomputable def momentTypedRecord(\d+) :', last_typed, re.M) == ['112']
    assert '.ok (.arr ((momentRecordsChunk112Push acc).reverse), tail) := by rfl' in last_parser
    assert 'momentRecordsAcc113' in last_typed and 'momentTypedRecordsBlock028 : List MomentRecord := [momentTypedRecord112]' in last_typed
    assert 'simp only [momentRecordsBlock028Chars, List.append_assoc]' not in last_parser
    assert not any(re.search(r'moment(?:TypedRecord|JsonRecord|RecordsChunk)(?:11[3-9]|1[2-9]\d)', s) for s in text.values())
    decoder = text[f'ImbalancedChen.{PREFIX}Moment06DecodeMetadata']
    simp = decoder.split('theorem decodeMoments_momentObjectWithRecords', 1)[1]
    assert 'parse_moment_metadata_logDenominator,' not in simp
    assert 'parse_moment_metadata_finalDenominator,' not in simp and 'pure_bind' not in simp
    final = text[f'ImbalancedChen.{PREFIX}Moment06Decoded']
    assert 'P2OriginalSaving19MomentParseDecodeBridge.parse_decode_of_parse_and_decode' in final
    assert 'momentRecordsAcc113.reverse momentTypedRowsThroughBlock028' in final
    parse = text[f'ImbalancedChen.{PREFIX}Moment06Parse']
    assert 'SourceJson.value (fuel + 162) momentChars06' in parse and 'value_moment06_original 58215' in parse
    assert 'SourceJson.parse (String.ofList momentPacked06.toList) = .ok momentRootValue' in parse
    shape = text[f'ImbalancedChen.{PREFIX}Moment06Shape']
    assert 'momentConcrete06.cellId = 6' in shape and 'momentConcrete06.rows.size = 113' in shape
    assert 'momentConcrete06.logDegree = 6' in shape and 'momentConcrete06.expDegree = 3' in shape
    assert 'momentConcrete06.logDenominator = 2^80' in shape and 'momentConcrete06.finalDenominator = 2^96' in shape
    assert cfg.witness_name in shape

    suppliers, external = {}, set()
    def visit_supplier(module):
        if module in sources or module in suppliers:
            return
        path = REPO / (module.replace('.', '/') + '.lean')
        source = path.read_text()
        imps = re.findall(r'^(?:public )?import\s+([\w.]+)', source, re.M)
        suppliers[module] = {'source': pin(path), 'imports': imps,
                             'object_qualification_status': 'not_checked_by_source_generation'}
        for imported in imps:
            if imported.startswith('ImbalancedChen.'):
                visit_supplier(imported)
            else:
                external.add(imported)
    for values in imports.values():
        for imported in values:
            if imported.startswith('ImbalancedChen.'):
                visit_supplier(imported)
            else:
                external.add(imported)
    topo, active, done = [], set(), set()
    def visit(module):
        if module in done:
            return
        assert module not in active, ('Cycle', module)
        active.add(module)
        for imported in imports[module]:
            if imported in sources:
                visit(imported)
            elif imported.startswith('ImbalancedChen.'):
                assert imported in suppliers
        active.remove(module)
        done.add(module)
        topo.append(module)
    target = f'ImbalancedChen.{PREFIX}Moment06Shape'
    visit(target)
    assert done == set(sources), sorted(set(sources) - done)
    return ({'status': 'PASSED_HOST_STRUCTURAL_CHECKS_ONLY', 'candidate_source_owner_count': 66,
             'actual_new_target_count': 65, 'restored_source_copy_count': 1,
             'raw_byte_reconstruction': digest(reconstructed), 'original_CRLF_preserved': True,
             'all_113_raw_chunks_exact': True, 'all_113_raw_AST_push_tokens_exact': True,
             'all_113_typed_record_decimal_tokens_exact': True, 'Q80_token_count': cfg.rows * 10,
             'old_Q96_token_count': cfg.rows, 'new_Q96_token_count': cfg.rows,
             'terminal_block_rows': [112], 'terminal_block_array_close_present': True,
             'candidate_DAG_reachable_from_shape': True, 'candidate_DAG_acyclic': True,
             'existing_project_supplier_source_count': len(suppliers),
             'external_imports': sorted(external), 'forbidden_source_tokens_found': [],
             'metadata_simp_cleanup_applied': True, 'generic_parse_decode_helper_reused': True,
             'first_actual_header_command_all66': 'import',
             'leading_source_marker_is_ordinary_comment_all65': True,
             'v3_vs_v2_only_leading_marker_changed_all65': True,
             'restored_Data06_source_identical_to_v2_and_recovery': True,
             'Lean_verified': False, 'arithmetic_replay_performed': False}, imports, topo, suppliers)


def archived_typed_value(base, node):
    fields = {f.key.scalar: f.value for f in node.fields}
    literal = lambda n: '(' + n.scalar + ' : Int)'
    return ('{ simplexId := ' + fields['simplex_id'].scalar + ',\n'
            '    factorFloorsQ80 := #[' + ', '.join(literal(n) for n in fields['log_gap_factor_floors_Q80'].children) + '],\n'
            '    oldFloorQ96 := ' + literal(fields['old_floor_Q96']) + ',\n'
            '    newFloorQ96 := ' + literal(fields['new_floor_Q96']) + ' }')


def render_report(cfg, manifest, validation):
    return f'''# Moment06 原始解析/解码源候选

状态：`SOURCE_CANDIDATE_HOST_CHECKED_NOT_COMPILED`。`formal_acceptance:false`，`P2_6_complete:false`。

v3静态header修正：v2全部保留；仅将65个新源import前新增的`/-!`模块文档标记改为普通`/-`注释，旧Data06源字节不变。Host检查66源的第一个实际command均为import，并逐源验证v2→v3只有上述一字节差异。这是静态发现后的源候选修正，未运行Lean。

已生成66个Lean源：65个新Moment06目标和1个逐字复制的旧ArchiveMomentData06源。旧Data06恢复对象仅在manifest记录其pin；未复制或重新编译该对象，恢复对象的当前context qualification仍未验证。

原输入58376bytes、113records，SHA256 `{cfg.sha256}`。完整原件按字节复制到 `goldbach-research/{cfg.fixture_name}`，保留CRLF，使未来以本目录 `project` 为cwd时原loader相对路径有效。没有改动原JSON。

parser和typed-list各29块；Block000..027各四行，Block028仅row112。末块没有padding，没有四行整块断言。parser singleton append-normalization使用rfl。metadata采用现有Moment05的已清理simp结构。最终parse/bind复用原MomentParseDecodeBridge；reader、decoder、helper、Q80/Q96、degree6/expdegree3定义未改。

Host检查已通过：66源和65新目标的exact模块集合、全DAG、113个raw span及原AST tokens、113条typed record全部decimal tokens、整文件字节重建、末块消耗原数组关闭符、metadata分母/次数/行界，以及禁止sorry/admit/native_decide/newaxiom/unsafe。原件/模板/恢复源与对象的pin在生成前后核对。没有执行Fraction算术replay。

原始root need162、records need151，root结束58374、array结束58371；parseChars初始fuel58377，通用root实例58215。这些都是host候选plan，尚非Lean证明。

入口：`python -B generate_moment06_v3.py --check-only`只读重建内存候选并核对现有artifact；所有初次输出均为exclusive-create，默认再执行生成会拒绝替换现有manifest。所有实际写入只发生本隔离目录。生成器从实际归档中选择函数定义，不执行旧初始化器、旧main或旧save。

完整清单：`MANIFEST.json`。Lean新目标顺序：manifest的 `new_compile_targets_topological`（65项）；`normal_compile_excluded_modules`列出已恢复Data06，禁止旧normal重编。已有公共供应者仅pin源码，没有移植或伪造其接受context。{len(manifest['existing_project_supplier_sources'])}个项目supplier源位于清单中。

未验证事项：

- 65个新目标的Lean语法、elaboration、每条原parser/decoder等式、全部shape和lookup定理均未编译。
- 未运行独立leanchecker或完整owned/environment/private/generated声明审计；未产生任何新olean或编译信用。
- 旧Data06 exact object/source尚需在实际当前accepted context中qualification；本源候选不授予它新接受信用。
- 保存Q80/Q96有限算术正确性、Geometry06、Archive aliases、OriginalFloorTransport及积分终点均不由本候选认证。
'''


if __name__ == '__main__':
    main()
