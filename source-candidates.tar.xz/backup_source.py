"""Read-back current Cell06 source candidates; no proof or build execution."""
from pathlib import Path
import hashlib
import io
import json
import tarfile

BASE = Path('/workspace/p26-cell06-source-candidate-20261128')
OUT = Path(__file__).resolve().parent


def pin(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def main():
    target = OUT / 'SOURCE_SNAPSHOT.json'
    assert not target.exists()
    members = {}

    def add(name, path, expected=None):
        path = Path(path)
        assert path.is_file()
        if expected is not None:
            assert pin(path) == expected
        assert name not in members or members[name] == path
        members[name] = path

    graph_path = BASE / 'CANDIDATE_GRAPH_v2.json'
    graph = json.loads(graph_path.read_text())
    assert graph['formal_acceptance'] is False and len(graph['entries']) == 334
    post_path = BASE / 'postfinite/SOURCE_MANIFEST.json'
    post = json.loads(post_path.read_text())
    assert post['formal_acceptance'] is False and len(post['sources']) == 17
    modules = {}
    for module, info in graph['entries'].items():
        add('project/' + module.replace('.', '/') + '.lean', info['source']['path'], info['source'])
        modules[module] = info['source']
        if 'object' in info:
            add('restored_objects/' + module.replace('.', '/') + '.olean', info['object']['path'], info['object'])
    for info in post['sources']:
        module = info['module']
        assert module not in modules
        add('project/' + module.replace('.', '/') + '.lean', info['source']['path'], info['source'])
        modules[module] = info['source']
    assert len(modules) == 351

    geometry = json.loads((BASE / 'geometry/DELIVERY_MANIFEST.json').read_text())
    assert geometry['formal_acceptance'] is False
    for entry in geometry['members']:
        path = Path(entry['path'])
        add('geometry-materials/' + str(path.relative_to(BASE / 'geometry')), path, entry)
    add('geometry-materials/DELIVERY_MANIFEST.json', BASE / 'geometry/DELIVERY_MANIFEST.json')
    for folder in ['moment/v3', 'finite/v2', 'finite/bounded-access/v2', 'postfinite']:
        for path in sorted((BASE / folder).rglob('*')):
            if path.is_file() and '__pycache__' not in path.parts:
                add('materials/' + str(path.relative_to(BASE)), path)
    runner_path = BASE / 'runner/DELIVERY_MANIFEST.json'
    assert pin(runner_path)['sha256'] == 'd14f188c6e011a5576db429e79378bb3bf9b1d8d080ff37584cbbb699008b462'
    runner = json.loads(runner_path.read_text())
    for entry in runner['members']:
        path = Path(entry['path'])
        add('runner-materials/' + str(path.relative_to(BASE / 'runner')), path, entry)
    add('runner-materials/DELIVERY_MANIFEST.json', runner_path)
    for path in [graph_path, BASE / 'SOURCE_GATE_HOST_PREFLIGHT.json']:
        add(path.name, path)
    restore = Path('/workspace/p26-next-cell06-recovery-20261128')
    for name in ['RESTORE_REPORT.json', 'TRANSPORT.json', 'MANIFEST.json']:
        add('restoration/' + name, restore / name)
    for name in [
        'eighth-third-minorant-extension-20261009-a23-s23_low-06-cell.witness.json',
        'eighth-third-moment-refinement-20261009-a23-low-06.witness.json',
    ]:
        add('goldbach-research/' + name, Path('/workspace/goldbach-research') / name)
    add('backup_source.py', Path(__file__))
    pins = {name: pin(path) for name, path in sorted(members.items())}
    manifest = {
        'schema': 'p26_cell06_current_source_candidate_backup_v1',
        'formal_acceptance': False, 'P2_6_complete': False,
        'accepted_parent_commit': 'c985c5965c3ca64a30570829713b25d5ebdcc243',
        'current_candidate_modules': 351, 'new_normal_targets': 349,
        'restored_old_data_objects': 2, 'old_normal_recompilations': 0,
        'Lean_commands_by_backup': 0, 'members': pins,
        'scope': 'Current source candidates and controller delivery only. No new mathematical acceptance. Earlier candidate revisions are not a complete historical snapshot.',
    }
    manifest_raw = (json.dumps(manifest, indent=2) + '\n').encode()
    archive = OUT / 'source-candidates.tar.xz'
    with tarfile.open(archive, 'w:xz') as tar:
        for name, path in sorted(members.items()):
            data = path.read_bytes()
            assert pin(path) == pins[name]
            entry = tarfile.TarInfo(name)
            entry.size, entry.mode = len(data), 0o644
            tar.addfile(entry, io.BytesIO(data))
        entry = tarfile.TarInfo('MANIFEST.json')
        entry.size, entry.mode = len(manifest_raw), 0o644
        tar.addfile(entry, io.BytesIO(manifest_raw))
    assert archive.stat().st_size < 90 * 1024**2
    with tarfile.open(archive) as tar:
        assert len(tar.getmembers()) == len(members) + 1
        for entry in tar:
            data = tar.extractfile(entry).read()
            if entry.name == 'MANIFEST.json':
                assert data == manifest_raw
            else:
                assert data == members[entry.name].read_bytes()
    for name, path in members.items():
        assert pin(path) == pins[name]
    (OUT / 'MANIFEST.json').write_bytes(manifest_raw)
    result = {
        'formal_acceptance': False, 'P2_6_complete': False,
        'scope': manifest['scope'], 'archive': pin(archive),
        'source_manifest': pin(OUT / 'MANIFEST.json'),
        'candidate_modules': 351, 'new_normal_targets': 349,
        'restored_objects': 2, 'archive_readback_members': len(members) + 1,
        'Lean_commands_by_backup': 0, 'backup_source': pin(Path(__file__)),
    }
    target.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()
