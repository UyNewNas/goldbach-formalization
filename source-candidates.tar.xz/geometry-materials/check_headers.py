#!/usr/bin/env python3
"""HOST_CHECK: imports must precede module documentation or other commands."""
import hashlib
import json
from pathlib import Path
import re
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent


def pin(path):
    b = Path(path).read_bytes()
    return {'path': str(Path(path).resolve()), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}


def check(text):
    # Ordinary nested comments and line comments are whitespace in the header;
    # /-! module documentation is a command and cannot precede a later import.
    i, seen_command, imports = 0, False, 0
    while i < len(text):
        if text[i].isspace():
            i += 1
        elif text.startswith('--', i):
            end = text.find('\n', i)
            i = len(text) if end < 0 else end + 1
        elif text.startswith('/-', i) and not text.startswith('/-!', i):
            depth, i = 1, i + 2
            while depth:
                assert i < len(text), 'Unterminated ordinary comment'
                if text.startswith('/-', i):
                    depth, i = depth + 1, i + 2
                elif text.startswith('-/', i):
                    depth, i = depth - 1, i + 2
                else:
                    i += 1
        else:
            end = text.find('\n', i)
            end = len(text) if end < 0 else end
            line = text[i:end]
            if re.match(r'import\s+', line):
                assert not seen_command, 'Import after a non-import command/moduleDoc'
                imports += 1
            else:
                seen_command = True
            i = end + 1
    assert imports > 0
    return imports


def main():
    manifest_path = ROOT / 'SOURCE_MANIFEST.json'
    m = json.loads(manifest_path.read_text())
    checked = []
    for row in m['owners']:
        for kind in ('source', 'audit'):
            path = Path(row[kind]['path'])
            assert pin(path) == row[kind]
            checked.append({'module': row['module'], 'kind': kind, 'imports': check(path.read_text()), 'file': pin(path)})
    # Exercise the specific header regression without invoking a Lean parser.
    assert check('/- ordinary marker -/\nimport A\n/-! docs -/\nnamespace N\nend N\n') == 1
    try:
        check('/-! module documentation -/\nimport A\n')
    except AssertionError:
        rejects_bad_header = True
    else:
        rejects_bad_header = False
    assert rejects_bad_header
    report = {'schema':'p26_cell06_geometry_header_host_check_v1','status':'PASS_HOST_HEADER_CHECK_ONLY',
              'manifest':pin(manifest_path),'checker':pin(Path(__file__)),
              'candidate_source_headers':153,'audit_source_headers':153,
              'moduleDoc_before_import_regression_rejected':True,'checked_files':checked,
              'Lean_commands':0,'formal_acceptance':False,'P2_6_complete':False}
    with (ROOT/'HEADER_CHECK.json').open('x') as out:
        json.dump(report,out,ensure_ascii=False,indent=2);out.write('\n')
    print(json.dumps({k:v for k,v in report.items() if k!='checked_files'}))


if __name__=='__main__':
    main()
