#!/usr/bin/env python3
"""Independent HOST_CHECK of generated sources; no proof checker is invoked."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import sys

sys.dont_write_bytecode = True
ROOT = Path('/workspace/p26-cell06-source-candidate-20261128/geometry')


def pin(path):
    b = Path(path).read_bytes()
    return {'path': str(Path(path).resolve()), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--root', type=Path, default=ROOT)
    args = ap.parse_args()
    root = args.root.resolve(strict=True)
    assert root.is_relative_to(ROOT)
    manifest_path = root / 'SOURCE_MANIFEST.json'
    m = json.loads(manifest_path.read_text())
    assert m['status'] == 'SOURCE_CANDIDATE' and m['formal_acceptance'] is False and m['P2_6_complete'] is False
    assert m['new_Lean_commands'] == m['lake_commands'] == m['MCP_jobs_submitted'] == 0
    assert m['cell'] == 6, 'This independent check pins the requested Cell06 instance'
    assert pin(m['original_input']['path']) == m['original_input']
    raw = Path(m['original_input']['path']).read_bytes()
    assert len(raw) == 335849 and hashlib.sha256(raw).hexdigest() == '377bbf9f0c96cfd537e34072b7e283760b3f44f3b4a7d55f47fa4c7a95517e9b'
    assert m['root_end'] == 335847 and raw[335847:] == b'\r\n' and raw.isascii()
    payload = json.loads(raw)
    assert (len(payload['simplices']),len(payload['vertices']),len(payload['vertex_values']),len(payload['face_ledger'])) == (113,33,33,62)
    for row in m['existing_template_and_supplier_source_pins'] + m['recovered_data06_files_checked']:
        assert pin(row['path']) == row
    for key in ('generator','checker','implementation_plan','recovery_report'):
        assert pin(m[key]['path']) == m[key]
    owners = m['owners']
    assert len(owners) == len({r['module'] for r in owners}) == 153
    assert m['counts_host_plan'] == {'geometry_owners':150,'shape_owners':3,'targets':153,'rows':113,'vertices':33,'faces':62,'future_normal_kernel_owned_steps':459}
    supplier = {r['module'] for r in m['generic_supplier_historical_pins']} | {'ImbalancedChen.P2OriginalSaving19ArchiveGeometryData06'}
    assert len(supplier) == 9
    available, sources = set(supplier), {}
    for row in owners:
        assert row['status'] == 'SOURCE_CANDIDATE' and row['formal_acceptance'] is False and row['P2_6_complete'] is False
        assert pin(row['source']['path']) == row['source'] and pin(row['audit']['path']) == row['audit']
        p = Path(row['source']['path'])
        assert p.is_relative_to(root / 'project/ImbalancedChen') and p.stem == row['module'].split('.')[-1]
        source = p.read_text()
        imports = re.findall(r'(?m)^import\s+(ImbalancedChen\.\S+)',source)
        assert imports == row['project_imports'] and set(imports) <= available
        assert not re.search(r'\b(?:sorry|admit|native_decide|newaxiom|unsafe)\b|(?m:^\s*axiom\b)',source)
        assert not re.search(r'Geometry(?:01|05)(?!\d)|geometryPacked(?:01|05)\b|originalGeometryJson(?:01|05)\b|concreteGeometry(?:01|05)\b|cell(?:01|05)\b',source)
        assert 'Metadata06' not in source
        available.add(row['module'])
        sources[p.stem] = source
    assert (root/'owner_order.txt').read_text().splitlines() == [r['module'] for r in owners]
    assert len(list((root/'project/ImbalancedChen').glob('*.lean'))) == 153
    assert len(list((root/'owned-audits').glob('*.lean'))) == 153
    tag = 'P2OriginalSaving19Geometry06Scalable'
    assert tag+'Metadata05' in sources and tag+'Metadata06' not in sources
    row_groups = m['row_leaves']
    assert len(row_groups) == 15
    assert [g[-1]['after']-g[0]['first'] for g in row_groups] == [8]*14+[1]
    assert row_groups[0][0]['start'] == 124031 and row_groups[-1][-1]['end'] == 335468
    assert row_groups[-1][-1]['final'] is True
    assert max(g[-1]['end']-g[0]['start'] for g in row_groups) == 16242
    for block in range(15):
        p, t = tag+f'SimplicesBlock{block:03d}', tag+f'TypedRows{block:03d}'
        assert p in sources and t in sources
        row = next(r for r in owners if r['module']=='ImbalancedChen.'+t)
        assert row['project_imports'] == ['ImbalancedChen.P2OriginalSaving19ArchiveRationalChars','ImbalancedChen.'+p]
    last = sources[tag+'TypedRows014']
    assert re.findall(r'noncomputable def geometryRowsTyped(\d{3}) : GeometryRow',last) == ['112']
    shape_rows = sources[tag+'ShapeRows']
    assert 'theorem row_identifiers_block_014 : ∀ r : Fin 1,' in shape_rows
    assert 'theorem all_row_identifiers : ∀ r : Fin 113,' in shape_rows
    assert '112 + r.val' in shape_rows and 'r.val - 112 < 1' in shape_rows
    assert 'row_identifiers_block_014 : ∀ r : Fin 8' not in shape_rows
    for family,count in [('Vertices',33),('VertexValues',33),('Faces',62),('FacetVertices',11),('Rows',113)]:
        declarations = re.findall(r'noncomputable def geometry'+family+r'Typed(\d{3})\s*:', '\n'.join(sources.values()))
        assert sorted(map(int,declarations)) == list(range(count)), (family,len(declarations))
    # All referenced node family/interval names must have corresponding generated owners.
    known = {s.removeprefix(tag) for s in sources if 'Node' in s}
    for text in sources.values():
        for token in re.findall(r'(?:Active8Enumeration|AllOriginalConstraintMinima|Vertices|VertexValues|FacetVertices|FaceLedger|Rows)?Node\d{3}To\d{3}',text):
            normalized = 'Rows'+token if token.startswith('Node') else token
            assert normalized in known, ('Unknown node name',token)
    assert len(m['required_local_shape_declarations']) == len(set(m['required_local_shape_declarations'])) == 252
    all_text = '\n'.join(sources.values())
    for fqn in m['required_local_shape_declarations']:
        assert re.search(r'\btheorem '+re.escape(fqn.rsplit('.',1)[1])+r'\b',all_text)
    whole = sources[tag+'WholeParse']
    assert 'geometryPacked06_original_parse' in whole and 'sourceRest_white_tail' in whole
    decoded = sources[tag+'Decoded']
    assert 'noncomputable def concreteGeometry06 : Geometry' in decoded
    assert 'geometryPacked06_parse_decode' in decoded and 'decode_originalGeometryJson06' in decoded
    assert '335850' in sources[tag+'WholeValue'] and 'sourceRest 335847' in sources[tag+'WholeValue']
    shape = sources[tag+'Shape']
    for snippet in ['concreteGeometry06.rows.size = 113','concreteGeometry06.vertices.size = 33',
                    'concreteGeometry06.faces.size = 62','FaceLedgerNode000To006.typedItems',
                    'VerticesNode000To002.typedItems','VertexValuesNode000To004.typedItems',
                    'Node000To014.typedRows','rows_000_to_014_shape']:
        assert snippet in shape,snippet
    # Exact quotations of every original rational/record were generated by the
    # pinned renderer; these host checks deliberately do not evaluate Lean.
    assert all(len(v)==8 for v in payload['vertices'])
    assert all(r['simplex_id']==i and len(r['vertex_ids'])==9 and len(set(r['vertex_ids']))==9 and
               max(r['vertex_ids'])<33 and len(r['factor_maxima'])==len(r['gap_weighted_means'])==10
               for i,r in enumerate(payload['simplices']))
    report = {'schema':'p26_cell06_geometry_host_check_v1','status':'PASS_HOST_CHECK_ONLY','manifest':pin(manifest_path),
              'input_exact_bytes_sha256_crlf':True,'topological_project_imports_checked':153,
              'candidate_sources_checked':153,'owned_audit_sources_pinned':153,'last_row_leaf_size':1,
              'last_identifier_domain':'Fin 1','required_local_shape_declarations':252,
              'source_bytes':sum(r['source']['bytes'] for r in owners),
              'template_and_supplier_source_pins_checked':len(m['existing_template_and_supplier_source_pins']),
              'old_cell01_cell05_specialized_references':0,'forbidden_proof_declarations':0,
              'Lean_commands':0,'formal_acceptance':False,'P2_6_complete':False}
    output=root/'HOST_CHECK.json'
    with output.open('x') as out:
        json.dump(report,out,ensure_ascii=False,indent=2);out.write('\n')
    print(json.dumps(report,ensure_ascii=False))


if __name__=='__main__':
    main()
