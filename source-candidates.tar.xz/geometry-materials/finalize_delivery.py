#!/usr/bin/env python3
"""Finalize candidate metadata and readback; never invoke Lean or services."""
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent


def fp(path):
    data = Path(path).read_bytes()
    return {'path':str(Path(path).resolve()),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}


def create(path,value):
    assert Path(path).resolve().is_relative_to(ROOT)
    data = value.encode() if isinstance(value,str) else (json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode()
    with Path(path).open('xb') as out:
        out.write(data)
    return fp(path)


def statement(source,name):
    match = re.search(r'(?m)^theorem '+re.escape(name)+r'\b',source)
    assert match,name
    text = source[match.start():]
    ends = [text.find(token) for token in (' := by',' :=\n',' where\n') if text.find(token)>=0]
    assert ends,name
    return text[:min(ends)].strip()


def main():
    m=json.loads((ROOT/'SOURCE_MANIFEST.json').read_text())
    host=json.loads((ROOT/'HOST_CHECK.json').read_text())
    header=json.loads((ROOT/'HEADER_CHECK.json').read_text())
    assert host['status']=='PASS_HOST_CHECK_ONLY' and header['status']=='PASS_HOST_HEADER_CHECK_ONLY'
    assert host['manifest']==header['manifest']==fp(ROOT/'SOURCE_MANIFEST.json')
    for row in m['owners']:
        assert fp(row['source']['path'])==row['source'] and fp(row['audit']['path'])==row['audit']
    spec=importlib.util.spec_from_file_location('frozen_geometry_generator',ROOT/'generate_geometry.py')
    generator=importlib.util.module_from_spec(spec);spec.loader.exec_module(generator)
    prior=fp(ROOT/'SOURCE_MANIFEST.json')
    try:
        generator.create(ROOT/'SOURCE_MANIFEST.json',b'forbidden overwrite test')
    except FileExistsError:
        exclusive_guard=True
    else:
        exclusive_guard=False
    assert exclusive_guard and fp(ROOT/'SOURCE_MANIFEST.json')==prior
    assert not any(p.name=='__pycache__' for p in ROOT.rglob('*'))
    tag='P2OriginalSaving19Geometry06Scalable'
    dec='ImbalancedChen.P2OriginalSaving19Geometry06ScalableDecoding'
    shape_ns='ImbalancedChen.P2OriginalSaving19Geometry06ScalableShape'
    shape=(ROOT/'project/ImbalancedChen'/f'{tag}Shape.lean').read_text()
    names=['dimension','physical_jacobian','row_count','vertex_count','vertex_values_count','vertex_values_size',
           'facet_count','facet_vertices_count','face_count','facet_original_indices_nodup','facet_original_indices_bound',
           'all_rows','all_vertices','all_facets','all_faces','concreteGeometry06_shape','geometryPacked06_parse_decode_shape']
    theorem_api=[]
    for name in names:
        declaration=statement(shape,name)
        theorem_api.append({'FQN':shape_ns+'.'+name,'declaration':declaration,
                            'resolved_concrete_geometry_type':declaration.split(' :',1)[1].strip().replace('concreteGeometry06',dec+'.Complete.concreteGeometry06'),
                            'module':'ImbalancedChen.'+tag+'Shape','formal_acceptance':False})
    selectors=[]
    for owner in m['owners']:
        source=Path(owner['source']['path']).read_text()
        for family,typ in [('Rows','GeometryRow'),('Vertices','Array ℚ')]:
            for index in re.findall(r'(?m)^noncomputable def geometry'+family+r'Typed(\d{3})\s*:',source):
                selectors.append({'FQN':dec+'.geometry'+family+'Typed'+index,'type':typ,
                                  'module':owner['module'],'source':owner['source'],'formal_acceptance':False})
    assert len(selectors)==146
    api={'schema':'p26_cell06_geometry_candidate_selector_api_v1','status':'SOURCE_CANDIDATE',
         'concrete_geometry':{'FQN':dec+'.Complete.concreteGeometry06','type':'Geometry',
                              'module':'ImbalancedChen.'+tag+'Decoded'},
         'row_root':dec+'.Node000To014.typedRows','vertices_root':dec+'.VerticesNode000To002.typedItems',
         'shape_namespace':shape_ns,'row_shape_namespace':shape_ns+'.Rows','array_shape_namespace':shape_ns+'.Arrays',
         'theorems':theorem_api,'individual_selectors':selectors,
         'formal_acceptance':False,'P2_6_complete':False}
    create(ROOT/'SELECTOR_API.json',api)
    report='''Cell06 geometry SOURCE_CANDIDATE 交付记录

已在本目录生成150个完整原始geometry parser/decoder候选owner及3个有限shape候选owner，共153个Lean源文件，源码共8,030,527字节；另有153份full-owned审计候选源。所有文件均由新适配生成器exclusive-create。未运行Lean、lake、MCP任务或Git提交，未修改原repo、Cell01、旧报告、原JSON、服务文件或moment目录。

实际执行：

1. 编写本目录IMPLEMENTATION_PLAN.md、generate_geometry.py和独立check_geometry.py。读取既有renderer方法并在Python内存中进行指定命名/计数适配；没有执行旧脚本main或Cell01/05专属constructor。原始reader/decoder及原数据未改变。
2. 执行 `python3 -B generate_geometry.py`，首次成功，153候选及全部审计源生成。先完整缓冲并检查拓扑，再写源文件；没有失败的生成尝试。
3. 执行 `python3 -B check_geometry.py`，结果PASS_HOST_CHECK_ONLY。实测原输入335849字节、精确SHA256、root_end335847及CRLF；153目标及imports拓扑、完整pins、15个row leaves、末叶只有row112、末identifier为Fin1、252项local shape事实、所有selector索引覆盖及节点名称通过host检查。旧Cell01/05专属candidate引用及禁用证明token均0；Metadata05保持。
4. 父进程指出moduleDoc-before-import陷阱后，新建独立check_headers.py；没有改动已冻结candidate/generator/checker。执行该脚本，153候选及153审计header均通过。回归检查明确拒绝 `/-! moduleDoc -/` 后跟import；普通 `/- ... -/` marker可以位于import前。未调用Lean parser。
5. 执行finalize_delivery.py，逐源/审计再读回pins，实际确认exclusive-create会拒绝覆盖SOURCE_MANIFEST.json且原bytes不变，确认无pycache；生成SELECTOR_API.json、此报告与交付manifest，并核对交付pins。GENERATION_STEPS.json保留工具调用输出；该记录中的最后planned项由本次finalize执行及DELIVERY_MANIFEST.json补足为已完成。

主要文件：SOURCE_MANIFEST.json固定153个owner、所有原模板/输入/生成器/检查器及supplier源码pins、方法适配明细、byte spans、import graph、shape事实和scope；HOST_CHECK.json和HEADER_CHECK.json是本地检查证据；SELECTOR_API.json给出精确FQN、声明type和146个逐row/vertex selector所在module；DELIVERY_MANIFEST.json汇总本交付所有文件pins。

精确接口：

- concreteGeometry06：ImbalancedChen.P2OriginalSaving19Geometry06ScalableDecoding.Complete.concreteGeometry06 : Geometry。
- 逐行geometryRowsTyped000…112及逐vertex geometryVerticesTyped000…032均位于ImbalancedChen.P2OriginalSaving19Geometry06ScalableDecoding。
- row root是Node000To014.typedRows；vertex root是VerticesNode000To002.typedItems，均在同Decoding namespace。
- shape theorem namespace为ImbalancedChen.P2OriginalSaving19Geometry06ScalableShape；Rows/Arrays为其子namespace。row_count给出rows.size=113；vertex_count给出vertices.size=33；vertex_values_size将实际vertexValues.size等同vertices.size。all_rows使用Fin113，all_vertices使用Fin33，完整逐字声明见SELECTOR_API.json。

明确未验证事项：

- 153份候选均未进行Lean normal compilation、independent kernel replay或full-owned执行。源码中的rfl/decide+kernel/omega等proof text只是待检源码，不是已接受证明。formal_acceptance=false，normal/kernel/owned接受数均0，P2_6_complete=false。
- Data06的既有source/object已经由独立恢复目录恢复并在本次host读取中核对exact pins，但旧receipt/log bodies缺失、历史raw chain及当前dependency-context join未重检。本交付不复制/重编这些旧对象，也不给其新增formal credit。
- 同构模板的Lean可接受性、所有新规模下normal/kernel资源消耗仍未知；host检查不能发现全部elaboration/typechecking问题。Shape使用当前Geometry05ScalableShape.lean中的generic membership proof源码作为模板，没有重引旧生成器过时proof body。
- 生成器CLI/engine对cell、repo、raw-root、output-root等做参数化，实际冻结和独立完整host验证仅覆盖本次Cell06实例；其他cell的shape-root迁移未作为本交付承诺。
- 未生成Archive.geometry Fin6 projection、BoundedAccess、moment、finite arithmetic或语义owner。有限shape不证明coverage、不交、determinant、physical-volume解释、仿射gap/factor含义、Jensen或积分。physical_volume/integral_gap字符串完整解析不等于其数学意义成立。
- 包中没有Lean对象、服务runner或MCP提交脚本。后续应恢复并qualify既有suppliers，在新的隔离上下文核验此153目标；不得借重编旧成功normal绕过exact对象/receipt恢复。

本目录内容全部属于SOURCE_CANDIDATE及HOST_CHECK证据。唯一实际完成的接受结论是本地文件生成、字节/结构检查和readback通过。
'''
    create(ROOT/'EXECUTION_REPORT.md',report)
    files=[]
    for path in sorted(ROOT.rglob('*')):
        assert not path.is_symlink()
        if path.is_file():
            files.append(fp(path))
    delivery={'schema':'p26_cell06_geometry_source_candidate_delivery_v1','status':'SOURCE_CANDIDATE',
              'source_manifest':fp(ROOT/'SOURCE_MANIFEST.json'),'host_check':fp(ROOT/'HOST_CHECK.json'),
              'header_check':fp(ROOT/'HEADER_CHECK.json'),'selector_api':fp(ROOT/'SELECTOR_API.json'),
              'execution_report':fp(ROOT/'EXECUTION_REPORT.md'),'members':files,'members_count':len(files),
              'targets':153,'geometry_owners':150,'shape_owners':3,'audit_sources':153,'source_bytes':8030527,
              'exclusive_create_rejection_checked':True,'no_pycache':True,'finalization_step_completed':True,
              'Lean_commands':0,'lake_commands':0,'MCP_jobs_submitted':0,'formal_acceptance':False,'P2_6_complete':False}
    path=ROOT/'DELIVERY_MANIFEST.json'
    create(path,delivery)
    readback=json.loads(path.read_text())
    assert readback==delivery
    for row in readback['members']:
        assert fp(row['path'])==row
    print(json.dumps({'delivery_manifest':fp(path),'source_manifest':delivery['source_manifest'],
                      'targets':153,'source_bytes':8030527,'members_checked':len(files),
                      'formal_acceptance':False,'P2_6_complete':False,'Lean_commands':0}))


if __name__=='__main__':
    main()
