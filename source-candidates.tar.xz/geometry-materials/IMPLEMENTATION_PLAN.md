# Cell06 geometry source candidate implementation plan

**Goal:** Generate the approved 150 geometry owners and 3 finite-shape owners, preserving the original reader, decoder, input, and ownership structure.

**Architecture:** A parameterized adapter reads frozen template functions, compiles only explicitly selected renderer methods in memory, and buffers generated Lean text. Host checks run over the complete buffered graph before exclusive creation of candidate files. No template script main or proof command runs.

**Spec:** `/workspace/p26-next-cell06-readonly-plan/geometry-report.md`, explicitly approved by the parent task.

**Writable root:** `/workspace/p26-cell06-source-candidate-20261128/geometry/` only. No Git mutation, Lean, lake, MCP job, subagent, or modification of any existing source/input/service file.

- [ ] Implement adapter and independent host checker in this root.
- [ ] Generate 153 candidate owners and their audit sources using exclusive creation.
- [ ] Verify exact input hash/bytes/CRLF, source graph, counts, leaf112/Fin1, references, forbidden declarations, and all manifest pins.
- [ ] Record all actual generation/check steps and remaining formal verification boundaries.

Review focus: do not rename `Metadata05`; do not assume every row leaf has eight rows; do not retain Cell01/05 specialized references; do not omit parser-only original fields; do not treat restored Data06 bytes or host checks as proof acceptance.
