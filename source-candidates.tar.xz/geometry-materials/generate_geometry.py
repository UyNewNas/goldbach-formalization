#!/usr/bin/env python3
"""Generate original geometry SOURCE_CANDIDATE files; never run proof commands."""
import argparse
import ast
import hashlib
import importlib.util
import inspect
import json
from pathlib import Path
import re
import sys
import textwrap
from types import SimpleNamespace

sys.dont_write_bytecode = True
ALLOWED_ROOT = Path('/workspace/p26-cell06-source-candidate-20261128/geometry')
DEFAULT_REPO = Path('/workspace/p26-proof-continuation-20261127')
TRANSFORMS = []
USED_TEMPLATES = set()


def pin_bytes(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def fp(path):
    path = Path(path).resolve(strict=True)
    return {'path': str(path), **pin_bytes(path.read_bytes())}


def create(path, value):
    path = Path(path)
    assert path.resolve().is_relative_to(ALLOWED_ROOT)
    data = value if isinstance(value, bytes) else value.encode() if isinstance(value, str) else (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode()
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as out:
        out.write(data)
    return fp(path)


def load_module(name, path):
    path = Path(path)
    USED_TEMPLATES.add(path.resolve())
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def function_source(path, cls, name):
    path = Path(path)
    USED_TEMPLATES.add(path.resolve())
    text = path.read_text()
    module = ast.parse(text)
    parent = next(n for n in module.body if isinstance(n, ast.ClassDef) and n.name == cls) if cls else module
    node = next(n for n in parent.body if isinstance(n, ast.FunctionDef) and n.name == name)
    return textwrap.dedent(ast.get_source_segment(text, node))


def adapt_method(path, cls, name, env, replacements=(), number_map=None):
    source = function_source(path, cls, name)
    initial = source
    changes = []
    for old, new in replacements:
        count = source.count(old)
        if count:
            source = source.replace(old, new)
            changes.append({'old': old, 'new': new, 'occurrences': count})
    if number_map:
        for old, new in number_map.items():
            source, count = re.subn(r'\b' + str(old) + r'\b', str(new), source)
            if count:
                changes.append({'old_number': old, 'new_number': new, 'occurrences': count})
    namespace = dict(env)
    exec(compile(source, str(path) + ':' + (cls + '.' if cls else '') + name, 'exec'), namespace)
    TRANSFORMS.append({'template': str(path), 'class': cls, 'method': name,
                       'original_function': pin_bytes(initial.encode()), 'adapted_function': pin_bytes(source.encode()),
                       'changes': changes})
    return namespace[name]


def build_engine_class(repo, cell, raw_root, output):
    scalable = repo / 'tools/p26/scalable'
    pilot = load_module('cell06_readonly_pilot', scalable / 'generate_pilot.py')
    legacy_dir = repo / 'docs/verification/20261125-p26/geometry-direct-packed-source-only'
    for path in [legacy_dir / n for n in ('generate.py', 'raw_planner.py', 'fragment_templates.py')]:
        USED_TEMPLATES.add(path.resolve())
    USED_TEMPLATES.update((scalable / n).resolve() for n in ('quotation.py', 'row_templates.py'))
    fields_path = repo / 'tools/p26/scalable-cell05-fields/generate_arrays.py'
    row_path = repo / 'tools/p26/scalable-cell05-complete/generate_rows.py'
    full_path = repo / 'docs/verification/20261125-p26/cell01-geometry-active8/generate_full.py'
    connections_path = repo / 'tools/p26/scalable-cell05-connections/generate_connections.py'
    shape_path = repo / 'tools/p26/scalable-cell05-connections/generate_shape.py'
    fields_tree = ast.parse(fields_path.read_text())
    fields_constants = {n.targets[0].id: ast.literal_eval(n.value) for n in fields_tree.body
                        if isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Name)
                        and n.targets[0].id in ('ARRAY_KEYS', 'TYPED')}

    class GeometryEngine(pilot.Engine):
        def __init__(self):
            super().__init__(cell, raw_root)
            self.output = output
            self.buffers = {}
            self.payload = json.loads(self.raw)
            self.vertex_count = len(self.payload['vertices'])
            self.row_count = len(self.payload['simplices'])
            self.face_count = len(self.payload['face_ledger'])
            self.field_index = {f.key.scalar: i for i, f in enumerate(self.node.fields)}
            self.roots = {}
            self.array_roots = {}
            self.row_nodes = []
            self.source_templates = []
            self.required_local_shape = []

        @staticmethod
        def field_tag(key):
            return ''.join(part.title() for part in key.split('_'))

        def block_plan(self, key):
            if key == 'simplices':
                return pilot.Engine.block_plan(self, key)
            assert key in fields_constants['ARRAY_KEYS']
            node = self.fields[key].value
            chunks = self.chunks_for(node, max_items=2, max_bytes=768)
            groups, group = [], []
            for chunk in chunks:
                if group and (len(group) == 8 or chunk['end'] - group[0]['start'] > 65536):
                    groups.append(group)
                    group = []
                group.append(chunk)
            if group:
                groups.append(group)
            return node, groups

        def save(self, short, source, scope, plan):
            assert short.startswith(self.tag) and short not in self.buffers
            source = source.replace('\ndef ', '\nnoncomputable def ')
            assert not re.search(r'\b(?:sorry|admit|native_decide|newaxiom|unsafe)\b|(?m:^\s*axiom\b)', source)
            assert not re.search(r'Geometry(?:01|05)(?!\d)|geometryPacked(?:01|05)\b|originalGeometryJson(?:01|05)\b|concreteGeometry(?:01|05)\b', source)
            self.buffers[short] = source
            record = {'module': 'ImbalancedChen.' + short,
                      'source': {'path': str(output / 'project/ImbalancedChen' / (short + '.lean')), **pin_bytes(source.encode())},
                      'scope': scope, 'project_imports': re.findall(r'(?m)^import\s+(ImbalancedChen\.\S+)', source),
                      'planned_obligations': plan, 'cell': cell,
                      'status': 'SOURCE_CANDIDATE', 'formal_acceptance': False,
                      'normal_kernel_owned_accepted': False, 'P2_6_complete': False}
            self.records.append(record)
            return record

        row_typed_leaf = pilot.Engine.typed_leaf

        def build_rows(self):
            _, groups = self.block_plan('simplices')
            for block in range(len(groups)):
                self.array_block_owner('simplices', block)
                self.row_typed_leaf(block)

            def build(first, last):
                if first == last:
                    return self.child(first, last)
                middle = (first + last) // 2
                build(first, middle)
                build(middle + 1, last)
                self.assembly_node(first, middle, middle + 1, last)
                self.row_nodes.append((first, middle, middle + 1, last))
                return self.child(first, last)

            root = build(0, len(groups) - 1)
            self.row_root_name = 'Node000To' + f'{len(groups)-1:03d}'
            ns = self.typed_ns + '.' + self.row_root_name
            self.roots['simplices'] = {
                'first': 0, 'last': len(groups) - 1, 'module': root['module'],
                'push': ns + '.blockPush', 'parse': ns + '.array_original', 'typed': True,
                'typ': 'GeometryRow', 'decoder': 'decodeGeometryRow', 'json': ns + '.jsonRows',
                'values': ns + '.typedRows', 'reverse': ns + '.blockPush_reverse',
                'decode': ns + '.original_rows_decode', 'length': ns + '.rows_length'}

        def row_shapes(self):
            _, groups = self.block_plan('simplices')
            root = self.row_root_name
            text = self.header(['ImbalancedChen.' + self.tag + 'Rows' + root], '.Rows',
                               f'Finite local shape for all {self.row_count} original typed rows.')
            text += '''noncomputable def RowShape (vertexCount : Nat) (row : GeometryRow) : Prop :=
  row.vertexIds.size = 9 ∧ row.vertexIds.toList.Nodup ∧
  (∀ i : Fin 9, row.vertexIds[i.val]! < vertexCount) ∧
  row.factorMaxima.size = 10 ∧ row.gapWeightedMeans.size = 10

'''
            names = []
            list_name = lambda a,b: f'geometryRowsTypedBlock{a:03d}' if a == b else f'Node{a:03d}To{b:03d}.typedRows'
            fact = lambda a,b: f'rows_{a:03d}_to_{b:03d}_shape'
            for block, group in enumerate(groups):
                first, after = group[0]['first'], group[-1]['after']
                witnesses = []
                for index in range(first, after):
                    local = f'geometryRow{index:03d}_shape'
                    self.required_local_shape.append(self.typed_ns + '.' + local)
                    witnesses.append(local + '.2')
                name, value = fact(block, block), list_name(block, block)
                text += f'theorem {name} : ∀ row ∈ {value}, RowShape {self.vertex_count} row := '
                text += self.membership_proof(value, witnesses) + '\n'
                names.append(name)
            for a,b,c,d in self.row_nodes:
                name = fact(a,d)
                text += f'''theorem {name} : ∀ row ∈ {list_name(a,d)}, RowShape {self.vertex_count} row := by
  intro row hrow
  change row ∈ {list_name(a,b)} ++ {list_name(c,d)} at hrow
  exact (List.mem_append.mp hrow).elim ({fact(a,b)} row) ({fact(c,d)} row)

'''
                names.append(name)
            for block, group in enumerate(groups):
                first, after = group[0]['first'], group[-1]['after']
                name = f'row_identifiers_block_{block:03d}'
                text += f'''theorem {name} : ∀ r : Fin {after-first},
    ({root}.typedRows.toArray[{first} + r.val]!).simplexId = {first} + r.val := by
  decide +kernel

'''
                names.append(name)
            text += f'''theorem all_row_identifiers : ∀ r : Fin {self.row_count},
    ({root}.typedRows.toArray[r.val]!).simplexId = r.val := by
  intro r
  have hr := r.isLt
'''
            indent = '  '
            for block, group in enumerate(groups[:-1]):
                first, after = group[0]['first'], group[-1]['after']
                text += indent + f'by_cases h{block} : r.val < {after}\n'
                if first == 0:
                    text += indent + f'· simpa only [Nat.zero_add] using row_identifiers_block_{block:03d} ⟨r.val, h{block}⟩\n'
                else:
                    text += indent + f'· have hb : r.val - {first} < {after-first} := by omega\n'
                    text += indent + f'  have he : {first} + (r.val - {first}) = r.val := by omega\n'
                    text += indent + f'  simpa only [he] using row_identifiers_block_{block:03d} ⟨r.val - {first}, hb⟩\n'
                text += indent + '·\n'
                indent += '  '
            block = len(groups)-1
            first, after = groups[-1][0]['first'], groups[-1][-1]['after']
            text += indent + f'have hb : r.val - {first} < {after-first} := by omega\n'
            text += indent + f'have he : {first} + (r.val - {first}) = r.val := by omega\n'
            text += indent + f'simpa only [he] using row_identifiers_block_{block:03d} ⟨r.val - {first}, hb⟩\n\n'
            names.append('all_row_identifiers')
            text += self.footer('.Rows', names)
            return self.save(self.tag + 'ShapeRows', text, 'Original row-local shape and identifiers through balanced parser-bound typed lists',
                             {'rows': self.row_count, 'row_bound': self.vertex_count,
                              'leaf_sizes': [g[-1]['after']-g[0]['first'] for g in groups],
                              'identifier_projection_blocks': len(groups), 'new_full_record_decisions': 0})

    # Rehost selected renderer functions only. No source template main/constructor runs.
    prototype = GeometryEngine()
    tag, typed_ns = prototype.tag, prototype.typed_ns
    shape_ns = f'ImbalancedChen.P2OriginalSaving19Geometry{cell:02d}ScalableShape'
    replacements = [('Geometry05Scalable', f'Geometry{cell:02d}Scalable'),
                    ('originalGeometryJson05', f'originalGeometryJson{cell:02d}'),
                    ('geometryPacked05', f'geometryPacked{cell:02d}'),
                    ('concreteGeometry05', f'concreteGeometry{cell:02d}'),
                    ('cell05', f'cell{cell:02d}'), ('cell 05', f'cell {cell:02d}')]
    numbers = {28: prototype.vertex_count, 56: prototype.row_count, 45: prototype.face_count,
               201042: len(prototype.raw), 168: prototype.row_count + sum(len(prototype.payload[k]) for k in fields_constants['TYPED'])}
    env = {'TAG': tag, 'TYPED_NS': typed_ns, 'SHAPE_NS': shape_ns, 'REPO': repo,
           'Path': Path, 're': re, 'fp': fp, 'base': pilot.base,
           'record_value': pilot.record_value, **fields_constants,
           'fields': SimpleNamespace(TYPED=fields_constants['TYPED'])}
    membership = adapt_method(shape_path, None, 'membership_proof', env)
    env['membership_proof'] = membership
    GeometryEngine.membership_proof = staticmethod(membership)
    for name in ('head', 'leaf', 'node_owner', 'balanced_root', 'array_value'):
        setattr(GeometryEngine, name, adapt_method(fields_path, 'FieldsEngine', name, env, replacements, numbers))
    GeometryEngine.field_typed_leaf = adapt_method(fields_path, 'FieldsEngine', 'typed_leaf', env, replacements, numbers)
    for name in ('child', 'assembly_node'):
        setattr(GeometryEngine, name, adapt_method(row_path, 'CompleteRows', name, env, replacements, numbers))
    for name in ('prior', 'field_header', 'array_field'):
        setattr(GeometryEngine, name, adapt_method(full_path, 'FullEngine', name, env, replacements, numbers))
    for name in ('scalar_field', 'whole_value', 'whole_parse', 'decode_fields', 'decoded'):
        setattr(GeometryEngine, name, adapt_method(connections_path, 'ConnectionsEngine', name, env, replacements, numbers))
    for name in ('header', 'footer', 'array_value_name', 'array_fact', 'array_shapes'):
        setattr(GeometryEngine, name, adapt_method(shape_path, 'ShapeEngine', name, env, replacements, numbers))
    return prototype, pilot, replacements, numbers


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=DEFAULT_REPO)
    parser.add_argument('--raw-root', type=Path, default=Path('/workspace/goldbach-research'))
    parser.add_argument('--cell', type=int, default=6)
    parser.add_argument('--output-root', type=Path, default=ALLOWED_ROOT)
    args = parser.parse_args()
    repo, output = args.repo.resolve(strict=True), args.output_root.resolve()
    assert output.is_relative_to(ALLOWED_ROOT) and 1 <= args.cell <= 12
    assert not (output / 'SOURCE_MANIFEST.json').exists(), 'Exclusive generation only; use a new output subdirectory'
    e, pilot, replacements, numbers = build_engine_class(repo, args.cell, args.raw_root, output)
    input_paths = repo / 'docs/verification/20261125-p26/archive-v4/INPUT_PATHS.json'
    recovery_path = Path('/workspace/p26-next-cell06-recovery-20261128/RESTORE_REPORT.json')
    audit_template = repo / 'tools/p26/scalable/owned-audits/P2OriginalSaving19Geometry05ScalableInput.lean'
    shape_template = repo / 'ImbalancedChen/P2OriginalSaving19Geometry05ScalableShape.lean'
    decode_template = repo / 'ImbalancedChen/P2OriginalSaving19Geometry01DirectDecodeFields.lean'
    generic_registry = repo / 'tools/p26/scalable-cell05-complete/SUPPLIER_REGISTRY.json'
    USED_TEMPLATES.update([input_paths, audit_template, shape_template, decode_template, generic_registry,
                           repo / 'ImbalancedChen' / f'P2OriginalSaving19ArchiveGeometryData{args.cell:02d}.lean'])
    generic = [r for r in json.loads(generic_registry.read_text())['suppliers']
               if not re.search(r'Geometry05Scalable|ArchiveGeometryData05', r['module'])]
    assert len(generic) == 8
    for row in generic:
        path = repo / (row['module'].replace('.', '/') + '.lean')
        assert pin_bytes(path.read_bytes()) == row['source']
        USED_TEMPLATES.add(path)
    frozen = [fp(p) for p in sorted(USED_TEMPLATES)]
    original_input = fp(e.raw_origin)
    assert e.raw[e.node.end:] == b'\r\n' and len(e.node.fields) == 14
    if args.cell == 6:
        assert len(e.raw) == 335849 and original_input['sha256'] == '377bbf9f0c96cfd537e34072b7e283760b3f44f3b4a7d55f47fa4c7a95517e9b'
        assert (e.row_count, e.vertex_count, e.face_count, e.node.end) == (113, 33, 62, 335847)
    e.input_owner()
    e.metadata_owner(5)
    e.build_rows()
    for key in ['active8_enumeration', 'vertices', 'vertex_values', 'all_original_constraint_minima', 'facet_vertices', 'face_ledger']:
        _, groups = e.block_plan(key)
        for block in range(len(groups)):
            e.array_block_owner(key, block)
            if key in {'vertices', 'vertex_values', 'facet_vertices', 'face_ledger'}:
                e.field_typed_leaf(key, block)
        root = e.balanced_root(key)
        e.roots[key] = root
        e.array_value(key, root)
    e.array_value('simplices', e.roots['simplices'])
    for field in e.node.fields[5:12]:
        assert field.value.kind == 'arr'
        e.field_header(field.key.scalar)
        e.array_field(field.key.scalar)
    e.scalar_field()
    e.whole_value()
    e.whole_parse()
    e.decode_fields()
    e.decoded()
    geometry_count = len(e.records)
    e.field_manifest = {'owners': list(e.records)}
    e.row_shapes()
    e.array_shapes()
    # Use the current source's repaired generic membership proof rather than
    # reviving the older generator's property_of_list_toArray proof body.
    shape = shape_template.read_text()
    shape_changes = list(replacements)
    shape_changes += [('FaceLedgerNode000To004', 'FaceLedgerNode000To006'),
                      ('face_ledger_000_to_004_shape', 'face_ledger_000_to_006_shape'),
                      ('VerticesNode000To001', 'VerticesNode000To002'),
                      ('vertices_000_to_001_shape', 'vertices_000_to_002_shape'),
                      ('VertexValuesNode000To003', 'VertexValuesNode000To004'),
                      ('vertex_values_000_to_003_shape', 'vertex_values_000_to_004_shape'),
                      ('RowsNode000To006', 'Rows' + e.row_root_name),
                      ('rows_000_to_006_shape', 'rows_000_to_014_shape')]
    for old, new in shape_changes:
        shape = shape.replace(old, new)
    # Do not change the suffix inside FaceLedgerNode000To006.
    shape = re.sub(r'(?<![A-Za-z0-9_])Node000To006\b', e.row_root_name, shape)
    for old, new in numbers.items():
        shape = re.sub(r'\b' + str(old) + r'\b', str(new), shape)
    e.save(e.tag + 'Shape', shape, 'Finite shape of the actual original decoder output; current generic membership proof template',
           {'rows': e.row_count, 'vertices': e.vertex_count, 'faces': e.face_count,
            'whole_parse_decode_shape_candidate': True, 'geometric_or_integral_interpretation': False,
            'source_template': str(shape_template), 'local_shape_fact_count': len(e.required_local_shape)})
    if args.cell == 6:
        assert geometry_count == 150 and len(e.records) == 153
        assert len(e.required_local_shape) == len(set(e.required_local_shape)) == 252
    # Verify the complete buffered import graph before writing any candidate.
    supplier_modules = {r['module'] for r in generic} | {f'ImbalancedChen.P2OriginalSaving19ArchiveGeometryData{args.cell:02d}'}
    available = set(supplier_modules)
    for row in e.records:
        assert set(row['project_imports']) <= available, ('Non-topological import', row['module'], set(row['project_imports'])-available)
        available.add(row['module'])
    assert [fp(p) for p in sorted(USED_TEMPLATES)] == frozen
    assert fp(e.raw_origin) == original_input
    audit_source = audit_template.read_text()
    old_audit_module = 'ImbalancedChen.P2OriginalSaving19Geometry05ScalableInput'
    assert audit_source.count(old_audit_module) == 2
    for row in e.records:
        short = row['module'].split('.')[-1]
        actual = create(output / 'project/ImbalancedChen' / (short + '.lean'), e.buffers[short])
        assert actual == row['source']
        row['audit'] = create(output / 'owned-audits' / (short + '.lean'), audit_source.replace(old_audit_module, row['module']))
    restored = json.loads(recovery_path.read_text())
    selected_recovery = [fp(r['path']) for r in restored['restored'] if r['module'] == 'ImbalancedChen.P2OriginalSaving19ArchiveGeometryData06']
    for got in selected_recovery:
        expected = next(r for r in restored['restored'] if r['path'] == got['path'])
        assert all(got[k] == expected[k] for k in ('bytes','sha256'))
    manifest = {
        'schema': 'p26_original_geometry_parameterized_source_candidates_v1', 'status': 'SOURCE_CANDIDATE',
        'cell': args.cell, 'repo_readonly': str(repo), 'output_root': str(output),
        'original_input': original_input, 'root_end': e.node.end, 'tail_hex': e.raw[e.node.end:].hex(),
        'original_field_order': [f.key.scalar for f in e.node.fields],
        'counts_host_plan': {'geometry_owners': geometry_count, 'shape_owners': len(e.records)-geometry_count,
                             'targets': len(e.records), 'rows': e.row_count, 'vertices': e.vertex_count, 'faces': e.face_count,
                             'future_normal_kernel_owned_steps': 3*len(e.records)},
        'row_leaves': [g for g in e.block_plan('simplices')[1]], 'row_nodes_postorder': e.row_nodes,
        'array_roots': e.roots, 'required_local_shape_declarations': e.required_local_shape,
        'owners': e.records, 'existing_template_and_supplier_source_pins': frozen,
        'generator': fp(Path(__file__)), 'checker': fp(Path(__file__).with_name('check_geometry.py')),
        'implementation_plan': fp(output / 'IMPLEMENTATION_PLAN.md'),
        'render_method_adaptations': TRANSFORMS,
        'whole_shape_source_adaptations': {'template': fp(shape_template), 'literal_replacements': shape_changes,
                                           'numeric_template_replacements': numbers,
                                           'standalone_row_node_regex': r'(?<![A-Za-z0-9_])Node000To006\b',
                                           'standalone_row_node_replacement': e.row_root_name},
        'generic_supplier_historical_pins': generic,
        'recovery_report': fp(recovery_path), 'recovered_data06_files_checked': selected_recovery,
        'raw_parser_changed': False, 'typed_decoder_changed': False, 'original_input_changed': False,
        'new_Lean_commands': 0, 'lake_commands': 0, 'MCP_jobs_submitted': 0,
        'normal_steps_accepted': 0, 'kernel_steps_accepted': 0, 'owned_steps_accepted': 0,
        'formal_acceptance': False, 'P2_6_complete': False,
        'scope': 'Candidate full original packed-byte parser/decoder equations plus finite shape; no determinant/coverage/volume/integral semantics.',
        'unverified': ['All 153 candidate sources require actual Lean normal compilation, independent kernel replay and full-owned audit.',
                       'Restored Data06 object bytes do not close historical receipt or current dependency-context acceptance.',
                       'No complete Archive.geometry Fin6 projection owner is included.',
                       'No geometric coverage, disjointness, determinant, physical-volume or integral meaning is established.']}
    create(output / 'owner_order.txt', ''.join(r['module']+'\n' for r in e.records))
    create(output / 'SOURCE_MANIFEST.json', manifest)
    print(json.dumps({'status':'SOURCE_CANDIDATE','targets':len(e.records),'geometry':geometry_count,
                      'shape':len(e.records)-geometry_count,'formal_acceptance':False,'new_Lean_commands':0,
                      'manifest':str(output/'SOURCE_MANIFEST.json')}))


if __name__ == '__main__':
    main()
