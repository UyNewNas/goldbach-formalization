import ImbalancedChen.P2OriginalSaving19Geometry06ScalableSimplicesField

/-! Exact original physical_volume field and original comma.
The original packed input, original parser and original decoder are unchanged.
This is a source-only candidate until normal, kernel and full-owned checks pass. -/
namespace ImbalancedChen.P2OriginalSaving19Geometry06ScalableParsing
set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false
open ImbalancedChen.P2OriginalSaving19Archive
open ImbalancedChen.P2OriginalSaving19PackedChars

namespace PhysicalVolumeField

noncomputable def fieldChars : List Char := ['\r', '\n', ' ', ' ', '"', 'p', 'h', 'y', 's', 'i', 'c', 'a', 'l', '_', 'v', 'o', 'l', 'u', 'm', 'e', '"', ':', ' ', '"', '1', '2', '0', '4', '6', '3', '3', '1', '5', '9', '0', '7', '2', '5', '1', '4', '9', '7', '8', '3', '7', '6', '1', '1', '5', '0', '9', '9', '1', '6', '7', '9', '6', '1', '9', '8', '0', '7', '9', '2', '1', '6', '2', '1', '4', '8', '2', '0', '9', '1', '8', '0', '0', '4', '9', '4', '8', '0', '4', '8', '6', '1', '8', '3', '/', '5', '3', '7', '4', '8', '6', '8', '4', '1', '5', '8', '0', '2', '0', '3', '0', '8', '0', '4', '9', '7', '2', '1', '7', '5', '6', '2', '2', '1', '4', '4', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '"', ',']
noncomputable def fieldKey : String := String.ofList ['p', 'h', 'y', 's', 'i', 'c', 'a', 'l', '_', 'v', 'o', 'l', 'u', 'm', 'e']
noncomputable def fieldValue : SourceJson := .str (String.ofList ['1', '2', '0', '4', '6', '3', '3', '1', '5', '9', '0', '7', '2', '5', '1', '4', '9', '7', '8', '3', '7', '6', '1', '1', '5', '0', '9', '9', '1', '6', '7', '9', '6', '1', '9', '8', '0', '7', '9', '2', '1', '6', '2', '1', '4', '8', '2', '0', '9', '1', '8', '0', '0', '4', '9', '4', '8', '0', '4', '8', '6', '1', '8', '3', '/', '5', '3', '7', '4', '8', '6', '8', '4', '1', '5', '8', '0', '2', '0', '3', '0', '8', '0', '4', '9', '7', '2', '1', '7', '5', '6', '2', '2', '1', '4', '4', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0'])
noncomputable def fieldAcc : List (String × SourceJson) := (fieldKey, fieldValue) :: SimplicesField.fieldAcc

theorem object_scalar (fuel : Nat) (tail : List Char) :
    SourceJson.object (fuel + 151) (SourceJson.white (fieldChars ++ tail)) SimplicesField.fieldAcc =
      SourceJson.object (fuel + 150) (SourceJson.white tail) fieldAcc := by rfl

theorem field_original_prefix :
    (sourceRest 335469).take 174 = fieldChars := by rfl

theorem field_original_split : sourceRest 335469 = fieldChars ++ sourceRest 335643 := by
  calc
    sourceRest 335469 = (sourceRest 335469).take 174 ++ (sourceRest 335469).drop 174 :=
      (List.take_append_drop 174 (sourceRest 335469)).symm
    _ = fieldChars ++ (sourceRest 335469).drop 174 :=
      congrArg (fun part => part ++ (sourceRest 335469).drop 174) field_original_prefix
    _ = fieldChars ++ sourceRest 335643 :=
      congrArg (fun tail => fieldChars ++ tail) (sourceRest_drop 335469 174)

theorem object_original_field :
    SourceJson.object 335837 (SourceJson.white (sourceRest 335469)) SimplicesField.fieldAcc =
      SourceJson.object 335836 (SourceJson.white (sourceRest 335643)) fieldAcc :=
  (congrArg (fun chars => SourceJson.object 335837 (SourceJson.white chars) SimplicesField.fieldAcc)
    field_original_split).trans (object_scalar 335686 (sourceRest 335643))

theorem sourceChars_through_field :
    SourceJson.value 335850 sourceChars =
      SourceJson.object 335836 (SourceJson.white (sourceRest 335643)) fieldAcc :=
  SimplicesField.sourceChars_through_field.trans object_original_field

#print axioms object_scalar
#print axioms field_original_prefix
#print axioms field_original_split
#print axioms object_original_field
#print axioms sourceChars_through_field

end PhysicalVolumeField

end ImbalancedChen.P2OriginalSaving19Geometry06ScalableParsing
