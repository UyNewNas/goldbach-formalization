import ImbalancedChen.P2OriginalSaving19Geometry06ScalableRowsNode000To014

/-! Finite local shape for all 113 original typed rows.
All input lists come from the original parser-bound typed leaf networks.
This source-only candidate has no geometric or integral interpretation. -/
namespace ImbalancedChen.P2OriginalSaving19Geometry06ScalableShape.Rows
set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false
open ImbalancedChen.P2OriginalSaving19Archive
open ImbalancedChen.P2OriginalSaving19Geometry06ScalableDecoding

noncomputable def RowShape (vertexCount : Nat) (row : GeometryRow) : Prop :=
  row.vertexIds.size = 9 ∧ row.vertexIds.toList.Nodup ∧
  (∀ i : Fin 9, row.vertexIds[i.val]! < vertexCount) ∧
  row.factorMaxima.size = 10 ∧ row.gapWeightedMeans.size = 10

theorem rows_000_to_000_shape : ∀ row ∈ geometryRowsTypedBlock000, RowShape 33 row := by
  intro item hitem
  simp only [geometryRowsTypedBlock000, List.mem_cons, List.not_mem_nil, or_false] at hitem
  rcases hitem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact geometryRow000_shape.2
  · exact geometryRow001_shape.2
  · exact geometryRow002_shape.2
  · exact geometryRow003_shape.2
  · exact geometryRow004_shape.2
  · exact geometryRow005_shape.2
  · exact geometryRow006_shape.2
  · exact geometryRow007_shape.2

theorem rows_001_to_001_shape : ∀ row ∈ geometryRowsTypedBlock001, RowShape 33 row := by
  intro item hitem
  simp only [geometryRowsTypedBlock001, List.mem_cons, List.not_mem_nil, or_false] at hitem
  rcases hitem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact geometryRow008_shape.2
  · exact geometryRow009_shape.2
  · exact geometryRow010_shape.2
  · exact geometryRow011_shape.2
  · exact geometryRow012_shape.2
  · exact geometryRow013_shape.2
  · exact geometryRow014_shape.2
  · exact geometryRow015_shape.2

theorem rows_002_to_002_shape : ∀ row ∈ geometryRowsTypedBlock002, RowShape 33 row := by
  intro item hitem
  simp only [geometryRowsTypedBlock002, List.mem_cons, List.not_mem_nil, or_false] at hitem
  rcases hitem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact geometryRow016_shape.2
  · exact geometryRow017_shape.2
  · exact geometryRow018_shape.2
  · exact geometryRow019_shape.2
  · exact geometryRow020_shape.2
  · exact geometryRow021_shape.2
  · exact geometryRow022_shape.2
  · exact geometryRow023_shape.2

theorem rows_003_to_003_shape : ∀ row ∈ geometryRowsTypedBlock003, RowShape 33 row := by
  intro item hitem
  simp only [geometryRowsTypedBlock003, List.mem_cons, List.not_mem_nil, or_false] at hitem
  rcases hitem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact geometryRow024_shape.2
  · exact geometryRow025_shape.2
  · exact geometryRow026_shape.2
  · exact geometryRow027_shape.2
  · exact geometryRow028_shape.2
  · exact geometryRow029_shape.2
  · exact geometryRow030_shape.2
  · exact geometryRow031_shape.2

theorem rows_004_to_004_shape : ∀ row ∈ geometryRowsTypedBlock004, RowShape 33 row := by
  intro item hitem
  simp only [geometryRowsTypedBlock004, List.mem_cons, List.not_mem_nil, or_false] at hitem
  rcases hitem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact geometryRow032_shape.2
  · exact geometryRow033_shape.2
  · exact geometryRow034_shape.2
  · exact geometryRow035_shape.2
  · exact geometryRow036_shape.2
  · exact geometryRow037_shape.2
  · exact geometryRow038_shape.2
  · exact geometryRow039_shape.2

theorem rows_005_to_005_shape : ∀ row ∈ geometryRowsTypedBlock005, RowShape 33 row := by
  intro item hitem
  simp only [geometryRowsTypedBlock005, List.mem_cons, List.not_mem_nil, or_false] at hitem
  rcases hitem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact geometryRow040_shape.2
  · exact geometryRow041_shape.2
  · exact geometryRow042_shape.2
  · exact geometryRow043_shape.2
  · exact geometryRow044_shape.2
  · exact geometryRow045_shape.2
  · exact geometryRow046_shape.2
  · exact geometryRow047_shape.2

theorem rows_006_to_006_shape : ∀ row ∈ geometryRowsTypedBlock006, RowShape 33 row := by
  intro item hitem
  simp only [geometryRowsTypedBlock006, List.mem_cons, List.not_mem_nil, or_false] at hitem
  rcases hitem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact geometryRow048_shape.2
  · exact geometryRow049_shape.2
  · exact geometryRow050_shape.2
  · exact geometryRow051_shape.2
  · exact geometryRow052_shape.2
  · exact geometryRow053_shape.2
  · exact geometryRow054_shape.2
  · exact geometryRow055_shape.2

theorem rows_007_to_007_shape : ∀ row ∈ geometryRowsTypedBlock007, RowShape 33 row := by
  intro item hitem
  simp only [geometryRowsTypedBlock007, List.mem_cons, List.not_mem_nil, or_false] at hitem
  rcases hitem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact geometryRow056_shape.2
  · exact geometryRow057_shape.2
  · exact geometryRow058_shape.2
  · exact geometryRow059_shape.2
  · exact geometryRow060_shape.2
  · exact geometryRow061_shape.2
  · exact geometryRow062_shape.2
  · exact geometryRow063_shape.2

theorem rows_008_to_008_shape : ∀ row ∈ geometryRowsTypedBlock008, RowShape 33 row := by
  intro item hitem
  simp only [geometryRowsTypedBlock008, List.mem_cons, List.not_mem_nil, or_false] at hitem
  rcases hitem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact geometryRow064_shape.2
  · exact geometryRow065_shape.2
  · exact geometryRow066_shape.2
  · exact geometryRow067_shape.2
  · exact geometryRow068_shape.2
  · exact geometryRow069_shape.2
  · exact geometryRow070_shape.2
  · exact geometryRow071_shape.2

theorem rows_009_to_009_shape : ∀ row ∈ geometryRowsTypedBlock009, RowShape 33 row := by
  intro item hitem
  simp only [geometryRowsTypedBlock009, List.mem_cons, List.not_mem_nil, or_false] at hitem
  rcases hitem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact geometryRow072_shape.2
  · exact geometryRow073_shape.2
  · exact geometryRow074_shape.2
  · exact geometryRow075_shape.2
  · exact geometryRow076_shape.2
  · exact geometryRow077_shape.2
  · exact geometryRow078_shape.2
  · exact geometryRow079_shape.2

theorem rows_010_to_010_shape : ∀ row ∈ geometryRowsTypedBlock010, RowShape 33 row := by
  intro item hitem
  simp only [geometryRowsTypedBlock010, List.mem_cons, List.not_mem_nil, or_false] at hitem
  rcases hitem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact geometryRow080_shape.2
  · exact geometryRow081_shape.2
  · exact geometryRow082_shape.2
  · exact geometryRow083_shape.2
  · exact geometryRow084_shape.2
  · exact geometryRow085_shape.2
  · exact geometryRow086_shape.2
  · exact geometryRow087_shape.2

theorem rows_011_to_011_shape : ∀ row ∈ geometryRowsTypedBlock011, RowShape 33 row := by
  intro item hitem
  simp only [geometryRowsTypedBlock011, List.mem_cons, List.not_mem_nil, or_false] at hitem
  rcases hitem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact geometryRow088_shape.2
  · exact geometryRow089_shape.2
  · exact geometryRow090_shape.2
  · exact geometryRow091_shape.2
  · exact geometryRow092_shape.2
  · exact geometryRow093_shape.2
  · exact geometryRow094_shape.2
  · exact geometryRow095_shape.2

theorem rows_012_to_012_shape : ∀ row ∈ geometryRowsTypedBlock012, RowShape 33 row := by
  intro item hitem
  simp only [geometryRowsTypedBlock012, List.mem_cons, List.not_mem_nil, or_false] at hitem
  rcases hitem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact geometryRow096_shape.2
  · exact geometryRow097_shape.2
  · exact geometryRow098_shape.2
  · exact geometryRow099_shape.2
  · exact geometryRow100_shape.2
  · exact geometryRow101_shape.2
  · exact geometryRow102_shape.2
  · exact geometryRow103_shape.2

theorem rows_013_to_013_shape : ∀ row ∈ geometryRowsTypedBlock013, RowShape 33 row := by
  intro item hitem
  simp only [geometryRowsTypedBlock013, List.mem_cons, List.not_mem_nil, or_false] at hitem
  rcases hitem with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact geometryRow104_shape.2
  · exact geometryRow105_shape.2
  · exact geometryRow106_shape.2
  · exact geometryRow107_shape.2
  · exact geometryRow108_shape.2
  · exact geometryRow109_shape.2
  · exact geometryRow110_shape.2
  · exact geometryRow111_shape.2

theorem rows_014_to_014_shape : ∀ row ∈ geometryRowsTypedBlock014, RowShape 33 row := by
  intro item hitem
  simp only [geometryRowsTypedBlock014, List.mem_cons, List.not_mem_nil, or_false] at hitem
  rcases hitem with rfl
  · exact geometryRow112_shape.2

theorem rows_000_to_001_shape : ∀ row ∈ Node000To001.typedRows, RowShape 33 row := by
  intro row hrow
  change row ∈ geometryRowsTypedBlock000 ++ geometryRowsTypedBlock001 at hrow
  exact (List.mem_append.mp hrow).elim (rows_000_to_000_shape row) (rows_001_to_001_shape row)

theorem rows_002_to_003_shape : ∀ row ∈ Node002To003.typedRows, RowShape 33 row := by
  intro row hrow
  change row ∈ geometryRowsTypedBlock002 ++ geometryRowsTypedBlock003 at hrow
  exact (List.mem_append.mp hrow).elim (rows_002_to_002_shape row) (rows_003_to_003_shape row)

theorem rows_000_to_003_shape : ∀ row ∈ Node000To003.typedRows, RowShape 33 row := by
  intro row hrow
  change row ∈ Node000To001.typedRows ++ Node002To003.typedRows at hrow
  exact (List.mem_append.mp hrow).elim (rows_000_to_001_shape row) (rows_002_to_003_shape row)

theorem rows_004_to_005_shape : ∀ row ∈ Node004To005.typedRows, RowShape 33 row := by
  intro row hrow
  change row ∈ geometryRowsTypedBlock004 ++ geometryRowsTypedBlock005 at hrow
  exact (List.mem_append.mp hrow).elim (rows_004_to_004_shape row) (rows_005_to_005_shape row)

theorem rows_006_to_007_shape : ∀ row ∈ Node006To007.typedRows, RowShape 33 row := by
  intro row hrow
  change row ∈ geometryRowsTypedBlock006 ++ geometryRowsTypedBlock007 at hrow
  exact (List.mem_append.mp hrow).elim (rows_006_to_006_shape row) (rows_007_to_007_shape row)

theorem rows_004_to_007_shape : ∀ row ∈ Node004To007.typedRows, RowShape 33 row := by
  intro row hrow
  change row ∈ Node004To005.typedRows ++ Node006To007.typedRows at hrow
  exact (List.mem_append.mp hrow).elim (rows_004_to_005_shape row) (rows_006_to_007_shape row)

theorem rows_000_to_007_shape : ∀ row ∈ Node000To007.typedRows, RowShape 33 row := by
  intro row hrow
  change row ∈ Node000To003.typedRows ++ Node004To007.typedRows at hrow
  exact (List.mem_append.mp hrow).elim (rows_000_to_003_shape row) (rows_004_to_007_shape row)

theorem rows_008_to_009_shape : ∀ row ∈ Node008To009.typedRows, RowShape 33 row := by
  intro row hrow
  change row ∈ geometryRowsTypedBlock008 ++ geometryRowsTypedBlock009 at hrow
  exact (List.mem_append.mp hrow).elim (rows_008_to_008_shape row) (rows_009_to_009_shape row)

theorem rows_010_to_011_shape : ∀ row ∈ Node010To011.typedRows, RowShape 33 row := by
  intro row hrow
  change row ∈ geometryRowsTypedBlock010 ++ geometryRowsTypedBlock011 at hrow
  exact (List.mem_append.mp hrow).elim (rows_010_to_010_shape row) (rows_011_to_011_shape row)

theorem rows_008_to_011_shape : ∀ row ∈ Node008To011.typedRows, RowShape 33 row := by
  intro row hrow
  change row ∈ Node008To009.typedRows ++ Node010To011.typedRows at hrow
  exact (List.mem_append.mp hrow).elim (rows_008_to_009_shape row) (rows_010_to_011_shape row)

theorem rows_012_to_013_shape : ∀ row ∈ Node012To013.typedRows, RowShape 33 row := by
  intro row hrow
  change row ∈ geometryRowsTypedBlock012 ++ geometryRowsTypedBlock013 at hrow
  exact (List.mem_append.mp hrow).elim (rows_012_to_012_shape row) (rows_013_to_013_shape row)

theorem rows_012_to_014_shape : ∀ row ∈ Node012To014.typedRows, RowShape 33 row := by
  intro row hrow
  change row ∈ Node012To013.typedRows ++ geometryRowsTypedBlock014 at hrow
  exact (List.mem_append.mp hrow).elim (rows_012_to_013_shape row) (rows_014_to_014_shape row)

theorem rows_008_to_014_shape : ∀ row ∈ Node008To014.typedRows, RowShape 33 row := by
  intro row hrow
  change row ∈ Node008To011.typedRows ++ Node012To014.typedRows at hrow
  exact (List.mem_append.mp hrow).elim (rows_008_to_011_shape row) (rows_012_to_014_shape row)

theorem rows_000_to_014_shape : ∀ row ∈ Node000To014.typedRows, RowShape 33 row := by
  intro row hrow
  change row ∈ Node000To007.typedRows ++ Node008To014.typedRows at hrow
  exact (List.mem_append.mp hrow).elim (rows_000_to_007_shape row) (rows_008_to_014_shape row)

theorem row_identifiers_block_000 : ∀ r : Fin 8,
    (Node000To014.typedRows.toArray[0 + r.val]!).simplexId = 0 + r.val := by
  decide +kernel

theorem row_identifiers_block_001 : ∀ r : Fin 8,
    (Node000To014.typedRows.toArray[8 + r.val]!).simplexId = 8 + r.val := by
  decide +kernel

theorem row_identifiers_block_002 : ∀ r : Fin 8,
    (Node000To014.typedRows.toArray[16 + r.val]!).simplexId = 16 + r.val := by
  decide +kernel

theorem row_identifiers_block_003 : ∀ r : Fin 8,
    (Node000To014.typedRows.toArray[24 + r.val]!).simplexId = 24 + r.val := by
  decide +kernel

theorem row_identifiers_block_004 : ∀ r : Fin 8,
    (Node000To014.typedRows.toArray[32 + r.val]!).simplexId = 32 + r.val := by
  decide +kernel

theorem row_identifiers_block_005 : ∀ r : Fin 8,
    (Node000To014.typedRows.toArray[40 + r.val]!).simplexId = 40 + r.val := by
  decide +kernel

theorem row_identifiers_block_006 : ∀ r : Fin 8,
    (Node000To014.typedRows.toArray[48 + r.val]!).simplexId = 48 + r.val := by
  decide +kernel

theorem row_identifiers_block_007 : ∀ r : Fin 8,
    (Node000To014.typedRows.toArray[56 + r.val]!).simplexId = 56 + r.val := by
  decide +kernel

theorem row_identifiers_block_008 : ∀ r : Fin 8,
    (Node000To014.typedRows.toArray[64 + r.val]!).simplexId = 64 + r.val := by
  decide +kernel

theorem row_identifiers_block_009 : ∀ r : Fin 8,
    (Node000To014.typedRows.toArray[72 + r.val]!).simplexId = 72 + r.val := by
  decide +kernel

theorem row_identifiers_block_010 : ∀ r : Fin 8,
    (Node000To014.typedRows.toArray[80 + r.val]!).simplexId = 80 + r.val := by
  decide +kernel

theorem row_identifiers_block_011 : ∀ r : Fin 8,
    (Node000To014.typedRows.toArray[88 + r.val]!).simplexId = 88 + r.val := by
  decide +kernel

theorem row_identifiers_block_012 : ∀ r : Fin 8,
    (Node000To014.typedRows.toArray[96 + r.val]!).simplexId = 96 + r.val := by
  decide +kernel

theorem row_identifiers_block_013 : ∀ r : Fin 8,
    (Node000To014.typedRows.toArray[104 + r.val]!).simplexId = 104 + r.val := by
  decide +kernel

theorem row_identifiers_block_014 : ∀ r : Fin 1,
    (Node000To014.typedRows.toArray[112 + r.val]!).simplexId = 112 + r.val := by
  decide +kernel

theorem all_row_identifiers : ∀ r : Fin 113,
    (Node000To014.typedRows.toArray[r.val]!).simplexId = r.val := by
  intro r
  have hr := r.isLt
  by_cases h0 : r.val < 8
  · simpa only [Nat.zero_add] using row_identifiers_block_000 ⟨r.val, h0⟩
  ·
    by_cases h1 : r.val < 16
    · have hb : r.val - 8 < 8 := by omega
      have he : 8 + (r.val - 8) = r.val := by omega
      simpa only [he] using row_identifiers_block_001 ⟨r.val - 8, hb⟩
    ·
      by_cases h2 : r.val < 24
      · have hb : r.val - 16 < 8 := by omega
        have he : 16 + (r.val - 16) = r.val := by omega
        simpa only [he] using row_identifiers_block_002 ⟨r.val - 16, hb⟩
      ·
        by_cases h3 : r.val < 32
        · have hb : r.val - 24 < 8 := by omega
          have he : 24 + (r.val - 24) = r.val := by omega
          simpa only [he] using row_identifiers_block_003 ⟨r.val - 24, hb⟩
        ·
          by_cases h4 : r.val < 40
          · have hb : r.val - 32 < 8 := by omega
            have he : 32 + (r.val - 32) = r.val := by omega
            simpa only [he] using row_identifiers_block_004 ⟨r.val - 32, hb⟩
          ·
            by_cases h5 : r.val < 48
            · have hb : r.val - 40 < 8 := by omega
              have he : 40 + (r.val - 40) = r.val := by omega
              simpa only [he] using row_identifiers_block_005 ⟨r.val - 40, hb⟩
            ·
              by_cases h6 : r.val < 56
              · have hb : r.val - 48 < 8 := by omega
                have he : 48 + (r.val - 48) = r.val := by omega
                simpa only [he] using row_identifiers_block_006 ⟨r.val - 48, hb⟩
              ·
                by_cases h7 : r.val < 64
                · have hb : r.val - 56 < 8 := by omega
                  have he : 56 + (r.val - 56) = r.val := by omega
                  simpa only [he] using row_identifiers_block_007 ⟨r.val - 56, hb⟩
                ·
                  by_cases h8 : r.val < 72
                  · have hb : r.val - 64 < 8 := by omega
                    have he : 64 + (r.val - 64) = r.val := by omega
                    simpa only [he] using row_identifiers_block_008 ⟨r.val - 64, hb⟩
                  ·
                    by_cases h9 : r.val < 80
                    · have hb : r.val - 72 < 8 := by omega
                      have he : 72 + (r.val - 72) = r.val := by omega
                      simpa only [he] using row_identifiers_block_009 ⟨r.val - 72, hb⟩
                    ·
                      by_cases h10 : r.val < 88
                      · have hb : r.val - 80 < 8 := by omega
                        have he : 80 + (r.val - 80) = r.val := by omega
                        simpa only [he] using row_identifiers_block_010 ⟨r.val - 80, hb⟩
                      ·
                        by_cases h11 : r.val < 96
                        · have hb : r.val - 88 < 8 := by omega
                          have he : 88 + (r.val - 88) = r.val := by omega
                          simpa only [he] using row_identifiers_block_011 ⟨r.val - 88, hb⟩
                        ·
                          by_cases h12 : r.val < 104
                          · have hb : r.val - 96 < 8 := by omega
                            have he : 96 + (r.val - 96) = r.val := by omega
                            simpa only [he] using row_identifiers_block_012 ⟨r.val - 96, hb⟩
                          ·
                            by_cases h13 : r.val < 112
                            · have hb : r.val - 104 < 8 := by omega
                              have he : 104 + (r.val - 104) = r.val := by omega
                              simpa only [he] using row_identifiers_block_013 ⟨r.val - 104, hb⟩
                            ·
                              have hb : r.val - 112 < 1 := by omega
                              have he : 112 + (r.val - 112) = r.val := by omega
                              simpa only [he] using row_identifiers_block_014 ⟨r.val - 112, hb⟩

#print axioms rows_000_to_000_shape
#print axioms rows_001_to_001_shape
#print axioms rows_002_to_002_shape
#print axioms rows_003_to_003_shape
#print axioms rows_004_to_004_shape
#print axioms rows_005_to_005_shape
#print axioms rows_006_to_006_shape
#print axioms rows_007_to_007_shape
#print axioms rows_008_to_008_shape
#print axioms rows_009_to_009_shape
#print axioms rows_010_to_010_shape
#print axioms rows_011_to_011_shape
#print axioms rows_012_to_012_shape
#print axioms rows_013_to_013_shape
#print axioms rows_014_to_014_shape
#print axioms rows_000_to_001_shape
#print axioms rows_002_to_003_shape
#print axioms rows_000_to_003_shape
#print axioms rows_004_to_005_shape
#print axioms rows_006_to_007_shape
#print axioms rows_004_to_007_shape
#print axioms rows_000_to_007_shape
#print axioms rows_008_to_009_shape
#print axioms rows_010_to_011_shape
#print axioms rows_008_to_011_shape
#print axioms rows_012_to_013_shape
#print axioms rows_012_to_014_shape
#print axioms rows_008_to_014_shape
#print axioms rows_000_to_014_shape
#print axioms row_identifiers_block_000
#print axioms row_identifiers_block_001
#print axioms row_identifiers_block_002
#print axioms row_identifiers_block_003
#print axioms row_identifiers_block_004
#print axioms row_identifiers_block_005
#print axioms row_identifiers_block_006
#print axioms row_identifiers_block_007
#print axioms row_identifiers_block_008
#print axioms row_identifiers_block_009
#print axioms row_identifiers_block_010
#print axioms row_identifiers_block_011
#print axioms row_identifiers_block_012
#print axioms row_identifiers_block_013
#print axioms row_identifiers_block_014
#print axioms all_row_identifiers
end ImbalancedChen.P2OriginalSaving19Geometry06ScalableShape.Rows
