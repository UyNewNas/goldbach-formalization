import ImbalancedChen.P2OriginalSaving19Geometry06ScalableRowsNode000To014

/-! Complete original simplices array value from a balanced tree.
The original packed input, original parser and original decoder are unchanged.
This is a source-only candidate until normal, kernel and full-owned checks pass. -/
namespace ImbalancedChen.P2OriginalSaving19Geometry06ScalableParsing
set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false
open ImbalancedChen.P2OriginalSaving19Archive
open ImbalancedChen.P2OriginalSaving19PackedChars

namespace SimplicesValue

noncomputable def arrayOpenChars : List Char := ['[']
noncomputable def arrayValue : SourceJson := .arr (ImbalancedChen.P2OriginalSaving19Geometry06ScalableDecoding.Node000To014.jsonRows)

theorem array_open_prefix :
    (sourceRest 124030).take 1 = arrayOpenChars := by rfl

theorem array_open_split : sourceRest 124030 = arrayOpenChars ++ sourceRest 124031 := by
  calc
    sourceRest 124030 = (sourceRest 124030).take 1 ++ (sourceRest 124030).drop 1 :=
      (List.take_append_drop 1 (sourceRest 124030)).symm
    _ = arrayOpenChars ++ (sourceRest 124030).drop 1 :=
      congrArg (fun part => part ++ (sourceRest 124030).drop 1) array_open_prefix
    _ = arrayOpenChars ++ sourceRest 124031 :=
      congrArg (fun tail => arrayOpenChars ++ tail) (sourceRest_drop 124030 1)

theorem value_array_open (fuel : Nat) :
    SourceJson.value (fuel + 658) (sourceRest 124030) =
      SourceJson.array (fuel + 657) (SourceJson.white (sourceRest 124031)) [] :=
  (congrArg (SourceJson.value (fuel + 658)) array_open_split).trans (by rfl)

theorem array_all_blocks (fuel : Nat) :
    SourceJson.array (fuel + 657) (SourceJson.white (sourceRest 124031)) [] =
      .ok (arrayValue, sourceRest 335468) := by
  simpa only [arrayValue, ImbalancedChen.P2OriginalSaving19Geometry06ScalableDecoding.Node000To014.blockPush_reverse, List.reverse_nil, List.nil_append]
    using (ImbalancedChen.P2OriginalSaving19Geometry06ScalableDecoding.Node000To014.array_original fuel [])

theorem value_array_original (fuel : Nat) :
    SourceJson.value (fuel + 658) (sourceRest 124030) =
      .ok (arrayValue, sourceRest 335468) :=
  (value_array_open fuel).trans (array_all_blocks fuel)

#print axioms array_open_prefix
#print axioms array_open_split
#print axioms value_array_open
#print axioms array_all_blocks
#print axioms value_array_original

end SimplicesValue

end ImbalancedChen.P2OriginalSaving19Geometry06ScalableParsing
