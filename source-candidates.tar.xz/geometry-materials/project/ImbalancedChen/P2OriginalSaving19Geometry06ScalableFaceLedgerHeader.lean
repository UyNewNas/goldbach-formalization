import ImbalancedChen.P2OriginalSaving19Geometry06ScalableFacetVerticesField

/-! Exact original object header; unchanged duplicate-key and error branches.
The original packed input, original parser and original decoder are unchanged.
This is a source-only candidate until normal, kernel and full-owned checks pass. -/
namespace ImbalancedChen.P2OriginalSaving19Geometry06ScalableParsing
set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false
open ImbalancedChen.P2OriginalSaving19Archive
open ImbalancedChen.P2OriginalSaving19PackedChars

namespace FaceLedgerField

noncomputable def headerChars : List Char := ['\r', '\n', ' ', ' ', '"', 'f', 'a', 'c', 'e', '_', 'l', 'e', 'd', 'g', 'e', 'r', '"', ':', ' ']
noncomputable def fieldKey : String := String.ofList ['f', 'a', 'c', 'e', '_', 'l', 'e', 'd', 'g', 'e', 'r']
noncomputable def afterValue (fuel : Nat) (result : SourceJson × List Char) :
    Except String (SourceJson × List Char) :=
  match SourceJson.white result.2 with
  | '}' :: ending => .ok (.obj (((fieldKey, result.1) :: FacetVerticesField.fieldAcc).reverse), ending)
  | ',' :: ending => SourceJson.object fuel (SourceJson.white ending) ((fieldKey, result.1) :: FacetVerticesField.fieldAcc)
  | _ => .error "object separator missing"

theorem object_header (fuel : Nat) (rest : List Char) :
    SourceJson.object (fuel + 82) (SourceJson.white (headerChars ++ rest)) FacetVerticesField.fieldAcc =
      (SourceJson.value (fuel + 81) rest).bind (afterValue (fuel + 81)) := by rfl

theorem header_original_prefix :
    (sourceRest 69068).take 19 = headerChars := by rfl

theorem header_original_split : sourceRest 69068 = headerChars ++ sourceRest 69087 := by
  calc
    sourceRest 69068 = (sourceRest 69068).take 19 ++ (sourceRest 69068).drop 19 :=
      (List.take_append_drop 19 (sourceRest 69068)).symm
    _ = headerChars ++ (sourceRest 69068).drop 19 :=
      congrArg (fun part => part ++ (sourceRest 69068).drop 19) header_original_prefix
    _ = headerChars ++ sourceRest 69087 :=
      congrArg (fun tail => headerChars ++ tail) (sourceRest_drop 69068 19)

theorem object_original_header (fuel : Nat) :
    SourceJson.object (fuel + 82) (SourceJson.white (sourceRest 69068)) FacetVerticesField.fieldAcc =
      (SourceJson.value (fuel + 81) (sourceRest 69087)).bind (afterValue (fuel + 81)) :=
  (congrArg (fun chars => SourceJson.object (fuel + 82) (SourceJson.white chars) FacetVerticesField.fieldAcc)
    header_original_split).trans (object_header fuel (sourceRest 69087))

theorem sourceChars_pending_value :
    SourceJson.value 335850 sourceChars =
      (SourceJson.value 335838 (sourceRest 69087)).bind (afterValue 335838) :=
  FacetVerticesField.sourceChars_through_field.trans (object_original_header 335757)

#print axioms object_header
#print axioms header_original_prefix
#print axioms header_original_split
#print axioms object_original_header
#print axioms sourceChars_pending_value

end FaceLedgerField

end ImbalancedChen.P2OriginalSaving19Geometry06ScalableParsing
