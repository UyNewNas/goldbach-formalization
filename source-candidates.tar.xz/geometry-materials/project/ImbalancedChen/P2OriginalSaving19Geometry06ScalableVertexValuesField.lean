import ImbalancedChen.P2OriginalSaving19Geometry06ScalableVertexValuesHeader
import ImbalancedChen.P2OriginalSaving19Geometry06ScalableVertexValuesValue

/-! Insert the completed original array into its original parent object.
The original packed input, original parser and original decoder are unchanged.
This is a source-only candidate until normal, kernel and full-owned checks pass. -/
namespace ImbalancedChen.P2OriginalSaving19Geometry06ScalableParsing
set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false
open ImbalancedChen.P2OriginalSaving19Archive
open ImbalancedChen.P2OriginalSaving19PackedChars

namespace VertexValuesField

noncomputable def separatorChars : List Char := [',']
noncomputable def fieldAcc : List (String × SourceJson) := (fieldKey, VertexValuesValue.arrayValue) :: VerticesField.fieldAcc

theorem after_value_separator (fuel : Nat) (tail : List Char) :
    (Except.ok (VertexValuesValue.arrayValue, separatorChars ++ tail)).bind (afterValue (fuel + 70)) =
      SourceJson.object (fuel + 70) (SourceJson.white tail) fieldAcc := by rfl

theorem separator_original_prefix :
    (sourceRest 63938).take 1 = separatorChars := by rfl

theorem separator_original_split : sourceRest 63938 = separatorChars ++ sourceRest 63939 := by
  calc
    sourceRest 63938 = (sourceRest 63938).take 1 ++ (sourceRest 63938).drop 1 :=
      (List.take_append_drop 1 (sourceRest 63938)).symm
    _ = separatorChars ++ (sourceRest 63938).drop 1 :=
      congrArg (fun part => part ++ (sourceRest 63938).drop 1) separator_original_prefix
    _ = separatorChars ++ sourceRest 63939 :=
      congrArg (fun tail => separatorChars ++ tail) (sourceRest_drop 63938 1)

theorem object_original_field (fuel : Nat) :
    SourceJson.object (fuel + 71) (SourceJson.white (sourceRest 48341)) VerticesField.fieldAcc =
      SourceJson.object (fuel + 70) (SourceJson.white (sourceRest 63939)) fieldAcc := by
  calc
    SourceJson.object (fuel + 71) (SourceJson.white (sourceRest 48341)) VerticesField.fieldAcc =
        (SourceJson.value (fuel + 70) (sourceRest 48362)).bind (afterValue (fuel + 70)) :=
      object_original_header fuel
    _ = (Except.ok (VertexValuesValue.arrayValue, sourceRest 63938)).bind (afterValue (fuel + 70)) :=
      congrArg (fun result => result.bind (afterValue (fuel + 70)))
        (VertexValuesValue.value_array_original (fuel + 0))
    _ = (Except.ok (VertexValuesValue.arrayValue, separatorChars ++ sourceRest 63939)).bind
          (afterValue (fuel + 70)) :=
      congrArg (fun rest => (Except.ok (VertexValuesValue.arrayValue, rest)).bind (afterValue (fuel + 70)))
        separator_original_split
    _ = SourceJson.object (fuel + 70) (SourceJson.white (sourceRest 63939)) fieldAcc :=
      after_value_separator fuel (sourceRest 63939)

theorem sourceChars_through_field :
    SourceJson.value 335850 sourceChars =
      SourceJson.object 335841 (SourceJson.white (sourceRest 63939)) fieldAcc :=
  VerticesField.sourceChars_through_field.trans (object_original_field 335771)

#print axioms after_value_separator
#print axioms separator_original_prefix
#print axioms separator_original_split
#print axioms object_original_field
#print axioms sourceChars_through_field

end VertexValuesField

end ImbalancedChen.P2OriginalSaving19Geometry06ScalableParsing
