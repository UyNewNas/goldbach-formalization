import ImbalancedChen.P2OriginalSaving19Geometry06ScalableDecoded
import ImbalancedChen.P2OriginalSaving19Geometry06ScalableShapeRows
import ImbalancedChen.P2OriginalSaving19Geometry06ScalableShapeArrays

/-! Complete finite shape of the actual original cell06 decoder output.
All input lists come from the original parser-bound typed leaf networks.
This source-only candidate has no geometric or integral interpretation. -/
namespace ImbalancedChen.P2OriginalSaving19Geometry06ScalableShape
set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false
open ImbalancedChen.P2OriginalSaving19Archive
open ImbalancedChen.P2OriginalSaving19Geometry06ScalableDecoding

open ImbalancedChen.P2OriginalSaving19Geometry06ScalableDecoding.Complete
open ImbalancedChen.P2OriginalSaving19Geometry06ScalableShape.Rows
open ImbalancedChen.P2OriginalSaving19Geometry06ScalableShape.Arrays

theorem property_of_list_toArray {α : Type} [Inhabited α]
    (items : List α) (property : α → Prop)
    (h : ∀ item ∈ items, property item) (index : Nat)
    (hi : index < items.toArray.size) : property (items.toArray[index]!) := by
  rw [getElem!_pos items.toArray index hi]
  apply h
  simp

theorem dimension : concreteGeometry06.dimension = 8 := by rfl
theorem physical_jacobian : concreteGeometry06.physicalJacobian = 1 := by rfl
theorem row_count : concreteGeometry06.rows.size = 113 := by rfl
theorem vertex_count : concreteGeometry06.vertices.size = 33 := by rfl
theorem vertex_values_count : concreteGeometry06.vertexValues.size = 33 := by rfl
theorem vertex_values_size : concreteGeometry06.vertexValues.size = concreteGeometry06.vertices.size := by rfl
theorem facet_count : concreteGeometry06.facetOriginalIndices.size = 11 := by rfl
theorem facet_vertices_count : concreteGeometry06.facetVertices.size = 11 := by rfl
theorem face_count : concreteGeometry06.faces.size = 62 := by rfl

theorem facet_original_indices_nodup : concreteGeometry06.facetOriginalIndices.toList.Nodup := by
  decide +kernel

theorem facet_original_indices_bound : ∀ i : Fin 11,
    concreteGeometry06.facetOriginalIndices[i.val]! < 97 := by
  decide +kernel

theorem all_rows : ∀ r : Fin 113,
    let row := concreteGeometry06.rows[r.val]!
    row.simplexId = r.val ∧
    row.vertexIds.size = 9 ∧ row.vertexIds.toList.Nodup ∧
    (∀ i : Fin 9, row.vertexIds[i.val]! < concreteGeometry06.vertices.size) ∧
    row.factorMaxima.size = 10 ∧ row.gapWeightedMeans.size = 10 := by
  intro r
  change (Node000To014.typedRows.toArray[r.val]!).simplexId = r.val ∧
    RowShape 33 (Node000To014.typedRows.toArray[r.val]!)
  exact ⟨all_row_identifiers r,
    property_of_list_toArray Node000To014.typedRows (RowShape 33)
      rows_000_to_014_shape r.val (by change r.val < 113; exact r.isLt)⟩

theorem all_vertices : ∀ v : Fin 33,
    (concreteGeometry06.vertices[v.val]!).size = concreteGeometry06.dimension ∧
    (concreteGeometry06.vertexValues[v.val]!).factors.size = 10 := by
  intro v
  change VertexShape 8 (VerticesNode000To002.typedItems.toArray[v.val]!) ∧
    ValueShape (VertexValuesNode000To004.typedItems.toArray[v.val]!)
  exact ⟨property_of_list_toArray VerticesNode000To002.typedItems (VertexShape 8)
      vertices_000_to_002_shape v.val (by change v.val < 33; exact v.isLt),
    property_of_list_toArray VertexValuesNode000To004.typedItems ValueShape
      vertex_values_000_to_004_shape v.val (by change v.val < 33; exact v.isLt)⟩

theorem all_facets : ∀ f : Fin 11,
    let facet := concreteGeometry06.facetVertices[f.val]!
    facet.toList.Nodup ∧
    (∀ i : Fin facet.size, facet[i.val]! < concreteGeometry06.vertices.size) := by
  intro f
  change FacetShape 33 (geometryFacetVerticesTypedBlock000.toArray[f.val]!)
  exact property_of_list_toArray geometryFacetVerticesTypedBlock000 (FacetShape 33)
    facet_vertices_000_to_000_shape f.val (by change f.val < 11; exact f.isLt)

theorem all_faces : ∀ f : Fin 62,
    let face := concreteGeometry06.faces[f.val]!
    face.vertices.toList.Nodup ∧
    (∀ i : Fin face.vertices.size, face.vertices[i.val]! < concreteGeometry06.vertices.size) ∧
    face.pivot < concreteGeometry06.vertices.size ∧ face.dimension ≤ concreteGeometry06.dimension := by
  intro f
  change FaceShape 33 8 (FaceLedgerNode000To006.typedItems.toArray[f.val]!)
  exact property_of_list_toArray FaceLedgerNode000To006.typedItems (FaceShape 33 8)
    face_ledger_000_to_006_shape f.val (by change f.val < 62; exact f.isLt)

structure GeometryShape (geometry : Geometry) : Prop where
  dimension : geometry.dimension = 8
  physicalJacobian : geometry.physicalJacobian = 1
  rowCount : geometry.rows.size = 113
  vertexCount : geometry.vertices.size = 33
  vertexValuesCount : geometry.vertexValues.size = 33
  facetCount : geometry.facetOriginalIndices.size = 11
  facetVerticesCount : geometry.facetVertices.size = 11
  faceCount : geometry.faces.size = 62
  facetIndicesNodup : geometry.facetOriginalIndices.toList.Nodup
  facetIndicesBound : ∀ i : Fin geometry.facetOriginalIndices.size,
    geometry.facetOriginalIndices[i.val]! < 97
  rows : ∀ r : Fin geometry.rows.size,
    let row := geometry.rows[r.val]!
    row.simplexId = r.val ∧ RowShape geometry.vertices.size row
  vertices : ∀ v : Fin geometry.vertices.size,
    (geometry.vertices[v.val]!).size = geometry.dimension ∧
    (geometry.vertexValues[v.val]!).factors.size = 10
  facets : ∀ f : Fin geometry.facetVertices.size,
    FacetShape geometry.vertices.size (geometry.facetVertices[f.val]!)
  faces : ∀ f : Fin geometry.faces.size,
    FaceShape geometry.vertices.size geometry.dimension (geometry.faces[f.val]!)

theorem concreteGeometry06_shape : GeometryShape concreteGeometry06 where
  dimension := dimension
  physicalJacobian := physical_jacobian
  rowCount := row_count
  vertexCount := vertex_count
  vertexValuesCount := vertex_values_count
  facetCount := facet_count
  facetVerticesCount := facet_vertices_count
  faceCount := face_count
  facetIndicesNodup := facet_original_indices_nodup
  facetIndicesBound := by
    intro i
    exact facet_original_indices_bound ⟨i.val, by simpa only [facet_count] using i.isLt⟩
  rows := by
    intro r
    exact all_rows ⟨r.val, by simpa only [row_count] using r.isLt⟩
  vertices := by
    intro v
    exact all_vertices ⟨v.val, by simpa only [vertex_count] using v.isLt⟩
  facets := by
    intro f
    exact all_facets ⟨f.val, by simpa only [facet_vertices_count] using f.isLt⟩
  faces := by
    intro f
    exact all_faces ⟨f.val, by simpa only [face_count] using f.isLt⟩

theorem geometryPacked06_parse_decode_shape :
    (SourceJson.parse (String.ofList geometryPacked06.toList) >>= decodeGeometry) =
      .ok concreteGeometry06 ∧ GeometryShape concreteGeometry06 :=
  ⟨geometryPacked06_parse_decode, concreteGeometry06_shape⟩

#print axioms property_of_list_toArray
#print axioms dimension
#print axioms physical_jacobian
#print axioms row_count
#print axioms vertex_count
#print axioms vertex_values_count
#print axioms vertex_values_size
#print axioms facet_count
#print axioms facet_vertices_count
#print axioms face_count
#print axioms facet_original_indices_nodup
#print axioms facet_original_indices_bound
#print axioms all_rows
#print axioms all_vertices
#print axioms all_facets
#print axioms all_faces
#print axioms concreteGeometry06_shape
#print axioms geometryPacked06_parse_decode_shape
end ImbalancedChen.P2OriginalSaving19Geometry06ScalableShape
