import ImbalancedChen.P2OriginalSaving19Geometry06ScalableVertexValuesNode000To004

/-! Complete original vertex_values array value from a balanced tree.
The original packed input, original parser and original decoder are unchanged.
This is a source-only candidate until normal, kernel and full-owned checks pass. -/
namespace ImbalancedChen.P2OriginalSaving19Geometry06ScalableParsing
set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false
open ImbalancedChen.P2OriginalSaving19Archive
open ImbalancedChen.P2OriginalSaving19PackedChars

namespace VertexValuesValue

noncomputable def arrayOpenChars : List Char := ['[']
noncomputable def arrayValue : SourceJson := .arr (ImbalancedChen.P2OriginalSaving19Geometry06ScalableDecoding.VertexValuesNode000To004.jsonItems)

theorem array_open_prefix :
    (sourceRest 48362).take 1 = arrayOpenChars := by rfl

theorem array_open_split : sourceRest 48362 = arrayOpenChars ++ sourceRest 48363 := by
  calc
    sourceRest 48362 = (sourceRest 48362).take 1 ++ (sourceRest 48362).drop 1 :=
      (List.take_append_drop 1 (sourceRest 48362)).symm
    _ = arrayOpenChars ++ (sourceRest 48362).drop 1 :=
      congrArg (fun part => part ++ (sourceRest 48362).drop 1) array_open_prefix
    _ = arrayOpenChars ++ sourceRest 48363 :=
      congrArg (fun tail => arrayOpenChars ++ tail) (sourceRest_drop 48362 1)

theorem value_array_open (fuel : Nat) :
    SourceJson.value (fuel + 70) (sourceRest 48362) =
      SourceJson.array (fuel + 69) (SourceJson.white (sourceRest 48363)) [] :=
  (congrArg (SourceJson.value (fuel + 70)) array_open_split).trans (by rfl)

theorem array_all_blocks (fuel : Nat) :
    SourceJson.array (fuel + 69) (SourceJson.white (sourceRest 48363)) [] =
      .ok (arrayValue, sourceRest 63938) := by
  simpa only [arrayValue, ImbalancedChen.P2OriginalSaving19Geometry06ScalableDecoding.VertexValuesNode000To004.blockPush_reverse, List.reverse_nil, List.nil_append]
    using (ImbalancedChen.P2OriginalSaving19Geometry06ScalableDecoding.VertexValuesNode000To004.array_original fuel [])

theorem value_array_original (fuel : Nat) :
    SourceJson.value (fuel + 70) (sourceRest 48362) =
      .ok (arrayValue, sourceRest 63938) :=
  (value_array_open fuel).trans (array_all_blocks fuel)

#print axioms array_open_prefix
#print axioms array_open_split
#print axioms value_array_open
#print axioms array_all_blocks
#print axioms value_array_original

end VertexValuesValue

end ImbalancedChen.P2OriginalSaving19Geometry06ScalableParsing
