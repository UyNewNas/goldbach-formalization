import ImbalancedChen.P2OriginalSaving19Geometry06ScalableVerticesHeader
import ImbalancedChen.P2OriginalSaving19Geometry06ScalableVerticesValue

/-! Insert the completed original array into its original parent object.
The original packed input, original parser and original decoder are unchanged.
This is a source-only candidate until normal, kernel and full-owned checks pass. -/
namespace ImbalancedChen.P2OriginalSaving19Geometry06ScalableParsing
set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false
open ImbalancedChen.P2OriginalSaving19Archive
open ImbalancedChen.P2OriginalSaving19PackedChars

namespace VerticesField

noncomputable def separatorChars : List Char := [',']
noncomputable def fieldAcc : List (String × SourceJson) := (fieldKey, VerticesValue.arrayValue) :: Active8EnumerationField.fieldAcc

theorem after_value_separator (fuel : Nat) (tail : List Char) :
    (Except.ok (VerticesValue.arrayValue, separatorChars ++ tail)).bind (afterValue (fuel + 61)) =
      SourceJson.object (fuel + 61) (SourceJson.white tail) fieldAcc := by rfl

theorem separator_original_prefix :
    (sourceRest 48340).take 1 = separatorChars := by rfl

theorem separator_original_split : sourceRest 48340 = separatorChars ++ sourceRest 48341 := by
  calc
    sourceRest 48340 = (sourceRest 48340).take 1 ++ (sourceRest 48340).drop 1 :=
      (List.take_append_drop 1 (sourceRest 48340)).symm
    _ = separatorChars ++ (sourceRest 48340).drop 1 :=
      congrArg (fun part => part ++ (sourceRest 48340).drop 1) separator_original_prefix
    _ = separatorChars ++ sourceRest 48341 :=
      congrArg (fun tail => separatorChars ++ tail) (sourceRest_drop 48340 1)

theorem object_original_field (fuel : Nat) :
    SourceJson.object (fuel + 62) (SourceJson.white (sourceRest 41102)) Active8EnumerationField.fieldAcc =
      SourceJson.object (fuel + 61) (SourceJson.white (sourceRest 48341)) fieldAcc := by
  calc
    SourceJson.object (fuel + 62) (SourceJson.white (sourceRest 41102)) Active8EnumerationField.fieldAcc =
        (SourceJson.value (fuel + 61) (sourceRest 41118)).bind (afterValue (fuel + 61)) :=
      object_original_header fuel
    _ = (Except.ok (VerticesValue.arrayValue, sourceRest 48340)).bind (afterValue (fuel + 61)) :=
      congrArg (fun result => result.bind (afterValue (fuel + 61)))
        (VerticesValue.value_array_original (fuel + 0))
    _ = (Except.ok (VerticesValue.arrayValue, separatorChars ++ sourceRest 48341)).bind
          (afterValue (fuel + 61)) :=
      congrArg (fun rest => (Except.ok (VerticesValue.arrayValue, rest)).bind (afterValue (fuel + 61)))
        separator_original_split
    _ = SourceJson.object (fuel + 61) (SourceJson.white (sourceRest 48341)) fieldAcc :=
      after_value_separator fuel (sourceRest 48341)

theorem sourceChars_through_field :
    SourceJson.value 335850 sourceChars =
      SourceJson.object 335842 (SourceJson.white (sourceRest 48341)) fieldAcc :=
  Active8EnumerationField.sourceChars_through_field.trans (object_original_field 335781)

#print axioms after_value_separator
#print axioms separator_original_prefix
#print axioms separator_original_split
#print axioms object_original_field
#print axioms sourceChars_through_field

end VerticesField

end ImbalancedChen.P2OriginalSaving19Geometry06ScalableParsing
