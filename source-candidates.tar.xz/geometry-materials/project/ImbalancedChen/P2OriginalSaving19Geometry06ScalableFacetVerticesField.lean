import ImbalancedChen.P2OriginalSaving19Geometry06ScalableFacetVerticesHeader
import ImbalancedChen.P2OriginalSaving19Geometry06ScalableFacetVerticesValue

/-! Insert the completed original array into its original parent object.
The original packed input, original parser and original decoder are unchanged.
This is a source-only candidate until normal, kernel and full-owned checks pass. -/
namespace ImbalancedChen.P2OriginalSaving19Geometry06ScalableParsing
set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false
open ImbalancedChen.P2OriginalSaving19Archive
open ImbalancedChen.P2OriginalSaving19PackedChars

namespace FacetVerticesField

noncomputable def separatorChars : List Char := [',']
noncomputable def fieldAcc : List (String × SourceJson) := (fieldKey, FacetVerticesValue.arrayValue) :: AllOriginalConstraintMinimaField.fieldAcc

theorem after_value_separator (fuel : Nat) (tail : List Char) :
    (Except.ok (FacetVerticesValue.arrayValue, separatorChars ++ tail)).bind (afterValue (fuel + 42)) =
      SourceJson.object (fuel + 42) (SourceJson.white tail) fieldAcc := by rfl

theorem separator_original_prefix :
    (sourceRest 69067).take 1 = separatorChars := by rfl

theorem separator_original_split : sourceRest 69067 = separatorChars ++ sourceRest 69068 := by
  calc
    sourceRest 69067 = (sourceRest 69067).take 1 ++ (sourceRest 69067).drop 1 :=
      (List.take_append_drop 1 (sourceRest 69067)).symm
    _ = separatorChars ++ (sourceRest 69067).drop 1 :=
      congrArg (fun part => part ++ (sourceRest 69067).drop 1) separator_original_prefix
    _ = separatorChars ++ sourceRest 69068 :=
      congrArg (fun tail => separatorChars ++ tail) (sourceRest_drop 69067 1)

theorem object_original_field (fuel : Nat) :
    SourceJson.object (fuel + 43) (SourceJson.white (sourceRest 66062)) AllOriginalConstraintMinimaField.fieldAcc =
      SourceJson.object (fuel + 42) (SourceJson.white (sourceRest 69068)) fieldAcc := by
  calc
    SourceJson.object (fuel + 43) (SourceJson.white (sourceRest 66062)) AllOriginalConstraintMinimaField.fieldAcc =
        (SourceJson.value (fuel + 42) (sourceRest 66084)).bind (afterValue (fuel + 42)) :=
      object_original_header fuel
    _ = (Except.ok (FacetVerticesValue.arrayValue, sourceRest 69067)).bind (afterValue (fuel + 42)) :=
      congrArg (fun result => result.bind (afterValue (fuel + 42)))
        (FacetVerticesValue.value_array_original (fuel + 0))
    _ = (Except.ok (FacetVerticesValue.arrayValue, separatorChars ++ sourceRest 69068)).bind
          (afterValue (fuel + 42)) :=
      congrArg (fun rest => (Except.ok (FacetVerticesValue.arrayValue, rest)).bind (afterValue (fuel + 42)))
        separator_original_split
    _ = SourceJson.object (fuel + 42) (SourceJson.white (sourceRest 69068)) fieldAcc :=
      after_value_separator fuel (sourceRest 69068)

theorem sourceChars_through_field :
    SourceJson.value 335850 sourceChars =
      SourceJson.object 335839 (SourceJson.white (sourceRest 69068)) fieldAcc :=
  AllOriginalConstraintMinimaField.sourceChars_through_field.trans (object_original_field 335797)

#print axioms after_value_separator
#print axioms separator_original_prefix
#print axioms separator_original_split
#print axioms object_original_field
#print axioms sourceChars_through_field

end FacetVerticesField

end ImbalancedChen.P2OriginalSaving19Geometry06ScalableParsing
