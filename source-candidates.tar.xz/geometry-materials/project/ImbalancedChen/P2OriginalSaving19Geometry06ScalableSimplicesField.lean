import ImbalancedChen.P2OriginalSaving19Geometry06ScalableSimplicesHeader
import ImbalancedChen.P2OriginalSaving19Geometry06ScalableSimplicesValue

/-! Insert the completed original array into its original parent object.
The original packed input, original parser and original decoder are unchanged.
This is a source-only candidate until normal, kernel and full-owned checks pass. -/
namespace ImbalancedChen.P2OriginalSaving19Geometry06ScalableParsing
set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false
open ImbalancedChen.P2OriginalSaving19Archive
open ImbalancedChen.P2OriginalSaving19PackedChars

namespace SimplicesField

noncomputable def separatorChars : List Char := [',']
noncomputable def fieldAcc : List (String × SourceJson) := (fieldKey, SimplicesValue.arrayValue) :: FaceLedgerField.fieldAcc

theorem after_value_separator (fuel : Nat) (tail : List Char) :
    (Except.ok (SimplicesValue.arrayValue, separatorChars ++ tail)).bind (afterValue (fuel + 658)) =
      SourceJson.object (fuel + 658) (SourceJson.white tail) fieldAcc := by rfl

theorem separator_original_prefix :
    (sourceRest 335468).take 1 = separatorChars := by rfl

theorem separator_original_split : sourceRest 335468 = separatorChars ++ sourceRest 335469 := by
  calc
    sourceRest 335468 = (sourceRest 335468).take 1 ++ (sourceRest 335468).drop 1 :=
      (List.take_append_drop 1 (sourceRest 335468)).symm
    _ = separatorChars ++ (sourceRest 335468).drop 1 :=
      congrArg (fun part => part ++ (sourceRest 335468).drop 1) separator_original_prefix
    _ = separatorChars ++ sourceRest 335469 :=
      congrArg (fun tail => separatorChars ++ tail) (sourceRest_drop 335468 1)

theorem object_original_field (fuel : Nat) :
    SourceJson.object (fuel + 659) (SourceJson.white (sourceRest 124013)) FaceLedgerField.fieldAcc =
      SourceJson.object (fuel + 658) (SourceJson.white (sourceRest 335469)) fieldAcc := by
  calc
    SourceJson.object (fuel + 659) (SourceJson.white (sourceRest 124013)) FaceLedgerField.fieldAcc =
        (SourceJson.value (fuel + 658) (sourceRest 124030)).bind (afterValue (fuel + 658)) :=
      object_original_header fuel
    _ = (Except.ok (SimplicesValue.arrayValue, sourceRest 335468)).bind (afterValue (fuel + 658)) :=
      congrArg (fun result => result.bind (afterValue (fuel + 658)))
        (SimplicesValue.value_array_original (fuel + 0))
    _ = (Except.ok (SimplicesValue.arrayValue, separatorChars ++ sourceRest 335469)).bind
          (afterValue (fuel + 658)) :=
      congrArg (fun rest => (Except.ok (SimplicesValue.arrayValue, rest)).bind (afterValue (fuel + 658)))
        separator_original_split
    _ = SourceJson.object (fuel + 658) (SourceJson.white (sourceRest 335469)) fieldAcc :=
      after_value_separator fuel (sourceRest 335469)

theorem sourceChars_through_field :
    SourceJson.value 335850 sourceChars =
      SourceJson.object 335837 (SourceJson.white (sourceRest 335469)) fieldAcc :=
  FaceLedgerField.sourceChars_through_field.trans (object_original_field 335179)

#print axioms after_value_separator
#print axioms separator_original_prefix
#print axioms separator_original_split
#print axioms object_original_field
#print axioms sourceChars_through_field

end SimplicesField

end ImbalancedChen.P2OriginalSaving19Geometry06ScalableParsing
