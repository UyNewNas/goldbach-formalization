import ImbalancedChen.P2OriginalSaving19Geometry06ScalablePhysicalVolumeField

/-! Original integral_gap, closing object and complete original value equation.
The original packed input, original parser and original decoder are unchanged.
This is a source-only candidate until normal, kernel and full-owned checks pass. -/
namespace ImbalancedChen.P2OriginalSaving19Geometry06ScalableParsing
set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false
open ImbalancedChen.P2OriginalSaving19Archive
open ImbalancedChen.P2OriginalSaving19PackedChars

noncomputable def finalFieldChars : List Char := ['\r', '\n', ' ', ' ', '"', 'i', 'n', 't', 'e', 'g', 'r', 'a', 'l', '_', 'g', 'a', 'p', '"', ':', ' ', '"', '1', '2', '5', '4', '3', '8', '5', '3', '1', '3', '3', '5', '5', '5', '0', '9', '8', '0', '0', '5', '6', '5', '6', '3', '6', '4', '7', '2', '7', '2', '4', '0', '6', '9', '7', '9', '6', '6', '0', '3', '2', '2', '3', '6', '6', '4', '0', '4', '5', '5', '5', '8', '0', '2', '6', '5', '6', '9', '7', '6', '2', '5', '1', '9', '1', '9', '5', '1', '0', '4', '3', '2', '4', '6', '8', '6', '8', '9', '/', '6', '4', '5', '9', '0', '4', '7', '1', '8', '8', '4', '7', '9', '1', '3', '9', '4', '3', '6', '1', '3', '3', '1', '6', '1', '1', '5', '3', '6', '7', '8', '0', '6', '0', '2', '1', '6', '6', '4', '7', '6', '8', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '"', '\r', '\n', '}']
noncomputable def finalFieldKey : String := String.ofList ['i', 'n', 't', 'e', 'g', 'r', 'a', 'l', '_', 'g', 'a', 'p']
noncomputable def finalFieldValue : SourceJson := .str (String.ofList ['1', '2', '5', '4', '3', '8', '5', '3', '1', '3', '3', '5', '5', '5', '0', '9', '8', '0', '0', '5', '6', '5', '6', '3', '6', '4', '7', '2', '7', '2', '4', '0', '6', '9', '7', '9', '6', '6', '0', '3', '2', '2', '3', '6', '6', '4', '0', '4', '5', '5', '5', '8', '0', '2', '6', '5', '6', '9', '7', '6', '2', '5', '1', '9', '1', '9', '5', '1', '0', '4', '3', '2', '4', '6', '8', '6', '8', '9', '/', '6', '4', '5', '9', '0', '4', '7', '1', '8', '8', '4', '7', '9', '1', '3', '9', '4', '3', '6', '1', '3', '3', '1', '6', '1', '1', '5', '3', '6', '7', '8', '0', '6', '0', '2', '1', '6', '6', '4', '7', '6', '8', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0'])
noncomputable def originalGeometryJson06 : SourceJson :=
  .obj (((finalFieldKey, finalFieldValue) :: PhysicalVolumeField.fieldAcc).reverse)

theorem object_final_field (fuel : Nat) (tail : List Char) :
    SourceJson.object (fuel + 182) (SourceJson.white (finalFieldChars ++ tail)) PhysicalVolumeField.fieldAcc =
      .ok (originalGeometryJson06, tail) := by rfl

theorem final_field_prefix :
    (sourceRest 335643).take 204 = finalFieldChars := by rfl

theorem final_field_split : sourceRest 335643 = finalFieldChars ++ sourceRest 335847 := by
  calc
    sourceRest 335643 = (sourceRest 335643).take 204 ++ (sourceRest 335643).drop 204 :=
      (List.take_append_drop 204 (sourceRest 335643)).symm
    _ = finalFieldChars ++ (sourceRest 335643).drop 204 :=
      congrArg (fun part => part ++ (sourceRest 335643).drop 204) final_field_prefix
    _ = finalFieldChars ++ sourceRest 335847 :=
      congrArg (fun tail => finalFieldChars ++ tail) (sourceRest_drop 335643 204)

theorem final_field_original :
    SourceJson.object 335836 (SourceJson.white (sourceRest 335643)) PhysicalVolumeField.fieldAcc =
      .ok (originalGeometryJson06, sourceRest 335847) :=
  (congrArg (fun chars => SourceJson.object 335836 (SourceJson.white chars) PhysicalVolumeField.fieldAcc)
    final_field_split).trans (object_final_field 335654 (sourceRest 335847))

theorem sourceChars_whole_value :
    SourceJson.value 335850 sourceChars =
      .ok (originalGeometryJson06, sourceRest 335847) :=
  PhysicalVolumeField.sourceChars_through_field.trans final_field_original

theorem geometryPacked06_whole_value :
    SourceJson.value 335850 geometryPacked06.toList =
      .ok (originalGeometryJson06, (geometryPacked06.drop 335847).toList) :=
  sourceChars_whole_value

#print axioms object_final_field
#print axioms final_field_prefix
#print axioms final_field_split
#print axioms final_field_original
#print axioms sourceChars_whole_value
#print axioms geometryPacked06_whole_value

end ImbalancedChen.P2OriginalSaving19Geometry06ScalableParsing
