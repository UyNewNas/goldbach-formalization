import ImbalancedChen.P2OriginalSaving19Geometry06ScalableFaceLedgerHeader
import ImbalancedChen.P2OriginalSaving19Geometry06ScalableFaceLedgerValue

/-! Insert the completed original array into its original parent object.
The original packed input, original parser and original decoder are unchanged.
This is a source-only candidate until normal, kernel and full-owned checks pass. -/
namespace ImbalancedChen.P2OriginalSaving19Geometry06ScalableParsing
set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false
open ImbalancedChen.P2OriginalSaving19Archive
open ImbalancedChen.P2OriginalSaving19PackedChars

namespace FaceLedgerField

noncomputable def separatorChars : List Char := [',']
noncomputable def fieldAcc : List (String × SourceJson) := (fieldKey, FaceLedgerValue.arrayValue) :: FacetVerticesField.fieldAcc

theorem after_value_separator (fuel : Nat) (tail : List Char) :
    (Except.ok (FaceLedgerValue.arrayValue, separatorChars ++ tail)).bind (afterValue (fuel + 81)) =
      SourceJson.object (fuel + 81) (SourceJson.white tail) fieldAcc := by rfl

theorem separator_original_prefix :
    (sourceRest 124012).take 1 = separatorChars := by rfl

theorem separator_original_split : sourceRest 124012 = separatorChars ++ sourceRest 124013 := by
  calc
    sourceRest 124012 = (sourceRest 124012).take 1 ++ (sourceRest 124012).drop 1 :=
      (List.take_append_drop 1 (sourceRest 124012)).symm
    _ = separatorChars ++ (sourceRest 124012).drop 1 :=
      congrArg (fun part => part ++ (sourceRest 124012).drop 1) separator_original_prefix
    _ = separatorChars ++ sourceRest 124013 :=
      congrArg (fun tail => separatorChars ++ tail) (sourceRest_drop 124012 1)

theorem object_original_field (fuel : Nat) :
    SourceJson.object (fuel + 82) (SourceJson.white (sourceRest 69068)) FacetVerticesField.fieldAcc =
      SourceJson.object (fuel + 81) (SourceJson.white (sourceRest 124013)) fieldAcc := by
  calc
    SourceJson.object (fuel + 82) (SourceJson.white (sourceRest 69068)) FacetVerticesField.fieldAcc =
        (SourceJson.value (fuel + 81) (sourceRest 69087)).bind (afterValue (fuel + 81)) :=
      object_original_header fuel
    _ = (Except.ok (FaceLedgerValue.arrayValue, sourceRest 124012)).bind (afterValue (fuel + 81)) :=
      congrArg (fun result => result.bind (afterValue (fuel + 81)))
        (FaceLedgerValue.value_array_original (fuel + 0))
    _ = (Except.ok (FaceLedgerValue.arrayValue, separatorChars ++ sourceRest 124013)).bind
          (afterValue (fuel + 81)) :=
      congrArg (fun rest => (Except.ok (FaceLedgerValue.arrayValue, rest)).bind (afterValue (fuel + 81)))
        separator_original_split
    _ = SourceJson.object (fuel + 81) (SourceJson.white (sourceRest 124013)) fieldAcc :=
      after_value_separator fuel (sourceRest 124013)

theorem sourceChars_through_field :
    SourceJson.value 335850 sourceChars =
      SourceJson.object 335838 (SourceJson.white (sourceRest 124013)) fieldAcc :=
  FacetVerticesField.sourceChars_through_field.trans (object_original_field 335757)

#print axioms after_value_separator
#print axioms separator_original_prefix
#print axioms separator_original_split
#print axioms object_original_field
#print axioms sourceChars_through_field

end FaceLedgerField

end ImbalancedChen.P2OriginalSaving19Geometry06ScalableParsing
