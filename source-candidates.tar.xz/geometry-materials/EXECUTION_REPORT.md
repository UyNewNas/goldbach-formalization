Cell06 geometry SOURCE_CANDIDATE 交付记录

已在本目录生成150个完整原始geometry parser/decoder候选owner及3个有限shape候选owner，共153个Lean源文件，源码共8,030,527字节；另有153份full-owned审计候选源。所有文件均由新适配生成器exclusive-create。未运行Lean、lake、MCP任务或Git提交，未修改原repo、Cell01、旧报告、原JSON、服务文件或moment目录。

实际执行：

1. 编写本目录IMPLEMENTATION_PLAN.md、generate_geometry.py和独立check_geometry.py。读取既有renderer方法并在Python内存中进行指定命名/计数适配；没有执行旧脚本main或Cell01/05专属constructor。原始reader/decoder及原数据未改变。
2. 执行 `python3 -B generate_geometry.py`，首次成功，153候选及全部审计源生成。先完整缓冲并检查拓扑，再写源文件；没有失败的生成尝试。
3. 执行 `python3 -B check_geometry.py`，结果PASS_HOST_CHECK_ONLY。实测原输入335849字节、精确SHA256、root_end335847及CRLF；153目标及imports拓扑、完整pins、15个row leaves、末叶只有row112、末identifier为Fin1、252项local shape事实、所有selector索引覆盖及节点名称通过host检查。旧Cell01/05专属candidate引用及禁用证明token均0；Metadata05保持。
4. 父进程指出moduleDoc-before-import陷阱后，新建独立check_headers.py；没有改动已冻结candidate/generator/checker。执行该脚本，153候选及153审计header均通过。回归检查明确拒绝 `/-! moduleDoc -/` 后跟import；普通 `/- ... -/` marker可以位于import前。未调用Lean parser。
5. 执行finalize_delivery.py，逐源/审计再读回pins，实际确认exclusive-create会拒绝覆盖SOURCE_MANIFEST.json且原bytes不变，确认无pycache；生成SELECTOR_API.json、此报告与交付manifest，并核对交付pins。GENERATION_STEPS.json保留工具调用输出；该记录中的最后planned项由本次finalize执行及DELIVERY_MANIFEST.json补足为已完成。

主要文件：SOURCE_MANIFEST.json固定153个owner、所有原模板/输入/生成器/检查器及supplier源码pins、方法适配明细、byte spans、import graph、shape事实和scope；HOST_CHECK.json和HEADER_CHECK.json是本地检查证据；SELECTOR_API.json给出精确FQN、声明type和146个逐row/vertex selector所在module；DELIVERY_MANIFEST.json汇总本交付所有文件pins。

精确接口：

- concreteGeometry06：ImbalancedChen.P2OriginalSaving19Geometry06ScalableDecoding.Complete.concreteGeometry06 : Geometry。
- 逐行geometryRowsTyped000…112及逐vertex geometryVerticesTyped000…032均位于ImbalancedChen.P2OriginalSaving19Geometry06ScalableDecoding。
- row root是Node000To014.typedRows；vertex root是VerticesNode000To002.typedItems，均在同Decoding namespace。
- shape theorem namespace为ImbalancedChen.P2OriginalSaving19Geometry06ScalableShape；Rows/Arrays为其子namespace。row_count给出rows.size=113；vertex_count给出vertices.size=33；vertex_values_size将实际vertexValues.size等同vertices.size。all_rows使用Fin113，all_vertices使用Fin33，完整逐字声明见SELECTOR_API.json。

明确未验证事项：

- 153份候选均未进行Lean normal compilation、independent kernel replay或full-owned执行。源码中的rfl/decide+kernel/omega等proof text只是待检源码，不是已接受证明。formal_acceptance=false，normal/kernel/owned接受数均0，P2_6_complete=false。
- Data06的既有source/object已经由独立恢复目录恢复并在本次host读取中核对exact pins，但旧receipt/log bodies缺失、历史raw chain及当前dependency-context join未重检。本交付不复制/重编这些旧对象，也不给其新增formal credit。
- 同构模板的Lean可接受性、所有新规模下normal/kernel资源消耗仍未知；host检查不能发现全部elaboration/typechecking问题。Shape使用当前Geometry05ScalableShape.lean中的generic membership proof源码作为模板，没有重引旧生成器过时proof body。
- 生成器CLI/engine对cell、repo、raw-root、output-root等做参数化，实际冻结和独立完整host验证仅覆盖本次Cell06实例；其他cell的shape-root迁移未作为本交付承诺。
- 未生成Archive.geometry Fin6 projection、BoundedAccess、moment、finite arithmetic或语义owner。有限shape不证明coverage、不交、determinant、physical-volume解释、仿射gap/factor含义、Jensen或积分。physical_volume/integral_gap字符串完整解析不等于其数学意义成立。
- 包中没有Lean对象、服务runner或MCP提交脚本。后续应恢复并qualify既有suppliers，在新的隔离上下文核验此153目标；不得借重编旧成功normal绕过exact对象/receipt恢复。

本目录内容全部属于SOURCE_CANDIDATE及HOST_CHECK证据。唯一实际完成的接受结论是本地文件生成、字节/结构检查和readback通过。
