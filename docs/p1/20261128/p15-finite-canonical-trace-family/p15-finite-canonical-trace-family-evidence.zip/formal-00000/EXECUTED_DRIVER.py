#!/usr/bin/env python3
"""New complete actual trace family only; no old proof replay."""
from pathlib import Path
import hashlib, importlib.util, json, os, shutil, sys, zipfile

ROOT = Path(__file__).resolve().parent
helper = Path('/workspace/p15-continue-20261127/docs/p1/20261127/p15-disagreement-partition/validate.py')
assert hashlib.sha256(helper.read_bytes()).hexdigest() == '04e67f06c4232a6bbd10be8d6c5419287c51a6c14e4b56e39864f230115ce6f7'
spec = importlib.util.spec_from_file_location('frozen_member_validation', helper)
driver = importlib.util.module_from_spec(spec)
spec.loader.exec_module(driver)
driver.WORK = ROOT / 'selected-sources'
driver.MODULE = 'ImbalancedChen.P1OriginalHistoricalFiniteTraceFamily'
driver.SOURCE = driver.WORK / 'ImbalancedChen/P1OriginalHistoricalFiniteTraceFamily.lean'
driver.OUT = ROOT / 'formal-00000'
driver.__file__ = __file__
original_run = driver.run
def original_proof_options(label, command, environment):
    if label == 'normal':
        command = [command[0], '-DmaxRecDepth=100000', '-DmaxHeartbeats=4000000', *command[1:]]
    return original_run(label, command, environment)
driver.run = original_proof_options

if '--worker' in sys.argv:
    seed = Path('/workspace/p1-complete-proof/20261128-p14-parent-four-gate-block000/formal-00000')
    seed_manifests = [seed / 'REUSED_IMPORT_LINKS.json', seed / 'REUSED_EXTRA_ALIAS_LINKS.json']
    seed_before = [driver.fingerprint(p) for p in seed_manifests]
    alias_cache = {}
    for manifest in seed_manifests:
        for link in json.loads(manifest.read_text()):
            p, target = Path(link['path']), link['target']
            assert Path(target).is_absolute() and p.is_symlink() and os.readlink(p) == target
            alias_cache.setdefault(target, p)
    stats = dict(hardlinked_symlink_inodes=0, new_symlinks=0,
        only_exact_absolute_targets=True, independent_output_namespaces=True)
    original_symlink_to = Path.symlink_to
    def share_symlink_inode(self, target, target_is_directory=False):
        cached = alias_cache.get(str(target))
        if cached is None:
            original_symlink_to(self, target, target_is_directory=target_is_directory)
            stats['new_symlinks'] += 1
        else:
            assert cached.is_symlink() and os.readlink(cached) == str(target)
            os.link(cached, self, follow_symlinks=False)
            stats['hardlinked_symlink_inodes'] += 1
        assert self.is_symlink() and os.readlink(self) == str(target)
    Path.symlink_to = share_symlink_inode
    shutil.copyfile(driver.SOURCE, driver.OUT / 'SELECTED_SOURCE.lean')
    shutil.copyfile(__file__, driver.OUT / 'EXECUTED_DRIVER.py')
    records = []
    def pin(fp):
        assert driver.fingerprint(Path(fp['path'])) == fp, fp['path']
        records.append(fp)
    for name in ['PLAN.md', 'REUSED_CONTEXTS.json', 'SOURCE_GIT_COUPLING.json']:
        records.append(driver.fingerprint(ROOT / name))
    namespace = driver.OUT / 'build/lib/lean/ImbalancedChen'
    namespace.mkdir(parents=True, exist_ok=True)
    aliases = []
    reviewed_roots = set()
    contexts = json.loads((ROOT / 'REUSED_CONTEXTS.json').read_text())
    assert len(contexts) == 8
    for context in contexts:
        receipt = Path(context['receipt'])
        result = json.loads(receipt.read_text())
        assert result['status'] == 'PASS_ISOLATED_NORMAL_KERNEL_FULL_OWNED'
        assert result['module'] == context['module']
        source = result.get('source', result.get('inputs', {}).get('source'))
        assert source == context['source']
        pin(source)
        records.append(driver.fingerprint(receipt))
        for stage in ['normal', 'kernel', 'audit']:
            assert result[stage]['exit_code'] == 0
            pin(result[stage]['log'])
        for fp in context['objects']:
            pin(fp)
            p = Path(fp['path'])
            if p.suffix in ['.olean', '.ilean']:
                target = namespace / p.name
                assert not target.exists()
                target.symlink_to(p)
                aliases.append(dict(path=str(target), target=str(p)))
        coupled = receipt.parent / 'COUPLED_IMPORT_VALIDATION.json'
        if coupled.exists():
            x = json.loads(coupled.read_text())
            assert x['status'] == 'PASS' and x['accepted_import_normal_or_kernel_commands'] == 0
            records.append(driver.fingerprint(coupled))
            for fp in x['inputs']:
                pin(fp)
        else:
            for dep_objects in result['inputs']['dependencies'].values():
                for fp in dep_objects:
                    pin(fp)
        root = Path(context['root'])
        review = json.loads((root / 'INDEPENDENT_REVIEW.json').read_text())
        assert review['blocking_findings'] == []
        if 'source_sha256' in review:
            assert review['source_sha256'] == source['sha256']
        archive_metadata = json.loads((root / 'ARCHIVE.json').read_text())
        archive = root / archive_metadata['archive']
        assert driver.fingerprint(archive)['sha256'] == archive_metadata['sha256']
        with zipfile.ZipFile(archive) as z:
            assert z.testzip() is None
            candidates = [n for n in z.namelist() if n.endswith('/' + Path(source['path']).name)]
            assert any(hashlib.sha256(z.read(n)).hexdigest() == source['sha256'] for n in candidates)
        if root not in reviewed_roots:
            records.extend(driver.fingerprint(root / n) for n in ['INDEPENDENT_REVIEW.json', 'ARCHIVE.json'])
            reviewed_roots.add(root)
    # Preserve the registered original P4A object used by the accepted rank bound.
    original = Path('/workspace/p1-complete-proof/20261127-p15-whole-atom-integration/SOURCE_SELECTION.json')
    boundary = next(row for row in json.loads(original.read_text())['member_reused_boundary']
        if row['module'] == 'ImbalancedChen.P4ASpliceDifferenceLowerModulus')
    records.append(driver.fingerprint(original))
    pin(boundary['object'])
    records.extend(seed_before)
    driver.save('COUPLED_IMPORTS_BEFORE.json', records)
    driver.save('REUSED_EXTRA_ALIAS_LINKS.json', aliases)
    driver.main()
    Path.symlink_to = original_symlink_to
    driver.save('IMPORT_ALIAS_STORAGE.json', stats)
    assert seed_before == [driver.fingerprint(p) for p in seed_manifests]
    assert records == [driver.fingerprint(Path(fp['path'])) for fp in records]
    assert all(Path(a['path']).is_symlink() and os.readlink(a['path']) == a['target'] for a in aliases)
    driver.save('COUPLED_IMPORT_VALIDATION.json', dict(status='PASS', inputs=records,
        reused_contexts=8, accepted_import_normal_or_kernel_commands=0,
        whole_P1_4_complete=False, whole_P1_5_complete=False))
else:
    driver.main()
