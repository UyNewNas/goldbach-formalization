/- Necessary private rational algebra for the original Q80 owner.
Uncompiled draft; original lower3Q, upper4Q and directedQQ definitions retained. -/

private theorem upper4Q_le_scaled (a : ℚ) (ha2 : 2 ≤ a) (ha4 : a ≤ 4) :
    upper4Q ((a - 2) / a) ≤ 2 * a / (a + 2) := by
  have ha : 0 < a := by linarith
  let y : ℚ := (a - 2) / a
  have hy0 : 0 ≤ y := div_nonneg (sub_nonneg.mpr ha2) ha.le
  have hyhalf : y ≤ 1 / 2 := by
    apply (div_le_iff₀ ha).mpr
    linarith
  have hden : 0 < 1 - y ^ 2 := by
    nlinarith [mul_nonneg hy0 (sub_nonneg.mpr hyhalf)]
  have hgap : 2 * y - (1 - y ^ 2) * upper4Q y =
      4 / 3 * y ^ 3 + 4 / 15 * y ^ 5 + 4 / 35 * y ^ 7 + 4 / 63 * y ^ 9 := by
    unfold upper4Q
    field_simp [ne_of_gt hden] <;> ring
  have hgap0 : 0 ≤ 4 / 3 * y ^ 3 + 4 / 15 * y ^ 5 +
      4 / 35 * y ^ 7 + 4 / 63 * y ^ 9 := by positivity
  have hupper : upper4Q y ≤ 2 * y / (1 - y ^ 2) := by
    apply (le_div_iff₀ hden).mpr
    nlinarith [hgap]
  have htwo : 0 < 2 - y := by linarith
  have hfrac : 2 * y / (1 - y ^ 2) ≤ 2 / (2 - y) := by
    apply (div_le_div_iff₀ hden htwo).mpr
    nlinarith
  have hscale : 2 / (2 - y) = 2 * a / (a + 2) := by
    dsimp only [y]
    field_simp [ha.ne', htwo.ne', show a + 2 ≠ 0 by linarith] <;> ring
  exact hupper.trans (hfrac.trans_eq hscale)

private theorem directedQQ_nonneg (b e : ℚ)
    (hb2 : 2 < b) (hb4 : b ≤ 4) (he0 : 0 ≤ e) (he : e ≤ b - 2) :
    0 ≤ directedQQ b e := by
  let a : ℚ := b - e
  let D : ℚ := 2 * (b - 1) - e
  let z : ℚ := e / D
  let y : ℚ := (a - 2) / a
  have ha2 : 2 ≤ a := by dsimp only [a]; linarith
  have ha4 : a ≤ 4 := by dsimp only [a]; linarith
  have ha0 : 0 ≤ a := by linarith
  have hD : 0 < D := by dsimp only [D]; linarith
  have hDa : D ≤ a + 2 := by dsimp only [D, a]; linarith
  have hz : 0 ≤ z := div_nonneg he0 hD.le
  have hlow : 2 * z ≤ lower3Q z := by
    unfold lower3Q
    nlinarith [pow_nonneg hz 3, pow_nonneg hz 5]
  have hfrac : 2 * a / (a + 2) ≤ 2 * a / D :=
    div_le_div_of_nonneg_left (by positivity) hD hDa
  have hu : upper4Q y ≤ 2 * a / D :=
    (upper4Q_le_scaled a ha2 ha4).trans hfrac
  have humul := mul_le_mul_of_nonneg_left hu he0
  have hlmul := mul_le_mul_of_nonneg_left hlow ha0
  have hscale : a * (2 * z) = e * (2 * a / D) := by
    dsimp only [z]
    ring
  rw [hscale] at hlmul
  have hnum : 0 ≤ a * lower3Q z - e * upper4Q y := by linarith
  change 0 ≤ (a * lower3Q z - e * upper4Q y) / (a * b)
  exact div_nonneg hnum (mul_nonneg ha0 (by linarith))
