"""Wait outside compiler queue; dispatch this metadata-only audit once a slot frees."""
from pathlib import Path
import json,os,time,subprocess,datetime
if not __debug__:raise SystemExit('Integrity checks require unoptimized Python')
ROOT=Path(__file__).resolve().parent
claim=ROOT/'DISPATCH_CLAIM.json'
with claim.open('x') as f:json.dump({'pid':os.getpid(),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'new_compiler_jobs_dispatched':0},f)
assert not (ROOT/'LANE_00000.json').exists() and not (ROOT/'metadata-00000').exists()
base=ROOT.parent
lanes=[base/'20261128-p15-cell0-affine-chronology/formal-00005/LANE.json',base/'20261128-p15-saving19-quoted-input-readback/LANE_00001.json',base/'20261128-p15-actual-compact-smooth-family/formal-00000/LANE.json',base/'20261128-p15-proper-power-signed-modulus-payment/formal-00000/LANE.json']
def save(d):
 path=ROOT/'DISPATCH_STATE.json';temporary=ROOT/'.dispatch-state.tmp';temporary.write_text(json.dumps(d,indent=2)+'\n');temporary.replace(path)
while True:
 rows=[]
 for path in lanes:
  try:record=json.loads(path.read_text())
  except (OSError,ValueError):record={'status':'UNKNOWN_NOT_COUNTED_FREE'}
  rows.append({'path':str(path),'status':record['status'],'exit_code':record.get('exit_code')})
 finished=sum(r['status']=='VALIDATION_LANE_FINISHED' for r in rows)
 state={'status':'WAITING_OUTSIDE_VALIDATION_QUEUE','pid':os.getpid(),'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'existing_jobs':rows,'terminal_existing_lanes':finished,'new_compiler_jobs_dispatched':0,'maximum_pending_running_validation_jobs':4}
 save(state)
 if finished>=1:
  # No existing job is restarted or modified; original lane still serializes work.
  assert not (ROOT/'LANE_00000.json').exists() and not (ROOT/'metadata-00000').exists()
  state.update(status='DISPATCHING_METADATA_ONLY_AFTER_EXISTING_SLOT_FREED',new_compiler_jobs_dispatched=1,maximum_pending_running_validation_jobs=5-finished);save(state)
  child=subprocess.Popen(['python3','-B',str(ROOT/'monitor_00000.py')]);state['child_pid']=child.pid;save(state)
  code=child.wait();state.update(status='METADATA_MONITOR_FINISHED',exit_code=code,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());save(state)
  raise SystemExit(code)
 time.sleep(5)
