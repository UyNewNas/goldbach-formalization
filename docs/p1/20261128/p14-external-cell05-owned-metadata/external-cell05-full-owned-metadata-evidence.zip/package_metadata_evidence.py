"""Seal metadata augmentation of existing Cell05 owners, without any proof command."""
from pathlib import Path
import json,hashlib,zipfile,importlib.util,sys,re,shutil
if not __debug__:raise SystemExit('Integrity checks require unoptimized Python')
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'metadata-00001'
def digest(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
result=json.loads((OUT/'METADATA_RESULTS.json').read_text());assert result['status']=='PASS_EXACT_ORIGINAL_CELL05_FULL_OWNED_METADATA_AUGMENTATION' and result['owned']==218 and result['private']==0
assert json.loads((ROOT/'LANE_00001.json').read_text())['status']=='VALIDATION_LANE_FINISHED' and json.loads((ROOT/'LANE_00001.json').read_text())['exit_code']==0
assert json.loads((OUT/'COMMAND.json').read_text())['exit_code']==0
before=json.loads((OUT/'INPUTS_BEFORE.json').read_text());assert before==json.loads((OUT/'INPUTS_AFTER.json').read_text()) and len(before)==1518
for fp in before:
 p=Path(fp['path']);assert p.stat().st_size==fp['bytes'] and digest(p)==fp['sha256'],str(p)
context=json.loads((OUT/'ISOLATED_OBJECT_CONTEXT.json').read_text());assert len(context['aliases'])==994
for r in context['aliases']:assert Path(r['path']).is_symlink() and str(Path(r['path']).readlink())==r['target']
assert (ROOT/'OwnedMetadataAudit.lean').read_bytes()==(OUT/'EXECUTED_AUDIT.lean').read_bytes()
assert (ROOT/'metadata_worker_00001.py').read_bytes()==(OUT/'EXECUTED_WORKER.py').read_bytes()
core=Path('/workspace/blue-build-tools/validate_member_roots_owned.py');assert digest(core)=='ed4dc724deb5e2cb28cbd461014c59bed52c373f6b18613f07cf663e456d8201'
spec=importlib.util.spec_from_file_location('unchanged_metadata_parser',core);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
modules=json.loads((ROOT/'MODULES.json').read_text());exports,inventory,axioms=module.read_audit((OUT/'metadata.log').read_text(),modules,0)
assert exports==json.loads((OUT/'OWNED_EXPORTS.json').read_text()) and inventory==json.loads((OUT/'OWNED_INVENTORY.json').read_text())
old={r['name']:r for r in json.loads((ROOT/'ORIGINAL_OWNED_RECORDS.json').read_text())};assert set(old)=={r['name'] for r in exports} and len(exports)==218
for row in exports:
 assert row['module']==old[row['name']]['module'] and row['type']==old[row['name']]['type'] and set(row['axioms'])==set(old[row['name']]['axioms'])
 for text in [row['type'],row['type_expression'],*row['universe_parameters']]:
  decoded=text
  for _ in range(3):decoded=re.sub(r'\\u([0-9a-fA-F]{4})|\\U([0-9a-fA-F]{8})',lambda m:chr(int(m.group(1) or m.group(2),16)),decoded)
  assert not any(token in decoded for token in ['sorryAx','…','⋯','...'])
review=json.loads((ROOT/'INDEPENDENT_METADATA_REVIEW.json').read_text());assert review['blocking_findings']==[] and review['owned']==218 and review['source_sha256']==digest(OUT/'EXECUTED_AUDIT.lean') and review['worker_sha256']==digest(OUT/'EXECUTED_WORKER.py')
reuse=ROOT.parent/'20261128-p15-saving19-external-local-exact-reuse';meta=json.loads((reuse/'ARCHIVE.json').read_text());oldzip=reuse/meta['archive'];assert digest(oldzip)==meta['sha256']
provenance=ROOT/'provider-history';provenance.mkdir(exist_ok=True)
for n in ['ARCHIVE.json','INDEPENDENT_REUSE_REVIEW.json','CURRENT_STATUS.json',meta['archive'],'LOCAL_NATIVE555_COMPLETE_MATCH.json']:shutil.copyfile(reuse/n,provenance/n)
admission={'status':'ACCEPTED_METADATA_AUGMENTATION_OF_EXISTING_CELL05_22_OWNERS','provider_commit':'f443b5db3360ba8d915fa82dca0fe89b3f073c50','existing_proof_modules':22,'existing_owned':218,'private':0,'context_project_objects':439,'context_native_artifacts':555,'all218_historical_names_prettytypes_axioms_exact':True,'raw_Expr_universes_private_fields_and_full_generated_inventory_complete':True,'historical_normal_kernel_audits':[22,22,5],'new_metadata_build_commands':1,'old_normal_kernel_or_old_audit_replays':0,'new_mathematical_credit':0,'reusable_only_with_exact_coherent_provider_object_context':True,'P1_same_name_old_objects_not_substitutable_without_interface_admission':True,'P1_monolithic_archive_interfaces_closed':False,'quoted_current_JSON_binding_closed':False,'whole_P1_4_complete':False,'whole_P1_5_complete':False,'original_register':'18/21','three_HOLDs_unchanged':True};(ROOT/'ADMISSION.json').write_text(json.dumps(admission,indent=2)+'\n')
archive=ROOT/'external-cell05-full-owned-metadata-evidence.zip';assert not archive.exists();members={}
for p in ROOT.rglob('*'):
 if p.is_file() and not p.is_symlink() and p.name not in ['ARCHIVE.json','PUBLISHED.json'] and p!=archive:
  assert '__pycache__' not in p.parts;members[str(p.relative_to(ROOT))]=p.read_bytes()
# Retain the provider-history ARCHIVE metadata explicitly despite the outer archive name exclusion.
members['provider-history/ARCHIVE.json']=(provenance/'ARCHIVE.json').read_bytes()
index=[{'path':n,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for n,data in sorted(members.items())];members['FILE_INDEX.json']=(json.dumps(index,indent=2)+'\n').encode()
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
 for n,data in sorted(members.items()):z.writestr(n,data)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for r in index:
  data=z.read(r['path']);assert len(data)==r['bytes'] and hashlib.sha256(data).hexdigest()==r['sha256']
meta={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':digest(archive),'members':len(members),'CRC_and_each_member_rehashed':True,'old_object_payloads_not_duplicated':True,'new_math_credit':0,'whole_P1_4_complete':False,'whole_P1_5_complete':False};(ROOT/'ARCHIVE.json').write_text(json.dumps(meta,indent=2)+'\n');print('SEALED_EXISTING_CELL05_METADATA',meta['bytes'],meta['sha256'])
