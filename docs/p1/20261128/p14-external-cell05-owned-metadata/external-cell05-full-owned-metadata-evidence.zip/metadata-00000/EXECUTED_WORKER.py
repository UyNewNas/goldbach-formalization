"""Only metadata enrichment of unchanged accepted provider objects; no proof replay."""
from pathlib import Path
import json,hashlib,subprocess,datetime,os,signal,importlib.util,time
if not __debug__:raise SystemExit('Integrity checks require unoptimized Python')
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'metadata-00000';OUT.mkdir(exist_ok=False)
CORE=Path('/workspace/blue-build-tools/validate_member_roots_owned.py');STATE=Path('/workspace/blue-build-tools/member-runtime-evidence/state.json')
assert hashlib.sha256(CORE.read_bytes()).hexdigest()=='ed4dc724deb5e2cb28cbd461014c59bed52c373f6b18613f07cf663e456d8201'
assert hashlib.sha256(STATE.read_bytes()).hexdigest()=='9f0688f701d861e3af832a1ab17d8d0fab41c1d30a3261f24922cae058e7b152'
def fp(p):
 p=Path(p)
 with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h)
def save(name,data):(OUT/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
context=json.loads((ROOT/'INPUT_CONTEXT.json').read_text());records={};duplicates=0
def pin(row):
 global duplicates
 if row['path'] in records:
  assert records[row['path']]==row;duplicates+=1;return
 assert fp(row['path'])==row,row['path'];records[row['path']]=row
for row in context['inputs']:pin(row)
for row in json.loads((ROOT/'PREPARED_CODE.json').read_text())['files']:pin(row)
for name in ['OwnedMetadataAudit.lean','metadata_worker_00000.py','validate_00000.py','monitor_00000.py','PREPARED_CODE.json','INPUT_CONTEXT.json','ORIGINAL_OWNED_RECORDS.json','MODULES.json','SCOPE.json','PLAN.md']:pin(fp(ROOT/name))
for p in [CORE,STATE,Path('/workspace/blue-build-tools/run_guarded.py'),Path('/workspace/blue-build-tools/serialize_validation_lane.py')]:pin(fp(p))
mathlib=Path('/workspace/blue-member-build/.lake/packages/mathlib');assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=mathlib,text=True).strip()=='e4c91783ca8e6a7c693ae624ade32fd22d4e43c1'
for p in [mathlib/'lean-toolchain',mathlib/'lake-manifest.json']:pin(fp(p))
namespace=OUT/'objects';aliases=[]
for row in context['links']:
 rel=Path(row['relative_path']);assert not rel.is_absolute() and '..' not in rel.parts
 dest=namespace/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.symlink_to(row['target']);assert os.readlink(dest)==row['target'];aliases.append({'path':str(dest),'target':row['target']})
assert len(aliases)==994
# First namespace contains all439 exact project modules and555 native artifacts.
# Keep standard inherited package paths only after excluding old project namespaces.
remaining=[];excluded=[]
for text in os.environ.get('LEAN_PATH','').split(os.pathsep):
 if not text:continue
 path=Path(text).resolve()
 if (path/'ImbalancedChen').exists():excluded.append(str(path));continue
 remaining.append(text)
assert remaining, 'missing original guarded standard package context'
environment=os.environ.copy();environment['LEAN_PATH']=str(namespace)+os.pathsep+os.pathsep.join(remaining)
save('ISOLATED_OBJECT_CONTEXT.json',{'aliases':aliases,'excluded_other_project_namespaces':excluded,'remaining_standard_package_paths':remaining,'all_project_modules_from_exact439':True,'all_external_native555_exact':True,'no_output_artifact_hardlinks':True})
save('INPUTS_BEFORE.json',list(records.values()));save('PIN_DEDUPLICATION.json',{'unique_paths':len(records),'duplicate_equal_references':duplicates})
(OUT/'EXECUTED_AUDIT.lean').write_bytes((ROOT/'OwnedMetadataAudit.lean').read_bytes());(OUT/'EXECUTED_WORKER.py').write_bytes(Path(__file__).read_bytes())
command=['lean','-DmaxRecDepth=100000','-DmaxHeartbeats=4000000',str(ROOT/'OwnedMetadataAudit.lean')];started=datetime.datetime.now(datetime.timezone.utc).isoformat();clock=time.monotonic();timeout=False
with (OUT/'metadata.log').open('x') as log:
 process=subprocess.Popen(command,cwd='/workspace/blue-member-build',env=environment,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 try:code=process.wait(timeout=1800)
 except subprocess.TimeoutExpired:
  timeout=True;os.killpg(process.pid,signal.SIGTERM)
  try:process.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait()
  code=process.returncode
save('COMMAND.json',{'argv':command,'cwd':'/workspace/blue-member-build','started_utc':started,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-clock,'exit_code':code,'timeout':timeout,'log':fp(OUT/'metadata.log'),'new_mathematical_theorem':False,'original_normal_kernel_or_audit_replays':0})
after=[fp(p) for p in records];save('INPUTS_AFTER.json',after);assert after==list(records.values())
assert all(Path(r['path']).is_symlink() and os.readlink(r['path'])==r['target'] for r in aliases)
if timeout or code:raise SystemExit(code or 124)
spec=importlib.util.spec_from_file_location('unchanged_full_owned_reader',CORE);core=importlib.util.module_from_spec(spec);spec.loader.exec_module(core)
modules=json.loads((ROOT/'MODULES.json').read_text());raw=(OUT/'metadata.log').read_text();decls,inventory,axioms=core.read_audit(raw,modules,code)
original=json.loads((ROOT/'ORIGINAL_OWNED_RECORDS.json').read_text());old={r['name']:r for r in original};assert len(old)==len(decls)==218 and set(old)=={r['name'] for r in decls}
comparisons=[]
for r in decls:
 prior=old[r['name']];assert r['module']==prior['module'] and set(r['axioms'])==set(prior['axioms']);assert r['type']==prior['type'], 'historical pretty type differs: '+r['name']
 comparisons.append({'name':r['name'],'module':r['module'],'old_pretty_type_exact':True,'old_axioms_exact':True,'raw_type_expression_present':True,'universe_parameters':r['universe_parameters'],'is_private':r['is_private']})
save('OWNED_EXPORTS.json',decls);save('OWNED_INVENTORY.json',inventory);save('HISTORICAL_RECORD_COMPARISON.json',comparisons)
save('METADATA_RESULTS.json',{'status':'PASS_EXACT_ORIGINAL_CELL05_FULL_OWNED_METADATA_AUGMENTATION','target_modules':22,'owned':len(decls),'private':inventory['private_name_count'],'axioms':axioms,'all_original218_names_and_types_and_axiom_sets_exact':True,'all_private_and_generated_included':True,'all_type_expression_universe_parameters_is_private_present':True,'all_source_objects_and_logs_before_after_identical':True,'provider439_project_and555_native_exact_context':True,'new_compiletime_metadata_audit_commands':1,'old_normal_kernel_or_old_audit_replays':0,'new_mathematical_credit':0,'await_independent_read_only_review_and_lane0':True,'P1_monolithic_archive_interfaces_closed':False,'historical_quoted_input_binding_closed':False,'whole_P1_4_complete':False,'whole_P1_5_complete':False})
print('PASS_ORIGINAL_CELL05_FULL_OWNED_METADATA',len(decls),inventory['private_name_count'],flush=True)
