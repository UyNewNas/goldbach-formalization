import ImbalancedChen.P1HistoricalFifthIndexedOwnerArchive
import ImbalancedChen.P1OriginalFifthUniformAdoptedBankError
namespace ImbalancedChen.P1IndexedB13ArgumentDiagnostic
noncomputable section
open scoped Classical
open P1OriginalPrefixRowDecodeSoundness P1OriginalVariableFifthContinuation
open P1OriginalFifthGrid400RefinedFullBoxCover P1HistoricalFifthIndexedOwnerArchive

theorem gridArg (i : ArchiveIndex) (hi : i ∈ licensedIndices) :
    (archiveRow i).grid = 400 := (licensedIndex_geometry i hi).1

theorem positiveArg (i : ArchiveIndex) (hi : i ∈ licensedIndices) :
    ∀ k : Fin 5, 1 ≤ (archiveRow i).lo k := (licensedIndex_geometry i hi).2.2.1

theorem keyArg (i : ArchiveIndex) (hi : i ∈ licensedIndices) :
    (archiveRow i).lo 0 ≤ 77 := (licensedIndex_geometry i hi).2.2.2

theorem selectedZeroArg (i : ArchiveIndex) (e : ℚ) (q : ℕ) (chi omega : ℝ) :
    ∀ j ∈ licensedOwners i e q chi omega,
      j ∈ P1OriginalCoarseFifthContinuation.selectedFifthCells 0 chi (refinedMesh q) omega
        (licensedOwners i e q chi omega) := licensedOwner_selected_zero i e q chi omega

theorem selectedBufferedArg (i : ArchiveIndex) (e : ℚ) (q : ℕ) (chi omega : ℝ) :
    ∀ j ∈ licensedOwners i e q chi omega,
      j ∈ P1OriginalCoarseFifthContinuation.selectedFifthCells e chi (refinedMesh q) omega
        (licensedOwners i e q chi omega) := licensedOwner_selected_buffer i e q chi omega

theorem stopZeroArg (i : ArchiveIndex) (e : ℚ) (q : ℕ) (chi omega : ℝ) :
    ∀ j ∈ licensedOwners i e q chi omega,
      P1OriginalHistoricalFifthOwnCubeAffineGates.firstStopCellCheck 0 (refinedMesh q) j = true :=
  licensedOwner_firstStop_zero i e q chi omega

theorem stopBufferedArg (i : ArchiveIndex) (e : ℚ) (q : ℕ) (chi omega : ℝ) :
    ∀ j ∈ licensedOwners i e q chi omega,
      P1OriginalHistoricalFifthOwnCubeAffineGates.firstStopCellCheck (e : ℝ) (refinedMesh q) j = true :=
  licensedOwner_firstStop_buffer i e q chi omega
end
end ImbalancedChen.P1IndexedB13ArgumentDiagnostic
