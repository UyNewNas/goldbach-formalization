import ImbalancedChen.P1HistoricalFifthIndexedOwnerArchive
import ImbalancedChen.P1OriginalFifthUniformAdoptedBankError
import Mathlib

/-! SOURCE_ONLY / UNCOMPILED_ZERO_CREDIT.
B13 is instantiated at the original full-table source indices. Row and
owner rejection stay explicit. The estimate does not identify the old
literal historical owner with a changed common-policy ancestor. -/
namespace ImbalancedChen.P1HistoricalFifthIndexedBankError
noncomputable section
open Set MeasureTheory
open scoped Classical BigOperators ENNReal
open P1OriginalPrefixRowDecodeSoundness P1OriginalVariableFifthContinuation
open P1OriginalFifthGrid400RefinedFullBoxCover P1OriginalFifthAdoptedOwnerBank
open P1OriginalFifthLiteralKernelModulus P1OriginalFifthJointMeshSchedule
open P1OriginalFifthMovingMeshFubiniBridge P1FifthUnitBoxGainDecomposition
open P1OriginalFifthActualB13IntegralError P1HistoricalFifthIndexedOwnerArchive

noncomputable def indexedDomain (i : ArchiveIndex) (e : ℚ) (q : ℕ) (chi omega : ℝ) (z : ℚ) : Set (Fin 5 → ℝ) :=
  ownerUnion (archiveRow i) z chi (refinedMesh q) omega (licensedOwners i e q chi omega)

/-- Same literal integral, abstracting the source row/owner bank before instantiation. -/
@[irreducible] private noncomputable def sourceKernelIntegral
    (raw : FifthWireRow) (q : ℕ) (chi omega : ℝ)
    (J : Finset (Label5 (refinedMesh q))) (z : ℚ) : ℝ :=
  ∫ t in ownerUnion raw z chi (refinedMesh q) omega J, positiveKernel raw (z : ℝ) t

noncomputable def indexedIntegral (i : ArchiveIndex) (e : ℚ) (q : ℕ) (chi omega : ℝ) (z : ℚ) : ℝ :=
  sourceKernelIntegral (archiveRow i) q chi omega (licensedOwners i e q chi omega) z

noncomputable def indexedOmitted (i : ArchiveIndex) (e : ℚ) (q : ℕ) (chi omega : ℝ) : Set (Fin 5 → ℝ) :=
  fixedParent (archiveRow i) \ indexedDomain i e q chi omega 0

noncomputable def indexedTrimMass (i : ArchiveIndex) (e : ℚ) (q : ℕ) (chi omega : ℝ) : ℝ :=
  ∫ t in indexedOmitted i e q chi omega, positiveKernel (archiveRow i) 0 t

noncomputable def indexedTrimCost (i : ArchiveIndex) (e : ℚ) (q : ℕ) (chi omega : ℝ) : ℝ :=
  rowMassBound (archiveRow i) * (volume (indexedOmitted i e q chi omega)).toReal

theorem indexedDomain_subset_parent (i : ArchiveIndex) (e : ℚ) (q : ℕ) (chi omega : ℝ) (z : ℚ) :
    indexedDomain i e q chi omega z ⊆ fixedParent (archiveRow i) := by
  intro t ht
  obtain ⟨j, _hj, htj⟩ := mem_iUnion₂.mp ht
  exact ⟨htj.1, htj.2.2.1⟩

theorem indexedOmitted_measurable (i : ArchiveIndex) (e : ℚ) (q : ℕ) (chi omega : ℝ) :
    MeasurableSet (indexedOmitted i e q chi omega) :=
  (fixedParent_measurable _).diff (ownerUnion_measurable _ _ _ _ _ _)

theorem indexedTrimMass_nonneg (i : ArchiveIndex) (e : ℚ) (q : ℕ) (chi omega : ℝ) :
    0 ≤ indexedTrimMass i e q chi omega :=
  setIntegral_nonneg (indexedOmitted_measurable i e q chi omega) (fun _ _ => le_max_left _ _)

theorem indexed_parent_sub_baseline (i : ArchiveIndex) (hi : i ∈ licensedIndices)
    (e : ℚ) (q : ℕ) (chi omega : ℝ) :
    parentIntegral (archiveRow i) - indexedIntegral i e q chi omega 0 =
      indexedTrimMass i e q chi omega := by
  have hg := licensedIndex_geometry i hi
  have h := setIntegral_sdiff (ownerUnion_measurable (archiveRow i) 0 chi (refinedMesh q) omega
      (licensedOwners i e q chi omega))
    (positiveKernel_integrableOn_of_subset (archiveRow i) 0 (fixedParent (archiveRow i))
      (fixedParent_subset_positiveCube _ hg.1 hg.2.2.1))
    (indexedDomain_subset_parent i e q chi omega 0)
  simpa only [parentIntegral, indexedIntegral, sourceKernelIntegral, indexedDomain, indexedTrimMass,
    indexedOmitted, Rat.cast_zero] using h.symm

theorem indexedTrimMass_le_cost (i : ArchiveIndex) (hi : i ∈ licensedIndices)
    (e : ℚ) (q : ℕ) (chi omega : ℝ) :
    indexedTrimMass i e q chi omega ≤ indexedTrimCost i e q chi omega := by
  have hg := licensedIndex_geometry i hi
  have hsub : indexedOmitted i e q chi omega ⊆ (archiveRow i).originalBox := fun _ ht => ht.1.1
  have hfinite : volume (indexedOmitted i e q chi omega) < ∞ :=
    (measure_mono hsub).trans_lt (by rw [rawBox_volume _ hg.1]; exact ENNReal.ofReal_lt_top)
  have hn :
      ‖(∫ t in indexedOmitted i e q chi omega, positiveKernel (archiveRow i) 0 t)‖ ≤
        rowMassBound (archiveRow i) * (volume (indexedOmitted i e q chi omega)).toReal := by
    apply norm_setIntegral_le_of_norm_le_const hfinite
    intro t ht
    simpa only [Real.norm_eq_abs, positiveKernel,
      abs_of_nonneg (le_max_left (0 : ℝ) _)] using
      positive_kernel_le_rowMassBound (archiveRow i) 0 (by norm_num) t
        (fixedParent_subset_positiveCube _ hg.1 hg.2.2.1 ht.1)
  change ‖indexedTrimMass i e q chi omega‖ ≤ indexedTrimCost i e q chi omega at hn
  simpa only [Real.norm_eq_abs, abs_of_nonneg (indexedTrimMass_nonneg i e q chi omega)] using hn

private theorem same_parameter_raw_B13 (raw : FifthWireRow)
    (q : ℕ) (hq : 0 < q) (hgrid : raw.grid = 400)
    (hpositive : ∀ k, 1 ≤ raw.lo k) (hkey : raw.lo 0 ≤ 77)
    (e : ℚ) (he : 0 ≤ e) (hemax : e ≤ 3 / 51200) (chi omega : ℝ)
    (hchi : chi ≤ (e : ℝ) / 10)
    (hstep : logPrimeMeshStep 0 (19 / 96) (refinedMesh q) ≤ chi)
    (J : Finset (Label5 (refinedMesh q)))
    (hselected0 : ∀ j ∈ J, j ∈ P1OriginalCoarseFifthContinuation.selectedFifthCells 0 chi (refinedMesh q) omega J)
    (hselected : ∀ j ∈ J, j ∈ P1OriginalCoarseFifthContinuation.selectedFifthCells e chi (refinedMesh q) omega J)
    (hstop0 : ∀ j ∈ J,
      P1OriginalHistoricalFifthOwnCubeAffineGates.firstStopCellCheck 0 (refinedMesh q) j = true)
    (hstop : ∀ j ∈ J,
      P1OriginalHistoricalFifthOwnCubeAffineGates.firstStopCellCheck (e : ℝ) (refinedMesh q) j = true) :
    |sourceKernelIntegral raw q chi omega J e - sourceKernelIntegral raw q chi omega J 0| ≤
      rowModulus raw e / (400 : ℝ)^5 +
        rowMassBound raw * (428 / 75 : ℝ) * (e : ℝ) / (400 : ℝ)^4 := by
  unfold sourceKernelIntegral
  simpa only [Rat.cast_zero] using
    actual_selected_owner_B13 raw q hq hgrid hpositive hkey e he hemax
    chi chi omega omega hchi hstep J hselected0 hselected hstop0 hstop

set_option pp.explicit true in
set_option pp.proofs true in
set_option pp.universes true in
theorem indexed_actual_B13 (i : ArchiveIndex) (hi : i ∈ licensedIndices)
    (q : ℕ) (hq : 0 < q) (e : ℚ) (he : 0 ≤ e) (hemax : e ≤ 3 / 51200)
    (chi omega : ℝ) (hchi : chi ≤ (e : ℝ) / 10)
    (hstep : logPrimeMeshStep 0 (19 / 96) (refinedMesh q) ≤ chi) :
    |indexedIntegral i e q chi omega e - indexedIntegral i e q chi omega 0| ≤
      rowEnvelope (fun k => rowModulus (archiveRow k))
        (fun k => rowMassBound (archiveRow k)) i e := by
  show_term
    have hg := licensedIndex_geometry i hi
    have h := same_parameter_raw_B13 (archiveRow i) q hq hg.1 hg.2.2.1 hg.2.2.2
      e he hemax chi omega hchi hstep (licensedOwners i e q chi omega)
      (licensedOwner_selected_zero i e q chi omega)
      (licensedOwner_selected_buffer i e q chi omega)
      (licensedOwner_firstStop_zero i e q chi omega)
      (licensedOwner_firstStop_buffer i e q chi omega)
    exact h

end
end ImbalancedChen.P1HistoricalFifthIndexedBankError
