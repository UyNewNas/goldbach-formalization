from pathlib import Path
import importlib.util,hashlib,json,os
ROOT=Path(__file__).resolve().parent
helper=Path('/workspace/p15-continue-20261127/docs/p1/20261127/p15-disagreement-partition/validate.py')
assert hashlib.sha256(helper.read_bytes()).hexdigest()=='04e67f06c4232a6bbd10be8d6c5419287c51a6c14e4b56e39864f230115ce6f7'
spec=importlib.util.spec_from_file_location('frozen_member_diagnostic',helper);driver=importlib.util.module_from_spec(spec);spec.loader.exec_module(driver)
driver.WORK=ROOT/'selected-sources';driver.MODULE='ImbalancedChen.P1IndexedBankErrorDiagnostic';driver.SOURCE=driver.WORK/'ImbalancedChen/P1IndexedBankErrorDiagnostic.lean';driver.OUT=ROOT/'formal-00000';driver.__file__=__file__
def worker():
 assert driver.fingerprint(driver.STATE)['sha256']==driver.STATE_SHA
 assert driver.fingerprint(driver.CORE)['sha256']==driver.CORE_SHA
 lib=Path('/workspace/p1-complete-proof/20261128-p14-indexed-bank-error/formal-00004/build/lib/lean')
 env=os.environ.copy();env['LEAN_PATH']=str(lib)+os.pathsep+env.get('LEAN_PATH','')
 driver.save('DIAGNOSTIC_SCOPE.json',dict(status='DIAGNOSTIC_ONLY_NO_FORMAL_CREDIT',source=driver.fingerprint(driver.SOURCE),reused_failed_attempt_namespace=str(lib),old_normal_kernel_replays=0,original_guard_unchanged=True,no_kernel_skip_or_altered_resource_flags=True))
 driver.run('normal-diagnostic',['lean','-DmaxRecDepth=100000','-DmaxHeartbeats=4000000','--root='+str(driver.WORK),str(driver.SOURCE)],env)
driver.worker=worker
driver.main()
