from pathlib import Path
import os,sys,json,hashlib,subprocess,datetime,time,shutil
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'diagnostic-00011'
STATE=Path('/workspace/blue-build-tools/member-runtime-evidence/state.json')
PROJECT=Path('/workspace/blue-member-build')
SOURCE=ROOT/'selected-sources-00011/ImbalancedChen/P1HistoricalFifthIndexedOwnerArchive.lean'
NAMESPACE=ROOT/'formal-00008/build/lib/lean'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(n,x):(OUT/n).write_text(json.dumps(x,indent=2)+'\n')
if '--worker' not in sys.argv:
 assert not OUT.exists();OUT.mkdir()
 command=['python3','/workspace/blue-build-tools/serialize_validation_lane.py','--state',str(STATE),'--receipt',str(OUT/'LANE.json'),'python3','/workspace/blue-build-tools/run_guarded.py','--state',str(STATE),'lake','--no-build','env','python3','-B',__file__,'--worker']
 raise SystemExit(subprocess.run(command,cwd=PROJECT).returncode)
assert sha(STATE)=='9f0688f701d861e3af832a1ab17d8d0fab41c1d30a3261f24922cae058e7b152'
assert NAMESPACE.is_dir()
shutil.copyfile(SOURCE,OUT/'SELECTED_SOURCE.lean');shutil.copyfile(__file__,OUT/'EXECUTED_DIAGNOSTIC.py')
reference=ROOT/'formal-00008/REUSED_IMPORT_LINKS.json'
links=json.loads(reference.read_text());assert len(links)==6972
for x in links:
 p=Path(x['path']);assert p.is_symlink() and str(p.readlink())==x['target']
env=os.environ.copy();env['LEAN_PATH']=str(NAMESPACE)+os.pathsep+env.get('LEAN_PATH','')
command=['lean','-DmaxRecDepth=100000','-DmaxHeartbeats=4000000','--root='+str(SOURCE.parents[1]),'-o',str(OUT/'Probe.olean'),'-i',str(OUT/'Probe.ilean'),'-c',str(OUT/'Probe.c'),str(SOURCE)]
record=dict(status='DIAGNOSTIC_ONLY_NO_FORMAL_ACCEPTANCE',source_sha256=sha(SOURCE),reused_import_namespace=str(NAMESPACE),reused_manifest_sha256=sha(reference),no_Data_rehash_or_accepted_Lean_replay=True,argv=command,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
save('STARTED.json',record);t=time.monotonic()
with (OUT/'normal.log').open('xb') as log:code=subprocess.run(command,cwd=PROJECT,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
record.update(exit_code=code,wall_seconds=time.monotonic()-t,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());save('RESULT.json',record)
raise SystemExit(code)
