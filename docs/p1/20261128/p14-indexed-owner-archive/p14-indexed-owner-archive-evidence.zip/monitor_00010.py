from pathlib import Path
import subprocess,time,os,signal,json,datetime
ROOT=Path(__file__).resolve().parent
assert not (ROOT/'WATCHDOG_00010.json').exists()
source=str(ROOT/'selected-sources-00010/ImbalancedChen/P1HistoricalFifthIndexedOwnerArchive.lean')
p=subprocess.Popen(['python','-B',str(ROOT/'diagnostic_00010.py')])
peak=0;observed=[];killed=[]
while p.poll() is None:
 for item in Path('/proc').iterdir():
  if not item.name.isdigit():continue
  try:
   cmd=(item/'cmdline').read_bytes().replace(b'\0',b' ').decode()
   ancestor=int(item.name);seen=set()
   while ancestor!=p.pid and ancestor>1 and ancestor not in seen:
    seen.add(ancestor)
    parent_status=(Path('/proc')/str(ancestor)/'status').read_text()
    ancestor=int(next(x.split()[1] for x in parent_status.splitlines() if x.startswith('PPid:')))
   if ancestor!=p.pid:continue
   rss=int(next(x.split()[1] for x in (item/'status').read_text().splitlines() if x.startswith('VmRSS:')))*1024
   peak=max(peak,rss)
   if int(item.name) not in observed:observed.append(int(item.name))
   if rss>14*2**30:
    os.kill(int(item.name),signal.SIGTERM);killed.append(dict(pid=int(item.name),rss_bytes=rss,utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
  except (OSError,ProcessLookupError,StopIteration):pass
 time.sleep(.5)
(ROOT/'WATCHDOG_00010.json').write_text(json.dumps(dict(status='FINISHED',exit_code=p.returncode,all_stage_peak_sampled_process_rss_bytes=peak,observed_own_descendant_pids=observed,terminated=killed,limit_gib=14,sampling_seconds=.5,guard_source_state_runtime_unchanged=True),indent=2)+'\n')
raise SystemExit(p.returncode)
