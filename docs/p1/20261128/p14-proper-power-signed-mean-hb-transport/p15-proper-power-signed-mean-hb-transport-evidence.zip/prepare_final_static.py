from pathlib import Path
import re,json,hashlib
ROOT=Path(__file__).resolve().parent
FINAL=ROOT/'formal-00001'
source=ROOT/'selected-sources/ImbalancedChen/P5ProperPowerSignedMeanHBTransport.lean'
result=json.loads((FINAL/'VALIDATION_RESULTS.json').read_text())
assert result['status']=='PASS_ISOLATED_NORMAL_KERNEL_FULL_OWNED'
assert json.loads((FINAL/'LANE.json').read_text())['exit_code']==0
assert json.loads((FINAL/'COUPLED_IMPORT_VALIDATION.json').read_text())['status']=='PASS'
assert source.read_bytes()==(FINAL/'SELECTED_SOURCE.lean').read_bytes()
assert source.read_bytes().replace(b'simp [signedKernel, Nat.ModEq.refl]',b'simp [signedKernel]')==(ROOT/'ORIGINAL_SOURCE.lean').read_bytes()
sha=hashlib.sha256(source.read_bytes()).hexdigest()
assert sha=='3933448b365bd84c145dccc784209093b0bc70ee2c670be0b627b807dc8b1173'
s=source.read_text()
assert len(re.findall(r'(?m)^def ',s))==5
assert len(re.findall(r'(?m)^theorem ',s))==5
assert not re.search(r'(?m)^private (def|theorem) ',s)
report={'status':'STATIC_PRESERVATION_CHECKED_AFTER_FORMAL_PASS','source_sha256':sha,'original_source_byte_exact':False,'all_original_bytes_preserved_after_removing_only_two_ModEq_refl_simp_arguments':True,'definition_count':5,'private_definition_count':0,'public_theorem_count':5,'private_theorem_count':0,'same_original_labelled_HB_integer_word_cutoffs_ambient_licence_in_count_and_mean':True,'same_arbitrary_signed_complex_rho_and_same_full_word_product_q_totient_coprime_mean':True,'target_t_independent_of_word_u':True,'product_collision_diagonal_retained_q_one_always_cancels':True,'no_claim_all_q_greater_one_diagonal_values_nonzero':True,'no_prime_plus_power_Lambda_log_identification_actual_W_N_licence_asymptotic_signed_M_full22_active_cap_or_global_payment_claim':True,'ordinary_imports':2,'actual_ordinary_source_closure':71,'not_fresh_Lake_target_or_import_closure_build_acceptance':True,'whole_P1_4_complete':False,'whole_P1_5_complete':False,'original_register':'18/21','three_ProperPower_HOLDs_unchanged':True}
(FINAL/'STATIC_SCOPE_PRESERVATION.json').write_text(json.dumps(report,indent=2)+'\n')
(ROOT/'ACCEPTED_ATTEMPT.json').write_text(json.dumps({'attempt':FINAL.name,'source_sha256':sha,'normal_kernel_audit_coupled_and_lane_verified':True},indent=2)+'\n')
print('PASS_STATIC_ORIGINAL_STATEMENTS_AND_DEFINITIONS_PRESERVED')
