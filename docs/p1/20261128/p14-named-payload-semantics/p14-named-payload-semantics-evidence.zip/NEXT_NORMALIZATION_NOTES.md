# Only if current no-image normalization still fails/is too expensive

Do not restart active formal-00003. Check normal-command.json,
VALIDATION_RESULTS.json and actual process first. Current sourceSHA is
12d0d639b08b5a8aa73e53c2d093ea059a636fb691fd4f3f71e6a996b95cbf15;
wrapper validate_00003.py restores only ORIGINAL proof options100000/4000000
from original trace. Guard -t0 -j2 -M12288, original core/kernel unchanged.
The interrupted previous formal00002 has final normal receipt exit-2,
717.980237924sec, no accepted result. Preserve it, not a math failure.

Current source has three private proven-equivalence helpers to rewrite
maxQ over a rational image into sup over original masks before numeric
expansion. SourcePick is still repeated across32 vertices and both scales.
Independent review identified this as a second potential cost.

Potential NEXT optimization, not yet implemented or compiled: on each of
TWO literal named parents, all16 OldMask subsets have sourcePick equal to
(if I.card<=2 then0 else1). Parent0 midpoint integer weights are63,61,55,53;
parent1 weights61,59,57,53, all divided by800. The three score planes meet
at s=25/128, i.e. integer sum156.25. Any <=2 selected entries have sum<=124,
any >=3 have sum>=169. Thus two private finite lookup equalities could be
proved ONCE and rewritten before unfolding sourcePick in four certificates.
Try direct standard decide/kernel finite checking; no native_decide/newaxiom.
Preserve original public definitions, A/C/cap tie order, all32 vertices,
separate32*400 and32*1600 scales, and all expected values. If this optimization
is needed, review its new exact source hashes and full audit before adopting.
Do not generalize this lookup to other archive rows or presume Key solved.

EXACT_FRACTION_DIAGNOSTIC confirms5984/5232 and29824/25152 using independent
exact Fraction arithmetic, NOT Lean/kernel acceptance. Only four literal
facts were left in formal00001 (default200k); all other API/namespace/sum/
vector issues were resolved. Matrix.vecCons unfolding caused a simp cycle;
keep cons_val_two/three/four instead. childVolume comes from original
FiveCoordinateBarycentric namespace.

Key pure row-lookup draft still awaits user path/commit; bounded repository,
proof path and MCP metadata lookups found no matching candidate. Do not
repeat global sort or invent a duplicate reported existing draft.
Both full P1.4/P1.5 remainOPEN, original register18/21 unchanged.
