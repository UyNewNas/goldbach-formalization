# Original directedQQ rational expansion, prerequisite to integer floor

Reuse accepted SharpDirectedLog.lower3_expanded/upper4_expanded via faithful
Rat->Real casts. No new Mercator/log bound or changed original1/9 tail.
Prove exact original numerator/denominator identity for Q A,B,H,d, with all
needed nonzero denominators explicit. C=H*A-d*B,Z=d*B,D=2H(A-B)-Z,Y=C-2HB.
Normalize z=Z/D,y=Y/C,a=C/(HB); use independent RN,RD,LN,LD variables in a
private fraction-combination lemma to avoid expanding all high powers.

This is original producer expression algebra only, not floor or data identity.
Integer quotient positivity,2named128 floor binding andstored2parent values
remain subsequent original obligations. No SourceChildFacts/desired integral
premise. Keep original Q80 definitions unchanged. No archive/Key/globalreserve
or P14/P15 total claim. Original18/21/3HOLD stayunchanged. Frozen Member guards,
original4M/100000 normal options, exact accepted context0oldreplay, full new
normal/kernel/owned typeExpruniverse/standard3audit, immutable attempts and
independent readonlyreview/packaging before publication.
