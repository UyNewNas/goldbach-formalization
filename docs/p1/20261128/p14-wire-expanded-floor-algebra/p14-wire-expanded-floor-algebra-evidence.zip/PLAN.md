# Next original source obligation: expanded integer floor identity

Latest accepted: arbitrary grid400 parent pick and originalD=childDQ/sourceD/
actual vertexD. Existing named128 geometry/activefield targets now accepted,
retaining original globalnames via separate owner. Legacy Data still contains
unvalidated original_all128_expanded_floors_exact and stored parent replacements.
Do not count its module asgreen. Fullbank/Key/globalreserve/P15medium remain.

Prefer exact generic producer algebra to re-evaluating128 Rational d values.
First search existing suppliers again. Reuse accepted SharpDirectedLog public
lower3_expanded andupper4_expanded (Real) through faithful Q casts; do NOT
reprove Mercator/log bounds or change original1/9 upper tail. Q80 lower3Q,
upper4Q,directedQQ,dyadicScale80 are the ORIGINAL definitions.

Let H=1024*row.hi4, C=H*A-d*B, Z=d*B, D=2*H*(A-B)-Z, Y=C-2*H*B.
Assumptions from original activefield gates: allhi>0,B>0,2B<A,2H*B<=C,d>0.
Then H,C,D>0,0<=Y<C,C²-Y²>0. D=C+H*(A-2B). Include Y=0 endpoint!
A/B-d/H=C/(H*B), z=e/(2(b-1)-e)=Z/D,
y=(b-e-2)/(b-e)=Y/C. Original expanded RN/RD andLN/LD are exactly the
existing Sharp public polynomial formulas. Combine once generically:
directedQQ(A/B,d/H)=B*(C*RN*LD-d*B*LN*RD)/(C*A*RD*LD).
For efficient ring proofs keep RN,RD,LN,LD as independent parameters in a
small private combination lemma, rather than expanding all high powers at once.
Use all necessary nonzero denominators explicitly, no SourceChildFacts premise.

Original prefactor is4*row.n*prodwireWidth/(prodrow.hi*row.hi4). All denominator
factors positive. Hence original expanded Int // expression is Int.floor of
the SAME rational minorant times2^80. Rat.floor_intCast_div_natCast (Data/Rat/
Floor.lean:55) supplies Int division equality after positive Int denominator
is identified with its toNat. Int floor with negative denominator must NOT be
silently treated as Euclidean division; positivity is an actual proof duty.
Original ExactFloor d<=0 fallback andchildFloorZ positive-branch definition
must agree including zero. General row.n need not be positive just for equality;
actual originalFields row.n=1600 andwireHi=actual endpoint gives real semantics.

Then close original_all128_expanded_floors_exact without d enumeration, using
accepted named geometry d_eq,A/B=childBQ,Bpositive, activeIntgates, wirewidth
andhi identities. Remaining allhi positivity follows from named_positive_indices
andpositive original widths/c indices (reuse actual endpoint suppliers).
Preserve original public target/fullname if extracting into another owner,
and remove original duplicate declaration/import atomically. Do NOT introduce
an import cycle: helper imports newDefinitions/named geometry/Q80, never the
legacy Data module that will import this helper.

Only afterward validate original2 stored-parent replacements by their original
INTEGER algorithm (no invented stored child arrays; NPZ stores parent fields).
Do not claim those closed values, wholebank orKey just from floor algebra.
FullBank SourceChildFacts also needs generic original AB fold/vertex licenses,
not only the named128 certificate; keep that scope separate.

Frozen Member -t0-j2-M12288 original4M/100000 options, exact source/driver/input
snapshots,0old normal/kernel. All new owner normal+kernel+full private/generated
type/Expr/universe/standard3axiom audit, independent review andsealed evidence.
Original18/21,3HOLD andboth totalP1.4/P1.5 stayopen. Key purelookup draft locator
is still awaited; do not duplicate that draft or retry fulltable sorting.
