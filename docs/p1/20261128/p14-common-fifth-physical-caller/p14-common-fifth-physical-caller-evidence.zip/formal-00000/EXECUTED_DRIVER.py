#!/usr/bin/env python3
"""Existing actual common ancestor excess only; no old proof replay."""
from pathlib import Path
import hashlib, importlib.util, json, os, shutil, sys, zipfile

ROOT = Path(__file__).resolve().parent
helper = Path('/workspace/p15-continue-20261127/docs/p1/20261127/p15-disagreement-partition/validate.py')
assert hashlib.sha256(helper.read_bytes()).hexdigest() == '04e67f06c4232a6bbd10be8d6c5419287c51a6c14e4b56e39864f230115ce6f7'
spec = importlib.util.spec_from_file_location('frozen_member_validation', helper)
driver = importlib.util.module_from_spec(spec)
spec.loader.exec_module(driver)
driver.WORK = ROOT / 'selected-sources'
driver.MODULE = 'ImbalancedChen.P5OriginalCommonFifthPhysicalCaller'
driver.SOURCE = driver.WORK / 'ImbalancedChen/P5OriginalCommonFifthPhysicalCaller.lean'
driver.OUT = ROOT / 'formal-00000'
driver.__file__ = __file__
original_run = driver.run
def original_proof_options(label, command, environment):
    if label == 'normal':
        command = [command[0], '-DmaxRecDepth=100000', '-DmaxHeartbeats=4000000', *command[1:]]
    return original_run(label, command, environment)
driver.run = original_proof_options

if '--worker' in sys.argv:
    seed = Path('/workspace/p1-complete-proof/20261128-p14-parent-four-gate-block000/formal-00000')
    seed_manifests = [seed / 'REUSED_IMPORT_LINKS.json', seed / 'REUSED_EXTRA_ALIAS_LINKS.json']
    seed_before = [driver.fingerprint(p) for p in seed_manifests]
    alias_cache = {}
    for manifest in seed_manifests:
        for link in json.loads(manifest.read_text()):
            p, target = Path(link['path']), link['target']
            assert Path(target).is_absolute() and p.is_symlink() and os.readlink(p) == target
            alias_cache.setdefault(target, p)
    stats = dict(hardlinked_symlink_inodes=0, new_symlinks=0,
        only_exact_absolute_targets=True, independent_output_namespaces=True)
    original_symlink_to = Path.symlink_to
    def share_symlink_inode(self, target, target_is_directory=False):
        cached = alias_cache.get(str(target))
        if cached is None:
            original_symlink_to(self, target, target_is_directory=target_is_directory)
            stats['new_symlinks'] += 1
        else:
            assert cached.is_symlink() and os.readlink(cached) == str(target)
            os.link(cached, self, follow_symlinks=False)
            stats['hardlinked_symlink_inodes'] += 1
        assert self.is_symlink() and os.readlink(self) == str(target)
    Path.symlink_to = share_symlink_inode
    shutil.copyfile(driver.SOURCE, driver.OUT / 'SELECTED_SOURCE.lean')
    shutil.copyfile(__file__, driver.OUT / 'EXECUTED_DRIVER.py')
    records = []
    pinned_inputs = {}
    duplicate_pin_references = 0
    def pin(fp):
        global duplicate_pin_references
        if fp['path'] in pinned_inputs:
            assert pinned_inputs[fp['path']] == fp, fp['path']
            duplicate_pin_references += 1
            return
        assert driver.fingerprint(Path(fp['path'])) == fp, fp['path']
        pinned_inputs[fp['path']] = fp
        records.append(fp)
    for name in ['PLAN.md', 'REUSED_CONTEXTS.json', 'SOURCE_GIT_COUPLING.json', 'SOURCE_CHANGE_PLAN.json', 'ORIGINAL_SOURCE.lean']:
        records.append(driver.fingerprint(ROOT / name))
    namespace = driver.OUT / 'build/lib/lean/ImbalancedChen'
    namespace.mkdir(parents=True, exist_ok=True)
    aliases = []
    reviewed_roots = set()
    contexts = json.loads((ROOT / 'REUSED_CONTEXTS.json').read_text())
    assert len(contexts) == 8
    for context in contexts:
        receipt = Path(context['receipt'])
        result = json.loads(receipt.read_text())
        assert result['status'] == 'PASS_ISOLATED_NORMAL_KERNEL_FULL_OWNED'
        assert result['module'] == context['module']
        source = result.get('source', result.get('inputs', {}).get('source'))
        assert source == context['source']
        pin(source)
        records.append(driver.fingerprint(receipt))
        for stage in ['normal', 'kernel', 'audit']:
            assert result[stage]['exit_code'] == 0
            pin(result[stage]['log'])
        for fp in context['objects']:
            pin(fp)
            p = Path(fp['path'])
            if p.suffix in ['.olean', '.ilean']:
                target = namespace / p.name
                assert not target.exists()
                target.symlink_to(p)
                aliases.append(dict(path=str(target), target=str(p)))
        coupled = receipt.parent / 'COUPLED_IMPORT_VALIDATION.json'
        if coupled.exists():
            x = json.loads(coupled.read_text())
            assert x['status'] == 'PASS'
            records.append(driver.fingerprint(coupled))
            if 'inputs' in x:
                assert x['accepted_import_normal_or_kernel_commands'] == 0
                for fp in x['inputs']:
                    pin(fp)
            else:
                assert x['reused_module_normal_or_kernel_commands'] == 0
                pin(x['original_receipt'])
                before = receipt.parent / 'RESIDUAL_IMPORT_BEFORE.json'
                after = receipt.parent / 'RESIDUAL_IMPORT_AFTER.json'
                initial = json.loads(before.read_text())
                assert initial == json.loads(after.read_text())
                records.extend(driver.fingerprint(p) for p in [before, after])
                for fp in initial:
                    pin(fp)
        elif 'inputs' in result:
            for dep_objects in result['inputs']['dependencies'].values():
                for fp in dep_objects:
                    pin(fp)
        else:
            before = receipt.parent / 'SOURCE_AND_REUSED_IMPORT_BEFORE.json'
            after = receipt.parent / 'SOURCE_AND_REUSED_IMPORT_AFTER.json'
            initial = json.loads(before.read_text())
            assert initial == json.loads(after.read_text())
            records.extend(driver.fingerprint(p) for p in [before, after])
            for fp in initial:
                pin(fp)
        root = Path(context.get('review_root', context['root']))
        review = json.loads((root / 'INDEPENDENT_REVIEW.json').read_text())
        assert review['blocking_findings'] == []
        if 'source_sha256' in review:
            reviewed = review['source_sha256']
            if isinstance(reviewed, dict):
                reviewed = reviewed[context['module']]
            assert reviewed == source['sha256']
        if 'source_fingerprints' in review:
            assert any(fp['sha256'] == source['sha256'] for fp in review['source_fingerprints'])
        archive_metadata = json.loads((root / 'ARCHIVE.json').read_text())
        archive = root / archive_metadata['archive']
        assert driver.fingerprint(archive)['sha256'] == archive_metadata['sha256']
        with zipfile.ZipFile(archive) as z:
            assert z.testzip() is None
            candidates = [n for n in z.namelist() if n.endswith('/' + Path(source['path']).name)]
            assert any(hashlib.sha256(z.read(n)).hexdigest() == source['sha256'] for n in candidates)
        if root not in reviewed_roots:
            records.extend(driver.fingerprint(root / n) for n in ['INDEPENDENT_REVIEW.json', 'ARCHIVE.json'])
            reviewed_roots.add(root)
    # Reuse original Preservation owner: normal, sole-module kernel, actual all-owned audit.
    old_root = Path('/workspace/p1-complete-proof/20261125-batch11-four-repairs-v1/audits/ca6c0c3d6a9a46812ea8/lane-0')
    old_receipt = old_root / 'VALIDATION_RESULTS.json'
    old = json.loads(old_receipt.read_text())
    mod = 'ImbalancedChen.P5OriginalCommonRefinedPreservation'
    assert old['status'] == 'PASS_NORMAL_KERNEL_ALL_ENVIRONMENT_OWNED_TYPES_AXIOMS'
    assert old['runtime_state_sha256'] == driver.STATE_SHA
    assert old['full_owned_including_private_generated'] and old['only_standard_axioms']
    assert old['source_plus_five_outputs_unchanged_across_kernel_and_audit']
    assert old['modules'][mod] == 'ddca6c374ca3e3722d4498f17a2543b610fa8c2e241b13e79903a4829a803aaf'
    records.append(driver.fingerprint(old_receipt))
    project = Path('/workspace/blue-member-build')
    for relative, fp in old['source_plus_five_outputs'][mod].items():
        actual = driver.fingerprint(project / relative)
        assert {k: actual[k] for k in ['bytes', 'sha256']} == fp
        records.append(actual)
    normal = old['reused_normal_evidence'][mod]
    normal_log = Path(normal['path'])
    assert driver.fingerprint(normal_log)['sha256'] == normal['sha256']
    assert normal['all_actual_built_modules'] == [mod]
    records.append(driver.fingerprint(normal_log))
    kernel = old['kernel_commands'][mod]
    assert kernel['exit_code'] == 0
    kernel_log = old_root / kernel['log']
    assert driver.fingerprint(kernel_log)['sha256'] == kernel['log_sha256']
    assert [line.removeprefix('replaying ') for line in kernel_log.read_text().splitlines()
        if line.startswith('replaying ')] == [mod]
    records.append(driver.fingerprint(kernel_log))
    audit = old['audit_command']
    assert audit['exit_code'] == 0
    audit_log = old_root / audit['log']
    assert driver.fingerprint(audit_log)['sha256'] == audit['log_sha256']
    records.append(driver.fingerprint(audit_log))
    records.append(driver.fingerprint(old_root / 'OWNED_EXPORTS.json'))
    # Original SeedHull owner reused byte-exact; no proof replay.
    seed_owner_root = Path('/workspace/p1-complete-proof/20261125-p14-continuation/bytes-frame-seed/540244f58dcfa10e035c12c7196597ee2198f327/audits/e7b1df620ddebe744e46/lane-0')
    seed_receipt = seed_owner_root / 'VALIDATION_RESULTS.json'
    old_seed = json.loads(seed_receipt.read_text())
    seed_module = 'ImbalancedChen.P5OriginalCommonRefinedSeedHull'
    assert old_seed['status'] == 'PASS_NORMAL_KERNEL_ALL_ENVIRONMENT_OWNED_TYPES_AXIOMS'
    assert old_seed['runtime_state_sha256'] == driver.STATE_SHA
    assert old_seed['full_owned_including_private_generated'] and old_seed['only_standard_axioms']
    assert old_seed['source_plus_five_outputs_unchanged_across_kernel_and_audit']
    assert old_seed['modules'][seed_module] == '10f01c955220dd6ef6d9453f2b83919a75501bfc6c421d9828466d063809f55b'
    records.append(driver.fingerprint(seed_receipt))
    for relative, fp in old_seed['source_plus_five_outputs'][seed_module].items():
        actual = driver.fingerprint(project / relative)
        assert {k: actual[k] for k in ['bytes', 'sha256']} == fp
        records.append(actual)
    original_normal = old_seed['reused_normal_evidence'][seed_module]
    normal_log = Path(original_normal['path'])
    assert driver.fingerprint(normal_log)['sha256'] == original_normal['sha256']
    records.append(driver.fingerprint(normal_log))
    original_kernel = old_seed['kernel_commands'][seed_module]
    assert original_kernel['exit_code'] == 0
    kernel_log = seed_owner_root / original_kernel['log']
    assert driver.fingerprint(kernel_log)['sha256'] == original_kernel['log_sha256']
    assert [line.removeprefix('replaying ') for line in kernel_log.read_text().splitlines()
        if line.startswith('replaying ')] == [seed_module]
    records.append(driver.fingerprint(kernel_log))
    original_audit = old_seed['audit_command']
    assert original_audit['exit_code'] == 0
    audit_log = seed_owner_root / original_audit['log']
    assert driver.fingerprint(audit_log)['sha256'] == original_audit['log_sha256']
    records.append(driver.fingerprint(audit_log))
    records.append(driver.fingerprint(seed_owner_root / 'OWNED_EXPORTS.json'))
    ordinary_path = ROOT / 'ORDINARY_IMPORT_SIX_FIELDS.json'
    ordinary = json.loads(ordinary_path.read_text())
    assert ordinary['ordinary_existing_import'] and ordinary['independent_owner_kernel_full_owned_not_claimed']
    records.append(driver.fingerprint(ordinary_path))
    for fp in ordinary['source_and_five_outputs']:
        pin(fp)
    driver.save('IMPORT_PIN_DEDUPLICATION.json', dict(unique_pin_inputs=len(pinned_inputs),
        duplicate_references=duplicate_pin_references, inconsistent_repeat_rejected=True,
        each_unique_pin_before_after_checked=True, original_receipt_provenance_preserved=True,
        guard_core_runtime_and_formal_checks_unchanged=True))
    records.extend(seed_before)
    driver.save('COUPLED_IMPORTS_BEFORE.json', records)
    driver.save('REUSED_EXTRA_ALIAS_LINKS.json', aliases)
    driver.main()
    Path.symlink_to = original_symlink_to
    driver.save('IMPORT_ALIAS_STORAGE.json', stats)
    assert seed_before == [driver.fingerprint(p) for p in seed_manifests]
    assert records == [driver.fingerprint(Path(fp['path'])) for fp in records]
    assert all(Path(a['path']).is_symlink() and os.readlink(a['path']) == a['target'] for a in aliases)
    driver.save('COUPLED_IMPORT_VALIDATION.json', dict(status='PASS', inputs=records,
        reused_contexts=8, accepted_import_normal_or_kernel_commands=0,
        whole_P1_4_complete=False, whole_P1_5_complete=False))
else:
    driver.main()
