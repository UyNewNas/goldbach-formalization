import ImbalancedChen.P5NamedFifthQ80FloorSoundness
import ImbalancedChen.P5OriginalChildIntegerWireDefinitions
import ImbalancedChen.P5OriginalNamedWireGeometryFields
import ImbalancedChen.P5OriginalWireExpandedFloorAlgebra

/-!
Original producer geometry and exact-floor binding for two named parents.
Independent transcription of the ORIGINAL producer integer geometry and
exact_floor(log_terms=4), followed by actual two-parent/128-child bindings.
Neither producer d nor its A/B is defined using the proposed rational
candidate. Parent midpoint argmin, strict ratio updates, integer planes,
vertex sum and expanded exact-floor numerator are separate definitions.

The archived subdivision NPZ stores indices/old_floor/new_floor PER PARENT;
it does NOT store per-child d/A/B. The latter are reconstructed source
expressions, not falsely attributed stored NPZ fields. Formal acceptance is recorded separately by the isolated normal/kernel audit.
-/
namespace ImbalancedChen.P5OriginalChildIntegerWireBinding

open scoped BigOperators
open P1OriginalPrefixRowDecodeSoundness
open P5NamedFifthPayloadSemantics P5NamedFifthAllChildren
open P5NamedFifthChildSpecificRatio P5NamedFifthQ80FloorSoundness
open P5OldFifthExact64ChildTiling P5OldFifthChildGapIntegral
open P5OldFifthFrozenUpperSurrogate

/-- Same original integer floor, instantiated on all 128 actual named children.
The source d/AB identities and active gates are independently established. -/
theorem original_all128_expanded_floors_exact :
    ∀ b : Bool, ∀ c : ChildIndex,
      originalExactFloor (originalFields (namedParent b) c) = childFloorZ b c := by
  intro b c
  obtain ⟨hd_eq, hB, hAB⟩ := original_all128_geometry_fields b c
  have hactive : 0 < (originalFields (namedParent b) c).d →
      (∀ i : Fin 5, 0 < (originalFields (namedParent b) c).hi i) ∧
      0 < (originalFields (namedParent b) c).B ∧
      2 * (originalFields (namedParent b) c).B < (originalFields (namedParent b) c).A ∧
      2 * (1024 * (originalFields (namedParent b) c).hi 4) *
          (originalFields (namedParent b) c).B ≤
        (1024 * (originalFields (namedParent b) c).hi 4) *
          (originalFields (namedParent b) c).A -
            (originalFields (namedParent b) c).d * (originalFields (namedParent b) c).B := by
    intro hd
    obtain ⟨h2, _, hg⟩ := original_all128_active_field_gates b c hd
    refine ⟨?_, hB, h2, hg⟩
    intro i
    rw [P5OriginalGenericWireFloorReceiver.original_hi_eq_actual]
    have hp : 0 < (namedParent b).lo i := lt_of_lt_of_le (by norm_num) (named_positive_indices b i)
    have hw : (0 : ℤ) < (width i : ℤ) := by fin_cases i <;> decide
    dsimp only [childRightNumer, childLeftNumer]
    positivity
  have h := P5OriginalWireExpandedFloorAlgebra.originalExactFloor_eq_directed_floor
    (originalFields (namedParent b) c) hactive
  have hn : (originalFields (namedParent b) c).n = 1600 := rfl
  have hw : ∀ i : Fin 5, (wireWidth i : ℚ) = (width i : ℚ) := by
    intro i
    fin_cases i <;> norm_num [wireWidth, width]
  simpa only [childFloorZ, childMinorantQ, prefactorQ, childEQ, hn, hd_eq, hAB,
    P5OriginalGenericWireFloorReceiver.original_hi_eq_actual, hw, Int.cast_ofNat] using h

/-- Actual stored PER-PARENT fields, statically extracted from block0000
indices0/1. There is no invented stored per-child array. -/
def storedParentOld (b : Bool) : ℤ :=
  if b then 14082959319322957 else 15820276063068009

def storedParentNew (b : Bool) : ℤ :=
  if b then 22702709338745202 else 24665590035783072

def reconstructedParentReplacement (b : Bool) : ℤ :=
  max (storedParentOld b)
    (∑ c : ChildIndex, originalExactFloor (originalFields (namedParent b) c))

/-- Separate kernel certificates keep each original64-child parent reduction
inside the unchanged lane budget. No parent expression or stored value changes. -/
private theorem parent_false_replacement_exact :
    reconstructedParentReplacement false = storedParentNew false := by
  decide +kernel

private theorem parent_true_replacement_exact :
    reconstructedParentReplacement true = storedParentNew true := by
  decide +kernel

/-- Binding of independently read stored fields to the original source
replacement expression. Only the two displayed original parents are
checked; this is not a whole-bank/pair total. -/
theorem stored_first_two_parent_replacements_exact :
    ∀ b : Bool, reconstructedParentReplacement b = storedParentNew b := by
  intro b
  cases b
  · exact parent_false_replacement_exact
  · exact parent_true_replacement_exact

theorem stored_first_two_new_strictly_exceed_old (b : Bool) :
    storedParentOld b < storedParentNew b := by
  cases b <;> decide

/-- These TWO stored replacements choose their complete child sum. No
old parent floor is added to its children, and no pair total is evaluated. -/
theorem stored_first_two_new_eq_complete_child_sum (b : Bool) :
    storedParentNew b =
      ∑ c : ChildIndex, originalExactFloor (originalFields (namedParent b) c) := by
  have h := stored_first_two_parent_replacements_exact b
  unfold reconstructedParentReplacement at h
  have hlt := stored_first_two_new_strictly_exceed_old b
  have hle : storedParentOld b ≤
      ∑ c : ChildIndex, originalExactFloor (originalFields (namedParent b) c) := by
    by_contra hn
    have hsmall : (∑ c : ChildIndex,
        originalExactFloor (originalFields (namedParent b) c)) ≤ storedParentOld b :=
      (lt_of_not_ge hn).le
    rw [max_eq_left hsmall] at h
    linarith
  rw [max_eq_right hle] at h
  exact h.symm

noncomputable section
open scoped Classical

/-- Real geometry fields remain attached to the SAME child index. -/
theorem original_lo_is_actual (b : Bool) (c : ChildIndex) (i : Fin 5) :
    (originalFields (namedParent b) c).lo i = childLeftNumer (namedParent b) c i := by
  have hw : wireWidth i = (width i : ℤ) := by fin_cases i <;> decide
  simp [originalFields, wireLo, childLeftNumer, hw]

theorem original_hi_is_actual (b : Bool) (c : ChildIndex) (i : Fin 5) :
    (originalFields (namedParent b) c).hi i = childRightNumer (namedParent b) c i := by
  have hw : wireWidth i = (width i : ℤ) := by fin_cases i <;> decide
  simp [originalFields, wireHi, wireLo, childRightNumer, childLeftNumer, hw]

/-- The original reconstructed field expression inherits the existing
sharp directed-log soundness without redoing a Mercator/Jensen proof. -/
theorem reconstructed_original_floor_sound (b : Bool) (c : ChildIndex) :
    ((originalExactFloor (originalFields (namedParent b) c) : ℤ) : ℝ) /
        (2 : ℝ) ^ 80 ≤
      P5ChildSelectedOwnerJensenReserve.certifiedChildJensen
        (sourcePicks (namedParent b)) (namedParent b) c
        (childBQ b c) (sourceChildD (namedParent b) c) := by
  rw [original_all128_expanded_floors_exact]
  simpa [childFloorQ, ImbalancedChen.Certificates.P2DirectedLogRounding.dyadicScale]
    using childFloorQ_le_actual_certified_Jensen b c

end
end ImbalancedChen.P5OriginalChildIntegerWireBinding
