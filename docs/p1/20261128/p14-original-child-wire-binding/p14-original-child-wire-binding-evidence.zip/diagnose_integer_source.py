"""DIAGNOSTIC ONLY: direct integer transcription, not a Lean certificate."""
import itertools,json,math
from pathlib import Path
W=(2,2,2,2,1)
BITS=list(itertools.product((False,True),repeat=5))
def parent(lo,old,new):
    picks=[]
    for mask in range(1,16):
        ss=sum(2*lo[i]+1 for i in range(4) if mask>>i&1)
        a,c,k=12800+16*ss,22800-48*ss,15300
        picks.append(0 if a<=c and a<=k else 1 if c<=k else 2)
    rows=[]
    for child in itertools.product(range(2),range(2),range(2),range(2),range(4)):
        l=tuple(4*x+w*j for x,w,j in zip(lo,W,child));h=tuple(x+w for x,w in zip(l,W))
        vertices=[tuple(x+(w if bit else 0) for x,w,bit in zip(l,W,bits)) for bits in BITS]
        d=0;planes=[[],[]]
        for v in vertices:
            oldplanes=[]
            for mask,pick in zip(range(1,16),picks):
                ss=sum(v[i] for i in range(4) if mask>>i&1)
                oldplanes.append(25600+16*ss if pick==0 else 45600-48*ss if pick==1 else 30600)
            oldnumer=max(30600-12*v[2],*oldplanes)
            ss=sum(v[2:5]);a,c=25600+16*ss,45600-48*ss
            d+=min(a,c)-max(oldnumer,32*(sum(v)+2*v[4]))
            for dest,plane in zip(planes,(a,c)):dest.append((plane-32*sum(v),32*v[4]))
        def maximum(xs):
            best=xs[0]
            for nxt in xs[1:]:
                if best[0]*nxt[1]<nxt[0]*best[1]:best=nxt
            return best
        aa,cc=map(maximum,planes)
        A,B=cc if cc[0]*aa[1]<aa[0]*cc[1] else aa
        if d<=0:floor=0;denpositive=None
        else:
            H=1024*h[4];C=H*A-d*B;Z=d*B;D=2*H*(A-B)-Z
            RN=2*Z*(15*D**4+5*Z**2*D**2+3*Z**4);RD=15*D**5
            Y=C-2*H*B;cs=C**2;ys=Y**2
            LN=2*Y*(315*cs**4-210*ys*cs**3-42*ys**2*cs**2-18*ys**3*cs-10*ys**4)
            LD=315*C**7*(cs-ys)
            DN=B*(C*RN*LD-d*B*LN*RD);DD=C*A*RD*LD
            N=4*1600*math.prod(W)*DN;Den=math.prod(h)*h[4]*DD
            denpositive=Den>0
            assert denpositive
            floor=N*2**80//Den
        rows.append(dict(child=child,d=d,A=A,B=B,floor=str(floor),denominator_positive=denpositive))
    total=sum(int(r['floor']) for r in rows)
    return dict(lo=lo,old=str(old),stored_new=str(new),child_sum=str(total),replacement=str(max(old,total)),matches=max(old,total)==new,rows=rows)
result=dict(status='PYTHON_DIAGNOSTIC_ONLY_NOT_FORMAL',parents=[parent((31,30,27,26,25),15820276063068009,24665590035783072),parent((30,29,28,26,25),14082959319322957,22702709338745202)])
Path(__file__).with_name('INTEGER_SOURCE_DIAGNOSTIC.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps([{k:v for k,v in p.items() if k!='rows'} for p in result['parents']],indent=2))
