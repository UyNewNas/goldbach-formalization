import Lean

/- Read-only serialized Expr inspection. No theorem, proof replay, evaluator
   admission or concrete JSON/shape assertion is added by this IO program. -/
open Lean

private def naturalLiteral (e : Expr) : IO Nat := do
  match e.consumeMData with
  | .lit (.natVal n) => return n
  | _ => throw <| IO.userError "quoted packed argument is not a Nat literal"

private partial def writeTree (e : Expr) (out : IO.FS.Handle) : IO (Nat × Nat) := do
  let e := e.consumeMData
  let args := e.getAppArgs
  match e.getAppFn with
  | .const name _ =>
    if name == `ImbalancedChen.P2OriginalSaving19PackedChars.Tree.empty then
      unless args.isEmpty do throw <| IO.userError "empty constructor has arguments"
      return (0, 0)
    else if name == `ImbalancedChen.P2OriginalSaving19PackedChars.Tree.branch then
      unless args.size == 2 do throw <| IO.userError "branch arity mismatch"
      let (nl, ll) ← writeTree args[0]! out
      let (nr, lr) ← writeTree args[1]! out
      return (nl + nr, ll + lr)
    else if name == `ImbalancedChen.P2OriginalSaving19PackedChars.Tree.leaf then
      unless args.size == 2 do throw <| IO.userError "leaf arity mismatch"
      let count ← naturalLiteral args[0]!
      let mut word ← naturalLiteral args[1]!
      if 256 < count then throw <| IO.userError "quoted leaf exceeds original blockLimit"
      let mut chars : List Char := []
      for _ in [:count] do
        let code := word % 4294967296
        if 0x10ffff < code ∨ (0xd800 ≤ code ∧ code ≤ 0xdfff) then
          throw <| IO.userError "invalid original Unicode scalar"
        chars := Char.ofNat code :: chars
        word := word / 4294967296
      unless word == 0 do throw <| IO.userError "packed word has unaccounted high digits"
      out.putStr (String.ofList chars.reverse)
      return (count, 1)
    else throw <| IO.userError ("unexpected quoted constructor: " ++ name.toString)
  | _ => throw <| IO.userError "quoted tree head is not a constructor constant"

unsafe def main (args : List String) : IO Unit := do
  unless args.length == 1 do throw <| IO.userError "usage: ReadQuotedInputs.lean OUTPUT_DIR"
  let outputDir : System.FilePath := args[0]!
  IO.FS.createDirAll outputDir
  initSearchPath (← findSysroot)
  for kind in ["Geometry", "Moment"] do
    for i in [:13] do
      let suffix := (if i < 10 then "0" else "") ++ toString i
      let modName := Name.str `ImbalancedChen ("P2OriginalSaving19Archive" ++ kind ++ "Data" ++ suffix)
      let constName := Name.str `ImbalancedChen.P2OriginalSaving19Archive
        ((if kind == "Geometry" then "geometry" else "moment") ++ "Packed" ++ suffix)
      let path := outputDir / (kind ++ suffix ++ ".json")
      let (count, leaves) ← withImportModules #[{module := modName}] {} fun env => do
        let some info := env.find? constName
          | throw <| IO.userError ("missing quoted definition " ++ constName.toString)
        let some value := info.value?
          | throw <| IO.userError ("quoted input is not a definition " ++ constName.toString)
        let out ← IO.FS.Handle.mk path IO.FS.Mode.write
        let counts ← writeTree value out
        out.flush
        return counts
      IO.println <| (Json.mkObj [("module", toJson modName.toString),
        ("constant", toJson constName.toString), ("characters", toJson count),
        ("leaves", toJson leaves), ("output", toJson path.toString)]).compress
