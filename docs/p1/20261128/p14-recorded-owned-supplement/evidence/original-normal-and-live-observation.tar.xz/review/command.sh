python3 -B - <<'P14_RECORDED_READ'
#!/usr/bin/env python3
"""Read only the exact original Recorded normal log/context and its live six files.

No Lean/Lake/guard invocation, directory walk, Git mutation, or remote file write.
The sole output is one bounded JSON transport record preserving the full log.
"""
from pathlib import Path
import base64
import hashlib
import json
import os
import re
import signal
import stat
import sys
import zlib

if not __debug__:
    raise RuntimeError('optimized Python is forbidden for this evidence reader')

# Filled from the reviewable PARAMETERS.json without changing the code below.
PARAMETERS_RAW = b'{\n  "schema": "p14_recorded_original_normal_bounded_read_parameters_v1",\n  "module": "ImbalancedChen.P5RecordedOldFifthBlockTotals",\n  "normal_log": {\n    "path": "/workspace/p1-complete-proof/modern-p1-build/incremental-six-root-after-source-repairs/normal.log",\n    "sha256": "63da4b14f4b1f9dda09882e90464cf8cffd322667471932e2a4e4b2898ae8bb9",\n    "maximum_bytes": 67108864\n  },\n  "source_context": {\n    "path": "/workspace/p1-complete-proof/modern-p1-build/incremental-six-root-after-source-repairs/SOURCE_CONTEXT.json",\n    "bytes": 550997,\n    "sha256": "db2dfc6e2ae8357ded33da4d3f5f938284db78ebaf5d6caa17d097d4ff5f3538",\n    "maximum_bytes": 1048576\n  },\n  "original_command": {\n    "repository_path": "docs/verification/20261123-blue-compilation/member-repair-batch96/P5OriginalTaylorFiveDimensionalMidpoint/static-provenance/ACTUAL_COMMAND.json",\n    "bytes": 9862,\n    "sha256": "c4831ed2e770a24776e23431d1a601cda0b8b8dce823430674fdddb05736ddc0",\n    "exit_code": 1\n  },\n  "original_expected_built_modules": [\n    "ImbalancedChen.P4AOriginalEighthParentPhysicalLedger",\n    "ImbalancedChen.P2OriginalFourteenSignedParentLedger",\n    "ImbalancedChen.P1OriginalCoarseFifthCellIntegral",\n    "ImbalancedChen.P1VariableFifthSelectedStoredBinding",\n    "ImbalancedChen.P1VariableFifthOriginalBaseQ3Bridge",\n    "ImbalancedChen.P1CorrectedFifthDensityDictionary",\n    "ImbalancedChen.P1CorrectedFifthVariableResidualApproximation",\n    "ImbalancedChen.Part5RenewalTablePositivity",\n    "ImbalancedChen.P5LiteralHeathBrownOccurrenceWords",\n    "ImbalancedChen.P4AOriginalFull87ArchivedStageNumericReconcile",\n    "ImbalancedChen.P2Winner9CompleteSeedTypes",\n    "ImbalancedChen.P2Winner9Row21RawVertexData",\n    "ImbalancedChen.P2Winner9CompleteSeedBlock43",\n    "ImbalancedChen.P2Winner9CompleteSeedVertices",\n    "ImbalancedChen.P2Winner9CurvatureExactMomentFloor",\n    "ImbalancedChen.P2Winner9CurvatureFullExactAssembly",\n    "ImbalancedChen.ActualExtendedThirdDistinctProductHarmonic",\n    "ImbalancedChen.ActualExtendedThirdInitialCutoff",\n    "ImbalancedChen.P2Winner9MixedDegreeSixExactAssembly",\n    "ImbalancedChen.P2Winner9MixedZeroCoefficientCurvatureLink",\n    "ImbalancedChen.P2Winner9MixedDegreeOnePolynomialMoment",\n    "ImbalancedChen.ActualThirdOriginalSharpChord",\n    "ImbalancedChen.P2Winner9BarycentricMixedDegreeOne",\n    "ImbalancedChen.ActualThirdOriginalWeights",\n    "ImbalancedChen.P2Winner9PhysicalAffineTransfer",\n    "ImbalancedChen.ActualThirdOriginalWeightedCurvature",\n    "ImbalancedChen.ActualThirdOriginalLiteralNodes",\n    "ImbalancedChen.ActualThirdOriginalRationalQuery",\n    "ImbalancedChen.ActualThirdOriginalOrdinaryOldChord",\n    "ImbalancedChen.ActualThirdOriginalSymmetricJensenLeaf",\n    "ImbalancedChen.ActualThirdOriginalSymmetricClippedMean",\n    "ImbalancedChen.ActualThirdOriginalRoundedNewMean",\n    "ImbalancedChen.Certificates.OriginalNodeArraysV1.DataCore",\n    "ImbalancedChen.Part4ActualThirdOriginalStoredNodeLocalChecker",\n    "ImbalancedChen.ActualThirdOriginalBelowMuBCandidate",\n    "ImbalancedChen.ActualThirdOriginalPositive256LogRange32",\n    "ImbalancedChen.Certificates.OriginalNodeArraysV1.CheckerCore",\n    "ImbalancedChen.ActualThirdOriginalStoredNodeQueryLookup",\n    "ImbalancedChen.P4AActualLowerIncrementGapBound",\n    "ImbalancedChen.P5RecordedOldFifthBlockTotals",\n    "ImbalancedChen.Part4ActualThirdOriginalFirstChordQuery",\n    "ImbalancedChen.P1OriginalFourthRawTableMetadata"\n  ],\n  "original_expected_failed_modules": [\n    "ImbalancedChen.P1OriginalPrefixRowDecodeSoundness",\n    "ImbalancedChen.P1OriginalProducerAttainedRowBinding",\n    "ImbalancedChen.P2InheritedFourthRaw31Embedding",\n    "ImbalancedChen.P2ActualFifthCandidateBelowSixthRaw31",\n    "ImbalancedChen.P4AActualEighthInheritedHistoryGuard",\n    "ImbalancedChen.OriginalAscendingThirteenLiteralAffineRows",\n    "ImbalancedChen.OriginalDescendingFifteenExportOwnershipJoin",\n    "ImbalancedChen.P5ZU1011OriginalSixteenPolicyBank",\n    "ImbalancedChen.P4AOriginalAscending14Literal42",\n    "ImbalancedChen.OriginalEighthCommonBetaWidthPayment",\n    "ImbalancedChen.P5OriginalAdoptedEighthPhysicalMasks",\n    "ImbalancedChen.P4AOriginalH5H7SourceDispatch",\n    "ImbalancedChen.P1OriginalCoarseFifthCellLimit",\n    "ImbalancedChen.P1OriginalVariableFourthSourceCoefficient",\n    "ImbalancedChen.P1OriginalFourthSmallRemainderBound",\n    "ImbalancedChen.P5ZU11LoweredCutoffFiniteRosser",\n    "ImbalancedChen.Part3ActualPrefixWinnerComplement",\n    "ImbalancedChen.P1CorrectedFifthStoredH45Check",\n    "ImbalancedChen.P5ZU1011H248CommonPartition",\n    "ImbalancedChen.P5ZU1011BufferedOrdinaryClamp",\n    "ImbalancedChen.ActualPrimeFineWordMultiplicity",\n    "ImbalancedChen.P4ASpliceDifferenceLowerModulus",\n    "ImbalancedChen.P1AffineBoxCompleteness",\n    "ImbalancedChen.P4AUpperTaggedParityCompiler",\n    "ImbalancedChen.P2ActualResidualUniverseMass",\n    "ImbalancedChen.P2LowerCanonicalRetainedTrace",\n    "ImbalancedChen.P2LowerFiniteCellBetaCompiler",\n    "ImbalancedChen.P2OriginalPairRootRoughProducer",\n    "ImbalancedChen.P5OriginalFeedbackTableKernels",\n    "ImbalancedChen.P5OriginalPrimeEndpointDivisors",\n    "ImbalancedChen.P5ActualRoughHeathBrownWords",\n    "ImbalancedChen.P4BSmoothRealBCompactFamily",\n    "ImbalancedChen.P4BSmoothPrimeVariableProfile",\n    "ImbalancedChen.P4BPhysicalRampMassReserve",\n    "ImbalancedChen.P4BSmoothProfileDirectionalDerivativeBudget",\n    "ImbalancedChen.P2OriginalFirstIntegralEndpoint",\n    "ImbalancedChen.Part3RoughFiniteEulerLogDerivative",\n    "ImbalancedChen.P5SubdivisionStoredParentArchive",\n    "ImbalancedChen.P2Winner9CompleteSeedBlock42",\n    "ImbalancedChen.P2Winner9CompleteSeedBlock41",\n    "ImbalancedChen.P2Winner9CompleteSeedBlock40",\n    "ImbalancedChen.P2Winner9CompleteSeedBlock39",\n    "ImbalancedChen.P2Winner9CompleteSeedBlock38",\n    "ImbalancedChen.P2Winner9CompleteSeedBlock37",\n    "ImbalancedChen.P2Winner9CompleteSeedBlock36",\n    "ImbalancedChen.P2Winner9CompleteSeedBlock35",\n    "ImbalancedChen.P2Winner9CompleteSeedBlock34",\n    "ImbalancedChen.P2Winner9CompleteSeedBlock33",\n    "ImbalancedChen.P2Winner9CompleteSeedBlock32",\n    "ImbalancedChen.P2Winner9CompleteSeedBlock31",\n    "ImbalancedChen.P2Winner9CompleteSeedBlock30",\n    "ImbalancedChen.P2Winner9CompleteSeedBlock29",\n    "ImbalancedChen.P2Winner9CompleteSeedBlock28",\n    "ImbalancedChen.P2Winner9CompleteSeedBlock27",\n    "ImbalancedChen.P2Winner9CompleteSeedBlock26",\n    "ImbalancedChen.P2Winner9CompleteSeedBlock25",\n    "ImbalancedChen.P2Winner9CompleteSeedBlock24",\n    "ImbalancedChen.P2Winner9CompleteSeedBlock23",\n    "ImbalancedChen.P2Winner9CompleteSeedBlock22",\n    "ImbalancedChen.P2Winner9CompleteSeedBlock21",\n    "ImbalancedChen.P2Winner9CompleteSeedBlock20",\n    "ImbalancedChen.P2Winner9CompleteSeedBlock19",\n    "ImbalancedChen.P2Winner9CompleteSeedBlock18",\n    "ImbalancedChen.P2Winner9CompleteSeedBlock17",\n    "ImbalancedChen.P2Winner9CompleteSeedBlock16",\n    "ImbalancedChen.P2Winner9CompleteSeedBlock15",\n    "ImbalancedChen.P2Winner9CompleteSeedBlock14",\n    "ImbalancedChen.P2Winner9CompleteSeedBlock13",\n    "ImbalancedChen.P2Winner9CompleteSeedBlock12",\n    "ImbalancedChen.P2Winner9CompleteSeedBlock11",\n    "ImbalancedChen.P2Winner9CompleteSeedBlock10",\n    "ImbalancedChen.P2Winner9CompleteSeedBlock09",\n    "ImbalancedChen.P2Winner9CompleteSeedBlock08",\n    "ImbalancedChen.P2Winner9CompleteSeedBlock07",\n    "ImbalancedChen.P2Winner9CompleteSeedBlock06",\n    "ImbalancedChen.P2Winner9CompleteSeedBlock05",\n    "ImbalancedChen.P2Winner9CompleteSeedBlock04",\n    "ImbalancedChen.P2Winner9CompleteSeedBlock03",\n    "ImbalancedChen.P2Winner9CompleteSeedBlock02",\n    "ImbalancedChen.P2Winner9CompleteSeedBlock01",\n    "ImbalancedChen.P2Winner9CompleteSeedBlock00",\n    "ImbalancedChen.P2Winner9SelectedRowEdgeGeometry",\n    "ImbalancedChen.P2OriginalSeedChronologicalMaxArithmetic",\n    "ImbalancedChen.P2Winner9Row21PrimitiveBinding",\n    "ImbalancedChen.ActualExtendedThirdCompactFrontier",\n    "ImbalancedChen.P2ContinuousSieveRational",\n    "ImbalancedChen.P2HistoricSieveTrapezoidError",\n    "ImbalancedChen.P2HistoricI80DivisionSoundness",\n    "ImbalancedChen.P2Winner9MixedKOneFiniteCollapse",\n    "ImbalancedChen.P2Winner9PhysicalVertexInterpolation",\n    "ImbalancedChen.P4AClosedTreeCoordinatePropagation",\n    "ImbalancedChen.ActualThirdOriginalSixTentCandidates",\n    "ImbalancedChen.ActualThirdOriginalPositive256LogIntegerGuards",\n    "ImbalancedChen.ActualThirdOriginalRoundedOldWeight",\n    "ImbalancedChen.ActualThirdOriginalBelowMuBRounded",\n    "ImbalancedChen.P4AActualSquaredGapDecay",\n    "ImbalancedChen.ActualThirdOriginalStoredQueryAllBranches",\n    "ImbalancedChen.P4AOriginalClosedTreeStructuralAggregation",\n    "ImbalancedChen.P5OriginalTaylorFiveDimensionalMidpoint",\n    "ImbalancedChen.P1ActualHistoricalThirdCellPartition",\n    "ImbalancedChen.P4AOriginalSixthClosedQuotients",\n    "ImbalancedChen.P2OriginalSixthSimplexMoments",\n    "ImbalancedChen.P1OriginalFourthQ80LogBounds"\n  ],\n  "original_target_source": {\n    "path": "/workspace/blue-member-build/ImbalancedChen/P5RecordedOldFifthBlockTotals.lean",\n    "sha256": "7a2548770d2e8f863ae30f9016b61845591b3f4882b60ec1b82bd43fdf1216fa",\n    "bytes": 23109\n  },\n  "historical_output_fingerprints": {},\n  "historical_inventory": {\n    "archive_path": "docs/p1/20261125/p14-continuation/evidence/diagnostic-read-01.tar.xz",\n    "archive_bytes": 62824,\n    "archive_sha256": "28e1d567078e272342b11e754201c70b190dfa1a66984b088dd20be572e92b52",\n    "member": "historical/whole-floor-readiness.json",\n    "member_bytes": 510883,\n    "member_sha256": "8d3e3e51d922bdd4309f845176cba167e3a2444aadb77aecf1f31825892aa2fc",\n    "recorded_utc": "2026-11-25T08:35:31.365089+00:00",\n    "target_row": {\n      "direct_project_imports": [],\n      "installed_source_sha256": "7a2548770d2e8f863ae30f9016b61845591b3f4882b60ec1b82bd43fdf1216fa",\n      "installed_source_symlink": false,\n      "matching_validation_receipts": [],\n      "object_exists": true,\n      "other_source_validation_receipts": [],\n      "scope": "new_inventory_scope",\n      "source_sha256": "7a2548770d2e8f863ae30f9016b61845591b3f4882b60ec1b82bd43fdf1216fa",\n      "trace_exists": true\n    }\n  },\n  "limits": {\n    "stdout_wire_bytes": 4194304,\n    "live_file_bytes": 33554432,\n    "live_snapshot_total_bytes_per_pass": 100663296,\n    "wall_seconds": 60\n  },\n  "whole_P1_4_complete": false,\n  "acceptance_claimed": false\n}\n'
PARAMETERS_SHA256 = '8c118a0091216219f5df3a316f94968212e166f1effa398ed97b32983771cb2f'
if hashlib.sha256(PARAMETERS_RAW).hexdigest() != PARAMETERS_SHA256:
    raise RuntimeError('reader parameter bytes differ')
P = json.loads(PARAMETERS_RAW)
M = P['module']
PROJECT = Path('/workspace/blue-member-build')
ANSI = re.compile(r'\x1b\[[0-?]*[ -/]*[@-~]')
BUILT = re.compile(r'^\s*[✔⚠ℹ]\ufe0f?\s+\[[^\]\r\n]+\]\s+Built\s+(ImbalancedChen(?:\.[A-Za-z0-9_]+)+)(?::olean)?(?=\s|$)', re.M)
FAILED = re.compile(r'^\s*✖\ufe0f?\s+\[[^\]\r\n]+\]\s+(?:Building|Built)\s+(ImbalancedChen(?:\.[A-Za-z0-9_]+)+)(?::olean)?(?=\s|$)', re.M)


def need(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def identity(s):
    return (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns)


def read_stable(path, maximum, expected_sha=None, expected_bytes=None, retain=False):
    path = Path(path)
    need(path.is_absolute() and all(not q.is_symlink() for q in (path, *path.parents)),
         'non-absolute or symlink path: ' + str(path))
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(descriptor, 'rb') as stream:
        before = os.fstat(stream.fileno())
        need(stat.S_ISREG(before.st_mode) and before.st_size <= maximum, 'file exceeds regular-file read bound: ' + str(path))
        need(expected_bytes is None or before.st_size == expected_bytes, 'original byte length differs: ' + str(path))
        digest, total, chunks = hashlib.sha256(), 0, []
        while chunk := stream.read(65536):
            total += len(chunk)
            need(total <= maximum, 'file grew beyond read bound: ' + str(path))
            digest.update(chunk)
            if retain:
                chunks.append(chunk)
        after = os.fstat(stream.fileno())
    final = path.lstat()
    need(total == before.st_size and identity(before) == identity(after) == identity(final) and
         all(not q.is_symlink() for q in (path, *path.parents)), 'file identity changed during read: ' + str(path))
    value = digest.hexdigest()
    need(expected_sha is None or value == expected_sha, 'exact original SHA-256 differs: ' + str(path))
    return {'path': str(path), 'bytes': total, 'sha256': value,
            'stable_file_identity': list(identity(before))}, b''.join(chunks) if retain else None


def live_snapshot():
    stem = M.replace('.', '/')
    paths = [stem + '.lean', '.lake/build/lib/lean/' + stem + '.olean',
             '.lake/build/lib/lean/' + stem + '.ilean', '.lake/build/ir/' + stem + '.c',
             '.lake/build/ir/' + stem + '.setup.json', '.lake/build/lib/lean/' + stem + '.trace']
    rows, used = {}, 0
    for relative in paths:
        try:
            bound = min(P['limits']['live_file_bytes'], P['limits']['live_snapshot_total_bytes_per_pass'] - used)
            row, _ = read_stable(PROJECT / relative, bound)
            used += row['bytes']
            old = P['historical_output_fingerprints'].get(relative)
            if relative == stem + '.lean':
                old = {key: P['original_target_source'][key] for key in ('bytes', 'sha256')}
            row.update(status='READ_ONLY_CURRENT_FINGERPRINT', old_fingerprint_available=old is not None,
                       matches_old_fingerprint=({key: row[key] for key in ('bytes', 'sha256')} == old) if old else None)
            rows[relative] = row
        except TimeoutError:
            raise
        except Exception as error:
            rows[relative] = {'path': str(PROJECT / relative), 'status': 'HELD', 'reason': str(error)}
    return rows


def main():
    signal.signal(signal.SIGALRM, lambda *_: (_ for _ in ()).throw(TimeoutError('fixed 60-second read limit reached')))
    signal.alarm(P['limits']['wall_seconds'])
    before = live_snapshot()
    spec = P['source_context']
    context_meta, context_raw = read_stable(spec['path'], spec['maximum_bytes'], spec['sha256'], spec['bytes'], True)
    context = json.loads(context_raw)
    need(context['effective_source_bindings'][M] == P['original_target_source'], 'original target source context differs')
    spec = P['normal_log']
    log_meta, log_raw = read_stable(spec['path'], spec['maximum_bytes'], spec['sha256'], retain=True)
    after = live_snapshot()
    text = ANSI.sub('', log_raw.decode('utf-8'))
    built = BUILT.findall(text)
    failed = FAILED.findall(text)
    selected_headers = [{'line': number, 'text': line} for number, line in enumerate(text.splitlines(), 1)
                        if (match := BUILT.match(line)) and match.group(1) == M]
    compressed = zlib.compress(log_raw, 9)
    log_meta.update(encoding='zlib+base64', compressed_bytes=len(compressed), compressed_sha256=sha(compressed),
                    zlib_base64=base64.b64encode(compressed).decode('ascii'))
    all_live = len(before) == 6 and all(row['status'] == 'READ_ONLY_CURRENT_FINGERPRINT' for row in before.values())
    result = {
        'schema': 'p14_recorded_original_normal_bounded_transport_v1',
        'status': 'READ_ONLY_ORIGINAL_LOG_CONTEXT_LIVE6_OBSERVATION_NOT_ACCEPTANCE',
        'parameters_sha256': PARAMETERS_SHA256,
        'module': M,
        'original_log': log_meta,
        'original_source_context': context_meta,
        'original_command_reference': P['original_command'],
        'original_target_source_binding': context['effective_source_bindings'][M],
        'original_source_context_config_pins': context['config_pins'],
        'all_actual_built_modules': built,
        'actual_built_set_matches_original_command': set(built) == set(P['original_expected_built_modules']),
        'actual_built_list_matches_original_command': built == P['original_expected_built_modules'],
        'selected_actual_success_headers': selected_headers,
        'target_in_actual_failed_headers': M in failed,
        'original_whole_batch_exit_code_preserved': P['original_command']['exit_code'],
        'live_six_before': before,
        'live_six_after': after,
        'all_six_files_present_and_stable_during_read': all_live and before == after,
        'historical_five_output_fingerprints_available': bool(P['historical_output_fingerprints']),
        'historical_output_snapshot_not_created_by_this_read': True,
        'current_source_matches_original': before[M.replace('.', '/') + '.lean'].get('matches_old_fingerprint'),
        'limits': P['limits'],
        'original_log_maximum_bytes': P['normal_log']['maximum_bytes'],
        'normal_kernel_full_owned_invocations': 0,
        'runtime_readiness_or_kernel_or_complete_owned_acceptance_claimed': False,
        'whole_P1_4_complete': False,
    }
    wire = (json.dumps(result, ensure_ascii=False, separators=(',', ':')) + '\n').encode('utf-8')
    need(len(wire) <= P['limits']['stdout_wire_bytes'], 'compressed JSON/base64 stdout exceeds fixed 4 MiB bound')
    signal.alarm(0)
    sys.stdout.buffer.write(wire)
    sys.stdout.buffer.flush()


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        signal.alarm(0)
        print(json.dumps({'schema': 'p14_recorded_original_normal_bounded_transport_v1',
                          'status': 'HELD_NO_ACCEPTANCE', 'reason': str(error),
                          'compiler_invocations': 0, 'whole_P1_4_complete': False}), flush=True)
        raise SystemExit(2)

P14_RECORDED_READ
