import ImbalancedChen.P5OriginalH3Cell00StrictOldPlanes
open ImbalancedChen.P5OriginalH3Cell00StrictOldPlanes
set_option autoImplicit false
example : strictCenter (2 : Fin 8) = (4241932747 / 40000000000 : ℝ) := by
  rfl
example : strictCenter (2 : Fin 8) = (4241932747 / 40000000000 : ℝ) := by
  norm_num [strictCenter, Matrix.cons_val_two, Matrix.cons_val_three, Matrix.cons_val_four]
example (t : Fin 8 → ℝ)
    (h : t 2 < strictCenter 2 + (1 / 100000000 : ℝ)) : t 2 < (107 / 1000 : ℝ) := by
  norm_num [strictCenter, Matrix.cons_val_two, Matrix.cons_val_three, Matrix.cons_val_four] at h
  linarith
