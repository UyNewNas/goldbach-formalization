import ImbalancedChen.P5OriginalH3Cell00StrictOldPlanes
import ImbalancedChen.P5OriginalPhaseBPhysicalBinding
import Mathlib.Tactic
namespace ImbalancedChen.P15H3ApiProbe4
noncomputable section
open scoped Classical BigOperators
open P5OriginalAdoptedEighthPhysicalMasks
example (t : Point) : H7 t = t 0 + t 1 + t 2 + t 3 + t 4 + t 5 + 3 * t 6 := by
  simp only [H7, Finset.sum_filter, Fin.sum_univ_succ, Fin.sum_univ_zero, Fin.succ, Fin.instOfNat, Fin.ofNat, Fin.Internal.ofNat, Fin.lt_def, Fin.val_mk, Fin.reduceFinMk]
  norm_num
  ring
example (t : Point) : prefixSquareExpr t (7 : Fin 8) =
    t 0 + t 1 + t 2 + t 3 + t 4 + t 5 + t 6 + 2 * t 7 := by
  simp only [prefixSquareExpr, Finset.sum_filter, Fin.sum_univ_succ, Fin.sum_univ_zero, Fin.succ, Fin.instOfNat, Fin.ofNat, Fin.Internal.ofNat, Fin.lt_def, Fin.val_mk, Fin.reduceFinMk]
  norm_num
  ring
example (t : Point) : (∑ j ∈ ({1, 3, 7} : Finset (Fin 8)), t j) = t 1 + t 3 + t 7 := by
  rw [Finset.sum_insert (by decide : (1 : Fin 8) ∉ ({3, 7} : Finset (Fin 8))),
    Finset.sum_insert (by decide : (3 : Fin 8) ∉ ({7} : Finset (Fin 8))),
    Finset.sum_singleton]
  ring
example (t : Point) : selectedSquareExpr mask138 t (4 : Fin 8) =
    (t 1 + t 3 + t 7) + (t 0 + t 2) + 2 * t 4 := by
  simp only [selectedSquareExpr, mask138, Finset.sum_filter, Fin.sum_univ_succ, Fin.sum_univ_zero, Fin.succ, Fin.instOfNat, Fin.ofNat, Fin.Internal.ofNat, Fin.lt_def, Fin.val_mk, Fin.reduceFinMk]
  norm_num [Finset.sum_insert, Finset.sum_singleton, Fin.ext_iff]
  ring
end
end ImbalancedChen.P15H3ApiProbe4
