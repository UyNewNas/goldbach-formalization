import ImbalancedChen.P5OriginalH3Cell00StrictOldPlanes
open ImbalancedChen.P5OriginalH3Cell00StrictOldPlanes
set_option autoImplicit false
example : strictCenter (2 : Fin 8) = (4241932747 / 40000000000 : ℝ) := by
  norm_num [strictCenter, Fin.isValue, Fin.reduceFinMk,
    Matrix.cons_val, Matrix.cons_val_zero, Matrix.cons_val_zero',
    Matrix.cons_val_succ, Matrix.cons_val_succ', Matrix.cons_val_fin_one,
    Fin.instOfNat, Fin.Internal.ofNat, Fin.ofNat, Fin.succ]
example (t : Fin 8 → ℝ) : t (⟨2, by decide⟩ : Fin 8) = t 2 := by
  exact congrArg t (Fin.ext rfl)
example (t : Fin 8 → ℝ)
    (h : t 2 < strictCenter 2 + (1 / 100000000 : ℝ)) : t 2 < (107 / 1000 : ℝ) := by
  norm_num [strictCenter, Fin.isValue, Fin.reduceFinMk,
    Matrix.cons_val, Matrix.cons_val_zero, Matrix.cons_val_zero',
    Matrix.cons_val_succ, Matrix.cons_val_succ', Matrix.cons_val_fin_one,
    Fin.instOfNat, Fin.Internal.ofNat, Fin.ofNat, Fin.succ] at h
  linarith
