import ImbalancedChen.P5OriginalH3Cell00StrictOldPlanes
import ImbalancedChen.P5OriginalPhaseBPhysicalBinding
import Mathlib.Tactic
namespace ImbalancedChen.P15H3ApiProbe6
noncomputable section
open scoped Classical BigOperators
open VariableEnvelope P5OriginalAdoptedEighthPhysicalMasks P5OriginalH3Cell00StrictOldPlanes
private theorem center_coord0 : strictCenter (0 : Fin 8) = (1061930909 / 7812500000 : ℝ) := rfl
private theorem center_coord1 : strictCenter (1 : Fin 8) = (111291629207 / 1000000000000 : ℝ) := rfl
private theorem center_coord2 : strictCenter (2 : Fin 8) = (4241932747 / 40000000000 : ℝ) := rfl
private theorem center_coord3 : strictCenter (3 : Fin 8) = (460093481 / 8000000000 : ℝ) := rfl
private theorem center_coord4 : strictCenter (4 : Fin 8) = (14190755429 / 500000000000 : ℝ) := rfl
private theorem center_coord5 : strictCenter (5 : Fin 8) = (3454105931 / 125000000000 : ℝ) := rfl
private theorem center_coord6 : strictCenter (6 : Fin 8) = (26884184039 / 1000000000000 : ℝ) := rfl
private theorem center_coord7 : strictCenter (7 : Fin 8) = (26134853963 / 1000000000000 : ℝ) := rfl
private theorem fin8_coord2 : (⟨2, by decide⟩ : Fin 8) = (2 : Fin 8) := Fin.ext rfl
private theorem fin8_coord3 : (⟨3, by decide⟩ : Fin 8) = (3 : Fin 8) := Fin.ext rfl
private theorem fin8_coord4 : (⟨4, by decide⟩ : Fin 8) = (4 : Fin 8) := Fin.ext rfl
private theorem fin8_coord5 : (⟨5, by decide⟩ : Fin 8) = (5 : Fin 8) := Fin.ext rfl
private theorem fin8_coord6 : (⟨6, by decide⟩ : Fin 8) = (6 : Fin 8) := Fin.ext rfl
private theorem fin8_coord7 : (⟨7, by decide⟩ : Fin 8) = (7 : Fin 8) := Fin.ext rfl

attribute [local simp] center_coord0 center_coord1 center_coord2 center_coord3 center_coord4 center_coord5 center_coord6 center_coord7 fin8_coord2 fin8_coord3 fin8_coord4 fin8_coord5 fin8_coord6 fin8_coord7

/-- Fixed rational side radius, chosen before any arithmetic parameter N. -/
def boxRadius : ℝ := 1 / 100000000

/-- An open eight-dimensional box around the published exact center. -/
def InBox (t : Point) : Prop :=
  ∀ j, strictCenter j - boxRadius < t j ∧
    t j < strictCenter j + boxRadius

private theorem box_coordinates {t : Point} (h : InBox t) :
    (strictCenter 0 - boxRadius < t 0 ∧ t 0 < strictCenter 0 + boxRadius) ∧
    (strictCenter 1 - boxRadius < t 1 ∧ t 1 < strictCenter 1 + boxRadius) ∧
    (strictCenter 2 - boxRadius < t 2 ∧ t 2 < strictCenter 2 + boxRadius) ∧
    (strictCenter 3 - boxRadius < t 3 ∧ t 3 < strictCenter 3 + boxRadius) ∧
    (strictCenter 4 - boxRadius < t 4 ∧ t 4 < strictCenter 4 + boxRadius) ∧
    (strictCenter 5 - boxRadius < t 5 ∧ t 5 < strictCenter 5 + boxRadius) ∧
    (strictCenter 6 - boxRadius < t 6 ∧ t 6 < strictCenter 6 + boxRadius) ∧
    (strictCenter 7 - boxRadius < t 7 ∧ t 7 < strictCenter 7 + boxRadius) :=
  ⟨h 0, h 1, h 2, h 3, h 4, h 5, h 6, h 7⟩

example {t : Point} (ht : InBox t) :
    newCap slot t < v (∑ j ∈ selectedMask slot, t j) := by
  rcases box_coordinates ht with ⟨h0, h1, h2, h3, h4, h5, h6, h7⟩
  norm_num [center_coord0, center_coord1, center_coord2, center_coord3, center_coord4, center_coord5, center_coord6, center_coord7, boxRadius] at h0 h1 h2 h3 h4 h5 h6 h7
  have hsum138 : (∑ j ∈ ({1, 3, 7} : Finset (Fin 8)), t j) =
      t 1 + t 3 + t 7 := by
    rw [Finset.sum_insert (by decide : (1 : Fin 8) ∉ ({3, 7} : Finset (Fin 8))),
      Finset.sum_insert (by decide : (3 : Fin 8) ∉ ({7} : Finset (Fin 8))),
      Finset.sum_singleton]
    ring
  change A (t 1 + t 3 + t 7) - eta < v (∑ j ∈ ({1, 3, 7} : Finset (Fin 8)), t j)
  rw [hsum138, v_eq_min]
  constructor <;> norm_num [A, C, eta] <;> linarith
example {t : Point} (ht : InBox t) :
    ∀ j ∉ selectedMask slot, selectedSquareExpr (selectedMask slot) t j < newCap slot t := by
  rcases box_coordinates ht with ⟨h0, h1, h2, h3, h4, h5, h6, h7⟩
  norm_num [center_coord0, center_coord1, center_coord2, center_coord3, center_coord4, center_coord5, center_coord6, center_coord7, boxRadius] at h0 h1 h2 h3 h4 h5 h6 h7
  have hsum138 : (∑ j ∈ ({1, 3, 7} : Finset (Fin 8)), t j) =
      t 1 + t 3 + t 7 := by
    rw [Finset.sum_insert (by decide : (1 : Fin 8) ∉ ({3, 7} : Finset (Fin 8))),
      Finset.sum_insert (by decide : (3 : Fin 8) ∉ ({7} : Finset (Fin 8))),
      Finset.sum_singleton]
    ring
  intro j hj
  change j ∉ ({1, 3, 7} : Finset (Fin 8)) at hj
  change selectedSquareExpr ({1, 3, 7} : Finset (Fin 8)) t j < A (t 1 + t 3 + t 7) - eta
  fin_cases j <;>
    norm_num [Fin.ext_iff] at hj <;>
    simp only [selectedSquareExpr, hsum138, Finset.sum_filter, Fin.sum_univ_succ, Fin.sum_univ_zero, Fin.succ, Fin.instOfNat, Fin.ofNat, Fin.Internal.ofNat, Fin.lt_def, Fin.val_mk, Fin.reduceFinMk] <;>
    norm_num [eta, A, Finset.sum_insert, Finset.sum_singleton, Fin.ext_iff] <;> linarith
end
end ImbalancedChen.P15H3ApiProbe6
