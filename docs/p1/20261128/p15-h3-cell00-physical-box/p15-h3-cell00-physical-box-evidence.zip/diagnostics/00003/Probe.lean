import ImbalancedChen.P5OriginalH3Cell00StrictOldPlanes
open ImbalancedChen.P5OriginalH3Cell00StrictOldPlanes
set_option autoImplicit false
example : strictCenter (2 : Fin 8) = (4241932747 / 40000000000 : ℝ) := by
  norm_num [strictCenter, Matrix.cons_val]
example : strictCenter (5 : Fin 8) = (3454105931 / 125000000000 : ℝ) := by
  norm_num [strictCenter, Matrix.cons_val]
example : strictCenter (7 : Fin 8) = (26134853963 / 1000000000000 : ℝ) := by
  norm_num [strictCenter, Matrix.cons_val]
