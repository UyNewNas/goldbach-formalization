#!/usr/bin/env python3
"""Read existing source/receipt bytes and prepare a normal-build reuse plan; never compile."""
from pathlib import Path
import hashlib
import json
import re
import subprocess

HERE = Path(__file__).resolve().parent
WORK = HERE.parents[1]
REPO = WORK / 'goldbach-p1'
RECEIPTS = WORK / 'p1-root-repairs/parallel-validation/downloaded-receipts'
HEADERS_PATH = WORK / 'context-recovery/COMPLETE_BUILD_HEADERS.json'
CLOUD_RECEIPTS = Path('/workspace/p1-complete-proof/20261124-resume')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)


def save(name, value):
    (HERE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


headers = json.loads(HEADERS_PATH.read_text())
head = git('rev-parse', 'HEAD').decode().strip()
assert not git('status', '--porcelain', '--', 'ImbalancedChen'), 'source tree is not clean'
accepted13_path = RECEIPTS / 'batch1-parallel-acceptance/TARGETS.json'
accepted13 = json.loads(accepted13_path.read_text())
assert len(set(accepted13)) == 13
source_commits = ['d726bbee66b53d2ae5bf8fc21cbb144d6d8ea3cb',
                  '103823711909b89ac9143f73352647e7a1061dc8',
                  '103823711909b89ac9143f73352647e7a1061dc8']
batch1_install = json.loads((RECEIPTS / 'batch1-normal/SOURCE_INSTALL.json').read_text())
batch1_expected = {r['module']: r['after_sha256'] for r in batch1_install['source_updates']}
imports_re = re.compile(r'^import\s+(ImbalancedChen(?:\.[A-Za-z0-9_]+)+)', re.M)
sources = {}


def source(m):
    if m not in sources:
        rel = m.replace('.', '/') + '.lean'
        raw = (REPO / rel).read_bytes()
        sources[m] = {'relative_path': rel, 'sha256': sha(raw),
                      'imports': imports_re.findall(raw.decode())}
    return sources[m]


def closure(ms):
    seen, stack = set(), list(ms)
    while stack:
        m = stack.pop()
        if m not in seen:
            seen.add(m)
            stack.extend(source(m)['imports'])
    return seen


normal_logs, modules, groups = {}, {}, []
for i, (log_rel, hdr) in enumerate(headers.items()):
    log_id = ['batch1', 'batch2_lane0', 'batch2_seed_lane1'][i]
    commit = source_commits[i]
    chosen = [m for m in hdr['built'] if i != 0 or m not in accepted13]
    groups.append(chosen)
    diff = git('diff', '--name-only', commit, head, '--', 'ImbalancedChen').decode().splitlines()
    changed = {p[:-5].replace('/', '.') for p in diff if p.endswith('.lean')}
    normal_logs[log_id] = {'path': str(CLOUD_RECEIPTS / log_rel),
                          'sha256': hdr['sha256'], 'source_commit': commit,
                          'expected_built_modules': hdr['built'],
                          'expected_failed_modules': hdr['failed'],
                          'complete_header_index_path': str(HEADERS_PATH),
                          'complete_header_index_sha256': sha(HEADERS_PATH.read_bytes())}
    local_log = RECEIPTS / log_rel
    if local_log.is_file():
        assert sha(local_log.read_bytes()) == hdr['sha256']
        normal_logs[log_id]['local_original_log'] = str(local_log)
    for m in chosen:
        s = source(m)
        normal_bytes = git('show', commit + ':' + s['relative_path'])
        assert sha(normal_bytes) == s['sha256'], ('normal_source_changed', m)
        dep = closure([m])
        assert not (dep & changed), ('normal_dependency_source_changed', m, dep & changed)
        if i == 0:
            assert batch1_expected[m] == s['sha256']
        modules[m] = {'source_sha256': s['sha256'], 'normal_log': log_id,
                      'normal_source_commit': commit,
                      'normal_source_git_blob_sha1': git('rev-parse', commit + ':' + s['relative_path']).decode().strip(),
                      'project_closure': sorted(dep),
                      'project_closure_count': len(dep),
                      'project_source_closure_unchanged_since_normal': True,
                      'historical_full_receipt_reused': False,
                      'audit_status': 'NORMAL_PASS_KERNEL_FULL_OWNED_PENDING'}
assert list(map(len, groups)) == [8, 16, 90]
assert len(modules) == 114 and not (set(modules) & set(accepted13))

installation = json.loads((WORK / 'terminal-reconcile/seed-terminal-wiring/INSTALL_PLAN.json').read_text())
changed_by_878 = set()
existing_at_pre_wire = set(git('ls-tree', '-r', '--name-only', '66008c903d291c6266b42c774cb79939cdda8b86', '--', 'ImbalancedChen').decode().splitlines())
for f in installation['files']:
    if f['target_path'] in existing_at_pre_wire:
        old = git('show', '66008c903d291c6266b42c774cb79939cdda8b86:' + f['target_path'])
        if sha(old) != f['sha256']:
            changed_by_878.add(f['module'])
assert changed_by_878 == {'ImbalancedChen.P4AOriginalFull87SeedRefinements',
                          'ImbalancedChen.P2Winner9T10TailJensen'}
group_closures = [closure(ms) for ms in groups]
assert not (set.union(*group_closures) & changed_by_878)
lane_modules = [groups[0] + groups[1], groups[2]]
lane_closures = [closure(ms) for ms in lane_modules]
assert lane_closures[0] & lane_closures[1] == {'ImbalancedChen.P2Winner9CompleteSeedTypes'}

template = RECEIPTS / 'accepted-batch102-two/PublicAudit.lean'
runner = REPO / 'docs/p1/20261124/parallel-resume/run_parallel_acceptance.py'
historical = json.loads((HERE / 'HISTORICAL_RECEIPT_CANDIDATES.json').read_text())
comparisons = json.loads((HERE / 'HISTORICAL_RECEIPT_SOURCE_COMPARISON.json').read_text())
assert all(not r['source_sha_matches'] for r in comparisons)
partial_path = Path('/workspace/scratch/4d172cd6182d/repo-count/docs/verification/20261123-winner9-geometry-member-scale/VERIFICATION_RESULTS.json')
partial = next(r for r in json.loads(partial_path.read_text())['modules']
               if r['module'] == 'ImbalancedChen.P2Winner9SelectedRowRealJacobian')
assert partial['source']['sha256'] == modules[partial['module']]['source_sha256']
partial_summary = {
    'module': partial['module'], 'path': str(partial_path),
    'receipt_sha256': sha(partial_path.read_bytes()),
    'source_sha256': partial['source']['sha256'],
    'kernel_replay': partial['kernel_replay'],
    'public_theorem_count': partial['theorem_audit']['theorem_count'],
    'full_environment_owned_scope': False,
    'old_current_dependency_or_six_artifact_identity_receipt': False,
    'complete_current_receipt_reusable': False,
    'reason': 'Same source has earlier named kernel and 23 public theorem checks; no full-owned receipt or complete current dependency/artifact binding is present. The newer P2 full-owned source is 16ee27bd, not current 73d7e839.'}

reuse = {'search_ref': historical['search_ref'],
         'searched_repository': str(REPO),
         'searched_directory': historical['searched_directory'],
         'validation_and_completion_receipts_read': historical['validation_and_completion_receipts_read'],
         'candidate24_complete_receipt_hits': [],
         'current114_complete_receipts_reused': [],
         'seed43_historical_complete_receipts_all_have_different_source_sha': True,
         'comparisons_file': 'HISTORICAL_RECEIPT_SOURCE_COMPARISON.json',
         'additional_p2_search_file': 'P2_HISTORICAL_RECEIPT_CANDIDATES.json',
         'partial_evidence': [partial_summary],
         'excluded_prior13': {'modules': accepted13,
                             'targets_path': str(accepted13_path),
                             'targets_sha256': sha(accepted13_path.read_bytes()),
                             'receipts': []},
         'metadata_only_263_not_used_as_proof_credit': True,
         'no_global_claim_of_exhaustive_all_scratch_receipt_search': True}
for q in sorted((RECEIPTS / 'batch1-parallel-acceptance').glob('lane-*/VALIDATION_RESULTS.json')):
    r = json.loads(q.read_text())
    assert r['status'] == 'PASS_NORMAL_KERNEL_ALL_ENVIRONMENT_OWNED_TYPES_AXIOMS'
    assert r['full_owned_including_private_generated']
    assert all(source(m)['sha256'] == s for m, s in r['modules'].items())
    reuse['excluded_prior13']['receipts'].append({'path': str(q), 'sha256': sha(q.read_bytes()),
                                                'modules': r['modules'],
                                                'status': r['status']})
save('RECEIPT_REUSE_INDEX.json', reuse)

plan = {'schema': 'p1_completed_normal_multibatch_audit_plan_v1',
        'status': 'PREPARED_NOT_EXECUTED', 'source_review_head': head,
        'project': '/workspace/blue-member-build',
        'receipt_root': str(CLOUD_RECEIPTS / 'batch1-batch2-normal-supplement-acceptance'),
        'runtime_states': ['/workspace/blue-build-tools/member-runtime-evidence/state.json',
                           '/workspace/blue-build-tools/runtime-evidence/state.json'],
        'audit_template': {'path': str(CLOUD_RECEIPTS / 'accepted-batch102-two/PublicAudit.lean'),
                           'sha256': sha(template.read_bytes())},
        'runner_template': {'path': str(runner), 'sha256': sha(runner.read_bytes())},
        'normal_logs': normal_logs, 'modules': modules,
        'groups': {'batch1_extra8': groups[0], 'batch2_extra16': groups[1], 'seed90': groups[2]},
        'lanes': [{'id': i, 'label': ['additional24', 'seed90'][i], 'modules': ms,
                   'project_closure_count': len(lane_closures[i])} for i, ms in enumerate(lane_modules)],
        'expected_project_sources': {m: source(m)['sha256'] for m in sorted(set.union(*lane_closures))},
        'dependency_review': {'mode': 'LOCAL_SOURCE_IMPORT_AND_GIT_BLOB_COMPARISON_ONLY',
                              'batch_project_closure_counts': [len(c) for c in group_closures],
                              'extra24_project_closure_count': len(lane_closures[0]),
                              'seed90_project_closure_count': len(lane_closures[1]),
                              'all114_project_closure_count': len(set.union(*lane_closures)),
                              'batch1_batch2_common_project_modules': sorted(group_closures[0] & group_closures[1]),
                              'lane_common_project_modules': sorted(lane_closures[0] & lane_closures[1]),
                              'changed_existing_modules_in_878_install': sorted(changed_by_878),
                              'targets_depending_on_changed_878_sources': [],
                              'normal_to_current_changed_project_sources_in_target_closures': [],
                              'target_dependency_edges': [{'from': m, 'to': d} for m in lane_modules[0]
                                                          for d in source(m)['imports'] if d in lane_modules[0]],
                              'runtime_readiness_not_claimed_by_static_check': True},
        'excluded_prior13': accepted13, 'reused_complete_modules': [],
        'receipt_deduplication_index': 'RECEIPT_REUSE_INDEX.json',
        'successful_normal_not_to_be_repeated': True,
        'whole_P1_complete': False, 'full_selected_11026_accepted': False}
save('AUDIT_PLAN.json', plan)
save('SOURCE_AND_NORMAL_INDEX.json', {'source_review_head': head, 'normal_logs': normal_logs,
                                    'modules': modules, 'excluded_prior13': accepted13,
                                    'no_new_audits_run': True})
print(json.dumps({'source_review_head': head, 'group_sizes': list(map(len, groups)),
                  'lane_sizes': list(map(len, lane_modules)), 'unique_closure_sources': len(plan['expected_project_sources']),
                  'original_normal_source_closures_unchanged': True,
                  'complete_historical_receipts_reused_in114': 0,
                  'excluded_previous_full_audits': 13,
                  'plan_sha256': sha((HERE / 'AUDIT_PLAN.json').read_bytes())}, ensure_ascii=False))
