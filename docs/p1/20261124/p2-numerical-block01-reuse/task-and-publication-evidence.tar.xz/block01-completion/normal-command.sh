python3 - <<'PY'
from pathlib import Path
import hashlib
checks={'verification/part2/run_winner9_private_checks.py':'df9949270753bb36cace92d70099de4a7c30dcea8f761ade36ecd03f50c5684d','verification/part2/run_winner9_private_audit.py':'b214fe826d40f96c9907cb9c42f0ac96dcc9bc48dc080a264c9c13de2b43cc08','verification/part2/winner9_private_audit_template.lean':'2975fe381dfc6de3b297a67bcc9db9dd064bcad37a0b45ee13bc1fcd957ee85b'}
for name,expected in checks.items():
 actual=hashlib.sha256(Path(name).read_bytes()).hexdigest()
 assert actual==expected, (name,actual,expected)
print('ORIGINAL_DRIVERS_BOUND',flush=True)
PY
python3 verification/part2/run_winner9_private_checks.py --workers 2 --threads 1 --memory-mb 6144 --time-budget-seconds 720 ImbalancedChen.P2Winner9NumericalCheck01
