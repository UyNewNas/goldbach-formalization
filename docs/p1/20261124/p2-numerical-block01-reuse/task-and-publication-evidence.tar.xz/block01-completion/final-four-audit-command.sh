set -euo pipefail
python3 - <<'PY'
from pathlib import Path
import hashlib,json,subprocess
digest=lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
checks={"verification/part2/run_winner9_private_checks.py":"df9949270753bb36cace92d70099de4a7c30dcea8f761ade36ecd03f50c5684d","verification/part2/run_winner9_private_audit.py":"b214fe826d40f96c9907cb9c42f0ac96dcc9bc48dc080a264c9c13de2b43cc08","verification/part2/winner9_private_audit_template.lean":"2975fe381dfc6de3b297a67bcc9db9dd064bcad37a0b45ee13bc1fcd957ee85b"}
for name,expected in checks.items():
 actual=digest(Path(name))
 assert actual==expected,(name,actual,expected)
records=json.loads(Path('.lake/p2-private/records.json').read_text())
sources={"ImbalancedChen.P2Winner9NumericalPage0029":"a778b74d2d74d23b27b7aaa145f619f8423dd0c45e48544985dbf7024adc43db","ImbalancedChen.P2Winner9NumericalPage0030":"db5f5f597f6f8bbb73a26e871f29a282dc0bb371996a6ac4fe384085e8704a75","ImbalancedChen.P2Winner9NumericalPage0031":"c4b56e190aeeade080cc79969ab05b86d57e9f168e628288f220827300d90791","ImbalancedChen.P2Winner9NumericalCheck01":"60ae4995bad2c181d1eb0504e3f67a9e54492fe5a833f6fec0b95c8fb66ff126"}
for module,expected in sources.items():
 source=Path(module.replace('.','/')+'.lean')
 obj=Path('.lake/p2-private/lib')/(module.replace('.','/')+'.olean')
 rec=records[module]
 actual_source=digest(source)
 actual_object=digest(obj)
 assert actual_source==expected==rec['source_sha256'],('SOURCE_MISMATCH',module)
 assert actual_object==rec['object_sha256'],('OBJECT_MISMATCH',module)
 assert rec.get('cache_schema')==2 and rec.get('exit_code')==0,('NORMAL_RECEIPT',module)
 prior=Path('.lake/p2-private/audit')/module/'latest.json'
 prior_rec=json.loads(prior.read_text()) if prior.exists() else {}
 print('PREFLIGHT_BOUND',json.dumps({'module':module,'source_sha256':actual_source,'object_sha256':actual_object,'closure_signature':rec.get('closure_signature'),'existing_audit_accepted':prior_rec.get('accepted'),'existing_audit_same_source_object':prior_rec.get('source_sha256')==actual_source and prior_rec.get('object_sha256')==actual_object}),flush=True)
lanes=[['ImbalancedChen.P2Winner9NumericalPage0029','ImbalancedChen.P2Winner9NumericalPage0031'],['ImbalancedChen.P2Winner9NumericalPage0030','ImbalancedChen.P2Winner9NumericalCheck01']]
processes=[]
for i,modules in enumerate(lanes):
 command=['python3','verification/part2/run_winner9_private_audit.py','--summary-name',f'p1-block01-final-audit-lane{i}.json',*modules]
 print('ORIGINAL_AUDIT_COMMAND',command,flush=True)
 processes.append(subprocess.Popen(command))
codes=[p.wait() for p in processes]
print('AUDIT_FOUR_EXIT_CODES',codes,flush=True)
raise SystemExit(int(any(codes)))
PY
