import ImbalancedChen.P2Winner9SeedArchiveChecks
import ImbalancedChen.P2Winner9CompleteSeedBlock00
import ImbalancedChen.P2Winner9CompleteSeedBlock01
import ImbalancedChen.P2Winner9SeedArchiveCheck00
import ImbalancedChen.P2Winner9CompleteSeedBlock02
import ImbalancedChen.P2Winner9SeedArchiveCheck01
import ImbalancedChen.P2Winner9SeedArchiveCheck02
import ImbalancedChen.P2Winner9CompleteSeedBlock03
import ImbalancedChen.P2Winner9CompleteSeedBlock04
import ImbalancedChen.P2Winner9SeedArchiveCheck03
import ImbalancedChen.P2Winner9CompleteSeedBlock05
import ImbalancedChen.P2Winner9SeedArchiveCheck04
import ImbalancedChen.P2Winner9CompleteSeedBlock06
import ImbalancedChen.P2Winner9SeedArchiveCheck05
import ImbalancedChen.P2Winner9CompleteSeedBlock07
import ImbalancedChen.P2Winner9SeedArchiveCheck06
import ImbalancedChen.P2Winner9CompleteSeedBlock08
import ImbalancedChen.P2Winner9SeedArchiveCheck07
import ImbalancedChen.P2Winner9SeedArchiveCheck08
import ImbalancedChen.P2Winner9CompleteSeedBlock09
import ImbalancedChen.P2Winner9CompleteSeedBlock10
import ImbalancedChen.P2Winner9SeedArchiveCheck09
import ImbalancedChen.P2Winner9CompleteSeedBlock11
import ImbalancedChen.P2Winner9SeedArchiveCheck10
import ImbalancedChen.P2Winner9SeedArchiveCheck11
import ImbalancedChen.P2Winner9CompleteSeedBlock12
import ImbalancedChen.P2Winner9CompleteSeedBlock13
import ImbalancedChen.P2Winner9SeedArchiveCheck12
import ImbalancedChen.P2Winner9CompleteSeedBlock14
import ImbalancedChen.P2Winner9SeedArchiveCheck13
import ImbalancedChen.P2Winner9SeedArchiveCheck14
import ImbalancedChen.P2Winner9CompleteSeedBlock15
import ImbalancedChen.P2Winner9CompleteSeedBlock16
import ImbalancedChen.P2Winner9SeedArchiveCheck15
import ImbalancedChen.P2Winner9CompleteSeedBlock17
import ImbalancedChen.P2Winner9SeedArchiveCheck16
import ImbalancedChen.P2Winner9CompleteSeedBlock18
import ImbalancedChen.P2Winner9SeedArchiveCheck17
import ImbalancedChen.P2Winner9SeedArchiveCheck18
import ImbalancedChen.P2Winner9CompleteSeedBlock19
import ImbalancedChen.P2Winner9CompleteSeedBlock20
import ImbalancedChen.P2Winner9SeedArchiveCheck19
import ImbalancedChen.P2Winner9CompleteSeedBlock21
import ImbalancedChen.P2Winner9SeedArchiveCheck20
import ImbalancedChen.P2Winner9CompleteSeedBlock22
import ImbalancedChen.P2Winner9SeedArchiveCheck21
import ImbalancedChen.P2Winner9SeedArchiveCheck22
import ImbalancedChen.P2Winner9CompleteSeedBlock23
import ImbalancedChen.P2Winner9CompleteSeedBlock24
import ImbalancedChen.P2Winner9SeedArchiveCheck23
import ImbalancedChen.P2Winner9CompleteSeedBlock25
import ImbalancedChen.P2Winner9SeedArchiveCheck24
import ImbalancedChen.P2Winner9CompleteSeedBlock26
import ImbalancedChen.P2Winner9SeedArchiveCheck25
import ImbalancedChen.P2Winner9SeedArchiveCheck26
import ImbalancedChen.P2Winner9CompleteSeedBlock27
import ImbalancedChen.P2Winner9CompleteSeedBlock28
import ImbalancedChen.P2Winner9SeedArchiveCheck27
import ImbalancedChen.P2Winner9CompleteSeedBlock29
import ImbalancedChen.P2Winner9SeedArchiveCheck28
import ImbalancedChen.P2Winner9SeedArchiveCheck29
import ImbalancedChen.P2Winner9CompleteSeedBlock30
import ImbalancedChen.P2Winner9CompleteSeedBlock31
import ImbalancedChen.P2Winner9SeedArchiveCheck30
import ImbalancedChen.P2Winner9CompleteSeedBlock32
import ImbalancedChen.P2Winner9SeedArchiveCheck31
import ImbalancedChen.P2Winner9SeedArchiveCheck32
import ImbalancedChen.P2Winner9CompleteSeedBlock33
import ImbalancedChen.P2Winner9CompleteSeedBlock34
import ImbalancedChen.P2Winner9SeedArchiveCheck33
import ImbalancedChen.P2Winner9CompleteSeedBlock35
import ImbalancedChen.P2Winner9SeedArchiveCheck34
import ImbalancedChen.P2Winner9CompleteSeedBlock36
import ImbalancedChen.P2Winner9SeedArchiveCheck35
import ImbalancedChen.P2Winner9SeedArchiveCheck36
import ImbalancedChen.P2Winner9CompleteSeedBlock37
import ImbalancedChen.P2Winner9CompleteSeedBlock38
import ImbalancedChen.P2Winner9SeedArchiveCheck37
import ImbalancedChen.P2Winner9CompleteSeedBlock39
import ImbalancedChen.P2Winner9SeedArchiveCheck38
import ImbalancedChen.P2Winner9SeedArchiveCheck39
import ImbalancedChen.P2Winner9CompleteSeedBlock40
import ImbalancedChen.P2Winner9CompleteSeedBlock41
import ImbalancedChen.P2Winner9SeedArchiveCheck40
import ImbalancedChen.P2Winner9CompleteSeedBlock42
import ImbalancedChen.P2Winner9SeedArchiveCheck41
import ImbalancedChen.P2Winner9CompleteSeedBlock43
import ImbalancedChen.P2Winner9SeedArchiveCheck42
import ImbalancedChen.P2Winner9SeedArchiveCheck43
import ImbalancedChen.P2Winner9CompleteSeedData
import Lean.Util.CollectAxioms

set_option pp.all true
set_option pp.maxSteps 1000000
set_option pp.universes true

open Lean Elab Command in
run_cmd do
  let env ← getEnv
  let modules := #[`ImbalancedChen.P2Winner9SeedArchiveChecks, `ImbalancedChen.P2Winner9CompleteSeedBlock00, `ImbalancedChen.P2Winner9CompleteSeedBlock01, `ImbalancedChen.P2Winner9SeedArchiveCheck00, `ImbalancedChen.P2Winner9CompleteSeedBlock02, `ImbalancedChen.P2Winner9SeedArchiveCheck01, `ImbalancedChen.P2Winner9SeedArchiveCheck02, `ImbalancedChen.P2Winner9CompleteSeedBlock03, `ImbalancedChen.P2Winner9CompleteSeedBlock04, `ImbalancedChen.P2Winner9SeedArchiveCheck03, `ImbalancedChen.P2Winner9CompleteSeedBlock05, `ImbalancedChen.P2Winner9SeedArchiveCheck04, `ImbalancedChen.P2Winner9CompleteSeedBlock06, `ImbalancedChen.P2Winner9SeedArchiveCheck05, `ImbalancedChen.P2Winner9CompleteSeedBlock07, `ImbalancedChen.P2Winner9SeedArchiveCheck06, `ImbalancedChen.P2Winner9CompleteSeedBlock08, `ImbalancedChen.P2Winner9SeedArchiveCheck07, `ImbalancedChen.P2Winner9SeedArchiveCheck08, `ImbalancedChen.P2Winner9CompleteSeedBlock09, `ImbalancedChen.P2Winner9CompleteSeedBlock10, `ImbalancedChen.P2Winner9SeedArchiveCheck09, `ImbalancedChen.P2Winner9CompleteSeedBlock11, `ImbalancedChen.P2Winner9SeedArchiveCheck10, `ImbalancedChen.P2Winner9SeedArchiveCheck11, `ImbalancedChen.P2Winner9CompleteSeedBlock12, `ImbalancedChen.P2Winner9CompleteSeedBlock13, `ImbalancedChen.P2Winner9SeedArchiveCheck12, `ImbalancedChen.P2Winner9CompleteSeedBlock14, `ImbalancedChen.P2Winner9SeedArchiveCheck13, `ImbalancedChen.P2Winner9SeedArchiveCheck14, `ImbalancedChen.P2Winner9CompleteSeedBlock15, `ImbalancedChen.P2Winner9CompleteSeedBlock16, `ImbalancedChen.P2Winner9SeedArchiveCheck15, `ImbalancedChen.P2Winner9CompleteSeedBlock17, `ImbalancedChen.P2Winner9SeedArchiveCheck16, `ImbalancedChen.P2Winner9CompleteSeedBlock18, `ImbalancedChen.P2Winner9SeedArchiveCheck17, `ImbalancedChen.P2Winner9SeedArchiveCheck18, `ImbalancedChen.P2Winner9CompleteSeedBlock19, `ImbalancedChen.P2Winner9CompleteSeedBlock20, `ImbalancedChen.P2Winner9SeedArchiveCheck19, `ImbalancedChen.P2Winner9CompleteSeedBlock21, `ImbalancedChen.P2Winner9SeedArchiveCheck20, `ImbalancedChen.P2Winner9CompleteSeedBlock22, `ImbalancedChen.P2Winner9SeedArchiveCheck21, `ImbalancedChen.P2Winner9SeedArchiveCheck22, `ImbalancedChen.P2Winner9CompleteSeedBlock23, `ImbalancedChen.P2Winner9CompleteSeedBlock24, `ImbalancedChen.P2Winner9SeedArchiveCheck23, `ImbalancedChen.P2Winner9CompleteSeedBlock25, `ImbalancedChen.P2Winner9SeedArchiveCheck24, `ImbalancedChen.P2Winner9CompleteSeedBlock26, `ImbalancedChen.P2Winner9SeedArchiveCheck25, `ImbalancedChen.P2Winner9SeedArchiveCheck26, `ImbalancedChen.P2Winner9CompleteSeedBlock27, `ImbalancedChen.P2Winner9CompleteSeedBlock28, `ImbalancedChen.P2Winner9SeedArchiveCheck27, `ImbalancedChen.P2Winner9CompleteSeedBlock29, `ImbalancedChen.P2Winner9SeedArchiveCheck28, `ImbalancedChen.P2Winner9SeedArchiveCheck29, `ImbalancedChen.P2Winner9CompleteSeedBlock30, `ImbalancedChen.P2Winner9CompleteSeedBlock31, `ImbalancedChen.P2Winner9SeedArchiveCheck30, `ImbalancedChen.P2Winner9CompleteSeedBlock32, `ImbalancedChen.P2Winner9SeedArchiveCheck31, `ImbalancedChen.P2Winner9SeedArchiveCheck32, `ImbalancedChen.P2Winner9CompleteSeedBlock33, `ImbalancedChen.P2Winner9CompleteSeedBlock34, `ImbalancedChen.P2Winner9SeedArchiveCheck33, `ImbalancedChen.P2Winner9CompleteSeedBlock35, `ImbalancedChen.P2Winner9SeedArchiveCheck34, `ImbalancedChen.P2Winner9CompleteSeedBlock36, `ImbalancedChen.P2Winner9SeedArchiveCheck35, `ImbalancedChen.P2Winner9SeedArchiveCheck36, `ImbalancedChen.P2Winner9CompleteSeedBlock37, `ImbalancedChen.P2Winner9CompleteSeedBlock38, `ImbalancedChen.P2Winner9SeedArchiveCheck37, `ImbalancedChen.P2Winner9CompleteSeedBlock39, `ImbalancedChen.P2Winner9SeedArchiveCheck38, `ImbalancedChen.P2Winner9SeedArchiveCheck39, `ImbalancedChen.P2Winner9CompleteSeedBlock40, `ImbalancedChen.P2Winner9CompleteSeedBlock41, `ImbalancedChen.P2Winner9SeedArchiveCheck40, `ImbalancedChen.P2Winner9CompleteSeedBlock42, `ImbalancedChen.P2Winner9SeedArchiveCheck41, `ImbalancedChen.P2Winner9CompleteSeedBlock43, `ImbalancedChen.P2Winner9SeedArchiveCheck42, `ImbalancedChen.P2Winner9SeedArchiveCheck43, `ImbalancedChen.P2Winner9CompleteSeedData]
  let allowed := #[`propext, `Classical.choice, `Quot.sound]
  -- Cache this computed modules.map exactly once, outside the full constant fold.
  let moduleNames := env.header.moduleNames
  let selected := env.constants.fold (init := #[]) fun names name _ =>
    match env.getModuleIdxFor? name with
    | some idx => if modules.contains moduleNames[idx.toNat]! then names.push name else names
    | none => names
  let names := selected.qsort Name.lt
  let inventory := Json.mkObj [("names", toJson (names.map Name.toString))]
  liftIO <| IO.println s!"MEMBER_OWNED_NAMES {inventory.compress}"
  let mut counts : Array (Name × Nat) := modules.map (·, 0)
  for name in names do
    let some info := env.find? name | throwError "Missing inventoried declaration {name}"
    let some owner := env.getModuleIdxFor? name | throwError "Missing declaration owner {name}"
    let moduleName := moduleNames[owner.toNat]!
    unless modules.contains moduleName do
      throwError "Inventoried declaration owner changed: {name}"
    if info.isUnsafe then
      throwError "Unsafe declaration in the audited roots: {name}"
    if info.isAxiom then
      throwError "Unproved axiom declaration in the audited roots: {name}"
    let axioms ← collectAxioms name
    for ax in axioms do
      unless allowed.contains ax do
        throwError "Forbidden transitive axiom {ax} in {name}"
    let type ← liftTermElabM do
      return (← Meta.ppExpr info.type).pretty
    let kind := match info with
      | .thmInfo _ => "theorem"
      | .defnInfo _ => "definition"
      | .opaqueInfo _ => "opaque"
      | .quotInfo _ => "quotient"
      | .axiomInfo _ => "axiom"
      | .inductInfo _ => "inductive"
      | .ctorInfo _ => "constructor"
      | .recInfo _ => "recursor"
    let record := Json.mkObj [
      ("name", toJson name.toString),
      ("module", toJson moduleName.toString),
      ("kind", toJson kind),
      ("is_private", toJson (isPrivateName name)),
      ("type", toJson type),
      ("type_expression", toJson (reprStr info.type)),
      ("universe_parameters", toJson (info.levelParams.map Name.toString)),
      ("axioms", toJson (axioms.map Name.toString))]
    liftIO <| IO.println s!"AUDIT_RECORD {record.compress}"
    counts := counts.map fun (m, count) => (m, if m == moduleName then count + 1 else count)
  for (m, count) in counts do
    unless count > 0 do
      throwError "Audited root module has no owned declarations: {m}"
    let record := Json.mkObj [("module", toJson m.toString), ("count", toJson count)]
    liftIO <| IO.println s!"MEMBER_OWNED_MODULE {record.compress}"
  liftIO <| IO.println s!"MEMBER_OWNED_COUNT {names.size}"
