# Batch9 result-driven normal audit adapter

**Prepared locally; not run against Batch9 evidence; no audit plan is frozen.**

`prepare_batch9_normal_audit.py` adapts the exact existing aligned Batch8 generator. The sibling `reused_batch8_aligned_generator.py` is its unchanged SHA256 `0d595b2f5c2996adab4b16c930c2a5f474836fa90114ac4d57a59449d70ac4e7` source. The adapter reuses its Git object reader, archive-member verifier, complete Built-header parser, command-source helpers, and original e9 plan schema. It does not create or execute an audit runner.

## Frozen execution inputs; results remain unknown

- Batch9 execution commit: `e44e941df0a4cdf126fc0a0c41df3abd7637d1e8`.
- Outer driver: `b081fa91051135af6714874a8eafbac52a720e340a131a429d099d87f90f220e`.
- Higher worker: `a53537587d0455282c4de641da8f57ff85004e82e730f1001ff5d3774f9d3e59`.
- Higher plan: `03b488f5b2df0d5112107a6e44003ad0e8ce0ee095bae5f0264d9596f80612cf`.
- Existing audit runner: `e9dadb4ee5cd0a9ad50e298a77c6133fe5e0d012f8b194ae02bd5118460fc9e1`, unchanged.

The 29 ordinary candidates are read from the original published execution plan. No success set is predicted. After an actual group directdeps exit 3, the adapter verifies every original per-target no-build command and derives the exact eligible list used by the subsequent normal command. It then checks the original `BUILD_SCOPE` and the complete `✔`, `⚠`, or `ℹ Built` set. `Replayed` does not select a target. A mixed normal exit 1 can supply its actual Built modules; an overall lane failure does not erase them.

## Higher's separate context

Higher is selected only when its exact original `NORMAL_RESULT.json` says `PASS_NORMAL_ONLY_PENDING_KERNEL_AND_FULL_OWNED`. The adapter requires its original normal command to exit 0 with exactly one new Built header, all six target source/output fingerprints, unchanged dependencies and roots, the original successful readiness command, the completed serialized worker, and the final coordinator result.

The main `PROJECT_SOURCE_CONTEXT.json` remains the original pre-install `3bc124…` snapshot. A separately verified source binding is derived from Higher's published `a9a4e5…` candidate, original `SOURCE_INSTALL.json`, exact `3bc124…` backup, before/after target snapshots, `NORMAL_RESULT`, and eight unchanged dependency sources. It never edits the original main context or substitutes a hash without this evidence.

The exact Higher worker records `DEPENDENCIES_BEFORE.json`, compares all dependency source/output snapshots again after normal, and writes the successful equality result into `NORMAL_RESULT.json`. It does **not** emit a separate `DEPENDENCIES_AFTER.json`. The adapter explicitly records that limitation and binds the before snapshots to the post-normal equality assertions of the exact original worker. It does not manufacture an after snapshot. Missing ancillary dependency outputs remain truthfully absent; the target's six fingerprints must all be present, and dependency `.olean` fingerprints and original no-build readiness are required.

Every selected source and ancestor must match both its actual normal context and the proposed **published review commit's canonical source bytes**. Consequently, if Higher passes at `a9a4e5…` while that review commit still has canonical `3bc124…`, preparation rejects with a source diagnostic. Publish the already-proved exact source alignment first; this adapter does not install it or relax the source gate.

## Original export needed

Supply the complete extracted Batch9 archive and the independently bound original archive-index SHA. The export must include the main configuration/result/source context, executed script and staged inputs, both outer worker commands/logs/serializer records, lane1 `LANE_RESULT`, all actual group and per-target directdeps commands/started records/logs, normal logs and `BUILD_SCOPE` records, and the ordinary source backups.

For Higher, include its complete `higher/` subtree: staged published candidate/preimage/plan/worker, source backup, independent `SOURCE_INSTALL`, original commands/logs, `NORMAL_RESULT`, `SOURCE_FIVE_BEFORE/AFTER`, dependency/root before snapshots, `PROBE_GATE`, recheck, and the original copied `reused-batch8-evidence/` members. This is evidence reuse; no probe is rerun. Include audit11's actual e9 `VALIDATION_RESULTS.json` under the same original archive index, or supply its explicit indexed local path. Audit11 is added to complete reuse exclusions only after its exact PASS receipt is verified; it is never scheduled again by this adapter.

## Run only after the actual complete export arrives

```bash
python3 /workspace/scratch/638a86a3af73/terminal-reconcile/batch9-normal-audit-preparation/prepare_batch9_normal_audit.py \
  --repo /workspace/scratch/638a86a3af73/goldbach-p1 \
  --evidence-root ACTUAL_EXTRACTED_BATCH9_DIRECTORY \
  --archive-root ACTUAL_ARCHIVE_ROOT \
  --archive-index ACTUAL_ORIGINAL_ARCHIVE_FILES_JSON \
  --archive-index-sha256 INDEPENDENT_ORIGINAL_INDEX_SHA256 \
  --review-commit PUBLISHED_EXACT_CURRENT_SOURCE_COMMIT \
  --out /workspace/scratch/638a86a3af73/terminal-reconcile/batch9-normal-audit-preparation/frozen
```

Repeat `--concurrent-module ImbalancedChen.ModuleName` for the next task's write targets. Any intersection with a selected audit closure is rejected. `--prior-audit-receipt` can identify the original indexed audit11 receipt explicitly. `--check-only` performs the same evidence and source checks without writing a package.

Exit 0 means a plan was prepared from actual new Built evidence, exit 2 means there are no new Built targets, and exit 3 means incomplete or mismatched evidence. A source mismatch writes a separate `frozen-SOURCE_MISMATCH.json` diagnostic and never creates a plan. Existing outputs are not overwritten.

Successful preparation writes `AUDIT_PLAN.json`, `PROVENANCE.json`, `SELECTION.json`, `SOURCE_GRAPH.json`, `HIGHER_NORMAL_BINDING.json`, the exact reused evidence bundle, and a manifest. The original e9 invocation remains `--prepare-only` followed by explicit `--lane 1` inside the existing serializer. All normal passes still await the original named-kernel and full-owned audit; this generator grants no acceptance.
