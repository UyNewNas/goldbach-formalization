#!/usr/bin/env python3
"""Bind completed Batch9 normal evidence to an unchanged e9 audit plan.

This is a local evidence adapter. Its only subprocesses are the reused
read-only Git object readers. It never invokes an audit runner, compiler,
guard, cloud API, source installer, or checkout.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re
import sys
import tarfile

sys.dont_write_bytecode = True
COMMON_SHA = "0d595b2f5c2996adab4b16c930c2a5f474836fa90114ac4d57a59449d70ac4e7"
COMMON_PATH = Path(__file__).with_name("reused_batch8_aligned_generator.py")
common_bytes = COMMON_PATH.read_bytes()
if hashlib.sha256(common_bytes).hexdigest() != COMMON_SHA:
    raise RuntimeError("Existing aligned generator bytes changed")
common_namespace = {"__name__": "batch9_existing_aligned_library", "__file__": str(COMMON_PATH)}
exec(compile(common_bytes, str(COMMON_PATH), "exec"), common_namespace)
for _name in ("EvidenceError", "require", "sha", "digest_file", "file_info", "json_bytes",
              "GitTree", "ArchiveEvidence", "load_read_only_helpers", "checked_headers"):
    globals()[_name] = common_namespace[_name]

NORMAL_COMMIT = "e44e941df0a4cdf126fc0a0c41df3abd7637d1e8"
PREFIX = "docs/p1/20261124/"
EXECUTION_PLAN_PATH = PREFIX + "batch9-parallel/EXECUTION_PLAN.json"
DRIVER_PATH = PREFIX + "batch9-parallel/run_batch9_parallel.py"
DRIVER_SHA = "b081fa91051135af6714874a8eafbac52a720e340a131a429d099d87f90f220e"
HELPER_PATH = common_namespace["HELPER_PATH"]
HELPER_SHA = common_namespace["HELPER_SHA"]
OPS_PATH = common_namespace["OPS_PATH"]
OPS_SHA = common_namespace["OPS_SHA"]
RUNNER_PATH = common_namespace["RUNNER_PATH"]
RUNNER_SHA = common_namespace["RUNNER_SHA"]
COMPLETE_STATUS = common_namespace["COMPLETE_STATUS"]
PROJECT = "/workspace/blue-member-build"
CLOUD_ROOT = Path("/workspace/p1-complete-proof/20261124-resume/batch9-higher-full-and-frontier")
HIGHER = "ImbalancedChen.P2OriginalSixthHigherMoments"
HIGHER_BEFORE = "3bc124a836f6637bdb8fd8448a3c76d1ed313756022329221ffa1268838b010d"
HIGHER_AFTER = "a9a4e532991af5ba3b397b7381fd4a1fdf3302ee25ef27a16ebba04e68a68334"
HIGHER_DRIVER_PATH = PREFIX + "higher-full-after-batch8/run_higher_full_after_batch8.py"
HIGHER_DRIVER_SHA = "a53537587d0455282c4de641da8f57ff85004e82e730f1001ff5d3774f9d3e59"
HIGHER_PLAN_PATH = PREFIX + "higher-full-after-batch8/EXECUTION_PLAN.json"
HIGHER_PLAN_SHA = "03b488f5b2df0d5112107a6e44003ad0e8ce0ee095bae5f0264d9596f80612cf"
HIGHER_PASS = "PASS_NORMAL_ONLY_PENDING_KERNEL_AND_FULL_OWNED"
DEFAULT_RECEIPT_ROOT = (
    "/workspace/p1-complete-proof/20261124-resume/"
    "batch9-completed-normal-supplement-acceptance"
)


def source_row(raw, helper):
    return {"sha256": sha(raw), "bytes": len(raw),
            "imports": [m for m in helper.imports(raw) if m.startswith("ImbalancedChen.")]}


def artifact_paths(module):
    # Same six-path layout as the pinned Higher worker and the unchanged e9 snap().
    stem = module.replace(".", "/")
    return [stem + ".lean", ".lake/build/lib/lean/" + stem + ".olean",
            ".lake/build/lib/lean/" + stem + ".ilean", ".lake/build/ir/" + stem + ".c",
            ".lake/build/ir/" + stem + ".setup.json", ".lake/build/lib/lean/" + stem + ".trace"]


def check_snapshot(module, snapshot, source_sha, source_bytes=None, complete=False):
    require(set(snapshot) == set(artifact_paths(module)), "six_path_snapshot_scope", module)
    for path, item in snapshot.items():
        require(item is not None or not complete, "missing_required_normal_artifact", path)
        if item is not None:
            require(set(item) == {"bytes", "sha256"} and type(item["bytes"]) is int and
                    item["bytes"] > 0 and re.fullmatch(r"[0-9a-f]{64}", item["sha256"]),
                    "invalid_artifact_fingerprint", path)
    source = snapshot[artifact_paths(module)[0]]
    require(source is not None and source["sha256"] == source_sha and
            (source_bytes is None or source["bytes"] == source_bytes),
            "snapshot_source_binding", module)


def original_command(evidence, local_dir, cloud_dir, name, expected_argv, stages=None):
    cmd = evidence.jread(local_dir / (name + "-command.json"))
    started = evidence.jread(local_dir / (name + "-started.json"))
    raw = evidence.read(local_dir / (name + ".log"))
    require(cmd["argv"] == expected_argv and cmd["cwd"] == PROJECT and
            cmd["log"] == str(cloud_dir / (name + ".log")),
            "original_command_contract", name)
    require(started == {k: cmd[k] for k in ("argv", "cwd", "started_utc")} and
            cmd.get("finished_utc") and cmd["finished_utc"] >= cmd["started_utc"] and
            type(cmd.get("exit_code")) is int and cmd["elapsed_seconds"] >= 0,
            "original_command_unfinished_or_time_binding", name)
    require(cmd["log_sha256"] == sha(raw) and cmd["log_bytes"] == len(raw),
            "original_command_raw_log_binding", name)
    if stages is not None:
        require(cmd["log"] in stages and all(stages[cmd["log"]].get(k) == v for k, v in cmd.items()),
                "lane_result_does_not_bind_original_command", name)
    return cmd, raw


def verify_git_read(reads, destination, commit, path, raw):
    matching = [row for row in reads if row.get("path") == str(destination)]
    require(len(matching) == 1, "git_read_destination_not_unique", str(destination))
    row = matching[0]
    require(row["argv"] == ["git", "show", commit + ":" + path] and row["exit_code"] == 0 and
            row["sha256"] == sha(raw) and row["bytes"] == len(raw),
            "git_read_not_bound_to_published_bytes", str(destination))


def completed_workers(evidence, root, config, result, helper):
    require(len(result["lane_commands"]) == 2, "both_original_lanes_not_finished")
    for lane in (0, 1):
        local_dir = root / "execution" / ("lane-" + str(lane))
        cloud_dir = CLOUD_ROOT / "execution" / ("lane-" + str(lane))
        argv = config["higher_config"]["worker_argv"] if lane == 0 else [
            "python3", str(CLOUD_ROOT / "executed-driver.py"), "--commit", NORMAL_COMMIT, "--normal-worker"]
        cmd, _ = original_command(evidence, local_dir, cloud_dir, "worker",
            helper.serialize(lane, cloud_dir / "VALIDATION_LANE.json", argv))
        lock = evidence.jread(local_dir / "VALIDATION_LANE.json")
        require(cmd == result["lane_commands"][lane] and lock["status"] == "VALIDATION_LANE_FINISHED" and
                lock["exit_code"] == cmd["exit_code"] and lock["argv"] == argv and
                lock["state"] == str(helper.STATES[lane]) and
                lock["no_compiler_guard_runtime_or_memory_limit_changes"] is True and
                lock["whole_chain_including_original_checker_serialized"] is True,
                "original_finished_serialized_worker_binding", lane)


def normal_group_evidence(evidence, root, execution, config, helper, ops):
    """Use the actual exit-3 branch, exact eligible list, and complete Built set."""
    lane_dir, cloud_dir = root / "execution/lane-1", CLOUD_ROOT / "execution/lane-1"
    lane = evidence.jread(lane_dir / "LANE_RESULT.json")
    require(lane["audit_failure_does_not_suppress_independent_normal"] is True and
            lane["skipped_source_mismatch_modules"] == config["source_mismatch_modules"],
            "normal_lane_result_contract")
    stages = {r["log"]: r for r in lane["stages"] if r.get("log")}
    require(len(stages) == sum(bool(r.get("log")) for r in lane["stages"]),
            "duplicate_lane_stage_logs")
    groups, logs, records, selection, selected = {}, {}, {}, [], []
    used_stages = set()

    def command(name, argv):
        answer = original_command(evidence, lane_dir, cloud_dir, name, argv, stages)
        used_stages.add(answer[0]["log"])
        return answer

    def no_normal(name):
        for suffix in ("-command.json", ".log", "-BUILD_SCOPE.json"):
            require(not (lane_dir / (name + suffix)).exists(),
                    "normal_evidence_present_for_ineligible_group", name)

    for group in execution["normal_groups"]:
        name, targets = group["name"], group["targets"]
        require(1 <= len(targets) <= 6, "normal_group_size_outside_original_limit", name)
        deps = sorted({d for m in targets for d in config["graph"][m]})
        require(deps, "empty_group_direct_dependency_gate", name)
        ready, _ = command(name + "-directdeps", helper.guard(1,
            ["lake", "--no-build", "build"] + ["+" + d + ":olean" for d in deps]))
        eligible, individual = list(targets), []
        if ready["exit_code"] == 3:
            eligible = []
            for m in targets:
                ds = sorted(set(config["graph"][m]))
                require(ds, "empty_individual_direct_dependency_gate", m)
                check, _ = command(name + "-directdeps-" + m.rsplit(".", 1)[-1], helper.guard(1,
                    ["lake", "--no-build", "build"] + ["+" + d + ":olean" for d in ds]))
                individual.append({"module": m, "command": check})
                if check["exit_code"] == 0:
                    eligible.append(m)
        elif ready["exit_code"] != 0:
            eligible = []
        row = {"group": name, "group_requested": targets, "eligible_after_actual_gates": eligible,
               "readiness": ready, "individual_readiness": individual}
        if not eligible:
            no_normal(name)
            selection.append({**row, "status": "SKIPPED_ACTUAL_DIRECT_DEPS_NOT_READY", "built": []})
            continue
        cmd, raw = command(name, helper.guard(1,
            ["lake", "build"] + ["+" + m + ":olean" for m in eligible]))
        built, failed, headers = checked_headers(raw, cmd, eligible, helper, ops)
        scope = evidence.jread(lane_dir / (name + "-BUILD_SCOPE.json"))
        require(scope["group_requested"] == targets and scope["requested"] == eligible and
                scope["built"] == built and scope["failed"] == failed and scope["unexpected"] == [] and
                scope["normal_requires_separate_kernel_and_owned_audit"] is True,
                "actual_build_scope_disagrees_with_eligible_command", name)
        key = "batch9_" + name
        groups[key] = built
        if built:
            logs[key] = {"path": cmd["log"], "sha256": sha(raw), "source_commit": NORMAL_COMMIT,
                         "expected_built_modules": built, "expected_failed_modules": failed}
            records[key] = {"original_command": cmd, "complete_built_headers": headers,
                            "whole_command_exit_code": cmd["exit_code"],
                            "original_command_record": file_info(lane_dir / (name + "-command.json")),
                            "original_log": file_info(lane_dir / (name + ".log")),
                            "source_context_kind": "ORIGINAL_BATCH9_PROJECT_SOURCE_CONTEXT",
                            "Replayed_headers_not_selected": True}
            selected.extend(built)
        selection.append({**row, "status": "FINISHED_NORMAL", "built": built, "failed": failed,
                          "without_new_Built_or_failed_header": sorted(set(eligible) - set(built + failed)),
                          "whole_command_exit_code": cmd["exit_code"]})
    audit_log = str(cloud_dir / "existing-normal-full-audit.log")
    require(set(stages) - used_stages <= {audit_log}, "unrecognized_lane1_command_stage",
            sorted(set(stages) - used_stages))
    return groups, logs, records, selection, selected, stages


def completed_prior_audit(args, evidence, root, config, prior, prior_raw, stages):
    """Exclude audit11; claim complete reuse only for its exact e9 PASS receipt."""
    prior_targets = list(prior["modules"])
    excluded, reused = list(prior["excluded_prior13"]), list(prior["reused_complete_modules"])
    result = None
    if config["audit_preparation_exit_code"] == 0:
        audit_root = Path(prior["receipt_root"])
        cmd, _ = original_command(evidence, root / "execution/lane-1", CLOUD_ROOT / "execution/lane-1",
            "existing-normal-full-audit", ["python3", config["audit_runner"], "--plan",
            str(audit_root / "AUDIT_PLAN.json"), "--receipt-root", str(audit_root), "--lane", "1"], stages)
        receipt_path = args.prior_audit_receipt or (
            evidence.root / audit_root.name / "lane-1/VALIDATION_RESULTS.json")
        if cmd["exit_code"] == 0 or receipt_path.exists():
            receipt = evidence.jread(receipt_path)
            require(receipt["status"] == COMPLETE_STATUS and receipt["plan_sha256"] == sha(prior_raw),
                    "prior_audit11_not_complete_exact_plan")
            require(receipt["modules"] == {m: row["source_sha256"] for m, row in prior["modules"].items()} and
                    receipt["project_dependency_sources"] == prior["expected_project_sources"],
                    "prior_audit11_complete_source_context_mismatch")
            for flag in ("source_plus_five_outputs_unchanged_across_kernel_and_audit",
                         "full_owned_including_private_generated", "only_standard_axioms",
                         "pp_all_true_no_elisions", "successful_normal_not_repeated"):
                require(receipt[flag] is True, "prior_audit11_required_acceptance_gate", flag)
            require(cmd["exit_code"] == 0, "prior_audit_receipt_with_failed_outer_command")
            reused += prior_targets
            result = {"receipt": file_info(receipt_path), "status": receipt["status"],
                      "module_count": len(receipt["modules"]), "owned_count": receipt["total_owned_exports"],
                      "repeated_by_this_plan": False}
    return excluded, list(dict.fromkeys(reused)), prior_targets, result


def higher_evidence(args, evidence, root, normal, config, batch_result, context, helper, ops):
    """Return an a9 source binding only after the original complete normal PASS."""
    local = root / "higher"
    cloud = CLOUD_ROOT / "higher"
    result_path = local / "execution/lane-0/NORMAL_RESULT.json"
    if not result_path.exists():
        require(batch_result["lane_commands"][0]["exit_code"] != 0,
                "successful_higher_lane_missing_normal_result")
        return None, {"status": "NO_COMPLETE_HIGHER_NORMAL_RESULT_NOT_SELECTED"}
    outcome = evidence.jread(result_path)
    if outcome["status"] != HIGHER_PASS:
        require(outcome["status"] in {"NORMAL_NOT_ACCEPTED", "BLOCKED_DEPENDENCIES_NO_INSTALL_OR_NORMAL"},
                "unknown_higher_normal_status", outcome["status"])
        return None, {"status": outcome["status"], "original_result": file_info(result_path),
                      "selected": False, "not_compiled_again_by_this_adapter": True}
    plan_raw = evidence.read(local / "inputs/EXECUTION_PLAN.json")
    require(sha(plan_raw) == HIGHER_PLAN_SHA and plan_raw == normal.read(HIGHER_PLAN_PATH),
            "higher_plan_not_exact_published_bytes")
    hp = json.loads(plan_raw)
    hc = evidence.jread(local / "RUN_CONFIG.json")
    require(hc == config["higher_config"] and hc["package_commit"] == NORMAL_COMMIT and
            hc["receipt_root"] == str(cloud) and hc["normal_target"] == HIGHER and
            hc["sources_installed_by_prepare"] is False and hc["plan_sha256"] == HIGHER_PLAN_SHA,
            "higher_independent_run_config_binding")
    driver = evidence.read(local / "executed-driver.py")
    require(sha(driver) == HIGHER_DRIVER_SHA == hc["driver_sha256"] and
            driver == normal.read(HIGHER_DRIVER_PATH), "higher_worker_exact_code_binding")
    require(hp["source_preimage_sha256"] == HIGHER_BEFORE and hp["candidate_sha256"] == HIGHER_AFTER and
            hp["canonical_path"] == helper.module_path(HIGHER), "higher_fixed_source_transition")
    candidate = evidence.read(local / "inputs/candidate.lean")
    preimage = evidence.read(local / "inputs/published-preimage.lean")
    donor = GitTree(args.repo, hp["source_commit"])
    try:
        require(candidate == donor.read(hp["candidate_published_path"]) and sha(candidate) == HIGHER_AFTER and
                preimage == donor.read(hp["canonical_path"]) and sha(preimage) == HIGHER_BEFORE and
                normal.read(hp["canonical_path"]) == preimage,
                "higher_candidate_or_preimage_not_exact_published_source")
        origin = donor.metadata(hp["candidate_published_path"])
    finally:
        donor.close()
    reads = evidence.jread(local / "GIT_SHOW_READS.json")
    verify_git_read(reads, cloud / "inputs/candidate.lean", hp["source_commit"], hp["candidate_published_path"], candidate)
    verify_git_read(reads, cloud / "inputs/published-preimage.lean", hp["source_commit"], hp["canonical_path"], preimage)
    require(context[HIGHER] == source_row(preimage, helper) and
            helper.imports(candidate) == helper.imports(preimage),
            "higher_preinstall_context_or_imports_changed")
    require(hc["expected_project_dependencies"] == hp["expected_project_dependencies"] ==
            outcome["project_dependency_sources"], "higher_dependency_source_maps_disagree")
    for m, digest in hp["expected_project_dependencies"].items():
        require(context[m]["sha256"] == digest and sha(normal.read(helper.module_path(m))) == digest,
                "higher_dependency_not_bound_to_actual_and_published_context", m)
    installed = evidence.jread(local / "SOURCE_INSTALL.json")
    require(len(installed["sources"]) == 1, "higher_install_scope")
    row = installed["sources"][0]
    require(row["module"] == HIGHER and row["path"] == hp["canonical_path"] and row["mutated"] is True and
            row["action"] == "INSTALL_BACKED_UP_PREIMAGE" and row["cloud_source_mutation_required"] is True and
            row["before_sha256"] == row["actual_before_sha256"] == HIGHER_BEFORE and
            row["after_sha256"] == row["actual_after_sha256"] == HIGHER_AFTER and
            installed["protected_roots_after"] == helper.FOUR_ROOTS and
            installed["original_dirty_git_worktree_not_checked_out"] is True,
            "higher_independent_source_install_not_exact")
    require(evidence.read(local / "source-backups" / hp["canonical_path"]) == preimage,
            "higher_exact_preimage_backup_missing")
    gate_raw = evidence.read(local / "PROBE_GATE.json")
    recheck = evidence.jread(local / "execution/lane-0/PROBE_GATE_RECHECK.json")
    require(sha(gate_raw) == hc["probe_gate_sha256"] == installed["probe_gate_sha256"] ==
            outcome["probe_gate_sha256"] == recheck["gate_sha256"] and
            recheck["actual_cloud_receipts_rechecked"] is True,
            "higher_original_probe_gate_binding")
    gate = json.loads(gate_raw)
    require(gate["status"] == "ACTUAL_BATCH8_PROBES_AND_LANE0_VERIFIED", "higher_original_probe_gate_status")
    for path, binding in gate["evidence_files"].items():
        rel = Path(path).relative_to(hp["batch8"]["root"])
        raw = evidence.read(local / "reused-batch8-evidence" / rel)
        require(sha(raw) == binding["sha256"] and len(raw) == binding["bytes"],
                "higher_original_reused_probe_evidence_changed", str(rel))
    lane_dir, cloud_dir = local / "execution/lane-0", cloud / "execution/lane-0"
    ready, _ = original_command(evidence, lane_dir, cloud_dir, "higher-directdeps", helper.guard(0,
        ["lake", "--no-build", "build"] + ["+" + m + ":olean" for m in hp["direct_project_dependencies"]]))
    cmd, raw = original_command(evidence, lane_dir, cloud_dir, "higher-full-module-normal", helper.guard(0,
        ["lake", "build", "+" + HIGHER + ":olean"]))
    built, failed, headers = checked_headers(raw, cmd, [HIGHER], helper, ops)
    require(ready["exit_code"] == cmd["exit_code"] == 0 and built == [HIGHER] and failed == [] and
            outcome["normal_command"] == cmd and outcome["direct_dependency_readiness"] == ready,
            "higher_PASS_without_exact_successful_normal_and_readiness")
    before = evidence.jread(lane_dir / "SOURCE_FIVE_BEFORE.json")
    after = evidence.jread(lane_dir / "SOURCE_FIVE_AFTER.json")
    check_snapshot(HIGHER, before, HIGHER_BEFORE, len(preimage))
    check_snapshot(HIGHER, after, HIGHER_AFTER, len(candidate), complete=True)
    require(outcome["module"] == HIGHER and outcome["source_sha256"] == HIGHER_AFTER and
            outcome["source_preimage_sha256"] == HIGHER_BEFORE and outcome["source_plus_five_outputs"] == after,
            "higher_normal_result_source_plus_five_binding")
    deps = evidence.jread(lane_dir / "DEPENDENCIES_BEFORE.json")
    roots = evidence.jread(lane_dir / "FOUR_ROOTS_BEFORE.json")
    require(set(deps) == set(hp["expected_project_dependencies"]) and set(roots) == set(helper.FOUR_ROOTS),
            "higher_dependency_or_protected_root_snapshot_scope")
    for m, digest in hp["expected_project_dependencies"].items():
        check_snapshot(m, deps[m], digest, context[m]["bytes"])
        require(deps[m][artifact_paths(m)[1]] is not None, "higher_ready_dependency_olean_missing", m)
    for m, digest in helper.FOUR_ROOTS.items():
        check_snapshot(m, roots[m], digest)
    for flag in ("project_dependency_artifacts_unchanged", "protected_four_roots_unchanged",
                 "runtime_guard_serializer_and_state_unchanged", "original_dirty_git_worktree_unchanged",
                 "all_raw_logs_preserved"):
        require(outcome[flag] is True, "higher_post_normal_invariance_gate", flag)
    require(outcome["independent_kernel_verified"] is False and outcome["full_owned_audit_verified"] is False and
            outcome["low_middle_or_degree6_probe_repeated"] is False and
            batch_result["higher_actual_source_sha256"] == HIGHER_AFTER and
            batch_result["lane_commands"][0]["exit_code"] == 0,
            "higher_final_source_or_lane_binding")
    provenance = {"status": HIGHER_PASS, "selected": True, "source_origin": origin,
                  "execution_commit": NORMAL_COMMIT, "original_result": file_info(result_path),
                  "source_install": file_info(local / "SOURCE_INSTALL.json"),
                  "source_plus_five_before": before, "source_plus_five_after": after,
                  "dependency_snapshots_before": deps, "protected_root_snapshots_before": roots,
                  "dependency_after_binding": {
                      "kind": "EXACT_ORIGINAL_WORKER_POST_NORMAL_EQUALITY_ASSERTIONS_AND_RESULT_FLAGS",
                      "worker_sha256": HIGHER_DRIVER_SHA,
                      "result": file_info(result_path),
                      "separate_DEPENDENCIES_AFTER_file_emitted_by_worker": False,
                      "no_synthetic_after_snapshot_created": True},
                  "main_context_kept_as_actual_preinstall_3bc": True,
                  "independent_postinstall_source_context": source_row(candidate, helper),
                  "complete_built_headers": headers, "original_normal_command": cmd,
                  "normal_only_not_kernel_or_full_owned_acceptance": True}
    return {"raw": candidate, "origin": origin, "command": cmd, "raw_log": raw,
            "headers": headers, "provenance": provenance}, provenance


def prepare(args):
    evidence = ArchiveEvidence(args.archive_root, args.archive_index, args.archive_index_sha256)
    root = args.evidence_root.resolve()
    require(root.is_relative_to(evidence.root), "batch9_evidence_not_under_original_archive")
    normal = GitTree(args.repo, NORMAL_COMMIT)
    review = normal if args.review_commit == NORMAL_COMMIT else GitTree(args.repo, args.review_commit)
    try:
        config = evidence.jread(root / "RUN_CONFIG.json")
        result = evidence.jread(root / "BATCH9_RESULT.json")
        context = evidence.jread(root / "PROJECT_SOURCE_CONTEXT.json")
        installation = evidence.jread(root / "SOURCE_INSTALL.json")
        reads = evidence.jread(root / "GIT_SHOW_READS.json")
        execution_raw = evidence.read(root / "inputs/EXECUTION_PLAN.json")
        execution = json.loads(execution_raw)
        require(config["commit"] == result["commit"] == installation["commit"] == NORMAL_COMMIT and
                execution_raw == normal.read(EXECUTION_PLAN_PATH) and
                config["plan_sha256"] == sha(execution_raw), "batch9_original_execution_binding")
        require(result["all_other_context_sources_unchanged_during_execution"] is True and
                result["original_dirty_git_worktree_unchanged"] is True and
                result["probe_and_previous_complete_audits_repeated"] is False,
                "batch9_final_context_or_worktree_gate_missing")
        require(context == config["sources"], "actual_context_disagrees_with_run_config")
        helper_raw = evidence.read(root / "inputs/batch5_helpers.py")
        ops_raw = evidence.read(root / "inputs/batch6_operations.py")
        helper = load_read_only_helpers(helper_raw, HELPER_SHA, "batch9_readonly_exact_helper")
        ops = load_read_only_helpers(ops_raw, OPS_SHA, "batch9_readonly_exact_ops")
        require(helper_raw == normal.read(HELPER_PATH) and ops_raw == normal.read(OPS_PATH),
                "original_helpers_not_published_bytes")
        runner_raw = evidence.read(root / "inputs/run_parallel_acceptance_multibatch.py")
        require(sha(runner_raw) == RUNNER_SHA and runner_raw == normal.read(RUNNER_PATH) == review.read(RUNNER_PATH),
                "exact_e9_runner_changed")
        driver = evidence.read(root / "executed-driver.py")
        require(sha(driver) == DRIVER_SHA == config["driver_sha256"] and driver == normal.read(DRIVER_PATH),
                "original_batch9_driver_changed")
        completed_workers(evidence, root, config, result, helper)
        require(result["protected_roots"] == installation["protected_roots"] == helper.FOUR_ROOTS,
                "protected_original_four_root_receipts_disagree")
        for m, digest in helper.FOUR_ROOTS.items():
            require(sha(review.read(helper.module_path(m))) == digest, "review_changes_original_root", m)
        candidates = [m for group in execution["normal_groups"] for m in group["targets"]]
        require(len(candidates) == len(set(candidates)) == execution["normal_module_count"] == 29 and
                HIGHER not in candidates, "original_normal29_universe_changed")
        require(config["source_mismatch_modules"] == [] and set(config["normal_sources"]) == set(candidates),
                "SOURCE_MISMATCH_UNREVIEWED_BATCH9_TARGET", {
                    "source_mismatch_modules": config["source_mismatch_modules"],
                    "actual_context": {m: context[m] for m in candidates},
                    "published_expected": execution["normal_sources"]})
        for m in candidates:
            require(config["normal_sources"][m] == execution["normal_sources"][m]["sha256"] ==
                    context[m]["sha256"] == sha(normal.read(helper.module_path(m))),
                    "SOURCE_MISMATCH_NORMAL_TARGET", m)
        require(all(row["imports"] == config["graph"][m] for m, row in context.items()),
                "original_context_graph_disagrees")
        require(sorted(helper.closure(config["graph"], candidates)) == config["normal_dependency_closure"],
                "original_normal_dependency_closure_disagrees")
        update_raw = evidence.read(root / "inputs/SOURCE_UPDATE.json")
        update = json.loads(update_raw)
        require(sha(update_raw) == execution["source_update_sha256"] and
                update_raw == normal.read(execution["source_update_path"]), "source_update_not_published_bytes")
        installed = {r["module"]: r for r in installation["sources"]}
        require(len(installed) == len(installation["sources"]) == len(update["updates"]) and
                set(installed) == {r["module"] for r in update["updates"]} <= set(candidates),
                "ordinary_install_scope_changed")
        for row in update["updates"]:
            m, rel = row["module"], row["path"]
            raw = evidence.read(root / "inputs/sources" / rel)
            require(rel == helper.module_path(m) and raw == normal.read(rel) and
                    sha(raw) == row["after_sha256"] == installed[m]["actual_after_sha256"] == context[m]["sha256"],
                    "ordinary_install_actual_source_binding", m)
            require(all(installed[m].get(k) == v for k, v in row.items()),
                    "ordinary_install_manifest_row_changed", m)
            if installed[m]["mutated"]:
                backup = evidence.read(root / "source-backups" / rel)
                require(sha(backup) == row["before_sha256"] == installed[m]["actual_before_sha256"],
                        "ordinary_install_preimage_backup_binding", m)
            else:
                require(installed[m]["actual_before_sha256"] == row["after_sha256"],
                        "ordinary_noop_did_not_preserve_existing_after_source", m)
            verify_git_read(reads, CLOUD_ROOT / "inputs/sources" / rel, NORMAL_COMMIT, rel, raw)
        prior_raw = evidence.read(root / "inputs/AUDIT_PLAN.json")
        prior = json.loads(prior_raw)
        require(sha(prior_raw) == execution["audit_plan_sha256"] and
                prior_raw == normal.read(execution["audit_plan_path"]) and len(prior["modules"]) == 11,
                "original_audit11_plan_not_exact_published_bytes")
        require(config["audit_receipt_root"] == prior["receipt_root"] and
                config["audit_runner"] == str(CLOUD_ROOT / "inputs/run_parallel_acceptance_multibatch.py") and
                prior["project"] == PROJECT and prior["runtime_states"] == [str(s) for s in helper.STATES] and
                prior["lanes"][0] == {"id": 0, "modules": []} and
                set(prior["lanes"][1]["modules"]) == set(prior["modules"]),
                "original_audit11_runner_or_receipt_root_binding")
        preparation, _ = original_command(evidence, root, CLOUD_ROOT, "existing-normal-audit-prepare-only", [
            "python3", config["audit_runner"], "--plan", str(CLOUD_ROOT / "inputs/AUDIT_PLAN.json"), "--prepare-only"])
        require(preparation["exit_code"] == config["audit_preparation_exit_code"],
                "audit11_preparation_command_not_bound")
        groups, logs, records, selections, selected, stages = normal_group_evidence(
            evidence, root, execution, config, helper, ops)
        excluded, reused, prior_targets, prior_result = completed_prior_audit(
            args, evidence, root, config, prior, prior_raw, stages)
        higher, higher_provenance = higher_evidence(
            args, evidence, root, normal, config, result, context, helper, ops)
        if higher:
            key = "batch9_higher_full_module_normal"
            cmd = higher["command"]
            groups[key] = [HIGHER]
            logs[key] = {"path": cmd["log"], "sha256": sha(higher["raw_log"]),
                         "source_commit": higher["origin"]["source_commit"],
                         "normal_execution_commit": NORMAL_COMMIT,
                         "expected_built_modules": [HIGHER], "expected_failed_modules": []}
            records[key] = higher_provenance
            selected.append(HIGHER)
        require(len(selected) == len(set(selected)), "duplicate_new_normal_credit")
        require(not set(selected) & set(excluded + reused + prior_targets), "duplicate_prior_accepted_or_audit11_target")
        graph, sources, mismatches = {}, {}, []

        def visit(m):
            if m in graph:
                return
            rel = helper.module_path(m)
            raw = higher["raw"] if m == HIGHER and higher else normal.read(rel)
            actual = source_row(raw, helper)
            origin = higher["origin"] if m == HIGHER and higher else normal.metadata(rel)
            original_context = actual if m == HIGHER and higher else context.get(m)
            current_raw = review.read(rel)
            if original_context != actual or sha(current_raw) != sha(raw) or config["graph"].get(m) != actual["imports"]:
                mismatches.append({"module": m, "published_normal_source": origin,
                                   "actual_normal_context": original_context,
                                   "original_main_preinstall_context": context.get(m),
                                   "reviewed_canonical_source": review.metadata(rel),
                                   "normal_sha256": sha(raw), "expected_project_imports": actual["imports"],
                                   "original_context_imports": config["graph"].get(m),
                                   "higher_independent_install_proof_required_and_checked": m == HIGHER and bool(higher)})
            graph[m] = actual["imports"]
            sources[m] = {**review.metadata(rel), "imports": actual["imports"],
                          "normal_source_origin": origin, "normal_execution_commit": NORMAL_COMMIT,
                          "source_binding_basis": "INDEPENDENT_HIGHER_INSTALL_AND_NORMAL_RESULT" if m == HIGHER
                          else "EXACT_PUBLISHED_BATCH9_SOURCE_AND_UNCHANGED_ACTUAL_CONTEXT"}
            for dep in graph[m]:
                visit(dep)
        for m in selected:
            visit(m)
        require(not mismatches, "SOURCE_MISMATCH_NO_PLAN_FROZEN", mismatches)
        closures = {m: sorted(helper.closure(graph, [m])) for m in selected}
        require(set(sources) == set().union(*(set(c) for c in closures.values())), "selected_closure_not_exact")
        if higher:
            require(set(closures[HIGHER]) - {HIGHER} == set(config["higher_config"]["expected_project_dependencies"]),
                    "higher_complete_selected_dependency_closure_disagrees")
        concurrent = list(dict.fromkeys(args.concurrent_module))
        for m in concurrent:
            helper.module_path(m)
        require(not set(concurrent) & set(sources), "concurrent_write_in_selected_audit_closure",
                sorted(set(concurrent) & set(sources)))
        modules = {}
        for key, built in groups.items():
            for m in built:
                s = sources[m]
                origin = s["normal_source_origin"]
                modules[m] = {"source_sha256": s["sha256"], "source_bytes": s["bytes"], "normal_log": key,
                    "normal_source_commit": origin["source_commit"], "normal_execution_commit": NORMAL_COMMIT,
                    "normal_source_git_blob_sha1": origin["git_blob_sha1"],
                    "normal_source_repository_path": origin["repository_path"],
                    "current_source_commit": review.commit, "current_source_git_blob_sha1": s["git_blob_sha1"],
                    "project_closure": closures[m], "project_closure_count": len(closures[m]),
                    "original_normal_source_context_complete": True,
                    "original_normal_all_project_sources_match_current_expected_context": True,
                    "normal_context_binding_kind": s["source_binding_basis"],
                    "historical_full_receipt_reused": False,
                    "audit_status": "NORMAL_REUSED_NEW_NAMED_KERNEL_AND_FULL_OWNED_PENDING"}
        plan = {"schema": "p1_completed_normal_multibatch_audit_plan_v1",
            "status": "PLAN_ONLY_NORMAL_REUSE_KERNEL_FULL_OWNED_PENDING", "source_review_head": review.commit,
            "project": PROJECT, "receipt_root": args.receipt_root,
            "runtime_states": [str(s) for s in helper.STATES], "audit_template": prior["audit_template"],
            "normal_logs": logs, "modules": modules, "groups": groups,
            "lanes": [{"id": 0, "modules": []}, {"id": 1, "modules": selected}],
            "expected_project_sources": {m: s["sha256"] for m, s in sorted(sources.items())},
            "excluded_prior13": excluded, "reused_complete_modules": reused,
            "excluded_prior_audit_targets_without_new_acceptance_claim": [] if prior_result else prior_targets,
            "successful_normal_not_to_be_repeated": True, "whole_P1_complete": False,
            "full_selected_11026_accepted": False,
            "source_context_binding": {"kind": "ACTUAL_BATCH9_CONTEXT_PLUS_INDEPENDENT_HIGHER_NORMAL_IF_PASSED",
                "normal_execution_commit": NORMAL_COMMIT, "review_commit": review.commit, "review_tree": review.tree,
                "original_preinstall_context": file_info(root / "PROJECT_SOURCE_CONTEXT.json"),
                "higher_selected_only_from_exact_independent_normal_result": bool(higher),
                "all_selected_source_and_ancestor_bytes_match_published_review_tree": True,
                "actual_cloud_source_gate_required": True, "current_cloud_readiness_claimed": False},
            "runner_binding": {"repository_path": RUNNER_PATH, "reviewed_commit": review.commit,
                "sha256": RUNNER_SHA, "unchanged_existing_runner": True,
                "required_invocation": "--prepare-only, then explicit --lane 1 inside existing state1 serializer; runner supplies guards.",
                "default_dual_lane_invocation_forbidden": True, "lane0_must_not_be_launched": True},
            "execution_constraints": {"active_lane": 1, "active_lane_modules": len(selected),
                "normal_compilation_not_to_be_repeated": True, "new_kernel_or_owned_acceptance_not_claimed_by_plan": True,
                "source_plus_five_outputs_gate_unchanged": True, "named_leanchecker_gate_unchanged": True,
                "all_environment_owned_types_and_axioms_gate_unchanged": True,
                "no_build_before_and_after_unchanged": True, "check_all_project_source_hashes_before_kernel": True},
            "dependency_review": {"project_closure_count": len(sources), "concurrent_write_modules": concurrent,
                "concurrent_write_modules_in_audit_closure": [], "concurrent_write_set_supplied": bool(concurrent),
                "protected_original_four_roots": helper.FOUR_ROOTS, "source_or_artifact_mutations_allowed_by_audit": False}}
        provenance = {"schema": "p1_batch9_actual_normal_supplement_provenance_v1",
            "normal_execution_commit": NORMAL_COMMIT, "review_commit": review.commit,
            "original_archive_index": file_info(args.archive_index), "raw_evidence_files": evidence.used,
            "normal_groups": records, "actual_group_selection": selections,
            "higher_independent_normal": higher_provenance, "prior11_actual_complete_acceptance": prior_result,
            "current_project_import_graph": graph, "current_expected_source_metadata": sources,
            "all_source_ancestors_bound_to_actual_context_and_published_review": True,
            "reused_aligned_generator": file_info(COMMON_PATH), "exact_e9_runner": review.metadata(RUNNER_PATH),
            "normal_success_is_not_kernel_or_full_owned_acceptance": True,
            "Lean_or_cloud_executed_by_generator": False, "canonical_modified": False}
        selection = {"status": "READY_FOR_PLAN_FREEZE" if selected else "NO_NEW_BUILT_TARGETS_NOTHING_TO_AUDIT",
            "normal_execution_commit": NORMAL_COMMIT, "review_commit": review.commit,
            "candidate_normal29": candidates, "groups": selections, "higher": higher_provenance["status"],
            "actual_built_targets": selected, "actual_built_count": len(selected),
            "project_source_count": len(sources), "proof_acceptance_claimed": False}
        return plan, provenance, selection, evidence
    finally:
        if review is not normal:
            review.close()
        normal.close()


def write_result(args, plan, provenance, selection, evidence):
    require(not args.out.exists(), "exclusive_output_directory_already_exists", str(args.out))
    args.out.mkdir(parents=True)
    (args.out / "SELECTION.json").write_bytes(json_bytes(selection))
    bundle = args.out / "NORMAL_EVIDENCE.tar.xz"
    with tarfile.open(bundle, "x:xz", format=tarfile.PAX_FORMAT) as archive:
        archive.add(evidence.index_path, arcname="ORIGINAL_ARCHIVE_FILES.json", recursive=False)
        for path, meta in sorted(evidence.used.items()):
            require(digest_file(path) == meta["sha256"], "evidence_changed_during_preparation", path)
            archive.add(path, arcname=meta["archive_member"], recursive=False)
    if selection["actual_built_targets"]:
        (args.out / "AUDIT_PLAN.json").write_bytes(json_bytes(plan))
        provenance["audit_plan_sha256"] = digest_file(args.out / "AUDIT_PLAN.json")
    provenance["raw_evidence_bundle"] = file_info(bundle)
    (args.out / "PROVENANCE.json").write_bytes(json_bytes(provenance))
    (args.out / "HIGHER_NORMAL_BINDING.json").write_bytes(json_bytes(provenance["higher_independent_normal"]))
    (args.out / "SOURCE_GRAPH.json").write_bytes(json_bytes({
        "source_commit": plan["source_review_head"], "graph": provenance["current_project_import_graph"],
        "sources": provenance["current_expected_source_metadata"],
        "closures": {m: r["project_closure"] for m, r in plan["modules"].items()}}))
    manifest = {"schema": "p1_batch9_normal_audit_package_v1", "generator": file_info(Path(__file__)),
        "reused_aligned_generator": file_info(COMMON_PATH), "status": selection["status"],
        "new_acceptance_claimed": False,
        "files": {p.name: file_info(p) for p in sorted(args.out.iterdir()) if p.is_file()}}
    (args.out / "MANIFEST.json").write_bytes(json_bytes(manifest))
    return {"status": selection["status"], "out": str(args.out), "targets": selection["actual_built_count"],
            "project_sources": selection["project_source_count"], "audit_plan_sha256": provenance.get("audit_plan_sha256")}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", required=True, type=Path)
    parser.add_argument("--evidence-root", required=True, type=Path)
    parser.add_argument("--archive-root", required=True, type=Path)
    parser.add_argument("--archive-index", required=True, type=Path)
    parser.add_argument("--archive-index-sha256", required=True)
    parser.add_argument("--review-commit", required=True,
                        help="Published Git canonical sources must equal every selected actual normal source, including a9 Higher if passed.")
    parser.add_argument("--prior-audit-receipt", type=Path)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--receipt-root", default=DEFAULT_RECEIPT_ROOT)
    parser.add_argument("--concurrent-module", action="append", default=[])
    parser.add_argument("--check-only", action="store_true")
    args = parser.parse_args()
    require(re.fullmatch(r"[0-9a-f]{64}", args.archive_index_sha256), "complete_archive_index_SHA_required")
    require(Path(args.receipt_root).is_absolute(), "absolute_cloud_receipt_root_required")
    try:
        plan, provenance, selection, evidence = prepare(args)
        print(json.dumps(selection if args.check_only else write_result(args, plan, provenance, selection, evidence),
                         ensure_ascii=False, indent=2))
        return 0 if selection["actual_built_targets"] else 2
    except (EvidenceError, KeyError, FileNotFoundError) as error:
        diagnostic = {"status": "EVIDENCE_NOT_READY_OR_MISMATCH_NO_PLAN_FROZEN", "error": str(error),
                      "normal_execution_commit": NORMAL_COMMIT, "review_commit": args.review_commit,
                      "source_gate_not_relaxed": True, "cloud_or_Lean_executed": False}
        if not args.check_only and "SOURCE_MISMATCH" in str(error):
            target = args.out.with_name(args.out.name + "-SOURCE_MISMATCH.json")
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open("xb") as stream:
                stream.write(json_bytes(diagnostic))
            diagnostic["diagnostic_file"] = str(target)
        print(json.dumps(diagnostic, ensure_ascii=False), file=sys.stderr)
        return 3


if __name__ == "__main__":
    raise SystemExit(main())
