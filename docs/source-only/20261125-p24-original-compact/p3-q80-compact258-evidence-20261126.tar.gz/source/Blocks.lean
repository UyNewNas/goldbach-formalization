import Lean
import Lean.Meta.Tactic.Cbv
import Lean.Meta.Sym.LitValues
import Lean.Util.CollectAxioms

/-!
Isolated original-Q80 proof-block diagnostic; no production module is imported.

The original source definitions and generic mathematical interfaces are copied
from the passed P24Q80NodeFactorization.lean (SHA-256
2f2e00982c0e28a4e93187106df1d0eed5d0912aec2b6473c0737689ac9c2a48),
with only the outer diagnostic namespace changed.

This prepared entry point computes the first 258 64-node nonconstant blocks,
16512 nodes at indices 32769 through 49280. The last two blocks cross i > 3*g;
the final block has three computed nonconstant predecessors at every node.
Run this size experiment only after the 128-node compact variant has passed
compilation, independent replay and the unchanged complete owned audit.
Each small arithmetic expression is reduced by a
fresh proof-producing cbvEntry at the existing default step limit. Proof-valued
lets share within-block facts; only synchronously checked private block theorems
publish facts into the temporary cache. Cache reads use direct index offsets.

No node/table/first/tail output is installed as an evaluator definition.
The final first-prefix positivity query is diagnostic only: it is not d10,
not the archived rational equality, and not a canonical P2 acceptance receipt.
All owned declarations, including the generator and its generated block theorems,
remain subject to independent replay and the unchanged complete owned audit.
No resource option is changed here.
The public diagnostic entry also tests private auxiliary naming below the
current public theorem, with one naming scope around the complete computation.
-/

namespace P24Q80NodeProofBlocks

local notation "ℕ" => Nat
local notation "ℤ" => Int

namespace ImbalancedChen.P2HistoricSieveTableSemantics

structure HistoricNode where
  ll : ℤ
  lh : ℤ
  hl : ℤ
  hh : ℤ
  deriving DecidableEq, Repr

end ImbalancedChen.P2HistoricSieveTableSemantics

namespace ImbalancedChen.P2OriginalCompactQ80EncloserSourceOnly

def scale : ℤ := 2 ^ 80

def up (n d : ℤ) : ℤ := -((-n) / d)

abbrev Node := P2HistoricSieveTableSemantics.HistoricNode
def initialNode : Node := ⟨0,0,scale,scale⟩
def trapLower (g j : ℕ) (x y : ℤ) : ℤ :=
  (x*(g : ℤ)/((j : ℤ)-1)+y*(g : ℤ)/(j : ℤ))/(2*(g : ℤ))
def trapUpper (g j : ℕ) (x y : ℤ) : ℤ :=
  up (up (x*(g : ℤ)) ((j : ℤ)-1)+up (y*(g : ℤ)) (j : ℤ)) (2*(g : ℤ))

def nodeUpdate (g i : ℕ) (old : ℕ → Node) : Node :=
  if i ≤ 2*g then initialNode else
  let j := i-g
  let p := old (i-1)
  let lo := trapLower g j (old (j-1)).hl (old j).hl
  let hi := trapUpper g j (old (j-1)).hh (old j).hh
  { ll := max p.ll (p.ll+lo-up scale (6*(g : ℤ)^3))
    lh := p.lh+hi
    hl := if i ≤ 3*g then scale else
      p.hl+trapLower g j (old (j-1)).ll (old j).ll
    hh := if i ≤ 3*g then scale else
      p.hh+trapUpper g j (old (j-1)).lh (old j).lh+up scale (12*(g : ℤ)^3) }

/-- A pure integer recursion, separately executable from the analytic
predecessor's noncomputable section. This is the complete table, not literals. -/
def sourceState (g : ℕ) : ℕ → (ℕ → Node) :=
  Nat.rec (motive := fun _ => ℕ → Node) (fun _ => initialNode)
    (fun k old i => if i = k+1 then nodeUpdate g (k+1) old else old i)

def sourceTable : ℕ → Node := sourceState 16384 (12*16384)

end ImbalancedChen.P2OriginalCompactQ80EncloserSourceOnly

namespace NodeStepProof

open ImbalancedChen.P2OriginalCompactQ80EncloserSourceOnly

/-- The exact original update arithmetic with its three reader arguments made
explicit. No computed node values are stored in this definition. -/
private def nodeFromThree (g i : ℕ) (p l r : Node) : Node :=
  if i ≤ 2*g then initialNode else
  let j := i-g
  let lo := trapLower g j l.hl r.hl
  let hi := trapUpper g j l.hh r.hh
  { ll := max p.ll (p.ll+lo-up scale (6*(g : ℤ)^3))
    lh := p.lh+hi
    hl := if i ≤ 3*g then scale else
      p.hl+trapLower g j l.ll r.ll
    hh := if i ≤ 3*g then scale else
      p.hh+trapUpper g j l.lh r.lh+up scale (12*(g : ℤ)^3) }

/-- Reader factorization is definitional equality for the actual Q80 formula. -/
private theorem nodeUpdate_from_three (g i : Nat) (old : Nat → Node) :
    nodeUpdate g i old =
      nodeFromThree g i (old (i - 1)) (old ((i - g) - 1)) (old (i - g)) := by
  rfl

/-- Increasing-index writes preserve every previously completed index.
The proof does not inspect the four integer fields or evaluate any table. -/
private theorem sourceState_completed_index_stable (g completed remaining i : Nat)
    (hi : i ≤ completed) :
    sourceState g (completed + remaining) i = sourceState g completed i := by
  induction remaining with
  | zero => rfl
  | succ remaining ih =>
      have hne : i ≠ completed + remaining + 1 := by omega
      change (if i = completed + remaining + 1 then
        nodeUpdate g (completed + remaining + 1)
          (sourceState g (completed + remaining))
        else sourceState g (completed + remaining) i) = sourceState g completed i
      rw [if_neg hne]
      exact ih

private theorem sourceState_at_completed (g n i : Nat) (hi : i ≤ n) :
    sourceState g n i = sourceState g i i := by
  have h := sourceState_completed_index_stable g i (n - i) i (Nat.le_refl i)
  have hcount : i + (n - i) = n := by omega
  simpa only [hcount] using h

private theorem sourceState_step (g n : Nat) :
    sourceState g (n + 1) (n + 1) = nodeUpdate g (n + 1) (sourceState g n) := by
  change (if n + 1 = n + 1 then nodeUpdate g (n + 1) (sourceState g n)
    else sourceState g n (n + 1)) = _
  rw [if_pos rfl]

/-- Every reader argument is the value at its own completed step.
The positivity assumption is exactly what makes i-g an earlier index. -/
private theorem source_node_recurrence (g n : Nat) (hg : 0 < g) :
    sourceState g (n + 1) (n + 1) =
      nodeFromThree g (n + 1)
        (sourceState g n n)
        (sourceState g (((n + 1) - g) - 1) (((n + 1) - g) - 1))
        (sourceState g ((n + 1) - g) ((n + 1) - g)) := by
  rw [sourceState_step, nodeUpdate_from_three]
  have hp : (n + 1) - 1 = n := by omega
  rw [hp]
  rw [sourceState_at_completed g n (((n + 1) - g) - 1) (by omega)]
  rw [sourceState_at_completed g n ((n + 1) - g) (by omega)]

/-- Supply only already proved predecessor values. The right side still is the
original update arithmetic, not an observed value or a table literal. -/
private theorem source_node_from_values (g n : Nat) (hg : 0 < g)
    (p l r : Node)
    (hp : sourceState g n n = p)
    (hl : sourceState g (((n + 1) - g) - 1) (((n + 1) - g) - 1) = l)
    (hr : sourceState g ((n + 1) - g) ((n + 1) - g) = r) :
    sourceState g (n + 1) (n + 1) = nodeFromThree g (n + 1) p l r := by
  rw [source_node_recurrence g n hg, hp, hl, hr]

/-- This is the per-node interface for a fresh proof-producing evaluation:
harithmetic is checked separately and then composed by equality transitivity. -/
private theorem source_node_from_checked_step (g n : Nat) (hg : 0 < g)
    (p l r value : Node)
    (hp : sourceState g n n = p)
    (hl : sourceState g (((n + 1) - g) - 1) (((n + 1) - g) - 1) = l)
    (hr : sourceState g ((n + 1) - g) ((n + 1) - g) = r)
    (harithmetic : nodeFromThree g (n + 1) p l r = value) :
    sourceState g (n + 1) (n + 1) = value :=
  (source_node_from_values g n hg p l r hp hl hr).trans harithmetic

/-- The original constant-prefix branch supplies initial-node facts at every
needed index up to 2*g, including zero. -/
private theorem sourceState_constant_prefix (g b : Nat) :
    b ≤ 2 * g → sourceState g b = fun _ => initialNode := by
  induction b with
  | zero =>
      intro _
      rfl
  | succ b ih =>
      intro hb
      have hprevious := ih (by omega)
      funext i
      change (if i = b + 1 then nodeUpdate g (b + 1) (sourceState g b)
        else sourceState g b i) = initialNode
      by_cases hi : i = b + 1
      · rw [if_pos hi]
        simp only [nodeUpdate, if_pos hb]
      · rw [if_neg hi]
        exact congrFun hprevious i

private theorem sourceNode_initial (g i : Nat) (hi : i ≤ 2 * g) :
    sourceState g i i = initialNode :=
  congrFun (sourceState_constant_prefix g i hi) i

/-- Boundary information for nodes in the intended nonconstant Q80 prefix.
No division-by-two index or unproved reader substitution is involved. -/
private theorem predecessor_indices (g i : Nat) (hg : 0 < g) (hi : 2 * g < i) :
    i - 1 < i ∧ (i - g) - 1 < i ∧ i - g < i ∧
      (i - g) - 1 + 1 = i - g := by
  omega

private theorem q80_grid_positive : 0 < (16384 : Nat) := by decide

/-- A source-form specialization, not a closed numeric computation. -/
private theorem q80_node_from_values (n : Nat) (p l r : Node)
    (hp : sourceState 16384 n n = p)
    (hl : sourceState 16384 (((n + 1) - 16384) - 1) (((n + 1) - 16384) - 1) = l)
    (hr : sourceState 16384 ((n + 1) - 16384) ((n + 1) - 16384) = r) :
    sourceState 16384 (n + 1) (n + 1) =
      nodeFromThree 16384 (n + 1) p l r :=
  source_node_from_values 16384 n q80_grid_positive p l r hp hl hr

/-- Only the node at 10*g is transported to the full original 12*g table.
There is no claim that a shorter complete reader equals the full table. -/
private theorem sourceTable_from_d10 (value : Node)
    (h : sourceState 16384 (10 * 16384) (10 * 16384) = value) :
    sourceTable (10 * 16384) = value :=
  (sourceState_at_completed 16384 (12 * 16384) (10 * 16384) (by decide)).trans h


/-- Transport any completed query in range to the full unchanged source table. -/
private theorem sourceTable_from_node (i : Nat) (value : Node)
    (hi : i ≤ 12 * 16384) (h : sourceState 16384 i i = value) :
    sourceTable i = value :=
  (sourceState_at_completed 16384 (12 * 16384) i hi).trans h

private theorem query_positive_of_node (i : Nat) (value : Node)
    (h : sourceTable i = value) (hv : 0 < value.lh) :
    0 < (sourceTable i).lh := by
  rw [h]
  exact hv

open Lean Meta Elab Tactic

/-- Input and proof-batching parameters, never computed table outputs. -/
private def grid : Nat := 16384
private def constantPrefix : Nat := 2 * grid
private def firstIndex : Nat := constantPrefix + 1
private def blockDepth : Nat := 6
private def blockSize : Nat := 2 ^ blockDepth

/-- Temporary expressions used only while constructing checked equalities. -/
private structure NodeValue where
  index : Nat
  value : Expr

private structure NodeCertificate where
  index : Nat
  value : Expr
  proof : Expr

private structure BlockDraft where
  values : Array NodeValue
  proof : Expr

private def sourceNodeExpr (i : Nat) : Expr :=
  mkApp3 (mkConst ``sourceState) (mkNatLit grid) (mkNatLit i) (mkNatLit i)

/-- Recognize only a literal or its canonical Nat OfNat wrapper, without reduction. -/
private def isNatNormalForm (e : Expr) : Bool :=
  match e with
  | .lit (.natVal _) => true
  | .app (.app (.app (.const ofNatName _) (.const natName []))
      (.lit (.natVal n))) (.app (.const instName []) (.lit (.natVal m))) =>
      ofNatName == ``OfNat.ofNat && natName == ``Nat &&
        instName == ``instOfNatNat && n == m
  | _ => false

/-- Accept both Sym integer literals and exact Int constructors on recognized Nat values.
This checks syntax only; the cbv value and its equality proof are never rewritten. -/
private def isIntegerNormalForm (e : Expr) : Bool :=
  (Lean.Meta.Sym.getIntValue? e).isSome ||
    match e with
    | .app (.const ctor []) n =>
        (ctor == ``Int.ofNat || ctor == ``Int.negSucc) && isNatNormalForm n
    | _ => false

private def isNodeNormalForm (e : Expr) : Bool :=
  e.isAppOfArity ``ImbalancedChen.P2HistoricSieveTableSemantics.HistoricNode.mk 4 &&
    e.getAppArgs.all isIntegerNormalForm

/-- Direct offsets into contiguous arrays; there is no prefix scan. -/
private def lookupCertificate (committed working : Array NodeCertificate)
    (start i : Nat) : MetaM NodeCertificate := do
  if i ≤ constantPrefix then
    let hbound ← mkDecideProof (← Meta.mkLe (mkNatLit i) (mkNatLit constantPrefix))
    return ⟨i, mkConst ``initialNode,
      mkApp3 (mkConst ``sourceNode_initial) (mkNatLit grid) (mkNatLit i) hbound⟩
  if start ≤ i then
    let some cert := working[i - start]?
      | throwError "Missing current-block predecessor certificate at index {i}"
    unless cert.index == i do
      throwError "Current-block certificate index mismatch at {i}"
    return cert
  let some cert := committed[i - firstIndex]?
    | throwError "Missing checked predecessor certificate at index {i}"
  unless cert.index == i do
    throwError "Checked certificate index mismatch at {i}"
  return cert

private def evaluateNode (e : Expr) : MetaM (Expr × Expr) := do
  unless !e.hasFVar && !e.hasMVar do
    throwError "Q80 node arithmetic must be closed before cbvEntry"
  let result ← Lean.Meta.Tactic.Cbv.cbvEntry e
  match result with
  | .step value _ _ _ =>
      unless isNodeNormalForm value do
        let headName : Option Name := match value.getAppFn with
          | .const name _ => some name
          | _ => none
        let args := value.getAppArgs
        let intValues := args.map fun arg =>
          Id.run (OptionT.run (Lean.Meta.Sym.getIntValue? arg))
        let observed := value.consumeMData
        let observedHeadName : Option Name := match observed.getAppFn with
          | .const name _ => some name
          | _ => none
        let observedArgs := observed.getAppArgs
        let observedIntValues := observedArgs.map fun arg =>
          Id.run (OptionT.run (Lean.Meta.Sym.getIntValue? arg.consumeMData))
        throwError "cbvEntry did not return an original HistoricNode four-Int normal form\n\
          raw_value_expr={reprStr value}\n\
          expected_head={``ImbalancedChen.P2HistoricSieveTableSemantics.HistoricNode.mk}\n\
          raw_head_const={reprStr headName}\n\
          raw_args_size={args.size}\n\
          raw_field_int_values={reprStr intValues}\n\
          observed_consumeMData_expr={reprStr observed}\n\
          observed_head_const={reprStr observedHeadName}\n\
          observed_args_size={observedArgs.size}\n\
          observed_field_int_values={reprStr observedIntValues}"
      -- Compact-term experiment: retain the freshly evaluated value only.
      -- Eq.trans still requires arithmetic = value, so the whole-block
      -- synchronous kernel check must validate this conversion.
      return (value, ← mkEqRefl value)
  | .rfl _ _ =>
      throwError "cbvEntry made no progress on the Q80 node arithmetic formula"

/-- Direct Nat.rec avoids compiler-generated partial recursion declarations. -/
private def balancedFold (leaf : Nat → MetaM Expr)
    (combine : Expr → Expr → MetaM Expr) : Nat → Nat → MetaM Expr :=
  Nat.rec (motive := fun _ => Nat → MetaM Expr)
    leaf
    (fun depth next offset => do
      let left ← next offset
      let right ← next (offset + 2 ^ depth)
      combine left right)

private def blockFactType (values : Array NodeValue) : MetaM Expr := do
  unless values.size == blockSize do
    throwError "A Q80 block must contain exactly {blockSize} node facts"
  let facts ← values.mapM fun item => mkEq (sourceNodeExpr item.index) item.value
  balancedFold
    (fun offset => do
      let some fact := facts[offset]? | throwError "Missing block proposition at offset {offset}"
      return fact)
    (fun left right => pure (mkApp2 (mkConst ``And) left right)) blockDepth 0

private def blockFactProof (facts : Array NodeCertificate) : MetaM Expr := do
  unless facts.size == blockSize do
    throwError "A Q80 block proof must contain exactly {blockSize} node facts"
  balancedFold
    (fun offset => do
      let some fact := facts[offset]? | throwError "Missing block proof at offset {offset}"
      return fact.proof)
    (fun left right => mkAppM ``And.intro #[left, right]) blockDepth 0

private def draftBlock (committed : Array NodeCertificate) (start : Nat) :
    (remaining : Nat) → Array NodeCertificate → Array Expr → MetaM BlockDraft :=
  Nat.rec (motive := fun _ => Array NodeCertificate → Array Expr → MetaM BlockDraft)
    (fun working proofLets => do
      let proof ← blockFactProof working
      let proof ← mkLetFVars proofLets proof
        (usedLetOnly := false) (generalizeNondepLet := false)
      let values := working.map fun cert =>
        ({ index := cert.index, value := cert.value } : NodeValue)
      return ⟨values, proof⟩)
    (fun _ next working proofLets => do
      let i := start + working.size
      let p ← lookupCertificate committed working start (i - 1)
      let l ← lookupCertificate committed working start ((i - grid) - 1)
      let r ← lookupCertificate committed working start (i - grid)
      let arithmetic := mkApp5 (mkConst ``nodeFromThree)
        (mkNatLit grid) (mkNatLit i) p.value l.value r.value
      let (value, arithmeticProof) ← evaluateNode arithmetic
      let sourceProof := mkAppN (mkConst ``source_node_from_values)
        #[mkNatLit grid, mkNatLit (i - 1), mkConst ``q80_grid_positive,
          p.value, l.value, r.value, p.proof, l.proof, r.proof]
      let proof := mkApp6 (mkConst ``Eq.trans [.succ .zero]) (mkConst ``Node)
        (sourceNodeExpr i) arithmetic value sourceProof arithmeticProof
      let type ← mkEq (sourceNodeExpr i) value
      withLetDecl (Name.mkSimple s!"q80_node_fact_{i}") type proof fun h =>
        next (working.push ⟨i, value, h⟩) (proofLets.push h))

/-- Select a leaf in the balanced conjunction with logarithmic proof depth. -/
private def projectBalanced : Nat → Expr → Nat → MetaM Expr :=
  Nat.rec (motive := fun _ => Expr → Nat → MetaM Expr)
    (fun proof offset => do
      unless offset == 0 do
        throwError "Invalid balanced-block projection offset"
      return proof)
    (fun depth next proof offset => do
      let half := 2 ^ depth
      if offset < half then
        let left ← mkAppM ``And.left #[proof]
        next left offset
      else
        let right ← mkAppM ``And.right #[proof]
        next right (offset - half))

/-- Only synchronously accepted block facts enter the committed cache. -/
private def checkBlock (committed : Array NodeCertificate) (start : Nat) :
    MetaM (Array NodeCertificate × Name) := do
  unless start == firstIndex + committed.size do
    throwError "The next Q80 block is not contiguous with the checked cache"
  let saved ← Meta.saveState
  tryCatchRuntimeEx
    (do
      let draft ← draftBlock committed start blockSize #[] #[]
      let type ← blockFactType draft.values
      unless !type.hasFVar && !type.hasMVar && !draft.proof.hasFVar && !draft.proof.hasMVar do
        throwError "Q80 block theorem type or proof is not closed"
      let env ← getEnv
      if env.hasUnsafe type || env.hasUnsafe draft.proof then
        throwError "Refusing to submit an unsafe Q80 block theorem"
      let blockName ← withOptions (Elab.async.set · false) do
        mkAuxLemma [] type draft.proof (kind? := some `_q80NodeProofBlock)
      let info ← getConstInfo blockName
      unless isPrivateName blockName do
        throwError "Generated Q80 block theorem is not private"
      match info with
      | .thmInfo _ => pure ()
      | _ => throwError "Generated Q80 block is not a theorem declaration"
      if info.isUnsafe || info.isPartial || info.isAxiom then
        throwError "Generated Q80 block failed the declaration-safety boundary"
      let mut updated := committed
      for offset in [:blockSize] do
        let some item := draft.values[offset]?
          | throwError "Missing checked Q80 value at offset {offset}"
        let proof ← projectBalanced blockDepth (mkConst blockName) offset
        updated := updated.push ⟨item.index, item.value, proof⟩
      logInfo m!"P24_Q80_CHECKED_BLOCK name={blockName} start={start} count={blockSize}"
      return (updated, blockName))
    (fun ex => do
      saved.restore
      throw ex)

/-- Parameterized prefix generation; this diagnostic invokes it for 258 blocks only. -/
private def buildPrefixBlocks (count : Nat) : MetaM (Array NodeCertificate × Array Name) := do
  unless count * blockSize ≤ 8 * grid do
    throwError "Requested Q80 proof blocks exceed the d10 prefix"
  let mut committed : Array NodeCertificate := #[]
  let mut names : Array Name := #[]
  for block in [:count] do
    unless committed.size == block * blockSize do
      throwError "Checked Q80 cache size is not the expected contiguous prefix"
    let start := firstIndex + committed.size
    let (updated, name) ← checkBlock committed start
    committed := updated
    names := names.push name
  return (committed, names)

/-- Return a terminal sourceTable equality; never put this different proof type
back into the source-node cache. The value remains a temporary Expr. -/
private def makeSourceTableCertificate (committed : Array NodeCertificate)
    (query : Nat) : MetaM (Expr × Expr) := do
  let cert ← lookupCertificate committed #[] (firstIndex + committed.size) query
  let hi ← mkDecideProof (← Meta.mkLe (mkNatLit query) (mkNatLit (12 * grid)))
  let proof := mkAppN (mkConst ``sourceTable_from_node)
    #[mkNatLit query, cert.value, hi, cert.proof]
  return (cert.value, proof)

private def provePrefix258Blocks : TacticM Unit := withMainContext do
  let currentPrefix := (← getDeclNGen).namePrefix
  let privatePrefix := mkPrivateName (← getEnv) currentPrefix
  withDeclNameForAuxNaming privatePrefix do
    let (committed, names) ← buildPrefixBlocks 258
    unless committed.size == 16512 && names.size == 258 do
      throwError "Unexpected 258-block Q80 inventory"
    let query := constantPrefix + 16512
    let (value, sourceProof) ← makeSourceTableCertificate committed query
    let field := mkProj ``ImbalancedChen.P2HistoricSieveTableSemantics.HistoricNode 1 value
    let positive ← mkAppM ``LT.lt #[toExpr (0 : Int), field]
    let positivity ← mkFreshExprMVar positive
    let [decideGoal] ← positivity.mvarId!.applyConst ``of_decide_eq_true
      | throwError "Could not create the small Q80 prefix positivity goal"
    Lean.Meta.Tactic.Cbv.cbvDecideGoal decideGoal
    let positivity ← instantiateMVars positivity
    let proof := mkApp4 (mkConst ``query_positive_of_node)
      (mkNatLit query) value sourceProof positivity
    (← getMainGoal).assign proof
    replaceMainGoal []
    logInfo "P24_Q80_DONE checked_blocks=258 computed_nodes=16512 first_index=32769 last_index=49280"

theorem prefix_258_q80_blocks_positive :
    0 < (sourceTable (2 * 16384 + 16512)).lh := by
  run_tac provePrefix258Blocks

#print axioms nodeUpdate_from_three
#print axioms source_node_from_checked_step
#print axioms sourceTable_from_node
#print axioms prefix_258_q80_blocks_positive

end NodeStepProof

end P24Q80NodeProofBlocks

