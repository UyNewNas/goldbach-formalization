import ImbalancedChen.Part3ActualAllFrameOriginalResolventReduction
import ImbalancedChen.Part3GammaActualMinimalDefectVanishes
import ImbalancedChen.Part3ActualEigenOriginalFourierClassicalModes

/-! SOURCE ONLY / UNCOMPILED / ZERO FORMAL CREDIT.
TRANSITIVE DOTS API HOLD through unchanged a947/618afb and be3646/0f1f.
Nonzero eigenmodes of the CONSTRUCTED compact all-frame variational
resolvent are converted to eigenpairs of the ORIGINAL native Gamma
Maass graph. Cusp membership is an output of the actual variational form
lift, and original-resolvent equality is the proved analytic reduction.
Reality, positivity and the upper bound for mu follow from the actual
original positive self-adjoint contraction. Its reciprocal shift is the
real nonnegative Maass eigenvalue. The existing SAME-AE smooth original
eigenfunction/Fourier modeling is then applied to these spectral modes.
No cusp invariance, smooth eigenvector or original graph eigenpair is an
input. No finite-dimensionality, rapid bounds or K classification here.
-/
namespace ImbalancedChen.Part3.ActualVariationalCuspEigenmodeConversion20261026b
noncomputable section
open Set MeasureTheory Module End
open scoped MatrixGroups UpperHalfPlane
open Gamma0ActualSmoothQuotientCore20261025a Gamma0ActualEnergyCompletion20261025a
open Gamma0ActualMaassClosedOperator20261025a Gamma0ActualFriedrichsOperator20261025a
open Gamma0ActualWeakRieszResolvent20261025a GammaActualMinimalDefectVanishes20261026b
open ActualAllFrameCuspCompactEmbedding20261026b AllNormalizedCuspAnnihilator20261026b
open ActualAllFrameCompactVariationalResolvent20261026b
open ActualAllFrameVariationalEigenspaces20261026b
open ActualAllFrameOriginalResolventReduction20261026b
open Gamma0QuotientCellPushforward20261025a
open NormalizedCuspCompactFourierFubini20261026b
open ActualEigenOriginalFourierClassicalModes20261026b
open ActualEigenNormalizedSmoothFrame20261026b GammaActualEigenSmoothRepresentative20261026b
open CanonicalTensorHyperbolicLaplacianForm20261024z MaassWeakOperatorCore20261024zz

/-- The real parameter used in the ORIGINAL differential equation. -/
def variationalMaassEigenvalue (mu : ℂ) : ℝ := mu.re⁻¹-1

/-- The constructed form lift proves actual cusp membership, so the
analytic reduction gives an ORIGINAL resolvent eigenpair. -/
theorem variational_eigenvector_original_resolvent (N : ℕ) [NeZero N]
    (hN : 0 < N) {mu : ℂ} (hmu : mu ≠ 0) (f : QuotientL2 N)
    (hf : f ∈ eigenspace (actualAllFrameVariationalResolvent N hN).toLinearMap mu) :
    f ∈ allFrameCuspSubspace N hN ∧ actualGammaResolvent N f = mu • f := by
  have hcusp : f ∈ allFrameCuspSubspace N hN :=
    (nonzero_eigenspace_le_actual_cuspidal_form N hN hmu hf).2
  have hRf : actualAllFrameVariationalResolvent N hN f = mu • f :=
    mem_eigenspace_iff.mp hf
  rw [actual_constrained_resolvent_eq_original_on_cusp N hN f hcusp] at hRf
  exact ⟨hcusp,hRf⟩

/-- Reality and 0<mu<=1 are derived for the ACTUAL original resolvent,
after genuine cusp reduction. The vector is required to be nonzero;
membership of the zero vector in an eigenspace is never used spectrally. -/
theorem variational_eigenvalue_real_positive_le_one (N : ℕ) [NeZero N]
    (hN : 0 < N) {mu : ℂ} (hmu : mu ≠ 0) (f : QuotientL2 N) (hf0 : f ≠ 0)
    (hf : f ∈ eigenspace (actualAllFrameVariationalResolvent N hN).toLinearMap mu) :
    mu = (mu.re : ℂ) ∧ 0 < mu.re ∧ mu.re ≤ 1 := by
  have hRf := (variational_eigenvector_original_resolvent N hN hmu f hf).2
  have hconj : star mu = mu := by
    have hs := actualGammaResolvent_symmetric N f f
    rw [hRf,inner_smul_left,inner_smul_right] at hs
    exact mul_right_cancel₀ (inner_self_ne_zero.mpr hf0) hs
  have him : mu.im = 0 := by
    have hi := congrArg Complex.im hconj
    simp only [Complex.star_def,Complex.conj_im] at hi
    linarith
  have hreal : mu = (mu.re : ℂ) := by
    apply Complex.ext <;> simp [him]
  have hquad : (inner ℂ f (actualGammaResolvent N f)).re = mu.re*‖f‖^2 := by
    rw [hRf,inner_smul_right,inner_self_eq_norm_sq_to_K]
    simp [Complex.mul_re]
  have hsq : 0 < ‖f‖^2 := sq_pos_of_pos (norm_pos_iff.mpr hf0)
  have hnonneg : 0 ≤ mu.re := by
    apply (mul_nonneg_iff_of_pos_right hsq).mp
    rw [← hquad]
    exact actualGammaResolvent_positive N f
  have hne : mu.re ≠ 0 := by
    intro hz
    apply hmu
    rw [hreal,hz,Complex.ofReal_zero]
  have hpos : 0 < mu.re := lt_of_le_of_ne hnonneg hne.symm
  have hnorm : ‖mu‖ ≤ 1 := by
    have hb := actualGammaResolvent_norm_le N f
    rw [hRf,norm_smul] at hb
    exact (mul_le_mul_right (norm_pos_iff.mpr hf0)).mp (by simpa using hb)
  exact ⟨hreal,hpos,(Complex.re_le_norm mu).trans hnorm⟩

theorem variationalMaassEigenvalue_nonneg (N : ℕ) [NeZero N]
    (hN : 0 < N) {mu : ℂ} (hmu : mu ≠ 0) (f : QuotientL2 N) (hf0 : f ≠ 0)
    (hf : f ∈ eigenspace (actualAllFrameVariationalResolvent N hN).toLinearMap mu) :
    0 ≤ variationalMaassEigenvalue mu := by
  obtain ⟨hreal,hpos,hle⟩ := variational_eigenvalue_real_positive_le_one N hN hmu f hf0 hf
  exact sub_nonneg.mpr ((one_le_inv₀ hpos).mpr hle)

/-- The exact native graph follows from R(f+lambda*f)=f and the proved
equality of the ORIGINAL minimal closure with its Friedrichs operator. -/
theorem variational_eigenvector_original_maass_graph (N : ℕ) [NeZero N]
    (hN : 0 < N) {mu : ℂ} (hmu : mu ≠ 0) (f : QuotientL2 N) (hf0 : f ≠ 0)
    (hf : f ∈ eigenspace (actualAllFrameVariationalResolvent N hN).toLinearMap mu) :
    (f,(variationalMaassEigenvalue mu : ℂ) • f) ∈ (actualClosedGammaMaass N).graph := by
  have hRf := (variational_eigenvector_original_resolvent N hN hmu f hf).2
  have hreal := (variational_eigenvalue_real_positive_le_one N hN hmu f hf0 hf).1
  have hlambda : (variationalMaassEigenvalue mu : ℂ) = mu⁻¹-1 := by
    simp only [variationalMaassEigenvalue,Complex.ofReal_sub,Complex.ofReal_inv,
      Complex.ofReal_one,← hreal]
  rw [actual_minimal_closure_eq_friedrichs N,actualGammaFriedrichs_mem_graph_iff N]
  have hsum : f + (variationalMaassEigenvalue mu : ℂ) • f = mu⁻¹ • f := by
    rw [hlambda]
    calc
      _ = (1 : ℂ) • f + (mu⁻¹-1) • f := by rw [one_smul]
      _ = (1+(mu⁻¹-1) : ℂ) • f := (add_smul _ _ _).symm
      _ = _ := by congr 1; ring
  rw [hsum,map_smul,hRf,smul_smul,inv_mul_cancel₀ hmu,one_smul]

/-- Full spectral-to-original-classical conversion. All hypotheses refer
to the CONSTRUCTED actual compact variational resolvent. The conclusion
uses the ORIGINAL quotient graph and ORIGINAL frameFourier f. -/
theorem actual_variational_cusp_eigenmode_has_original_classical_modes
    (N : ℕ) [NeZero N] (hN : 0 < N) {mu : ℂ} (hmu : mu ≠ 0)
    (f : QuotientL2 N) (hf0 : f ≠ 0)
    (hf : f ∈ eigenspace (actualAllFrameVariationalResolvent N hN).toLinearMap mu) :
    mu = (mu.re : ℂ) ∧ 0 < mu.re ∧ mu.re ≤ 1 ∧
      0 ≤ variationalMaassEigenvalue mu ∧ f ∈ allFrameCuspSubspace N hN ∧
      ((f,(variationalMaassEigenvalue mu : ℂ) • f) ∈ (actualClosedGammaMaass N).graph) ∧
      ∃ Phi : UpperHalfPlane → ℂ,
        ContDiffOn ℝ ∞ (extendUpper Phi) upperChart ∧
        (Phi =ᵐ[(volume : Measure UpperHalfPlane)] fun z => f (orbitProjection N z)) ∧
        GammaSmoothMultiplierPeriodization20261026a.IsGammaInvariant N Phi ∧
        (∀ z : UpperHalfPlane,
          upperMaass Phi z = (variationalMaassEigenvalue mu : ℂ)*Phi z) ∧
        ∀ g : SL(2, ℤ),
          (∀ n : ℤ, ContDiffOn ℝ 2 (classicalFrameMode N g Phi n) (Ioi (0 : ℝ)) ∧
            ∀ y, 0 < y →
              -deriv (deriv (classicalFrameMode N g Phi n)) y +
                (((2*Real.pi*(n : ℝ) : ℝ) : ℂ)^2)*classicalFrameMode N g Phi n y =
              ((variationalMaassEigenvalue mu : ℂ)/(y : ℂ)^2)*classicalFrameMode N g Phi n y) ∧
          (∀ᵐ y ∂((volume : Measure ℝ).restrict (Ioi (0 : ℝ))), ∀ n : ℤ,
            classicalFrameMode N g Phi n y = frameFourier N hN g f n y) := by
  obtain ⟨hreal,hpos,hle⟩ := variational_eigenvalue_real_positive_le_one N hN hmu f hf0 hf
  have hgraph := variational_eigenvector_original_maass_graph N hN hmu f hf0 hf
  obtain ⟨Phi,hPhi,hAE,hGamma,hPDE⟩ := actual_native_eigen_has_smooth_upper_representative
    N (variationalMaassEigenvalue mu) f hgraph
  refine ⟨hreal,hpos,hle,variationalMaassEigenvalue_nonneg N hN hmu f hf0 hf,
    (variational_eigenvector_original_resolvent N hN hmu f hf).1,hgraph,
    Phi,hPhi,hAE,hGamma,hPDE,?_⟩
  intro g
  exact ⟨fun n => classicalFrameMode_C2_and_ode N g Phi
    (smoothFrame_contDiffOn N hN g Phi hPhi)
    (fun y hy => smoothFrame_period_one N hN g Phi hGamma y hy)
    (variationalMaassEigenvalue mu)
    (fun p hp => smoothFrame_maass N hN g Phi hPhi (variationalMaassEigenvalue mu) hPDE hp) n,
    classicalFrameModes_ae_original N hN g Phi f hAE⟩

end
end ImbalancedChen.Part3.ActualVariationalCuspEigenmodeConversion20261026b
