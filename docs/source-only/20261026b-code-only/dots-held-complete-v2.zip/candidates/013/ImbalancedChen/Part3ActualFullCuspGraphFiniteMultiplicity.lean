import ImbalancedChen.Part3ActualFullCuspFriedrichs
import Mathlib.Analysis.Normed.Module.FiniteDimension

/-! SOURCE ONLY / UNCOMPILED / ZERO FORMAL CREDIT.
TRANSITIVE DOTS HOLD: immutable analytic1a3/be3646 and mean0f1f chain.
EVERY complex graph-eigenspace of the native FULL original cusp operator
is finite-dimensional. Closedness comes from the actual native operator
graph. Its unit ball lies in the actual compact R_C image of a bounded
ball, since the EXACT graph equation reconstructs u as R_C(u+lambda*u).
Riesz' compact-ball theorem then proves finite dimension. No spectral
eigenvalue conversion, eigenspan density, finite multiplicity premise,
full-L2 spectral expansion or Eisenstein completeness is assumed. -/

namespace ImbalancedChen.Part3.ActualFullCuspGraphFiniteMultiplicity20261026b
noncomputable section
open Set Metric
open Gamma0ActualSmoothQuotientCore20261025a Gamma0ActualFriedrichsOperator20261025a
open ActualFullCuspResolvent20261026b ActualFullCuspCompactResolvent20261026b
open ActualFullCuspFriedrichs20261026b

def actualFullCuspEigenGraphMap (N : ℕ) [NeZero N] (hN : 0 < N) (λ : ℂ) :
    ActualFullCuspL2 N hN →L[ℂ] ActualFullCuspL2 N hN × ActualFullCuspL2 N hN :=
  (ContinuousLinearMap.id ℂ (ActualFullCuspL2 N hN)).prod
    (λ • ContinuousLinearMap.id ℂ (ActualFullCuspL2 N hN))

/-- Actual native graph eigenvectors, including zero, as a submodule of
the FULL original all-frame cusp Hilbert space. -/
def actualFullCuspGraphEigenspace (N : ℕ) [NeZero N] (hN : 0 < N) (λ : ℂ) :
    Submodule ℂ (ActualFullCuspL2 N hN) :=
  (actualFullCuspFriedrichs N hN).graph.comap (actualFullCuspEigenGraphMap N hN λ).toLinearMap

theorem mem_actualFullCuspGraphEigenspace_iff (N : ℕ) [NeZero N] (hN : 0 < N)
    (λ : ℂ) (u : ActualFullCuspL2 N hN) :
    u ∈ actualFullCuspGraphEigenspace N hN λ ↔
      (u,λ • u) ∈ (actualFullCuspFriedrichs N hN).graph := Iff.rfl

/-- The finite-dimensional spaces below are literal ORIGINAL Gamma
graph eigenspaces inside the actual cusp space, not surrogate spectra. -/
theorem mem_actualFullCuspGraphEigenspace_iff_original (N : ℕ) [NeZero N] (hN : 0 < N)
    (λ : ℂ) (u : ActualFullCuspL2 N hN) :
    u ∈ actualFullCuspGraphEigenspace N hN λ ↔
      ((u : QuotientL2 N),λ • (u : QuotientL2 N)) ∈ (actualGammaFriedrichs N).graph :=
  actualFullCuspFriedrichs_graph_iff_original N hN

theorem actualFullCuspGraphEigenspace_closed (N : ℕ) [NeZero N] (hN : 0 < N) (λ : ℂ) :
    IsClosed (actualFullCuspGraphEigenspace N hN λ : Set (ActualFullCuspL2 N hN)) := by
  have hg : IsClosed ((actualFullCuspFriedrichs N hN).graph :
      Set (ActualFullCuspL2 N hN × ActualFullCuspL2 N hN)) := actualFullCuspFriedrichs_isClosed N hN
  exact hg.preimage (actualFullCuspEigenGraphMap N hN λ).continuous

/-- Compact-resolvent finite multiplicity by the actual compact-ball
argument. There is no excluded lambda and no eigenvalue conversion input. -/
theorem actualFullCuspGraphEigenspace_finiteDimensional (N : ℕ) [NeZero N]
    (hN : 0 < N) (λ : ℂ) : FiniteDimensional ℂ (actualFullCuspGraphEigenspace N hN λ) := by
  let H := ActualFullCuspL2 N hN
  let E := actualFullCuspGraphEigenspace N hN λ
  let M : ℝ := 1+‖λ‖
  have hM : 0 < M := by dsimp [M]; linarith [norm_nonneg λ]
  have hK : IsCompact (closure (actualFullCuspResolvent N hN '' closedBall (0 : H) M)) :=
    (isCompactOperator_iff_isCompact_closure_image_closedBall
      (actualFullCuspResolvent N hN).toLinearMap hM).mp (actualFullCuspResolvent_isCompactOperator N hN)
  have himage : ((↑) '' closedBall (0 : E) 1 : Set H) = (E : Set H) ∩ closedBall (0 : H) 1 := by
    ext u
    constructor
    · rintro ⟨v,hv,rfl⟩
      exact ⟨v.property,by simpa only [mem_closedBall,dist_zero_right] using hv⟩
    · rintro ⟨hu,hball⟩
      refine ⟨⟨u,hu⟩,?_,rfl⟩
      simpa only [mem_closedBall,dist_zero_right] using hball
  have hclosed : IsClosed ((↑) '' closedBall (0 : E) 1 : Set H) := by
    rw [himage]
    exact (actualFullCuspGraphEigenspace_closed N hN λ).inter isClosed_closedBall
  have hsub : ((↑) '' closedBall (0 : E) 1 : Set H) ⊆
      closure (actualFullCuspResolvent N hN '' closedBall (0 : H) M) := by
    rintro u ⟨v,hv,rfl⟩
    have hvnorm : ‖v‖ ≤ 1 := by simpa only [mem_closedBall,dist_zero_right] using hv
    apply subset_closure
    refine ⟨(v : H)+λ • (v : H),?_,?_⟩
    · rw [mem_closedBall,dist_zero_right]
      calc
        _ ≤ ‖(v : H)‖+‖λ • (v : H)‖ := norm_add_le _ _
        _ = ‖v‖+‖λ‖*‖v‖ := by rw [norm_smul]; rfl
        _ ≤ 1+‖λ‖*1 := add_le_add hvnorm (mul_le_mul_of_nonneg_left hvnorm (norm_nonneg λ))
        _ = M := by dsimp [M]; ring
    · have heig : ((v : H),λ • (v : H)) ∈ (actualFullCuspFriedrichs N hN).graph := v.property
      exact (actualFullCuspFriedrichs_mem_graph_iff N hN).mp heig
  have hc : IsCompact ((↑) '' closedBall (0 : E) 1 : Set H) := hK.of_isClosed_subset hclosed hsub
  apply FiniteDimensional.of_isCompact_closedBall₀ ℂ (by norm_num : (0 : ℝ)<1)
  exact Subtype.isCompact_iff.mpr hc

end
end ImbalancedChen.Part3.ActualFullCuspGraphFiniteMultiplicity20261026b
