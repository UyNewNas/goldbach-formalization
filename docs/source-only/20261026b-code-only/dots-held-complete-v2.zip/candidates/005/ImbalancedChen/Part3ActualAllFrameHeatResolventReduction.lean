import ImbalancedChen.Part3ActualAllFrameOriginalResolventReduction
import ImbalancedChen.Part3ActualAllFrameGlobalMeanZero
import ImbalancedChen.Part3Gamma0ActualSigmaHeatResolvent
import Mathlib.Analysis.CStarAlgebra.ContinuousFunctionalCalculus.Commute

/-!
SOURCE ONLY / UNCOMPILED / ZERO FORMAL CREDIT.
TRANSITIVE DOTS API HOLD through existing be3646/0f1f suppliers.

The ORIGINAL Gamma heat and shifted resolvents preserve BOTH actual
all-frame cusp and orthogonal-complement subspaces. Actual projection
commutation follows from the ORIGINAL R commutation and the native CFC;
no heat-invariance or spectral-gap hypothesis is supplied. The actual
cuspidal heat semigroup is defined on the entire genuine cusp space and
converges strongly to zero by the proved global-mean exclusion and scalar
DCT result. No numerical/uniform gap or decay rate is claimed.
-/
namespace ImbalancedChen.Part3.ActualAllFrameHeatResolventReduction20261026b
noncomputable section
open Set Filter
open scoped Topology
open Gamma0ActualSmoothQuotientCore20261025a Gamma0ActualWeakRieszResolvent20261025a
open Gamma0ActualHeatGenerator20261025a Gamma0ActualShiftedFriedrichsResolvent20261025a
open GenericPositiveResolventHeat20261025a PositiveContractionResolventCalculus20261025a
open AllNormalizedCuspAnnihilator20261026b ActualAllFrameOriginalResolventReduction20261026b
open ActualAllFrameGlobalMeanZero20261026b

private theorem original_R_commute_projection (N : ℕ) [NeZero N] (hN : 0 < N) :
    Commute (actualGammaResolvent N) (actualAllFrameCuspProjection N hN) := by
  change (actualGammaResolvent N).comp (actualAllFrameCuspProjection N hN) =
    (actualAllFrameCuspProjection N hN).comp (actualGammaResolvent N)
  exact actualGammaResolvent_commutes_cuspProjection N hN

/-- The full real continuous functional calculus of the ORIGINAL R
commutes with the genuine physical cusp projection. -/
theorem actual_real_cfc_commutes_cuspProjection (N : ℕ) [NeZero N] (hN : 0 < N)
    (φ : C(spectrum ℝ (actualGammaResolvent N), ℝ)) :
    (cfcHom (actualGammaResolvent_selfAdjoint N) φ).comp
        (actualAllFrameCuspProjection N hN) =
      (actualAllFrameCuspProjection N hN).comp
        (cfcHom (actualGammaResolvent_selfAdjoint N) φ) := by
  change Commute (cfcHom (actualGammaResolvent_selfAdjoint N) φ)
    (actualAllFrameCuspProjection N hN)
  exact IsSelfAdjoint.commute_cfcHom (actualGammaResolvent_selfAdjoint N)
    (actualGammaResolvent_selfAdjoint N) (original_R_commute_projection N hN) φ

private theorem maps_cusp_of_projection_commutation (N : ℕ) [NeZero N] (hN : 0 < N)
    (T : QuotientL2 N →L[ℂ] QuotientL2 N)
    (hT : T.comp (actualAllFrameCuspProjection N hN) =
      (actualAllFrameCuspProjection N hN).comp T)
    (f : QuotientL2 N) (hf : f ∈ allFrameCuspSubspace N hN) :
    T f ∈ allFrameCuspSubspace N hN := by
  have hp : actualAllFrameCuspProjection N hN f = f :=
    Submodule.starProjection_eq_self_iff.mpr hf
  have h := congrArg (fun S : QuotientL2 N →L[ℂ] QuotientL2 N => S f) hT
  change T (actualAllFrameCuspProjection N hN f) = actualAllFrameCuspProjection N hN (T f) at h
  rw [hp] at h
  exact Submodule.starProjection_eq_self_iff.mp h.symm

private theorem maps_orthogonal_of_projection_commutation (N : ℕ) [NeZero N] (hN : 0 < N)
    (T : QuotientL2 N →L[ℂ] QuotientL2 N)
    (hT : T.comp (actualAllFrameCuspProjection N hN) =
      (actualAllFrameCuspProjection N hN).comp T)
    (f : QuotientL2 N) (hf : f ∈ (allFrameCuspSubspace N hN)ᗮ) :
    T f ∈ (allFrameCuspSubspace N hN)ᗮ := by
  have hk : (actualAllFrameCuspProjection N hN).ker = (allFrameCuspSubspace N hN)ᗮ :=
    Submodule.ker_starProjection _
  rw [← hk] at hf ⊢
  change actualAllFrameCuspProjection N hN f = 0 at hf
  change actualAllFrameCuspProjection N hN (T f) = 0
  have h := congrArg (fun S : QuotientL2 N →L[ℂ] QuotientL2 N => S f) hT
  change T (actualAllFrameCuspProjection N hN f) = actualAllFrameCuspProjection N hN (T f) at h
  rw [hf, map_zero] at h
  exact h.symm

theorem actualGammaHeat_commutes_allFrameProjection (N : ℕ) [NeZero N]
    (hN : 0 < N) (t : ℝ) :
    (actualGammaHeat N t).comp (actualAllFrameCuspProjection N hN) =
      (actualAllFrameCuspProjection N hN).comp (actualGammaHeat N t) := by
  change (cfcHom (actualGammaResolvent_selfAdjoint N)
      (heatScalar (actualGammaHeatData N) t)).comp (actualAllFrameCuspProjection N hN) =
    (actualAllFrameCuspProjection N hN).comp
      (cfcHom (actualGammaResolvent_selfAdjoint N) (heatScalar (actualGammaHeatData N) t))
  exact actual_real_cfc_commutes_cuspProjection N hN _

theorem actualGammaHeat_allFrame_invariant (N : ℕ) [NeZero N] (hN : 0 < N)
    (t : ℝ) (f : QuotientL2 N) (hf : f ∈ allFrameCuspSubspace N hN) :
    actualGammaHeat N t f ∈ allFrameCuspSubspace N hN :=
  maps_cusp_of_projection_commutation N hN _ (actualGammaHeat_commutes_allFrameProjection N hN t) f hf

theorem actualGammaHeat_allFrame_orthogonal_invariant (N : ℕ) [NeZero N] (hN : 0 < N)
    (t : ℝ) (f : QuotientL2 N) (hf : f ∈ (allFrameCuspSubspace N hN)ᗮ) :
    actualGammaHeat N t f ∈ (allFrameCuspSubspace N hN)ᗮ :=
  maps_orthogonal_of_projection_commutation N hN _
    (actualGammaHeat_commutes_allFrameProjection N hN t) f hf

theorem actualGammaShiftedResolvent_commutes_allFrameProjection (N : ℕ) [NeZero N]
    (hN : 0 < N) (a : ℝ) :
    (actualGammaShiftedResolvent N a).comp (actualAllFrameCuspProjection N hN) =
      (actualAllFrameCuspProjection N hN).comp (actualGammaShiftedResolvent N a) := by
  change Commute (cfc (resolventRatio a) (actualGammaResolvent N))
    (actualAllFrameCuspProjection N hN)
  exact (original_R_commute_projection N hN).cfc_real (resolventRatio a)

theorem actualGammaShiftedResolvent_allFrame_invariant (N : ℕ) [NeZero N]
    (hN : 0 < N) (a : ℝ) (f : QuotientL2 N) (hf : f ∈ allFrameCuspSubspace N hN) :
    actualGammaShiftedResolvent N a f ∈ allFrameCuspSubspace N hN :=
  maps_cusp_of_projection_commutation N hN _
    (actualGammaShiftedResolvent_commutes_allFrameProjection N hN a) f hf

theorem actualGammaShiftedResolvent_allFrame_orthogonal_invariant (N : ℕ) [NeZero N]
    (hN : 0 < N) (a : ℝ) (f : QuotientL2 N) (hf : f ∈ (allFrameCuspSubspace N hN)ᗮ) :
    actualGammaShiftedResolvent N a f ∈ (allFrameCuspSubspace N hN)ᗮ :=
  maps_orthogonal_of_projection_commutation N hN _
    (actualGammaShiftedResolvent_commutes_allFrameProjection N hN a) f hf

def actualFullCuspHeat (N : ℕ) [NeZero N] (hN : 0 < N) (t : ℝ) :
    allFrameCuspSubspace N hN →L[ℂ] allFrameCuspSubspace N hN :=
  (actualGammaHeat N t).restrict (actualGammaHeat_allFrame_invariant N hN t)

theorem actualFullCuspHeat_tendsto_zero (N : ℕ) [NeZero N] (hN : 0 < N)
    (f : allFrameCuspSubspace N hN) :
    Tendsto (fun t : ℝ => actualFullCuspHeat N hN t f) atTop (𝓝 0) := by
  apply tendsto_iff_norm_sub_tendsto_zero.2
  have h := tendsto_iff_norm_sub_tendsto_zero.1
    (actualGammaHeat_allFrame_tendsto_zero N hN f.property)
  simpa only [sub_zero] using h

end
end ImbalancedChen.Part3.ActualAllFrameHeatResolventReduction20261026b
