import ImbalancedChen.Part3ActualFrameMeanNormalizedAdmissibility
import ImbalancedChen.Part3AllFrameResolventMeanWeakEuler
import ImbalancedChen.Part3NormalizedCuspFourierHeightL2
import ImbalancedChen.Part3PhysicalHeightTailMeasureBridge

/-!
SOURCE ONLY / UNCOMPILED / ZERO FORMAL CREDIT / TRANSITIVE DOTS HOLD.

The ORIGINAL native quotient resolvent preserves the ORIGINAL closed
annihilator of all normalized rational-frame zero seeds. For each actual
resolvent input in that annihilator, genuine weak Euler regularity produces
a SAME-AE classical mean. Its high-height L2 follows from the actual
quotient spatial coefficient transport; its small-scale averaged bound
follows from the actual framed orbit count. The derived scalar uniqueness
then kills every actual frame mean. No resolvent invariance, mean ODE,
regularity, endpoint estimate, or spectral completeness is a premise.

The immutable first-weak be3646 and high-cylinder Fourier0f1f API holds
remain explicit transitive dependencies. This source does not repair or
bypass those suppliers and is not ready for installation while held.
-/
namespace ImbalancedChen.Part3.ActualAllFrameResolventInvariance20261026b
noncomputable section
open Set Filter MeasureTheory Matrix
open scoped MatrixGroups UpperHalfPlane
open CuspCylinderMeasure20261024z Gamma0GeneralCuspWidth20261025a
open ActualInfinityCuspAnnihilator20261026b AllNormalizedCuspAnnihilator20261026b
open Gamma0ActualEnergyCompletion20261025a Gamma0ActualWeakRieszResolvent20261025a
open AllFrameCompletedMeanDerivative20261026b AllFrameResolventMeanWeakEuler20261026b
open WeakEulerClassicalPair20261026b NormalizedCuspCompactFourierFubini20261026b
open NormalizedCuspFourierHeightL220261026b PhysicalHeightTailMeasureBridge20261026b
open ActualFrameMeanNormalizedAdmissibility20261026b
open ShiftOneEulerFixedNormalizedTest20261026b ShiftOneEulerSmallThresholdTestUniqueness20261026b

/-- Every actual normalized-frame resolvent mean has a derived classical
representative which vanishes on the ENTIRE positive half-line. -/
theorem actual_allFrame_resolvent_classical_mean_zero (N : ℕ) [NeZero N]
    (hN : 0 < N) (g : SL(2, ℤ)) (f : QuotientL2 N)
    (hf : f ∈ allFrameCuspSubspace N hN) :
    ∃ p : ClassicalWeakEulerPair 0
      (actualFrameFormMean N hN g (actualRieszLift N f))
      (actualFrameGradientMean N hN g (actualRieszLift N f)),
      ∀ y : ℝ, 0 < y → p.mean y = 0 := by
  obtain ⟨p⟩ := actual_allFrame_resolvent_nonempty_classical_mean_pair N hN g f hf
  have hmean : ∀ᵐ y : ℝ, 0 < y →
      frameFourier N hN g (actualGammaResolvent N f) 0 y = p.mean y := by
    simpa only [actualFrameFormMean, ← actualGammaResolvent_apply] using p.mean_ae
  have hheight := real_positive_volume_ae_eq_height hmean
  have hnative := actual_frameFourier_memLp_high_height N hN g
    (Y := (2 : ℝ)) (by norm_num) (actualGammaResolvent N f) 0
  have hclassTail : MemLp (fun y : PositiveHeight => p.mean y) 2
      (heightMeasure.restrict {y : PositiveHeight | (2 : ℝ) ≤ (y : ℝ)}) := by
    exact hnative.congr (ae_restrict_of_ae hheight)
  have htail := native_closed_height_tail_to_physicalTail p.mean p.mean_C2.continuousOn
    (2 : ℝ) (by norm_num) hclassTail
  have hbound := sameAE_actual_frame_mean_fixedTest_bound_below N hN g
    (actualGammaResolvent N f) p.mean hheight.symm
  have hw : (0 : ℝ) < (cuspWidth N g : ℝ) := by exact_mod_cast cuspWidth_pos N hN g
  refine ⟨p, ?_⟩
  exact shiftOneEuler_fixedTest_below_unique p.mean p.mean_C2
    (fun y hy => p.mean_second_derivative y hy) htail
    (1 / (cuspWidth N g : ℝ)) (one_div_pos.mpr hw)
    (actualFrameMeanTestConstant N g (actualGammaResolvent N f) fixedOriginalHeightSeed) hbound

/-- Analytic primitive: the ORIGINAL R=(I+A)^-1 preserves the ORIGINAL
all-frame cusp annihilator. No alternate constrained resolvent occurs. -/
theorem actualGammaResolvent_mem_allFrameCuspSubspace (N : ℕ) [NeZero N]
    (hN : 0 < N) (f : QuotientL2 N) (hf : f ∈ allFrameCuspSubspace N hN) :
    actualGammaResolvent N f ∈ allFrameCuspSubspace N hN := by
  apply (actualL2_mem_allFrame_iff_allFrameAEZero N hN (actualGammaResolvent N f)).mpr
  intro g
  obtain ⟨p, hp⟩ := actual_allFrame_resolvent_classical_mean_zero N hN g f hf
  have hmean : ∀ᵐ y : ℝ, 0 < y →
      frameFourier N hN g (actualGammaResolvent N f) 0 y = p.mean y := by
    simpa only [actualFrameFormMean, ← actualGammaResolvent_apply] using p.mean_ae
  filter_upwards [hmean] with y hy
  intro hypos
  exact (hy hypos).trans (hp y hypos)

theorem actualGammaResolvent_allFrame_zeroSeed_tests (N : ℕ) [NeZero N]
    (hN : 0 < N) (f : QuotientL2 N) (hf : f ∈ allFrameCuspSubspace N hN)
    (g : SL(2, ℤ)) (s : HeightSeed) :
    inner ℂ (frameZeroSeedL2 N hN g s) (actualGammaResolvent N f) = 0 :=
  (mem_allFrameCuspSubspace_iff N hN (actualGammaResolvent N f)).mp
    (actualGammaResolvent_mem_allFrameCuspSubspace N hN f hf) g s

end
end ImbalancedChen.Part3.ActualAllFrameResolventInvariance20261026b
