import ImbalancedChen.Part3ActualAllFrameEnergyImageSpectralSplit
import ImbalancedChen.Part3Gamma0ActualWeakRieszResolvent
import ImbalancedChen.Part3ActualAllFrameResolventInvariance

/-!
SOURCE ONLY / UNCOMPILED / ZERO FORMAL CREDIT.
TRANSITIVE DOTS API HOLD through existing be3646/0f1f suppliers.
The actual analytic ALL-frame original-resolvent invariance theorem is
consumed unchanged. Original self-adjointness supplies complementary
invariance and actual orthogonal-projection commutation. Riesz uniqueness
identifies the compact constrained resolvent with ORIGINAL R times the
actual cusp projection; no invariance or reduction statement is a premise.
-/
namespace ImbalancedChen.Part3.ActualAllFrameOriginalResolventReduction20261026b
noncomputable section
open Set
open Gamma0ActualSmoothQuotientCore20261025a Gamma0ActualEnergyCompletion20261025a
open Gamma0ActualWeakRieszResolvent20261025a
open ActualAllFrameCuspCompactEmbedding20261026b AllNormalizedCuspAnnihilator20261026b
open ActualAllFrameCompactVariationalResolvent20261026b GenericHilbertAdjointSquare20261025a
open ActualAllFrameEnergyImageSpectralSplit20261026b
open ActualAllFrameResolventInvariance20261026b

instance actualAllFrameCusp_complete (N : ℕ) [NeZero N] (hN : 0 < N) :
    CompleteSpace (allFrameCuspSubspace N hN) :=
  (allFrameCuspSubspace_closed N hN).completeSpace_coe

def actualAllFrameCuspProjection (N : ℕ) [NeZero N] (hN : 0 < N) :
    QuotientL2 N →L[ℂ] QuotientL2 N :=
  (allFrameCuspSubspace N hN).starProjection

theorem actualAllFrameCuspProjection_range (N : ℕ) [NeZero N] (hN : 0 < N) :
    (actualAllFrameCuspProjection N hN).range = allFrameCuspSubspace N hN :=
  Submodule.range_starProjection _

theorem actualAllFrameCuspProjection_selfAdjoint (N : ℕ) [NeZero N] (hN : 0 < N) :
    IsSelfAdjoint (actualAllFrameCuspProjection N hN) :=
  isSelfAdjoint_starProjection (allFrameCuspSubspace N hN)

private theorem constrained_resolvent_eq_original_of_output_mem
    (N : ℕ) [NeZero N] (hN : 0 < N) (f : QuotientL2 N)
    (houtput : actualGammaResolvent N f ∈ allFrameCuspSubspace N hN) :
    actualAllFrameVariationalResolvent N hN f = actualGammaResolvent N f := by
  let e : actualAllFrameEnergySubspace N hN := ⟨actualRieszLift N f, houtput⟩
  have he : e = actualAllFrameRieszLift N hN f := by
    apply rieszLift_weak_unique (actualAllFrameInclusion N hN) f e
    intro d
    change inner ℂ (d : EnergyCompletion N) (actualRieszLift N f) =
      inner ℂ (physicalProjection N (d : EnergyCompletion N)) f
    exact actualRieszLift_weak N f (d : EnergyCompletion N)
  change actualAllFrameInclusion N hN (actualAllFrameRieszLift N hN f) =
    physicalProjection N (actualRieszLift N f)
  rw [← he]
  rfl

/-- The ACTUAL complementary space is invariant, by original
self-adjointness and the proved analytic cusp invariance. -/
theorem actualGammaResolvent_mem_allFrame_orthogonal (N : ℕ) [NeZero N]
    (hN : 0 < N) (f : QuotientL2 N) (hf : f ∈ (allFrameCuspSubspace N hN)ᗮ) :
    actualGammaResolvent N f ∈ (allFrameCuspSubspace N hN)ᗮ := by
  intro v hv
  rw [← actualGammaResolvent_symmetric N v f]
  exact hf _ (actualGammaResolvent_mem_allFrameCuspSubspace N hN v hv)

/-- Genuine ORIGINAL resolvent commutation with the actual cusp
projection, derived after the endpoint argument rather than assumed. -/
theorem actualGammaResolvent_commutes_cuspProjection (N : ℕ) [NeZero N] (hN : 0 < N) :
    (actualGammaResolvent N).comp (actualAllFrameCuspProjection N hN) =
      (actualAllFrameCuspProjection N hN).comp (actualGammaResolvent N) := by
  ext f
  change actualGammaResolvent N ((allFrameCuspSubspace N hN).starProjection f) =
    (allFrameCuspSubspace N hN).starProjection (actualGammaResolvent N f)
  symm
  apply (allFrameCuspSubspace N hN).eq_starProjection_of_mem_orthogonal
    (actualGammaResolvent_mem_allFrameCuspSubspace N hN _
      ((allFrameCuspSubspace N hN).starProjection_apply_mem f))
  rw [← map_sub]
  exact actualGammaResolvent_mem_allFrame_orthogonal N hN _
    ((allFrameCuspSubspace N hN).sub_starProjection_mem_orthogonal f)

theorem actual_constrained_resolvent_eq_original_on_cusp (N : ℕ) [NeZero N]
    (hN : 0 < N) (f : QuotientL2 N) (hf : f ∈ allFrameCuspSubspace N hN) :
    actualAllFrameVariationalResolvent N hN f = actualGammaResolvent N f :=
  constrained_resolvent_eq_original_of_output_mem N hN f
    (actualGammaResolvent_mem_allFrameCuspSubspace N hN f hf)

theorem actual_constrained_resolvent_zero_on_cusp_orthogonal (N : ℕ) [NeZero N]
    (hN : 0 < N) (f : QuotientL2 N) (hf : f ∈ (allFrameCuspSubspace N hN)ᗮ) :
    actualAllFrameVariationalResolvent N hN f = 0 := by
  change f ∈ (actualAllFrameVariationalResolvent N hN).ker
  rw [actual_variational_kernel_eq_energyImage_orthogonal N hN]
  exact Submodule.orthogonal_le (actualAllFrameEnergyImage_le_cusp N hN) hf

theorem actual_constrained_resolvent_eq_original_projection_apply
    (N : ℕ) [NeZero N] (hN : 0 < N) (f : QuotientL2 N) :
    actualAllFrameVariationalResolvent N hN f =
      actualGammaResolvent N (actualAllFrameCuspProjection N hN f) := by
  have hz := actual_constrained_resolvent_zero_on_cusp_orthogonal N hN
    (f-actualAllFrameCuspProjection N hN f)
      ((allFrameCuspSubspace N hN).sub_starProjection_mem_orthogonal f)
  rw [map_sub] at hz
  exact (sub_eq_zero.mp hz).trans (actual_constrained_resolvent_eq_original_on_cusp N hN _
    ((allFrameCuspSubspace N hN).starProjection_apply_mem f))

/-- Exact native operator identity on the ORIGINAL quotient space. -/
theorem actual_constrained_resolvent_eq_original_comp_projection
    (N : ℕ) [NeZero N] (hN : 0 < N) :
    actualAllFrameVariationalResolvent N hN =
      (actualGammaResolvent N).comp (actualAllFrameCuspProjection N hN) := by
  ext f
  exact actual_constrained_resolvent_eq_original_projection_apply N hN f

end
end ImbalancedChen.Part3.ActualAllFrameOriginalResolventReduction20261026b
