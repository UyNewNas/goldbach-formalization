import ImbalancedChen.Part3ActualAllFramePhysicalFormReduction

/-!
SOURCE ONLY / UNCOMPILED / ZERO FORMAL CREDIT / TRANSITIVE DOTS HOLD.
The actual all-frame energy projection splits BOTH the original physical
mass and original unshifted closed Dirichlet form. Energy orthogonality
and the proved physical JQ=P_C J identity make the two Dirichlet cross
terms vanish. The final sesquilinear identity holds for EVERY pair in the
ORIGINAL completed form space, and yields exact mass, shifted-energy and
unshifted Dirichlet Pythagoras. No form invariance or gradient descent is
included as an input.
-/
namespace ImbalancedChen.Part3.ActualAllFrameDirichletOrthogonalSplit20261026b
noncomputable section
open Set
open Gamma0ActualSmoothQuotientCore20261025a Gamma0ActualEnergyCompletion20261025a
open Gamma0ActualFriedrichsOperator20261025a ActualAllFrameCuspCompactEmbedding20261026b
open AllNormalizedCuspAnnihilator20261026b ActualAllFrameEnergyProjection20261026b
open ActualAllFramePhysicalFormReduction20261026b

/-- The ORIGINAL unshifted Dirichlet cross term vanishes between the
actual energy cusp space and its ENERGY orthogonal complement. -/
theorem actualDirichletPair_allFrame_cross_zero (N : ℕ) [NeZero N] (hN : 0 < N)
    (d e : EnergyCompletion N) (hd : d ∈ actualAllFrameEnergySubspace N hN)
    (he : e ∈ (actualAllFrameEnergySubspace N hN)ᗮ) :
    actualDirichletPair N d e = 0 := by
  have hE : inner ℂ d e = 0 := he d hd
  have hH : inner ℂ (physicalProjection N d) (physicalProjection N e) = 0 :=
    physicalProjection_allFrameEnergy_orthogonal_mem N hN e he (physicalProjection N d) hd
  rw [actualDirichletPair,hE,hH,sub_self]

theorem actualDirichletPair_allFrame_cross_zero_reverse (N : ℕ) [NeZero N] (hN : 0 < N)
    (d e : EnergyCompletion N) (hd : d ∈ actualAllFrameEnergySubspace N hN)
    (he : e ∈ (actualAllFrameEnergySubspace N hN)ᗮ) :
    actualDirichletPair N e d = 0 := by
  have hE : inner ℂ e d = 0 := inner_eq_zero_symm.mp (he d hd)
  have hH0 : inner ℂ (physicalProjection N d) (physicalProjection N e) = 0 :=
    physicalProjection_allFrameEnergy_orthogonal_mem N hN e he (physicalProjection N d) hd
  have hH : inner ℂ (physicalProjection N e) (physicalProjection N d) = 0 :=
    inner_eq_zero_symm.mp hH0
  rw [actualDirichletPair,hE,hH,sub_self]

theorem actualAllFrame_energy_norm_sq_split (N : ℕ) [NeZero N] (hN : 0 < N)
    (e : EnergyCompletion N) :
    ‖e‖^2 = ‖actualAllFrameEnergyProjection N hN e‖^2 +
      ‖e-actualAllFrameEnergyProjection N hN e‖^2 := by
  have hC : actualAllFrameEnergyProjection N hN e ∈ actualAllFrameEnergySubspace N hN :=
    (actualAllFrameEnergySubspace N hN).starProjection_apply_mem e
  have hD : e-actualAllFrameEnergyProjection N hN e ∈ (actualAllFrameEnergySubspace N hN)ᗮ :=
    (actualAllFrameEnergySubspace N hN).sub_starProjection_mem_orthogonal e
  calc
    ‖e‖^2 = ‖actualAllFrameEnergyProjection N hN e + (e-actualAllFrameEnergyProjection N hN e)‖^2 := by
      congr 1
      congr 1
      abel
    _ = _ := norm_add_sq_eq_norm_sq_add_norm_sq_of_inner_eq_zero _ _ (hD _ hC)

/-- Exact ORIGINAL physical mass split, with the SAME two completed-form
vectors as in the shifted-energy and unshifted Dirichlet split. -/
theorem actualAllFrame_physical_mass_sq_split (N : ℕ) [NeZero N] (hN : 0 < N)
    (e : EnergyCompletion N) :
    ‖physicalProjection N e‖^2 = ‖physicalProjection N (actualAllFrameEnergyProjection N hN e)‖^2 +
      ‖physicalProjection N (e-actualAllFrameEnergyProjection N hN e)‖^2 := by
  have hC : actualAllFrameEnergyProjection N hN e ∈ actualAllFrameEnergySubspace N hN :=
    (actualAllFrameEnergySubspace N hN).starProjection_apply_mem e
  have hD : e-actualAllFrameEnergyProjection N hN e ∈ (actualAllFrameEnergySubspace N hN)ᗮ :=
    (actualAllFrameEnergySubspace N hN).sub_starProjection_mem_orthogonal e
  have horth : inner ℂ (physicalProjection N (actualAllFrameEnergyProjection N hN e))
      (physicalProjection N (e-actualAllFrameEnergyProjection N hN e)) = 0 :=
    physicalProjection_allFrameEnergy_orthogonal_mem N hN _ hD _ hC
  calc
    ‖physicalProjection N e‖^2 =
        ‖physicalProjection N (actualAllFrameEnergyProjection N hN e) +
          physicalProjection N (e-actualAllFrameEnergyProjection N hN e)‖^2 := by
      rw [map_sub]
      congr 1
      congr 1
      abel
    _ = _ := norm_add_sq_eq_norm_sq_add_norm_sq_of_inner_eq_zero _ _ horth

/-- Full sesquilinear split of the ORIGINAL unshifted closed form;
neither vector needs smoothness or original operator-domain membership. -/
theorem actualDirichletPair_allFrame_split (N : ℕ) [NeZero N] (hN : 0 < N)
    (d e : EnergyCompletion N) :
    actualDirichletPair N d e =
      actualDirichletPair N (actualAllFrameEnergyProjection N hN d) (actualAllFrameEnergyProjection N hN e) +
      actualDirichletPair N (d-actualAllFrameEnergyProjection N hN d) (e-actualAllFrameEnergyProjection N hN e) := by
  let Q := actualAllFrameEnergyProjection N hN
  have hdC : Q d ∈ actualAllFrameEnergySubspace N hN :=
    (actualAllFrameEnergySubspace N hN).starProjection_apply_mem d
  have heC : Q e ∈ actualAllFrameEnergySubspace N hN :=
    (actualAllFrameEnergySubspace N hN).starProjection_apply_mem e
  have hdD : d-Q d ∈ (actualAllFrameEnergySubspace N hN)ᗮ :=
    (actualAllFrameEnergySubspace N hN).sub_starProjection_mem_orthogonal d
  have heD : e-Q e ∈ (actualAllFrameEnergySubspace N hN)ᗮ :=
    (actualAllFrameEnergySubspace N hN).sub_starProjection_mem_orthogonal e
  have hcross1 := actualDirichletPair_allFrame_cross_zero N hN (Q d) (e-Q e) hdC heD
  have hcross2 := actualDirichletPair_allFrame_cross_zero_reverse N hN (Q e) (d-Q d) heC hdD
  change actualDirichletPair N d e = actualDirichletPair N (Q d) (Q e) + actualDirichletPair N (d-Q d) (e-Q e)
  calc
    actualDirichletPair N d e =
        actualDirichletPair N (Q d) (Q e) + actualDirichletPair N (Q d) (e-Q e) +
          actualDirichletPair N (d-Q d) (Q e) + actualDirichletPair N (d-Q d) (e-Q e) := by
      simp only [actualDirichletPair,map_sub,inner_sub_left,inner_sub_right]
      ring
    _ = _ := by rw [hcross1,hcross2]; ring

theorem actualDirichletEnergy_allFrame_split (N : ℕ) [NeZero N] (hN : 0 < N)
    (e : EnergyCompletion N) :
    (actualDirichletPair N e e).re =
      (actualDirichletPair N (actualAllFrameEnergyProjection N hN e) (actualAllFrameEnergyProjection N hN e)).re +
      (actualDirichletPair N (e-actualAllFrameEnergyProjection N hN e) (e-actualAllFrameEnergyProjection N hN e)).re := by
  simpa only [Complex.add_re] using congrArg Complex.re (actualDirichletPair_allFrame_split N hN e e)

end
end ImbalancedChen.Part3.ActualAllFrameDirichletOrthogonalSplit20261026b
