import ImbalancedChen.Part3ActualAllFrameOriginalResolventReduction
import ImbalancedChen.Part3ActualAllFrameZeroEnergyRigidity
import ImbalancedChen.Part3GammaHeatStrongMeanLimit

/-!
SOURCE ONLY / UNCOMPILED / ZERO FORMAL CREDIT.
TRANSITIVE HOLD: the original resolvent reduction retains its upstream
be3646/0f1f API hold. No held source is repaired or bypassed here.

The FULL actual all-frame annihilator, in the ORIGINAL quotient Hilbert
space, is orthogonal to the actual constant. This is not inferred from
one cusp's literal Fourier mean. Original resolvent commutation projects
the genuine fixed constant to a fixed vector in the full cusp subspace.
Its actual Riesz lift has zero original Dirichlet energy, so the proved
all-frame zero-energy rigidity kills that projected constant.

Consequently every full all-frame vector has literal GLOBAL quotient
mean zero, zero constant/zero-atom projection and no scalar zero atom.
The existing actual strong heat mean limit then yields pointwise strong
decay to zero. No heat invariance of the cusp space, uniform rate,
positive spectral gap or whole-plane Hardy estimate is asserted.
-/
namespace ImbalancedChen.Part3.ActualAllFrameGlobalMeanZero20261026b
noncomputable section
open Set MeasureTheory Filter
open scoped Topology
open Gamma0ActualSmoothQuotientCore20261025a Gamma0QuotientCellPushforward20261025a
open Gamma0ActualConstantMode20261025a Gamma0ActualEnergyCompletion20261025a
open Gamma0ActualWeakRieszResolvent20261025a Gamma0ActualFriedrichsOperator20261025a
open GammaConstantFormClosure20261026a AllNormalizedCuspAnnihilator20261026b
open ActualAllFrameOriginalResolventReduction20261026b
open ActualAllFrameZeroEnergyRigidity20261026b
open GammaConstantRankOneProjection20261026a GammaZeroAtomConstantClosure20261026a
open GammaZeroSpectralProjectionKernel20261026a GammaHeatMeanInvariant20261026b
open Gamma0ActualUnboundedScalarMeasure20261025a Gamma0ActualHeatGenerator20261025a
open GammaHeatStrongMeanLimit20261026b

/-- The actual full cusp projection annihilates the original constant.
The original resolvent and its actual Riesz lift supply the required
zero-energy witness; no cusp/global mean hypothesis is supplied. -/
theorem actualAllFrameCuspProjection_constant_eq_zero
    (N : ℕ) [NeZero N] (hN : 0 < N) :
    actualAllFrameCuspProjection N hN (constantL2 N) = 0 := by
  let p : QuotientL2 N := actualAllFrameCuspProjection N hN (constantL2 N)
  have hc : actualGammaResolvent N (constantL2 N) = constantL2 N :=
    (kernel_mem_iff_resolvent_fixed N (constantL2 N)).mp
      (constantL2_mem_friedrichsGraph_zero N)
  have hcomm := congrArg
    (fun T : QuotientL2 N →L[ℂ] QuotientL2 N => T (constantL2 N))
    (actualGammaResolvent_commutes_cuspProjection N hN)
  have hp : actualGammaResolvent N p = p := by
    simpa only [ContinuousLinearMap.comp_apply, hc, p] using hcomm
  let e : EnergyCompletion N := actualRieszLift N p
  have heproj : physicalProjection N e = p := hp
  have hecusp : physicalProjection N e ∈ allFrameCuspSubspace N hN := by
    rw [heproj]
    exact (allFrameCuspSubspace N hN).starProjection_apply_mem (constantL2 N)
  have hweak : inner ℂ e e = inner ℂ (physicalProjection N e) p :=
    actualRieszLift_weak N p e
  have heDir : actualDirichletPair N e e = 0 := by
    change inner ℂ e e - inner ℂ (physicalProjection N e) (physicalProjection N e) = 0
    rw [hweak, heproj, sub_self]
  have hezero : e = 0 := actual_allFrame_zero_energy_eq_zero N hN e hecusp
    (by rw [heDir, Complex.zero_re])
  change p = 0
  rw [← heproj, hezero, map_zero]

/-- Orthogonality of the original constant to the FULL all-frame space.
The actual orthogonal projection, not an assumed mean functional law,
licenses this statement. -/
theorem constantL2_mem_allFrame_orthogonal
    (N : ℕ) [NeZero N] (hN : 0 < N) :
    constantL2 N ∈ (allFrameCuspSubspace N hN)ᗮ := by
  have h := (allFrameCuspSubspace N hN).sub_starProjection_mem_orthogonal
    (constantL2 N)
  change constantL2 N - actualAllFrameCuspProjection N hN (constantL2 N) ∈
    (allFrameCuspSubspace N hN)ᗮ at h
  simpa only [actualAllFrameCuspProjection_constant_eq_zero N hN, sub_zero] using h

theorem actual_allFrame_inner_constant_eq_zero
    (N : ℕ) [NeZero N] (hN : 0 < N)
    {f : QuotientL2 N} (hf : f ∈ allFrameCuspSubspace N hN) :
    inner ℂ (constantL2 N) f = 0 := by
  have h : inner ℂ f (constantL2 N) = 0 :=
    constantL2_mem_allFrame_orthogonal N hN f hf
  simpa only [inner_conj_symm, star_zero] using congrArg star h

/-- The GLOBAL physical quotient mean, with its literal original
carrierPushforward normalization, vanishes on the FULL cusp space. -/
theorem actual_allFrame_global_mean_zero
    (N : ℕ) [NeZero N] (hN : 0 < N)
    {f : QuotientL2 N} (hf : f ∈ allFrameCuspSubspace N hN) :
    (∫ q, f q ∂carrierPushforward N) = 0 := by
  rw [← constantL2_inner]
  exact actual_allFrame_inner_constant_eq_zero N hN hf

theorem allFrameCuspSubspace_le_actualMeanZero
    (N : ℕ) [NeZero N] (hN : 0 < N) :
    allFrameCuspSubspace N hN ≤ actualMeanZero N := by
  intro f hf
  exact (mem_actualMeanZero_iff N f).mpr (actual_allFrame_global_mean_zero N hN hf)

theorem actual_constantRankOne_kills_allFrame
    (N : ℕ) [NeZero N] (hN : 0 < N)
    {f : QuotientL2 N} (hf : f ∈ allFrameCuspSubspace N hN) :
    constantRankOne N f = 0 := by
  rw [constantRankOne_apply_mean, actual_allFrame_global_mean_zero N hN hf,
    zero_div, zero_smul]

theorem actualZeroProjection_kills_allFrame
    (N : ℕ) [NeZero N] (hN : 0 < N)
    {f : QuotientL2 N} (hf : f ∈ allFrameCuspSubspace N hN) :
    actualZeroProjection N f = 0 := by
  rw [actualZeroProjection_eq_constantRankOne]
  exact actual_constantRankOne_kills_allFrame N hN hf

theorem actualLaplaceMeasure_allFrame_zero_atom
    (N : ℕ) [NeZero N] (hN : 0 < N)
    {f : QuotientL2 N} (hf : f ∈ allFrameCuspSubspace N hN) :
    actualLaplaceMeasure N f {0} = 0 :=
  (actualLaplaceMeasure_zero_eq_zero_iff_mean_zero N f).mpr
    (actual_allFrame_global_mean_zero N hN hf)

/-- Actual heat tends strongly to zero on every vector of the FULL
all-frame space. This is a vectorwise long-time statement; preservation
of that space at intermediate times is not a premise or conclusion. -/
theorem actualGammaHeat_allFrame_tendsto_zero
    (N : ℕ) [NeZero N] (hN : 0 < N)
    {f : QuotientL2 N} (hf : f ∈ allFrameCuspSubspace N hN) :
    Tendsto (fun t : ℝ => actualGammaHeat N t f) atTop (𝓝 0) :=
  actualGammaHeat_meanZero_tendsto_zero N
    (allFrameCuspSubspace_le_actualMeanZero N hN hf)

end
end ImbalancedChen.Part3.ActualAllFrameGlobalMeanZero20261026b
