import ImbalancedChen.Part3ActualImaginaryFourierLogODE
import ImbalancedChen.Part3ImaginaryRadialCanonicalKSelection

/-!
# Actual signed nonzero Maass Fourier coefficient: physical imaginary K

SOURCE ONLY / UNCOMPILED / ZERO FORMAL CREDIT / HOLD_DEPENDENCY.

The actual periodic C2 PDE and raw physical strip L2 give the native
log ODE and its L2 norm. Canonical imaginary-order K selection then gives
a unique physical coefficient rho_n, with the exact sqrt(y) factor,
argument 2*pi*|n|*y, and domain y>Y. Both signs of n and tau=0 are
included. A far-right nonzero K anchor proves coefficient uniqueness;
no height-one denominator or global zero-free premise is introduced.

INSTALLATION HOLD: the canonical-selection chain requires the corrected
native derivative-L2 source d4d0a..., while the existing target is c51501...
and correction of that existing target belongs exclusively to Dots.
This completed mathematical source must remain ready_to_install=false
until the exact dependency guard is resolved. No bypass is supplied.
-/

namespace ImbalancedChen.Part3.ActualImaginaryMaassFourierK20261026b

noncomputable section
open Set MeasureTheory
open ActualMaassFourierODE20261026a ActualFourierBesselConjugation20261026a
open ActualImaginaryFourierLogODE20261026b ImaginaryRadialCanonicalKSelection20261026b
open ComplexOrderKBridgeSourceOnly ComplexOrderKRadialRegularitySourceOnly
attribute [local instance] Measure.Subtype.measureSpace

/-- Genuine physical cusp-tail classification. Hypotheses concern only
the original function, its PDE/periodicity and its spatial L2 norm; no
coefficient ODE, coefficient L2 norm, or K shape is a premise. -/
theorem actual_nonzero_coefficient_eq_unique_imaginaryK
    {u : ℝ × ℝ → ℂ} {tau Y : ℝ} {n : ℤ}
    (hu : ContDiffOn ℝ 2 u upperDomain)
    (hp : ∀ x y : ℝ, 0 < y → u (x+1,y)=u(x,y))
    (hPDE : ∀ p ∈ upperDomain,
      -(p.2 : ℂ)^2*(partialX (partialX u) p+partialY (partialY u) p) =
        ((1/4+tau^2 : ℝ) : ℂ)*u p)
    (hn : n ≠ 0) (hY : 0 < Y)
    (hstrip : Integrable (fun p : PeriodCell × ℝ => p.2⁻¹^2*‖u (p.1,p.2)‖^2)
      ((volume : Measure PeriodCell).prod (volume.restrict (Ioi Y)))) :
    ∃! rho : ℂ, ∀ y : ℝ, Y < y →
      coefficient u n y = rho*(Real.sqrt y : ℂ)*
        complexOrderK ((tau : ℂ)*Complex.I) (2*Real.pi*|(n : ℝ)|*y) := by
  have ha := modeFrequency_pos hn
  let R := Real.log (modeFrequency n*Y)
  obtain ⟨hODE,hL2⟩ := actualFourierLogMode_ODE_and_L2_of_strip hu hp hPDE hn hY hstrip
  obtain ⟨rho,hrho,_⟩ := L2_tail_solution_eq_unique_actualK hODE hL2
  have hshape (y : ℝ) (hy : Y < y) : coefficient u n y =
      rho*(Real.sqrt y : ℂ)*complexOrderK ((tau : ℂ)*Complex.I) (modeFrequency n*y) := by
    have hy0 := hY.trans hy
    have hqy := mul_pos ha hy0
    have hlog : R < Real.log (modeFrequency n*y) :=
      Real.log_lt_log (mul_pos ha hY) (mul_lt_mul_of_pos_left hy ha)
    have hmode := hrho (Real.log (modeFrequency n*y)) hlog
    simp only [actualFourierLogMode,imaginaryK,radialK,Real.exp_log hqy] at hmode
    have hrec := coefficient_recovery (coefficient u n) ha hy0
    change coefficient u n y = (Real.sqrt y : ℂ)*actualBesselMode u n (modeFrequency n*y) at hrec
    rw [hmode] at hrec
    simpa only [mul_assoc,mul_comm,mul_left_comm] using hrec
  refine ⟨rho,fun y hy => hshape y hy,?_⟩
  intro d hd
  obtain ⟨a,haR,hKa⟩ := imaginaryK_nonzero_anchor tau R
  let y := Real.exp a/modeFrequency n
  have hy0 : 0 < y := div_pos (Real.exp_pos _) ha
  have hyY : Y < y := by
    apply (lt_div_iff₀ ha).mpr
    have he := Real.exp_lt_exp.mpr haR
    rw [show R = Real.log (modeFrequency n*Y) from rfl,
      Real.exp_log (mul_pos ha hY)] at he
    simpa only [mul_comm] using he
  have harg : modeFrequency n*y = Real.exp a := by
    dsimp [y]
    field_simp [ha.ne']
  have hden : (Real.sqrt y : ℂ)*
      complexOrderK ((tau : ℂ)*Complex.I) (modeFrequency n*y) ≠ 0 := by
    apply mul_ne_zero (Complex.ofReal_ne_zero.mpr (Real.sqrt_pos.mpr hy0).ne')
    rw [harg]
    exact hKa
  apply mul_right_cancel₀ hden
  calc
    d*((Real.sqrt y : ℂ)*complexOrderK ((tau : ℂ)*Complex.I) (modeFrequency n*y)) =
        coefficient u n y := by simpa only [mul_assoc] using (hd y hyY).symm
    _ = rho*((Real.sqrt y : ℂ)*complexOrderK ((tau : ℂ)*Complex.I) (modeFrequency n*y)) := by
      simpa only [mul_assoc] using hshape y hyY

end
end ImbalancedChen.Part3.ActualImaginaryMaassFourierK20261026b
