import ImbalancedChen.Part3NormalizedCuspActualVerticalPhysicalWeak
import ImbalancedChen.Part3NormalizedCuspPhysicalMeanZero
import ImbalancedChen.Part3CuspWeakH1JointSmoothPacketCore

/-! SOURCE ONLY / UNCOMPILED / ZERO FORMAL CREDIT.
TRANSITIVE DOTS HOLD: original physicalmean1ce9/normalizedFourier0f1f.
The ACTUAL original completed all-frame cuspidal form vector now gives a
full physical H1 jet in every normalized rational cusp. Its weighted
value and BOTH raw derivatives have one ORIGINAL form norm budget. The
two actual distribution equations and the existing actual cusp mean
supplier yield ONE genuinely jointly smooth finite Fourier packet
sequence converging in all THREE physical norms. No final physical H1
packet, smooth value, form-core density or approximation is a premise. -/

namespace ImbalancedChen.Part3.ActualAllFrameCuspPhysicalH1Packets20261026b
noncomputable section
open Set MeasureTheory Filter Matrix
open scoped MatrixGroups UpperHalfPlane Topology
open Gamma0ActualSmoothQuotientCore20261025a Gamma0ActualEnergyCompletion20261025a
open Gamma0ActualFriedrichsOperator20261025a NormalizedCuspNativeDerivative20261026b
open NormalizedCuspNativeVerticalDerivative20261026b NormalizedCuspActualPhysicalWeak20261026b
open NormalizedCuspActualVerticalPhysicalWeak20261026b NormalizedCuspPhysicalMeanZero20261026b
open NormalizedCuspCylinderL220261026b AllNormalizedCuspAnnihilator20261026b
open CuspCylinderMeasure20261024z ClosedHorizontalCuspTail20261026a
open ActualHighStripNativeCylinderMeasure20261026b CuspPhysicalH1HeightExhaustion20261026b
open CuspRawWeakDerivativeBridge20261026b CuspVerticalWeakCutoffProduct20261026b
open CuspWeakH1JointSmoothPacketCore20261026b JointSmoothFiniteCuspPackets20261026b
open FiniteCuspH1PacketDensity20261026b CommonHeightSmoothApproximation20261026b

def actualNormalizedCuspPhysicalH1Jet (N : ℕ) [NeZero N] (hN : 0 < N) (g : SL(2, ℤ))
    {a : ℝ} (ha : 1 < a) (e : EnergyCompletion N) : PhysicalH1Jet a :=
  (normalizedCuspNativeValue N hN g ha e,
    normalizedCuspNativeDx N hN g ha e,normalizedCuspNativeDy N hN g ha e)

theorem actual_native_value_norm_le (N : ℕ) [NeZero N] (hN : 0 < N)
    (g : SL(2, ℤ)) {a : ℝ} (ha : 1 < a) (e : EnergyCompletion N) :
    ‖normalizedCuspNativeValue N hN g ha e‖ ≤ ‖physicalProjection N e‖ := by
  have hnorm : ‖normalizedCuspNativeValue N hN g ha e‖ =
      ‖normalizedCuspCylinder N hN g ha (physicalProjection N e)‖ := by
    rw [Lp.norm_def,Lp.norm_def]
    have he := eLpNorm_congr_ae (p := (2 : ℝ≥0∞)) (native_value_eq_closed_cylinder_ae N hN g ha e)
    simpa only [functionMeasure_eq_closed_tail a (zero_lt_one.trans ha)] using congrArg ENNReal.toReal he
  rw [hnorm]
  exact normalizedCuspCylinder_norm_le N hN g ha (physicalProjection N e)

/-- All THREE physical coordinates together have unit original shifted
form cost; the two derivative energies are not separately doubled. -/
theorem actual_normalized_cusp_fullH1_budget (N : ℕ) [NeZero N] (hN : 0 < N)
    (g : SL(2, ℤ)) {a : ℝ} (ha : 1 < a) (e : EnergyCompletion N) :
    ‖normalizedCuspNativeValue N hN g ha e‖^2 +
      (‖normalizedCuspNativeDx N hN g ha e‖^2+‖normalizedCuspNativeDy N hN g ha e‖^2) ≤ ‖e‖^2 := by
  have hv := pow_le_pow_left₀ (norm_nonneg _) (actual_native_value_norm_le N hN g ha e) 2
  have hd := normalizedCuspNative_joint_derivative_budget N hN g ha e
  have he : ‖physicalProjection N e‖^2+(actualDirichletPair N e e).re = ‖e‖^2 := by
    rw [actualDirichletPair,Complex.sub_re,← InnerProductSpace.norm_sq_eq_re_inner,
      ← InnerProductSpace.norm_sq_eq_re_inner]
    ring
  exact (add_le_add hv hd).trans_eq he

/-- Actual Γ form vectors supply ALL three physical weak-H1 inputs of
the genuine packet-density theorem. The horizontal mean uses the existing
actual all-frame supplier unchanged and retains its explicit Dots hold. -/
theorem actual_allFrame_cusp_joint_smooth_packet_sequence (N : ℕ) [NeZero N]
    (hN : 0 < N) (g : SL(2, ℤ)) {a : ℝ} (ha : 1 < a) (e : EnergyCompletion N)
    (he : physicalProjection N e ∈ allFrameCuspSubspace N hN) :
    ∃ P : ℕ → SmoothPacket,
      (∀ n,dist (packetH1Jet (P n) a) (actualNormalizedCuspPhysicalH1Jet N hN g ha e)<tolerance n) ∧
      Tendsto (fun n => packetH1Jet (P n) a) atTop (𝓝 (actualNormalizedCuspPhysicalH1Jet N hN g ha e)) :=
  weakH1_joint_smooth_packet_sequence (zero_lt_one.trans ha)
    (actualNormalizedCuspPhysicalH1Jet N hN g ha e)
    (raw_weak_implies_weighted (actual_normalized_cusp_physical_raw_weak N hN g ha e))
    (actual_normalized_cusp_physical_vertical_weak N hN g ha e)
    (actual_native_value_mean_zero N hN g ha e he)

end
end ImbalancedChen.Part3.ActualAllFrameCuspPhysicalH1Packets20261026b
