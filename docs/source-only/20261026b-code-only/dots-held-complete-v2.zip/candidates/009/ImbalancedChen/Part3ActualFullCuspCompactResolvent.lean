import ImbalancedChen.Part3ActualFullCuspResolvent
import ImbalancedChen.Part3ActualAllFrameOriginalResolventReduction

/-! SOURCE ONLY / UNCOMPILED / ZERO FORMAL CREDIT.
TRANSITIVE DOTS HOLD: immutable analytic1a3/be3646 and mean0f1f chain.
The SHARED literal restriction of ORIGINAL R to the FULL actual all-frame
cusp Hilbert space is COMPACT. The actual analytic invariance/reduction
identifies its values with the proved compact constrained R, after which
the genuine closed-subspace codomain restriction preserves compactness.
The shared resolvent is not redefined. No invariance, density, compactness
or graph conclusion is assumed. No full-L2/Eisenstein claim is made. -/

namespace ImbalancedChen.Part3.ActualFullCuspCompactResolvent20261026b
noncomputable section
open Set
open Gamma0ActualSmoothQuotientCore20261025a Gamma0ActualWeakRieszResolvent20261025a
open AllNormalizedCuspAnnihilator20261026b ActualFullCuspResolvent20261026b
open ActualAllFrameCompactVariationalResolvent20261026b
open ActualAllFrameOriginalResolventReduction20261026b

/-- Compactness of ORIGINAL resolvent restricted to the ENTIRE original
all-frame cusp subspace, from the actual analytic reduction. -/
theorem actualFullCuspResolvent_isCompactOperator (N : ℕ) [NeZero N] (hN : 0 < N) :
    IsCompactOperator (actualFullCuspResolvent N hN) := by
  let C := allFrameCuspSubspace N hN
  have hpre : IsCompactOperator (fun f : ActualFullCuspL2 N hN =>
      actualAllFrameVariationalResolvent N hN (f : QuotientL2 N)) :=
    (actualAllFrameVariationalResolvent_isCompactOperator N hN).comp_clm C.subtypeL
  have hc := hpre.codRestrict (fun f => actualAllFrameVariationalResolvent_mem N hN (f : QuotientL2 N))
    (allFrameCuspSubspace_closed N hN)
  have he : Set.codRestrict (fun f : ActualFullCuspL2 N hN =>
        actualAllFrameVariationalResolvent N hN (f : QuotientL2 N)) C
        (fun f => actualAllFrameVariationalResolvent_mem N hN (f : QuotientL2 N)) =
      (actualFullCuspResolvent N hN : ActualFullCuspL2 N hN → ActualFullCuspL2 N hN) := by
    funext f
    apply Subtype.ext
    change actualAllFrameVariationalResolvent N hN (f : QuotientL2 N) = actualGammaResolvent N f
    exact actual_constrained_resolvent_eq_original_on_cusp N hN f f.property
  rw [he] at hc
  exact hc

end
end ImbalancedChen.Part3.ActualFullCuspCompactResolvent20261026b
