import ImbalancedChen.Part3ActualAllFrameResolventInvariance
import Mathlib.Analysis.InnerProductSpace.Adjoint
import Mathlib.Topology.Algebra.Module.ContinuousLinearMap.Restrict

/-!
SOURCE_ONLY / UNCOMPILED / ZERO FORMAL CREDIT / READY_FALSE.
TRANSITIVE DOTS API HOLD through immutable actual analytic invariance1a3
and its existing be3646/0f1f dependencies; no bypass or repair.

The shared resolvent on the FULL original all-frame cusp subspace is the
literal restriction of ORIGINAL actualGammaResolvent, using its actual
proved analytic invariance. Original symmetry and injectivity give its
self-adjointness, injectivity and dense range on the ENTIRE cusp Hilbert
space. No invariance, range density or constrained-resolvent identity is
assumed. Compactness and the native full-cusp graph are separately owned.
-/

namespace ImbalancedChen.Part3.ActualFullCuspResolvent20261026b
noncomputable section
open Set
open Gamma0ActualSmoothQuotientCore20261025a Gamma0ActualWeakRieszResolvent20261025a
open AllNormalizedCuspAnnihilator20261026b ActualAllFrameResolventInvariance20261026b

abbrev ActualFullCuspL2 (N : ℕ) [NeZero N] (hN : 0 < N) := allFrameCuspSubspace N hN

local instance actualFullCusp_complete (N : ℕ) [NeZero N] (hN : 0 < N) :
    CompleteSpace (ActualFullCuspL2 N hN) :=
  (allFrameCuspSubspace_closed N hN).completeSpace_coe

/-- ORIGINAL native R restricted to the ENTIRE original cusp annihilator.
This is the sole shared full-cusp resolvent definition. -/
def actualFullCuspResolvent (N : ℕ) [NeZero N] (hN : 0 < N) :
    ActualFullCuspL2 N hN →L[ℂ] ActualFullCuspL2 N hN :=
  (actualGammaResolvent N).restrict (actualGammaResolvent_mem_allFrameCuspSubspace N hN)

@[simp] theorem actualFullCuspResolvent_coe (N : ℕ) [NeZero N] (hN : 0 < N)
    (f : ActualFullCuspL2 N hN) :
    (actualFullCuspResolvent N hN f : QuotientL2 N) = actualGammaResolvent N f := rfl

theorem actualFullCuspResolvent_symmetric (N : ℕ) [NeZero N] (hN : 0 < N)
    (f g : ActualFullCuspL2 N hN) :
    inner ℂ (actualFullCuspResolvent N hN f) g =
      inner ℂ f (actualFullCuspResolvent N hN g) :=
  actualGammaResolvent_symmetric N f g

theorem actualFullCuspResolvent_selfAdjoint (N : ℕ) [NeZero N] (hN : 0 < N) :
    IsSelfAdjoint (actualFullCuspResolvent N hN) := by
  apply ContinuousLinearMap.isSelfAdjoint_iff_isSymmetric.mpr
  exact actualFullCuspResolvent_symmetric N hN

theorem actualFullCuspResolvent_injective (N : ℕ) [NeZero N] (hN : 0 < N) :
    Function.Injective (actualFullCuspResolvent N hN) := by
  intro f g hfg
  apply Subtype.ext
  apply actualGammaResolvent_injective N
  exact congrArg (fun h : ActualFullCuspL2 N hN => (h : QuotientL2 N)) hfg

theorem actualFullCuspResolvent_adjoint (N : ℕ) [NeZero N] (hN : 0 < N) :
    (actualFullCuspResolvent N hN).adjoint = actualFullCuspResolvent N hN :=
  (actualFullCuspResolvent_selfAdjoint N hN).isSymmetric.clm_adjoint_eq

/-- Dense range on the FULL cusp space, with no density of the energy
image supplied as a premise. -/
theorem actualFullCuspResolvent_denseRange (N : ℕ) [NeZero N] (hN : 0 < N) :
    DenseRange (actualFullCuspResolvent N hN) := by
  change Dense ((actualFullCuspResolvent N hN).range : Set (ActualFullCuspL2 N hN))
  apply Submodule.dense_iff_topologicalClosure_eq_top.mpr
  apply (actualFullCuspResolvent N hN).range.topologicalClosure_eq_top_iff.mpr
  rw [ContinuousLinearMap.orthogonal_range, actualFullCuspResolvent_adjoint,
    show (actualFullCuspResolvent N hN).ker = ⊥ from
      LinearMap.ker_eq_bot.mpr (actualFullCuspResolvent_injective N hN)]

theorem actualFullCuspResolvent_norm_le (N : ℕ) [NeZero N] (hN : 0 < N)
    (f : ActualFullCuspL2 N hN) : ‖actualFullCuspResolvent N hN f‖ ≤ ‖f‖ :=
  actualGammaResolvent_norm_le N f

theorem actualFullCuspResolvent_firm (N : ℕ) [NeZero N] (hN : 0 < N)
    (f : ActualFullCuspL2 N hN) :
    ‖actualFullCuspResolvent N hN f‖^2 ≤
      (inner ℂ f (actualFullCuspResolvent N hN f)).re :=
  actualGammaResolvent_firm N f

end
end ImbalancedChen.Part3.ActualFullCuspResolvent20261026b
