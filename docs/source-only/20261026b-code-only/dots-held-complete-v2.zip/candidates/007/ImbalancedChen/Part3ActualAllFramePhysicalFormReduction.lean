import ImbalancedChen.Part3ActualAllFrameEnergyProjection
import ImbalancedChen.Part3Gamma0PhysicalClosedDirichletForm

/-!
SOURCE ONLY / UNCOMPILED / ZERO FORMAL CREDIT / TRANSITIVE DOTS HOLD.
The physical cusp projection preserves the ORIGINAL closed form domain.
Actual Riesz-lift intertwining and the energy/physical projection symmetry
prove J Q=P_C J on every completed form vector. The pre-existing unique
actualEnergyLift then gives the exact canonical lift of projected physical
form vectors. No form invariance, alternative domain or lift is assumed.
-/
namespace ImbalancedChen.Part3.ActualAllFramePhysicalFormReduction20261026b
noncomputable section
open Set
open Gamma0ActualSmoothQuotientCore20261025a Gamma0ActualEnergyCompletion20261025a
open Gamma0ActualWeakRieszResolvent20261025a Gamma0ActualFriedrichsOperator20261025a
open Gamma0PhysicalClosedDirichletForm20261025a ActualAllFrameCuspCompactEmbedding20261026b
open AllNormalizedCuspAnnihilator20261026b ActualAllFrameOriginalResolventReduction20261026b
open ActualAllFrameEnergyProjection20261026b

/-- Exact physical/energy projection intertwining on the ORIGINAL
completed form, proved by actual adjoint testing on all physical vectors. -/
theorem physicalProjection_allFrameEnergyProjection_apply (N : ℕ) [NeZero N] (hN : 0 < N)
    (e : EnergyCompletion N) :
    physicalProjection N (actualAllFrameEnergyProjection N hN e) =
      actualAllFrameCuspProjection N hN (physicalProjection N e) := by
  apply ext_inner_right ℂ
  intro f
  calc
    inner ℂ (physicalProjection N (actualAllFrameEnergyProjection N hN e)) f =
        inner ℂ (actualAllFrameEnergyProjection N hN e) (actualRieszLift N f) :=
      (actualRieszLift_weak N f (actualAllFrameEnergyProjection N hN e)).symm
    _ = inner ℂ e (actualAllFrameEnergyProjection N hN (actualRieszLift N f)) :=
      Submodule.inner_starProjection_left_eq_right (actualAllFrameEnergySubspace N hN) e _
    _ = inner ℂ e (actualRieszLift N (actualAllFrameCuspProjection N hN f)) := by
      rw [actualAllFrameEnergyProjection_riesz_apply]
    _ = inner ℂ (physicalProjection N e) (actualAllFrameCuspProjection N hN f) :=
      actualRieszLift_weak N _ e
    _ = inner ℂ (actualAllFrameCuspProjection N hN (physicalProjection N e)) f :=
      (Submodule.inner_starProjection_left_eq_right (allFrameCuspSubspace N hN) _ f).symm

theorem physicalProjection_comp_allFrameEnergyProjection (N : ℕ) [NeZero N] (hN : 0 < N) :
    (physicalProjection N).comp (actualAllFrameEnergyProjection N hN) =
      (actualAllFrameCuspProjection N hN).comp (physicalProjection N) := by
  ext e
  exact physicalProjection_allFrameEnergyProjection_apply N hN e

/-- Energy-orthogonal completed vectors have physical images in the
actual physical cusp complement, as a CONSEQUENCE of JQ=P_C J. -/
theorem physicalProjection_allFrameEnergy_orthogonal_mem (N : ℕ) [NeZero N] (hN : 0 < N)
    (e : EnergyCompletion N) (he : e ∈ (actualAllFrameEnergySubspace N hN)ᗮ) :
    physicalProjection N e ∈ (allFrameCuspSubspace N hN)ᗮ := by
  apply (allFrameCuspSubspace N hN).starProjection_apply_eq_zero_iff.mp
  change actualAllFrameCuspProjection N hN (physicalProjection N e) = 0
  have hQ : actualAllFrameEnergyProjection N hN e = 0 :=
    (actualAllFrameEnergySubspace N hN).starProjection_apply_eq_zero_iff.mpr he
  rw [← physicalProjection_allFrameEnergyProjection_apply,hQ,map_zero]

/-- Projection point in the EXISTING original form-domain submodule,
using its EXISTING unique energy lift. -/
def actualAllFrameFormProjectionPoint (N : ℕ) [NeZero N] (hN : 0 < N) :
    actualEnergyFormDomain N →ₗ[ℂ] actualEnergyFormDomain N :=
  (actualEnergyLift N).symm.toLinearMap.comp
    ((actualAllFrameEnergyProjection N hN).toLinearMap.comp (actualEnergyLift N).toLinearMap)

theorem actualAllFrameFormProjectionPoint_energyLift (N : ℕ) [NeZero N] (hN : 0 < N)
    (u : actualEnergyFormDomain N) :
    actualEnergyLift N (actualAllFrameFormProjectionPoint N hN u) =
      actualAllFrameEnergyProjection N hN (actualEnergyLift N u) :=
  (actualEnergyLift N).apply_symm_apply _

/-- The constructed form point is exactly the ORIGINAL physical cusp
projection of u, proved after its canonical energy lift was constructed. -/
theorem actualAllFrameFormProjectionPoint_physical (N : ℕ) [NeZero N] (hN : 0 < N)
    (u : actualEnergyFormDomain N) :
    (actualAllFrameFormProjectionPoint N hN u : QuotientL2 N) =
      actualAllFrameCuspProjection N hN (u : QuotientL2 N) := by
  change physicalProjection N (actualAllFrameEnergyProjection N hN (actualEnergyLift N u)) = _
  rw [physicalProjection_allFrameEnergyProjection_apply,actualEnergyLift_projection]

theorem actualAllFrameCuspProjection_mem_original_formDomain (N : ℕ) [NeZero N] (hN : 0 < N)
    (u : actualEnergyFormDomain N) :
    actualAllFrameCuspProjection N hN (u : QuotientL2 N) ∈ actualEnergyFormDomain N := by
  rw [← actualAllFrameFormProjectionPoint_physical N hN u]
  exact (actualAllFrameFormProjectionPoint N hN u).property

theorem actualAllFrameCuspComplement_mem_original_formDomain (N : ℕ) [NeZero N] (hN : 0 < N)
    (u : actualEnergyFormDomain N) :
    (u : QuotientL2 N)-actualAllFrameCuspProjection N hN (u : QuotientL2 N) ∈ actualEnergyFormDomain N :=
  (actualEnergyFormDomain N).sub_mem u.property (actualAllFrameCuspProjection_mem_original_formDomain N hN u)

/-- Exact canonical energy lift for the complementary physical form
point as well, retaining the same actualEnergyLift on the original domain. -/
theorem actualAllFrameFormComplement_energyLift (N : ℕ) [NeZero N] (hN : 0 < N)
    (u : actualEnergyFormDomain N) :
    actualEnergyLift N (u-actualAllFrameFormProjectionPoint N hN u) =
      actualEnergyLift N u-actualAllFrameEnergyProjection N hN (actualEnergyLift N u) := by
  rw [map_sub,actualAllFrameFormProjectionPoint_energyLift]

end
end ImbalancedChen.Part3.ActualAllFramePhysicalFormReduction20261026b
