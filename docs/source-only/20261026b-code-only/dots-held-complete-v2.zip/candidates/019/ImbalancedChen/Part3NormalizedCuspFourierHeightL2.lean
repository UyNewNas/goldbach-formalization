import ImbalancedChen.Part3NormalizedCuspCylinderFourier
import ImbalancedChen.Part3CuspUpperBandMixedFourierConvergence

/-!
SOURCE ONLY / UNCOMPILED / ZERO FORMAL CREDIT.
TRANSITIVE DOTS API HOLD: existing normalized-cylinder Fourier supplier.
Every actual normalized cusp has literal original quotient Fourier
coefficients in genuine high-height dy/y² L2. The constructed native
height vector supplies the infinity endpoint, including m=0, without
continuity or a cusp condition. Old infinity-only source is unchanged.
-/
namespace ImbalancedChen.Part3.NormalizedCuspFourierHeightL220261026b
noncomputable section
open Set MeasureTheory Filter Matrix
open scoped MatrixGroups UpperHalfPlane
open Gamma0QuotientCellPushforward20261025a
open CuspCylinderMeasure20261024z ActualCylinderModeEmbeddings20261026a
open ActualCylinderFourierCoefficients20261026a
open ActualHighStripNativeCylinderMeasure20261026b ActualHighStripCylinderL2Equivalence20261026b
open ActualQuotientInfinityCylinderFourier20261026b
open NormalizedCuspCylinderL220261026b NormalizedCuspCylinderFourier20261026b
open NormalizedCuspCompactFourierFubini20261026b CuspUpperBandMixedFourierConvergence20261026b

local instance : Fact (0 < (1 : ℝ)) := ⟨zero_lt_one⟩

def normalizedFrameCylinderExtension (N : ℕ) [NeZero N] (hN : 0 < N)
    (g : SL(2, ℤ)) {Y : ℝ} (hY : 1 < Y) (f : QuotientL2 N) : CylinderL2 :=
  restrictedZeroExtensionVector cylinderMeasure (closedCylinderTail Y)
    (closedCylinderTail_measurable Y) (normalizedCuspCylinder N hN g hY f)

theorem normalizedFrameCylinderExtension_norm (N : ℕ) [NeZero N] (hN : 0 < N)
    (g : SL(2, ℤ)) {Y : ℝ} (hY : 1 < Y) (f : QuotientL2 N) :
    ‖normalizedFrameCylinderExtension N hN g hY f‖ = ‖normalizedCuspCylinder N hN g hY f‖ :=
  (restrictedZeroExtension cylinderMeasure (closedCylinderTail Y)
    (closedCylinderTail_measurable Y)).norm_map _

def normalizedFrameHeightCoefficient (N : ℕ) [NeZero N] (hN : 0 < N)
    (g : SL(2, ℤ)) {Y : ℝ} (hY : 1 < Y) (f : QuotientL2 N) (m : ℤ) : HeightL2 :=
  cylinderCoefficient m (normalizedFrameCylinderExtension N hN g hY f)

theorem normalizedFrameHeightCoefficient_norm_le (N : ℕ) [NeZero N] (hN : 0 < N)
    (g : SL(2, ℤ)) {Y : ℝ} (hY : 1 < Y) (f : QuotientL2 N) (m : ℤ) :
    ‖normalizedFrameHeightCoefficient N hN g hY f m‖ ≤ ‖f‖ := by
  have hm : ‖cylinderCoefficient m‖ ≤ 1 := by
    rw [cylinderCoefficient, ContinuousLinearMap.adjoint.norm_map]
    exact (modeEmbedding m).norm_toContinuousLinearMap_le
  calc
    _ ≤ ‖cylinderCoefficient m‖ * ‖normalizedFrameCylinderExtension N hN g hY f‖ :=
      (cylinderCoefficient m).le_opNorm _
    _ ≤ 1*‖normalizedFrameCylinderExtension N hN g hY f‖ :=
      mul_le_mul_of_nonneg_right hm (norm_nonneg _)
    _ = ‖normalizedCuspCylinder N hN g hY f‖ := by
      rw [one_mul, normalizedFrameCylinderExtension_norm]
    _ ≤ ‖f‖ := normalizedCuspCylinder_norm_le N hN g hY f

theorem normalizedFrameHeightCoefficient_ae_high (N : ℕ) [NeZero N] (hN : 0 < N)
    (g : SL(2, ℤ)) {Y : ℝ} (hY : 1 < Y) (f : QuotientL2 N) (m : ℤ) :
    normalizedFrameHeightCoefficient N hN g hY f m =ᵐ[heightMeasure.restrict (closedHeightTail Y)]
      (fun y : PositiveHeight => frameFourier N hN g f m (y : ℝ)) := by
  let U := normalizedCuspCylinder N hN g hY f
  let E := normalizedFrameCylinderExtension N hN g hY f
  have he : E =ᵐ[cylinderMeasure.restrict (closedCylinderTail Y)] U := by
    filter_upwards [ae_restrict_of_ae (restrictedZeroExtensionVector_ae cylinderMeasure
      (closedCylinderTail Y) (closedCylinderTail_measurable Y) U),
      ae_restrict_mem (closedCylinderTail_measurable Y)] with p hp hpt
    simpa only [Set.indicator_of_mem hpt] using hp
  rw [closedCylinderTail_measure_product] at he
  have hswap : ∀ᵐ p : PositiveHeight × UnitAddCircle
      ∂(heightMeasure.restrict (closedHeightTail Y)).prod AddCircle.haarAddCircle,
      E (p.2,p.1) = U (p.2,p.1) :=
    Measure.measurePreserving_swap.quasiMeasurePreserving.ae he
  filter_upwards [ae_restrict_of_ae (cylinderCoefficient_ae m E),
    ae_ae_of_ae_prod hswap, normalizedCuspCylinder_all_coefficients N hN g hY f]
      with y hy hsection hphysical
  change (cylinderCoefficient m E) y = _
  rw [hy]
  change AddCircle.fourierCoeff (fun x : UnitAddCircle => E (x,y)) m = _
  rw [congrFun (AddCircle.fourierCoeff_congr_ae hsection) m]
  exact hphysical.2 m

/-- True infinity endpoint for ALL actual normalized-frame Fourier
coefficients, including the ORIGINAL actual horocycle mean m=0. -/
theorem actual_frameFourier_memLp_high_height (N : ℕ) [NeZero N] (hN : 0 < N)
    (g : SL(2, ℤ)) {Y : ℝ} (hY : 1 < Y) (f : QuotientL2 N) (m : ℤ) :
    MemLp (fun y : PositiveHeight => frameFourier N hN g f m (y : ℝ)) 2
      (heightMeasure.restrict (closedHeightTail Y)) :=
  ((normalizedFrameHeightCoefficient N hN g hY f m).memLp.mono_measure
    Measure.restrict_le_self).congr (normalizedFrameHeightCoefficient_ae_high N hN g hY f m)

end
end ImbalancedChen.Part3.NormalizedCuspFourierHeightL220261026b
