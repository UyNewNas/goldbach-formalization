import ImbalancedChen.Part3ActualFullCuspEnergyImage

/-!
SOURCE_ONLY / UNCOMPILED / ZERO FORMAL CREDIT / READY_FALSE.
TRANSITIVE immutable be3646/0f1f DOTS API HOLD preserved.

Nonzero eigenspaces of the actual constrained compact R are exactly the
ORIGINAL native R eigenspaces lying in the FULL original cusp subspace.
The known nonzero eigenspan/form-image closure theorem and the newly
derived full image identification give cuspidal completeness. The same
statement is transported to the sole shared ORIGINAL full-cusp restricted
resolvent, without replacing it by a separately defined compact operator.
This is cuspidal completeness ONLY: no full-L2 or Eisenstein assertion,
nor the separately owned conversion from resolvent mu to native lambda.
-/

namespace ImbalancedChen.Part3.ActualFullCuspEigenspanCompleteness20261026b
noncomputable section
open Set Module End
open Gamma0ActualSmoothQuotientCore20261025a Gamma0ActualWeakRieszResolvent20261025a
open AllNormalizedCuspAnnihilator20261026b
open ActualAllFrameCuspCompactEmbedding20261026b
open ActualAllFrameCompactVariationalResolvent20261026b
open ActualAllFrameEnergyImageSpectralSplit20261026b
open ActualAllFrameOriginalResolventReduction20261026b
open ActualFullCuspResolvent20261026b ActualFullCuspEnergyImage20261026b

/-- The actual constrained nonzero eigenspaces are ORIGINAL R cusp
eigenspaces. The cusp-membership direction uses the proved form image. -/
theorem nonzero_constrained_eigenspace_eq_original_cusp
    (N : ℕ) [NeZero N] (hN : 0 < N) (μ : ℂ) (hμ : μ ≠ 0) :
    eigenspace (actualAllFrameVariationalResolvent N hN).toLinearMap μ =
      (allFrameCuspSubspace N hN) ⊓ eigenspace (actualGammaResolvent N).toLinearMap μ := by
  ext f
  constructor
  · intro hf
    have hspan : f ∈ actualNonzeroVariationalEigenSpan N hN :=
      (le_iSup (fun ν : {ν : ℂ // ν ≠ 0} =>
        eigenspace (actualAllFrameVariationalResolvent N hN).toLinearMap ν.val) ⟨μ,hμ⟩) hf
    have hcusp : f ∈ allFrameCuspSubspace N hN :=
      actualAllFrameEnergyImage_le_cusp N hN
        (actualNonzeroVariationalEigenSpan_le_energyImage N hN hspan)
    refine ⟨hcusp, mem_eigenspace_iff.mpr ?_⟩
    have he := mem_eigenspace_iff.mp hf
    rw [actual_constrained_resolvent_eq_original_on_cusp N hN f hcusp] at he
    exact he
  · rintro ⟨hcusp, hf⟩
    apply mem_eigenspace_iff.mpr
    rw [actual_constrained_resolvent_eq_original_on_cusp N hN f hcusp]
    exact mem_eigenspace_iff.mp hf

def actualOriginalCuspNonzeroEigenSpan (N : ℕ) [NeZero N] (hN : 0 < N) :
    Submodule ℂ (QuotientL2 N) :=
  ⨆ μ : {μ : ℂ // μ ≠ 0}, (allFrameCuspSubspace N hN) ⊓
    eigenspace (actualGammaResolvent N).toLinearMap μ.val

theorem original_cusp_eigenspan_eq_variational_span (N : ℕ) [NeZero N] (hN : 0 < N) :
    actualOriginalCuspNonzeroEigenSpan N hN = actualNonzeroVariationalEigenSpan N hN := by
  apply iSup_congr
  intro μ
  exact (nonzero_constrained_eigenspace_eq_original_cusp N hN μ.val μ.property).symm

/-- Nonzero ORIGINAL resolvent cusp modes are complete in the ENTIRE
actual cusp annihilator, not just an unidentified form-image closure. -/
theorem original_nonzero_cusp_eigenspan_closure_eq_full_cusp
    (N : ℕ) [NeZero N] (hN : 0 < N) :
    (actualOriginalCuspNonzeroEigenSpan N hN).topologicalClosure =
      allFrameCuspSubspace N hN := by
  rw [original_cusp_eigenspan_eq_variational_span,
    actual_nonzero_eigenspan_closure_eq_energyImage, actualAllFrameEnergyImage_eq_full_cusp]

def actualFullCuspNonzeroEigenSpan (N : ℕ) [NeZero N] (hN : 0 < N) :
    Submodule ℂ (ActualFullCuspL2 N hN) :=
  ⨆ μ : {μ : ℂ // μ ≠ 0}, eigenspace (actualFullCuspResolvent N hN).toLinearMap μ.val

theorem full_cusp_eigenspace_map_eq_original_inf (N : ℕ) [NeZero N] (hN : 0 < N)
    (μ : ℂ) :
    (eigenspace (actualFullCuspResolvent N hN).toLinearMap μ).map
        (allFrameCuspSubspace N hN).subtype =
      (allFrameCuspSubspace N hN) ⊓ eigenspace (actualGammaResolvent N).toLinearMap μ := by
  ext f
  constructor
  · rintro ⟨v, hv, rfl⟩
    refine ⟨v.property, mem_eigenspace_iff.mpr ?_⟩
    exact congrArg (fun u : ActualFullCuspL2 N hN => (u : QuotientL2 N))
      (mem_eigenspace_iff.mp hv)
  · rintro ⟨hcusp, hf⟩
    refine ⟨⟨f,hcusp⟩, mem_eigenspace_iff.mpr (Subtype.ext ?_), rfl⟩
    exact mem_eigenspace_iff.mp hf

theorem full_cusp_eigenspan_map_eq_original_span (N : ℕ) [NeZero N] (hN : 0 < N) :
    (actualFullCuspNonzeroEigenSpan N hN).map (allFrameCuspSubspace N hN).subtype =
      actualOriginalCuspNonzeroEigenSpan N hN := by
  unfold actualFullCuspNonzeroEigenSpan actualOriginalCuspNonzeroEigenSpan
  rw [Submodule.map_iSup]
  apply iSup_congr
  intro μ
  exact full_cusp_eigenspace_map_eq_original_inf N hN μ.val

/-- Completeness inside the FULL original cuspidal Hilbert space for
the sole shared ORIGINAL restricted resolvent. -/
theorem full_cusp_nonzero_eigenspan_closure_eq_top (N : ℕ) [NeZero N] (hN : 0 < N) :
    (actualFullCuspNonzeroEigenSpan N hN).topologicalClosure = ⊤ := by
  apply le_antisymm le_top
  intro f hf
  change f ∈ closure (actualFullCuspNonzeroEigenSpan N hN : Set (ActualFullCuspL2 N hN))
  rw [Metric.mem_closure_iff]
  intro ε hε
  have hamb : (f : QuotientL2 N) ∈
      (actualOriginalCuspNonzeroEigenSpan N hN).topologicalClosure := by
    rw [original_nonzero_cusp_eigenspan_closure_eq_full_cusp]
    exact f.property
  change (f : QuotientL2 N) ∈ closure
    (actualOriginalCuspNonzeroEigenSpan N hN : Set (QuotientL2 N)) at hamb
  obtain ⟨u, hu, hdist⟩ := Metric.mem_closure_iff.mp hamb ε hε
  rw [← full_cusp_eigenspan_map_eq_original_span N hN] at hu
  obtain ⟨v, hv, hvu⟩ := hu
  refine ⟨v, hv, ?_⟩
  change dist (f : QuotientL2 N) (v : QuotientL2 N) < ε
  rw [hvu]
  exact hdist

end
end ImbalancedChen.Part3.ActualFullCuspEigenspanCompleteness20261026b
