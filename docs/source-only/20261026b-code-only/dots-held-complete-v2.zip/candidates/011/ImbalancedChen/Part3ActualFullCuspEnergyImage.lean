import ImbalancedChen.Part3ActualFullCuspResolvent
import ImbalancedChen.Part3ActualAllFrameOriginalResolventReduction

/-!
SOURCE_ONLY / UNCOMPILED / ZERO FORMAL CREDIT / READY_FALSE.
TRANSITIVE immutable be3646/0f1f DOTS API HOLD preserved.

The original constrained compact-resolvent kernel is exactly the FULL
actual cusp orthogonal complement, derived from the actual operator
identity R_constrained=ORIGINAL_R*P_C and original injectivity. Its known
kernel/form-image identity then proves closure(actual form image)=ENTIRE
actual cusp subspace. The true Riesz lift also proves dense range of the
same physical form inclusion with full-cusp codomain. No density premise.
-/

namespace ImbalancedChen.Part3.ActualFullCuspEnergyImage20261026b
noncomputable section
open Set
open Gamma0ActualSmoothQuotientCore20261025a Gamma0ActualEnergyCompletion20261025a
open Gamma0ActualWeakRieszResolvent20261025a
open AllNormalizedCuspAnnihilator20261026b ActualAllFrameResolventInvariance20261026b
open ActualAllFrameCuspCompactEmbedding20261026b
open ActualAllFrameCompactVariationalResolvent20261026b
open ActualAllFrameEnergyImageSpectralSplit20261026b
open ActualAllFrameOriginalResolventReduction20261026b
open ActualFullCuspResolvent20261026b

theorem actual_constrained_kernel_eq_full_cusp_orthogonal
    (N : ℕ) [NeZero N] (hN : 0 < N) :
    (actualAllFrameVariationalResolvent N hN).ker = (allFrameCuspSubspace N hN)ᗮ := by
  have hker : (actualAllFrameVariationalResolvent N hN).ker =
      (actualAllFrameCuspProjection N hN).ker := by
    ext f
    change actualAllFrameVariationalResolvent N hN f = 0 ↔
      actualAllFrameCuspProjection N hN f = 0
    rw [actual_constrained_resolvent_eq_original_projection_apply]
    constructor
    · intro hf
      apply actualGammaResolvent_injective N
      simpa only [map_zero] using hf
    · intro hf
      rw [hf, map_zero]
  rw [hker]
  exact Submodule.ker_starProjection (allFrameCuspSubspace N hN)

/-- Equality with the ENTIRE original all-frame annihilator, not merely
an unnamed closed subspace of it. -/
theorem actualAllFrameEnergyImage_eq_full_cusp (N : ℕ) [NeZero N] (hN : 0 < N) :
    actualAllFrameEnergyImage N hN = allFrameCuspSubspace N hN := by
  letI : CompleteSpace (actualAllFrameEnergyImage N hN) :=
    (actualAllFrameEnergyImage_closed N hN).completeSpace_coe
  have horth : (actualAllFrameEnergyImage N hN)ᗮ = (allFrameCuspSubspace N hN)ᗮ :=
    (actual_variational_kernel_eq_energyImage_orthogonal N hN).symm.trans
      (actual_constrained_kernel_eq_full_cusp_orthogonal N hN)
  have hd := congrArg (fun K : Submodule ℂ (QuotientL2 N) => Kᗮ) horth
  simpa only [Submodule.orthogonal_orthogonal] using hd

/-- The EXISTING actual physical form inclusion, with its codomain
restricted to the full original cusp Hilbert space. -/
def actualFullCuspEnergyInclusion (N : ℕ) [NeZero N] (hN : 0 < N) :
    actualAllFrameEnergySubspace N hN →L[ℂ] ActualFullCuspL2 N hN :=
  (actualAllFrameInclusion N hN).codRestrict (allFrameCuspSubspace N hN)
    (fun e => e.property)

@[simp] theorem actualFullCuspEnergyInclusion_coe (N : ℕ) [NeZero N] (hN : 0 < N)
    (e : actualAllFrameEnergySubspace N hN) :
    (actualFullCuspEnergyInclusion N hN e : QuotientL2 N) =
      physicalProjection N (e : EnergyCompletion N) := rfl

/-- Every original full-cusp resolvent output has a genuine cuspidal
form lift, supplied by ORIGINAL actualRieszLift. -/
theorem actualFullCuspResolvent_range_subset_energyInclusion_range
    (N : ℕ) [NeZero N] (hN : 0 < N) :
    range (actualFullCuspResolvent N hN) ⊆ range (actualFullCuspEnergyInclusion N hN) := by
  rintro u ⟨f, rfl⟩
  have hc : physicalProjection N (actualRieszLift N (f : QuotientL2 N)) ∈
      allFrameCuspSubspace N hN := by
    rw [← actualGammaResolvent_apply]
    exact actualGammaResolvent_mem_allFrameCuspSubspace N hN f f.property
  let e : actualAllFrameEnergySubspace N hN := ⟨actualRieszLift N (f : QuotientL2 N), hc⟩
  refine ⟨e, Subtype.ext ?_⟩
  exact (actualGammaResolvent_apply N (f : QuotientL2 N)).symm

/-- Actual form-image density in FULL C, obtained from the already proved
self-adjoint injective ORIGINAL restricted resolvent, with no hDense input. -/
theorem actualFullCuspEnergyInclusion_denseRange (N : ℕ) [NeZero N] (hN : 0 < N) :
    DenseRange (actualFullCuspEnergyInclusion N hN) :=
  (actualFullCuspResolvent_denseRange N hN).mono
    (actualFullCuspResolvent_range_subset_energyInclusion_range N hN)

end
end ImbalancedChen.Part3.ActualFullCuspEnergyImage20261026b
