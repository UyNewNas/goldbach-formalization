import ImbalancedChen.Part3ActualFullCuspCompactResolvent
import ImbalancedChen.Part3Gamma0ActualFriedrichsOperator

/-! SOURCE ONLY / UNCOMPILED / ZERO FORMAL CREDIT.
TRANSITIVE DOTS HOLD: original analytic1a3/be3646/mean0f1f chain.
A native unbounded self-adjoint nonnegative operator on the FULL original
all-frame cusp Hilbert space is constructed from the SOLE shared ORIGINAL
resolvent restriction. Its graph is EXACTLY the original Gamma Friedrichs
graph on pairs of cusp vectors. The native domain is dense, (I+A_C) is
onto with actual compact R_C as inverse. No invariance, density, spectral
conversion or graph comparison is a premise. This is not a full-L2 or
Eisenstein spectral-completeness assertion. -/

namespace ImbalancedChen.Part3.ActualFullCuspFriedrichs20261026b
noncomputable section
open Set
open Gamma0ActualSmoothQuotientCore20261025a Gamma0ActualFriedrichsOperator20261025a
open ActualFullCuspResolvent20261026b ActualFullCuspCompactResolvent20261026b
open GenericFriedrichsOperator20261025a

def actualFullCuspFriedrichs (N : ℕ) [NeZero N] (hN : 0 < N) :
    ActualFullCuspL2 N hN →ₗ.[ℂ] ActualFullCuspL2 N hN :=
  friedrichsR (actualFullCuspResolvent N hN)

theorem actualFullCuspFriedrichs_domain (N : ℕ) [NeZero N] (hN : 0 < N) :
    (actualFullCuspFriedrichs N hN).domain = (actualFullCuspResolvent N hN).range :=
  friedrichsR_domain (actualFullCuspResolvent N hN)

theorem actualFullCuspFriedrichs_mem_graph_iff (N : ℕ) [NeZero N] (hN : 0 < N)
    {u v : ActualFullCuspL2 N hN} :
    (u,v) ∈ (actualFullCuspFriedrichs N hN).graph ↔ actualFullCuspResolvent N hN (u+v)=u :=
  friedrichsR_mem_graph_iff (actualFullCuspResolvent N hN) (actualFullCuspResolvent_injective N hN)

/-- Exact ORIGINAL native operator identification on pairs of FULL cusp
vectors, with no assumption about an auxiliary constrained resolvent. -/
theorem actualFullCuspFriedrichs_graph_iff_original (N : ℕ) [NeZero N] (hN : 0 < N)
    {u v : ActualFullCuspL2 N hN} :
    (u,v) ∈ (actualFullCuspFriedrichs N hN).graph ↔
      ((u : QuotientL2 N),(v : QuotientL2 N)) ∈ (actualGammaFriedrichs N).graph := by
  rw [actualFullCuspFriedrichs_mem_graph_iff,actualGammaFriedrichs_mem_graph_iff]
  constructor
  · intro h
    exact congrArg (fun w : ActualFullCuspL2 N hN => (w : QuotientL2 N)) h
  · intro h
    apply Subtype.ext
    exact h

theorem actualFullCuspFriedrichs_isClosed (N : ℕ) [NeZero N] (hN : 0 < N) :
    (actualFullCuspFriedrichs N hN).IsClosed :=
  friedrichsR_isClosed (actualFullCuspResolvent N hN) (actualFullCuspResolvent_injective N hN)

theorem actualFullCuspFriedrichs_isSelfAdjoint (N : ℕ) [NeZero N] (hN : 0 < N) :
    IsSelfAdjoint (actualFullCuspFriedrichs N hN) :=
  friedrichsR_isSelfAdjoint (actualFullCuspResolvent N hN)
    (actualFullCuspResolvent_selfAdjoint N hN) (actualFullCuspResolvent_injective N hN)

theorem actualFullCuspFriedrichs_dense_domain (N : ℕ) [NeZero N] (hN : 0 < N) :
    Dense ((actualFullCuspFriedrichs N hN).domain : Set (ActualFullCuspL2 N hN)) :=
  friedrichsR_dense_domain (actualFullCuspResolvent N hN)
    (actualFullCuspResolvent_selfAdjoint N hN) (actualFullCuspResolvent_injective N hN)

theorem actualFullCuspFriedrichs_graph_nonneg (N : ℕ) [NeZero N] (hN : 0 < N)
    {u v : ActualFullCuspL2 N hN} (huv : (u,v) ∈ (actualFullCuspFriedrichs N hN).graph) :
    0 ≤ (inner ℂ u v).re :=
  friedrichsR_graph_nonneg (actualFullCuspResolvent N hN)
    (actualFullCuspResolvent_injective N hN) (actualFullCuspResolvent_firm N hN) huv

theorem actualFullCuspFriedrichs_nonneg (N : ℕ) [NeZero N] (hN : 0 < N)
    (u : (actualFullCuspFriedrichs N hN).domain) :
    0 ≤ (inner ℂ (u : ActualFullCuspL2 N hN) (actualFullCuspFriedrichs N hN u)).re :=
  friedrichsR_nonneg (actualFullCuspResolvent N hN)
    (actualFullCuspResolvent_injective N hN) (actualFullCuspResolvent_firm N hN) u

def actualFullCuspResolventPoint (N : ℕ) [NeZero N] (hN : 0 < N)
    (f : ActualFullCuspL2 N hN) : (actualFullCuspFriedrichs N hN).domain :=
  resolventPoint (actualFullCuspResolvent N hN) f

theorem actualFullCuspFriedrichs_apply_resolvent (N : ℕ) [NeZero N] (hN : 0 < N)
    (f : ActualFullCuspL2 N hN) :
    actualFullCuspFriedrichs N hN (actualFullCuspResolventPoint N hN f) = f-actualFullCuspResolvent N hN f :=
  friedrichsR_apply_image (actualFullCuspResolvent N hN) (actualFullCuspResolvent_injective N hN) f

theorem actualFullCuspFriedrichs_shift_surjective (N : ℕ) [NeZero N] (hN : 0 < N)
    (f : ActualFullCuspL2 N hN) :
    ∃ u : (actualFullCuspFriedrichs N hN).domain, (u : ActualFullCuspL2 N hN)+actualFullCuspFriedrichs N hN u=f :=
  friedrichsR_shift_surjective (actualFullCuspResolvent N hN) (actualFullCuspResolvent_injective N hN) f

end
end ImbalancedChen.Part3.ActualFullCuspFriedrichs20261026b
