import ImbalancedChen.Part3ActualAllFrameOriginalResolventReduction

/-!
SOURCE ONLY / UNCOMPILED / ZERO FORMAL CREDIT / TRANSITIVE DOTS HOLD.
The ENERGY orthogonal projection onto the genuine original completed-form
all-frame cusp subspace. Its commutation with the ORIGINAL Riesz lift is
derived from proved analytic original-resolvent cusp preservation and the
actual weak Riesz identity on the physical orthogonal complement. No form
invariance or projected lift identity is a hypothesis.
-/
namespace ImbalancedChen.Part3.ActualAllFrameEnergyProjection20261026b
noncomputable section
open Set
open Gamma0ActualSmoothQuotientCore20261025a Gamma0ActualEnergyCompletion20261025a
open Gamma0ActualWeakRieszResolvent20261025a ActualAllFrameCuspCompactEmbedding20261026b
open AllNormalizedCuspAnnihilator20261026b ActualAllFrameOriginalResolventReduction20261026b
open ActualAllFrameResolventInvariance20261026b

instance actualAllFrameEnergy_complete (N : ℕ) [NeZero N] (hN : 0 < N) :
    CompleteSpace (actualAllFrameEnergySubspace N hN) :=
  (actualAllFrameEnergySubspace_closed N hN).completeSpace_coe

/-- Projection in the ORIGINAL shifted energy Hilbert norm. -/
def actualAllFrameEnergyProjection (N : ℕ) [NeZero N] (hN : 0 < N) :
    EnergyCompletion N →L[ℂ] EnergyCompletion N :=
  (actualAllFrameEnergySubspace N hN).starProjection

theorem actualAllFrameEnergyProjection_range (N : ℕ) [NeZero N] (hN : 0 < N) :
    (actualAllFrameEnergyProjection N hN).range = actualAllFrameEnergySubspace N hN :=
  Submodule.range_starProjection _

theorem actualAllFrameEnergyProjection_selfAdjoint (N : ℕ) [NeZero N] (hN : 0 < N) :
    IsSelfAdjoint (actualAllFrameEnergyProjection N hN) :=
  isSelfAdjoint_starProjection (actualAllFrameEnergySubspace N hN)

/-- The actual adjoint lift of a physical cusp vector is cuspidal in
energy because its physical image is the ORIGINAL resolvent image. -/
theorem actualRieszLift_mem_allFrameEnergy (N : ℕ) [NeZero N] (hN : 0 < N)
    (f : QuotientL2 N) (hf : f ∈ allFrameCuspSubspace N hN) :
    actualRieszLift N f ∈ actualAllFrameEnergySubspace N hN := by
  change physicalProjection N (actualRieszLift N f) ∈ allFrameCuspSubspace N hN
  rw [← actualGammaResolvent_apply]
  exact actualGammaResolvent_mem_allFrameCuspSubspace N hN f hf

/-- Complementary energy orthogonality is proved by ORIGINAL Riesz
testing; no physical form-domain preservation is used here. -/
theorem actualRieszLift_mem_allFrameEnergy_orthogonal (N : ℕ) [NeZero N] (hN : 0 < N)
    (f : QuotientL2 N) (hf : f ∈ (allFrameCuspSubspace N hN)ᗮ) :
    actualRieszLift N f ∈ (actualAllFrameEnergySubspace N hN)ᗮ := by
  intro e he
  rw [actualRieszLift_weak]
  exact hf _ he

/-- Exact pointwise intertwining Q J*=J* P_C for the original maps. -/
theorem actualAllFrameEnergyProjection_riesz_apply (N : ℕ) [NeZero N] (hN : 0 < N)
    (f : QuotientL2 N) :
    actualAllFrameEnergyProjection N hN (actualRieszLift N f) =
      actualRieszLift N (actualAllFrameCuspProjection N hN f) := by
  change (actualAllFrameEnergySubspace N hN).starProjection (actualRieszLift N f) = _
  apply (actualAllFrameEnergySubspace N hN).eq_starProjection_of_mem_orthogonal
    (actualRieszLift_mem_allFrameEnergy N hN _
      ((allFrameCuspSubspace N hN).starProjection_apply_mem f))
  rw [← map_sub]
  exact actualRieszLift_mem_allFrameEnergy_orthogonal N hN _
    ((allFrameCuspSubspace N hN).sub_starProjection_mem_orthogonal f)

/-- Native continuous-linear-map identity, after the two genuine
subspace statements above have been proved. -/
theorem actualAllFrameEnergyProjection_comp_riesz (N : ℕ) [NeZero N] (hN : 0 < N) :
    (actualAllFrameEnergyProjection N hN).comp (actualRieszLift N) =
      (actualRieszLift N).comp (actualAllFrameCuspProjection N hN) := by
  ext f
  exact actualAllFrameEnergyProjection_riesz_apply N hN f

end
end ImbalancedChen.Part3.ActualAllFrameEnergyProjection20261026b
