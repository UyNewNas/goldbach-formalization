import ImbalancedChen.Part3ActualVariationalCuspEigenmodeConversion
import ImbalancedChen.Part3ActualAllFrameFixedLevelCoercivity

/-! SOURCE ONLY / UNCOMPILED / ZERO FORMAL CREDIT.
TRANSITIVE DOTS API HOLD through unchanged be3646/0f1f suppliers.
The genuine fixed-level all-frame coercivity constant controls the
ORIGINAL Maass eigenvalue attached to each nonzero constructed compact
variational mode. The proof tests the constructed original form lift
against itself. The constant is positive and unquantified for each fixed
N; no numerical gap, uniform level bound or full-Gamma gap is claimed.
-/
namespace ImbalancedChen.Part3.ActualVariationalCuspEigenvalueStrictness20261026b
noncomputable section
open Set Module End
open Gamma0ActualSmoothQuotientCore20261025a Gamma0ActualEnergyCompletion20261025a
open Gamma0ActualFriedrichsOperator20261025a
open ActualAllFrameCuspCompactEmbedding20261026b AllNormalizedCuspAnnihilator20261026b
open ActualAllFrameCompactVariationalResolvent20261026b
open ActualAllFrameVariationalEigenspaces20261026b
open ActualAllFrameFixedLevelCoercivity20261026b
open ActualVariationalCuspEigenmodeConversion20261026b

/-- A fixed ACTUAL level has one strictly positive lower bound for all
nonzero variational modes' ORIGINAL Maass eigenvalues. -/
theorem exists_fixed_level_variational_maass_lower_bound
    (N : ℕ) [NeZero N] (hN : 0 < N) :
    ∃ c : ℝ, 0 < c ∧ ∀ {mu : ℂ}, mu ≠ 0 → ∀ f : QuotientL2 N, f ≠ 0 →
      f ∈ eigenspace (actualAllFrameVariationalResolvent N hN).toLinearMap mu →
      c ≤ variationalMaassEigenvalue mu := by
  obtain ⟨c,hc,hcoercive⟩ := exists_actual_allFrame_physical_coercivity N hN
  refine ⟨c,hc,?_⟩
  intro mu hmu f hf0 hf
  obtain ⟨e,he,hform⟩ := nonzero_eigenvector_has_actual_variational_lift N hN hmu f hf
  have hphys : physicalProjection N (e : EnergyCompletion N) = f := he
  have hbound := hcoercive (e : EnergyCompletion N) e.property
  rw [hphys] at hbound
  have hreal := (variational_eigenvalue_real_positive_le_one N hN hmu f hf0 hf).1
  have hshift : mu⁻¹-1 = (variationalMaassEigenvalue mu : ℂ) := by
    simp only [variationalMaassEigenvalue,Complex.ofReal_sub,Complex.ofReal_inv,
      Complex.ofReal_one,← hreal]
  have hself := hform e
  rw [he,hshift,inner_self_eq_norm_sq_to_K] at hself
  have henergy : (actualDirichletPair N (e : EnergyCompletion N)
      (e : EnergyCompletion N)).re = variationalMaassEigenvalue mu*‖f‖^2 := by
    rw [hself]
    simp [Complex.mul_re]
  rw [henergy] at hbound
  exact (mul_le_mul_right (sq_pos_of_pos (norm_pos_iff.mpr hf0))).mp hbound

theorem actual_variational_maass_eigenvalue_pos
    (N : ℕ) [NeZero N] (hN : 0 < N) {mu : ℂ} (hmu : mu ≠ 0)
    (f : QuotientL2 N) (hf0 : f ≠ 0)
    (hf : f ∈ eigenspace (actualAllFrameVariationalResolvent N hN).toLinearMap mu) :
    0 < variationalMaassEigenvalue mu := by
  obtain ⟨c,hc,hbound⟩ := exists_fixed_level_variational_maass_lower_bound N hN
  exact hc.trans_le (hbound hmu f hf0 hf)

/-- The corresponding nonzero compact-resolvent spectral parameter lies
strictly below one, because the ORIGINAL cusp energy is strictly positive. -/
theorem actual_variational_eigenvalue_strict_unit_interval
    (N : ℕ) [NeZero N] (hN : 0 < N) {mu : ℂ} (hmu : mu ≠ 0)
    (f : QuotientL2 N) (hf0 : f ≠ 0)
    (hf : f ∈ eigenspace (actualAllFrameVariationalResolvent N hN).toLinearMap mu) :
    mu = (mu.re : ℂ) ∧ 0 < mu.re ∧ mu.re < 1 := by
  obtain ⟨hreal,hpos,hle⟩ := variational_eigenvalue_real_positive_le_one N hN hmu f hf0 hf
  have hlt : mu.re < 1 := lt_of_le_of_ne hle (by
    intro heq
    have hpositive := actual_variational_maass_eigenvalue_pos N hN hmu f hf0 hf
    have hz : variationalMaassEigenvalue mu = 0 := by
      simp only [variationalMaassEigenvalue,heq,inv_one,sub_self]
    rw [hz] at hpositive
    exact (lt_irrefl (0 : ℝ)) hpositive)
  exact ⟨hreal,hpos,hlt⟩

end
end ImbalancedChen.Part3.ActualVariationalCuspEigenvalueStrictness20261026b
