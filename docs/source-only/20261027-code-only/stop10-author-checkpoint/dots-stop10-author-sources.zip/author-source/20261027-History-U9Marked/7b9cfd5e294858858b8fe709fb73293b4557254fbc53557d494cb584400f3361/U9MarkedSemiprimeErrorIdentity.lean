import ImbalancedChen.U9SemiprimeFibreMultiplicity
import ImbalancedChen.ActualSmallRoughAttachment

-- SOURCE ONLY / UNCOMPILED / ZERO FORMAL CREDIT.
-- A mark can distinguish the two original owners of the same semiprime.
-- It is applied BEFORE pushforward; no mark is reconstructed from a product.
-- The original labels retain all strict cuts, moving ceilings and masks.

namespace ImbalancedChen.U9SemiprimeSwitch

noncomputable section
open scoped BigOperators
open Classical

variable {ι : Type*} [Fintype ι] [DecidableEq ι]

def markedFibre (N : ℕ) (X : ℝ) (mark : P5zU9Triple → ι)
    (a : ι) (m r : ℕ) : Finset P5zU9Triple :=
  (fibre N X m r).filter fun t => mark t = a

def markedWeight (N : ℕ) (X : ℝ) (mark : P5zU9Triple → ι)
    (a : ι) (m r : ℕ) : ℝ :=
  ((markedFibre N X mark a m r).card : ℝ)

-- The swapped label must satisfy BOTH the old source and the actual mark.
-- In particular a mark need not be invariant under swap.
theorem markedFibre_eq_pair_filter {N : ℕ} {X : ℝ} {t : P5zU9Triple}
    (ht : t ∈ labels N X) (mark : P5zU9Triple → ι) (a : ι) :
    markedFibre N X mark a (key t).1 (key t).2 =
      ({t, swap t} : Finset P5zU9Triple).filter
        (fun u => u ∈ labels N X ∧ mark u = a) := by
  rw [markedFibre, fibre_eq_pair_filter ht]
  ext u
  simp only [Finset.mem_filter]
  tauto

theorem markedWeight_bounds (N : ℕ) (X : ℝ) (mark : P5zU9Triple → ι)
    (a : ι) (m r : ℕ) :
    0 ≤ markedWeight N X mark a m r ∧ markedWeight N X mark a m r ≤ 2 := by
  constructor
  · exact Nat.cast_nonneg _
  · have h := (Finset.card_le_card
      (Finset.filter_subset (fun t => mark t = a) (fibre N X m r))).trans
        (fibre_card_le_two N X m r)
    exact_mod_cast h

private theorem key_in_original_carrier {N : ℕ} {X : ℝ}
    {t : P5zU9Triple} (ht : t ∈ labels N X) :
    key t ∈ Finset.range N ×ˢ chenAdditivePrimeCarrier N := by
  have hs := (Finset.mem_filter.mp ht).1
  have hd := p5z_u9_order_source_data hs
  obtain ⟨_, hr⟩ := Finset.mem_product.mp (Finset.mem_filter.mp hd.1).1
  have hpos := (mem_chenAdditivePrimeCarrier.mp hr).2.1.pos
  have hlt := p5z_u9_switchedLabels_product_lt hs
  rw [← key_product t] at hlt
  exact Finset.mem_product.mpr
    ⟨Finset.mem_range.mpr ((Nat.le_mul_of_pos_right _ hpos).trans_lt hlt), hr⟩

-- Genuine joint pushforward. A test can inspect the original mark and
-- both receiver coordinates. The old unmarked pushforward cannot do this.
theorem marked_pushforward (N : ℕ) (X : ℝ) (mark : P5zU9Triple → ι)
    (G : ι → ℕ → ℕ → ℝ) :
    (∑ a, ∑ m ∈ Finset.range N, ∑ r ∈ chenAdditivePrimeCarrier N,
      markedWeight N X mark a m r * G a m r) =
      ∑ t ∈ labels N X, G (mark t) (key t).1 (key t).2 := by
  let receiver : Finset (ι × (ℕ × ℕ)) :=
    Finset.univ ×ˢ (Finset.range N ×ˢ chenAdditivePrimeCarrier N)
  have hf := Finset.sum_fiberwise_of_maps_to
    (s := labels N X) (t := receiver)
    (g := fun t => (mark t, key t))
    (fun t ht => Finset.mem_product.mpr
      ⟨Finset.mem_univ _, key_in_original_carrier ht⟩)
    (fun t => G (mark t) (key t).1 (key t).2)
  rw [← hf]
  simp only [receiver, Finset.sum_product]
  apply Finset.sum_congr rfl
  intro a _
  apply Finset.sum_congr rfl
  intro m _
  apply Finset.sum_congr rfl
  intro r _
  have heq : ((labels N X).filter fun t => (mark t, key t) = (a, (m, r))) =
      markedFibre N X mark a m r := by
    ext t
    simp only [markedFibre, fibre, Finset.mem_filter, Prod.mk.injEq]
    tauto
  rw [heq]
  calc
    _ = ∑ _t ∈ markedFibre N X mark a m r, G a m r := by
      simp only [markedWeight, Finset.sum_const, nsmul_eq_mul]
    _ = _ := by
      apply Finset.sum_congr rfl
      intro t ht
      obtain ⟨htf, hmark⟩ := Finset.mem_filter.mp ht
      have hk := (Finset.mem_filter.mp htf).2
      rw [hmark, hk]

-- This raw row includes every residue, including nonunits. Its zero-row
-- theorem below uses arithmetic, rather than placing a zero gate in its definition.
def markedRowError (N : ℕ) (X : ℝ) (mark : P5zU9Triple → ι)
    (a : ι) (m d : ℕ) : ℝ :=
  ∑ r ∈ chenAdditivePrimeCarrier N, markedWeight N X mark a m r *
    ((if Nat.ModEq d (m * r) N then 1 else 0) -
      (if Nat.Coprime (m * r) d then 1 else 0) / (Nat.totient d : ℝ))

theorem markedRowError_eq_zero_of_nonunit (N : ℕ) (X : ℝ)
    (mark : P5zU9Triple → ι) (a : ι) {m d : ℕ}
    (hd : 0 < d) (hN : Nat.Coprime N d) (hm : ¬ Nat.Coprime m d) :
    markedRowError N X mark a m d = 0 := by
  unfold markedRowError
  apply Finset.sum_eq_zero
  intro r _
  have hAP : ¬ Nat.ModEq d (m * r) N := by
    rw [product_AP_iff hd hN]
    exact fun h => hm h.1
  have hcop : ¬ Nat.Coprime (m * r) d := by
    rw [Nat.coprime_mul_iff_left]
    exact fun h => hm h.1
  simp only [if_neg hAP, if_neg hcop, zero_div, sub_self, mul_zero]

theorem markedRowError_eq_primitive_AP (N : ℕ) (X : ℝ)
    (mark : P5zU9Triple → ι) (a : ι) {m d : ℕ}
    (hd : 0 < d) (hN : Nat.Coprime N d) (hm : Nat.Coprime m d) :
    markedRowError N X mark a m d =
      (∑ r ∈ (chenAdditivePrimeCarrier N).filter
        (fun r => Nat.ModEq d r (residue N m d)), markedWeight N X mark a m r) -
      (∑ r ∈ (chenAdditivePrimeCarrier N).filter
        (fun r => Nat.Coprime r d), markedWeight N X mark a m r) /
          (Nat.totient d : ℝ) := by
  simp only [markedRowError, Finset.sum_filter, Finset.sum_div,
    ← Finset.sum_sub_distrib]
  apply Finset.sum_congr rfl
  intro r _
  rw [product_AP_iff hd hN, Nat.coprime_mul_iff_left]
  simp only [hm, true_and]
  split_ifs <;> ring

-- Exact error budget on an arbitrary label-dependent positive marked family.
-- sigma may vanish; no division by a mark mass or norm occurs.
theorem signedError_eq_marked_rows (N : ℕ) (X : ℝ)
    (mark : P5zU9Triple → ι) (sigma : ι → ℝ)
    (Q : Finset ℕ) (rho : ℕ → ℝ) :
    p5z_labelledDistributionError (labels N X) p5z_u9_product
        (fun t => sigma (mark t)) N Q rho =
      ∑ a, sigma a * ∑ m ∈ Finset.range N,
        ∑ d ∈ Q, rho d * markedRowError N X mark a m d := by
  unfold p5z_labelledDistributionError p5z_labelledCongruenceMass
    p5z_labelledCoprimeMass
  simp only [Finset.sum_div, ← Finset.sum_sub_distrib]
  have hrow (d : ℕ) :
      (∑ t ∈ labels N X,
        ((if Nat.ModEq d (p5z_u9_product t) N then sigma (mark t) else 0) -
          (if Nat.Coprime (p5z_u9_product t) d then sigma (mark t) else 0) /
            (Nat.totient d : ℝ))) =
        ∑ a, sigma a * ∑ m ∈ Finset.range N, markedRowError N X mark a m d := by
    calc
      _ = ∑ t ∈ labels N X, sigma (mark t) *
          ((if Nat.ModEq d ((key t).1 * (key t).2) N then 1 else 0) -
            (if Nat.Coprime ((key t).1 * (key t).2) d then 1 else 0) /
              (Nat.totient d : ℝ)) := by
        apply Finset.sum_congr rfl
        intro t _
        rw [key_product]
        split_ifs <;> ring
      _ = ∑ a, ∑ m ∈ Finset.range N, ∑ r ∈ chenAdditivePrimeCarrier N,
          markedWeight N X mark a m r * (sigma a *
            ((if Nat.ModEq d (m * r) N then 1 else 0) -
              (if Nat.Coprime (m * r) d then 1 else 0) /
                (Nat.totient d : ℝ))) :=
        (marked_pushforward N X mark _).symm
      _ = _ := by
        simp only [markedRowError, Finset.mul_sum]
        apply Finset.sum_congr rfl
        intro a _
        apply Finset.sum_congr rfl
        intro m _
        apply Finset.sum_congr rfl
        intro r _
        ring
  simp_rw [hrow, Finset.mul_sum]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro a _
  rw [Finset.sum_comm]
  simp only [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro m _
  apply Finset.sum_congr rfl
  intro d _
  ring

-- The same signed rho is summed inside each marked/semiprime error budget.
-- No pointwise-in-modulus error bound or analytical saving is assumed.
theorem abs_signedError_le_marked_budgets (N : ℕ) (X : ℝ)
    (mark : P5zU9Triple → ι) (sigma : ι → ℝ) (hsigma : ∀ a, 0 ≤ sigma a)
    (Q : Finset ℕ) (rho : ℕ → ℝ) :
    |p5z_labelledDistributionError (labels N X) p5z_u9_product
        (fun t => sigma (mark t)) N Q rho| ≤
      ∑ a, sigma a * ∑ m ∈ Finset.range N,
        |∑ d ∈ Q, rho d * markedRowError N X mark a m d| := by
  rw [signedError_eq_marked_rows]
  apply (Finset.abs_sum_le_sum_abs _ _).trans
  apply Finset.sum_le_sum
  intro a _
  rw [abs_mul, abs_of_nonneg (hsigma a)]
  exact mul_le_mul_of_nonneg_left (Finset.abs_sum_le_sum_abs _ _) (hsigma a)

-- Literal actual physical rho: the full carrier is positive and coprime
-- to N by its construction. Thus every nonunit semiprime row above is zero.
theorem actual_rho_marked_error_identity (N cap : ℕ) (X w z L : ℝ)
    (retain : List ℕ → Bool) (mark : P5zU9Triple → ι) (sigma : ι → ℝ) :
    p5z_labelledDistributionError (labels N X) p5z_u9_product
        (fun t => sigma (mark t)) N (actualSmallRoughModuli retain N cap w z)
        (actualSmallRoughRho retain N cap w z L) =
      ∑ a, sigma a * ∑ m ∈ Finset.range N,
        ∑ d ∈ actualSmallRoughModuli retain N cap w z,
          actualSmallRoughRho retain N cap w z L d * markedRowError N X mark a m d :=
  signedError_eq_marked_rows N X mark sigma _ _

theorem actual_nonunit_marked_row_zero (N cap : ℕ) (X w z : ℝ)
    (retain : List ℕ → Bool) (mark : P5zU9Triple → ι) (a : ι) {m d : ℕ}
    (hd : d ∈ actualSmallRoughModuli retain N cap w z) (hm : ¬ Nat.Coprime m d) :
    markedRowError N X mark a m d = 0 := by
  exact markedRowError_eq_zero_of_nonunit N X mark a
    (Nat.pos_of_ne_zero (actualSmallRoughModuli_squarefree _ _ _ _ _ hd).ne_zero)
    (actualSmallRoughModuli_coprime_target _ _ _ _ _ hd).symm hm

end
end ImbalancedChen.U9SemiprimeSwitch
