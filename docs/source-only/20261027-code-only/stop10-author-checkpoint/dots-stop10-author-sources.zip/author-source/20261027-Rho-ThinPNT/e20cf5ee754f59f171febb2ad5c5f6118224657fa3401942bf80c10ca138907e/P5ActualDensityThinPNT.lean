import ImbalancedChen.P5ThinExceptionalPrimePNT
import ImbalancedChen.P5RoughPartitionDensityStripBound

-- SOURCE_ONLY / UNCOMPILED_ZERO_CREDIT.
-- The quantitative moving-endpoint PNT supplier is inserted into the
-- actual SAME-pair physical density sum, on the original FULL modulus
-- support. No absolute small-beta sum is introduced. No SF rewrite,
-- original adopted-mask alteration, enhanced sieve function, or new cap
-- is used. The finite source identities already retain those choices.

namespace ImbalancedChen.P5Z.ActualDensityThinPNT20261027
noncomputable section
open Classical Real
open scoped BigOperators
open RoughPartitionStripAbsoluteMass RoughPartitionDensityStripBound
open OriginalRoughPartitionedCoefficient OriginalRoughPartitionDensityError
open ThinExceptionalPrimePNT20261027

-- One quantitative PNT constant and threshold precede every retained
-- policy, modulus support, enumeration cap, mesh and moving strip width.
theorem exists_actual_partition_density_PNT_bound (K : ℝ) :
    ∃ C T : ℝ, 0 < C ∧ 2 ≤ T ∧
      ∀ (N cap : ℕ), 1 < N →
      ∀ (retainOdd : List ℕ → Bool) (a b B : ℝ) (mesh : ℕ) (delta : ℝ),
      a ≤ b → 0 < delta → T ≤ (N : ℝ) ^ (b - delta) →
      |physicalDensitySum
          (actualSmallRoughModuli retainOdd N cap ((N : ℝ) ^ a) ((N : ℝ) ^ b))
          (actualSmallRoughRho retainOdd N cap ((N : ℝ) ^ a) ((N : ℝ) ^ b) B) -
        physicalDensitySum
          (actualSmallRoughModuli retainOdd N cap ((N : ℝ) ^ a) ((N : ℝ) ^ b))
          (fun q => actualSmallRoughRho retainOdd N cap
              ((N : ℝ) ^ a) ((N : ℝ) ^ b) B q *
            roughPartitionMass N ((N : ℝ) ^ a) a b mesh delta q)| ≤
        actualSmallPairMagnitude N cap ((N : ℝ) ^ a) B *
          ((∏ p ∈ roughPrimeFinset N cap ((N : ℝ) ^ a) ((N : ℝ) ^ b),
              (1 + 1 / ((p : ℝ) - 1))) *
            ((2 / ((N : ℝ) ^ (b - delta) * log ((N : ℝ) ^ (b - delta)))) *
              (((N : ℝ) ^ b - (N : ℝ) ^ (b - delta)) +
                C * ((N : ℝ) ^ b / (log ((N : ℝ) ^ b)) ^ K +
                  (N : ℝ) ^ (b - delta) /
                    (log ((N : ℝ) ^ (b - delta))) ^ K)))) := by
  obtain ⟨C, T, hC, hT, hstrip⟩ := exists_actual_upper_strip_PNT_bound K
  refine ⟨C, T, hC, hT, ?_⟩
  intro N cap hN retainOdd a b B mesh delta hab hdelta hlow
  have hNR : (1 : ℝ) < N := by exact_mod_cast hN
  have hAU : (N : ℝ) ^ (b - delta) ≤ (N : ℝ) ^ b :=
    rpow_le_rpow_of_exponent_le hNR.le (by linarith)
  have hpnt := hstrip N cap a b delta hlow hAU
  have hEuler : 0 ≤ ∏ p ∈ roughPrimeFinset N cap ((N : ℝ) ^ a) ((N : ℝ) ^ b),
      (1 + 1 / ((p : ℝ) - 1)) := by
    apply Finset.prod_nonneg
    intro p hp
    have hp2 : (2 : ℝ) ≤ p := by
      exact_mod_cast (mem_roughPrimeFinset.mp hp).2.1.two_le
    have hpred : 0 < (p : ℝ) - 1 := by linarith
    positivity
  have hPair : 0 ≤ actualSmallPairMagnitude N cap ((N : ℝ) ^ a) B := by
    exact (abs_nonneg _).trans (le_max_left _ _)
  exact (actual_partition_density_strip_bound hN retainOdd a b B mesh delta hab hdelta).trans
    (mul_le_mul_of_nonneg_left (mul_le_mul_of_nonneg_left hpnt hEuler) hPair)

end
end ImbalancedChen.P5Z.ActualDensityThinPNT20261027
