import ImbalancedChen.P5ThinExceptionalPrimePNT
import Mathlib.Analysis.Complex.Exponential

-- SOURCE_ONLY / UNCOMPILED_ZERO_CREDIT.
-- Explicit shrinking-width version of the moving-endpoint PNT estimate.
-- The geometric input delta*log N <= 1 is a scalar cutoff condition,
-- never a prime-sum or density hypothesis. This estimate applies directly
-- to varying delta; no passage from fixed-width convergence is made.

namespace ImbalancedChen.P5Z.ThinExceptionalLogWidth20261027
noncomputable section
open Classical Real
open scoped BigOperators
open RoughPartitionStripAbsoluteMass ThinExceptionalPrimePNT20261027

theorem exists_actual_upper_strip_log_width_bound (K : ℝ) (hK : 0 ≤ K) :
    ∃ C T : ℝ, 0 < C ∧ 2 ≤ T ∧
      ∀ (N cap : ℕ), 1 < N → ∀ (a b delta : ℝ),
      0 ≤ delta → delta * log (N : ℝ) ≤ 1 →
      T ≤ (N : ℝ) ^ (b - delta) →
      (∑ p ∈ upperPrimeStrip N cap a b delta, 1 / ((p : ℝ) - 1)) ≤
        (4 * delta * log (N : ℝ) +
          8 * C / (log ((N : ℝ) ^ (b - delta))) ^ K) /
            log ((N : ℝ) ^ (b - delta)) := by
  obtain ⟨C, T, hC, hT, hPNT⟩ := exists_actual_upper_strip_PNT_bound K
  refine ⟨C, T, hC, hT, ?_⟩
  intro N cap hN a b delta hdelta hwidth hlow
  let A : ℝ := (N : ℝ) ^ (b - delta)
  let U : ℝ := (N : ℝ) ^ b
  let y : ℝ := delta * log (N : ℝ)
  have hn : (1 : ℝ) < N := by exact_mod_cast hN
  have hn0 : (0 : ℝ) < N := zero_lt_one.trans hn
  have hA2 : 2 ≤ A := hT.trans hlow
  have hA0 : 0 < A := by linarith
  have hLA : 0 < log A := log_pos (by linarith)
  have hy : 0 ≤ y := mul_nonneg hdelta (log_pos hn).le
  have hAU : A ≤ U := rpow_le_rpow_of_exponent_le hn.le (by linarith)
  have hidentity : U = A * exp y := by
    dsimp [U, A, y]
    rw [rpow_def_of_pos hn0, rpow_def_of_pos hn0, ← exp_add]
    congr 1
    ring
  have hexp : exp y - 1 ≤ 2 * y := by
    have h := abs_exp_sub_one_le (show |y| ≤ 1 by rwa [abs_of_nonneg hy])
    rw [abs_of_nonneg hy] at h
    exact (le_abs_self _).trans h
  have hgap : U - A ≤ 2 * A * y := by
    rw [hidentity]
    nlinarith [mul_le_mul_of_nonneg_left hexp hA0.le]
  have hAy : A * y ≤ A := by
    simpa using mul_le_mul_of_nonneg_left (show y ≤ 1 from hwidth) hA0.le
  have hU3 : U ≤ 3 * A := by nlinarith
  have hlog : log A ≤ log U := log_le_log hA0 hAU
  have hden : (log A) ^ K ≤ (log U) ^ K :=
    rpow_le_rpow hLA.le hlog hK
  have hden0 : 0 < (log A) ^ K := rpow_pos_of_pos hLA K
  have hdenU0 : 0 < (log U) ^ K := rpow_pos_of_pos (hLA.trans_le hlog) K
  have hUterm : U / (log U) ^ K ≤ 3 * A / (log A) ^ K := by
    exact (div_le_div_of_nonneg_left (hA0.le.trans hAU) hden0 hden).trans
      (div_le_div_of_nonneg_right hU3 hden0.le)
  have hbracket : (U - A) + C * (U / (log U) ^ K + A / (log A) ^ K) ≤
      A * (2 * y + 4 * C / (log A) ^ K) := by
    have hc := mul_le_mul_of_nonneg_left hUterm hC.le
    nlinarith
  have hmul := mul_le_mul_of_nonneg_left hbracket
    (show 0 ≤ 2 / (A * log A) by positivity)
  have hp := hPNT N cap a b delta hlow hAU
  change (∑ p ∈ upperPrimeStrip N cap a b delta, 1 / ((p : ℝ) - 1)) ≤
    (4 * delta * log (N : ℝ) + 8 * C / (log A) ^ K) / log A
  apply hp.trans
  convert hmul using 1 <;> dsimp [y] <;>
    field_simp [hA0.ne', hLA.ne', hden0.ne'] <;> ring

end
end ImbalancedChen.P5Z.ThinExceptionalLogWidth20261027

