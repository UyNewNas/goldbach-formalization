import ImbalancedChen.Part3ThetaArbitraryLogPower
import ImbalancedChen.P5RoughPartitionStripAbsoluteMass

-- SOURCE_ONLY / UNCOMPILED_ZERO_CREDIT.
-- A quantitative PNT supplier for the actual strict upper rough strip.
-- The constant and threshold precede both endpoints, the target, its cap,
-- the original rough lower wall, and the strip width. No fixed-width
-- Mertens limit is used. Target deletion and any truncation of cap can
-- only decrease the positive mass. The marked lower endpoint is strict.

namespace ImbalancedChen.P5Z.ThinExceptionalPrimePNT20261027
noncomputable section
open Classical Real Filter
open scoped BigOperators Topology
open RoughPartitionStripAbsoluteMass
open ImbalancedChen.Part3.ThetaArbitraryLogPower20261026b

private def thetaPrimes (x : ℝ) : Finset ℕ :=
  (Finset.Icc 0 (Nat.floor x)).filter Nat.Prime

private theorem mem_thetaPrimes {x : ℝ} (hx : 0 ≤ x) {p : ℕ} :
    p ∈ thetaPrimes x ↔ p.Prime ∧ (p : ℝ) ≤ x := by
  simp only [thetaPrimes, Finset.mem_filter, Finset.mem_Icc, Nat.zero_le,
    true_and, Nat.le_floor_iff hx]
  tauto

private theorem thetaPrimes_sum (x : ℝ) :
    (∑ p ∈ thetaPrimes x, log (p : ℝ)) = Chebyshev.theta x := by
  exact (Chebyshev.theta_eq_sum_Icc x).symm

-- A finite subset may retain any arithmetic filters, including p ∤ N.
-- Its weighted logarithmic mass is bounded by the exact theta increment.
theorem finite_strict_window_log_mass_le (S : Finset ℕ) {A U : ℝ}
    (hA : 0 ≤ A) (hAU : A ≤ U)
    (hS : ∀ p ∈ S, p.Prime ∧ A < (p : ℝ) ∧ (p : ℝ) ≤ U) :
    (∑ p ∈ S, log (p : ℝ)) ≤ Chebyshev.theta U - Chebyshev.theta A := by
  have hU : 0 ≤ U := hA.trans hAU
  have hsub : thetaPrimes A ⊆ thetaPrimes U := by
    intro p hp
    obtain ⟨hp, hpA⟩ := (mem_thetaPrimes hA).mp hp
    exact (mem_thetaPrimes hU).mpr ⟨hp, hpA.trans hAU⟩
  have hSsub : S ⊆ thetaPrimes U \ thetaPrimes A := by
    intro p hp
    obtain ⟨hpP, hpA, hpU⟩ := hS p hp
    apply Finset.mem_sdiff.mpr
    refine ⟨(mem_thetaPrimes hU).mpr ⟨hpP, hpU⟩, ?_⟩
    intro hp'
    exact (not_le_of_gt hpA) ((mem_thetaPrimes hA).mp hp').2
  have hsum := Finset.sum_sdiff (f := fun p : ℕ => log (p : ℝ)) hsub
  rw [thetaPrimes_sum, thetaPrimes_sum] at hsum
  have hle : (∑ p ∈ S, log (p : ℝ)) ≤
      ∑ p ∈ thetaPrimes U \ thetaPrimes A, log (p : ℝ) := by
    apply Finset.sum_le_sum_of_subset_of_nonneg hSsub
    intro p hp _
    have hpP := ((mem_thetaPrimes hU).mp (Finset.mem_sdiff.mp hp).1).1
    exact log_nonneg (by exact_mod_cast hpP.one_lt.le)
  linarith

-- The density denominator p-1 costs at most two, including p=2.
theorem finite_strict_window_reciprocal_le_theta (S : Finset ℕ) {A U : ℝ}
    (hA : 2 ≤ A) (hAU : A ≤ U)
    (hS : ∀ p ∈ S, p.Prime ∧ A < (p : ℝ) ∧ (p : ℝ) ≤ U) :
    (∑ p ∈ S, 1 / ((p : ℝ) - 1)) ≤
      (2 / (A * log A)) * (Chebyshev.theta U - Chebyshev.theta A) := by
  have hAp : 0 < A := by linarith
  have hlogA : 0 < log A := log_pos (by linarith)
  have hD : 0 < A * log A := mul_pos hAp hlogA
  calc
    _ ≤ ∑ p ∈ S, (2 / (A * log A)) * log (p : ℝ) := by
      apply Finset.sum_le_sum
      intro p hp
      obtain ⟨hpP, hpA, _⟩ := hS p hp
      have hp2 : (2 : ℝ) ≤ p := by exact_mod_cast hpP.two_le
      have hpred : 0 < (p : ℝ) - 1 := by linarith
      have hlog : log A ≤ log (p : ℝ) := log_le_log hAp hpA.le
      have hprod : A * log A ≤ 2 * ((p : ℝ) - 1) * log (p : ℝ) := by
        have h1 := mul_le_mul_of_nonneg_right
          (show A ≤ 2 * ((p : ℝ) - 1) by linarith) hlogA.le
        have h2 := mul_le_mul_of_nonneg_left hlog
          (show 0 ≤ 2 * ((p : ℝ) - 1) by positivity)
        exact h1.trans h2
      apply (div_le_iff₀ hpred).mpr
      have hquot : (1 : ℝ) ≤
          (2 * ((p : ℝ) - 1) * log (p : ℝ)) / (A * log A) :=
        (le_div_iff₀ hD).mpr (by simpa using hprod)
      convert hquot using 1 <;> ring
    _ = (2 / (A * log A)) * (∑ p ∈ S, log (p : ℝ)) :=
      (Finset.mul_sum S _ _).symm
    _ ≤ _ := mul_le_mul_of_nonneg_left
      (finite_strict_window_log_mass_le S hAp.le hAU hS) (by positivity)

-- Quantitative endpoint error, uniform even when A and U move together.
-- No desired window bound or theta error is an input: genuine medium PNT
-- supplies the two endpoint errors with an arbitrary real logarithmic power.
theorem exists_actual_upper_strip_PNT_bound (K : ℝ) :
    ∃ C T : ℝ, 0 < C ∧ 2 ≤ T ∧
      ∀ (N cap : ℕ) (a b delta : ℝ),
      T ≤ (N : ℝ) ^ (b - delta) →
      (N : ℝ) ^ (b - delta) ≤ (N : ℝ) ^ b →
      (∑ p ∈ upperPrimeStrip N cap a b delta, 1 / ((p : ℝ) - 1)) ≤
        (2 / ((N : ℝ) ^ (b - delta) * log ((N : ℝ) ^ (b - delta)))) *
          (((N : ℝ) ^ b - (N : ℝ) ^ (b - delta)) +
            C * ((N : ℝ) ^ b / (log ((N : ℝ) ^ b)) ^ K +
              (N : ℝ) ^ (b - delta) / (log ((N : ℝ) ^ (b - delta))) ^ K)) := by
  obtain ⟨C, hC, hevent⟩ := exists_theta_error_logPower K
  obtain ⟨T, hT⟩ := eventually_atTop.mp hevent
  refine ⟨C, max 2 T, hC, le_max_left _ _, ?_⟩
  intro N cap a b delta hlow hAU
  let A : ℝ := (N : ℝ) ^ (b - delta)
  let U : ℝ := (N : ℝ) ^ b
  have hA : 2 ≤ A := (le_max_left _ _).trans hlow
  have hAT : T ≤ A := (le_max_right _ _).trans hlow
  have hUT : T ≤ U := hAT.trans hAU
  have hAe := hT A hAT
  have hUe := hT U hUT
  have hinc : Chebyshev.theta U - Chebyshev.theta A ≤
      (U - A) + C * (U / (log U) ^ K + A / (log A) ^ K) := by
    have hUa := (abs_le.mp hUe).2
    have hAa := (abs_le.mp hAe).1
    linarith
  have hfinite := finite_strict_window_reciprocal_le_theta
    (upperPrimeStrip N cap a b delta) hA hAU (by
      intro p hp
      obtain ⟨hp, hstrict⟩ := Finset.mem_filter.mp hp
      have hd := mem_roughPrimeFinset.mp hp
      exact ⟨hd.2.1, hstrict, hd.2.2.2.2.le⟩)
  exact hfinite.trans (mul_le_mul_of_nonneg_left hinc
    (by have : 0 < log A := log_pos (by linarith); positivity))

end
end ImbalancedChen.P5Z.ThinExceptionalPrimePNT20261027

