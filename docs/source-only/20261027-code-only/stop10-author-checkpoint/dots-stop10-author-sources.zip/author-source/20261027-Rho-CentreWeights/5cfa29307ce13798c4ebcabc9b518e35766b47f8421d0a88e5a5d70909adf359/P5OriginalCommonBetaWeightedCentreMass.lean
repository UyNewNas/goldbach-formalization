import ImbalancedChen.P5OriginalCommonBetaMainWallReserve
import ImbalancedChen.P5ZU1011JointNearCapPrimeReserve

-- SOURCE ONLY / UNCOMPILED_ZERO_CREDIT.
-- The residual coefficients are summed with their actual signs BEFORE
-- taking an absolute value. No absolute beta-coefficient mass is used.
namespace ImbalancedChen.P5Z.OriginalCommonBetaWeightedCentreMass
noncomputable section
open Classical Filter Set Topology
open scoped BigOperators
open U11Integral U1011OriginalSixteenArithmeticProducts
open U1011OriginalSixteenJointNearCapCompiler (ordinaryTuples)
open OriginalCommonBetaActualParameters OriginalCommonBetaMainWallReserve
open OriginalJointPresievedCompiler
open OriginalFixedCommonBetaDensityEnvelope
open U1011AdaptivePrimeError JointNearCapPrimeReserve

def absoluteRowMass (n N : ℕ) (eta : ℚ) (nu epsilon : ℝ)
    (E : ℕ × ℕ → Prop) : ℝ :=
  ∑ t ∈ ordinaryTuples n N E, |rowMain n N eta nu epsilon t|

def weightedTest (n N : ℕ) (eta : ℚ) (nu epsilon : ℝ)
    (E : ℕ × ℕ → Prop) (f : LogFour → ℝ) : ℝ :=
  ∑ t ∈ ordinaryTuples n N E, rowMain n N eta nu epsilon t * f (coordinates N t)

def weightedPhysicalSigma (n N : ℕ) (eta : ℚ) (nu epsilon : ℝ)
    (E : ℕ × ℕ → Prop) (f : LogFour → ℝ) (q : ℕ) : ℝ :=
  ∑ a ∈ (jointMarks n N eta (smallCutoff nu epsilon N) E).filter
      (fun a => OriginalOrdinaryPresievedSigma.modulus a = q),
    OriginalOrdinaryPresievedSigma.rowCoefficient n N eta (smallCutoff nu epsilon N)
      (betaLevel nu epsilon N) a.1 a.2 * f (coordinates N a.1)

def physicalFibreMean (n N : ℕ) (eta : ℚ) (nu epsilon : ℝ)
    (E : ℕ × ℕ → Prop) (f : LogFour → ℝ) : ℝ :=
  (∑ q ∈ jointSupport n N eta (smallCutoff nu epsilon N) E,
    weightedPhysicalSigma n N eta nu epsilon E f q * (1 / (Nat.totient q : ℝ))) *
      Real.log (N : ℝ) / singularSeries N

-- Literal complete physical modulus fullPrefix(t)*r. This equality
-- records precisely which original rho is used by the sampling payment.
theorem weightedTest_eq_full_physical_rows (n N : ℕ) (eta : ℚ) (nu epsilon : ℝ)
    (E : ℕ × ℕ → Prop) (f : LogFour → ℝ) :
    weightedTest n N eta nu epsilon E f =
      (∑ t ∈ ordinaryTuples n N E,
        ∑ r ∈ OriginalOrdinaryPresievedSigma.rowSupport n N eta (smallCutoff nu epsilon N) t,
          OriginalOrdinaryPresievedSigma.rowCoefficient n N eta (smallCutoff nu epsilon N)
            (betaLevel nu epsilon N) t r *
            (1 / (Nat.totient (fullPrefix t * r) : ℝ)) * f (coordinates N t)) *
              Real.log (N : ℝ) / singularSeries N := by
  unfold weightedTest rowMain
  simp_rw [Finset.sum_mul, Finset.sum_div]
  apply Finset.sum_congr rfl
  intro t ht
  apply Finset.sum_congr rfl
  intro r hr
  ring

-- Exact full-q fibre assembly, retaining coincident physical moduli and
-- every original mark. No new squarefree mask or quotient modulus enters.
theorem weightedTest_eq_physicalFibreMean (n N : ℕ) (eta : ℚ) (nu epsilon : ℝ)
    (E : ℕ × ℕ → Prop) (f : LogFour → ℝ) :
    weightedTest n N eta nu epsilon E f = physicalFibreMean n N eta nu epsilon E f := by
  have hf := Finset.sum_fiberwise_of_maps_to
    (s := jointMarks n N eta (smallCutoff nu epsilon N) E)
    (t := jointSupport n N eta (smallCutoff nu epsilon N) E)
    (g := OriginalOrdinaryPresievedSigma.modulus)
    (fun a ha => Finset.mem_image_of_mem OriginalOrdinaryPresievedSigma.modulus ha)
    (fun a => OriginalOrdinaryPresievedSigma.rowCoefficient n N eta (smallCutoff nu epsilon N)
      (betaLevel nu epsilon N) a.1 a.2 *
      (1 / (Nat.totient (OriginalOrdinaryPresievedSigma.modulus a) : ℝ)) * f (coordinates N a.1))
  have hrows :
      (∑ t ∈ ordinaryTuples n N E,
        ∑ r ∈ OriginalOrdinaryPresievedSigma.rowSupport n N eta (smallCutoff nu epsilon N) t,
          OriginalOrdinaryPresievedSigma.rowCoefficient n N eta (smallCutoff nu epsilon N)
            (betaLevel nu epsilon N) t r *
            (1 / (Nat.totient (fullPrefix t * r) : ℝ)) * f (coordinates N t)) =
      ∑ q ∈ jointSupport n N eta (smallCutoff nu epsilon N) E,
        weightedPhysicalSigma n N eta nu epsilon E f q * (1 / (Nat.totient q : ℝ)) := by
    rw [← Finset.sum_sigma]
    change (∑ a ∈ jointMarks n N eta (smallCutoff nu epsilon N) E,
      OriginalOrdinaryPresievedSigma.rowCoefficient n N eta (smallCutoff nu epsilon N)
        (betaLevel nu epsilon N) a.1 a.2 *
        (1 / (Nat.totient (OriginalOrdinaryPresievedSigma.modulus a) : ℝ)) * f (coordinates N a.1)) = _
    rw [← hf]
    apply Finset.sum_congr rfl
    intro q hq
    unfold weightedPhysicalSigma
    rw [Finset.sum_mul]
    apply Finset.sum_congr rfl
    intro a ha
    rw [(Finset.mem_filter.mp ha).2]
    ring
  rw [weightedTest_eq_full_physical_rows, hrows]
  rfl

theorem original_prefixMass_le_box (n N : ℕ) (hN : 1 < N)
    (E : ℕ × ℕ → Prop) :
    (∑ t ∈ ordinaryTuples n N E, 1 / (Nat.totient (fullPrefix t) : ℝ)) ≤
      actualPrimeBoxMass N (fun _ : Fin 4 => (417 / 5000 : ℝ))
        (fun _ => (59 / 250 : ℝ)) := by
  have heq : (∑ t ∈ ordinaryTuples n N E, 1 / (Nat.totient (fullPrefix t) : ℝ)) =
      jointMass N E (U1011SameRhoNativePrimeBoxDensity.ordinaryKeep n N) (fun _ => 1) := by
    simp only [jointMass, U1011SameRhoNativePrimeBoxDensity.ordinaryKeep,
      ordinaryTuples, U1011OriginalSixteenJointNativeCompiler.ordinaryTuples,
      Finset.sum_filter]
  rw [heq, jointMass_eq_box hN]
  change (∑ q ∈ BufferedPrimeErrorPayment.tuples N,
    if jointKept N E (U1011SameRhoNativePrimeBoxDensity.ordinaryKeep n N) q
    then BufferedPrimeErrorPayment.weight q * 1 else 0) ≤
      ∑ q ∈ BufferedPrimeErrorPayment.tuples N, BufferedPrimeErrorPayment.weight q
  apply Finset.sum_le_sum
  intro q hq
  split_ifs
  · simp only [mul_one, le_refl]
  · exact actualPrimeBoxWeight_nonneg hq

-- The envelope depends on the ALREADY FIXED common pair. It precedes
-- every later geometric refinement, test, moving original E and N.
theorem exists_uniform_absoluteRowMass_bound (n : ℕ) (eta : ℚ) (heta : 0 < eta)
    (nu epsilon : ℝ) (hnu : 0 < nu) (he : 0 < epsilon)
    (heBudget : epsilon < epsilonBudget n eta nu) :
    ∃ C : ℝ, 0 < C ∧ ∃ N0 : ℕ, 2 ≤ N0 ∧ ∀ N : ℕ, N0 ≤ N → Even N →
      ∀ E : ℕ × ℕ → Prop, absoluteRowMass n N eta nu epsilon E ≤ C := by
  obtain ⟨A, hA, N1, hN1, hrow⟩ :=
    exists_fixed_joint_row_density_envelope n eta heta nu epsilon hnu he heBudget
  obtain ⟨N2, hbox⟩ := eventually_atTop.mp eventually_originalCube_mass_bounded
  have hB : 0 ≤ originalCubeMassBound := by unfold originalCubeMassBound; positivity
  refine ⟨A * (originalCubeMassBound + 1), mul_pos hA (by linarith),
    max N1 N2, hN1.trans (le_max_left _ _), ?_⟩
  intro N hN hEven E
  have hN1' : N1 ≤ N := (le_max_left _ _).trans hN
  have hN2' : N2 ≤ N := (le_max_right _ _).trans hN
  have hlarge : 1 < N := by omega
  have hpoint (t : Four) (ht : t ∈ ordinaryTuples n N E) :
      |rowMain n N eta nu epsilon t| ≤ A * (1 / (Nat.totient (fullPrefix t) : ℝ)) := by
    rw [rowMain_eq_density hlarge heta hnu he heBudget ht,
      abs_div, abs_of_nonneg (Nat.cast_nonneg _)]
    have hb := (hrow N hN1' hEven E t ht).2
    rw [ownerDensity_at_native]
    exact (div_le_div_of_nonneg_right hb (Nat.cast_nonneg _)).trans_eq (by ring)
  calc
    absoluteRowMass n N eta nu epsilon E ≤
        ∑ t ∈ ordinaryTuples n N E, A * (1 / (Nat.totient (fullPrefix t) : ℝ)) :=
      Finset.sum_le_sum hpoint
    _ = A * ∑ t ∈ ordinaryTuples n N E, 1 / (Nat.totient (fullPrefix t) : ℝ) :=
      (Finset.mul_sum _ _ _).symm
    _ ≤ A * actualPrimeBoxMass N (fun _ : Fin 4 => (417 / 5000 : ℝ))
        (fun _ => (59 / 250 : ℝ)) :=
      mul_le_mul_of_nonneg_left (original_prefixMass_le_box n N hlarge E) hA.le
    _ ≤ A * originalCubeMassBound := mul_le_mul_of_nonneg_left (hbox N hN2') hA.le
    _ ≤ A * (originalCubeMassBound + 1) := by nlinarith

end
end ImbalancedChen.P5Z.OriginalCommonBetaWeightedCentreMass
