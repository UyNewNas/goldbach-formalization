import ImbalancedChen.P5OriginalCommonBetaGeometricCentre
import ImbalancedChen.P5PresievedRoughSmoothBoxAtoms

-- SOURCE ONLY / UNCOMPILED_ZERO_CREDIT.
-- The test and its derivative cap are both supplied here by the existing
-- canonical compact smooth atom. All original low/base/removed rows and
-- their full physical rho are retained by weightedTest, uniformly in E.
namespace ImbalancedChen.P5Z.OriginalCommonBetaAtomCentrePayment
noncomputable section
open Classical Set Filter Topology
open scoped BigOperators
open U11Integral U1011OriginalFifteenNativeGridCells
open OriginalCommonBetaActualParameters OriginalCommonBetaGeometricCentre

theorem exists_actual_atom_fderiv_bound (inner : Bool) (δ : ℝ) (hδ : 0 < δ)
    (a b : ℝ) (fine : ℕ) (j : Fin 4 → Fin (fine + 1)) :
    ∃ M : ℝ, 0 ≤ M ∧ ∀ v : LogFour,
      ‖fderiv ℝ (PresievedRoughSmoothBoxAtoms.atom inner δ a b fine j) v‖ ≤ M := by
  obtain ⟨M, hM, hbound⟩ :=
    PresievedRoughSmoothBoxAtoms.exists_atom_derivative_budget hδ inner a b fine j 1
  refine ⟨M, hM, ?_⟩
  intro v
  simpa only [norm_iteratedFDeriv_one] using hbound v

-- A single cap is constructed for the ENTIRE fixed atom family, on both
-- inner/outer sides, before selecting the later sampling mesh or N.
theorem exists_actual_atom_family_fderiv_bound (δ : ℝ) (hδ : 0 < δ)
    (a b : ℝ) (fine : ℕ) :
    ∃ M : ℝ, 0 ≤ M ∧ ∀ (inner : Bool) (j : Grid fine) (v : LogFour),
      ‖fderiv ℝ (PresievedRoughSmoothBoxAtoms.atom inner δ a b fine j) v‖ ≤ M := by
  choose C hC hbound using fun inner : Bool => fun j : Grid fine =>
    exists_actual_atom_fderiv_bound inner δ hδ a b fine j
  let M : ℝ := ∑ inner : Bool, ∑ j : Grid fine, C inner j
  have hrow (inner : Bool) : 0 ≤ ∑ j : Grid fine, C inner j :=
    Finset.sum_nonneg (fun j _ => hC inner j)
  refine ⟨M, Finset.sum_nonneg (fun inner _ => hrow inner), ?_⟩
  intro inner j v
  calc
    _ ≤ C inner j := hbound inner j v
    _ ≤ ∑ k : Grid fine, C inner k :=
      Finset.single_le_sum (fun k _ => hC inner k) (Finset.mem_univ j)
    _ ≤ M := Finset.single_le_sum (fun side _ => hrow side) (Finset.mem_univ inner)

-- No derivative, coefficient norm, cell-error or mean hypothesis remains.
-- The fixed test atom precedes the approximation mesh and N threshold.
theorem exists_actual_atom_weighted_centre_payment
    (n : ℕ) (eta : ℚ) (heta : 0 < eta) (nu epsilon : ℝ)
    (hnu : 0 < nu) (he : 0 < epsilon) (heBudget : epsilon < epsilonBudget n eta nu)
    (inner : Bool) (δ : ℝ) (hδ : 0 < δ) (a b : ℝ)
    (fine : ℕ) (j : Fin 4 → Fin (fine + 1)) (reserve : ℝ) (hreserve : 0 < reserve) :
    ∃ m N0 : ℕ, 2 ≤ N0 ∧ ∀ N : ℕ, N0 ≤ N → Even N → ∀ E : ℕ × ℕ → Prop,
      centreError n N m eta nu epsilon E
        (PresievedRoughSmoothBoxAtoms.atom inner δ a b fine j) < reserve := by
  obtain ⟨M, hM, hderiv⟩ := exists_actual_atom_fderiv_bound inner δ hδ a b fine j
  obtain ⟨m, N0, hN0, hpay⟩ := exists_uniform_weighted_centre_reserve
    n eta heta nu epsilon hnu he heBudget M hM reserve hreserve
  refine ⟨m, N0, hN0, ?_⟩
  intro N hN hEven E
  exact hpay N hN hEven E _
    ((PresievedRoughSmoothBoxAtoms.contDiff_atom inner δ a b fine j).differentiable (by simp)) hderiv

-- One mesh and threshold for every fixed atom label and both sides.
-- The complete original moving mask is still evaluated at its tuple.
theorem exists_actual_atom_family_weighted_centre_payment
    (n : ℕ) (eta : ℚ) (heta : 0 < eta) (nu epsilon : ℝ)
    (hnu : 0 < nu) (he : 0 < epsilon) (heBudget : epsilon < epsilonBudget n eta nu)
    (δ : ℝ) (hδ : 0 < δ) (a b : ℝ) (fine : ℕ) (reserve : ℝ) (hreserve : 0 < reserve) :
    ∃ m N0 : ℕ, 2 ≤ N0 ∧ ∀ N : ℕ, N0 ≤ N → Even N → ∀ E : ℕ × ℕ → Prop,
      ∀ (inner : Bool) (j : Grid fine), centreError n N m eta nu epsilon E
        (PresievedRoughSmoothBoxAtoms.atom inner δ a b fine j) < reserve := by
  obtain ⟨M, hM, hderiv⟩ := exists_actual_atom_family_fderiv_bound δ hδ a b fine
  obtain ⟨m, N0, hN0, hpay⟩ := exists_uniform_weighted_centre_reserve
    n eta heta nu epsilon hnu he heBudget M hM reserve hreserve
  refine ⟨m, N0, hN0, ?_⟩
  intro N hN hEven E inner j
  exact hpay N hN hEven E _
    ((PresievedRoughSmoothBoxAtoms.contDiff_atom inner δ a b fine j).differentiable (by simp))
    (hderiv inner j)

end
end ImbalancedChen.P5Z.OriginalCommonBetaAtomCentrePayment
