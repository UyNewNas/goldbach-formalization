import ImbalancedChen.P5OriginalCommonBetaWeightedCentreMass
import Mathlib.Analysis.Calculus.MeanValue

-- SOURCE ONLY / UNCOMPILED_ZERO_CREDIT.
-- Genuine geometric midpoint evaluation at the original signed rowMain.
-- A derivative supremum is a local analytic primitive, not a hypothesis
-- about an integrated error, density comparison or AP distribution.
namespace ImbalancedChen.P5Z.OriginalCommonBetaGeometricCentre
noncomputable section
open Classical Set Filter Topology
open scoped BigOperators
open U11Integral U1011OriginalSixteenArithmeticProducts
open U1011OriginalFifteenNativeGridCells
open U1011OriginalSixteenJointNearCapCompiler (ordinaryTuples)
open OriginalCommonBetaActualParameters OriginalCommonBetaMainWallReserve
open OriginalCommonBetaWeightedCentreMass

def centre (m : ℕ) (j : Grid m) : LogFour := fun i =>
  (logPrimeMeshLo (lower : ℝ) (upper : ℝ) m j i +
    logPrimeMeshHi (lower : ℝ) (upper : ℝ) m j i) / 2

def sampled (m : ℕ) (f : LogFour → ℝ) (v : LogFour) : ℝ := f (centre m (owner m v))

theorem norm_sub_centre_le {m : ℕ} {v : LogFour} (hv : v ∈ cube) :
    ‖v - centre m (owner m v)‖ ≤ logPrimeMeshStep (lower : ℝ) (upper : ℝ) m / 2 := by
  have hs := logPrimeMeshStep_pos (by norm_num [lower, upper] : (lower : ℝ) < (upper : ℝ)) m
  apply (pi_norm_le_iff_of_nonneg (half_pos hs).le).mpr
  intro i
  have hi := mem_logPrimeMeshCell.mp (owner_mem m hv) i
  have hh := logPrimeMeshHi_eq_lo_add_step (lower : ℝ) (upper : ℝ) m (owner m v) i
  change |v i - centre m (owner m v) i| ≤ _
  unfold centre
  apply abs_le.mpr
  constructor <;> linarith [hi.1, hi.2]

-- Only pointwise differentiability and an actual derivative bound occur.
-- They can be supplied by the existing compact smooth-atom construction.
theorem sampled_error_le_derivative {M : ℝ} (hM : 0 ≤ M) (f : LogFour → ℝ)
    (hdiff : Differentiable ℝ f) (hderiv : ∀ v, ‖fderiv ℝ f v‖ ≤ M)
    (m : ℕ) {v : LogFour} (hv : v ∈ cube) :
    |f v - sampled m f v| ≤ M * (logPrimeMeshStep (lower : ℝ) (upper : ℝ) m / 2) := by
  have hmv : ‖f v - f (centre m (owner m v))‖ ≤ M * ‖v - centre m (owner m v)‖ :=
    Convex.norm_image_sub_le_of_norm_fderiv_le (fun x _ => hdiff x)
      (fun x _ => hderiv x) convex_univ (mem_univ _) (mem_univ _)
  change |f v - f (centre m (owner m v))| ≤ _
  exact hmv.trans (mul_le_mul_of_nonneg_left (norm_sub_centre_le hv) hM)

def centreError (n N m : ℕ) (eta : ℚ) (nu epsilon : ℝ)
    (E : ℕ × ℕ → Prop) (f : LogFour → ℝ) : ℝ :=
  |weightedTest n N eta nu epsilon E f - weightedTest n N eta nu epsilon E (sampled m f)|

theorem centreError_eq_original_physical_density_difference
    (n N m : ℕ) (eta : ℚ) (nu epsilon : ℝ) (E : ℕ × ℕ → Prop) (f : LogFour → ℝ) :
    centreError n N m eta nu epsilon E f =
      |physicalFibreMean n N eta nu epsilon E f -
        physicalFibreMean n N eta nu epsilon E (sampled m f)| := by
  unfold centreError
  rw [weightedTest_eq_physicalFibreMean, weightedTest_eq_physicalFibreMean]

theorem centreError_le_mass {n N m : ℕ} {M : ℝ} (hN : 1 < N)
    (eta : ℚ) (nu epsilon : ℝ) (E : ℕ × ℕ → Prop) (hM : 0 ≤ M)
    (f : LogFour → ℝ) (hdiff : Differentiable ℝ f) (hderiv : ∀ v, ‖fderiv ℝ f v‖ ≤ M) :
    centreError n N m eta nu epsilon E f ≤
      (M * (logPrimeMeshStep (lower : ℝ) (upper : ℝ) m / 2)) *
        absoluteRowMass n N eta nu epsilon E := by
  unfold centreError weightedTest
  rw [← Finset.sum_sub_distrib]
  apply (Finset.abs_sum_le_sum_abs _ _).trans
  calc
    _ ≤ ∑ t ∈ ordinaryTuples n N E, |rowMain n N eta nu epsilon t| *
        (M * (logPrimeMeshStep (lower : ℝ) (upper : ℝ) m / 2)) := by
      apply Finset.sum_le_sum
      intro t ht
      have hv : coordinates N t ∈ cube :=
        U1011OriginalFifteenJointNativeRows.joint_coordinates_cube hN (Finset.mem_filter.mp ht).1
      rw [← mul_sub, abs_mul]
      exact mul_le_mul_of_nonneg_left (sampled_error_le_derivative hM f hdiff hderiv m hv) (abs_nonneg _)
    _ = _ := by rw [← Finset.sum_mul]; unfold absoluteRowMass; ring

-- The common pair precedes M and the reserve; the chosen mesh and target
-- threshold precede EVERY test with this derivative cap and every E.
-- In particular the test may be selected later using N or the mask.
theorem exists_uniform_weighted_centre_reserve (n : ℕ) (eta : ℚ) (heta : 0 < eta)
    (nu epsilon : ℝ) (hnu : 0 < nu) (he : 0 < epsilon)
    (heBudget : epsilon < epsilonBudget n eta nu) (M : ℝ) (hM : 0 ≤ M)
    (reserve : ℝ) (hreserve : 0 < reserve) :
    ∃ m N0 : ℕ, 2 ≤ N0 ∧ ∀ N : ℕ, N0 ≤ N → Even N →
      ∀ E : ℕ × ℕ → Prop, ∀ f : LogFour → ℝ, Differentiable ℝ f →
        (∀ v, ‖fderiv ℝ f v‖ ≤ M) → centreError n N m eta nu epsilon E f < reserve := by
  obtain ⟨C, hC, N0, hN0, hmass⟩ :=
    exists_uniform_absoluteRowMass_bound n eta heta nu epsilon hnu he heBudget
  have hlim : Tendsto (fun m : ℕ =>
      (M * (logPrimeMeshStep (lower : ℝ) (upper : ℝ) m / 2)) * C) atTop (𝓝 0) := by
    simpa using (((tendsto_logPrimeMeshStep (lower : ℝ) (upper : ℝ)).div_const 2).const_mul M).mul_const C
  obtain ⟨m, hm⟩ := (hlim.eventually (gt_mem_nhds hreserve)).exists
  refine ⟨m, N0, hN0, ?_⟩
  intro N hN hEven E f hdiff hderiv
  have hlarge : 1 < N := by omega
  have hstep : 0 ≤ M * (logPrimeMeshStep (lower : ℝ) (upper : ℝ) m / 2) :=
    mul_nonneg hM (half_pos (logPrimeMeshStep_pos (by norm_num [lower, upper]) m)).le
  exact (centreError_le_mass hlarge eta nu epsilon E hM f hdiff hderiv).trans_lt
    ((mul_le_mul_of_nonneg_left (hmass N hN hEven E) hstep).trans_lt hm)

end
end ImbalancedChen.P5Z.OriginalCommonBetaGeometricCentre
