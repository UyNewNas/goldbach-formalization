import ImbalancedChen.Part3NormalizedCuspCompactPoincare
import ImbalancedChen.Part3NativeCuspEffectiveDecomposition
import ImbalancedChen.Part3Gamma0ParabolicEffectiveDecomposition

-- SOURCE ONLY / UNCOMPILED / ZERO FORMAL CREDIT.
-- This is the original sharp half-open strip seed, at Fourier mode zero.
-- The full effective action is reindexed by the actual cusp stabilizer
-- quotient and integer translations. The existing exact strip tiling
-- supplies one integer, including at the strip boundary. No smooth
-- horizontal partition replaces the original physicalFrameSeed.
-- Compact positive height support also gives an explicit y^2 majorant;
-- ORIGINAL allowed-row absolute convergence is paid by Eisenstein at 2.

namespace ImbalancedChen.Part3.NativeOriginalSharpZeroSeedPartition20261027

noncomputable section
open Set MeasureTheory Matrix Matrix.SpecialLinearGroup
open scoped MatrixGroups UpperHalfPlane BigOperators
open ImbalancedChen.Part3.RealEisensteinSeedConvergence
open ImbalancedChen.Part3.PrimitiveEisensteinParameterAnalytic
open ImbalancedChen.Part3.Gamma0GeneralCuspWidth20261025a
open ImbalancedChen.Part3.Gamma0GeneralCuspUnitPeriod20261025a
open ImbalancedChen.Part3.GammaInfinityTranslationStrip20261025a
open ImbalancedChen.Part3.Gamma0ParabolicEffectiveDecomposition20261025a
open ImbalancedChen.Part3.ActualInfinityKloostermanSeed20261025a
open ImbalancedChen.Part3.CompactCuspParabolicL220261025a
open ImbalancedChen.Part3.Gamma0EffectiveActionKernel20261024z
open ImbalancedChen.Part3.Gamma0EffectiveFiniteUnfolding20261025a
open ImbalancedChen.Part3.Gamma0ComplexL1PoincareUnfolding20261025a
open ImbalancedChen.Part3.Gamma0CompactGlobalOverlap20261025a
open ImbalancedChen.Part3.Gamma0QuotientCellPushforward20261025a
open ImbalancedChen.Part3.Gamma0CarrierAESection20261025a
open ImbalancedChen.Part3.NormalizedCuspCompactPoincare20261026b
open ImbalancedChen.Part3.NormalizedCuspCompactQuotientLp20261026b
open ImbalancedChen.Part3.NativeAllCuspEisenstein20261026b
open ImbalancedChen.Part3.NativeCuspAllowedRowCosets20261026b
open ImbalancedChen.Part3.NativeCuspHalfPairNormalization20261026b
open ImbalancedChen.Part3.NativeCuspPoincarePartition20261026b

-- The denominator has no zero on the original compact radial support.
-- Thus no lower-height parameter or majorant is assumed as an input.
theorem compact_positive_profile_sq_bound (ψ : ℝ → ℂ) (hψ : Continuous ψ)
    (hc : HasCompactSupport ψ) (hpos : tsupport ψ ⊆ Ioi (0 : ℝ)) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ y : ℝ, 0 < y → ‖ψ y‖ ≤ C * y ^ 2 := by
  have hquot : ContinuousOn (fun y : ℝ => ‖ψ y‖ / y ^ 2) (tsupport ψ) :=
    hψ.norm.continuousOn.div (continuous_id.pow 2).continuousOn
      (fun y hy => pow_ne_zero 2 (hpos hy).ne')
  obtain ⟨b, hb⟩ := hc.bddAbove_image hquot
  refine ⟨max b 0, le_max_right b 0, ?_⟩
  intro y hy
  by_cases hs : y ∈ tsupport ψ
  · have hratio : ‖ψ y‖ / y ^ 2 ≤ max b 0 :=
      (hb ⟨y, hs, rfl⟩).trans (le_max_left b 0)
    exact (div_le_iff₀ (sq_pos_of_pos hy)).mp hratio
  · rw [image_eq_zero_of_notMem_tsupport hs, norm_zero]
    exact mul_nonneg (le_max_right b 0) (sq_nonneg y)

theorem normalizedSeed_two_norm (N : ℕ) (hN : 0 < N) (g : SL(2, ℤ))
    (z : UpperHalfPlane) (v : PrimitivePair) :
    ‖normalizedSeed N g z v (2 : ℂ)‖ = normalizedBase N g z v ^ 2 := by
  have hb := normalizedBase_pos N hN g z v
  calc
    _ = Real.exp (Real.log (normalizedBase N g z v) * 2) := by
      simp only [normalizedSeed, Complex.norm_exp, Complex.mul_re,
        Complex.ofReal_re, Complex.ofReal_im]
      norm_num
      congr 1
      ring
    _ = normalizedBase N g z v ^ (2 : ℝ) := (Real.rpow_def_of_pos hb 2).symm
    _ = _ := Real.rpow_two _

-- This absolute convergence is for the literal ORIGINAL AllowedPair.
-- In particular it precedes the use of infinite signed-row regrouping.
theorem original_allowed_profile_norm_summable (N : ℕ) (hN : 0 < N)
    (g : SL(2, ℤ)) (ψ : ℝ → ℂ) (hψ : Continuous ψ)
    (hc : HasCompactSupport ψ) (hpos : tsupport ψ ⊆ Ioi (0 : ℝ))
    (z : UpperHalfPlane) :
    Summable (fun v : AllowedPair N g => ‖ψ (normalizedBase N g z v.1)‖) := by
  obtain ⟨C, hC, hbound⟩ := compact_positive_profile_sq_bound ψ hψ hc hpos
  have hmajor := (normalizedSeed_norm_summable N hN g z (2 : ℂ)
    (by norm_num)).mul_left C
  apply Summable.of_nonneg_of_le (fun _ => norm_nonneg _) _ hmajor
  intro v
  rw [normalizedSeed_two_norm N hN]
  exact hbound _ (normalizedBase_pos N hN g z v.1)

theorem original_allowed_profile_summable (N : ℕ) (hN : 0 < N)
    (g : SL(2, ℤ)) (ψ : ℝ → ℂ) (hψ : Continuous ψ)
    (hc : HasCompactSupport ψ) (hpos : tsupport ψ ⊆ Ioi (0 : ℝ))
    (z : UpperHalfPlane) :
    Summable (fun v : AllowedPair N g => ψ (normalizedBase N g z v.1)) :=
  (original_allowed_profile_norm_summable N hN g ψ hψ hc hpos z).of_norm

theorem original_allowed_profile_even (N : ℕ) (g : SL(2, ℤ))
    (z : UpperHalfPlane) (ψ : ℝ → ℂ) (v : AllowedPair N g) :
    ψ (normalizedBase N g z (allowedNeg N g v).1) =
      ψ (normalizedBase N g z v.1) := by
  have hlin : ((-(v.1.1 0) : ℤ) : ℂ) * (z : ℂ) + ((-(v.1.1 1) : ℤ) : ℂ) =
      -((v.1.1 0 : ℂ) * (z : ℂ) + (v.1.1 1 : ℂ)) := by
    push_cast
    ring
  change ψ (positiveBase z (primitiveNeg v.1) / (cuspWidth N g : ℝ)) = _
  simp only [positiveBase, primitiveNeg, Pi.neg_apply, hlin, norm_neg]

def originalRadialCosetSeed (N : ℕ) (g : SL(2, ℤ)) (z : UpperHalfPlane)
    (ψ : ℝ → ℂ) (q : CuspCosets N g) : ℂ :=
  signedSeed N g (fun v => ψ (normalizedBase N g z v.1))
    (original_allowed_profile_even N g z ψ) (cuspAllowedRowEquiv N g q)

theorem originalRadialCosetSeed_projection (N : ℕ) (hN : 0 < N)
    (g : SL(2, ℤ)) (z : UpperHalfPlane) (ψ : ℝ → ℂ)
    (gamma : CongruenceSubgroup.Gamma0 N) :
    originalRadialCosetSeed N g z ψ (Quotient.mk'' gamma) =
      ψ (((normalizedScaling N hN g)⁻¹ • (gamma • z)).im) := by
  change ψ (normalizedBase N g z (allowedBottomRow N g gamma).1) = _
  rw [normalizedBase_allowedBottomRow_eq_height N hN]

theorem originalRadialCosetSeed_representative (N : ℕ) (hN : 0 < N)
    (g : SL(2, ℤ)) (z : UpperHalfPlane) (ψ : ℝ → ℂ) (q : CuspCosets N g) :
    originalRadialCosetSeed N g z ψ q =
      ψ (((normalizedScaling N hN g)⁻¹ • (cuspRepresentative N g q • z)).im) := by
  calc
    _ = originalRadialCosetSeed N g z ψ
        (Quotient.mk'' (cuspRepresentative N g q)) :=
      congrArg (originalRadialCosetSeed N g z ψ) (cuspRepresentative_class N g q).symm
    _ = _ := originalRadialCosetSeed_projection N hN g z ψ _

theorem original_radial_coset_summable (N : ℕ) (hN : 0 < N) (g : SL(2, ℤ))
    (ψ : ℝ → ℂ) (hψ : Continuous ψ) (hc : HasCompactSupport ψ)
    (hpos : tsupport ψ ⊆ Ioi (0 : ℝ)) (z : UpperHalfPlane) :
    Summable (originalRadialCosetSeed N g z ψ) :=
  (cuspAllowedRowEquiv N g).summable_iff.mpr
    (signedSeed_summable N g (fun v => ψ (normalizedBase N g z v.1))
      (original_allowed_profile_even N g z ψ)
      (original_allowed_profile_summable N hN g ψ hψ hc hpos z))

theorem original_half_row_eq_coset_sum (N : ℕ) (hN : 0 < N) (g : SL(2, ℤ))
    (ψ : ℝ → ℂ) (hψ : Continuous ψ) (hc : HasCompactSupport ψ)
    (hpos : tsupport ψ ⊆ Ioi (0 : ℝ)) (z : UpperHalfPlane) :
    (1 / 2 : ℂ) * (∑' v : AllowedPair N g, ψ (normalizedBase N g z v.1)) =
      ∑' q : CuspCosets N g, originalRadialCosetSeed N g z ψ q := by
  rw [tsum_rows_eq_two_cusp_cosets N g (fun v => ψ (normalizedBase N g z v.1))
    (original_allowed_profile_even N g z ψ)
    (original_allowed_profile_summable N hN g ψ hψ hc hpos z)]
  change (1 / 2 : ℂ) * (2 * ∑' q : CuspCosets N g,
    originalRadialCosetSeed N g z ψ q) = _
  ring

-- Compactness of the ORIGINAL physical strip seed justifies the product
-- tsum interchange. It does not assume convergence of a desired identity.
theorem original_sharp_zero_effective_norm_summable (N : ℕ) (hN : 0 < N)
    (g : SL(2, ℤ)) (ψ : ℝ → ℂ) (hc : HasCompactSupport ψ)
    (hpos : tsupport ψ ⊆ Ioi (0 : ℝ)) (z : UpperHalfPlane) :
    Summable (fun e : effectiveGamma0 N =>
      ‖physicalFrameSeed N hN g 0 ψ (effectiveMatrixAction N e z)‖) := by
  obtain ⟨M, hM, hfinite⟩ := compact_seed_uniform_finite_support N
    (physicalFrameSeed N hN g 0 ψ)
    ((cuspSupportK_isCompact ψ hc hpos).image (frameAction_continuous N hN g))
    (physicalFrameSeed_support N hN g 0 ψ)
  obtain ⟨S, hcard, hzero⟩ := hfinite z
  exact summable_of_ne_finset_zero (s := S) (fun e he => by rw [hzero e he, norm_zero])

theorem original_sharp_zero_trace_eq_cosets (N : ℕ) (hN : 0 < N)
    (g : SL(2, ℤ)) (ψ : ℝ → ℂ) (hc : HasCompactSupport ψ)
    (hpos : tsupport ψ ⊆ Ioi (0 : ℝ)) (z : UpperHalfPlane) :
    complexSeedTrace N (physicalFrameSeed N hN g 0 ψ) z =
      ∑' q : CuspCosets N g, originalRadialCosetSeed N g z ψ q := by
  have hs := (original_sharp_zero_effective_norm_summable N hN g ψ hc hpos z).of_norm
  have hprod := (cuspEffectiveEquiv N hN g).summable_iff.mpr hs
  have hprod' : Summable (fun p : CuspCosets N g × ℤ =>
      cuspStripSeed 0 ψ (translate p.2
        ((normalizedScaling N hN g)⁻¹ • (cuspRepresentative N g p.1 • z)))) := by
    apply hprod.congr
    rintro ⟨q, k⟩
    simp only [physicalFrameSeed, cuspPair_normalized_action, translate_eq_vadd]
  change (∑' e : effectiveGamma0 N,
    physicalFrameSeed N hN g 0 ψ (effectiveMatrixAction N e z)) = _
  calc
    _ = ∑' p : CuspCosets N g × ℤ,
        physicalFrameSeed N hN g 0 ψ
          (effectiveMatrixAction N (cuspEffectiveEquiv N hN g p) z) :=
      ((cuspEffectiveEquiv N hN g).tsum_eq _).symm
    _ = ∑' p : CuspCosets N g × ℤ, cuspStripSeed 0 ψ
        (translate p.2 ((normalizedScaling N hN g)⁻¹ • (cuspRepresentative N g p.1 • z))) := by
      apply tsum_congr
      rintro ⟨q, k⟩
      simp only [physicalFrameSeed, cuspPair_normalized_action, translate_eq_vadd]
    _ = ∑' q : CuspCosets N g, ∑' k : ℤ, cuspStripSeed 0 ψ
        (translate k ((normalizedScaling N hN g)⁻¹ • (cuspRepresentative N g q • z))) :=
      hprod'.tsum_prod
    _ = _ := by
      apply tsum_congr
      intro q
      rw [originalRadialCosetSeed_representative N hN]
      have hstrip := periodic_strip_indicator_tsum (fourierRadialSeed 0 ψ)
        (fourierRadialSeed_periodic 0 ψ)
        ((normalizedScaling N hN g)⁻¹ • (cuspRepresentative N g q • z))
      simpa only [cuspStripSeed, fourierRadialSeed, AddCircle.fourier_zero, one_mul] using hstrip

-- The central kernel is counted once in effectiveGamma0. The factor 1/2
-- here is exactly the two ORIGINAL signed rows per actual cusp coset.
theorem original_sharp_zero_trace_eq_half_allowed_rows (N : ℕ) (hN : 0 < N)
    (g : SL(2, ℤ)) (ψ : ℝ → ℂ) (hψ : Continuous ψ)
    (hc : HasCompactSupport ψ) (hpos : tsupport ψ ⊆ Ioi (0 : ℝ))
    (z : UpperHalfPlane) :
    complexSeedTrace N (physicalFrameSeed N hN g 0 ψ) z =
      (1 / 2 : ℂ) * ∑' v : AllowedPair N g, ψ (normalizedBase N g z v.1) := by
  rw [original_sharp_zero_trace_eq_cosets N hN g ψ hc hpos]
  exact (original_half_row_eq_coset_sum N hN g ψ hψ hc hpos z).symm

-- This binds the identity to the actual original quotient Poincare API.
theorem original_sharp_zero_Poincare_projection (N : ℕ) [NeZero N] (hN : 0 < N)
    (g : SL(2, ℤ)) (ψ : ℝ → ℂ) (hψ : Continuous ψ)
    (hc : HasCompactSupport ψ) (hpos : tsupport ψ ⊆ Ioi (0 : ℝ))
    (z : reducedCarrier N) :
    complexPoincare N (physicalFrameSeed N hN g 0 ψ) (reducedProjection N z) =
      (1 / 2 : ℂ) * ∑' v : AllowedPair N g, ψ (normalizedBase N g z v.1) := by
  rw [complexPoincare_projection]
  exact original_sharp_zero_trace_eq_half_allowed_rows N hN g ψ hψ hc hpos z

end
end ImbalancedChen.Part3.NativeOriginalSharpZeroSeedPartition20261027
