import ImbalancedChen.P5ActualSafePhysicalTensorBank

-- SOURCE ONLY / UNCOMPILED / ZERO FORMAL CREDIT.
-- Exact signed MAIN normal form of the ACTUAL weighted tensor coefficient.
-- The physical product, its squarefree condition and the tested finite
-- modulus set survive finite Fubini. Totients separate ONLY under that SF
-- condition. No multiplicative replacement for a nonsquarefree term occurs.
namespace ImbalancedChen.P5Z.ActualSignedTensorPhysicalMain
noncomputable section
open Classical
open scoped BigOperators
open U1011OriginalFifteenNativeGridCells U1011FourDimensionalSmoothBoxAtoms
open OriginalCommonBetaGlobalSafeBank OriginalCommonBetaSafeAtomRealization
open OriginalCommonBetaCanonicalSmoothAtoms OriginalMixedSmoothLabelAssignment
open OriginalPresievedRoughRank OriginalCommonBetaActualParameters
open ActualMixedRejectedPhysicalBounds ActualSafeGlobalCoefficientGlue
open ActualCountWordSafeSplit ActualSafeCountWeightedTensor
open ActualSafeMixedComputedPartition ActualSafeMixedWeightedGroups
open ActualSafeMixedWeightedTensor ActualSafePhysicalCountWord
open ActualSmoothWeightedLabelGamma WeightedCommonBetaAttachment
open AllCountWordNormalization SafeWeightedCountWordNativeValue
open ActualSafePhysicalTensorBank

def tripleCoefficient (P1 P2 P3 : Finset ℕ) (c : ℝ)
    (g1 g2 g3 : ℕ → ℝ) (q : ℕ) : ℝ :=
  ∑ q1∈P1, ∑ q2∈P2, ∑ q3∈P3,
    c*g1 q1*g2 q2*g3 q3*
      (if Squarefree (q1*q2*q3) ∧ q1*q2*q3=q then 1 else 0)

-- Q is an arbitrary finite physical carrier. In particular this formula
-- never silently replaces the physical support by a beta or prime cap.
def tripleMain (Q P1 P2 P3 : Finset ℕ) (c : ℝ)
    (g1 g2 g3 : ℕ → ℝ) : ℝ :=
  ∑ q1∈P1, ∑ q2∈P2, ∑ q3∈P3,
    if Squarefree (q1*q2*q3) ∧ q1*q2*q3∈Q then
      c*(g1 q1/(Nat.totient q1 : ℝ))*
        (g2 q2/(Nat.totient q2 : ℝ))*(g3 q3/(Nat.totient q3 : ℝ))
    else 0

theorem squarefree_product_totient (q1 q2 q3 : ℕ)
    (hs : Squarefree (q1*q2*q3)) :
    (Nat.totient (q1*q2*q3) : ℝ)=
      (Nat.totient q1 : ℝ)*(Nat.totient q2 : ℝ)*(Nat.totient q3 : ℝ) := by
  rw [Nat.totient_mul (Nat.coprime_of_squarefree_mul hs),
    Nat.totient_mul (Nat.coprime_of_squarefree_mul hs.of_mul_left),
    Nat.cast_mul, Nat.cast_mul]

theorem physical_delta_main (Q : Finset ℕ) (q1 q2 q3 : ℕ) (a : ℝ) :
    (∑ q∈Q, (a*(if Squarefree (q1*q2*q3) ∧ q1*q2*q3=q then 1 else 0))/
      (Nat.totient q : ℝ))=
      if Squarefree (q1*q2*q3) ∧ q1*q2*q3∈Q then
        a/((Nat.totient q1 : ℝ)*(Nat.totient q2 : ℝ)*(Nat.totient q3 : ℝ))
      else 0 := by
  by_cases hs : Squarefree (q1*q2*q3)
  · have ht : ∀ q : ℕ,
        (a*(if Squarefree (q1*q2*q3) ∧ q1*q2*q3=q then 1 else 0))/
          (Nat.totient q : ℝ)=
        if q1*q2*q3=q then a/(Nat.totient (q1*q2*q3) : ℝ) else 0 := by
      intro q
      by_cases hq : q1*q2*q3=q
      · subst q
        simp [hs]
      · simp [hs,hq]
    simp_rw [ht]
    simp [Finset.sum_ite_eq',hs,squarefree_product_totient q1 q2 q3 hs]
  · simp [hs]

-- This is the actual reciprocal-totient diagonal calculation, rather than
-- a generic coefficient pairing that leaves the physical delta unevaluated.
theorem triple_physical_density (Q P1 P2 P3 : Finset ℕ) (c : ℝ)
    (g1 g2 g3 : ℕ → ℝ) :
    physicalDensitySum Q (tripleCoefficient P1 P2 P3 c g1 g2 g3)=
      tripleMain Q P1 P2 P3 c g1 g2 g3 := by
  unfold physicalDensitySum tripleCoefficient tripleMain
  simp_rw [Finset.sum_div]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro q1 hq1
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro q2 hq2
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro q3 hq3
  rw [physical_delta_main]
  split_ifs <;> ring

def countMain (Q : Finset ℕ) (n fine mesh N : ℕ) (eta : ℚ)
    (nu0 epsilon s xi : ℝ) (hxi : 0<xi) (inner : Bool)
    (b : BankIndex n fine) (r : ℕ) (m : Fin (mesh+1)→ℕ) (A : ℝ) : ℝ :=
  if hlo : omega nu0 epsilon≤profileCutoff n eta b.1 then
    let w := (N : ℝ)^omega nu0 epsilon
    let B := (N : ℝ)^(nu0*epsilon)
    let primeCap := Nat.ceil ((N : ℝ)^profileCutoff n eta b.1)
    let P := mixedCarrier N eta nu0 epsilon s b primeCap
    let W := OriginalMixedSmoothLabelAssignment.actualWeightNN n eta b.1 N
      (branchSide inner b.2.2.1) s fine b.2.2.2 primeCap w
      (omega nu0 epsilon) (profileCutoff n eta b.1) mesh xi hlo hxi
    let words := computedWords N eta nu0 epsilon inner s b m A
    tripleMain Q (weightedCarrier P words.1) (weightedCarrier P words.2.1)
      (attachedCarrier P words.2.2 N (Nat.ceil w) w)
      (((-1 : ℝ)^r)*(wordFactorial words.1 : ℝ)*(wordFactorial words.2.1 : ℝ)*
        (wordFactorial words.2.2 : ℝ)/(wordFactorial (mixedWord m) : ℝ))
      (gamma P W words.1) (gamma P W words.2.1)
      (attached P W words.2.2 N (Nat.ceil w) r w B)
  else 0

theorem actual_count_tensor_main (Q : Finset ℕ) (n fine mesh N : ℕ) (eta : ℚ)
    (nu0 epsilon s xi : ℝ) (hxi : 0<xi) (inner : Bool)
    (b : BankIndex n fine) (r : ℕ) (m : Fin (mesh+1)→ℕ) (A : ℝ) :
    physicalDensitySum Q (countTensorCoefficient n fine mesh N eta nu0 epsilon s xi hxi inner b r m A)=
      countMain Q n fine mesh N eta nu0 epsilon s xi hxi inner b r m A := by
  unfold countTensorCoefficient countMain
  split_ifs with hlo
  · exact triple_physical_density _ _ _ _ _ _ _ _
  · simp [physicalDensitySum]

def bankMain (Q : Finset ℕ) (inner : Bool) (S : Finset Row) (n N : ℕ)
    (eta : ℚ) (nu0 epsilon xi : ℝ) (hxi : 0<xi) (fine mesh : ℕ) (s A : ℝ) : ℝ :=
  ∑ b∈bank inner S n eta fine s,(atomAt inner n fine s b).sign*
    ∑ r∈Finset.range (rankBound nu0 epsilon+1),
      ∑ m∈safeCounts (omega nu0 epsilon) (profileCutoff n eta b.1) (profileLevel n eta b.1) mesh r,
        countMain Q n fine mesh N eta nu0 epsilon s xi hxi inner b r m A

theorem density_finset_sum {ι : Type*} (Q : Finset ℕ) (I : Finset ι)
    (f : ι → ℕ → ℝ) :
    physicalDensitySum Q (fun q=>∑ i∈I,f i q)=
      ∑ i∈I,physicalDensitySum Q (f i) := by
  unfold physicalDensitySum
  simp_rw [Finset.sum_div]
  rw [Finset.sum_comm]

theorem density_scalar (Q : Finset ℕ) (c : ℝ) (f : ℕ → ℝ) :
    physicalDensitySum Q (fun q=>c*f q)=c*physicalDensitySum Q f := by
  unfold physicalDensitySum
  simp_rw [mul_div_assoc]
  rw [Finset.mul_sum]

theorem actual_signed_tensor_bank_main (Q : Finset ℕ) (inner : Bool)
    (S : Finset Row) (n N : ℕ) (eta : ℚ) (nu0 epsilon xi : ℝ) (hxi : 0<xi)
    (fine mesh : ℕ) (s A : ℝ) :
    physicalDensitySum Q
      (tensorBankCoefficient inner S n N eta nu0 epsilon xi hxi fine mesh s A)=
      bankMain Q inner S n N eta nu0 epsilon xi hxi fine mesh s A := by
  unfold tensorBankCoefficient bankMain
  rw [density_finset_sum]
  apply Finset.sum_congr rfl
  intro b hb
  rw [density_scalar,density_finset_sum]
  congr 1
  apply Finset.sum_congr rfl
  intro r hr
  rw [density_finset_sum]
  apply Finset.sum_congr rfl
  intro m hm
  exact actual_count_tensor_main Q n fine mesh N eta nu0 epsilon s xi hxi inner b r m A

-- The left side is the independently constructed actual SAFE physical
-- bank, not a new surrogate density. The finite physical set is shared
-- literally with the three reserves in the full signed coefficient join.
theorem actual_safe_physical_main {n N fine mesh : ℕ} {eta : ℚ}
    (hN : 1<N) (heta : 0<eta) (inner : Bool) (S : Finset Row) {s : ℝ} (hs : 0<s)
    (hpadding : ∀ j∈U1011OriginalSixteenCommonSmallParameters.selectedCells n,
      padding fine s≤profilePadding n eta j)
    (nu0 epsilon xi : ℝ) (hnu : 0<nu0) (he : 0<epsilon)
    (heBudget : epsilon<epsilonBudget n eta nu0) (hxi : 0<xi)
    (A : ℝ) (hA : 1≤A) (hAu : A≤(N : ℝ)^(1/3 : ℝ)) (Q : Finset ℕ) :
    physicalDensitySum Q
      (safeBankCoefficient inner S n N eta nu0 epsilon xi hxi fine mesh s)=
      bankMain Q inner S n N eta nu0 epsilon xi hxi fine mesh s A := by
  have hp := actual_safeBank_test_eq_tensorBank hN heta inner S hs hpadding
    nu0 epsilon xi hnu he heBudget hxi A hA hAu Q
      (fun q=>1/(Nat.totient q : ℝ))
  have hd : physicalDensitySum Q
        (safeBankCoefficient inner S n N eta nu0 epsilon xi hxi fine mesh s)=
      physicalDensitySum Q
        (tensorBankCoefficient inner S n N eta nu0 epsilon xi hxi fine mesh s A) := by
    simpa only [physicalDensitySum,one_div,div_eq_mul_inv] using hp
  exact hd.trans (actual_signed_tensor_bank_main Q inner S n N eta nu0 epsilon xi hxi fine mesh s A)

end
end ImbalancedChen.P5Z.ActualSignedTensorPhysicalMain
