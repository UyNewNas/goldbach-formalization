import ImbalancedChen.P2LowerFiniteRetainedNodeTable

-- SOURCE ONLY / UNCOMPILED_ZERO_CREDIT.
-- Arrays below are constructed from canonical integer traces. This source
-- does not replay historical numerical arrays or validate an external file.

namespace ImbalancedChen.P2LowerRetainedNodeFrameArray

noncomputable section
open scoped Classical
open P2PhysicalIncomingPrefixCells P2LowerCapPlanIntegerRetention
open P2LowerFiniteRetainedNodeTable

-- Every step records exactly one frame, including an odd bypass step.
-- Thus no odd step can silently disappear from the certificate array.
theorem run_frames_length {depth m : ℕ} (P : CapPlan depth m)
    (a b : ℝ) (H : Trace) (xs : List ℝ) :
    (run P a b H xs).frames.length=H.frames.length+xs.length := by
  induction xs generalizing H with
  | nil => simp only [run,List.foldl_nil,List.length_nil,Nat.add_zero]
  | cons x xs ih =>
      change (run P a b (step P a b H x) xs).frames.length=_
      rw [ih]
      simp only [step,List.length_append,List.length_singleton,List.length_cons]
      omega

theorem integerTrace_frames_length {depth m : ℕ} (P : CapPlan depth m)
    (a b seedCap : ℝ) (N : ℕ) (history : List ℕ) :
    (integerTrace P a b seedCap N history).frames.length=history.length := by
  simpa only [integerTrace,root,List.length_nil,Nat.zero_add,
    physicalWord,List.length_map,List.length_reverse] using
      run_frames_length P a b (root seedCap) (physicalWord N history)

def frameArray (node : NodeData) : Array Frame := node.trace.frames.toArray

@[simp] theorem frameArray_toList (node : NodeData) :
    (frameArray node).toList=node.trace.frames := rfl

-- The certificate contains one physical frame per canonical prime factor.
-- The rank count is derived from the actual run, not supplied by a caller.
theorem readNode_frameArray_size {depth m : ℕ} (P : CapPlan depth m)
    (a b seedCap : ℝ) (N d : ℕ) :
    (frameArray (readNode P a b seedCap N d)).size=d.primeFactorsList.length := by
  simpa only [frameArray,List.size_toArray,readNode] using
    integerTrace_frames_length P a b seedCap N d.primeFactorsList

-- A later chronological suffix preserves every old array record literally,
-- including its incoming cap, frozen cap, selected branch and tested Prop.
theorem integerTrace_newer_frames_prefix {depth m : ℕ} (P : CapPlan depth m)
    (a b seedCap : ℝ) (N : ℕ) (newer older : List ℕ) :
    (integerTrace P a b seedCap N (newer++older)).frames.take
        (integerTrace P a b seedCap N older).frames.length=
      (integerTrace P a b seedCap N older).frames := by
  unfold integerTrace
  have hw : physicalWord N (newer++older)=physicalWord N older++physicalWord N newer := by
    simp only [physicalWord,List.reverse_append,List.map_append]
  rw [hw,run_append]
  obtain ⟨extra,he⟩ := run_frames_extend P a b
    (run P a b (root seedCap) (physicalWord N older)) (physicalWord N newer)
  rw [he,List.take_append_length]

-- This finite array is produced from the table, using increasing natural
-- modulus order. It is not an assumed array of retained-node witnesses.
def nodeArray {depth m : ℕ} (P : CapPlan depth m)
    (a b seedCap : ℝ) (N cap : ℕ) (z0 w : ℝ) : Array NodeData :=
  ((retainedTable P a b seedCap N cap z0 w).sort (·≤·)).map
    (readNode P a b seedCap N) |>.toArray

-- Projection recovers the complete table without omissions or row aliases.
theorem nodeArray_moduli {depth m : ℕ} (P : CapPlan depth m)
    (a b seedCap : ℝ) (N cap : ℕ) (z0 w : ℝ) :
    (nodeArray P a b seedCap N cap z0 w).toList.map NodeData.modulus=
      (retainedTable P a b seedCap N cap z0 w).sort (·≤·) := by
  simp [nodeArray,List.map_map,readNode]

-- Every actual finite row has computed acceptance and its exact frame count.
theorem indexed_node_certificate {depth m : ℕ} (P : CapPlan depth m)
    (a b seedCap : ℝ) (N cap : ℕ) (z0 w : ℝ)
    (i : NodeIndex P a b seedCap N cap z0 w) :
    (readNode P a b seedCap N i.val).trace.accepted=true ∧
      (frameArray (readNode P a b seedCap N i.val)).size=i.val.primeFactorsList.length := by
  exact ⟨(retained_row_canonical_witness P a b seedCap N cap z0 w i.property).2.2,
    readNode_frameArray_size P a b seedCap N i.val⟩

end
end ImbalancedChen.P2LowerRetainedNodeFrameArray
