import ImbalancedChen.P2LowerFiniteRetainedArrayAudit

-- SOURCE ONLY / UNCOMPILED_ZERO_CREDIT.
-- Exact finite witness enumeration: no row aliases, no omitted retained
-- modulus, and no numerical replay or cardinal evaluation.

namespace ImbalancedChen.P2LowerFiniteRetainedArrayEnumeration

noncomputable section
open scoped Classical
open P2PhysicalIncomingPrefixCells P2LowerCapPlanIntegerRetention
open P2LowerFiniteRetainedNodeTable P2LowerRetainedNodeFrameArray
open P2LowerFiniteRetainedArrayAudit

-- The array has exactly one row per retained modulus. This identity does
-- not replace the actual cardinal by an externally computed integer.
theorem nodeArray_size_eq_card {depth m : ℕ} (P : CapPlan depth m)
    (a b seedCap : ℝ) (N cap : ℕ) (z0 w : ℝ) :
    (nodeArray P a b seedCap N cap z0 w).size=
      (retainedTable P a b seedCap N cap z0 w).card := by
  simp only [nodeArray,List.size_toArray,List.length_map,Finset.length_sort]

-- The canonical modulus projection is a list without repetitions.
-- Thus distinct table rows never certify the same natural modulus.
theorem nodeArray_moduli_nodup {depth m : ℕ} (P : CapPlan depth m)
    (a b seedCap : ℝ) (N cap : ℕ) (z0 w : ℝ) :
    ((nodeArray P a b seedCap N cap z0 w).toList.map NodeData.modulus).Nodup := by
  rw [nodeArray_moduli]
  exact Finset.sort_nodup _ _

theorem readNode_injective {depth m : ℕ} (P : CapPlan depth m)
    (a b seedCap : ℝ) (N : ℕ) :
    Function.Injective (readNode P a b seedCap N) := by
  intro d e he
  exact congrArg NodeData.modulus he

-- A retained modulus fixes ALL row data, including canonical factor
-- history and frozen cap trace, not just the signed coefficient value.
theorem array_rows_equal_of_modulus_eq {depth m : ℕ} (P : CapPlan depth m)
    (a b seedCap : ℝ) (N cap : ℕ) (z0 w : ℝ) (left right : NodeData)
    (hl : left∈(nodeArray P a b seedCap N cap z0 w).toList)
    (hr : right∈(nodeArray P a b seedCap N cap z0 w).toList)
    (hmod : left.modulus=right.modulus) : left=right := by
  obtain ⟨d,hd,rfl⟩ := (mem_nodeArray_iff P a b seedCap N cap z0 w left).mp hl
  obtain ⟨e,he,rfl⟩ := (mem_nodeArray_iff P a b seedCap N cap z0 w right).mp hr
  exact congrArg (readNode P a b seedCap N) hmod

-- Forward and reverse coverage concern the COMPLETE original retained
-- support. The concrete geometric CapPlan and its legality remain OPEN.
theorem array_modulus_iff_rawSupport {depth m : ℕ} (P : CapPlan depth m)
    (a b seedCap : ℝ) {N : ℕ} (hN : 1<(N:ℝ)) (cap : ℕ)
    (z0 w : ℝ) (hmargin : 2*w<seedCap) (d : ℕ) :
    d∈(nodeArray P a b seedCap N cap z0 w).toList.map NodeData.modulus ↔
      d∈P2LowerFiniteCellRounding.rawSupport
        (retainEven P a b seedCap N) N cap z0 ((N:ℝ)^w) := by
  rw [nodeArray_moduli,Finset.mem_sort,
    retainedTable_eq_rawSupport P a b seedCap hN cap z0 w hmargin]

-- This is existence AND uniqueness of the actual generated row at every
-- raw retained modulus. Neither direction assumes an array certificate.
theorem rawSupport_unique_array_row {depth m : ℕ} (P : CapPlan depth m)
    (a b seedCap : ℝ) {N : ℕ} (hN : 1<(N:ℝ)) (cap : ℕ)
    (z0 w : ℝ) (hmargin : 2*w<seedCap) {d : ℕ}
    (hd : d∈P2LowerFiniteCellRounding.rawSupport
      (retainEven P a b seedCap N) N cap z0 ((N:ℝ)^w)) :
    ∃! node : NodeData,
      node∈(nodeArray P a b seedCap N cap z0 w).toList ∧ node.modulus=d := by
  obtain ⟨node,hnode,hmod,haudit⟩ :=
    raw_support_has_generated_array_row P a b seedCap hN cap z0 w hmargin hd
  refine ⟨node,⟨hnode,hmod⟩,?_⟩
  intro other hother
  exact array_rows_equal_of_modulus_eq P a b seedCap N cap z0 w other node
    hother.1 hnode (hother.2.trans hmod.symm)

end
end ImbalancedChen.P2LowerFiniteRetainedArrayEnumeration
