import ImbalancedChen.P2LowerCanonicalRetainedTrace

-- SOURCE ONLY / UNCOMPILED_ZERO_CREDIT.
-- The finite table computes canonical retention from the original parity trace.
-- The geometric CapPlan is an explicit input. Its original bank instantiation,
-- legality and quantitative margins are still separate OPEN obligations.

namespace ImbalancedChen.P2LowerFiniteRetainedNodeTable

noncomputable section
open scoped Classical
open P2PhysicalIncomingPrefixCells P2LowerCapPlanIntegerRetention
open P2LowerFiniteCellRounding P2LowerCanonicalRetainedTrace

-- One row for every accepted actual rough divisor. No serialized certificate
-- or proof of final retention is an input to the table constructor.
def retainedTable {depth m : ℕ} (P : CapPlan depth m)
    (a b seedCap : ℝ) (N cap : ℕ) (z0 w : ℝ) : Finset ℕ :=
  (universe N cap z0 ((N:ℝ)^w)).filter
    (fun d => retainEven P a b seedCap N d.primeFactorsList=true)

@[simp] theorem mem_retainedTable {depth m : ℕ} (P : CapPlan depth m)
    (a b seedCap : ℝ) (N cap : ℕ) (z0 w : ℝ) (d : ℕ) :
    d∈retainedTable P a b seedCap N cap z0 w ↔
      d∈universe N cap z0 ((N:ℝ)^w) ∧
        retainEven P a b seedCap N d.primeFactorsList=true := by
  exact Finset.mem_filter

-- Equality concerns the COMPLETE raw support, including the odd bypass.
-- It is not equality to the stricter all-rank geometric stepGate support.
theorem retainedTable_eq_rawSupport {depth m : ℕ} (P : CapPlan depth m)
    (a b seedCap : ℝ) {N : ℕ} (hN : 1<(N:ℝ)) (cap : ℕ)
    (z0 w : ℝ) (hmargin : 2*w<seedCap) :
    retainedTable P a b seedCap N cap z0 w=
      rawSupport (retainEven P a b seedCap N) N cap z0 ((N:ℝ)^w) := by
  ext d
  exact (mem_retainedTable P a b seedCap N cap z0 w d).trans
    (raw_support_iff_canonical_trace P a b seedCap hN cap z0 w hmargin d).symm

-- A row contains only deterministic data. Validity comes from table
-- membership and is never stored as an unproved certificate field.
structure NodeData where
  modulus : ℕ
  history : List ℕ
  trace : Trace

def readNode {depth m : ℕ} (P : CapPlan depth m)
    (a b seedCap : ℝ) (N d : ℕ) : NodeData :=
  ⟨d,d.primeFactorsList,integerTrace P a b seedCap N d.primeFactorsList⟩

abbrev NodeIndex {depth m : ℕ} (P : CapPlan depth m)
    (a b seedCap : ℝ) (N cap : ℕ) (z0 w : ℝ) :=
  {d : ℕ // d∈retainedTable P a b seedCap N cap z0 w}

-- The same canonical chronological prime subword produces every row.
-- No alternative ordering or ancestor policy may be selected per row.
theorem retained_row_canonical_witness {depth m : ℕ} (P : CapPlan depth m)
    (a b seedCap : ℝ) (N cap : ℕ) (z0 w : ℝ) {d : ℕ}
    (hd : d∈retainedTable P a b seedCap N cap z0 w) :
    (readNode P a b seedCap N d).history.reverse <+
        roughPrimeUniverse N cap z0 ((N:ℝ)^w) ∧
      (readNode P a b seedCap N d).history.prod=d ∧
      (readNode P a b seedCap N d).trace.accepted=true := by
  obtain ⟨hU,hret⟩ := (mem_retainedTable P a b seedCap N cap z0 w d).mp hd
  obtain ⟨hsub,hprod⟩ := canonical_subword_of_universe N cap z0 ((N:ℝ)^w) hU
  exact ⟨hsub,by simpa only [readNode,List.prod_reverse] using hprod,hret⟩

-- The coefficient reader binds the original signed Mobius value to this
-- concrete finite table. Neither rounding nor an enhanced density is used.
theorem raw_coefficient_from_retainedTable {depth m : ℕ} (P : CapPlan depth m)
    (a b seedCap : ℝ) {N : ℕ} (hN : 1<(N:ℝ)) (cap : ℕ)
    (z0 w : ℝ) (hmargin : 2*w<seedCap) (d : ℕ) :
    raw (retainEven P a b seedCap N) N cap z0 ((N:ℝ)^w) d=
      if d∈retainedTable P a b seedCap N cap z0 w
      then (ArithmeticFunction.moebius d:ℝ) else 0 := by
  rw [raw_value,←retainedTable_eq_rawSupport P a b seedCap hN cap z0 w hmargin]

end
end ImbalancedChen.P2LowerFiniteRetainedNodeTable
