import ImbalancedChen.P2LowerSignedCellOriginalAudit

-- SOURCE ONLY / UNCOMPILED_ZERO_CREDIT.
-- A canonical rough modulus excluded by the actual computed policy has
-- a first failed original gate whose complete incoming prefix passed.
-- This supplies an actual first-exit witness before boundary estimates.

namespace ImbalancedChen.P2LowerCanonicalFirstFailure

noncomputable section
open scoped Classical
open P2PhysicalIncomingPrefixCells P2LowerCapPlanIntegerRetention
open P2LowerOriginalPrefixAudit P2LowerSignedCellOriginalAudit
open P2LowerCanonicalRetainedTrace P2LowerFiniteCellRounding

private theorem first_failed_admission {depth m : ℕ} (P : CapPlan depth m)
    (a b : ℝ) (H : Trace) (xs : List ℝ) (hH : H.accepted=true)
    (h : (run P a b H xs).accepted≠true) :
    ∃pre x post, xs=pre++x::post ∧
      (run P a b H pre).accepted=true ∧ ¬admission (run P a b H pre) x := by
  induction xs generalizing H with
  | nil => exact (h hH).elim
  | cons x xs ih =>
      by_cases hx : admission H x
      · have hs : (step P a b H x).accepted=true :=
          (step_accepted_iff P a b H x).mpr ⟨hH,hx⟩
        obtain ⟨pre,y,post,he,ha,hf⟩ := ih (step P a b H x) hs h
        refine ⟨x::pre,y,post,?_,ha,hf⟩
        simp only [List.cons_append,he]
      · exact ⟨[],x,xs,rfl,hH,hx⟩

-- The failed test is evaluated at an accepted incoming prefix, not
-- merely at some later prefix after an earlier rejection.
theorem rejected_run_has_first_failure {depth m : ℕ} (P : CapPlan depth m)
    (a b : ℝ) (H : Trace) (xs : List ℝ) (hH : H.accepted=true)
    (h : (run P a b H xs).accepted≠true) :
    ∃pre x post, xs=pre++x::post ∧
      (run P a b H pre).accepted=true ∧
      ¬originalGate (H.word++pre) (run P a b H pre).cap x ∧
      ((H.word++pre).length=0 ∨ ((H.word++pre).length+1)%2=0) := by
  obtain ⟨pre,x,post,he,ha,hf⟩ := first_failed_admission P a b H xs hH h
  have ho : ¬originalGate (H.word++pre) (run P a b H pre).cap x := by
    simpa only [admission,originalGate,run_word] using hf
  exact ⟨pre,x,post,he,ha,ho,failing_prefix_is_initial_or_even _ _ _ ho⟩

-- Both the natural modulus and its ordering are fixed by the actual
-- canonical factor history. No alternate history is chosen to fail.
theorem excluded_rough_modulus_first_failure {depth m : ℕ} (P : CapPlan depth m)
    (a b seedCap : ℝ) {N : ℕ} (hN : 1<(N:ℝ)) (cap : ℕ)
    (z0 w : ℝ) (hmargin : 2*w<seedCap) {d : ℕ}
    (hd : d∈universe N cap z0 ((N:ℝ)^w))
    (hout : d∉rawSupport (retainEven P a b seedCap N) N cap z0 ((N:ℝ)^w)) :
    ∃pre x post, physicalWord N d.primeFactorsList=pre++x::post ∧
      (run P a b (root seedCap) pre).accepted=true ∧
      ¬originalGate pre (run P a b (root seedCap) pre).cap x ∧
      (pre.length=0 ∨ (pre.length+1)%2=0) := by
  have hn : retainEven P a b seedCap N d.primeFactorsList≠true := by
    intro ht
    exact hout ((raw_support_iff_canonical_trace P a b seedCap hN cap z0 w hmargin d).mpr
      ⟨hd,ht⟩)
  obtain ⟨pre,x,post,he,ha,hf,hpar⟩ := rejected_run_has_first_failure P a b
    (root seedCap) (physicalWord N d.primeFactorsList) rfl hn
  exact ⟨pre,x,post,he,ha,hf,hpar⟩

end
end ImbalancedChen.P2LowerCanonicalFirstFailure
