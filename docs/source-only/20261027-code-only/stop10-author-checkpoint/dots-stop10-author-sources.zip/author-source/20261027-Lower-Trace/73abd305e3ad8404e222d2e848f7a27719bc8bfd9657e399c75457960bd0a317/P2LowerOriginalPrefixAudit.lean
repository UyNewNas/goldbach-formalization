import ImbalancedChen.P2LowerCapPlanIntegerRetention

-- SOURCE ONLY / UNCOMPILED_ZERO_CREDIT.
-- The semantic audit quantifies over every chronological split. Its cap is
-- the cap computed on the STRICT incoming prefix, before the new choice.
-- Odd full ranks after the initial square have no own-cube requirement.
-- No claim identifies this audit with the stricter all-rank stepGate.

namespace ImbalancedChen.P2LowerOriginalPrefixAudit

noncomputable section
open scoped Classical
open P2PhysicalIncomingPrefixCells P2LowerCapPlanIntegerRetention

def originalGate (prefix : List ℝ) (incoming x : ℝ) : Prop :=
  if prefix.length=0 then 2*x<incoming
  else if (prefix.length+1)%2=0 then prefix.sum+3*x<incoming else True

-- Each inequality retains the complete computed ancestry. A fresh cap
-- at the child cannot be substituted into this incoming test.
def PrefixAudit {depth m : ℕ} (P : CapPlan depth m) (a b : ℝ)
    (H : Trace) (xs : List ℝ) : Prop :=
  ∀ pre x post, xs=pre++x::post →
    originalGate (H.word++pre) (run P a b H pre).cap x

private def SplitTests {depth m : ℕ} (P : CapPlan depth m) (a b : ℝ)
    (H : Trace) (xs : List ℝ) : Prop :=
  ∀ pre x post, xs=pre++x::post → admission (run P a b H pre) x

private theorem splitTests_cons {depth m : ℕ} (P : CapPlan depth m)
    (a b : ℝ) (H : Trace) (x : ℝ) (xs : List ℝ) :
    SplitTests P a b H (x::xs) ↔
      admission H x ∧ SplitTests P a b (step P a b H x) xs := by
  constructor
  · intro h
    refine ⟨?_,?_⟩
    · exact h [] x xs rfl
    · intro pre y post he
      have ht := h (x::pre) y post (by simpa only [List.cons_append,he])
      exact ht
  · rintro ⟨hx,hxs⟩ pre y post he
    cases pre with
    | nil =>
        obtain ⟨rfl,rfl⟩ := List.cons.inj he
        exact hx
    | cons z pre =>
        have hz : x=z := (List.cons.inj he).1
        have hs : xs=pre++y::post := (List.cons.inj he).2
        subst z
        exact hxs pre y post hs

private theorem run_accepted_iff_splitTests {depth m : ℕ} (P : CapPlan depth m)
    (a b : ℝ) (H : Trace) (xs : List ℝ) :
    (run P a b H xs).accepted=true ↔ H.accepted=true ∧ SplitTests P a b H xs := by
  induction xs generalizing H with
  | nil =>
      have hempty : SplitTests P a b H [] := by
        intro pre x post he
        have hlen := congrArg List.length he
        simp only [List.length_nil,List.length_append,List.length_cons] at hlen
        omega
      simp only [run,List.foldl_nil,and_iff_left hempty]
  | cons x xs ih =>
      change (run P a b (step P a b H x) xs).accepted=true ↔ _
      rw [ih,step_accepted_iff,splitTests_cons]
      exact and_assoc

-- Compiler correctness for the complete original parity audit. The
-- universal statement includes the first square and every even cube,
-- while all earlier cap lookups remain tied to their original prefixes.
theorem run_accepted_iff_prefixAudit {depth m : ℕ} (P : CapPlan depth m)
    (a b : ℝ) (H : Trace) (xs : List ℝ) :
    (run P a b H xs).accepted=true ↔ H.accepted=true ∧ PrefixAudit P a b H xs := by
  rw [run_accepted_iff_splitTests]
  have he : SplitTests P a b H xs ↔ PrefixAudit P a b H xs := by
    simp only [SplitTests,PrefixAudit,admission,originalGate,run_word]
  rw [he]

theorem retainEven_iff_original_prefixAudit {depth m : ℕ} (P : CapPlan depth m)
    (a b seedCap : ℝ) (N : ℕ) (history : List ℕ) :
    retainEven P a b seedCap N history=true ↔
      PrefixAudit P a b (root seedCap) (physicalWord N history) := by
  unfold retainEven integerTrace
  rw [run_accepted_iff_prefixAudit]
  exact ⟨fun h=>h.2,fun h=>⟨rfl,h⟩⟩

-- A rejected computed trace supplies a literal failing chronological
-- prefix. This is suitable for later boundary localization; failure is
-- not an unconstrained premise supplied to a band estimate.
theorem rejected_run_has_failing_prefix {depth m : ℕ} (P : CapPlan depth m)
    (a b : ℝ) (H : Trace) (xs : List ℝ) (hH : H.accepted=true)
    (h : (run P a b H xs).accepted≠true) :
    ∃ pre x post, xs=pre++x::post ∧
      ¬originalGate (H.word++pre) (run P a b H pre).cap x := by
  have hn : ¬PrefixAudit P a b H xs := by
    intro ha
    exact h ((run_accepted_iff_prefixAudit P a b H xs).mpr ⟨hH,ha⟩)
  unfold PrefixAudit at hn
  push_neg at hn
  exact hn

-- No positive-length odd prefix split can witness failure. In
-- particular a fifth-rank cube is never introduced by this compiler.
theorem failing_prefix_is_initial_or_even (prefix : List ℝ) (incoming x : ℝ)
    (h : ¬originalGate prefix incoming x) :
    prefix.length=0 ∨ (prefix.length+1)%2=0 := by
  by_cases hz : prefix.length=0
  · exact Or.inl hz
  · apply Or.inr
    by_contra ho
    exact h (by simp only [originalGate,if_neg hz,if_neg ho])

theorem odd_gate_bypass (prefix : List ℝ) (incoming x : ℝ)
    (hz : prefix.length≠0) (ho : (prefix.length+1)%2≠0) :
    originalGate prefix incoming x := by
  simp only [originalGate,if_neg hz,if_neg ho]

end
end ImbalancedChen.P2LowerOriginalPrefixAudit
