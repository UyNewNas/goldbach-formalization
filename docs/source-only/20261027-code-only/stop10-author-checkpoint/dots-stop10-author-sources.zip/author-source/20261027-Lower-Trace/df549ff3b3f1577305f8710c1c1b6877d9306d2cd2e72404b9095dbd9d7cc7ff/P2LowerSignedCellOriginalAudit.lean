import ImbalancedChen.P2LowerOriginalPrefixAudit
import ImbalancedChen.P2LowerCanonicalRetainedTrace

-- SOURCE ONLY / UNCOMPILED_ZERO_CREDIT.
-- The actual signed ALL/ANY cell compiler is bound to all original
-- parity gates of each canonical natural factor history. Quantifiers
-- stay in their original order: ANY chooses one WHOLE accepted history.
-- An arbitrary finite cap plan is not certified as the original bank.

namespace ImbalancedChen.P2LowerSignedCellOriginalAudit

noncomputable section
open scoped Classical
open P2PhysicalIncomingPrefixCells P2LowerCapPlanIntegerRetention
open P2LowerOriginalPrefixAudit P2LowerCanonicalRetainedTrace
open P2LowerFiniteCellRounding

def modulusAudit {depth m : ℕ} (P : CapPlan depth m)
    (a b seedCap : ℝ) (N d : ℕ) : Prop :=
  PrefixAudit P a b (root seedCap) (physicalWord N d.primeFactorsList)

theorem raw_support_iff_original_audit {depth m : ℕ} (P : CapPlan depth m)
    (a b seedCap : ℝ) {N : ℕ} (hN : 1<(N:ℝ)) (cap : ℕ)
    (z0 w : ℝ) (hmargin : 2*w<seedCap) (d : ℕ) :
    d∈rawSupport (retainEven P a b seedCap N) N cap z0 ((N:ℝ)^w) ↔
      d∈universe N cap z0 ((N:ℝ)^w) ∧ modulusAudit P a b seedCap N d := by
  rw [raw_support_iff_canonical_trace P a b seedCap hN cap z0 w hmargin d,
    retainEven_iff_original_prefixAudit]
  rfl

-- Positive coefficients test ALL members of their one actual label
-- fibre, with ALL original prefix gates at each member.
theorem inner_iff_all_original_audits {depth m : ℕ} (P : CapPlan depth m)
    (a b seedCap : ℝ) {N : ℕ} (hN : 1<(N:ℝ)) (cap : ℕ)
    (z0 w tau : ℝ) (hmargin : 2*w<seedCap) (d : ℕ) :
    inner (retainEven P a b seedCap N) N cap z0 ((N:ℝ)^w) tau d ↔
      ∀e∈cell N cap z0 ((N:ℝ)^w) tau d, modulusAudit P a b seedCap N e := by
  constructor
  · intro hi e he
    exact ((raw_support_iff_original_audit P a b seedCap hN cap z0 w hmargin e).mp
      (hi he)).2
  · intro ha e he
    exact (raw_support_iff_original_audit P a b seedCap hN cap z0 w hmargin e).mpr
      ⟨(Finset.mem_filter.mp he).1,ha e he⟩

-- Negative coefficients use ANY whole history passing ALL its prefix
-- tests. No independently chosen witnesses for separate gates occur.
theorem outer_iff_one_whole_original_audit {depth m : ℕ} (P : CapPlan depth m)
    (a b seedCap : ℝ) {N : ℕ} (hN : 1<(N:ℝ)) (cap : ℕ)
    (z0 w tau : ℝ) (hmargin : 2*w<seedCap) (d : ℕ) :
    outer (retainEven P a b seedCap N) N cap z0 ((N:ℝ)^w) tau d ↔
      ∃e∈cell N cap z0 ((N:ℝ)^w) tau d, modulusAudit P a b seedCap N e := by
  constructor
  · rintro ⟨e,he⟩
    obtain ⟨hc,hr⟩ := Finset.mem_inter.mp he
    exact ⟨e,hc,((raw_support_iff_original_audit P a b seedCap hN cap z0 w hmargin e).mp hr).2⟩
  · rintro ⟨e,hc,ha⟩
    refine ⟨e,Finset.mem_inter.mpr ⟨hc,?_⟩⟩
    exact (raw_support_iff_original_audit P a b seedCap hN cap z0 w hmargin e).mpr
      ⟨(Finset.mem_filter.mp hc).1,ha⟩

-- The literal output of the installed signed rounding constructor,
-- now with the original gates exposed instead of an opaque policy bit.
theorem coefficient_eq_original_audits {depth m : ℕ} (P : CapPlan depth m)
    (a b seedCap : ℝ) {N : ℕ} (hN : 1<(N:ℝ)) (cap : ℕ)
    (z0 w tau : ℝ) (hmargin : 2*w<seedCap) (d : ℕ) :
    coefficient (retainEven P a b seedCap N) N cap z0 ((N:ℝ)^w) tau d=
      if d∈universe N cap z0 ((N:ℝ)^w) then
        if 0≤(ArithmeticFunction.moebius d:ℝ) then
          if (∀e∈cell N cap z0 ((N:ℝ)^w) tau d, modulusAudit P a b seedCap N e)
          then (ArithmeticFunction.moebius d:ℝ) else 0
        else if (∃e∈cell N cap z0 ((N:ℝ)^w) tau d, modulusAudit P a b seedCap N e)
          then (ArithmeticFunction.moebius d:ℝ) else 0
      else 0 := by
  unfold coefficient
  rw [inner_iff_all_original_audits P a b seedCap hN cap z0 w tau hmargin d,
    outer_iff_one_whole_original_audit P a b seedCap hN cap z0 w tau hmargin d]

end
end ImbalancedChen.P2LowerSignedCellOriginalAudit
