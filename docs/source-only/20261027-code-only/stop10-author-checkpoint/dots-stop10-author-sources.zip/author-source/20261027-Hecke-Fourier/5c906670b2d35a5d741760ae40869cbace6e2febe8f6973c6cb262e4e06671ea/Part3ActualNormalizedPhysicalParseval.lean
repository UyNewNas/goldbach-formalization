import ImbalancedChen.Part3ActualNormalizedHeckeFourier

-- SOURCE_ONLY / UNCOMPILED_ZERO_CREDIT, 2026-10-27.
-- Actual periodic Parseval on the original compact Lebesgue period cell.
-- The physical y/|n| and hyperbolic 1/(y*|n|) factors are derived from
-- literal Fourier integrals and the actual quotient real-K classification.
-- Zero mode is retained. No Parseval/normalization hypothesis is supplied.

namespace ImbalancedChen.Part3.ActualNormalizedPhysicalParseval20261027
noncomputable section
open Set MeasureTheory
open ActualNormalizedHeckeFourier20261027
open QuotientRealKFourierCoefficient20261026b
open ActualPoincareSpectralCoefficient20261026a
open ActualMaassFourierODE20261026a
open Gamma0QuotientCellPushforward20261025a
open ComplexOrderKBridgeSourceOnly
attribute [local instance] Measure.Subtype.measureSpace

-- Pinned Mathlib all-integer Parseval is transported to the ORIGINAL
-- compact period cell Icc 0 1 with induced Lebesgue measure, mass exactly 1.
theorem actualTestFourier_hasSum_cell (N : ℕ) (U : Gamma0OrbitSpace N → ℂ)
    (hC : ContinuousOn (maassChart N U) upperDomain)
    {y : ℝ} (hy : 0 < y) :
    HasSum (fun n : ℤ => ‖actualTestFourier N U n y‖^2)
      (∫ x : PeriodCell, ‖maassChart N U (x,y)‖^2) := by
  have hslice := continuous_slice hC hy
  have hsq : IntegrableOn (fun x => ‖maassChart N U (x,y)‖^2) (Ioc (0 : ℝ) 1) :=
    ((hslice.norm.pow 2).intervalIntegrable 0 1).1
  have hL2 : MemLp (fun x => maassChart N U (x,y)) 2
      (volume.restrict (Ioc (0 : ℝ) 1)) :=
    (memLp_two_iff_integrable_sq_norm hslice.aestronglyMeasurable.restrict).mpr hsq
  have hs := AddCircle.hasSum_sq_fourierCoeffOn (by norm_num : (0 : ℝ)<1) hL2
  simp_rw [actualTestFourier_eq_coefficient, coefficient_eq_fourierCoeffOn]
  rw [integral_subtype_comap measurableSet_Icc, integral_Icc_eq_integral_Ioc]
  simpa only [sub_zero, inv_one, one_smul,
    intervalIntegral.integral_of_le zero_le_one] using hs

variable (N : ℕ) [NeZero N] (U : Gamma0OrbitSpace N → ℂ)
  (hU : Continuous (testLift N U)) (hU2 : MemLp U 2 (carrierPushforward N))
  (hC2 : ContDiffOn ℝ 2 (maassChart N U) upperDomain)
  (nu : ℝ) (hnu : 0 ≤ nu)
  (hPDE : ∀ z ∈ upperDomain,
    -(z.2 : ℂ)^2*(partialX (partialX (maassChart N U)) z+
      partialY (partialY (maassChart N U)) z) =
        (1/4-(nu : ℂ)^2)*maassChart N U z)

-- Exact squared norm, with the original physical factor y/|n|.
theorem actualTestFourier_norm_sq_R {n : ℤ} (hn : n ≠ 0)
    {y : ℝ} (hy : 0 < y) :
    ‖actualTestFourier N U n y‖^2 =
      (y/|(n : ℝ)|)*‖quotientR N U nu n‖^2*
        ‖complexOrderK (nu : ℂ) (2*Real.pi*|(n : ℝ)|*y)‖^2 := by
  rw [actual_fourier_eq_R_physical N U hU hU2 hC2 nu hnu hPDE hn hy]
  simp only [norm_mul, mul_pow, Complex.norm_real, Real.norm_eq_abs,
    abs_of_nonneg (Real.sqrt_nonneg _),
    Real.sq_sqrt (div_nonneg hy.le (abs_nonneg (n : ℝ)))]
  ring

-- This energy restores the original zero mode explicitly. It cannot be
-- dropped by the division by |n| in the nonzero coefficient normalization.
def physicalModeEnergy (y : ℝ) (n : ℤ) : ℝ :=
  if n = 0 then ‖actualTestFourier N U 0 y‖^2
  else (y/|(n : ℝ)|)*‖quotientR N U nu n‖^2*
    ‖complexOrderK (nu : ℂ) (2*Real.pi*|(n : ℝ)|*y)‖^2

theorem physicalModeEnergy_eq {y : ℝ} (hy : 0 < y) (n : ℤ) :
    physicalModeEnergy N U nu y n = ‖actualTestFourier N U n y‖^2 := by
  by_cases hn : n = 0
  · simp only [physicalModeEnergy, if_pos hn, hn]
  · rw [physicalModeEnergy, if_neg hn,
      ← actualTestFourier_norm_sq_R N U hU hU2 hC2 nu hnu hPDE hn hy]

-- True normalized periodic Parseval in the same original cell measure.
theorem periodicParseval_R {y : ℝ} (hy : 0 < y) :
    HasSum (physicalModeEnergy N U nu y)
      (∫ x : PeriodCell, ‖maassChart N U (x,y)‖^2) := by
  simpa only [physicalModeEnergy_eq N U hU hU2 hC2 nu hnu hPDE hy] using
    actualTestFourier_hasSum_cell N U hC2.continuousOn hy

-- Hyperbolic y^-2 density changes y/|n| to 1/(y*|n|), with no other
-- frequency, cusp-width, probability-measure, or Bessel normalization.
def hyperbolicModeEnergy (y : ℝ) (n : ℤ) : ℝ :=
  if n = 0 then y⁻¹^2*‖actualTestFourier N U 0 y‖^2
  else ‖quotientR N U nu n‖^2/(y*|(n : ℝ)|)*
    ‖complexOrderK (nu : ℂ) (2*Real.pi*|(n : ℝ)|*y)‖^2

theorem hyperbolicModeEnergy_eq {y : ℝ} (hy : 0 < y) (n : ℤ) :
    hyperbolicModeEnergy N U nu y n = y⁻¹^2*physicalModeEnergy N U nu y n := by
  by_cases hn : n = 0
  · simp only [hyperbolicModeEnergy, physicalModeEnergy, if_pos hn]
  · have hnR : (n : ℝ) ≠ 0 := by exact_mod_cast hn
    simp only [hyperbolicModeEnergy, physicalModeEnergy, if_neg hn]
    field_simp [hy.ne', abs_ne_zero.mpr hnR] <;> ring

-- The original physical cell integral with the literal hyperbolic density.
theorem periodicParseval_R_hyperbolic {y : ℝ} (hy : 0 < y) :
    HasSum (hyperbolicModeEnergy N U nu y)
      (∫ x : PeriodCell, y⁻¹^2*‖maassChart N U (x,y)‖^2) := by
  have hs := (periodicParseval_R N U hU hU2 hC2 nu hnu hPDE hy).mul_left (y⁻¹^2)
  rw [integral_const_mul]
  simpa only [hyperbolicModeEnergy_eq N U nu hy] using hs

theorem tsum_hyperbolicModeEnergy {y : ℝ} (hy : 0 < y) :
    (∑' n : ℤ, hyperbolicModeEnergy N U nu y n) =
      ∫ x : PeriodCell, y⁻¹^2*‖maassChart N U (x,y)‖^2 :=
  (periodicParseval_R_hyperbolic N U hU hU2 hC2 nu hnu hPDE hy).tsum_eq

end
end ImbalancedChen.Part3.ActualNormalizedPhysicalParseval20261027
