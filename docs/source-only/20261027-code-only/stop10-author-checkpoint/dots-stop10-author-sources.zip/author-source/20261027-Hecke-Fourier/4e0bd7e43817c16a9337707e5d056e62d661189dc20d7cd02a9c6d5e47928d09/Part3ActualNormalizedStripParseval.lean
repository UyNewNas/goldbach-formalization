import ImbalancedChen.Part3ActualNormalizedPhysicalParseval
import Mathlib.MeasureTheory.Integral.DominatedConvergence
import Mathlib.MeasureTheory.Integral.Prod

-- SOURCE_ONLY / UNCOMPILED_ZERO_CREDIT, 2026-10-27.
-- Integrate actual normalized physical Fourier Parseval over the original
-- high strip with dx dy/y^2. Original quotient L2 pays summability and the
-- integral/series exchange. The zero Fourier mode remains in every identity.

namespace ImbalancedChen.Part3.ActualNormalizedStripParseval20261027
noncomputable section
open Set MeasureTheory Filter
open ActualNormalizedPhysicalParseval20261027
open QuotientRealKFourierCoefficient20261026b
open ActualPoincareSpectralCoefficient20261026a
open ActualMaassFourierODE20261026a
open Gamma0QuotientCellPushforward20261025a
open CanonicalHighStripRawEnergy20261026b
attribute [local instance] Measure.Subtype.measureSpace

local instance periodCell_finite : IsFiniteMeasure (volume : Measure PeriodCell) := by
  constructor
  rw [Measure.Subtype.volume_univ measurableSet_Icc.nullMeasurableSet]
  exact isCompact_Icc.measure_lt_top

variable (N : ℕ) [NeZero N] (U : Gamma0OrbitSpace N → ℂ)
  (hU : Continuous (testLift N U)) (hU2 : MemLp U 2 (carrierPushforward N))
  (hC2 : ContDiffOn ℝ 2 (maassChart N U) upperDomain)
  (nu : ℝ) (hnu : 0 ≤ nu)
  (hPDE : ∀ z ∈ upperDomain,
    -(z.2 : ℂ)^2*(partialX (partialX (maassChart N U)) z+
      partialY (partialY (maassChart N U)) z) =
        (1/4-(nu : ℂ)^2)*maassChart N U z)

-- Equality with literal coefficient energy supplies measurability without
-- any regularity premise on an asserted K/Fourier spectral expansion.
theorem normalizedEnergy_eq_literal {y : ℝ} (hy : 0 < y) (n : ℤ) :
    hyperbolicModeEnergy N U nu y n =
      y⁻¹^2*‖coefficient (maassChart N U) n y‖^2 := by
  rw [hyperbolicModeEnergy_eq N U nu hy,
    physicalModeEnergy_eq N U hU hU2 hC2 nu hnu hPDE hy,
    actualTestFourier_eq_coefficient]

theorem normalizedEnergy_nonneg {y : ℝ} (hy : 0 < y) (n : ℤ) :
    0 ≤ hyperbolicModeEnergy N U nu y n := by
  rw [normalizedEnergy_eq_literal N U hU hU2 hC2 nu hnu hPDE hy]
  exact mul_nonneg (sq_nonneg _) (sq_nonneg _)

theorem normalizedEnergy_aestronglyMeasurable {Y : ℝ} (hY : 1 ≤ Y) (n : ℤ) :
    AEStronglyMeasurable (fun y => hyperbolicModeEnergy N U nu y n)
      (volume.restrict (Ioi Y)) := by
  have hpos : ∀ y ∈ Ioi Y, 0 < y := fun y hy =>
    lt_trans (lt_of_lt_of_le zero_lt_one hY) hy
  have hc := coefficient_continuousOn hC2.continuousOn n
  have he : ContinuousOn
      (fun y => y⁻¹^2*‖coefficient (maassChart N U) n y‖^2) (Ioi Y) :=
    ((continuousOn_id.inv₀ (fun y hy => (hpos y hy).ne')).pow 2).mul
      ((hc.mono (fun y hy => hpos y hy)).norm.pow 2)
  apply (he.aestronglyMeasurable measurableSet_Ioi).congr
  filter_upwards [ae_restrict_mem measurableSet_Ioi] with y hy
  exact (normalizedEnergy_eq_literal N U hU hU2 hC2 nu hnu hPDE (hpos y hy) n).symm

-- No summability of coefficient-height integrals is assumed: actual
-- quotient L2 gives the original raw strip integral, which dominates the
-- whole nonnegative series by the transverse Parseval already proved.
theorem hasSum_integrated_normalizedEnergy {Y : ℝ} (hY : 1 ≤ Y) :
    HasSum (fun n : ℤ => ∫ y in Ioi Y, hyperbolicModeEnergy N U nu y n)
      (∫ p : PeriodCell × ℝ,
        p.2⁻¹^2*‖maassChart N U (p.1,p.2)‖^2
          ∂((volume : Measure PeriodCell).prod (volume.restrict (Ioi Y)))) := by
  have hpos : ∀ y ∈ Ioi Y, 0 < y := fun y hy =>
    lt_trans (lt_of_lt_of_le zero_lt_one hY) hy
  have hstrip : Integrable
      (fun p : PeriodCell × ℝ => p.2⁻¹^2*‖maassChart N U (p.1,p.2)‖^2)
      ((volume : Measure PeriodCell).prod (volume.restrict (Ioi Y))) :=
    actual_quotient_raw_strip_energy N U hU hU2 Y hY
  have hseries : ∀ᵐ y ∂(volume.restrict (Ioi Y)),
      HasSum (fun n : ℤ => hyperbolicModeEnergy N U nu y n)
        (∫ x : PeriodCell, y⁻¹^2*‖maassChart N U (x,y)‖^2) := by
    filter_upwards [ae_restrict_mem measurableSet_Ioi] with y hy
    exact periodicParseval_R_hyperbolic N U hU hU2 hC2 nu hnu hPDE (hpos y hy)
  have hsumIntegrable : Integrable
      (fun y => ∑' n : ℤ, hyperbolicModeEnergy N U nu y n)
      (volume.restrict (Ioi Y)) := by
    apply hstrip.integral_prod_right.congr
    filter_upwards [hseries] with y hy
    exact hy.tsum_eq.symm
  rw [integral_prod_symm _ hstrip]
  apply MeasureTheory.hasSum_integral_of_dominated_convergence
    (fun n y => hyperbolicModeEnergy N U nu y n)
  · exact normalizedEnergy_aestronglyMeasurable N U hU hU2 hC2 nu hnu hPDE hY
  · intro n
    filter_upwards [ae_restrict_mem measurableSet_Ioi] with y hy
    rw [Real.norm_of_nonneg
      (normalizedEnergy_nonneg N U hU hU2 hC2 nu hnu hPDE (hpos y hy) n)]
  · exact hseries.mono (fun y hy => hy.summable)
  · exact hsumIntegrable
  · exact hseries

-- Exact original strip mass equals the infinite sum of physical normalized
-- mode energies. This does not identify a Gamma spectral resolution.
theorem integrated_periodicParseval_R {Y : ℝ} (hY : 1 ≤ Y) :
    (∑' n : ℤ, ∫ y in Ioi Y, hyperbolicModeEnergy N U nu y n) =
      ∫ p : PeriodCell × ℝ,
        p.2⁻¹^2*‖maassChart N U (p.1,p.2)‖^2
          ∂((volume : Measure PeriodCell).prod (volume.restrict (Ioi Y))) :=
  (hasSum_integrated_normalizedEnergy N U hU hU2 hC2 nu hnu hPDE hY).tsum_eq

end
end ImbalancedChen.Part3.ActualNormalizedStripParseval20261027
