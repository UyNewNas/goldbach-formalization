import ImbalancedChen.P2OriginalEnhancedPairRoots
import ImbalancedChen.P2EnhancedLowerGraphRankTwoSupport

-- SOURCE ONLY / UNCOMPILED_ZERO_CREDIT.
-- Concrete original L5/L6 roots instantiate the finite physical graph.
-- The support hypotheses are derived from the original root domains.
-- The rank is the COMPLETE concatenated slot count, including old marks.

namespace ImbalancedChen.P2OriginalEnhancedPairGraphSupport

noncomputable section
open Set
open P2EnhancedLowerPhysicalNode P2EnhancedLowerFinitePhysicalGraph
open P2OriginalEnhancedPairRoots P2EnhancedLowerGraphRankTwoSupport

def fifthStart (m : PrefixMark) (x : Fin 2 → ℝ) : TypedNode :=
  ⟨false,fifth m x⟩

def sixthStart (m : PrefixMark) (x : Fin 2 → ℝ) : TypedNode :=
  ⟨false,sixth m x⟩

theorem original_fifth_descendant_support {a b : ℝ} {mesh depth : ℕ}
    (m : PrefixMark) {x : Fin 2 → ℝ}
    (hx : x ∈ Part5OriginalUpsilon5CausalDictionary.triangle)
    {code : Program mesh depth} {z : Coordinates depth}
    (hz : Member a b depth (fifthStart m x) code z)
    (hrank : (realize depth (fifthStart m x) code z).physical.slots.length≤2) :
    (word (realize depth (fifthStart m x) code z).physical).sum≤1527/3584 := by
  have hg := fifth_admissible m hx
  have hb := fifth_support_inputs m hx
  have hw : WordBound (57/224) (fifth m x) := by
    intro t ht
    change t ∈ (fifth m x).slots.map Slot.exponent at ht
    obtain ⟨s,hs,hse⟩ := List.mem_map.mp ht
    rw [←hse]
    exact hb.2.1 s hs
  exact graph_lowRank_complete_exponent hg.1 hg.2.1 hg.2.2.2
    hb.1 hw hb.2.2 hz hrank

theorem original_sixth_descendant_support {a b eta : ℝ} {mesh depth : ℕ}
    (m : PrefixMark) (heta : 0≤eta) {x : Fin 2 → ℝ}
    (hx : x ∈ currentChenUpsilon6LogDomain eta)
    {code : Program mesh depth} {z : Coordinates depth}
    (hz : Member a b depth (sixthStart m x) code z)
    (hrank : (realize depth (sixthStart m x) code z).physical.slots.length≤2) :
    (word (realize depth (sixthStart m x) code z).physical).sum≤1527/3584 := by
  have hg := sixth_admissible m heta hx
  have hb := sixth_support_inputs m hx
  have hw : WordBound (57/224) (sixth m x) := by
    intro t ht
    change t ∈ (sixth m x).slots.map Slot.exponent at ht
    obtain ⟨s,hs,hse⟩ := List.mem_map.mp ht
    rw [←hse]
    exact hb.2.1 s hs
  exact graph_lowRank_complete_exponent hg.1 hg.2.1 hg.2.2.2
    hb.1 hw hb.2.2 hz hrank

end
end ImbalancedChen.P2OriginalEnhancedPairGraphSupport
