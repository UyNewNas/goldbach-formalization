import ImbalancedChen.P2EnhancedLowerPhysicalNode
import ImbalancedChen.CurrentChenP5CausalPrimeCorrectionPayment

-- SOURCE ONLY / UNCOMPILED_ZERO_CREDIT.
-- Original L5 and retained L6 root constructors, in physical decreasing
-- chronology. The level is the actual original piecewise causal level.
-- Marks below enumerate the three prefix patterns used by the v(t),
-- v(t+u), and W candidates. This does not assert a distribution licence
-- for every candidate, or choose a winning table action.

namespace ImbalancedChen.P2OriginalEnhancedPairRoots

noncomputable section
open Set
open P2EnhancedLowerPhysicalNode

inductive PrefixMark where
  | none | largest | both
  deriving DecidableEq, Fintype

def markedSlots (m : PrefixMark) (u t : ℝ) : List Slot :=
  match m with
  | .none => [⟨t,false⟩,⟨u,false⟩]
  | .largest => [⟨t,true⟩,⟨u,false⟩]
  | .both => [⟨t,true⟩,⟨u,true⟩]

def fifth (m : PrefixMark) (x : Fin 2 → ℝ) : PhysicalNode :=
  { occurrence := 4
    total := Part5OriginalUpsilon5CausalDictionary.level (x 0) (x 1)
    slots := markedSlots m (x 0) (x 1)
    ceiling := 417/5000
    argument := Part5OriginalUpsilon5CausalDictionary.argument x }

def sixth (m : PrefixMark) (x : Fin 2 → ℝ) : PhysicalNode :=
  { occurrence := 5
    total := P5U6CausalLevelGeometry.physicalLevel (x 0) (x 1)
    slots := markedSlots m (x 0) (x 1)
    ceiling := 417/5000
    argument := P5U6CausalLevelGeometry.argument x }

@[simp] theorem word_markedSlots (m : PrefixMark) (u t : ℝ) :
    (markedSlots m u t).map Slot.exponent = [t,u] := by
  cases m <;> rfl

@[simp] theorem fifth_word (m : PrefixMark) (x : Fin 2 → ℝ) :
    word (fifth m x) = [x 1,x 0] := word_markedSlots m _ _

@[simp] theorem sixth_word (m : PrefixMark) (x : Fin 2 → ℝ) :
    word (sixth m x) = [x 1,x 0] := word_markedSlots m _ _

@[simp] theorem fifth_residual (m : PrefixMark) (x : Fin 2 → ℝ) :
    residual (fifth m x) = Part5OriginalUpsilon5CausalDictionary.residual x := by
  simp only [residual,fifth_word,List.sum_cons,List.sum_nil,add_zero]
  dsimp [fifth,Part5OriginalUpsilon5CausalDictionary.residual]
  ring

@[simp] theorem sixth_residual (m : PrefixMark) (x : Fin 2 → ℝ) :
    residual (sixth m x) = P5U6CausalLevelGeometry.residual x := by
  simp only [residual,sixth_word,List.sum_cons,List.sum_nil,add_zero]
  dsimp [sixth,P5U6CausalLevelGeometry.residual]
  ring

@[simp] theorem fifth_alpha (m : PrefixMark) (x : Fin 2 → ℝ) :
    alpha (fifth m x) = Part5OriginalUpsilon5CausalDictionary.alpha x := by
  rw [alpha,fifth_word,fifth_residual]
  simp only [List.sum_cons,List.sum_nil,add_zero]
  unfold Part5OriginalUpsilon5CausalDictionary.alpha
  congr 1 <;> ring

@[simp] theorem sixth_alpha (m : PrefixMark) (x : Fin 2 → ℝ) :
    alpha (sixth m x) = P5U6CausalLevelGeometry.alpha x := by
  rw [alpha,sixth_word,sixth_residual]
  simp only [List.sum_cons,List.sum_nil,add_zero]
  unfold P5U6CausalLevelGeometry.alpha,P5U6CausalLevelGeometry.sourceExponent
  congr 1 <;> ring

-- These are primitive complete-prefix tests, not target-support premises.
theorem markedSlots_gates (m : PrefixMark) {u t Q : ℝ}
    (hfirst : 2*t≤Q) (hsecond : t+2*u≤Q) :
    SquareGates Q 0 ((markedSlots m u t).map Slot.exponent) ∧
    SquareGates Q (selectedWord (markedSlots m u t)).sum
      (remainingWord (markedSlots m u t)) := by
  cases m <;>
    simp [markedSlots,SquareGates,selectedWord,remainingWord,hfirst,hsecond]

theorem fifth_admissible (m : PrefixMark) {x : Fin 2 → ℝ}
    (hx : x ∈ Part5OriginalUpsilon5CausalDictionary.triangle) :
    fullGates (fifth m x) ∧ selectedGates (fifth m x) ∧
      0<residual (fifth m x) ∧ 2≤alpha (fifth m x) := by
  have hg := Part5OriginalUpsilon5CausalDictionary.selected_full_squares hx
  have hp := markedSlots_gates m hg.1.le hg.2.le
  exact ⟨hp.1,hp.2,by simpa using
    Part5OriginalUpsilon5CausalDictionary.residual_pos hx,by simpa using
    Part5OriginalUpsilon5CausalDictionary.alpha_ge_two hx⟩

theorem sixth_admissible (m : PrefixMark) {eta : ℝ} (heta : 0≤eta)
    {x : Fin 2 → ℝ} (hx : x ∈ currentChenUpsilon6LogDomain eta) :
    fullGates (sixth m x) ∧ selectedGates (sixth m x) ∧
      0<residual (sixth m x) ∧ 2≤alpha (sixth m x) := by
  have hg := P5U6CausalLevelGeometry.root_squares heta hx
  have hp := markedSlots_gates m hg.1.le hg.2.1.le
  exact ⟨hp.1,hp.2,by simpa using P5U6CausalLevelGeometry.residual_pos heta hx,
    by simpa using P5U6CausalLevelGeometry.alpha_ge_two heta hx⟩

-- Supply the actual primitive inputs needed for the total-rank support
-- theorem, including old slots; no new rough-rank bound is assumed here.
theorem fifth_support_inputs (m : PrefixMark) {x : Fin 2 → ℝ}
    (hx : x ∈ Part5OriginalUpsilon5CausalDictionary.triangle) :
    (fifth m x).total≤153/256 ∧
      (∀ s ∈ (fifth m x).slots,s.exponent≤57/224) ∧
      (fifth m x).ceiling≤57/224 := by
  obtain ⟨hu,hut,ht⟩ := Part5OriginalUpsilon5CausalDictionary.mem_triangle.mp hx
  refine ⟨P5CausalPrimeCorrectionPayment.original_U5_level_le_cap x,?_,by norm_num [fifth]⟩
  have ht' : x 1≤57/224 := by
    dsimp [Part5OriginalUpsilon5CausalDictionary.h] at ht
    linarith
  have hu' : x 0≤57/224 := hut.le.trans ht'
  cases m <;> simp [fifth,markedSlots] <;> exact ⟨ht',hu'⟩

theorem sixth_support_inputs (m : PrefixMark) {eta : ℝ}
    {x : Fin 2 → ℝ} (hx : x ∈ currentChenUpsilon6LogDomain eta) :
    (sixth m x).total≤153/256 ∧
      (∀ s ∈ (sixth m x).slots,s.exponent≤57/224) ∧
      (sixth m x).ceiling≤57/224 := by
  obtain ⟨hu,huh,hht,htd⟩ := mem_currentChenUpsilon6LogRectangle.mp hx.1
  refine ⟨P5CausalPrimeCorrectionPayment.original_U6_level_le_cap x,?_,by norm_num [sixth]⟩
  have ht' : x 1≤57/224 := by linarith only [htd]
  have hu' : x 0≤57/224 := by linarith only [huh]
  cases m <;> simp [sixth,markedSlots] <;> exact ⟨ht',hu'⟩

end
end ImbalancedChen.P2OriginalEnhancedPairRoots
