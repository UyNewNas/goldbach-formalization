import ImbalancedChen.CurrentP5MarkedElevenWitnessSource
import ImbalancedChen.P2EnhancedLowerFinitePhysicalGraph

-- SOURCE ONLY / UNCOMPILED_ZERO_CREDIT.
-- The actual eleven-root frontier before ordinary/positive licence
-- selection. This uses the original finite receiver/witness carrier,
-- keeping every receiver, row, and prime-tuple coordinate as a label.
-- It adds the physical chronological word and unrolled finite programs.
-- Its finiteness is constructive and needs no externally serialized graph.

namespace ImbalancedChen.P2OriginalElevenRootCarrier

noncomputable section
open scoped BigOperators
open Classical
open P2EnhancedLowerFinitePhysicalGraph

-- The padded witness coordinates are in ASCENDING prime order.
-- The physical chronology is the reverse, including the full fourth
-- prime in row eleven. Indicator rows have the empty prime prefix.
def primeWord (t : P5MarkedWitness) : List ℕ :=
  match t.1.val with
  | 0 | 1 => []
  | 2 | 3 => [t.2.2.1.1]
  | 9 | 10 => [t.2.2.2.2,t.2.2.2.1,t.2.2.1.2,t.2.2.1.1]
  | _ => [t.2.2.1.2,t.2.2.1.1]

def coordinate (N p : ℕ) : ℝ := Real.log (p:ℝ)/Real.log (N:ℝ)

def physicalWord (N : ℕ) (t : P5MarkedWitness) : List ℝ :=
  (primeWord t).map (coordinate N)

inductive RootKind where
  | causalLower | ordinaryUpper | pairLower | positiveProduct | upperAlternative
  deriving DecidableEq

def kind (i : Fin 11) : RootKind :=
  match i.val with
  | 0 | 1 => .causalLower
  | 2 | 3 => .ordinaryUpper
  | 4 | 5 => .pairLower
  | 6 | 7 | 8 => .positiveProduct
  | _ => .upperAlternative

-- No H/h query is introduced for the three positive-product roots.
theorem positive_root_kinds :
    kind 6=.positiveProduct ∧ kind 7=.positiveProduct ∧ kind 8=.positiveProduct := by
  exact ⟨rfl,rfl,rfl⟩

theorem primeWord_length (t : P5MarkedWitness) :
    (primeWord t).length≤4 := by
  rcases t with ⟨i,P,q⟩
  fin_cases i <;> norm_num [primeWord]

@[simp] theorem tenth_word (P : ℕ) (q : P5WitnessFour) :
    primeWord (9,(P,q)) = [q.2.2,q.2.1,q.1.2,q.1.1] := rfl

@[simp] theorem eleventh_word (P : ℕ) (q : P5WitnessFour) :
    primeWord (10,(P,q)) = [q.2.2,q.2.1,q.1.2,q.1.1] := rfl

-- A root label includes the ORIGINAL mark itself. Equal prime products
-- from different rows, receivers, or tuple labels are never identified.
abbrev RootLabel := P5MarkedWitness × List ℕ

def label (t : P5MarkedWitness) : RootLabel := (t,primeWord t)

theorem label_injective : Function.Injective label := by
  intro t u h
  exact congrArg Prod.fst h

def roots (N : ℕ) (E : ℕ×ℕ → Prop) : Finset RootLabel :=
  (p5MarkedElevenSource N E).image label

theorem mem_roots (N : ℕ) (E : ℕ×ℕ → Prop) (t : P5MarkedWitness) :
    label t ∈ roots N E ↔ t ∈ p5MarkedElevenSource N E := by
  constructor
  · intro h
    obtain ⟨u,hu,he⟩ := Finset.mem_image.mp h
    exact label_injective he ▸ hu
  · intro h
    exact Finset.mem_image.mpr ⟨t,h,rfl⟩

theorem roots_card (N : ℕ) (E : ℕ×ℕ → Prop) :
    (roots N E).card=(p5MarkedElevenSource N E).card :=
  Finset.card_image_of_injective _ label_injective

-- The root-to-program frontier is literally finite for every horizon.
-- Geometric membership and evaluation use the existing deterministic
-- physical constructor after an admissible ordinary root is selected.
def frontier (N : ℕ) (E : ℕ×ℕ → Prop) (mesh horizon : ℕ) :
    Finset (RootLabel × GraphVertex mesh horizon) :=
  roots N E ×ˢ allVertices mesh horizon

theorem mem_frontier (N : ℕ) (E : ℕ×ℕ → Prop) (mesh horizon : ℕ)
    (r : RootLabel) (v : GraphVertex mesh horizon) :
    (r,v) ∈ frontier N E mesh horizon ↔ r ∈ roots N E := by
  simp only [frontier,Finset.mem_product,allVertices,Finset.mem_univ,and_true]

-- This exact identity binds the concrete root labels to the original
-- paired eleven functional, with the SAME E in L6 and U11 and no E in U10.
theorem roots_signed_sum (N : ℕ) (E : ℕ×ℕ → Prop) :
    (∑ r ∈ roots N E,p5CausalReceiverLedgerWeight r.1.1) =
      currentChenPairedPrimeSum N E := by
  rw [roots,Finset.sum_image]
  · exact p5MarkedElevenSource_signed_sum N E
  · intro t ht u hu he
    exact label_injective he

end
end ImbalancedChen.P2OriginalElevenRootCarrier
