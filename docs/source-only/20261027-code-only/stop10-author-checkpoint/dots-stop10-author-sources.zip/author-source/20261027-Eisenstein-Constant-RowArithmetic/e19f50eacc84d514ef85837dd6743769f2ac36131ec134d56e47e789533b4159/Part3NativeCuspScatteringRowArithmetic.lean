import ImbalancedChen.Part3NativeAllCuspEisenstein
import ImbalancedChen.Part3PrimitiveEisensteinParameterAutomorphy
import ImbalancedChen.Part3Gamma0GeneralCuspUnitPeriod

-- SOURCE ONLY / UNCOMPILED / ZERO FORMAL CREDIT.
-- Literal arbitrary-cusp scattering row arithmetic. The original Gamma0
-- witnesses and both actual widths remain visible. This supplies finite
-- Dirichlet coefficients, not a postulated Fourier expansion of Eisenstein.

namespace ImbalancedChen.Part3.NativeCuspScatteringRowArithmetic20261027
noncomputable section
open Matrix Matrix.SpecialLinearGroup
open scoped MatrixGroups UpperHalfPlane BigOperators
open ImbalancedChen.Part3.Gamma0ParabolicBottomRow20261025a
open ImbalancedChen.Part3.Gamma0GeneralCuspWidth20261025a
open ImbalancedChen.Part3.Gamma0GeneralCuspUnitPeriod20261025a
open ImbalancedChen.Part3.PrimitiveRealEisensteinAutomorphy
open ImbalancedChen.Part3.PrimitiveEisensteinParameterAnalytic
open ImbalancedChen.Part3.PrimitiveEisensteinParameterAutomorphy
open ImbalancedChen.Part3.NativeAllCuspEisenstein20261026b

def framedRow (N : ℕ) (g h : SL(2, ℤ)) (c d : ℤ) : Prop :=
  ∃ gamma : CongruenceSubgroup.Gamma0 N,
    bottomRow (g⁻¹ * (gamma : SL(2, ℤ)) * h) = ![c, d]

private theorem bottomRow_mul (a b : SL(2, ℤ)) :
    bottomRow (a*b) = bottomRow a ᵥ* (b : Matrix (Fin 2) (Fin 2) ℤ) := by
  funext j
  simp [bottomRow, Matrix.vecMul, Matrix.mul_apply, coe_mul]

-- This connects the arithmetic predicate to the common native allowedRow;
-- it does not replace the original Gamma0 subgroup with a conjugate subgroup.
theorem framedRow_primitive_action_iff (N : ℕ) (g h : SL(2, ℤ)) (v : PrimitivePair) :
    framedRow N g h ((primitivePairEquiv h v).1 0) ((primitivePairEquiv h v).1 1) ↔
      allowedRow N g v := by
  have hvec : ![((primitivePairEquiv h v).1 0), ((primitivePairEquiv h v).1 1)] =
      (primitivePairEquiv h v).1 := by
    funext j
    fin_cases j <;> rfl
  rw [framedRow, hvec]
  constructor
  · rintro ⟨gamma, hgamma⟩
    refine ⟨gamma, ?_⟩
    have he := congrArg (fun u : Fin 2 → ℤ =>
      u ᵥ* ((h⁻¹ : SL(2, ℤ)) : Matrix (Fin 2) (Fin 2) ℤ)) hgamma
    rw [bottomRow_mul, primitivePairEquiv_value, Matrix.vecMul_vecMul,
      Matrix.vecMul_vecMul] at he
    have hi : (h : Matrix (Fin 2) (Fin 2) ℤ) *
        ((h⁻¹ : SL(2, ℤ)) : Matrix (Fin 2) (Fin 2) ℤ) = 1 := by
      rw [← coe_mul]; simp
    simpa only [hi, Matrix.vecMul_one] using he
  · rintro ⟨gamma, hgamma⟩
    refine ⟨gamma, ?_⟩
    rw [bottomRow_mul, hgamma, primitivePairEquiv_value]

private theorem framedRow_shift (N : ℕ) (hN : 0 < N) (g h : SL(2, ℤ))
    (c d k : ℤ) (hr : framedRow N g h c d) :
    framedRow N g h c (d+c*(cuspWidth N h : ℤ)*k) := by
  obtain ⟨gamma, hgamma⟩ := hr
  let delta : CongruenceSubgroup.Gamma0 N :=
    ⟨h * ModularGroup.T ^ ((cuspWidth N h : ℤ)*k) * h⁻¹,
      width_multiple_mem_gamma0 N hN h k⟩
  refine ⟨gamma*delta, ?_⟩
  have hg : g⁻¹ * ((gamma*delta : CongruenceSubgroup.Gamma0 N) : SL(2, ℤ)) * h =
      (g⁻¹ * (gamma : SL(2, ℤ)) * h) *
        ModularGroup.T ^ ((cuspWidth N h : ℤ)*k) := by
    simp only [Subgroup.coe_mul, delta]
    group
  rw [hg, bottomRow_mul, hgamma]
  funext j
  fin_cases j <;>
    simp [Matrix.vecMul, ModularGroup.coe_T_zpow] <;> ring

-- Exact integral residue period in the observing frame h. The normalized
-- real horizontal period is one, and this integer d period is c*width(h).
theorem framedRow_shift_iff (N : ℕ) (hN : 0 < N) (g h : SL(2, ℤ))
    (c d k : ℤ) :
    framedRow N g h c (d+c*(cuspWidth N h : ℤ)*k) ↔ framedRow N g h c d := by
  constructor
  · intro hr
    have he := framedRow_shift N hN g h c (d+c*(cuspWidth N h : ℤ)*k) (-k) hr
    convert he using 1 <;> ring
  · exact framedRow_shift N hN g h c d k

theorem framedRow_bezout (N : ℕ) (g h : SL(2, ℤ)) (c d : ℤ)
    (hr : framedRow N g h c d) : ∃ u v : ℤ, u*c+v*d=1 := by
  obtain ⟨gamma, hgamma⟩ := hr
  obtain ⟨u, v, huv⟩ := bottomRow_bezout (g⁻¹ * (gamma : SL(2, ℤ)) * h)
  refine ⟨u, v, ?_⟩
  simpa [hgamma] using huv

-- The zero denominator has precisely the two primitive signs, so a later
-- half-pair decomposition must count the leading term once.
theorem framedRow_zero_unit (N : ℕ) (g h : SL(2, ℤ)) (d : ℤ)
    (hr : framedRow N g h 0 d) : d=1 ∨ d = -1 := by
  obtain ⟨u, v, huv⟩ := framedRow_bezout N g h 0 d hr
  have hv : v*d=1 := by simpa using huv
  rcases Int.eq_one_or_neg_one_of_mul_eq_one' hv with ⟨_, hd⟩ | ⟨_, hd⟩
  · exact Or.inl hd
  · exact Or.inr hd

def residueBlock (N : ℕ) (g h : SL(2, ℤ)) (c : ℕ) : Finset ℕ := by
  classical
  exact (Finset.range (c*cuspWidth N h)).filter
    (fun d => framedRow N g h (c : ℤ) (d : ℤ))

def scatteringDirichletCoeff (N : ℕ) (g h : SL(2, ℤ)) (c : ℕ) : ℕ :=
  (residueBlock N g h c).card

theorem mem_residueBlock (N : ℕ) (g h : SL(2, ℤ)) (c d : ℕ) :
    d ∈ residueBlock N g h c ↔
      d < c*cuspWidth N h ∧ framedRow N g h (c : ℤ) (d : ℤ) := by
  classical
  simp [residueBlock]

theorem scatteringDirichletCoeff_le (N : ℕ) (g h : SL(2, ℤ)) (c : ℕ) :
    scatteringDirichletCoeff N g h c ≤ c*cuspWidth N h := by
  classical
  calc
    _ ≤ (Finset.range (c*cuspWidth N h)).card :=
      Finset.card_le_card (Finset.filter_subset _ _)
    _ = _ := Finset.card_range _

@[simp] theorem scatteringDirichletCoeff_zero (N : ℕ) (g h : SL(2, ℤ)) :
    scatteringDirichletCoeff N g h 0 = 0 := by
  simp [scatteringDirichletCoeff, residueBlock]

-- Exact real cusp-pair matrix. Its lower entries supply the Dirichlet
-- denominator C and horizontal shift D/C; neither width is dropped.
def normalizedCuspProduct (N : ℕ) (hN : 0 < N) (g h : SL(2, ℤ))
    (gamma : CongruenceSubgroup.Gamma0 N) : SL(2, ℝ) :=
  (normalizedScaling N hN g)⁻¹ * integralReal (gamma : SL(2, ℤ)) *
    normalizedScaling N hN h

theorem normalizedCuspProduct_lower_entries (N : ℕ) (hN : 0 < N)
    (g h : SL(2, ℤ)) (gamma : CongruenceSubgroup.Gamma0 N) :
    normalizedCuspProduct N hN g h gamma 1 0 =
      Real.sqrt (cuspWidth N g : ℝ) *
        ((g⁻¹*(gamma : SL(2, ℤ))*h) 1 0 : ℝ) * Real.sqrt (cuspWidth N h : ℝ) ∧
    normalizedCuspProduct N hN g h gamma 1 1 =
      Real.sqrt (cuspWidth N g : ℝ) *
        ((g⁻¹*(gamma : SL(2, ℤ))*h) 1 1 : ℝ) / Real.sqrt (cuspWidth N h : ℝ) := by
  have hprod : normalizedCuspProduct N hN g h gamma =
      (widthDiagonal (cuspWidth N g) (cuspWidth_pos N hN g))⁻¹ *
        integralReal (g⁻¹*(gamma : SL(2, ℤ))*h) *
          widthDiagonal (cuspWidth N h) (cuspWidth_pos N hN h) := by
    simp [normalizedCuspProduct, normalizedScaling, integralReal, mul_inv_rev,
      mul_assoc]
  rw [hprod]
  constructor <;>
    simp [widthDiagonal, integralReal, SL2_inv_expl, coe_mul, Matrix.mul_fin_two,
      Matrix.SpecialLinearGroup.map_apply_coe] <;> ring

theorem normalizedCuspProduct_lower_ratio (N : ℕ) (hN : 0 < N)
    (g h : SL(2, ℤ)) (gamma : CongruenceSubgroup.Gamma0 N)
    (hc : (g⁻¹*(gamma : SL(2, ℤ))*h) 1 0 ≠ 0) :
    normalizedCuspProduct N hN g h gamma 1 1 /
        normalizedCuspProduct N hN g h gamma 1 0 =
      ((g⁻¹*(gamma : SL(2, ℤ))*h) 1 1 : ℝ) /
        (((g⁻¹*(gamma : SL(2, ℤ))*h) 1 0 : ℝ) * (cuspWidth N h : ℝ)) := by
  have hwg : 0 < (cuspWidth N g : ℝ) := by exact_mod_cast cuspWidth_pos N hN g
  have hwh : 0 < (cuspWidth N h : ℝ) := by exact_mod_cast cuspWidth_pos N hN h
  have hsg := (Real.sqrt_pos.mpr hwg).ne'
  have hsh := (Real.sqrt_pos.mpr hwh).ne'
  have hcr : ((g⁻¹*(gamma : SL(2, ℤ))*h) 1 0 : ℝ) ≠ 0 := by exact_mod_cast hc
  rw [(normalizedCuspProduct_lower_entries N hN g h gamma).1,
    (normalizedCuspProduct_lower_entries N hN g h gamma).2]
  conv_rhs => rw [← Real.sq_sqrt hwh.le]
  field_simp [hsg, hsh, hcr] <;> ring

end
end ImbalancedChen.Part3.NativeCuspScatteringRowArithmetic20261027
