import ImbalancedChen.Part3NativeCuspScatteringRowArithmetic
import Mathlib.NumberTheory.LSeries.Dirichlet

-- SOURCE ONLY / UNCOMPILED / ZERO FORMAL CREDIT.
-- The actual finite residue counts, not a free coefficient family, define
-- a genuinely absolutely convergent cusp-pair Dirichlet series for Re(s)>1.
-- Identifying it with the horocycle constant term still requires native
-- row regrouping and the justified real integral interchange.

namespace ImbalancedChen.Part3.NativeCuspScatteringDirichlet20261027
noncomputable section
open Complex Matrix Matrix.SpecialLinearGroup
open scoped MatrixGroups
open ImbalancedChen.Part3.Gamma0GeneralCuspWidth20261025a
open ImbalancedChen.Part3.NativeCuspScatteringRowArithmetic20261027

def scatteringCoeffComplex (N : ℕ) (g h : SL(2, ℤ)) (n : ℕ) : ℂ :=
  (scatteringDirichletCoeff N g h n : ℂ)

@[simp] theorem scatteringCoeffComplex_zero (N : ℕ) (g h : SL(2, ℤ)) :
    scatteringCoeffComplex N g h 0 = 0 := by
  simp [scatteringCoeffComplex]

theorem norm_scatteringCoeffComplex_le (N : ℕ) (g h : SL(2, ℤ)) (n : ℕ) :
    ‖scatteringCoeffComplex N g h n‖ ≤ (cuspWidth N h : ℝ)*(n : ℝ) := by
  have hb : (scatteringDirichletCoeff N g h n : ℝ) ≤
      ((n*cuspWidth N h : ℕ) : ℝ) := by
    exact_mod_cast scatteringDirichletCoeff_le N g h n
  simpa [scatteringCoeffComplex, mul_comm] using hb

-- Absolute convergence follows solely from the proved finite count bound.
-- It does not use an Eisenstein Fourier expansion or spectral assertion.
theorem scatteringCoeffComplex_LSeriesSummable (N : ℕ) (g h : SL(2, ℤ))
    {z : ℂ} (hz : 2 < z.re) : LSeriesSummable (scatteringCoeffComplex N g h) z := by
  apply LSeriesSummable_of_le_const_mul_rpow (x := 2) hz
  refine ⟨(cuspWidth N h : ℝ), ?_⟩
  intro n hn
  simpa only [show (2 : ℝ)-1=1 by norm_num, Real.rpow_one] using
    norm_scatteringCoeffComplex_le N g h n

theorem scattering_terms_norm_summable (N : ℕ) (g h : SL(2, ℤ))
    (s : ℂ) (hs : 1 < s.re) :
    Summable (fun n : ℕ => ‖LSeries.term (scatteringCoeffComplex N g h) (2*s) n‖) := by
  have hz : 2 < (2*s).re := by simpa using (show 2 < 2*s.re by linarith)
  exact (scatteringCoeffComplex_LSeriesSummable N g h hz).norm

def scatteringWidthFactor (N : ℕ) (g h : SL(2, ℤ)) (s : ℂ) : ℂ :=
  Complex.exp (-s * ((Real.log (cuspWidth N g : ℝ) +
    Real.log (cuspWidth N h : ℝ) : ℝ) : ℂ))

def scatteringDirichletSeries (N : ℕ) (g h : SL(2, ℤ)) (s : ℂ) : ℂ :=
  scatteringWidthFactor N g h s * LSeries (scatteringCoeffComplex N g h) (2*s)

def scatteringDirichletTerm (N : ℕ) (g h : SL(2, ℤ)) (s : ℂ) (n : ℕ) : ℂ :=
  scatteringWidthFactor N g h s * LSeries.term (scatteringCoeffComplex N g h) (2*s) n

theorem scatteringDirichletTerm_norm_summable (N : ℕ) (g h : SL(2, ℤ))
    (s : ℂ) (hs : 1 < s.re) :
    Summable (fun n : ℕ => ‖scatteringDirichletTerm N g h s n‖) := by
  simpa only [scatteringDirichletTerm, norm_mul] using
    (scattering_terms_norm_summable N g h s hs).mul_left
      ‖scatteringWidthFactor N g h s‖

theorem scatteringDirichletSeries_eq_tsum (N : ℕ) (g h : SL(2, ℤ)) (s : ℂ) :
    scatteringDirichletSeries N g h s = ∑' n : ℕ, scatteringDirichletTerm N g h s n := by
  simp only [scatteringDirichletSeries, scatteringDirichletTerm, LSeries, tsum_mul_left]

theorem norm_scatteringWidthFactor (N : ℕ) (g h : SL(2, ℤ)) (s : ℂ) :
    ‖scatteringWidthFactor N g h s‖ =
      Real.exp (-s.re*(Real.log (cuspWidth N g : ℝ)+Real.log (cuspWidth N h : ℝ))) := by
  rw [scatteringWidthFactor, Complex.norm_exp]
  simp

end
end ImbalancedChen.Part3.NativeCuspScatteringDirichlet20261027
