import ImbalancedChen.Part3ActualCuspKernelNormalSeries
import ImbalancedChen.Part3ActualGamma0MaassDescent

-- SOURCE ONLY. UNCOMPILED_ZERO_CREDIT. All original actual spectral holds retained.
-- Independent actual Gamma0 actions in both variables, from the selected eigenprofiles.
-- This concerns only the original discrete cuspidal series; no raw angular parameter,
-- Eisenstein term, scattering measure or functional-calculus kernel is substituted.
namespace ImbalancedChen.Part3.ActualCuspKernelAutomorphy20261027
noncomputable section
open scoped UpperHalfPlane BigOperators
open ActualFullCuspEigenbasis20261026b ActualCuspEigenbasisNativeLabels20261026b
open ActualCuspSmoothEigenprofileFamily20261026b ActualCuspKernelNormalSeries20261027
open ActualGamma0MaassDescent20261025a MaassWeakOperatorCore20261024zz
open MixedSpectralKernelNormalConvergence20261026b
open SmoothMixedSpectralKernelSeries20261026b RapidSpectralCoefficientWeights20261026b

def actualCuspUpperKernelTerm (N : ℕ) [NeZero N] (hN : 0 < N) (h : ℝ → ℂ)
    (i : actualCuspBasisIndex N hN) (z w : UpperHalfPlane) : ℂ :=
  h (actualCuspNativeEigenvalue N hN i) * actualCuspSmoothProfile N hN i z *
    star (actualCuspSmoothProfile N hN i w)

def actualCuspUpperKernel (N : ℕ) [NeZero N] (hN : 0 < N) (h : ℝ → ℂ)
    (z w : UpperHalfPlane) : ℂ :=
  ∑' i, actualCuspUpperKernelTerm N hN h i z w

theorem actualCuspKernelTerm_at_upper (N : ℕ) [NeZero N] (hN : 0 < N)
    (h : ℝ → ℂ) (i : actualCuspBasisIndex N hN) (z w : UpperHalfPlane) :
    actualCuspKernelTerm N hN h i ((z.re,z.im),(w.re,w.im)) =
      actualCuspUpperKernelTerm N hN h i z w := by
  change h (actualCuspNativeEigenvalue N hN i) *
    extendUpper (actualCuspSmoothProfile N hN i) (z.re,z.im) *
      star (extendUpper (actualCuspSmoothProfile N hN i) (w.re,w.im)) = _
  rw [extendUpper_pair, extendUpper_pair]
  rfl

theorem actualCuspKernel_at_upper (N : ℕ) [NeZero N] (hN : 0 < N)
    (h : ℝ → ℂ) (z w : UpperHalfPlane) :
    actualCuspKernel N hN h ((z.re,z.im),(w.re,w.im)) =
      actualCuspUpperKernel N hN h z w := by
  apply tsum_congr
  intro i
  exact actualCuspKernelTerm_at_upper N hN h i z w

-- The finite terms themselves are invariant, independently in each variable.
theorem actualCuspUpperKernelTerm_gamma_left (N : ℕ) [NeZero N] (hN : 0 < N)
    (h : ℝ → ℂ) (i : actualCuspBasisIndex N hN)
    (gamma : CongruenceSubgroup.Gamma0 N) (z w : UpperHalfPlane) :
    actualCuspUpperKernelTerm N hN h i (gamma • z) w =
      actualCuspUpperKernelTerm N hN h i z w := by
  unfold actualCuspUpperKernelTerm
  rw [(actualCuspSmoothProfile_spec N hN i).2.2.1 gamma z]

theorem actualCuspUpperKernelTerm_gamma_right (N : ℕ) [NeZero N] (hN : 0 < N)
    (h : ℝ → ℂ) (i : actualCuspBasisIndex N hN)
    (gamma : CongruenceSubgroup.Gamma0 N) (z w : UpperHalfPlane) :
    actualCuspUpperKernelTerm N hN h i z (gamma • w) =
      actualCuspUpperKernelTerm N hN h i z w := by
  unfold actualCuspUpperKernelTerm
  rw [(actualCuspSmoothProfile_spec N hN i).2.2.1 gamma w]

-- No automorphy hypothesis is accepted from the caller: it is a selected profile fact.
theorem actualCuspUpperKernel_gamma_left (N : ℕ) [NeZero N] (hN : 0 < N)
    (h : ℝ → ℂ) (gamma : CongruenceSubgroup.Gamma0 N) (z w : UpperHalfPlane) :
    actualCuspUpperKernel N hN h (gamma • z) w = actualCuspUpperKernel N hN h z w := by
  apply tsum_congr
  intro i
  exact actualCuspUpperKernelTerm_gamma_left N hN h i gamma z w

theorem actualCuspUpperKernel_gamma_right (N : ℕ) [NeZero N] (hN : 0 < N)
    (h : ℝ → ℂ) (gamma : CongruenceSubgroup.Gamma0 N) (z w : UpperHalfPlane) :
    actualCuspUpperKernel N hN h z (gamma • w) = actualCuspUpperKernel N hN h z w := by
  apply tsum_congr
  intro i
  exact actualCuspUpperKernelTerm_gamma_right N hN h i gamma z w

theorem actualCuspUpperKernel_gamma_both (N : ℕ) [NeZero N] (hN : 0 < N)
    (h : ℝ → ℂ) (gamma delta : CongruenceSubgroup.Gamma0 N) (z w : UpperHalfPlane) :
    actualCuspUpperKernel N hN h (gamma • z) (delta • w) =
      actualCuspUpperKernel N hN h z w := by
  rw [actualCuspUpperKernel_gamma_left, actualCuspUpperKernel_gamma_right]

-- Rapid coefficients make the upper series a genuinely absolutely summable series.
-- The automorphy statements above therefore apply to the smooth kernel constructed earlier.
theorem actualCuspUpperKernel_norm_summable (N : ℕ) [NeZero N] (hN : 0 < N)
    {h : ℝ → ℂ} (hh : RapidOnNonnegative h) (z w : UpperHalfPlane) :
    Summable (fun i => ‖actualCuspUpperKernelTerm N hN h i z w‖) := by
  have hs := actualCuspKernel_derivative_summable N hN hh []
    (p := ((z.re,z.im),(w.re,w.im))) ⟨z.im_pos,w.im_pos⟩
  apply hs.congr
  intro i
  change ‖actualCuspKernelTerm N hN h i ((z.re,z.im),(w.re,w.im))‖ = _
  rw [actualCuspKernelTerm_at_upper]

end
end ImbalancedChen.Part3.ActualCuspKernelAutomorphy20261027
