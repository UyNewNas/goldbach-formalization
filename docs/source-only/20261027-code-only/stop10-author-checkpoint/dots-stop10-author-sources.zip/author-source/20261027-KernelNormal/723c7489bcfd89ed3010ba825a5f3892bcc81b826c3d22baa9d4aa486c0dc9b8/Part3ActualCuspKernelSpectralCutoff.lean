import ImbalancedChen.Part3ActualCuspKernelNormalSeries
import ImbalancedChen.Part3ActualCuspBasisIndexCounting
import Mathlib.Order.Filter.AtTopBot.Finset

-- SOURCE ONLY. UNCOMPILED_ZERO_CREDIT. Original actual spectral API holds retained.
-- Converts arbitrary finite-index convergence to genuine native-energy truncation.
-- Repeated eigenvalues enter together, through their original multiplicity slots.
namespace ImbalancedChen.Part3.ActualCuspKernelSpectralCutoff20261027
noncomputable section
open Set Filter
open scoped Topology BigOperators
open CompactC2ProductMollifier20261026a MixedSpectralKernelNormalConvergence20261026b
open ActualFullCuspEigenbasis20261026b ActualCuspEigenbasisNativeLabels20261026b
open ActualCuspBasisIndexCounting20261026b Gamma0ActualSmoothQuotientCore20261025a
open RapidSpectralCoefficientWeights20261026b SmoothMixedSpectralKernelSeries20261026b
open ActualCuspKernelNormalSeries20261027

def actualCuspSpectralFinset (N : ℕ) [NeZero N] (hN : 0 < N) (T : ℝ) :
    Finset (actualCuspBasisIndex N hN) :=
  (actualCuspIndexSublevel_finite N hN T).toFinset

@[simp] theorem mem_actualCuspSpectralFinset (N : ℕ) [NeZero N] (hN : 0 < N)
    (T : ℝ) (i : actualCuspBasisIndex N hN) :
    i ∈ actualCuspSpectralFinset N hN T ↔ actualCuspNativeEigenvalue N hN i ≤ T := by
  simp [actualCuspSpectralFinset, actualCuspIndexSublevel]

theorem actualCuspSpectralFinset_monotone (N : ℕ) [NeZero N] (hN : 0 < N) :
    Monotone (actualCuspSpectralFinset N hN) := by
  intro S T hST i hi
  exact (mem_actualCuspSpectralFinset N hN T i).mpr
    (((mem_actualCuspSpectralFinset N hN S i).mp hi).trans hST)

-- Cofinality is proved from the actual native label of each basis vector.
-- No chosen enumeration, distinct-eigenvalue restriction, or cutoff convergence is assumed.
theorem actualCuspSpectralFinset_tendsto (N : ℕ) [NeZero N] (hN : 0 < N) :
    Tendsto (actualCuspSpectralFinset N hN) atTop atTop := by
  apply (actualCuspSpectralFinset_monotone N hN).tendsto_atTop_finset
  intro i
  exact ⟨actualCuspNativeEigenvalue N hN i,
    (mem_actualCuspSpectralFinset N hN _ i).mpr le_rfl⟩

def actualCuspKernelSpectralJetCutoff (N : ℕ) [NeZero N] (hN : 0 < N)
    (h : ℝ → ℂ) (w : List (Fin 4)) (T : ℝ) (p : PairPlane) : ℂ :=
  ∑ i ∈ actualCuspSpectralFinset N hN T,
    pairWordPartial w (actualCuspKernelTerm N hN h i) p

-- The limiting function is the genuine classical derivative of the actual kernel.
theorem actualCuspKernel_spectral_cutoff_derivatives_normal (N : ℕ) [NeZero N]
    (hN : 0 < N) {h : ℝ → ℂ} (hh : RapidOnNonnegative h) (w : List (Fin 4))
    {K L : Set Plane} (hK : IsCompact K) (hL : IsCompact L)
    (hKO : K ⊆ upperChart) (hLO : L ⊆ upperChart) :
    TendstoUniformlyOn (actualCuspKernelSpectralJetCutoff N hN h w)
      (pairWordPartial w (actualCuspKernel N hN h)) atTop (K ×ˢ L) := by
  obtain ⟨hnormal, htermwise⟩ :=
    actualCuspKernel_all_derivatives_normal N hN hh w hK hL hKO hLO
  have hnormal' := hnormal.congr_right (fun p hp => (htermwise p hp).symm)
  intro u hu
  exact (actualCuspSpectralFinset_tendsto N hN).eventually (hnormal' u hu)

theorem actualCuspKernel_spectral_cutoff_tendsto_at (N : ℕ) [NeZero N]
    (hN : 0 < N) {h : ℝ → ℂ} (hh : RapidOnNonnegative h) (w : List (Fin 4))
    {p : PairPlane} (hp : p ∈ upperChart ×ˢ upperChart) :
    Tendsto (fun T => actualCuspKernelSpectralJetCutoff N hN h w T p) atTop
      (𝓝 (pairWordPartial w (actualCuspKernel N hN h) p)) := by
  have hn := actualCuspKernel_spectral_cutoff_derivatives_normal N hN hh w
    (isCompact_singleton (x := p.1)) (isCompact_singleton (x := p.2))
    (singleton_subset_iff.mpr hp.1) (singleton_subset_iff.mpr hp.2)
  exact hn.tendsto_at ⟨rfl, rfl⟩

end
end ImbalancedChen.Part3.ActualCuspKernelSpectralCutoff20261027
