import ImbalancedChen.Part3NativeCuspComplexSeriesDifferential
import Mathlib.Analysis.Calculus.ContDiff.Comp
import Mathlib.Tactic

-- SOURCE ONLY / UNCOMPILED / ZERO FORMAL CREDIT.
-- Genuine C2 and Maass eigen-equation of the original allowed-row cusp series.
-- The summable Hessian bound proves continuity and the Frechet series theorem
-- proves differentiability. Coordinatewise existence is not used to infer C2.

namespace ImbalancedChen.Part3.NativeAllCuspEisensteinC2Maass20261027
noncomputable section
open Set Filter Complex UpperHalfPlane
open scoped Topology UpperHalfPlane MatrixGroups BigOperators
open ImbalancedChen.Part3.RealEisensteinSeedLaplacian
open ImbalancedChen.Part3.Gamma0GeneralCuspWidth20261025a
open ImbalancedChen.Part3.NativeAllCuspEisenstein20261026b
open ImbalancedChen.Part3.NativeCuspComplexLogJets20261026b
open ImbalancedChen.Part3.NativeCuspComplexJetMajorants20261026b
open ImbalancedChen.Part3.NativeCuspComplexSeriesDifferential20261027

theorem coordinateJet_continuousAt (j : JetSlot) (w : ℝ) (s : ℂ)
    (c d : ℝ) (p : Plane) (hcd : c≠0 ∨ d≠0) (hp : 0<p.2) :
    ContinuousAt (fun q : Plane => coordinateJet j w s c d q.1 q.2) p := by
  have hq : Q c d p.1 p.2≠0 := (Q_pos hcd hp).ne'
  have hQ : ContinuousAt (fun q : Plane => Q c d q.1 q.2) p := by unfold Q; fun_prop
  have hqx : ContinuousAt (fun q : Plane => Qx c d q.1) p := by unfold Qx; fun_prop
  have hqy : ContinuousAt (fun q : Plane => Qy c q.2) p := by unfold Qy; fun_prop
  have hX : ContinuousAt (fun q : Plane => logX c d q.1 q.2) p := hqx.neg.div hQ hq
  have hY : ContinuousAt (fun q : Plane => logY c d q.1 q.2) p :=
    (continuousAt_const.div continuous_snd.continuousAt hp.ne').sub (hqy.div hQ hq)
  have hXX : ContinuousAt (fun q : Plane => logXX c d q.1 q.2) p :=
    ((hqx.div hQ hq).pow 2).sub (continuousAt_const.div hQ hq)
  have hXY : ContinuousAt (fun q : Plane => logXY c d q.1 q.2) p :=
    (hqx.mul hqy).div (hQ.pow 2) (pow_ne_zero 2 hq)
  have hYY : ContinuousAt (fun q : Plane => logYY c d q.1 q.2) p :=
    ((continuousAt_const.div (continuous_snd.continuousAt.pow 2) (pow_ne_zero 2 hp.ne')).add
      ((hqy.div hQ hq).pow 2)).sub (continuousAt_const.div hQ hq)
  have hXc := Complex.continuous_ofReal.continuousAt.comp hX
  have hYc := Complex.continuous_ofReal.continuousAt.comp hY
  have hXXc := Complex.continuous_ofReal.continuousAt.comp hXX
  have hXYc := Complex.continuous_ofReal.continuousAt.comp hXY
  have hYYc := Complex.continuous_ofReal.continuousAt.comp hYY
  have hK := (kernel_differentiableAt w s c d p hcd hp).continuousAt
  have hC : ContinuousAt (fun q : Plane => coefficient j s c d q.1 q.2) p := by
    cases j <;> dsimp [coefficient] <;> fun_prop
  exact hC.mul hK

-- Continuity of every actual jet sum follows on a genuine neighborhood from
-- the immutable local uniform majorant, including all second and mixed jets.
theorem jetSum_continuousOn (N : ℕ) (hN : 0<N) (g : SL(2,ℤ))
    (j : JetSlot) (s : ℂ) (hs : 1<s.re) : ContinuousOn (jetSum N g j s) upperDomain := by
  intro p hp
  have hB : 0<p.2/2 := by linarith
  let A : ℝ := |p.1|+1
  let D : Set Plane := Ioo (p.1-1) (p.1+1) ×ˢ Ioo (p.2/2) (3*p.2/2)
  let u := rowJetMajorant N g s.re s.re ‖s‖ A (p.2/2) (3*p.2/2) hB
  have hmem : p∈D := by constructor <;> constructor <;> linarith
  have hc : ContinuousOn (jetSum N g j s) D := by
    apply continuousOn_tsum (u := u)
    · intro v q hq
      exact (coordinateJet_continuousAt j _ s _ _ q
        (primitive_coordinates_nonzero v.1) (hB.trans hq.2.1)).continuousWithinAt
    · exact rowJetMajorant_summable N g s.re s.re ‖s‖ A (p.2/2) (3*p.2/2) hs hs hB
    · intro v q hq
      have hx : |q.1|≤A := by
        apply abs_le.mpr
        constructor <;> dsimp [A] <;>
          linarith [neg_abs_le p.1,le_abs_self p.1,hq.1.1,hq.1.2]
      exact rowJet_norm_le_majorant N hN g j s.re s.re ‖s‖ A (p.2/2) (3*p.2/2)
        hs hs hB s ⟨le_rfl,le_rfl⟩ le_rfl q ⟨hx,hq.2.1.le,hq.2.2.le⟩ v
  exact (hc.continuousAt ((isOpen_Ioo.prod isOpen_Ioo).mem_nhds hmem)).continuousWithinAt

theorem sumGradient_continuousOn (N : ℕ) (hN : 0<N) (g : SL(2,ℤ))
    (j : FirstSlot) (s : ℂ) (hs : 1<s.re) : ContinuousOn (sumGradient N g j s) upperDomain := by
  exact (firstLift.continuous.comp_continuousOn (jetSum_continuousOn N hN g (xSlot j) s hs)).add
    (secondLift.continuous.comp_continuousOn (jetSum_continuousOn N hN g (ySlot j) s hs))

theorem jetSum_contDiffOn_one (N : ℕ) (hN : 0<N) (g : SL(2,ℤ))
    (j : FirstSlot) (s : ℂ) (hs : 1<s.re) : ContDiffOn ℝ 1 (jetSum N g (slot j) s) upperDomain := by
  apply (contDiffOn_succ_iff_hasFDerivWithinAt_of_uniqueDiffOn
    (n := 0) upperDomain_isOpen.uniqueDiffOn).2
  refine ⟨?_,sumGradient N g j s,contDiffOn_zero.mpr (sumGradient_continuousOn N hN g j s hs),?_⟩
  · intro h
    norm_num at h
  · intro p hp
    exact (jetSum_hasFDerivAt N hN g j s hs p hp).hasFDerivWithinAt

theorem native_jetSum_contDiffOn_two (N : ℕ) (hN : 0<N) (g : SL(2,ℤ))
    (s : ℂ) (hs : 1<s.re) : ContDiffOn ℝ 2 (jetSum N g .value s) upperDomain := by
  apply (contDiffOn_succ_iff_hasFDerivWithinAt_of_uniqueDiffOn
    (n := 1) upperDomain_isOpen.uniqueDiffOn).2
  refine ⟨?_,sumGradient N g .value s,?_,?_⟩
  · intro h
    norm_num at h
  · exact (firstLift.contDiff.comp_contDiffOn (jetSum_contDiffOn_one N hN g .x s hs)).add
      (secondLift.contDiff.comp_contDiffOn (jetSum_contDiffOn_one N hN g .y s hs))
  · intro p hp
    exact (jetSum_hasFDerivAt N hN g .value s hs p hp).hasFDerivWithinAt

-- C2 of the normalized native series; cuspChart_eq_actual binds it to the
-- original Gamma0 allowed rows for every positive natural level and frame.
theorem native_cuspChart_contDiffOn_two (N : ℕ) (hN : 0<N) (g : SL(2,ℤ))
    (s : ℂ) (hs : 1<s.re) : ContDiffOn ℝ 2 (cuspChart N g s) upperDomain := by
  exact (native_jetSum_contDiffOn_two N hN g s hs).const_smul (1/2:ℂ)

def partialX (f : Plane → ℂ) (p : Plane) : ℂ := deriv (fun t => f (t,p.2)) p.1
def partialY (f : Plane → ℂ) (p : Plane) : ℂ := deriv (fun t => f (p.1,t)) p.2

theorem jetSum_hasDerivAt_x (N : ℕ) (hN : 0<N) (g : SL(2,ℤ)) (j : FirstSlot)
    (s : ℂ) (hs : 1<s.re) (p : Plane) (hp : 0<p.2) :
    HasDerivAt (fun t => jetSum N g (slot j) s (t,p.2)) (jetSum N g (xSlot j) s p) p.1 := by
  have hpath : HasDerivAt (fun t : ℝ => (t,p.2)) (1,0) p.1 :=
    (hasDerivAt_id p.1).prodMk (hasDerivAt_const p.1 p.2)
  simpa [sumGradient] using (jetSum_hasFDerivAt N hN g j s hs p hp).comp_hasDerivAt p.1 hpath

theorem jetSum_hasDerivAt_y (N : ℕ) (hN : 0<N) (g : SL(2,ℤ)) (j : FirstSlot)
    (s : ℂ) (hs : 1<s.re) (p : Plane) (hp : 0<p.2) :
    HasDerivAt (fun t => jetSum N g (slot j) s (p.1,t)) (jetSum N g (ySlot j) s p) p.2 := by
  have hpath : HasDerivAt (fun t : ℝ => (p.1,t)) (0,1) p.2 :=
    (hasDerivAt_const p.2 p.1).prodMk (hasDerivAt_id p.2)
  simpa [sumGradient] using (jetSum_hasFDerivAt N hN g j s hs p hp).comp_hasDerivAt p.2 hpath

theorem cuspChart_partialX (N : ℕ) (hN : 0<N) (g : SL(2,ℤ))
    (s : ℂ) (hs : 1<s.re) (p : Plane) (hp : 0<p.2) :
    partialX (cuspChart N g s) p=(1/2:ℂ)*jetSum N g .x s p := by
  exact ((jetSum_hasDerivAt_x N hN g .value s hs p hp).const_mul (1/2:ℂ)).deriv

theorem cuspChart_partialY (N : ℕ) (hN : 0<N) (g : SL(2,ℤ))
    (s : ℂ) (hs : 1<s.re) (p : Plane) (hp : 0<p.2) :
    partialY (cuspChart N g s) p=(1/2:ℂ)*jetSum N g .y s p := by
  exact ((jetSum_hasDerivAt_y N hN g .value s hs p hp).const_mul (1/2:ℂ)).deriv

theorem cuspChart_partialXX (N : ℕ) (hN : 0<N) (g : SL(2,ℤ))
    (s : ℂ) (hs : 1<s.re) (p : Plane) (hp : 0<p.2) :
    partialX (partialX (cuspChart N g s)) p=(1/2:ℂ)*jetSum N g .xx s p := by
  have heq : (fun t => partialX (cuspChart N g s) (t,p.2))=
      (fun t => (1/2:ℂ)*jetSum N g .x s (t,p.2)) := by
    funext t
    exact cuspChart_partialX N hN g s hs (t,p.2) hp
  change deriv (fun t => partialX (cuspChart N g s) (t,p.2)) p.1 = _
  rw [heq]
  exact ((jetSum_hasDerivAt_x N hN g .x s hs p hp).const_mul (1/2:ℂ)).deriv

theorem cuspChart_partialYY (N : ℕ) (hN : 0<N) (g : SL(2,ℤ))
    (s : ℂ) (hs : 1<s.re) (p : Plane) (hp : 0<p.2) :
    partialY (partialY (cuspChart N g s)) p=(1/2:ℂ)*jetSum N g .yy s p := by
  have heq : (fun t => partialY (cuspChart N g s) (p.1,t)) =ᶠ[𝓝 p.2]
      (fun t => (1/2:ℂ)*jetSum N g .y s (p.1,t)) := by
    filter_upwards [isOpen_Ioi.mem_nhds hp] with t ht
    exact cuspChart_partialY N hN g s hs (p.1,t) ht
  exact (((jetSum_hasDerivAt_y N hN g .y s hs p hp).const_mul (1/2:ℂ)).congr_of_eventuallyEq
    heq.symm).deriv

-- No Maass equation for the sum is a hypothesis: all terms satisfy the
-- equation, the two Hessian series converge, and their derivatives are proved.
theorem native_cuspChart_maass (N : ℕ) (hN : 0<N) (g : SL(2,ℤ))
    (s : ℂ) (hs : 1<s.re) (p : Plane) (hp : 0<p.2) :
    -(p.2:ℂ)^2*(partialX (partialX (cuspChart N g s)) p+
      partialY (partialY (cuspChart N g s)) p)=s*(1-s)*cuspChart N g s p := by
  rw [cuspChart_partialXX N hN g s hs p hp,cuspChart_partialYY N hN g s hs p hp]
  have hx := rowJet_summable N hN g .xx s hs p hp
  have hy := rowJet_summable N hN g .yy s hs p hp
  have heq (v : AllowedPair N g) :
      -(p.2:ℂ)^2*(rowJet N g .xx s p v+rowJet N g .yy s p v)=
        s*(1-s)*rowJet N g .value s p v := by
    simpa only [rowJet,coordinateJet_xx,coordinateJet_yy,coordinateJet_value] using
      kernel_jet_maass (cuspWidth N g:ℝ) s (v.1.1 0:ℝ) (v.1.1 1:ℝ) p.1 p.2
        (primitive_coordinates_nonzero v.1) hp
  calc
    _ = (1/2:ℂ)*(-(p.2:ℂ)^2*(jetSum N g .xx s p+jetSum N g .yy s p)) := by ring
    _ = (1/2:ℂ)*(∑' v : AllowedPair N g,
        -(p.2:ℂ)^2*(rowJet N g .xx s p v+rowJet N g .yy s p v)) := by
      rw [tsum_mul_left,hx.tsum_add hy]
      rfl
    _ = (1/2:ℂ)*(∑' v : AllowedPair N g,s*(1-s)*rowJet N g .value s p v) := by
      congr 1
      exact tsum_congr heq
    _ = s*(1-s)*cuspChart N g s p := by rw [tsum_mul_left]; unfold cuspChart jetSum; ring

-- Exact native-family endpoint at any upper-half-plane point.
theorem native_cuspEisenstein_maass (N : ℕ) (hN : 0<N) (g : SL(2,ℤ))
    (s : ℂ) (hs : 1<s.re) (z : ℍ) :
    -(z.im:ℂ)^2*(partialX (partialX (cuspChart N g s)) (z.re,z.im)+
      partialY (partialY (cuspChart N g s)) (z.re,z.im))=s*(1-s)*cuspEisenstein N g s z := by
  rw [← cuspChart_eq_actual N hN g s z]
  exact native_cuspChart_maass N hN g s hs (z.re,z.im) z.im_pos

end
end ImbalancedChen.Part3.NativeAllCuspEisensteinC2Maass20261027
