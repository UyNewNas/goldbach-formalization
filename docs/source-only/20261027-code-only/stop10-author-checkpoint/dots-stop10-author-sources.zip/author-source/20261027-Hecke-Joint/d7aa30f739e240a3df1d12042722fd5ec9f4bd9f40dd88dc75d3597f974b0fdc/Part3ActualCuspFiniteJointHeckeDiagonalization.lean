import ImbalancedChen.Part3ActualCuspidalHeckePairCommutation
import ImbalancedChen.Part3ActualWholeHeckeSelfAdjoint
import Mathlib.Analysis.InnerProductSpace.JointEigenspace
import Mathlib.Analysis.InnerProductSpace.l2Space
import Mathlib.LinearAlgebra.Basis.Submodule

-- SOURCE_ONLY / UNCOMPILED / ZERO_FORMAL_CREDIT / READY_FALSE.
-- Symmetry of each SAME actual bounded prime Hecke operator comes from
-- the proved geometric pairing on the original quotient correspondence.
-- Commutation, native eigenspace invariance and finite dimension are derived
-- from frozen actual sources. There is no assumed spectral decomposition.
-- Pinned mathlib already supplies arbitrary-family joint eigenspaces; this
-- module applies that theorem to the actual finite native Maass fibers.

namespace ImbalancedChen.Part3.ActualCuspFiniteJointHeckeDiagonalization20261027
noncomputable section
open Set Module End
open ActualFullCuspResolvent20261026b
open ActualFullCuspGraphFiniteMultiplicity20261026b
open ActualCuspidalHeckeRestriction20261026b
open ActualCuspidalHeckePairCommutation20261027
open ActualWholeHeckeSelfAdjoint20261027

variable (N : ℕ) [NeZero N] (hN : 0 < N) (λ : ℂ)

local instance nativeFiber_finiteDimensional :
    FiniteDimensional ℂ (actualFullCuspGraphEigenspace N hN λ) :=
  actualFullCuspGraphEigenspace_finiteDimensional N hN λ

theorem goodPrimeHecke_preserves_nativeFiber (p : GoodPrime N)
    (u : ActualFullCuspL2 N hN) (hu : u ∈ actualFullCuspGraphEigenspace N hN λ) :
    goodPrimeHecke N hN p u ∈ actualFullCuspGraphEigenspace N hN λ := by
  letI : NeZero (N*p.val) := ⟨(Nat.mul_pos hN p.property.1.pos).ne'⟩
  exact actualCuspHecke_preserves_native_eigenspace N p.val hN
    p.property.1 p.property.2 λ u hu

def nativeFiberHecke (p : GoodPrime N) :
    actualFullCuspGraphEigenspace N hN λ →L[ℂ]
      actualFullCuspGraphEigenspace N hN λ :=
  (goodPrimeHecke N hN p).restrict (goodPrimeHecke_preserves_nativeFiber N hN λ p)

theorem nativeFiberHecke_coe (p : GoodPrime N)
    (u : actualFullCuspGraphEigenspace N hN λ) :
    (nativeFiberHecke N hN λ p u : ActualFullCuspL2 N hN) =
      goodPrimeHecke N hN p (u : ActualFullCuspL2 N hN) := rfl

theorem nativeFiberHecke_commute (p q : GoodPrime N) :
    Commute (nativeFiberHecke N hN λ p).toLinearMap
      (nativeFiberHecke N hN λ q).toLinearMap := by
  apply LinearMap.ext
  intro u
  apply Subtype.ext
  exact congrArg (fun T : ActualFullCuspL2 N hN →L[ℂ] ActualFullCuspL2 N hN =>
    T (u : ActualFullCuspL2 N hN)) (goodPrimeHecke_commute N hN p q).eq

theorem nativeFiberHecke_symmetric (p : GoodPrime N) :
    (nativeFiberHecke N hN λ p).toLinearMap.IsSymmetric := by
  letI : NeZero (N*p.val) := ⟨(Nat.mul_pos hN p.property.1.pos).ne'⟩
  intro u v
  exact physicalHeckeOperator_inner_symm N p.val hN p.property.1 p.property.2
    ((u : ActualFullCuspL2 N hN) : Gamma0ActualSmoothQuotientCore20261025a.QuotientL2 N)
    ((v : ActualFullCuspL2 N hN) : Gamma0ActualSmoothQuotientCore20261025a.QuotientL2 N)

def nativeJointHeckeSpace (χ : GoodPrime N → ℂ) :
    Submodule ℂ (actualFullCuspGraphEigenspace N hN λ) :=
  ⨅ p : GoodPrime N, eigenspace (nativeFiberHecke N hN λ p).toLinearMap (χ p)

theorem nativeJointHeckeSpace_orthogonal :
    OrthogonalFamily ℂ (nativeJointHeckeSpace N hN λ)
      (fun χ => (nativeJointHeckeSpace N hN λ χ).subtypeₗᵢ) :=
  LinearMap.IsSymmetric.orthogonalFamily_iInf_eigenspaces
    (nativeFiberHecke_symmetric N hN λ)

-- The index is the entire countable set of good primes at once. No
-- finite-prefix limit, stabilization, or chosen finite prime set is used.
theorem nativeJointHeckeSpace_iSup_eq_top :
    (⨆ χ : GoodPrime N → ℂ, nativeJointHeckeSpace N hN λ χ) = ⊤ := by
  apply LinearMap.IsSymmetric.iSup_iInf_eq_top_of_commute
    (nativeFiberHecke_symmetric N hN λ)
  intro p q _
  exact nativeFiberHecke_commute N hN λ p q

abbrev NativeJointHeckeIndex :=
  Σ χ : GoodPrime N → ℂ, Fin (finrank ℂ (nativeJointHeckeSpace N hN λ χ))

def nativeJointHeckeSpaceBasis (χ : GoodPrime N → ℂ) :
    OrthonormalBasis (Fin (finrank ℂ (nativeJointHeckeSpace N hN λ χ))) ℂ
      (nativeJointHeckeSpace N hN λ χ) :=
  stdOrthonormalBasis ℂ (nativeJointHeckeSpace N hN λ χ)

def nativeJointHeckeVector (i : NativeJointHeckeIndex N hN λ) :
    actualFullCuspGraphEigenspace N hN λ :=
  (nativeJointHeckeSpaceBasis N hN λ i.1 i.2 : actualFullCuspGraphEigenspace N hN λ)

theorem nativeJointHeckeVector_orthonormal :
    Orthonormal ℂ (nativeJointHeckeVector N hN λ) :=
  (nativeJointHeckeSpace_orthogonal N hN λ).orthonormal_sigma_orthonormal
    (fun χ => (nativeJointHeckeSpaceBasis N hN λ χ).orthonormal)

theorem nativeJointHeckeVector_span_eq_top :
    Submodule.span ℂ (range (nativeJointHeckeVector N hN λ)) = ⊤ := by
  rw [← nativeJointHeckeSpace_iSup_eq_top N hN λ]
  apply le_antisymm
  · apply Submodule.span_le.mpr
    rintro v ⟨⟨χ,j⟩, rfl⟩
    exact (le_iSup (nativeJointHeckeSpace N hN λ) χ)
      (nativeJointHeckeSpaceBasis N hN λ χ j).property
  · apply iSup_le
    intro χ u hu
    obtain ⟨c,hc⟩ := (nativeJointHeckeSpaceBasis N hN λ χ).toBasis.mem_submodule_iff'.mp hu
    rw [hc]
    apply Submodule.sum_mem
    intro j _
    apply Submodule.smul_mem
    exact Submodule.subset_span ⟨⟨χ,j⟩,rfl⟩

theorem nativeJointHeckeVector_dense_span :
    ⊤ ≤ (Submodule.span ℂ (range (nativeJointHeckeVector N hN λ))).topologicalClosure := by
  rw [nativeJointHeckeVector_span_eq_top N hN λ]
  exact Submodule.le_topologicalClosure ⊤

def nativeJointHeckeHilbertBasis :
    HilbertBasis (NativeJointHeckeIndex N hN λ) ℂ
      (actualFullCuspGraphEigenspace N hN λ) :=
  HilbertBasis.mk (nativeJointHeckeVector_orthonormal N hN λ)
    (nativeJointHeckeVector_dense_span N hN λ)

theorem nativeJointHeckeHilbertBasis_apply (i : NativeJointHeckeIndex N hN λ) :
    nativeJointHeckeHilbertBasis N hN λ i = nativeJointHeckeVector N hN λ i :=
  congrFun (HilbertBasis.coe_mk (nativeJointHeckeVector_orthonormal N hN λ)
    (nativeJointHeckeVector_dense_span N hN λ)) i

theorem nativeJointHeckeVector_eigen (p : GoodPrime N)
    (i : NativeJointHeckeIndex N hN λ) :
    nativeFiberHecke N hN λ p (nativeJointHeckeVector N hN λ i) =
      i.1 p • nativeJointHeckeVector N hN λ i := by
  apply mem_eigenspace_iff.mp
  exact (Submodule.mem_iInf.mp
    (nativeJointHeckeSpaceBasis N hN λ i.1 i.2).property) p

-- Actual full-cusp operator action, retaining the native Maass fiber.
theorem nativeJointHeckeVector_actual_eigen (p : GoodPrime N)
    (i : NativeJointHeckeIndex N hN λ) :
    goodPrimeHecke N hN p
        (nativeJointHeckeVector N hN λ i : ActualFullCuspL2 N hN) =
      i.1 p • (nativeJointHeckeVector N hN λ i : ActualFullCuspL2 N hN) :=
  congrArg (fun u : actualFullCuspGraphEigenspace N hN λ =>
    (u : ActualFullCuspL2 N hN)) (nativeJointHeckeVector_eigen N hN λ p i)

theorem nativeJointHeckeHilbertBasis_actual_eigen (p : GoodPrime N)
    (i : NativeJointHeckeIndex N hN λ) :
    goodPrimeHecke N hN p
        (nativeJointHeckeHilbertBasis N hN λ i : ActualFullCuspL2 N hN) =
      i.1 p • (nativeJointHeckeHilbertBasis N hN λ i : ActualFullCuspL2 N hN) := by
  rw [nativeJointHeckeHilbertBasis_apply]
  exact nativeJointHeckeVector_actual_eigen N hN λ p i

theorem nativeJointHeckeHilbertBasis_original_graph
    (i : NativeJointHeckeIndex N hN λ) :
    (((nativeJointHeckeHilbertBasis N hN λ i : ActualFullCuspL2 N hN) :
        Gamma0ActualSmoothQuotientCore20261025a.QuotientL2 N),
      λ • ((nativeJointHeckeHilbertBasis N hN λ i : ActualFullCuspL2 N hN) :
        Gamma0ActualSmoothQuotientCore20261025a.QuotientL2 N)) ∈
      (Gamma0ActualFriedrichsOperator20261025a.actualGammaFriedrichs N).graph :=
  (mem_actualFullCuspGraphEigenspace_iff_original N hN λ _).mp
    (nativeJointHeckeHilbertBasis N hN λ i).property

end
end ImbalancedChen.Part3.ActualCuspFiniteJointHeckeDiagonalization20261027
