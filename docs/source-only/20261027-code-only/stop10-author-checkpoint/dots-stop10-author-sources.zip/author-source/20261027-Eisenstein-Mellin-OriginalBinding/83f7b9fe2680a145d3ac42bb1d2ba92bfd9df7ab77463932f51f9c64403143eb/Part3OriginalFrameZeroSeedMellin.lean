import ImbalancedChen.Part3NativeCuspCompactMellinSynthesis
import ImbalancedChen.Part3NativeOriginalSharpZeroSeedPartition
import ImbalancedChen.Part3AllNormalizedCuspAnnihilator

-- SOURCE ONLY / UNCOMPILED / ZERO FORMAL CREDIT.
-- This is the original SHARP half-open unit-strip seed, transported by the
-- actual normalized cusp frame and periodized through effectiveGamma0.
-- The signed-row half factor and actual width are supplied by the exact
-- original strip partition theorem. No smooth horizontal replacement is used.
namespace ImbalancedChen.Part3.OriginalFrameZeroSeedMellin20261027
noncomputable section
open Set MeasureTheory Matrix
open scoped MatrixGroups UpperHalfPlane
open SmoothZeroHeightSeedProfiles20261026b
open CompactHeightMellinInversion20261027 NativeCuspCompactMellinSynthesis20261027
open NativeAllCuspEisenstein20261026b NativeOriginalSharpZeroSeedPartition20261027
open NormalizedCuspCompactPoincare20261026b AllNormalizedCuspAnnihilator20261026b
open Gamma0ComplexL1PoincareUnfolding20261025a
open Gamma0QuotientCellPushforward20261025a Gamma0CarrierAESection20261025a
open Gamma0QuotientConullTransport20261025a

theorem original_frame_zero_trace_mellin (N : ℕ) (hN : 0 < N) (g : SL(2, ℤ))
    (s : SmoothHeightSeed) (σ : ℝ) (hσ : 1 < σ) (z : UpperHalfPlane) :
    complexSeedTrace N (physicalFrameSeed N hN g 0 s.toFun) z =
      (2 * Real.pi)⁻¹ • ∫ t : ℝ,
        mellinAngular s σ t * cuspEisenstein N g (verticalParameter σ t) z := by
  rw [original_sharp_zero_trace_eq_half_allowed_rows N hN g s.toFun
    s.continuous s.compact s.positive]
  exact compactRowSeries_mellin N hN g z s σ hσ

theorem original_frame_zero_Poincare_mellin_projection (N : ℕ) [NeZero N]
    (hN : 0 < N) (g : SL(2, ℤ)) (s : SmoothHeightSeed)
    (σ : ℝ) (hσ : 1 < σ) (z : reducedCarrier N) :
    complexPoincare N (physicalFrameSeed N hN g 0 s.toFun) (reducedProjection N z) =
      (2 * Real.pi)⁻¹ • ∫ t : ℝ,
        mellinAngular s σ t * cuspEisenstein N g (verticalParameter σ t) z := by
  rw [original_sharp_zero_Poincare_projection N hN g s.toFun
    s.continuous s.compact s.positive]
  exact compactRowSeries_mellin N hN g z s σ hσ

-- The genuine original quotient L2 vector is the MemLp.toLp of precisely the
-- function whose projected values were computed above. The AE representative
-- equality is the native toLp equality, with no new L2 or representation premise.
theorem original_frameZeroSeedL2_ae_representative (N : ℕ) [NeZero N]
    (hN : 0 < N) (g : SL(2, ℤ)) (s : SmoothHeightSeed) :
    (fun q => (frameZeroSeedL2 N hN g s.toHeightSeed) q) =ᵐ[carrierPushforward N]
      complexPoincare N (physicalFrameSeed N hN g 0 s.toFun) := by
  unfold frameZeroSeedL2 framePoincareL2
  exact (framePoincare_memLp_two N hN g 0 s.toFun
    s.continuous s.compact s.positive).coeFn_toLp

theorem original_frameZeroSeedL2_mellin_representative (N : ℕ) [NeZero N]
    (hN : 0 < N) (g : SL(2, ℤ)) (s : SmoothHeightSeed)
    (σ : ℝ) (hσ : 1 < σ) :
    ((fun q => (frameZeroSeedL2 N hN g s.toHeightSeed) q) =ᵐ[carrierPushforward N]
      complexPoincare N (physicalFrameSeed N hN g 0 s.toFun)) ∧
    (∀ z : reducedCarrier N,
      complexPoincare N (physicalFrameSeed N hN g 0 s.toFun) (reducedProjection N z) =
        (2 * Real.pi)⁻¹ • ∫ t : ℝ,
          mellinAngular s σ t * cuspEisenstein N g (verticalParameter σ t) z) :=
  ⟨original_frameZeroSeedL2_ae_representative N hN g s,
    original_frame_zero_Poincare_mellin_projection N hN g s σ hσ⟩

end
end ImbalancedChen.Part3.OriginalFrameZeroSeedMellin20261027
