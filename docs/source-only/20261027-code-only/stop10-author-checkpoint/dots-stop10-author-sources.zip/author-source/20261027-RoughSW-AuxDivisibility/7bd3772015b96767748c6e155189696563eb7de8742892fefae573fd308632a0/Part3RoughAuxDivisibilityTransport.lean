import ImbalancedChen.Part3RoughAuxiliarySW
import Mathlib.Data.Nat.ModEq

-- SOURCE ONLY / UNCOMPILED_ZERO_CREDIT.
-- The Brun expansion in distribution-prime-product-completion-20261010.txt,
-- section 5, changes a rough slot into signed divisibility branches n=d*m.
-- This module transports those branches on ONE physical carrier, including
-- their literal coefficient mean. It proves no Siegel--Walfisz estimate.
-- The auxiliary k deletion estimate already exists in Part3RoughAuxiliarySW.

namespace ImbalancedChen.Part3.RoughAuxDivisibility20261027

noncomputable section
open Classical Finset
open scoped BigOperators

-- A finite branch pushed from quotient m to the physical integer d*m.
-- The definition remains meaningful at d=0; analytic callers use d>0.
def divisorLift (S : Finset ℕ) (d : ℕ) (α : ℕ → ℂ) (n : ℕ) : ℂ :=
  ∑ m ∈ S, if d*m=n then α m else 0

-- Actual divisibility support is proved, rather than inserted as a premise.
theorem divisorLift_eq_zero_of_not_dvd (S : Finset ℕ) (d n : ℕ)
    (α : ℕ → ℂ) (hn : ¬d∣n) : divisorLift S d α n=0 := by
  apply Finset.sum_eq_zero
  intro m hm
  apply if_neg
  intro h
  exact hn ⟨m,h.symm⟩

-- For positive d this is literally the original quotient coefficient,
-- with no multiplicity from the pushforward and no loss of its sign.
theorem divisorLift_apply_mul (S : Finset ℕ) (d m : ℕ) (hd : 0<d)
    (α : ℕ → ℂ) :
    divisorLift S d α (d*m)=if m∈S then α m else 0 := by
  unfold divisorLift
  by_cases hm : m∈S
  · rw [Finset.sum_eq_single m]
    · simp only [hm,if_true]
    · intro a ha hne
      apply if_neg
      intro h
      exact hne (Nat.eq_of_mul_eq_mul_left hd h)
    · intro hnot
      exact (hnot hm).elim
  · rw [if_neg hm]
    apply Finset.sum_eq_zero
    intro a ha
    apply if_neg
    intro h
    have ham : a=m := Nat.eq_of_mul_eq_mul_left hd h
    exact hm (ham ▸ ha)

-- Exact pushforward for any test. T is the common physical carrier.
theorem divisorLift_test (S T : Finset ℕ) (d : ℕ) (α F : ℕ → ℂ)
    (hT : ∀ m∈S, d*m∈T) :
    (∑ n∈T, divisorLift S d α n * F n)=∑ m∈S, α m * F (d*m) := by
  unfold divisorLift
  simp_rw [Finset.sum_mul]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro m hm
  rw [Finset.sum_eq_single (d*m)]
  · simp
  · intro n hn hne
    simp only [Ne.symm hne,if_false,zero_mul]
  · intro hnot
    exact (hnot (hT m hm)).elim

-- Writing the discrepancy as a linear test keeps its coprime source mean
-- visible. The denominator is always the original phi(q).
def auxiliaryKernel (k q b n : ℕ) : ℂ :=
  (if Nat.ModEq q n b ∧ n.Coprime k then 1 else 0) -
    (if n.Coprime (k*q) then 1 else 0)/(q.totient:ℂ)

theorem auxiliarySWError_eq_kernel (S : Finset ℕ) (α : ℕ → ℂ) (k q b : ℕ) :
    auxiliarySWError S α k q b=∑ n∈S, α n * auxiliaryKernel k q b n := by
  unfold auxiliarySWError auxiliaryKernel
  simp_rw [mul_sub]
  rw [Finset.sum_sub_distrib]
  congr 1
  · apply Finset.sum_congr rfl
    intro n hn
    split_ifs <;> simp
  · rw [Finset.sum_div]
    apply Finset.sum_congr rfl
    intro n hn
    split_ifs <;> simp [div_eq_mul_inv]

-- r is the quotient residue. No arbitrary residue mean replaces the
-- physical mean: d being coprime to k*q makes the two tests identical.
theorem auxiliaryKernel_dilate (d k q b r m : ℕ)
    (hdkq : d.Coprime (k*q)) (hr : Nat.ModEq q (d*r) b) :
    auxiliaryKernel k q b (d*m)=auxiliaryKernel k q r m := by
  have hdk : d.Coprime k := (Nat.coprime_mul_iff_right.mp hdkq).1
  have hdq : d.Coprime q := (Nat.coprime_mul_iff_right.mp hdkq).2
  have hmod : Nat.ModEq q (d*m) b ↔ Nat.ModEq q m r := by
    constructor
    · intro h
      exact Nat.ModEq.cancel_left_of_coprime hdq.symm (h.trans hr.symm)
    · intro h
      exact (h.mul_left d).trans hr
  simp only [auxiliaryKernel,hmod,Nat.coprime_mul_iff_left,hdk,hdkq,true_and]

-- The residue given to a local supplier is again primitive; the caller
-- does not need to add an independent arithmetic admissibility premise.
theorem quotientResidue_coprime (d q b r : ℕ) (hb : b.Coprime q)
    (hr : Nat.ModEq q (d*r) b) : r.Coprime q := by
  have hprod : (d*r).Coprime q := by
    change Nat.gcd (d*r) q=1
    rw [hr.gcd_eq]
    exact hb
  exact (Nat.coprime_mul_iff_left.mp hprod).2

-- Every discarded divisor branch vanishes in BOTH terms, for every k.
-- This uses the physical residue being primitive modulo q.
theorem auxiliaryKernel_dilate_vanish (d k q b m : ℕ)
    (hb : b.Coprime q) (hd : ¬d.Coprime (k*q)) :
    auxiliaryKernel k q b (d*m)=0 := by
  have hmean : ¬(d*m).Coprime (k*q) := by
    intro h
    exact hd (Nat.coprime_mul_iff_left.mp h).1
  have hAP : ¬(Nat.ModEq q (d*m) b ∧ (d*m).Coprime k) := by
    rintro ⟨hmod,hk⟩
    have hq : (d*m).Coprime q := by
      change Nat.gcd (d*m) q=1
      rw [hmod.gcd_eq]
      exact hb
    exact hmean (hk.mul_right hq)
  simp only [auxiliaryKernel,if_neg hAP,if_neg hmean,zero_div,sub_zero]

-- One actual divisibility branch with its transported residue and mean.
theorem auxiliarySWError_divisorLift (S T : Finset ℕ) (d k q b r : ℕ)
    (α : ℕ → ℂ) (hT : ∀ m∈S,d*m∈T)
    (hdkq : d.Coprime (k*q)) (hr : Nat.ModEq q (d*r) b) :
    auxiliarySWError T (divisorLift S d α) k q b=
      auxiliarySWError S α k q r := by
  rw [auxiliarySWError_eq_kernel,divisorLift_test S T d α _ hT,
    auxiliarySWError_eq_kernel]
  apply Finset.sum_congr rfl
  intro m hm
  rw [auxiliaryKernel_dilate d k q b r m hdkq hr]

-- A fixed Brun polynomial, or any finite signed divisor expansion, is
-- represented by its actual coefficient sum on the physical n variable.
-- Different branches may have different quotient carriers and coefficients.
def divisorFamilyCoefficient (D : Finset ℕ) (S : ℕ → Finset ℕ)
    (c : ℕ → ℂ) (α : ℕ → ℕ → ℂ) (n : ℕ) : ℂ :=
  ∑ d∈D,c d * divisorLift (S d) d (α d) n

-- Exact signed action, including every noncoprime divisor branch.
-- The residue transport is required only on surviving branches.
-- c remains signed: cancellation occurs before any norm is taken.
theorem auxiliarySWError_divisorFamily (D T : Finset ℕ)
    (S : ℕ → Finset ℕ) (c : ℕ → ℂ) (α : ℕ → ℕ → ℂ)
    (k q b : ℕ) (r : ℕ → ℕ) (hb : b.Coprime q)
    (hT : ∀ d∈D,∀ m∈S d,d*m∈T)
    (hres : ∀ d∈D,d.Coprime (k*q) → Nat.ModEq q (d*r d) b) :
    auxiliarySWError T (divisorFamilyCoefficient D S c α) k q b=
      ∑ d∈D,if d.Coprime (k*q) then
        c d * auxiliarySWError (S d) (α d) k q (r d) else 0 := by
  rw [auxiliarySWError_eq_kernel]
  unfold divisorFamilyCoefficient
  simp_rw [Finset.sum_mul]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro d hd
  simp_rw [mul_assoc]
  rw [← Finset.mul_sum,divisorLift_test (S d) T d (α d) _ (hT d hd)]
  by_cases hc : d.Coprime (k*q)
  · rw [if_pos hc,auxiliarySWError_eq_kernel]
    congr 1
    apply Finset.sum_congr rfl
    intro m hm
    rw [auxiliaryKernel_dilate d k q b (r d) m hc (hres d hd hc)]
  · rw [if_neg hc]
    have hz : (∑ m∈S d,α d m * auxiliaryKernel k q b (d*m))=0 := by
      apply Finset.sum_eq_zero
      intro m hm
      rw [auxiliaryKernel_dilate_vanish d k q b m hb hc,mul_zero]
    rw [hz,mul_zero]

-- A genuine estimate with each local error still explicit. There is no
-- hypothesis here assuming a logarithmic bound or a final SW target.
-- The surviving branch carrier retains its scaled physical interval,
-- its actual coefficient (including mu sign), and the original phi(q).
theorem auxiliarySWError_divisorFamily_norm_le (D T : Finset ℕ)
    (S : ℕ → Finset ℕ) (c : ℕ → ℂ) (α : ℕ → ℕ → ℂ)
    (k q b : ℕ) (r : ℕ → ℕ) (hb : b.Coprime q)
    (hT : ∀ d∈D,∀ m∈S d,d*m∈T)
    (hres : ∀ d∈D,d.Coprime (k*q) → Nat.ModEq q (d*r d) b) :
    ‖auxiliarySWError T (divisorFamilyCoefficient D S c α) k q b‖≤
      ∑ d∈D,if d.Coprime (k*q) then
        ‖c d‖ * ‖auxiliarySWError (S d) (α d) k q (r d)‖ else 0 := by
  rw [auxiliarySWError_divisorFamily D T S c α k q b r hb hT hres]
  apply (norm_sum_le _ _).trans_eq
  apply Finset.sum_congr rfl
  intro d hd
  split_ifs <;> simp only [norm_mul,norm_zero]

end
end ImbalancedChen.Part3.RoughAuxDivisibility20261027

