import ImbalancedChen.Part3CompactHeightMellinInversion
import ImbalancedChen.Part3NativeAllCuspEisenstein
import Mathlib.MeasureTheory.Integral.DominatedConvergence

-- SOURCE ONLY / UNCOMPILED / ZERO FORMAL CREDIT.
-- Genuine Mellin synthesis of the ORIGINAL allowed-row series. The half factor
-- retains both signs. Every scalar row integral is L1, and the sum of the
-- integrals of its norm is summable before the sum-integral interchange.
namespace ImbalancedChen.Part3.NativeCuspCompactMellinSynthesis20261027
noncomputable section
open Set MeasureTheory Complex Matrix
open scoped FourierTransform SchwartzMap MatrixGroups UpperHalfPlane
open SmoothZeroHeightSeedProfiles20261026b CompactHeightMellinInversion20261027
open NativeAllCuspEisenstein20261026b

def verticalParameter (σ t : ℝ) : ℂ := (σ : ℂ) + (t : ℂ) * Complex.I

@[simp] theorem verticalParameter_re (σ t : ℝ) : (verticalParameter σ t).re = σ := by
  simp [verticalParameter]

theorem normalizedSeed_vertical_norm (N : ℕ) (hN : 0 < N) (g : SL(2, ℤ))
    (z : UpperHalfPlane) (v : PrimitiveEisensteinParameterAnalytic.PrimitivePair) (σ t : ℝ) :
    ‖normalizedSeed N g z v (verticalParameter σ t)‖ =
      ‖normalizedSeed N g z v (σ : ℂ)‖ := by
  simp only [norm_normalizedSeed N hN, verticalParameter_re, Complex.ofReal_re]

def rowIntegrand (N : ℕ) (g : SL(2, ℤ)) (z : UpperHalfPlane)
    (s : SmoothHeightSeed) (σ : ℝ) (v : AllowedPair N g) (ξ : ℝ) : ℂ :=
  mellinFrequency s σ ξ * normalizedSeed N g z v.1 (verticalParameter σ (2 * Real.pi * ξ))

theorem rowIntegrand_norm (N : ℕ) (hN : 0 < N) (g : SL(2, ℤ))
    (z : UpperHalfPlane) (s : SmoothHeightSeed) (σ : ℝ) (v : AllowedPair N g) (ξ : ℝ) :
    ‖rowIntegrand N g z s σ v ξ‖ =
      ‖mellinFrequency s σ ξ‖ * ‖normalizedSeed N g z v.1 (σ : ℂ)‖ := by
  rw [rowIntegrand, norm_mul, normalizedSeed_vertical_norm N hN]

theorem rowIntegrand_continuous (N : ℕ) (g : SL(2, ℤ)) (z : UpperHalfPlane)
    (s : SmoothHeightSeed) (σ : ℝ) (v : AllowedPair N g) :
    Continuous (rowIntegrand N g z s σ v) := by
  apply (mellinFrequency_continuous s σ).mul
  unfold normalizedSeed verticalParameter
  fun_prop

theorem rowIntegrand_integrable (N : ℕ) (hN : 0 < N) (g : SL(2, ℤ))
    (z : UpperHalfPlane) (s : SmoothHeightSeed) (σ : ℝ) (v : AllowedPair N g) :
    Integrable (rowIntegrand N g z s σ v) := by
  apply ((mellinFrequency_integrable s σ).norm.mul_const
    ‖normalizedSeed N g z v.1 (σ : ℂ)‖).mono'
    (rowIntegrand_continuous N g z s σ v).aestronglyMeasurable
  exact Filter.Eventually.of_forall (fun ξ => (rowIntegrand_norm N hN g z s σ v ξ).le)

theorem rowIntegrand_integral_norm_summable (N : ℕ) (hN : 0 < N) (g : SL(2, ℤ))
    (z : UpperHalfPlane) (s : SmoothHeightSeed) (σ : ℝ) (hσ : 1 < σ) :
    Summable (fun v : AllowedPair N g => ∫ ξ : ℝ, ‖rowIntegrand N g z s σ v ξ‖) := by
  have hn := normalizedSeed_norm_summable N hN g z (σ : ℂ) (by simpa using hσ)
  have heq (v : AllowedPair N g) : (∫ ξ : ℝ, ‖rowIntegrand N g z s σ v ξ‖) =
      (∫ ξ : ℝ, ‖mellinFrequency s σ ξ‖) * ‖normalizedSeed N g z v.1 (σ : ℂ)‖ := by
    simp only [rowIntegrand_norm N hN, integral_mul_const]
  simpa only [heq] using hn.mul_left (∫ ξ : ℝ, ‖mellinFrequency s σ ξ‖)

theorem row_mellin_inversion (N : ℕ) (hN : 0 < N) (g : SL(2, ℤ))
    (z : UpperHalfPlane) (s : SmoothHeightSeed) (σ : ℝ) (v : AllowedPair N g) :
    s.toFun (normalizedBase N g z v.1) = ∫ ξ : ℝ, rowIntegrand N g z s σ v ξ := by
  rw [compact_height_mellin_inversion_frequency s σ (normalizedBase_pos N hN g z v.1),
    ← integral_const_mul]
  apply integral_congr_ae
  filter_upwards [] with ξ
  unfold rowIntegrand normalizedSeed verticalParameter
  rw [← mul_assoc, ← Complex.exp_add]
  calc
    _ = Complex.exp (((σ : ℂ) + (2 * Real.pi * ξ : ℝ) * Complex.I) *
        (Real.log (normalizedBase N g z v.1) : ℂ)) * mellinFrequency s σ ξ := by
      congr 2
      push_cast
      ring
    _ = _ := mul_comm _ _

def compactRowSeries (N : ℕ) (g : SL(2, ℤ)) (s : SmoothHeightSeed)
    (z : UpperHalfPlane) : ℂ :=
  (1 / 2 : ℂ) * ∑' v : AllowedPair N g, s.toFun (normalizedBase N g z v.1)

theorem compactRowSeries_mellin_frequency (N : ℕ) (hN : 0 < N) (g : SL(2, ℤ))
    (z : UpperHalfPlane) (s : SmoothHeightSeed) (σ : ℝ) (hσ : 1 < σ) :
    compactRowSeries N g s z = ∫ ξ : ℝ, mellinFrequency s σ ξ *
      cuspEisenstein N g (verticalParameter σ (2 * Real.pi * ξ)) z := by
  unfold compactRowSeries
  simp_rw [row_mellin_inversion N hN g z s σ]
  rw [integral_tsum_of_summable_integral_norm
    (rowIntegrand_integrable N hN g z s σ)
    (rowIntegrand_integral_norm_summable N hN g z s σ hσ), ← integral_const_mul]
  apply integral_congr_ae
  filter_upwards [] with ξ
  simp only [rowIntegrand, cuspEisenstein, tsum_mul_left]
  ring

-- Angular normalization uses dt/(2*pi), with the actual Fourier supplier.
theorem compactRowSeries_mellin (N : ℕ) (hN : 0 < N) (g : SL(2, ℤ))
    (z : UpperHalfPlane) (s : SmoothHeightSeed) (σ : ℝ) (hσ : 1 < σ) :
    compactRowSeries N g s z = (2 * Real.pi)⁻¹ • ∫ t : ℝ,
      mellinAngular s σ t * cuspEisenstein N g (verticalParameter σ t) z := by
  rw [compactRowSeries_mellin_frequency N hN g z s σ hσ]
  have h := Measure.integral_comp_mul_left (fun t : ℝ => mellinAngular s σ t *
    cuspEisenstein N g (verticalParameter σ t) z) (2 * Real.pi)
  have hp : 0 < 2 * Real.pi := mul_pos (by norm_num) Real.pi_pos
  simpa only [mellinAngular, inv_mul_cancel_left₀ hp.ne',
    abs_of_pos (inv_pos.mpr hp)] using h

end
end ImbalancedChen.Part3.NativeCuspCompactMellinSynthesis20261027
