import ImbalancedChen.P5U7SpatialFullSemiprimeCDFMean
import ImbalancedChen.LogPrimeBoxMesh

-- SOURCE_ONLY / UNCOMPILED_ZERO_CREDIT.
-- The arithmetic input below is the already proved ACTUAL ordered-source CDF,
-- never a hypothetical CDF supplier. All target-N masks and repeated terminal
-- prime labels remain inside p5U7ActualSemiprimeProductWeight N m.
-- Cutoffs are STRICT natural ranges. In particular the terminal prefix N is
-- retained in the Stieltjes formula; there is no endpoint-null assertion.
namespace ImbalancedChen
noncomputable section
open Set Filter Topology
open scoped BigOperators
open Classical

def p5U7OrderedSemiprimeCDF (N : ℕ) (x : ℝ) : ℝ :=
  (Real.log (N : ℝ)/(N : ℝ))*
    ∑ m ∈ Finset.range (Nat.floor (x*(N : ℝ))),
      p5U7ActualSemiprimeProductWeight N m

theorem p5U7OrderedSemiprimeCDF_mono (N : ℕ) :
    Monotone (p5U7OrderedSemiprimeCDF N) := by
  intro x y hxy
  unfold p5U7OrderedSemiprimeCDF
  apply mul_le_mul_of_nonneg_left
  · apply Finset.sum_le_sum_of_subset_of_nonneg
      (Finset.range_mono (Nat.floor_mono
        (mul_le_mul_of_nonneg_right hxy (Nat.cast_nonneg N))))
    intro m _ _
    exact p5U7ActualSemiprimeProductWeight_nonneg N m
  · exact div_nonneg (Real.log_natCast_nonneg N) (Nat.cast_nonneg N)

-- Flooring changes only the independent product cutoff. The prime exclusions,
-- outer marked pair, 59/250 wall, and ordered terminal carrier still use N.
theorem tendsto_p5U7OrderedSemiprimeCDF (x : ℝ) (hx : x ∈ Icc (0 : ℝ) 1) :
    Tendsto (fun N => p5U7OrderedSemiprimeCDF N x) atTop
      (𝓝 (x*p5U7ComponentSemiprimeIntegral)) := by
  by_cases hx0 : x=0
  · subst x
    simpa [p5U7OrderedSemiprimeCDF] using
      (tendsto_const_nhds (x := (0 : ℝ)))
  have hxpos : 0<x := lt_of_le_of_ne hx.1 (Ne.symm hx0)
  have hMN : ∀ N : ℕ, Nat.floor (x*(N : ℝ)) ≤ N := by
    intro N
    have h := Nat.floor_mono
      (mul_le_mul_of_nonneg_right hx.2 (Nat.cast_nonneg N))
    simpa only [one_mul,Nat.floor_natCast] using h
  have hratio : Tendsto
      (fun N : ℕ => (Nat.floor (x*(N : ℝ)) : ℝ)/(N : ℝ)) atTop (𝓝 x) :=
    (tendsto_nat_floor_mul_div_atTop hx.1).comp
      (tendsto_natCast_atTop_atTop (R := ℝ))
  exact tendsto_p5U7SpatialSemiprimeCDF_normalized _ x hxpos
    (Eventually.of_forall hMN) hratio

theorem p5U7ComponentSemiprimeIntegral_nonneg :
    0 ≤ p5U7ComponentSemiprimeIntegral := by
  have h := tendsto_p5U7OrderedSemiprimeCDF 1 (by norm_num)
  simp only [one_mul] at h
  apply le_of_tendsto h
  apply Eventually.of_forall
  intro N
  exact mul_nonneg
    (div_nonneg (Real.log_natCast_nonneg N) (Nat.cast_nonneg N))
    (Finset.sum_nonneg (fun m _ => p5U7ActualSemiprimeProductWeight_nonneg N m))

-- Finite monotone interpolation supplies the uniformity. The mesh is fixed
-- before N; no rate for PNT, eta collars, or the scalar CDF is assumed.
theorem p5U7OrderedSemiprimeCDF_eventually_uniform (epsilon : ℝ) (he : 0<epsilon) :
    ∀ᶠ N : ℕ in atTop, ∀ x ∈ Icc (0 : ℝ) 1,
      |p5U7OrderedSemiprimeCDF N x-x*p5U7ComponentSemiprimeIntegral|<epsilon := by
  let C := p5U7ComponentSemiprimeIntegral
  have hC : 0≤C := p5U7ComponentSemiprimeIntegral_nonneg
  have he3 : 0<epsilon/3 := by positivity
  have hs := Metric.tendsto_nhds.mp
    ((tendsto_logPrimeMeshStep 0 1).const_mul C) (epsilon/3) he3
  obtain ⟨n,hn⟩ := hs.exists
  have hstep : C*logPrimeMeshStep 0 1 n < epsilon/3 := by
    have hn' : |C*logPrimeMeshStep 0 1 n|<epsilon/3 := by
      simpa only [mul_zero,Real.dist_eq,sub_zero] using hn
    exact (le_abs_self _).trans_lt hn'
  have hpoint : ∀ i : Fin (n+2), logPrimeMeshPoint 0 1 n i.val ∈ Icc (0 : ℝ) 1 := by
    intro i
    constructor
    · simpa using logPrimeMeshPoint_mono (a := (0 : ℝ)) (b := 1) (by norm_num) n
        (Nat.zero_le i.val)
    · have hi : i.val≤n+1 := by omega
      simpa using logPrimeMeshPoint_mono (a := (0 : ℝ)) (b := 1) (by norm_num) n hi
  have hgrid : ∀ᶠ N : ℕ in atTop, ∀ i : Fin (n+2),
      |p5U7OrderedSemiprimeCDF N (logPrimeMeshPoint 0 1 n i.val)-
        logPrimeMeshPoint 0 1 n i.val*C|<epsilon/3 := by
    apply eventually_all.mpr
    intro i
    have h := Metric.tendsto_nhds.mp
      (tendsto_p5U7OrderedSemiprimeCDF _ (hpoint i)) (epsilon/3) he3
    simpa only [Real.dist_eq] using h
  filter_upwards [hgrid] with N hN
  intro x hx
  by_cases hx1 : x=1
  · subst x
    have h := hN ⟨n+1,by omega⟩
    simp only [logPrimeMeshPoint_last] at h
    exact h.trans (by linarith)
  have hxlt : x<1 := lt_of_le_of_ne hx.2 hx1
  obtain ⟨i,hi⟩ := exists_logPrimeMeshInterval 0 1 n ⟨hx.1,hxlt⟩
  have hlo := abs_lt.mp (hN ⟨i.val,by omega⟩)
  have hhi := abs_lt.mp (hN ⟨i.val+1,by omega⟩)
  have hFLo := p5U7OrderedSemiprimeCDF_mono N hi.1
  have hFHi := p5U7OrderedSemiprimeCDF_mono N hi.2.le
  have hCLo := mul_le_mul_of_nonneg_right hi.1 hC
  have hCHi := mul_le_mul_of_nonneg_right hi.2.le hC
  have hsucc := logPrimeMeshPoint_succ 0 1 n i.val
  have hsuccC := congrArg (fun y : ℝ => y*C) hsucc
  dsimp only at hsuccC
  apply abs_lt.mpr
  constructor <;> nlinarith

theorem tendstoUniformlyOn_p5U7OrderedSemiprimeCDF :
    TendstoUniformlyOn p5U7OrderedSemiprimeCDF
      (fun x => x*p5U7ComponentSemiprimeIntegral) atTop (Icc (0 : ℝ) 1) := by
  apply Metric.tendstoUniformlyOn_iff.mpr
  intro epsilon he
  filter_upwards [p5U7OrderedSemiprimeCDF_eventually_uniform epsilon he] with N hN
  intro x hx
  simpa only [Real.dist_eq,abs_sub_comm] using hN x hx

-- Discrete Stieltjes integration by parts on [0,n). The test value H n is
-- an extension at the right endpoint. Its contribution cancels exactly with
-- the final difference; no requirement H n=0 is made.
private theorem ordered_stieltjes_identity (a H : ℕ → ℝ) (n : ℕ) :
    (∑ m ∈ Finset.range n,a m*H m) =
      (∑ m ∈ Finset.range n,a m)*H n+
        ∑ k ∈ Finset.range n,
          (∑ m ∈ Finset.range (k+1),a m)*(H k-H (k+1)) := by
  induction n with
  | zero => simp
  | succ n ih =>
    have hprefix : (∑ m ∈ Finset.range (n+1),a m) =
        (∑ m ∈ Finset.range n,a m)+a n := Finset.sum_range_succ a n
    calc
      _ = (∑ m ∈ Finset.range n,a m*H m)+a n*H n :=
        Finset.sum_range_succ _ _
      _ = ((∑ m ∈ Finset.range n,a m)*H n+
          ∑ k ∈ Finset.range n,
            (∑ m ∈ Finset.range (k+1),a m)*(H k-H (k+1)))+a n*H n := by rw [ih]
      _ = (∑ m ∈ Finset.range (n+1),a m)*H (n+1)+
          ((∑ k ∈ Finset.range n,
            (∑ m ∈ Finset.range (k+1),a m)*(H k-H (k+1)))+
            (∑ m ∈ Finset.range (n+1),a m)*(H n-H (n+1))) := by
          simp only [hprefix]
          ring
      _ = _ := by rw [Finset.sum_range_succ]

private theorem ordered_stieltjes_bound (a H : ℕ → ℝ) (n : ℕ) (delta : ℝ)
    (hdelta : 0≤delta)
    (hA : ∀ k≤n, |∑ m ∈ Finset.range k,a m|≤delta) :
    |∑ m ∈ Finset.range n,a m*H m|≤
      delta*(|H n|+∑ k ∈ Finset.range n,|H k-H (k+1)|) := by
  rw [ordered_stieltjes_identity]
  calc
    _ ≤ |(∑ m ∈ Finset.range n,a m)*H n|+
        ∑ k ∈ Finset.range n,
          |(∑ m ∈ Finset.range (k+1),a m)*(H k-H (k+1))| :=
      (abs_add_le _ _).trans
        (add_le_add_left (Finset.abs_sum_le_sum_abs _ _) _)
    _ ≤ delta*|H n|+
        ∑ k ∈ Finset.range n,delta*|H k-H (k+1)| := by
      apply add_le_add
      · rw [abs_mul]
        exact mul_le_mul_of_nonneg_right (hA n le_rfl) (abs_nonneg _)
      · apply Finset.sum_le_sum
        intro k hk
        rw [abs_mul]
        exact mul_le_mul_of_nonneg_right
          (hA (k+1) (by have := Finset.mem_range.mp hk; omega)) (abs_nonneg _)
    _ = _ := by rw [mul_add,Finset.mul_sum]

def p5U7OrderedSemiprimeCenteredWeight (N m : ℕ) : ℝ :=
  (Real.log (N : ℝ)/(N : ℝ))*p5U7ActualSemiprimeProductWeight N m-
    p5U7ComponentSemiprimeIntegral/(N : ℝ)

theorem p5U7OrderedSemiprimeCenteredWeight_prefix {N k : ℕ} (hN : 0<N) :
    (∑ m ∈ Finset.range k,p5U7OrderedSemiprimeCenteredWeight N m) =
      p5U7OrderedSemiprimeCDF N ((k : ℝ)/(N : ℝ))-
        ((k : ℝ)/(N : ℝ))*p5U7ComponentSemiprimeIntegral := by
  have hNR : (N : ℝ)≠0 := by exact_mod_cast hN.ne'
  simp only [p5U7OrderedSemiprimeCDF,div_mul_cancel₀ _ hNR,Nat.floor_natCast,
    p5U7OrderedSemiprimeCenteredWeight,Finset.sum_sub_distrib,
    ← Finset.mul_sum,Finset.sum_const,Finset.card_range,nsmul_eq_mul]
  ring

-- One N-threshold works for EVERY signed test on the literal actual carrier
-- whose endpoint plus discrete total variation is at most B. B may be zero.
-- The comparison is the exact uniform mesh mass C/N, so no unproved Riemann
-- error or endpoint convention is hidden in the conclusion.
theorem p5U7OrderedSemiprimeStieltjes_eventually_uniform
    (B epsilon : ℝ) (hB : 0≤B) (he : 0<epsilon) :
    ∀ᶠ N : ℕ in atTop, ∀ H : ℕ → ℝ,
      |H N|+(∑ k ∈ Finset.range N,|H k-H (k+1)|)≤B →
      |(Real.log (N : ℝ)/(N : ℝ))*
          (∑ x ∈ p5U7ArithmeticFour N,H (p5U7FourProduct x))-
        (p5U7ComponentSemiprimeIntegral/(N : ℝ))*
          (∑ m ∈ Finset.range N,H m)|<epsilon := by
  let delta := epsilon/(B+1)
  have hdelta : 0<delta := div_pos he (by linarith)
  filter_upwards [eventually_gt_atTop (0 : ℕ),
    p5U7OrderedSemiprimeCDF_eventually_uniform delta hdelta] with N hN hCDF
  intro H hH
  have hA : ∀ k≤N,
      |∑ m ∈ Finset.range k,p5U7OrderedSemiprimeCenteredWeight N m|≤delta := by
    intro k hk
    rw [p5U7OrderedSemiprimeCenteredWeight_prefix hN]
    have hNR : (0 : ℝ)<N := by exact_mod_cast hN
    exact (hCDF _ ⟨div_nonneg (Nat.cast_nonneg k) hNR.le,
      (div_le_one hNR).mpr (by exact_mod_cast hk)⟩).le
  have hbound := ordered_stieltjes_bound
    (p5U7OrderedSemiprimeCenteredWeight N) H N delta hdelta.le hA
  have heq : (∑ m ∈ Finset.range N,
      p5U7OrderedSemiprimeCenteredWeight N m*H m) =
      (Real.log (N : ℝ)/(N : ℝ))*
          (∑ x ∈ p5U7ArithmeticFour N,H (p5U7FourProduct x))-
        (p5U7ComponentSemiprimeIntegral/(N : ℝ))*
          (∑ m ∈ Finset.range N,H m) := by
    rw [← p5U7ActualSemiprimeProductWeight_Fubini]
    simp only [p5U7OrderedSemiprimeCenteredWeight,sub_mul,
      Finset.sum_sub_distrib,← Finset.mul_sum,mul_assoc]
  rw [heq] at hbound
  calc
    _ ≤ delta*(|H N|+∑ k ∈ Finset.range N,|H k-H (k+1)|) := hbound
    _ ≤ delta*B := mul_le_mul_of_nonneg_left hH hdelta.le
    _ < delta*(B+1) := mul_lt_mul_of_pos_left (by linarith) hdelta
    _ = epsilon := div_mul_cancel₀ epsilon (by linarith : B+1≠0)

-- Tests may vary with N. In particular fixed bounded-variation profiles on
-- the physical scale m/N enter by their sampled discrete variation bound.
theorem tendsto_p5U7OrderedSemiprimeStieltjes_moving
    (H : ℕ → ℕ → ℝ) (B : ℝ) (hB : 0≤B)
    (hH : ∀ᶠ N : ℕ in atTop,
      |H N N|+(∑ k ∈ Finset.range N,|H N k-H N (k+1)|)≤B) :
    Tendsto (fun N : ℕ =>
      (Real.log (N : ℝ)/(N : ℝ))*
          (∑ x ∈ p5U7ArithmeticFour N,H N (p5U7FourProduct x))-
        (p5U7ComponentSemiprimeIntegral/(N : ℝ))*
          (∑ m ∈ Finset.range N,H N m)) atTop (𝓝 0) := by
  apply Metric.tendsto_nhds.mpr
  intro epsilon he
  filter_upwards [hH,p5U7OrderedSemiprimeStieltjes_eventually_uniform B epsilon hB he]
    with N hHN hN
  simpa only [Real.dist_eq,sub_zero] using hN (H N) hHN

end
end ImbalancedChen
