import ImbalancedChen.Part3ActualCuspKernelPositive

-- SOURCE ONLY. UNCOMPILED_ZERO_CREDIT. No full-spectrum completeness is assumed.
-- The finite test-point Gram form is an actual nonnegative spectral density.
namespace ImbalancedChen.Part3.ActualCuspKernelFiniteGram20261027
noncomputable section
open Set
open scoped BigOperators
open ActualCuspKernelNormalSeries20261027 ActualCuspKernelPositive20261027
open ActualCuspSmoothEigenprofileFamily20261026b ActualCuspEigenbasisNativeLabels20261026b
open ActualFullCuspEigenbasis20261026b
open MixedSpectralKernelNormalConvergence20261026b
open PlanarWeakDifferentialMultiindex20261026b SmoothMixedSpectralKernelSeries20261026b
open RapidSpectralCoefficientWeights20261026b
open Gamma0ActualSmoothQuotientCore20261025a

private theorem finite_gram_product {X : Type*} (s : Finset X) (c f : X → ℂ) :
    (∑ a ∈ s, ∑ b ∈ s, c a * star (c b) * (f a * star (f b))) =
      (∑ a ∈ s, c a * f a) * star (∑ a ∈ s, c a * f a) := by
  classical
  simp only [star_sum, star_mul, Finset.sum_mul, Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro a ha
  apply Finset.sum_congr rfl
  intro b hb
  ring

def actualCuspFiniteGram {X : Type*} (N : ℕ) [NeZero N] (hN : 0 < N)
    (w : ℝ → ℝ) (s : Finset X) (c : X → ℂ) (p : X → ℝ × ℝ) : ℂ :=
  ∑ a ∈ s, ∑ b ∈ s,
    c a * star (c b) * actualCuspKernel N hN (fun x => (w x : ℂ)) (p a,p b)

-- The finite spatial sums can pass through the original spectral series
-- because every pair is absolutely summable by the proved actual kernel bound.
theorem actualCuspFiniteGram_density {X : Type*} (N : ℕ) [NeZero N] (hN : 0 < N)
    {w : ℝ → ℝ} (hw : RapidOnNonnegative (fun x => (w x : ℂ)))
    (s : Finset X) (c : X → ℂ) (p : X → ℝ × ℝ)
    (hp : ∀ a ∈ s, p a ∈ upperChart) :
    actualCuspFiniteGram N hN w s c p =
      ((∑' i : actualCuspBasisIndex N hN,
        w (actualCuspNativeEigenvalue N hN i) *
          Complex.normSq (∑ a ∈ s, c a * actualCuspPlanarProfile N hN i (p a))) : ℂ) := by
  classical
  let T := fun (a b : X) (i : actualCuspBasisIndex N hN) =>
    c a * star (c b) * actualCuspKernelTerm N hN (fun x => (w x : ℂ)) i (p a,p b)
  have hs : ∀ a ∈ s, ∀ b ∈ s, Summable (T a b) := by
    intro a ha b hb
    exact ((actualCuspKernel_derivative_summable N hN hw []
      ⟨hp a ha,hp b hb⟩).of_norm).mul_left (c a * star (c b))
  have hsa : ∀ a ∈ s, Summable (fun i => ∑ b ∈ s, T a b i) := by
    intro a ha
    exact summable_sum (fun b hb => hs a ha b hb)
  calc
    _ = ∑ a ∈ s, ∑ b ∈ s, ∑' i, T a b i := by
      apply Finset.sum_congr rfl
      intro a ha
      apply Finset.sum_congr rfl
      intro b hb
      exact (tsum_mul_left).symm
    _ = ∑ a ∈ s, ∑' i, ∑ b ∈ s, T a b i := by
      apply Finset.sum_congr rfl
      intro a ha
      exact (Summable.tsum_finsetSum (fun b hb => hs a ha b hb)).symm
    _ = ∑' i, ∑ a ∈ s, ∑ b ∈ s, T a b i :=
      (Summable.tsum_finsetSum hsa).symm
    _ = ∑' i : actualCuspBasisIndex N hN,
        (w (actualCuspNativeEigenvalue N hN i) : ℂ) *
          ((∑ a ∈ s, c a * actualCuspPlanarProfile N hN i (p a)) *
            star (∑ a ∈ s, c a * actualCuspPlanarProfile N hN i (p a))) := by
      apply tsum_congr
      intro i
      rw [← finite_gram_product]
      simp only [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro a ha
      apply Finset.sum_congr rfl
      intro b hb
      dsimp [T, actualCuspKernelTerm, mixedKernelTerm, testPartial, directionalIter]
      ring
    _ = _ := by
      rw [Complex.ofReal_tsum]
      apply tsum_congr
      intro i
      rw [Complex.mul_conj, Complex.ofReal_mul]

theorem actualCuspFiniteGram_nonnegative {X : Type*} (N : ℕ) [NeZero N] (hN : 0 < N)
    {w : ℝ → ℝ} (hw : RapidOnNonnegative (fun x => (w x : ℂ)))
    (hw0 : ∀ x, 0 ≤ x → 0 ≤ w x)
    (s : Finset X) (c : X → ℂ) (p : X → ℝ × ℝ)
    (hp : ∀ a ∈ s, p a ∈ upperChart) :
    (actualCuspFiniteGram N hN w s c p).im = 0 ∧
      0 ≤ (actualCuspFiniteGram N hN w s c p).re := by
  rw [actualCuspFiniteGram_density N hN hw s c p hp]
  simp only [Complex.ofReal_im, Complex.ofReal_re]
  exact ⟨rfl, tsum_nonneg (fun i => mul_nonneg
    (hw0 _ (actualCuspNativeEigenvalue_nonneg N hN i)) (Complex.normSq_nonneg _))⟩

end
end ImbalancedChen.Part3.ActualCuspKernelFiniteGram20261027
