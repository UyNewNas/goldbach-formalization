import ImbalancedChen.Part3ActualCuspKernelNormalSeries
import Mathlib.Analysis.Complex.Basic

-- SOURCE ONLY. UNCOMPILED_ZERO_CREDIT. All transitive spectral holds retained.
-- Hermitian symmetry and positivity concern the actual cuspidal series only.
-- Nonnegative scalar coefficients are primitive hypotheses, not a kernel premise.
namespace ImbalancedChen.Part3.ActualCuspKernelPositive20261027
noncomputable section
open Set
open scoped BigOperators
open ActualCuspKernelNormalSeries20261027
open ActualCuspSmoothEigenprofileFamily20261026b ActualCuspEigenbasisNativeLabels20261026b
open ActualFullCuspEigenbasis20261026b
open MixedSpectralKernelNormalConvergence20261026b
open PlanarWeakDifferentialMultiindex20261026b SmoothMixedSpectralKernelSeries20261026b
open RapidSpectralCoefficientWeights20261026b
open Gamma0ActualSmoothQuotientCore20261025a

theorem actualCuspKernel_conjugate (N : ℕ) [NeZero N] (hN : 0 < N)
    (h : ℝ → ℂ) (p q : ℝ × ℝ) :
    star (actualCuspKernel N hN h (p,q)) =
      actualCuspKernel N hN (fun x => star (h x)) (q,p) := by
  unfold actualCuspKernel mixedKernelSeries
  rw [tsum_star]
  apply tsum_congr
  intro i
  simp only [mixedKernelTerm, star_mul, star_star]
  ring

theorem actualCuspKernel_real_hermitian (N : ℕ) [NeZero N] (hN : 0 < N)
    (w : ℝ → ℝ) (p q : ℝ × ℝ) :
    star (actualCuspKernel N hN (fun x => (w x : ℂ)) (p,q)) =
      actualCuspKernel N hN (fun x => (w x : ℂ)) (q,p) := by
  simpa using actualCuspKernel_conjugate N hN (fun x => (w x : ℂ)) p q

-- This is an exact identity of the original profile series. The rapid-decay
-- assumption below is used to establish convergence, not to redefine its value.
theorem actualCuspKernel_diagonal (N : ℕ) [NeZero N] (hN : 0 < N)
    (w : ℝ → ℝ) (p : ℝ × ℝ) :
    actualCuspKernel N hN (fun x => (w x : ℂ)) (p,p) =
      ((∑' i : actualCuspBasisIndex N hN,
        w (actualCuspNativeEigenvalue N hN i) *
          Complex.normSq (actualCuspPlanarProfile N hN i p)) : ℂ) := by
  rw [Complex.ofReal_tsum]
  unfold actualCuspKernel mixedKernelSeries
  apply tsum_congr
  intro i
  simp only [mixedKernelTerm, testPartial, directionalIter, Complex.ofReal_mul]
  rw [mul_assoc, Complex.mul_conj]
  rfl

theorem actualCuspKernel_diagonal_weight_summable (N : ℕ) [NeZero N] (hN : 0 < N)
    {w : ℝ → ℝ} (hw : RapidOnNonnegative (fun x => (w x : ℂ)))
    {p : ℝ × ℝ} (hp : p ∈ upperChart) :
    Summable (fun i : actualCuspBasisIndex N hN =>
      w (actualCuspNativeEigenvalue N hN i) *
        Complex.normSq (actualCuspPlanarProfile N hN i p)) := by
  have hs := (actualCuspKernel_derivative_summable N hN hw [] ⟨hp,hp⟩).of_norm
  have hr := (Complex.hasSum_re hs.hasSum).summable
  convert hr using 1
  ext i
  simp only [pairWordPartial, actualCuspKernelTerm, mixedKernelTerm, testPartial,
    directionalIter]
  rw [mul_assoc, Complex.mul_conj]
  simp

theorem actualCuspKernel_diagonal_nonnegative (N : ℕ) [NeZero N] (hN : 0 < N)
    {w : ℝ → ℝ} (hw : RapidOnNonnegative (fun x => (w x : ℂ)))
    (hw0 : ∀ x, 0 ≤ x → 0 ≤ w x) {p : ℝ × ℝ} (hp : p ∈ upperChart) :
    (actualCuspKernel N hN (fun x => (w x : ℂ)) (p,p)).im = 0 ∧
      0 ≤ (actualCuspKernel N hN (fun x => (w x : ℂ)) (p,p)).re := by
  have hs := actualCuspKernel_diagonal_weight_summable N hN hw hp
  rw [actualCuspKernel_diagonal]
  simp only [Complex.ofReal_im, Complex.ofReal_re]
  exact ⟨rfl, tsum_nonneg (fun i => mul_nonneg
    (hw0 _ (actualCuspNativeEigenvalue_nonneg N hN i)) (Complex.normSq_nonneg _))⟩

-- Pointwise comparison pays no additional spectral loss: the same actual
-- nonnegative profile densities appear on both sides, and both sums converge.
theorem actualCuspKernel_diagonal_mono (N : ℕ) [NeZero N] (hN : 0 < N)
    {u v : ℝ → ℝ}
    (hu : RapidOnNonnegative (fun x => (u x : ℂ)))
    (hv : RapidOnNonnegative (fun x => (v x : ℂ)))
    (huv : ∀ x, 0 ≤ x → u x ≤ v x)
    {p : ℝ × ℝ} (hp : p ∈ upperChart) :
    (actualCuspKernel N hN (fun x => (u x : ℂ)) (p,p)).re ≤
      (actualCuspKernel N hN (fun x => (v x : ℂ)) (p,p)).re := by
  rw [actualCuspKernel_diagonal, actualCuspKernel_diagonal]
  simp only [Complex.ofReal_re]
  exact (actualCuspKernel_diagonal_weight_summable N hN hu hp).tsum_le_tsum
    (fun i => mul_le_mul_of_nonneg_right
      (huv _ (actualCuspNativeEigenvalue_nonneg N hN i)) (Complex.normSq_nonneg _))
    (actualCuspKernel_diagonal_weight_summable N hN hv hp)

end
end ImbalancedChen.Part3.ActualCuspKernelPositive20261027
