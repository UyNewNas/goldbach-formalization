import ImbalancedChen.P2EnhancedLowerFinitePhysicalGraph

-- SOURCE ONLY / UNCOMPILED / ZERO FORMAL CREDIT.
-- Original distribution-coefficient-completion, section 7: total rough
-- rank includes the old marked primes. No high-rank BV licence is asserted.
namespace ImbalancedChen.P2EnhancedLowerGraphRankTwoSupport

noncomputable section
open P2EnhancedLowerPhysicalNode P2EnhancedLowerPhysicalTransition
open P2EnhancedLowerFinitePhysicalGraph

def WordBound (rho : ℝ) (n : PhysicalNode) : Prop :=
  ∀ x ∈ word n, x ≤ rho

theorem appendOne_wordBound {rho x s : ℝ} {n : PhysicalNode}
    (hn : WordBound rho n) (hx : x ≤ rho) :
    WordBound rho (appendOne n x s) := by
  intro t ht
  rw [word_appendOne] at ht
  rcases List.mem_append.mp ht with ht | ht
  · exact hn t ht
  · rcases List.mem_singleton.mp ht with rfl
    exact hx

theorem appendPair_wordBound {rho x y s : ℝ} {n : PhysicalNode}
    (hn : WordBound rho n) (hx : x ≤ rho) (hy : y ≤ rho) :
    WordBound rho (appendPair n x y s) := by
  intro t ht
  rw [word_appendPair] at ht
  rcases List.mem_append.mp ht with ht | ht
  · exact hn t ht
  · simp only [List.mem_cons, List.mem_singleton] at ht
    rcases ht with rfl | rfl
    · exact hy
    · exact hx

-- These hypotheses concern only the primitive root ceiling and its old
-- physical slots. Every appended exponent is bounded by the local gates.
theorem perform_wordBound {rho : ℝ} {n : PhysicalNode}
    {shape : StepShape} {z : P5OriginalActionMassBound.Point}
    (hn : WordBound rho n) (hc : n.ceiling ≤ rho)
    (hz : LocalDomain n shape z) : WordBound rho (perform n shape z) := by
  cases shape with
  | retain => exact hn
  | transport cell => exact hn
  | buchstabUpper => exact appendOne_wordBound hn (hz.2.1.2.1.trans hc)
  | buchstabLower => exact appendOne_wordBound hn (hz.2.2.1.2.1.trans hc)
  | w1Fixed i j => exact hn
  | w1Singleton i j => exact appendOne_wordBound hn (hz.2.1.2.1.trans hc)
  | w2Fixed bank anchor => exact hn
  | w2Singleton bank piece => exact appendOne_wordBound hn (hz.2.1.2.1.trans hc)
  | w2Pair bank piece =>
      exact appendPair_wordBound hn
        (hz.2.1.2.1.le.trans (hz.2.1.2.2.1.trans hc))
        (hz.2.1.2.2.1.trans hc)

theorem realize_wordBound {a b rho : ℝ} {mesh depth : ℕ}
    {n : TypedNode} {code : Program mesh depth} {z : Coordinates depth}
    (hn : WordBound rho n.physical) (hc : n.physical.ceiling ≤ rho)
    (hz : Member a b depth n code z) :
    WordBound rho (realize depth n code z).physical ∧
      (realize depth n code z).physical.ceiling ≤ rho := by
  induction depth generalizing n with
  | zero => exact ⟨hn, hc⟩
  | succ depth ih =>
      have hb := perform_wordBound hn hc hz.2.2.1
      have hceil := (perform_ceiling hz.2.2.1).trans hc
      exact ih hb hceil hz.2.2.2

-- The second complete square is x+2y≤total. Combining it with the
-- original largest-prime ceiling bounds x+y, including marked slots.
theorem lowRank_complete_exponent {n : PhysicalNode}
    (hgate : fullGates n) (hcap : n.total ≤ (153 / 256 : ℝ))
    (hword : WordBound (57 / 224 : ℝ) n) (hrank : n.slots.length ≤ 2) :
    (word n).sum ≤ (1527 / 3584 : ℝ) := by
  have hlen : (word n).length ≤ 2 := by simpa [word] using hrank
  cases hw : word n with
  | nil => simp only [hw, List.sum_nil]; norm_num
  | cons x xs =>
      cases xs with
      | nil =>
          have hgates : SquareGates n.total 0 [x] := by
            simpa only [fullGates, hw] using hgate
          have hg : 2*x ≤ n.total := by
            simpa only [zero_add] using hgates.1
          simp only [hw, List.sum_cons, List.sum_nil, add_zero]
          linarith
      | cons y ys =>
          cases ys with
          | nil =>
              have hx : x ≤ (57 / 224 : ℝ) := hword x (by simp [hw])
              have hg : x+2*y ≤ n.total := by
                change SquareGates n.total 0 (word n) at hgate
                rw [hw] at hgate
                simpa only [SquareGates, zero_add] using hgate.2.1
              simp only [hw, List.sum_cons, List.sum_nil, add_zero]
              linarith
          | cons t ts => simp only [hw, List.length_cons] at hlen; omega

theorem graph_lowRank_complete_exponent {a b : ℝ} {mesh depth : ℕ}
    {n : TypedNode} {code : Program mesh depth} {z : Coordinates depth}
    (hf : fullGates n.physical) (hs : selectedGates n.physical)
    (ha : 2 ≤ alpha n.physical) (htotal : n.physical.total ≤ (153 / 256 : ℝ))
    (hword : WordBound (57 / 224 : ℝ) n.physical)
    (hceiling : n.physical.ceiling ≤ (57 / 224 : ℝ))
    (hz : Member a b depth n code z)
    (hrank : (realize depth n code z).physical.slots.length ≤ 2) :
    (word (realize depth n code z).physical).sum ≤ (1527 / 3584 : ℝ) := by
  apply lowRank_complete_exponent (realize_gates_alpha hf hs ha hz).1
  · rw [realize_total]; exact htotal
  · exact (realize_wordBound hword hceiling hz).1
  · exact hrank

-- Both beta/fine inflation and complete-scale conversion are charged.
-- The caller supplies their primitive reserve budget, not a half-level bound.
theorem lowRank_after_reserves {n : PhysicalNode} {inflation kappa : ℝ}
    (hgate : fullGates n) (hcap : n.total ≤ (153 / 256 : ℝ))
    (hword : WordBound (57 / 224 : ℝ) n) (hrank : n.slots.length ≤ 2)
    (hkappa : kappa < 1)
    (hbudget : inflation + kappa/2 < (265 / 3584 : ℝ)) :
    ((word n).sum + inflation)/(1-kappa) < (1/2 : ℝ) := by
  have hsum := lowRank_complete_exponent hgate hcap hword hrank
  apply (div_lt_iff₀ (sub_pos.mpr hkappa)).mpr
  linarith

end
end ImbalancedChen.P2EnhancedLowerGraphRankTwoSupport
