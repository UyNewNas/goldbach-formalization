import ImbalancedChen.P2EnhancedLowerGraphRankTwoSupport
import ImbalancedChen.ChenQuotientLevelGeometry
import ImbalancedChen.CurrentChenUpsilon9SwitchedUpperDensity

-- SOURCE ONLY / UNCOMPILED / ZERO FORMAL CREDIT.
-- A fixed exponent reserve is chosen before the target. The atom support
-- estimate below is in physical exponent coordinates including every old
-- marked prime; it is not a cap on a residual divisor alone.
namespace ImbalancedChen.P2EnhancedLowerGraphPhysicalBVCap

noncomputable section
open Filter
open P2EnhancedLowerPhysicalNode P2EnhancedLowerPhysicalTransition
open P2EnhancedLowerFinitePhysicalGraph P2EnhancedLowerGraphRankTwoSupport
open MathlibNt.SieveTheory.LiuWeight (panModulusCutoff)

def reservedExponent (inflation kappa : ℝ) : ℝ :=
  ((1527 / 3584 : ℝ)+inflation)/(1-kappa)

theorem reservedExponent_lt_half {inflation kappa : ℝ} (hkappa : kappa < 1)
    (hbudget : inflation+kappa/2 < (265 / 3584 : ℝ)) :
    reservedExponent inflation kappa < (1/2 : ℝ) := by
  unfold reservedExponent
  apply (div_lt_iff₀ (sub_pos.mpr hkappa)).mpr
  linarith

-- One threshold works for every actual finite path, its depth, root and
-- modulus, after the fixed beta/fine and complete-scale reserves are paid.
theorem eventually_graph_lowRank_physical_BV_cap
    (B inflation kappa : ℝ) (hkappa : kappa < 1)
    (hbudget : inflation+kappa/2 < (265 / 3584 : ℝ)) :
    ∀ᶠ N : ℕ in atTop, ∀ a b : ℝ, ∀ mesh depth : ℕ,
      ∀ n : TypedNode, ∀ code : Program mesh depth, ∀ z : Coordinates depth,
      fullGates n.physical → selectedGates n.physical → 2 ≤ alpha n.physical →
      n.physical.total ≤ (153 / 256 : ℝ) →
      WordBound (57 / 224 : ℝ) n.physical → n.physical.ceiling ≤ (57 / 224 : ℝ) →
      Member a b depth n code z →
      (realize depth n code z).physical.slots.length ≤ 2 →
      ∀ d : ℕ,
      (d : ℝ) ≤ (N : ℝ) ^
        (((word (realize depth n code z).physical).sum+inflation)/(1-kappa)) →
      d ≤ panModulusCutoff N B := by
  have hhalf := reservedExponent_lt_half hkappa hbudget
  filter_upwards
    [eventually_powerBound_le_chenInitialLevelCap B (reservedExponent inflation kappa) hhalf,
      eventually_ge_atTop (1 : ℕ)] with N hcap hN
  intro a b mesh depth n code z hf hs ha htotal hword hceiling hz hrank d hd
  have hsum := graph_lowRank_complete_exponent hf hs ha htotal hword hceiling hz hrank
  have he : ((word (realize depth n code z).physical).sum+inflation)/(1-kappa) ≤
      reservedExponent inflation kappa :=
    div_le_div_of_nonneg_right (add_le_add_right hsum inflation) (sub_pos.mpr hkappa).le
  have hNreal : (1 : ℝ) ≤ N := by exact_mod_cast hN
  have hpower : (d : ℝ) ≤ (N : ℝ) ^ reservedExponent inflation kappa :=
    hd.trans (Real.rpow_le_rpow_of_exponent_le hNreal he)
  rw [currentChenUpsilon9_panCutoff_eq_initialLevel]
  exact hcap d hpower

end
end ImbalancedChen.P2EnhancedLowerGraphPhysicalBVCap
