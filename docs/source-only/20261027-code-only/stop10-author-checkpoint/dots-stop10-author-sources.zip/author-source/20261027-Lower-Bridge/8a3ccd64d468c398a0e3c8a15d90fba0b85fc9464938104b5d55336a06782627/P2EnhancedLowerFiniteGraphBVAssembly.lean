import ImbalancedChen.P2EnhancedLowerFinitePhysicalGraph
import ImbalancedChen.Part3PrimeAPDistribution

-- SOURCE ONLY / UNCOMPILED / ZERO FORMAL CREDIT.
-- The finite graph is fixed before N. Its original restoring scalars may
-- exceed one because marked multiplicities are retained. Only the inner
-- normalized coefficients have absolute value at most one.
namespace ImbalancedChen.P2EnhancedLowerFiniteGraphBVAssembly

noncomputable section
open Filter
open scoped BigOperators
open P2EnhancedLowerFinitePhysicalGraph
open MathlibNt.SieveTheory.LiuWeight (panModulusCutoff)

def restoringMass (mesh horizon : ℕ) (scalar : GraphVertex mesh horizon → ℝ) : ℝ :=
  ∑ v ∈ allVertices mesh horizon, |scalar v|

def discrepancy (mesh horizon N : ℕ)
    (scalar : GraphVertex mesh horizon → ℝ)
    (support : GraphVertex mesh horizon → Finset ℕ)
    (endpoint : GraphVertex mesh horizon → ℕ)
    (residue : GraphVertex mesh horizon → ℕ → ℕ)
    (coefficient : GraphVertex mesh horizon → ℕ → ℝ) : ℝ :=
  ∑ v ∈ allVertices mesh horizon, scalar v *
    ∑ d ∈ support v, coefficient v d * part3PrimeAPError (endpoint v) (residue v d) d

theorem restoringMass_nonneg (mesh horizon : ℕ)
    (scalar : GraphVertex mesh horizon → ℝ) : 0 ≤ restoringMass mesh horizon scalar := by
  exact Finset.sum_nonneg (fun _ _ => abs_nonneg _)

-- A complete physical modulus cap is required for every coefficient;
-- the inner residual divisor cap alone cannot enter this theorem.
theorem graph_BV_uniform (mesh horizon : ℕ)
    (scalar : GraphVertex mesh horizon → ℝ) (accuracy : ℝ) (haccuracy : 0 < accuracy) :
    ∃ B : ℝ, 0 ≤ B ∧ ∃ C : ℝ, 0 < C ∧
      ∀ᶠ N : ℕ in atTop, ∀ Q : ℕ, Q ≤ panModulusCutoff N B →
        ∀ support : GraphVertex mesh horizon → Finset ℕ,
        (∀ v ∈ allVertices mesh horizon, support v ⊆ Finset.Icc 1 Q) →
        ∀ endpoint : GraphVertex mesh horizon → ℕ,
        (∀ v ∈ allVertices mesh horizon, endpoint v ≤ N) →
        ∀ residue : GraphVertex mesh horizon → ℕ → ℕ,
        (∀ v ∈ allVertices mesh horizon, ∀ d ∈ support v, Nat.Coprime (residue v d) d) →
        ∀ coefficient : GraphVertex mesh horizon → ℕ → ℝ,
        (∀ v ∈ allVertices mesh horizon, ∀ d ∈ support v, |coefficient v d| ≤ 1) →
        |discrepancy mesh horizon N scalar support endpoint residue coefficient| ≤
          restoringMass mesh horizon scalar * (C * (N : ℝ) / Real.log (N : ℝ)^accuracy) := by
  obtain ⟨B, hB, C, hC, hBV⟩ :=
    part3_abs_sum_mul_primeAPError_log_saving accuracy haccuracy
  refine ⟨B, hB, C, hC, ?_⟩
  filter_upwards [hBV] with N hN
  intro Q hQ support hsupport endpoint hendpoint residue hresidue coefficient hcoefficient
  unfold discrepancy
  calc
    _ ≤ ∑ v ∈ allVertices mesh horizon,
        |scalar v * ∑ d ∈ support v,
          coefficient v d * part3PrimeAPError (endpoint v) (residue v d) d| :=
      Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ v ∈ allVertices mesh horizon,
        |scalar v| * (C * (N : ℝ) / Real.log (N : ℝ)^accuracy) := by
      apply Finset.sum_le_sum
      intro v hv
      rw [abs_mul]
      exact mul_le_mul_of_nonneg_left
        (hN Q hQ (support v) (hsupport v hv) (endpoint v) (hendpoint v hv)
          (residue v) (hresidue v hv) (coefficient v) (hcoefficient v hv))
        (abs_nonneg _)
    _ = _ := by rw [restoringMass, Finset.sum_mul]

-- The fixed graph coefficient is assembled exactly. Different labelled
-- vertices remain distinct even when they yield the same physical modulus.
theorem coefficient_restoringMass_bound (mesh horizon : ℕ)
    (scalar : GraphVertex mesh horizon → ℝ)
    (coefficient : GraphVertex mesh horizon → ℕ → ℝ) (d : ℕ)
    (hunit : ∀ v ∈ allVertices mesh horizon, |coefficient v d| ≤ 1) :
    |∑ v ∈ allVertices mesh horizon, scalar v * coefficient v d| ≤
      restoringMass mesh horizon scalar := by
  refine (Finset.abs_sum_le_sum_abs _ _).trans ?_
  apply Finset.sum_le_sum
  intro v hv
  rw [abs_mul]
  simpa only [mul_one] using
    mul_le_mul_of_nonneg_left (hunit v hv) (abs_nonneg (scalar v))

end
end ImbalancedChen.P2EnhancedLowerFiniteGraphBVAssembly
