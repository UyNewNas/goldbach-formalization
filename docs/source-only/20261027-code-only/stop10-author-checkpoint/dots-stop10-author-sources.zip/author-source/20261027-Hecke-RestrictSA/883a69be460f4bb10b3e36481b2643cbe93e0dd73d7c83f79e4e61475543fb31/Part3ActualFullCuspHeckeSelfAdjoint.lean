import ImbalancedChen.Part3ActualCuspidalHeckeRestriction
import ImbalancedChen.Part3ActualHeckeReversalL2
import Mathlib.Analysis.InnerProductSpace.Adjoint
import Mathlib.Topology.Algebra.Module.ContinuousLinearMap.Restrict

-- SOURCE_ONLY / UNCOMPILED_ZERO_CREDIT / READY_FALSE, 2026-10-27.
-- Self-adjointness of the EXISTING original normalized physical Tp on the
-- entire original all-frame cusp annihilator, using its canonical863e restriction.
-- Self-adjointness is proved directly from the actual reversal pairing;
-- no self-adjointness of the operator on the ambient quotient is assumed.
-- Transitive immutable source/API holds remain in force.

namespace ImbalancedChen.Part3.ActualFullCuspHeckeSelfAdjoint20261027
noncomputable section
open MeasureTheory
open Gamma0ActualSmoothQuotientCore20261025a Gamma0QuotientCellPushforward20261025a
open AllNormalizedCuspAnnihilator20261026b ActualFullCuspResolvent20261026b
open ActualCuspidalHeckeRestriction20261026b
open ActualBoundedPhysicalHecke20261026b ActualHeckeCorrespondencePairing20261026b
open ActualHeckeForgetL220261026b ActualHeckeSecondL220261026b
open ActualHeckeAllFrameCuspPreservation20261026b ActualHeckeReversalL220261027

variable (N p : ℕ) [NeZero N] [NeZero (N*p)]
  (hN : 0 < N) (hp : p.Prime) (hpN : ¬ p ∣ N)

local instance fullCusp_complete : CompleteSpace (allFrameCuspSubspace N hN) :=
  (allFrameCuspSubspace_closed N hN).completeSpace_coe

-- Literal original p+1 branch formula for the restricted native L2 vector.
theorem actualCuspHeckeOperator_physical_representative (f : allFrameCuspSubspace N hN) :
    ((actualCuspHeckeOperator N p hN hp hpN f : QuotientL2 N) : Gamma0OrbitSpace N → ℂ)
      =ᵐ[carrierPushforward N]
      ActualPrimeHeckeQuotientDescent20261026b.quotientHecke N p hp hpN
        (f : QuotientL2 N) :=
  physicalHeckeOperator_coe N p hN hp hpN f

-- The actual inherited bound retains the original square-root normalization.
theorem actualCuspHeckeOperator_apply_norm_le (f : allFrameCuspSubspace N hN) :
    ‖actualCuspHeckeOperator N p hN hp hpN f‖ ≤
      ((p+1 : ℝ)/Real.sqrt (p : ℝ))*‖f‖ :=
  physicalHeckeOperator_apply_norm_le N p hN hp hpN f

theorem actualCuspHeckeOperator_norm_le :
    ‖actualCuspHeckeOperator N p hN hp hpN‖ ≤ (p+1 : ℝ)/Real.sqrt (p : ℝ) := by
  apply ContinuousLinearMap.opNorm_le_bound
  · exact div_nonneg (by positivity) (Real.sqrt_nonneg _)
  · exact actualCuspHeckeOperator_apply_norm_le N p hN hp hpN

-- This native pairing is proved for actual full-cusp vectors and the same
-- restricted operator, before any self-adjointness assertion is made.
private theorem fullCuspHecke_pairing (f g : allFrameCuspSubspace N hN) :
    (Real.sqrt (p : ℝ) : ℂ) * inner ℂ f (actualCuspHeckeOperator N p hN hp hpN g) =
      inner ℂ (rawPullback N p hp hpN (f : QuotientL2 N))
        (rawSecondPullbackLinear N p hN hp hpN (g : QuotientL2 N)) := by
  change (Real.sqrt (p : ℝ) : ℂ) * inner ℂ (f : QuotientL2 N)
    (physicalHeckeOperator N p hN hp hpN (g : QuotientL2 N)) = _
  rw [physicalHeckeOperator_eq_physicalHeckeLp]
  exact (rawPullback_inner_physicalHecke N p hN hp hpN f g).symm

-- Direct restriction symmetry: actual reversal interchanges the pullbacks,
-- and complex conjugation cancels the real nonzero sqrt(p) normalization.
theorem actualCuspHeckeOperator_symmetric (f g : allFrameCuspSubspace N hN) :
    inner ℂ (actualCuspHeckeOperator N p hN hp hpN f) g =
      inner ℂ f (actualCuspHeckeOperator N p hN hp hpN g) := by
  have hs : (Real.sqrt (p : ℝ) : ℂ) ≠ 0 := by
    exact_mod_cast (Real.sqrt_pos.mpr
      (show (0 : ℝ) < p by exact_mod_cast hp.pos)).ne'
  apply mul_left_cancel₀ hs
  calc
    (Real.sqrt (p : ℝ) : ℂ) * inner ℂ (actualCuspHeckeOperator N p hN hp hpN f) g =
        star ((Real.sqrt (p : ℝ) : ℂ) * inner ℂ g (actualCuspHeckeOperator N p hN hp hpN f)) := by
      simp only [star_mul]
      simp
    _ = star (inner ℂ (rawPullback N p hp hpN (g : QuotientL2 N))
        (rawSecondPullbackLinear N p hN hp hpN (f : QuotientL2 N))) :=
      congrArg star (fullCuspHecke_pairing N p hN hp hpN g f)
    _ = inner ℂ (rawSecondPullbackLinear N p hN hp hpN (f : QuotientL2 N))
        (rawPullback N p hp hpN (g : QuotientL2 N)) := inner_conj_symm _ _
    _ = inner ℂ (rawPullback N p hp hpN (f : QuotientL2 N))
        (rawSecondPullbackLinear N p hN hp hpN (g : QuotientL2 N)) :=
      (rawPullback_inner_swap N p hp hpN hN f g).symm
    _ = (Real.sqrt (p : ℝ) : ℂ) * inner ℂ f (actualCuspHeckeOperator N p hN hp hpN g) :=
      (fullCuspHecke_pairing N p hN hp hpN f g).symm

-- The native bounded adjoint is on the entire original cusp Hilbert space.
theorem actualCuspHeckeOperator_isSelfAdjoint :
    IsSelfAdjoint (actualCuspHeckeOperator N p hN hp hpN) := by
  apply ContinuousLinearMap.isSelfAdjoint_iff_isSymmetric.mpr
  exact actualCuspHeckeOperator_symmetric N p hN hp hpN

theorem actualCuspHeckeOperator_adjoint :
    (actualCuspHeckeOperator N p hN hp hpN).adjoint = actualCuspHeckeOperator N p hN hp hpN :=
  (actualCuspHeckeOperator_isSelfAdjoint N p hN hp hpN).isSymmetric.clm_adjoint_eq

end
end ImbalancedChen.Part3.ActualFullCuspHeckeSelfAdjoint20261027



