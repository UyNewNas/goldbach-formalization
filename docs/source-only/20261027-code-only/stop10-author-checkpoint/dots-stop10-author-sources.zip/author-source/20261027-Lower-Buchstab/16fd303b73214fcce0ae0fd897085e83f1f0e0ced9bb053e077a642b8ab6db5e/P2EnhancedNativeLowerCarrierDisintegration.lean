import ImbalancedChen.P2EnhancedNativeLowerResidualFactor

-- SOURCE ONLY / UNCOMPILED_ZERO_CREDIT.
-- Exact finite arithmetic identities. No density or distribution assertion.
-- The lower coefficient keeps its original even set-prefix tests. Its
-- conditional small level is L/d and its parity is the actual rough rank.

namespace ImbalancedChen.P2EnhancedNativeLowerCarrierDisintegration

noncomputable section
open scoped Classical BigOperators
open P5Z.OriginalOrdinaryBetaRegroup
open P2EnhancedNativeLowerResidualFactor

-- The complete native divisor carrier is split before inactive rows are
-- removed. B is the saved physical marked prefix in every signed test.
theorem native_lower_test_split (N cap B : ℕ) {w Z : ℝ}
    (hwZ : w ≤ Z) (L : ℝ) (F : ℕ → ℝ) :
    (∑ q ∈ actualSmallRosserSupport N cap Z,
      actualSmallRosserMinus N cap Z L q * F (B * q)) =
    ∑ d ∈ roughSupport N cap w Z,
      lowerRoughWeight N cap w Z L d *
        ∑ e ∈ actualSmallRosserSupport N cap w,
          lowerResidualSmallWeight N cap w L d e * F (B * (e * d)) := by
  rw [nativeSupport_eq_products N cap hwZ]
  rw [sum_smallRoughModuli
    (fun e he => actualSmallRosserSupport_smallPrimeSupportedAt N cap w he)
    (fun d hd => roughSupport_rough hd)]
  rw [Finset.sum_product, Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro d hd
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro e he
  rw [native_lower_residual_factor_on_support hwZ he hd]
  ring

-- Coefficientwise disintegration, including q=0, absent cap primes,
-- forbidden target primes and repeated powers. A product fibre is kept;
-- no independent beta(e) replaces the conditional native small factor.
theorem native_lower_coefficient_fibre (N cap q : ℕ) {w Z : ℝ}
    (hwZ : w ≤ Z) (L : ℝ) :
    actualSmallRosserMinus N cap Z L q =
      ∑ d ∈ roughSupport N cap w Z,
        lowerRoughWeight N cap w Z L d *
          ∑ e ∈ actualSmallRosserSupport N cap w,
            if e * d = q then lowerResidualSmallWeight N cap w L d e else 0 := by
  have h := native_lower_test_split N cap 1 hwZ L
    (fun a => if a = q then (1 : ℝ) else 0)
  have hleft :
      (∑ a ∈ actualSmallRosserSupport N cap Z,
        actualSmallRosserMinus N cap Z L a *
          (if a = q then (1 : ℝ) else 0)) =
        actualSmallRosserMinus N cap Z L q := by
    by_cases hq : q ∈ actualSmallRosserSupport N cap Z
    · simp [mul_ite, hq]
    · have hz : actualSmallRosserMinus N cap Z L q = 0 := by
        by_contra hn
        exact hq (actualSmallRosserMinus_active hn).1
      simp [mul_ite, hq, hz]
  simpa only [one_mul, mul_ite, mul_one, mul_zero, hleft] using h

-- Explicit separation of the two genuine rough-parity branches. In the
-- even branch the small atom is LOWER; in the odd branch it is UPPER.
-- Both branches use L/d and preserve the physical argument B*(e*d).
theorem native_lower_test_parity (N cap B : ℕ) {w Z : ℝ}
    (hwZ : w ≤ Z) (L : ℝ) (F : ℕ → ℝ) :
    (∑ q ∈ actualSmallRosserSupport N cap Z,
      actualSmallRosserMinus N cap Z L q * F (B * q)) =
      (∑ d ∈ roughSupport N cap w Z,
        if Even d.primeFactors.card then
          lowerRoughWeight N cap w Z L d *
            ∑ e ∈ actualSmallRosserSupport N cap w,
              actualSmallRosserMinus N cap w (L / (d : ℝ)) e *
                F (B * (e * d))
        else 0) +
      (∑ d ∈ roughSupport N cap w Z,
        if Even d.primeFactors.card then 0 else
          lowerRoughWeight N cap w Z L d *
            ∑ e ∈ actualSmallRosserSupport N cap w,
              actualSmallRosserPlus N cap w (L / (d : ℝ)) e *
                F (B * (e * d))) := by
  rw [native_lower_test_split N cap B hwZ L F, ← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro d hd
  by_cases hp : Even d.primeFactors.card <;>
    simp only [lowerResidualSmallWeight, hp, if_pos, if_neg, add_zero, zero_add]

-- The full original marked prefix is part of the divisor event. The
-- identity is valid at n=0 and does not silently cancel B from the event.
theorem native_lower_divisor_split (N cap B n : ℕ) {w Z : ℝ}
    (hwZ : w ≤ Z) (L : ℝ) :
    (∑ q ∈ actualSmallRosserSupport N cap Z,
      if B * q ∣ n then actualSmallRosserMinus N cap Z L q else 0) =
    ∑ d ∈ roughSupport N cap w Z,
      lowerRoughWeight N cap w Z L d *
        ∑ e ∈ actualSmallRosserSupport N cap w,
          if B * (e * d) ∣ n then lowerResidualSmallWeight N cap w L d e else 0 := by
  simpa only [mul_ite, mul_one, mul_zero] using
    native_lower_test_split N cap B hwZ L
      (fun a => if a ∣ n then (1 : ℝ) else 0)

end
end ImbalancedChen.P2EnhancedNativeLowerCarrierDisintegration
