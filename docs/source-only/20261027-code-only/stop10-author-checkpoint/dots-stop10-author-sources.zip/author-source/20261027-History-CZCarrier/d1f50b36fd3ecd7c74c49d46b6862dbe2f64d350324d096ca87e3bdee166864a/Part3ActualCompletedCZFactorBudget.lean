import ImbalancedChen.Part3ActualCompletedAllModeBridge

-- SOURCE ONLY / UNCOMPILED / ZERO FORMAL CREDIT, 2026-10-27.
-- Actual c,z aggregation after the original source split.  The Cauchy
-- carrier costs Q times the square of the fixed eligible t carrier;
-- neither the signed f window nor the two h labels are counted again.
-- Ordered t1,t2 factorizations at a positive z cost at most tau(z).
-- This elementary estimate does not supply the retained spectral 7/32.
-- An application after the closed-T split must first pay its COST2.

namespace ImbalancedChen.Part3.ActualCompletedCZFactorBudget20261027

noncomputable section
open Classical Finset CommonSmoothCutoff OriginalSmoothPoissonTail
open ActualReciprocalSquarePoissonSourceOnly
open ActualCompletedSquarePushforwardSourceOnly
open ActualCompletedAllModeBridge20261026b
open OriginalSmoothPoissonTail.FiniteOperator20261026b
open scoped BigOperators

def eligibleFactors (A : ℕ) (a : ℤ) (T : Finset ℕ) : Finset ℕ :=
  T.filter (fixedUnit A a)

def factorPairs (A : ℕ) (a : ℤ) (T : Finset ℕ) : Finset (ℕ × ℕ) :=
  eligibleFactors A a T ×ˢ eligibleFactors A a T

def factorProducts (A : ℕ) (a : ℤ) (T : Finset ℕ) : Finset ℕ :=
  (factorPairs A a T).image (fun p => p.1*p.2)

def orderedFactorFibre (A : ℕ) (a : ℤ) (T : Finset ℕ) (z : ℕ) :
    Finset (ℕ × ℕ) :=
  (factorPairs A a T).filter (fun p => p.1*p.2=z)

-- This applies to the literal source and every retained sign/f/gcd slice
-- by its actual source inclusion, before any norm or coefficient bound.
theorem jointZCarrier_subset_factorProducts
    {A : ℕ} {a : ℤ} {T : Finset ℕ} {H : ℕ} {Fset : Finset ℤ}
    {U : Finset Source} (hU : U ⊆ carrier A a T H Fset) :
    jointZCarrier U ⊆ factorProducts A a T := by
  intro z hz
  obtain ⟨zy,hzy,hz⟩ := mem_image.mp hz
  obtain ⟨s,hs,hszy⟩ := mem_image.mp hzy
  obtain ⟨hr,hgate⟩ := mem_filter.mp (hU hs)
  obtain ⟨_,huv⟩ := mem_product.mp hr
  obtain ⟨hu,hv⟩ := mem_product.mp huv
  have htu : s.2.1.1 ∈ T := (mem_product.mp hu).1
  have htv : s.2.2.1 ∈ T := (mem_product.mp hv).1
  apply mem_image.mpr
  refine ⟨(s.2.1.1,s.2.2.1),?_,?_⟩
  · exact mem_product.mpr
      ⟨mem_filter.mpr ⟨htu,hgate.2.1⟩,mem_filter.mpr ⟨htv,hgate.2.2⟩⟩
  · change (output s).1 = z
    exact (congrArg Prod.fst hszy).trans hz

theorem jointZCarrier_card_le
    {A : ℕ} {a : ℤ} {T : Finset ℕ} {H : ℕ} {Fset : Finset ℤ}
    {U : Finset Source} (hU : U ⊆ carrier A a T H Fset) :
    (jointZCarrier U).card ≤ (eligibleFactors A a T).card^2 := by
  calc
    _ ≤ (factorProducts A a T).card :=
      card_le_card (jointZCarrier_subset_factorProducts hU)
    _ ≤ (factorPairs A a T).card := card_image_le
    _ = _ := by simp only [factorPairs,card_product,pow_two]

-- Positivity of z is essential: tau(0)=0 cannot bound a zero-product fibre.
-- Injecting into the FIRST divisor retains both orders, including squares.
theorem orderedFactorFibre_card_le_divisors (A : ℕ) (a : ℤ)
    (T : Finset ℕ) {z : ℕ} (hz : 0 < z) :
    (orderedFactorFibre A a T z).card ≤ z.divisors.card := by
  apply card_le_card_of_injOn (fun p : ℕ × ℕ => p.1)
  · intro p hp
    have hprod := (mem_filter.mp hp).2
    exact Nat.mem_divisors.mpr ⟨⟨p.2,hprod.symm⟩,hz.ne'⟩
  · intro p hp r hr hfirst
    have hpz := (mem_filter.mp hp).2
    have hrz := (mem_filter.mp hr).2
    have hp0 : 0 < p.1 := by
      have : p.1*p.2 ≠ 0 := by rw [hpz]; exact hz.ne'
      exact Nat.pos_of_ne_zero (fun h => this (by simp [h]))
    apply Prod.ext hfirst
    apply Nat.eq_of_mul_eq_mul_left hp0
    calc
      p.1*p.2 = z := hpz
      _ = r.1*r.2 := hrz.symm
      _ = p.1*r.2 := by rw [hfirst]

-- The two fixed unit gates imply the ORIGINAL a,z coprimality at every
-- product, independently of whether its signed coefficient cancels.
theorem factorProducts_residue_coprime (A : ℕ) (a : ℤ) (T : Finset ℕ)
    {z : ℕ} (hz : z ∈ factorProducts A a T) : a.natAbs.Coprime z := by
  obtain ⟨p,hp,rfl⟩ := mem_image.mp hz
  obtain ⟨hp1,hp2⟩ := mem_product.mp hp
  have h1 := (mem_filter.mp hp1).2.2
  have h2 := (mem_filter.mp hp2).2.2
  exact (h1.mul_left h2).symm

theorem product_coprime_iff (q : ℕ) (p : ℕ × ℕ) :
    q.Coprime (p.1*p.2) ↔ q.Coprime p.1 ∧ q.Coprime p.2 :=
  Nat.coprime_mul_iff_right

-- The physical completed kernel's actual c,z gate defines this carrier.
def activeCZ (U : Finset Source) (Q : ℕ) : Finset (ℕ × ℕ) :=
  ((Ioc 0 Q) ×ˢ jointZCarrier U).filter (fun p => p.1.Coprime p.2)

theorem activeCZ_card_le
    {A : ℕ} {a : ℤ} {T : Finset ℕ} {H : ℕ} {Fset : Finset ℤ}
    {U : Finset Source} (hU : U ⊆ carrier A a T H Fset) (Q : ℕ) :
    (activeCZ U Q).card ≤ Q*(eligibleFactors A a T).card^2 := by
  calc
    _ ≤ ((Ioc 0 Q) ×ˢ jointZCarrier U).card := card_le_card (filter_subset _ _)
    _ = Q*(jointZCarrier U).card := by simp only [card_product,Nat.card_Ioc,Nat.sub_zero]
    _ ≤ _ := Nat.mul_le_mul_left Q (jointZCarrier_card_le hU)

theorem carrierLevelSeries_zero_of_not_coprime (U : Finset Source)
    (lambda : ℕ → ℂ) (omega : ℤ → ℂ) (M N : ℝ) (q z : ℕ) (a : ℤ)
    (hz : ¬q.Coprime z) : carrierLevelSeries U lambda omega M N q z a = 0 := by
  simp only [carrierLevelSeries,ActualCompletedPairYFibres20261026b.actualCommonScalar,
    if_neg hz,zero_mul]

theorem sum_cz_eq_sum_activeCZ (U : Finset Source)
    (lambda : ℕ → ℂ) (omega : ℤ → ℂ) (M N : ℝ) (Q : ℕ) (a : ℤ) :
    (∑ q ∈ Ioc 0 Q, ∑ z ∈ jointZCarrier U,
      carrierLevelSeries U lambda omega M N q z a) =
      ∑ p ∈ activeCZ U Q, carrierLevelSeries U lambda omega M N p.1 p.2 a := by
  rw [activeCZ,Finset.sum_filter,Finset.sum_product]
  apply Finset.sum_congr rfl
  intro q hq
  apply Finset.sum_congr rfl
  intro z hz
  by_cases h : q.Coprime z
  · simp only [if_pos h]
  · simp only [if_neg h,carrierLevelSeries_zero_of_not_coprime U lambda omega M N q z a h]

-- This is the precise elementary aggregate factor budget.  The RHS is
-- the original complex summand energy, with every collision intact.
theorem sum_cz_norm_sq_le_factor_budget
    {A : ℕ} {a : ℤ} {T : Finset ℕ} {H : ℕ} {Fset : Finset ℤ}
    {U : Finset Source} (hU : U ⊆ carrier A a T H Fset)
    (lambda : ℕ → ℂ) (omega : ℤ → ℂ) (M N : ℝ) (Q : ℕ) :
    ‖∑ q ∈ Ioc 0 Q, ∑ z ∈ jointZCarrier U,
      carrierLevelSeries U lambda omega M N q z a‖^2 ≤
      (Q*(eligibleFactors A a T).card^2 : ℕ) *
        ∑ p ∈ activeCZ U Q, ‖carrierLevelSeries U lambda omega M N p.1 p.2 a‖^2 := by
  rw [sum_cz_eq_sum_activeCZ]
  have hcs := complex_finset_cauchy_norm_sq (activeCZ U Q)
    (fun _ => (1 : ℂ)) (fun p => carrierLevelSeries U lambda omega M N p.1 p.2 a)
  simp only [one_mul,norm_one,one_pow,Finset.sum_const,nsmul_eq_mul,mul_one] at hcs
  exact hcs.trans (mul_le_mul_of_nonneg_right
    (by exact_mod_cast activeCZ_card_le hU Q)
    (Finset.sum_nonneg (fun _ _ => sq_nonneg _)))

-- The literal completedPiece gets the same factor budget.  H and F
-- still occur in its true signed summands, never in the Cauchy count.
theorem completedPiece_norm_sq_le_factor_budget
    (A : ℕ) (a : ℤ) (T : Finset ℕ) (H : ℕ)
    (lambda : ℕ → ℂ) (omega : ℤ → ℂ) (M N B C F : ℝ) :
    let U := carrier A a T H (Icc (Int.ceil (-F)) (Int.floor F))
    ‖completedPiece A a T H lambda omega M N B C F‖^2 ≤
      (Nat.floor (10*C)*(eligibleFactors A a T).card^2 : ℕ) *
        ∑ p ∈ activeCZ U (Nat.floor (10*C)),
          ‖carrierLevelSeries U lambda omega M N p.1 p.2 a‖^2 := by
  dsimp only
  rw [completedPiece_eq_sum_c_level_series]
  exact sum_cz_norm_sq_le_factor_budget (fun _ hs => hs) lambda omega M N _

end
end ImbalancedChen.Part3.ActualCompletedCZFactorBudget20261027
