import ImbalancedChen.Part3NativeCuspComplexLogJets
import Mathlib.Analysis.Calculus.ContDiff.Operations
import Mathlib.Analysis.SpecialFunctions.ExpDeriv
import Mathlib.MeasureTheory.Integral.DivergenceTheorem
import Mathlib.Tactic

-- SOURCE ONLY / UNCOMPILED / ZERO FORMAL CREDIT.
-- A first native Green boundary primitive for the actual allowed-row family.
-- Every finite approximation retains the actual cusp width and the factor 1/2.
-- The four edges are retained: finite row sets need not be periodic.
-- Infinite derivative interchange, limiting edge cancellation, continuation,
-- scattering and spectral completeness are not conclusions of this module.

namespace ImbalancedChen.Part3.NativeCuspFiniteRectangleGreen20261027

noncomputable section
open Set Filter Complex MeasureTheory Topology
open scoped UpperHalfPlane MatrixGroups BigOperators Interval
open ImbalancedChen.Part3.RealEisensteinSeedLaplacian
open ImbalancedChen.Part3.NativeAllCuspEisenstein20261026b
open ImbalancedChen.Part3.NativeCuspComplexLogJets20261026b
open ImbalancedChen.Part3.Gamma0GeneralCuspWidth20261025a

def positiveChart : Set (ℝ × ℝ) := {p | 0 < p.2}

theorem positiveChart_isOpen : IsOpen positiveChart :=
  isOpen_lt continuous_const continuous_snd

-- The indexing type is the original Gamma0(N) allowed-row subtype, with both signs.
def finiteJet (N : ℕ) (g : SL(2, ℤ))
    (j : ℝ → ℂ → ℝ → ℝ → ℝ → ℝ → ℂ)
    (A : Finset (AllowedPair N g)) (s : ℂ) (p : ℝ × ℝ) : ℂ :=
  (1 / 2 : ℂ) * ∑ v ∈ A,
    j (cuspWidth N g : ℝ) s (v.1.1 0 : ℝ) (v.1.1 1 : ℝ) p.1 p.2

def finiteValue (N : ℕ) (g : SL(2, ℤ)) := finiteJet N g kernel
def finiteX (N : ℕ) (g : SL(2, ℤ)) := finiteJet N g jetX
def finiteY (N : ℕ) (g : SL(2, ℤ)) := finiteJet N g jetY
def finiteXX (N : ℕ) (g : SL(2, ℤ)) := finiteJet N g jetXX
def finiteYY (N : ℕ) (g : SL(2, ℤ)) := finiteJet N g jetYY

-- Exact binding to the native normalized finite partial sum, with no free coefficients.
theorem finiteValue_eq_actual_partialSum (N : ℕ) (hN : 0 < N) (g : SL(2, ℤ))
    (A : Finset (AllowedPair N g)) (s : ℂ) (z : UpperHalfPlane) :
    finiteValue N g A s (z.re, z.im) =
      (1 / 2 : ℂ) * ∑ v ∈ A, normalizedSeed N g z v.1 s := by
  unfold finiteValue finiteJet
  congr 1
  apply Finset.sum_congr rfl
  intro v hv
  exact kernel_eq_normalizedSeed N hN g s z v.1

private theorem kernel_smooth (w : ℝ) (s : ℂ) (c d : ℝ)
    (hcd : c ≠ 0 ∨ d ≠ 0) :
    ContDiffOn ℝ 1 (fun p : ℝ × ℝ => kernel w s c d p.1 p.2) positiveChart := by
  have hQ : ContDiffOn ℝ 1 (fun p : ℝ × ℝ => Q c d p.1 p.2) positiveChart := by
    unfold Q
    fun_prop
  have hlogY : ContDiffOn ℝ 1 (fun p : ℝ × ℝ => Real.log p.2) positiveChart :=
    contDiffOn_snd.log (fun p hp => (ne_of_gt hp))
  have hlogQ := hQ.log (fun p hp => (Q_pos hcd hp (x := p.1)).ne')
  have hlogR : ContDiffOn ℝ 1 (fun p : ℝ × ℝ => logBase w c d p.1 p.2) positiveChart := by
    simpa only [logBase] using (hlogY.sub hlogQ).sub
      (contDiffOn_const (c := Real.log w))
  have hlogC := Complex.ofRealCLM.contDiff.comp_contDiffOn hlogR
  simpa only [kernel] using ((contDiffOn_const (c := s)).mul hlogC).cexp

private theorem jetX_smooth (w : ℝ) (s : ℂ) (c d : ℝ)
    (hcd : c ≠ 0 ∨ d ≠ 0) :
    ContDiffOn ℝ 1 (fun p : ℝ × ℝ => jetX w s c d p.1 p.2) positiveChart := by
  have hQ : ContDiffOn ℝ 1 (fun p : ℝ × ℝ => Q c d p.1 p.2) positiveChart := by
    unfold Q
    fun_prop
  have hQx : ContDiffOn ℝ 1 (fun p : ℝ × ℝ => Qx c d p.1) positiveChart := by
    unfold Qx
    fun_prop
  have hx : ContDiffOn ℝ 1 (fun p : ℝ × ℝ => logX c d p.1 p.2) positiveChart := by
    simpa only [logX] using hQx.neg.div hQ (fun p hp => (Q_pos hcd hp (x := p.1)).ne')
  have hxC := Complex.ofRealCLM.contDiff.comp_contDiffOn hx
  simpa only [jetX] using ((contDiffOn_const (c := s)).mul hxC).mul
    (kernel_smooth w s c d hcd)

private theorem jetY_smooth (w : ℝ) (s : ℂ) (c d : ℝ)
    (hcd : c ≠ 0 ∨ d ≠ 0) :
    ContDiffOn ℝ 1 (fun p : ℝ × ℝ => jetY w s c d p.1 p.2) positiveChart := by
  have hQ : ContDiffOn ℝ 1 (fun p : ℝ × ℝ => Q c d p.1 p.2) positiveChart := by
    unfold Q
    fun_prop
  have hQy : ContDiffOn ℝ 1 (fun p : ℝ × ℝ => Qy c p.2) positiveChart := by
    unfold Qy
    fun_prop
  have hyinv : ContDiffOn ℝ 1 (fun p : ℝ × ℝ => 1 / p.2) positiveChart :=
    (contDiffOn_const (c := (1 : ℝ))).div contDiffOn_snd (fun p hp => ne_of_gt hp)
  have hy : ContDiffOn ℝ 1 (fun p : ℝ × ℝ => logY c d p.1 p.2) positiveChart := by
    simpa only [logY] using hyinv.sub
      (hQy.div hQ (fun p hp => (Q_pos hcd hp (x := p.1)).ne'))
  have hyC := Complex.ofRealCLM.contDiff.comp_contDiffOn hy
  simpa only [jetY] using ((contDiffOn_const (c := s)).mul hyC).mul
    (kernel_smooth w s c d hcd)

theorem finiteValue_smooth (N : ℕ) (g : SL(2, ℤ))
    (A : Finset (AllowedPair N g)) (s : ℂ) :
    ContDiffOn ℝ 1 (finiteValue N g A s) positiveChart := by
  exact (contDiffOn_const (c := (1 / 2 : ℂ))).mul (ContDiffOn.sum (s := A) (fun v hv =>
    kernel_smooth _ _ _ _ (primitive_coordinates_nonzero v.1)))

theorem finiteX_smooth (N : ℕ) (g : SL(2, ℤ))
    (A : Finset (AllowedPair N g)) (s : ℂ) :
    ContDiffOn ℝ 1 (finiteX N g A s) positiveChart := by
  exact (contDiffOn_const (c := (1 / 2 : ℂ))).mul (ContDiffOn.sum (s := A) (fun v hv =>
    jetX_smooth _ _ _ _ (primitive_coordinates_nonzero v.1)))

theorem finiteY_smooth (N : ℕ) (g : SL(2, ℤ))
    (A : Finset (AllowedPair N g)) (s : ℂ) :
    ContDiffOn ℝ 1 (finiteY N g A s) positiveChart := by
  exact (contDiffOn_const (c := (1 / 2 : ℂ))).mul (ContDiffOn.sum (s := A) (fun v hv =>
    jetY_smooth _ _ _ _ (primitive_coordinates_nonzero v.1)))

theorem finiteValue_hasDerivAt_x (N : ℕ) (g : SL(2, ℤ))
    (A : Finset (AllowedPair N g)) (s : ℂ) (x y : ℝ) (hy : 0 < y) :
    HasDerivAt (fun t => finiteValue N g A s (t,y)) (finiteX N g A s (x,y)) x := by
  exact (HasDerivAt.fun_sum (u := A) (fun v hv => kernel_deriv_x _ _ _ _ _ _
    (primitive_coordinates_nonzero v.1) hy)).const_mul (1 / 2 : ℂ)

theorem finiteValue_hasDerivAt_y (N : ℕ) (g : SL(2, ℤ))
    (A : Finset (AllowedPair N g)) (s : ℂ) (x y : ℝ) (hy : 0 < y) :
    HasDerivAt (fun t => finiteValue N g A s (x,t)) (finiteY N g A s (x,y)) y := by
  exact (HasDerivAt.fun_sum (u := A) (fun v hv => kernel_deriv_y _ _ _ _ _ _
    (primitive_coordinates_nonzero v.1) hy)).const_mul (1 / 2 : ℂ)

theorem finiteX_hasDerivAt_x (N : ℕ) (g : SL(2, ℤ))
    (A : Finset (AllowedPair N g)) (s : ℂ) (x y : ℝ) (hy : 0 < y) :
    HasDerivAt (fun t => finiteX N g A s (t,y)) (finiteXX N g A s (x,y)) x := by
  exact (HasDerivAt.fun_sum (u := A) (fun v hv => jetX_deriv_x _ _ _ _ _ _
    (primitive_coordinates_nonzero v.1) hy)).const_mul (1 / 2 : ℂ)

theorem finiteY_hasDerivAt_y (N : ℕ) (g : SL(2, ℤ))
    (A : Finset (AllowedPair N g)) (s : ℂ) (x y : ℝ) (hy : 0 < y) :
    HasDerivAt (fun t => finiteY N g A s (x,t)) (finiteYY N g A s (x,y)) y := by
  exact (HasDerivAt.fun_sum (u := A) (fun v hv => jetY_deriv_y _ _ _ _ _ _
    (primitive_coordinates_nonzero v.1) hy)).const_mul (1 / 2 : ℂ)

-- The finite eigenrelation is proved from the frozen actual single-row relation.
theorem finiteValue_jet_maass (N : ℕ) (g : SL(2, ℤ))
    (A : Finset (AllowedPair N g)) (s : ℂ) (x y : ℝ) (hy : 0 < y) :
    -(y : ℂ)^2 * (finiteXX N g A s (x,y) + finiteYY N g A s (x,y)) =
      s * (1-s) * finiteValue N g A s (x,y) := by
  classical
  induction A using Finset.induction_on with
  | empty => simp [finiteValue, finiteXX, finiteYY, finiteJet]
  | @insert v A hv ih =>
    have hrow := kernel_jet_maass (cuspWidth N g : ℝ) s
      (v.1.1 0 : ℝ) (v.1.1 1 : ℝ) x y (primitive_coordinates_nonzero v.1) hy
    simp only [finiteValue, finiteXX, finiteYY, finiteJet, Finset.sum_insert hv] at ih ⊢
    linear_combination (1 / 2 : ℂ) * hrow + ih

def greenX (N : ℕ) (g h : SL(2, ℤ)) (A : Finset (AllowedPair N g))
    (B : Finset (AllowedPair N h)) (s u : ℂ) (p : ℝ × ℝ) : ℂ :=
  star (finiteValue N g A s p) * finiteX N h B u p -
    star (finiteX N g A s p) * finiteValue N h B u p

def greenY (N : ℕ) (g h : SL(2, ℤ)) (A : Finset (AllowedPair N g))
    (B : Finset (AllowedPair N h)) (s u : ℂ) (p : ℝ × ℝ) : ℂ :=
  star (finiteValue N g A s p) * finiteY N h B u p -
    star (finiteY N g A s p) * finiteValue N h B u p

theorem greenX_smooth (N : ℕ) (g h : SL(2, ℤ)) (A : Finset (AllowedPair N g))
    (B : Finset (AllowedPair N h)) (s u : ℂ) :
    ContDiffOn ℝ 1 (greenX N g h A B s u) positiveChart :=
  ((finiteValue_smooth N g A s).star.mul (finiteX_smooth N h B u)).sub
    ((finiteX_smooth N g A s).star.mul (finiteValue_smooth N h B u))

theorem greenY_smooth (N : ℕ) (g h : SL(2, ℤ)) (A : Finset (AllowedPair N g))
    (B : Finset (AllowedPair N h)) (s u : ℂ) :
    ContDiffOn ℝ 1 (greenY N g h A B s u) positiveChart :=
  ((finiteValue_smooth N g A s).star.mul (finiteY_smooth N h B u)).sub
    ((finiteY_smooth N g A s).star.mul (finiteValue_smooth N h B u))

theorem greenX_hasDerivAt_x (N : ℕ) (g h : SL(2, ℤ)) (A : Finset (AllowedPair N g))
    (B : Finset (AllowedPair N h)) (s u : ℂ) (x y : ℝ) (hy : 0 < y) :
    HasDerivAt (fun t => greenX N g h A B s u (t,y))
      (star (finiteValue N g A s (x,y)) * finiteXX N h B u (x,y) -
        star (finiteXX N g A s (x,y)) * finiteValue N h B u (x,y)) x := by
  convert (((finiteValue_hasDerivAt_x N g A s x y hy).star.mul
    (finiteX_hasDerivAt_x N h B u x y hy)).sub
      ((finiteX_hasDerivAt_x N g A s x y hy).star.mul
        (finiteValue_hasDerivAt_x N h B u x y hy))) using 1 <;> simp only [greenX] <;> ring

theorem greenY_hasDerivAt_y (N : ℕ) (g h : SL(2, ℤ)) (A : Finset (AllowedPair N g))
    (B : Finset (AllowedPair N h)) (s u : ℂ) (x y : ℝ) (hy : 0 < y) :
    HasDerivAt (fun t => greenY N g h A B s u (x,t))
      (star (finiteValue N g A s (x,y)) * finiteYY N h B u (x,y) -
        star (finiteYY N g A s (x,y)) * finiteValue N h B u (x,y)) y := by
  convert (((finiteValue_hasDerivAt_y N g A s x y hy).star.mul
    (finiteY_hasDerivAt_y N h B u x y hy)).sub
      ((finiteY_hasDerivAt_y N g A s x y hy).star.mul
        (finiteValue_hasDerivAt_y N h B u x y hy))) using 1 <;> simp only [greenY] <;> ring

private theorem slice_x {F : ℝ × ℝ → ℂ} {x y : ℝ} (hF : DifferentiableAt ℝ F (x,y)) :
    deriv (fun t : ℝ => F (t,y)) x = fderiv ℝ F (x,y) (1,0) :=
  (hF.hasFDerivAt.comp_hasDerivAt x
    ((hasDerivAt_id x).prodMk (hasDerivAt_const x y))).deriv

private theorem slice_y {F : ℝ × ℝ → ℂ} {x y : ℝ} (hF : DifferentiableAt ℝ F (x,y)) :
    deriv (fun t : ℝ => F (x,t)) y = fderiv ℝ F (x,y) (0,1) :=
  (hF.hasFDerivAt.comp_hasDerivAt y
    ((hasDerivAt_const y x).prodMk (hasDerivAt_id y))).deriv

-- No PDE or Green premise is supplied by a caller.
theorem green_divergence (N : ℕ) (g h : SL(2, ℤ)) (A : Finset (AllowedPair N g))
    (B : Finset (AllowedPair N h)) (s u : ℂ) (x y : ℝ) (hy : 0 < y) :
    fderiv ℝ (greenX N g h A B s u) (x,y) (1,0) +
      fderiv ℝ (greenY N g h A B s u) (x,y) (0,1) =
        (star (s*(1-s)) - u*(1-u)) *
          (star (finiteValue N g A s (x,y)) * finiteValue N h B u (x,y) / (y : ℂ)^2) := by
  have hx := ((greenX_smooth N g h A B s u) (x,y) hy).contDiffAt
    (positiveChart_isOpen.mem_nhds hy)
  have hv := ((greenY_smooth N g h A B s u) (x,y) hy).contDiffAt
    (positiveChart_isOpen.mem_nhds hy)
  rw [← slice_x (hx.differentiableAt (by norm_num)),
    ← slice_y (hv.differentiableAt (by norm_num)),
    (greenX_hasDerivAt_x N g h A B s u x y hy).deriv,
    (greenY_hasDerivAt_y N g h A B s u x y hy).deriv]
  have hfs := congrArg star (finiteValue_jet_maass N g A s x y hy)
  simp only [star_neg, star_mul, star_add, star_pow] at hfs
  have hyStar : star (y : ℂ) = (y : ℂ) := by simp
  rw [hyStar] at hfs
  have hgu := finiteValue_jet_maass N h B u x y hy
  rw [← mul_div_assoc]
  apply (eq_div_iff (pow_ne_zero 2 (Complex.ofReal_ne_zero.mpr hy.ne'))).mpr
  linear_combination finiteValue N h B u (x,y) * hfs -
    star (finiteValue N g A s (x,y)) * hgu

def rectanglePairing (N : ℕ) (g h : SL(2, ℤ)) (A : Finset (AllowedPair N g))
    (B : Finset (AllowedPair N h)) (s u : ℂ) (a b Y T : ℝ) : ℂ :=
  ∫ x in a..b, ∫ y in Y..T,
    star (finiteValue N g A s (x,y)) * finiteValue N h B u (x,y) / (y : ℂ)^2

-- Exact four-edge native Green identity. In particular neither vertical edge is discarded.
theorem finite_native_rectangle_green (N : ℕ) (g h : SL(2, ℤ))
    (A : Finset (AllowedPair N g)) (B : Finset (AllowedPair N h)) (s u : ℂ)
    (a b Y T : ℝ) (hY : 0 < Y) (hYT : Y ≤ T) :
    (star (s*(1-s)) - u*(1-u)) * rectanglePairing N g h A B s u a b Y T =
      (((∫ x in a..b, greenY N g h A B s u (x,T)) -
          ∫ x in a..b, greenY N g h A B s u (x,Y)) +
        ∫ y in Y..T, greenX N g h A B s u (b,y)) -
          ∫ y in Y..T, greenX N g h A B s u (a,y) := by
  let Jx := greenX N g h A B s u
  let Jy := greenY N g h A B s u
  let R : Set (ℝ × ℝ) := uIcc a b ×ˢ uIcc Y T
  have hR : R ⊆ positiveChart := by
    intro p hp
    have hpY : Y ≤ p.2 := (show p.2 ∈ Icc Y T by simpa only [uIcc_of_le hYT] using hp.2).1
    exact hY.trans_le hpY
  have hx : ContDiffOn ℝ 1 Jx positiveChart := greenX_smooth N g h A B s u
  have hy : ContDiffOn ℝ 1 Jy positiveChart := greenY_smooth N g h A B s u
  have hdiv : ContinuousOn
      (fun p : ℝ × ℝ => fderiv ℝ Jx p (1,0) + fderiv ℝ Jy p (0,1)) positiveChart :=
    ((hx.continuousOn_fderiv_of_isOpen positiveChart_isOpen (by norm_num)).clm_apply
      continuousOn_const).add
        ((hy.continuousOn_fderiv_of_isOpen positiveChart_isOpen (by norm_num)).clm_apply
          continuousOn_const)
  have hi : IntegrableOn
      (fun p : ℝ × ℝ => fderiv ℝ Jx p (1,0) + fderiv ℝ Jy p (0,1)) R :=
    (hdiv.mono hR).integrableOn_compact (isCompact_uIcc.prod isCompact_uIcc)
  have hdf : ∀ p ∈ Ioo (min a b) (max a b) ×ˢ Ioo (min Y T) (max Y T),
      HasFDerivAt Jx (fderiv ℝ Jx p) p := by
    intro p hp
    have hp0 : p ∈ positiveChart := hY.trans (by simpa only [min_eq_left hYT] using hp.2.1)
    exact (((hx p hp0).contDiffAt (positiveChart_isOpen.mem_nhds hp0)).differentiableAt
      (by norm_num)).hasFDerivAt
  have hdg : ∀ p ∈ Ioo (min a b) (max a b) ×ˢ Ioo (min Y T) (max Y T),
      HasFDerivAt Jy (fderiv ℝ Jy p) p := by
    intro p hp
    have hp0 : p ∈ positiveChart := hY.trans (by simpa only [min_eq_left hYT] using hp.2.1)
    exact (((hy p hp0).contDiffAt (positiveChart_isOpen.mem_nhds hp0)).differentiableAt
      (by norm_num)).hasFDerivAt
  have hstokes := integral2_divergence_prod_of_hasFDerivAt Jx Jy (fderiv ℝ Jx) (fderiv ℝ Jy)
    a Y b T (hx.continuousOn.mono hR) (hy.continuousOn.mono hR) hdf hdg hi
  have hmass :
      (∫ x in a..b, ∫ y in Y..T,
        fderiv ℝ Jx (x,y) (1,0) + fderiv ℝ Jy (x,y) (0,1)) =
      (star (s*(1-s)) - u*(1-u)) * rectanglePairing N g h A B s u a b Y T := by
    calc
      _ = ∫ x in a..b, ∫ y in Y..T,
          (star (s*(1-s)) - u*(1-u)) *
            (star (finiteValue N g A s (x,y)) * finiteValue N h B u (x,y) / (y : ℂ)^2) := by
        apply intervalIntegral.integral_congr
        intro x hxR
        apply intervalIntegral.integral_congr
        intro y hyR
        have hy0 : 0 < y := hY.trans_le (by simpa only [min_eq_left hYT] using hyR.1)
        exact green_divergence N g h A B s u x y hy0
      _ = _ := by
        simp_rw [intervalIntegral.integral_const_mul]
        rfl
  rw [hmass] at hstokes
  exact hstokes

end
end ImbalancedChen.Part3.NativeCuspFiniteRectangleGreen20261027
