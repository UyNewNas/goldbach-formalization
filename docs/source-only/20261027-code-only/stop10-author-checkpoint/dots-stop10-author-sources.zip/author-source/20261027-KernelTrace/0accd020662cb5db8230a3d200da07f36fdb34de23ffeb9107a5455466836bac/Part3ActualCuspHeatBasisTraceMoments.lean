import ImbalancedChen.Part3ActualCuspHeatNuclearSeries

-- SOURCE ONLY / UNCOMPILED_ZERO_CREDIT / READY_FALSE.
-- Literal actual-operator diagonal sums and all positive ONB image moments.
-- The trace here is explicitly the diagonal sum in the constructed genuine
-- cuspidal ONB. Basis independence and an abstract infinite trace/Schatten
-- ideal API are separate statements and are not silently assumed.
namespace ImbalancedChen.Part3.ActualCuspHeatBasisTraceMoments20261027
noncomputable section
open ActualFullCuspResolvent20261026b ActualFullCuspEigenbasis20261026b
open ActualCuspEigenbasisNativeLabels20261026b
open ActualAllFrameHeatResolventReduction20261026b
open ActualCuspHeatNativeDiagonal20261027 ActualCuspHeatNuclearSeries20261027

theorem actualFullCuspHeat_diagonal_summable (N : ℕ) [NeZero N] (hN : 0 < N)
    {t : ℝ} (ht : 0 < t) :
    Summable (fun i : actualCuspBasisIndex N hN =>
      inner ℂ (actualCuspHilbertBasis N hN i)
        (actualFullCuspHeat N hN t (actualCuspHilbertBasis N hN i))) := by
  apply Summable.of_norm
  have h := actualCuspHeatWeight_summable N hN ht
  convert h using 1
  funext i
  rw [actualFullCuspHeat_basis_diagonal N hN ht.le i,
    Complex.norm_real, Real.norm_eq_abs, abs_of_pos (Real.exp_pos _)]

def actualCuspBasisHeatTrace (N : ℕ) [NeZero N] (hN : 0 < N) (t : ℝ) : ℝ :=
  ∑' i : actualCuspBasisIndex N hN,
    (inner ℂ (actualCuspHilbertBasis N hN i)
      (actualFullCuspHeat N hN t (actualCuspHilbertBasis N hN i))).re

theorem actualCuspBasisHeatTrace_eq_native_sum (N : ℕ) [NeZero N] (hN : 0 < N)
    {t : ℝ} (ht : 0 ≤ t) :
    actualCuspBasisHeatTrace N hN t =
      ∑' i : actualCuspBasisIndex N hN,
        Real.exp (-t * actualCuspNativeEigenvalue N hN i) := by
  apply tsum_congr
  intro i
  rw [actualFullCuspHeat_basis_diagonal N hN ht i, Complex.ofReal_re]

theorem actualCuspBasisHeatTrace_hasSum (N : ℕ) [NeZero N] (hN : 0 < N)
    {t : ℝ} (ht : 0 < t) :
    HasSum (fun i : actualCuspBasisIndex N hN =>
      Real.exp (-t * actualCuspNativeEigenvalue N hN i))
        (actualCuspBasisHeatTrace N hN t) := by
  rw [actualCuspBasisHeatTrace_eq_native_sum N hN ht.le]
  exact (actualCuspHeatWeight_summable N hN ht).hasSum

theorem actualCuspBasisHeatTrace_nonneg (N : ℕ) [NeZero N] (hN : 0 < N)
    {t : ℝ} (ht : 0 ≤ t) : 0 ≤ actualCuspBasisHeatTrace N hN t := by
  rw [actualCuspBasisHeatTrace_eq_native_sum N hN ht]
  exact tsum_nonneg (fun i => (Real.exp_pos _).le)

-- Every positive real image-norm moment is summable. On this constructed
-- positive diagonal operator these are the concrete spectral moment data
-- needed by any later Schatten-ideal interface.
theorem actualFullCuspHeat_basis_norm_rpow_summable (N : ℕ) [NeZero N] (hN : 0 < N)
    {t p : ℝ} (ht : 0 < t) (hp : 0 < p) :
    Summable (fun i : actualCuspBasisIndex N hN =>
      ‖actualFullCuspHeat N hN t (actualCuspHilbertBasis N hN i)‖ ^ p) := by
  convert actualCuspHeatWeight_summable N hN (mul_pos hp ht) using 1
  funext i
  rw [actualFullCuspHeat_basis_norm N hN ht.le i, ← Real.exp_mul]
  congr 1
  ring

theorem actualFullCuspHeat_basis_norm_rpow_total (N : ℕ) [NeZero N] (hN : 0 < N)
    {t p : ℝ} (ht : 0 ≤ t) (hp : 0 ≤ p) :
    (∑' i : actualCuspBasisIndex N hN,
      ‖actualFullCuspHeat N hN t (actualCuspHilbertBasis N hN i)‖ ^ p) =
        actualCuspBasisHeatTrace N hN (p * t) := by
  rw [actualCuspBasisHeatTrace_eq_native_sum N hN (mul_nonneg hp ht)]
  apply tsum_congr
  intro i
  rw [actualFullCuspHeat_basis_norm N hN ht i, ← Real.exp_mul]
  congr 1
  ring

theorem actualFullCuspHeat_basis_norm_sq_summable (N : ℕ) [NeZero N] (hN : 0 < N)
    {t : ℝ} (ht : 0 < t) :
    Summable (fun i : actualCuspBasisIndex N hN =>
      ‖actualFullCuspHeat N hN t (actualCuspHilbertBasis N hN i)‖ ^ 2) := by
  convert actualCuspHeatWeight_summable N hN (mul_pos (by norm_num : (0 : ℝ) < 2) ht)
    using 1
  funext i
  exact actualFullCuspHeat_basis_norm_sq N hN ht.le i

-- Literal Hilbert-Schmidt squared basis sum equals the actual diagonal
-- trace at doubled time, without assuming a trace or kernel identity.
theorem actualFullCuspHeat_basis_hilbertSchmidt_square (N : ℕ) [NeZero N] (hN : 0 < N)
    {t : ℝ} (ht : 0 ≤ t) :
    (∑' i : actualCuspBasisIndex N hN,
      ‖actualFullCuspHeat N hN t (actualCuspHilbertBasis N hN i)‖ ^ 2) =
        actualCuspBasisHeatTrace N hN (2 * t) := by
  rw [actualCuspBasisHeatTrace_eq_native_sum N hN (mul_nonneg (by norm_num) ht)]
  apply tsum_congr
  exact actualFullCuspHeat_basis_norm_sq N hN ht

end
end ImbalancedChen.Part3.ActualCuspHeatBasisTraceMoments20261027
