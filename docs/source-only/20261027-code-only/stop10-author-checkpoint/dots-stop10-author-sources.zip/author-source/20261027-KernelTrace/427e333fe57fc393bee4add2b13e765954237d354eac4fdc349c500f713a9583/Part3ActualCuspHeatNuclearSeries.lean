import ImbalancedChen.Part3ActualCuspHeatNativeDiagonal
import ImbalancedChen.Part3ActualCuspHeatSmallTimeWeights
import Mathlib.Analysis.InnerProductSpace.LinearMap
import Mathlib.Analysis.Normed.Operator.Bilinear

-- SOURCE ONLY / UNCOMPILED_ZERO_CREDIT / READY_FALSE.
-- An actual operator-norm absolutely convergent rank-one series for the
-- ORIGINAL native full-cusp heat. Coefficients and ONB are constructed
-- suppliers, and summability comes from the genuine multiplicity count.
-- No nuclear representation, trace class or Schatten predicate is assumed.
namespace ImbalancedChen.Part3.ActualCuspHeatNuclearSeries20261027
noncomputable section
open Set InnerProductSpace
open ActualFullCuspResolvent20261026b ActualFullCuspEigenbasis20261026b
open ActualCuspEigenbasisNativeLabels20261026b
open ActualAllFrameHeatResolventReduction20261026b
open ActualCuspHeatNativeDiagonal20261027 ActualCuspHeatSmallTimeWeights20261027

theorem actualCuspHeatWeight_summable (N : ℕ) [NeZero N] (hN : 0 < N)
    {t : ℝ} (ht : 0 < t) :
    Summable (fun i : actualCuspBasisIndex N hN =>
      Real.exp (-t * actualCuspNativeEigenvalue N hN i)) := by
  simpa only [pow_zero, mul_one] using
    actualCuspHeatPolynomialWeight_summable N hN ht 0

def actualCuspHeatRankOne (N : ℕ) [NeZero N] (hN : 0 < N) (t : ℝ)
    (i : actualCuspBasisIndex N hN) :
    ActualFullCuspL2 N hN →L[ℂ] ActualFullCuspL2 N hN :=
  (Real.exp (-t * actualCuspNativeEigenvalue N hN i) : ℂ) •
    rankOne ℂ (actualCuspHilbertBasis N hN i) (actualCuspHilbertBasis N hN i)

theorem actualCuspHeatRankOne_norm (N : ℕ) [NeZero N] (hN : 0 < N)
    (t : ℝ) (i : actualCuspBasisIndex N hN) :
    ‖actualCuspHeatRankOne N hN t i‖ =
      Real.exp (-t * actualCuspNativeEigenvalue N hN i) := by
  simp only [actualCuspHeatRankOne, norm_smul, norm_rankOne,
    actualCuspHilbertBasis_norm N hN i, mul_one,
    Complex.norm_real, Real.norm_eq_abs, abs_of_pos (Real.exp_pos _)]

theorem actualCuspHeatRankOne_norm_summable (N : ℕ) [NeZero N] (hN : 0 < N)
    {t : ℝ} (ht : 0 < t) :
    Summable (fun i : actualCuspBasisIndex N hN => ‖actualCuspHeatRankOne N hN t i‖) := by
  simpa only [actualCuspHeatRankOne_norm] using actualCuspHeatWeight_summable N hN ht

theorem actualCuspHeatRankOne_summable (N : ℕ) [NeZero N] (hN : 0 < N)
    {t : ℝ} (ht : 0 < t) :
    Summable (actualCuspHeatRankOne N hN t) :=
  (actualCuspHeatRankOne_norm_summable N hN ht).of_norm

-- The operator-valued sum is identified on the entire genuine cusp space
-- by its dense ONB span. Thus this is stronger than a formal scalar sum.
theorem actualFullCuspHeat_eq_tsum_rankOne (N : ℕ) [NeZero N] (hN : 0 < N)
    {t : ℝ} (ht : 0 < t) :
    actualFullCuspHeat N hN t = ∑' i, actualCuspHeatRankOne N hN t i := by
  classical
  apply ContinuousLinearMap.ext_on
    (Submodule.dense_iff_topologicalClosure_eq_top.mpr
      (actualCuspHilbertBasis N hN).dense_span)
  rintro _ ⟨j, rfl⟩
  rw [actualFullCuspHeat_basis_apply N hN ht.le j]
  have hEval := (actualCuspHeatRankOne_summable N hN ht).hasSum.mapL
    (ContinuousLinearMap.apply ℂ (ActualFullCuspL2 N hN)
      (actualCuspHilbertBasis N hN j))
  have hsingle : HasSum
      (fun i : actualCuspBasisIndex N hN =>
        actualCuspHeatRankOne N hN t i (actualCuspHilbertBasis N hN j))
      ((Real.exp (-t * actualCuspNativeEigenvalue N hN j) : ℂ) •
        actualCuspHilbertBasis N hN j) := by
    convert hasSum_ite_eq j
      ((Real.exp (-t * actualCuspNativeEigenvalue N hN j) : ℂ) •
        actualCuspHilbertBasis N hN j) using 1
    funext i
    by_cases hij : i = j
    · subst i
      simp [actualCuspHeatRankOne, rankOne_apply, inner_self_eq_norm_sq_to_K,
        actualCuspHilbertBasis_norm]
    · simp [actualCuspHeatRankOne, rankOne_apply,
        (actualCuspHilbertBasis N hN).orthonormal.inner_eq_zero hij, hij]
  exact hsingle.unique hEval

theorem actualFullCuspHeat_hasSum_rankOne (N : ℕ) [NeZero N] (hN : 0 < N)
    {t : ℝ} (ht : 0 < t) :
    HasSum (actualCuspHeatRankOne N hN t) (actualFullCuspHeat N hN t) := by
  rw [actualFullCuspHeat_eq_tsum_rankOne N hN ht]
  exact (actualCuspHeatRankOne_summable N hN ht).hasSum

-- Exact absolute rank-one norm mass, with multiplicities.
theorem actualCuspHeatRankOne_total_norm (N : ℕ) [NeZero N] (hN : 0 < N) (t : ℝ) :
    (∑' i : actualCuspBasisIndex N hN, ‖actualCuspHeatRankOne N hN t i‖) =
      ∑' i : actualCuspBasisIndex N hN,
        Real.exp (-t * actualCuspNativeEigenvalue N hN i) := by
  apply tsum_congr
  exact actualCuspHeatRankOne_norm N hN t

end
end ImbalancedChen.Part3.ActualCuspHeatNuclearSeries20261027
