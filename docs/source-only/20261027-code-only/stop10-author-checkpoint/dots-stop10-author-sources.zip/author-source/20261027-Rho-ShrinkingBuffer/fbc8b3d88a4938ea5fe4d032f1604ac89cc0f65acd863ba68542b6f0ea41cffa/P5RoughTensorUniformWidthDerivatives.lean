import ImbalancedChen.P5RoughLogGridSmoothTensorPartition
import Mathlib.Analysis.Calculus.ContDiff.Bounds

-- SOURCE ONLY / UNCOMPILED_ZERO_CREDIT.
-- The old compactness bound fixes mesh and width before selecting C.
-- This supplier instead fixes rank and derivative order first. Its C
-- works for EVERY mesh, label, endpoints, and width in (0,1].
-- The deliberately coarse exponent rank * order is sufficient for a
-- logarithmic schedule. No arithmetic distribution estimate is assumed.
namespace ImbalancedChen.P5Z.RoughTensorUniformWidthDerivatives
noncomputable section
open Classical
open scoped BigOperators
open RoughLogGridSmoothPartition

def leibnizCost (r k : ℕ) : ℝ :=
  ∑ p ∈ (Finset.univ : Finset (Fin r)).sym k,
    ((p : Multiset (Fin r)).countPerms : ℝ)

theorem leibnizCost_nonneg (r k : ℕ) : 0 ≤ leibnizCost r k := by
  exact Finset.sum_nonneg (fun p hp => Nat.cast_nonneg _)

-- Finite derivative-order selection is independent of endpoints and mesh.
theorem exists_all_lower_label_budget (k : ℕ) :
    ∃ B : ℝ, 0 ≤ B ∧ ∀ (m : ℕ), m ≤ k → ∀ (a b : ℝ) (n : ℕ)
      (δ : ℝ), 0 < δ → δ ≤ 1 → ∀ (j : Fin (n + 1)) (x : ℝ),
        ‖iteratedFDeriv ℝ m (label a b n δ j) x‖ ≤ B / δ ^ k := by
  choose C hC hb using fun m : Fin (k + 1) => exists_label_frechet_budget m.val
  let B : ℝ := ∑ m : Fin (k + 1), C m
  have hC0 (m : Fin (k + 1)) : 0 ≤ C m := zero_le_one.trans (hC m)
  have hB0 : 0 ≤ B := Finset.sum_nonneg (fun m hm => hC0 m)
  refine ⟨B, hB0, ?_⟩
  intro m hm a b n δ hδ hδ1 j x
  let t : Fin (k + 1) := ⟨m, Nat.lt_succ_of_le hm⟩
  have hCB : C t ≤ B := Finset.single_le_sum (fun q hq => hC0 q) (Finset.mem_univ t)
  calc
    ‖iteratedFDeriv ℝ m (label a b n δ j) x‖ ≤ C t / δ ^ m := hb t a b n δ hδ j x
    _ ≤ B / δ ^ m := div_le_div_of_nonneg_right hCB (pow_nonneg hδ.le m)
    _ ≤ B / δ ^ k := div_le_div_of_nonneg_left hB0 (pow_pos hδ k)
      (pow_le_pow_of_le_one hδ.le hδ1 hm)

theorem coordinate_derivative_le {r : ℕ} (a b : ℝ) (n : ℕ) (δ : ℝ)
    (j : Labels r n) (i : Fin r) (m : ℕ) (v : Fin r → ℝ) :
    ‖iteratedFDeriv ℝ m (fun y : Fin r → ℝ => label a b n δ (j i) (y i)) v‖ ≤
      ‖iteratedFDeriv ℝ m (label a b n δ (j i)) (v i)‖ := by
  let P : (Fin r → ℝ) →L[ℝ] ℝ := ContinuousLinearMap.proj i
  have hP : ‖P‖ ≤ 1 := by
    apply ContinuousLinearMap.opNorm_le_bound _ zero_le_one
    intro y
    simpa only [P, ContinuousLinearMap.proj_apply, one_mul] using norm_le_pi_norm y i
  change ‖iteratedFDeriv ℝ m ((label a b n δ (j i)) ∘ P) v‖ ≤ _
  rw [P.iteratedFDeriv_comp_right (contDiff_label a b n δ (j i)) v (by simp)]
  have hn := (iteratedFDeriv ℝ m (label a b n δ (j i)) (P v)).norm_compContinuousLinearMap_le
    (fun _ : Fin m => P)
  have hnorm :
      ‖(iteratedFDeriv ℝ m (label a b n δ (j i)) (P v)).compContinuousLinearMap
          (fun _ : Fin m => P)‖ ≤
        ‖iteratedFDeriv ℝ m (label a b n δ (j i)) (P v)‖ * ‖P‖ ^ m := by
    simpa only [Finset.prod_const, Finset.card_univ, Fintype.card_fin] using hn
  exact hnorm.trans (mul_le_of_le_one_right (norm_nonneg _)
    (pow_le_one₀ (norm_nonneg _) hP))

-- This is a full operator norm estimate, including mixed directions.
-- In particular, neither n nor δ can be hidden in the existential C.
theorem exists_uniform_tensor_derivative_budget (r k : ℕ) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ (a b : ℝ) (n : ℕ) (δ : ℝ),
      0 < δ → δ ≤ 1 → ∀ (j : Labels r n) (v : Fin r → ℝ),
        ‖iteratedFDeriv ℝ k (tensor a b n δ j) v‖ ≤ C / δ ^ (k * r) := by
  obtain ⟨B, hB, hb⟩ := exists_all_lower_label_budget k
  refine ⟨leibnizCost r k * B ^ r,
    mul_nonneg (leibnizCost_nonneg r k) (pow_nonneg hB r), ?_⟩
  intro a b n δ hδ hδ1 j v
  let f : Fin r → (Fin r → ℝ) → ℝ := fun i y => label a b n δ (j i) (y i)
  have hf (i : Fin r) : ContDiff ℝ ∞ (f i) :=
    (contDiff_label a b n δ (j i)).comp (contDiff_apply ℝ ℝ i)
  have hfactor (p : Sym (Fin r) k) (i : Fin r) :
      ‖iteratedFDeriv ℝ ((p : Multiset (Fin r)).count i) (f i) v‖ ≤ B / δ ^ k := by
    have hm : (p : Multiset (Fin r)).count i ≤ k := by
      simpa only [Sym.card_coe] using Multiset.count_le_card i (p : Multiset (Fin r))
    exact (coordinate_derivative_le a b n δ j i _ v).trans
      (hb _ hm a b n δ hδ hδ1 (j i) (v i))
  have hproduct (p : Sym (Fin r) k) :
      (∏ i : Fin r, ‖iteratedFDeriv ℝ ((p : Multiset (Fin r)).count i) (f i) v‖) ≤
        (B / δ ^ k) ^ r := by
    calc
      _ ≤ ∏ _i : Fin r, B / δ ^ k :=
        Finset.prod_le_prod (fun i hi => norm_nonneg _) (fun i hi => hfactor p i)
      _ = (B / δ ^ k) ^ r := by simp
  have hmain := norm_iteratedFDeriv_prod_le (𝕜 := ℝ)
    (u := (Finset.univ : Finset (Fin r))) (f := f)
    (fun i hi => hf i) (x := v) (n := k) (by simp : (k : ℕ∞ω) ≤ ∞)
  change ‖iteratedFDeriv ℝ k (fun y => ∏ i : Fin r, f i y) v‖ ≤ _
  apply hmain.trans
  calc
    _ ≤ ∑ p ∈ (Finset.univ : Finset (Fin r)).sym k,
        ((p : Multiset (Fin r)).countPerms : ℝ) * (B / δ ^ k) ^ r := by
      apply Finset.sum_le_sum
      intro p hp
      exact mul_le_mul_of_nonneg_left (hproduct p) (Nat.cast_nonneg _)
    _ = leibnizCost r k * (B / δ ^ k) ^ r := by rw [← Finset.sum_mul]; rfl
    _ = (leibnizCost r k * B ^ r) / δ ^ (k * r) := by
      rw [div_pow, ← pow_mul]
      ring

end
end ImbalancedChen.P5Z.RoughTensorUniformWidthDerivatives
