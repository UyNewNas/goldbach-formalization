import ImbalancedChen.Part3SmoothZeroHeightSeedProfiles
import Mathlib.Analysis.Distribution.SchwartzSpace.Fourier
import Mathlib.MeasureTheory.Measure.Haar.NormedSpace

-- SOURCE ONLY / UNCOMPILED / ZERO FORMAL CREDIT.
-- The input is the original smooth compact positive-height seed. No inversion
-- or Fourier integrability premise is assumed. Fourier normalization is 2*pi.
namespace ImbalancedChen.Part3.CompactHeightMellinInversion20261027
noncomputable section
open Set MeasureTheory Complex
open scoped FourierTransform SchwartzMap
open SmoothZeroHeightSeedProfiles20261026b

def tiltedLogProfile (s : SmoothHeightSeed) (σ u : ℝ) : ℂ :=
  Complex.exp (-(σ : ℂ) * (u : ℂ)) * s.toFun (Real.exp u)

theorem tiltedLogProfile_compact (s : SmoothHeightSeed) (σ : ℝ) :
    HasCompactSupport (tiltedLogProfile s σ) := by
  have hlog : ContinuousOn Real.log (tsupport s.toFun) := by
    intro y hy
    exact (Real.continuousAt_log (ne_of_gt (s.positive hy))).continuousWithinAt
  apply HasCompactSupport.of_support_subset_isCompact (s.compact.image_of_continuousOn hlog)
  intro u hu
  refine ⟨Real.exp u, subset_tsupport _ ?_, Real.log_exp u⟩
  intro hz
  exact hu (by simp [tiltedLogProfile, hz])

theorem tiltedLogProfile_cinfty (s : SmoothHeightSeed) (σ : ℝ) :
    ContDiff ℝ ∞ (tiltedLogProfile s σ) := by
  unfold tiltedLogProfile
  exact ((contDiff_const.mul Complex.ofRealCLM.contDiff).cexp).mul
    (s.cinfty.comp Real.contDiff_exp)

def logSchwartz (s : SmoothHeightSeed) (σ : ℝ) : 𝓢(ℝ, ℂ) :=
  (tiltedLogProfile_compact s σ).toSchwartzMap (tiltedLogProfile_cinfty s σ)

@[simp] theorem logSchwartz_apply (s : SmoothHeightSeed) (σ u : ℝ) :
    logSchwartz s σ u = tiltedLogProfile s σ u := rfl

-- This coefficient is the negative-sign Mellin transform in logarithmic
-- coordinates, with angular frequency 2*pi*ξ.
def mellinFrequency (s : SmoothHeightSeed) (σ ξ : ℝ) : ℂ :=
  (𝓕 (logSchwartz s σ) : 𝓢(ℝ, ℂ)) ξ

theorem mellinFrequency_integrable (s : SmoothHeightSeed) (σ : ℝ) :
    Integrable (mellinFrequency s σ) :=
  (𝓕 (logSchwartz s σ) : 𝓢(ℝ, ℂ)).integrable

theorem mellinFrequency_continuous (s : SmoothHeightSeed) (σ : ℝ) :
    Continuous (mellinFrequency s σ) :=
  (𝓕 (logSchwartz s σ) : 𝓢(ℝ, ℂ)).continuous

theorem mellinFrequency_literal (s : SmoothHeightSeed) (σ ξ : ℝ) :
    mellinFrequency s σ ξ = ∫ u : ℝ,
      Complex.exp (-((σ : ℂ) + (2 * Real.pi * ξ : ℝ) * Complex.I) * (u : ℂ)) *
        s.toFun (Real.exp u) := by
  rw [mellinFrequency, SchwartzMap.fourier_coe, Real.fourier_eq']
  apply integral_congr_ae
  filter_upwards [] with u
  simp only [RCLike.inner_apply,
    conj_trivial, smul_eq_mul, logSchwartz_apply, tiltedLogProfile]
  rw [← mul_assoc, ← Complex.exp_add]
  congr 2
  push_cast
  ring

theorem compact_height_mellin_inversion_frequency (s : SmoothHeightSeed) (σ : ℝ)
    {y : ℝ} (hy : 0 < y) :
    s.toFun y = Complex.exp ((σ : ℂ) * (Real.log y : ℂ)) *
      ∫ ξ : ℝ, Complex.exp ((2 * Real.pi * ξ * Real.log y : ℝ) * Complex.I) *
        mellinFrequency s σ ξ := by
  have hi := congrArg (fun f : 𝓢(ℝ, ℂ) => f (Real.log y))
    (fourierInv_fourier_eq (logSchwartz s σ))
  rw [SchwartzMap.fourierInv_coe, Real.fourierInv_eq'] at hi
  have heq : (∫ ξ : ℝ, Complex.exp ((2 * Real.pi * ξ * Real.log y : ℝ) * Complex.I) *
      mellinFrequency s σ ξ) = tiltedLogProfile s σ (Real.log y) := by
    simpa only [RCLike.inner_apply, conj_trivial, mul_assoc, mul_comm,
      mul_left_comm, smul_eq_mul, mellinFrequency,
      logSchwartz_apply] using hi
  rw [heq, tiltedLogProfile, Real.exp_log hy, ← mul_assoc, ← Complex.exp_add]
  simp

def mellinAngular (s : SmoothHeightSeed) (σ t : ℝ) : ℂ :=
  mellinFrequency s σ ((2 * Real.pi)⁻¹ * t)

theorem mellinAngular_integrable (s : SmoothHeightSeed) (σ : ℝ) :
    Integrable (mellinAngular s σ) := by
  exact (integrable_comp_mul_left_iff (mellinFrequency s σ)
    (inv_ne_zero (mul_ne_zero (by norm_num) Real.pi_ne_zero))).mpr
      (mellinFrequency_integrable s σ)

theorem compact_height_mellin_inversion (s : SmoothHeightSeed) (σ : ℝ)
    {y : ℝ} (hy : 0 < y) :
    s.toFun y = Complex.exp ((σ : ℂ) * (Real.log y : ℂ)) *
      ((2 * Real.pi)⁻¹ • ∫ t : ℝ,
        Complex.exp ((t * Real.log y : ℝ) * Complex.I) * mellinAngular s σ t) := by
  rw [compact_height_mellin_inversion_frequency s σ hy]
  congr 1
  have h := Measure.integral_comp_mul_left
    (fun t : ℝ => Complex.exp ((t * Real.log y : ℝ) * Complex.I) *
      mellinAngular s σ t) (2 * Real.pi)
  have hp : 0 < 2 * Real.pi := mul_pos (by norm_num) Real.pi_pos
  simpa only [mellinAngular, inv_mul_cancel_left₀ hp.ne',
    abs_of_pos (inv_pos.mpr hp), mul_assoc] using h

end
end ImbalancedChen.Part3.CompactHeightMellinInversion20261027
