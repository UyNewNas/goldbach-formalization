import ImbalancedChen.Part3ActualCuspFiniteKernelAction
import ImbalancedChen.Part3ActualCuspSmoothEigenprofileFamily
import ImbalancedChen.Part3GammaSmoothMultiplierPeriodization

-- SOURCE ONLY / UNCOMPILED_ZERO_CREDIT / TRANSITIVE DOTS API HOLD.
-- The SAME actual smooth family descends through the original orbit quotient.
-- Its finite kernel acts by the ORIGINAL Borel coefficients, almost everywhere.
-- No infinite integral interchange or new spectral operator is asserted.

namespace ImbalancedChen.Part3.ActualCuspSmoothFiniteKernelDescent20261027
noncomputable section
open Set Filter MeasureTheory
open Gamma0QuotientCellPushforward20261025a
open Gamma0FiniteMeasureCarrier20261024z
open Gamma0ActualSmoothQuotientCore20261025a ActualFullCuspResolvent20261026b
open ActualFullCuspEigenbasis20261026b ActualCuspEigenbasisNativeLabels20261026b
open GenericBoundedBorelCalculus20261025a ActualCuspBoundedBorelMultiplier20261026b
open ActualCuspFiniteKernelAction20261027 ActualCuspSmoothEigenprofileFamily20261026b
open GammaSmoothMultiplierPeriodization20261026a

def actualCuspQuotientSmoothProfile (N : ℕ) [NeZero N] (hN : 0 < N)
    (i : actualCuspBasisIndex N hN) : Gamma0OrbitSpace N → ℂ :=
  quotientMultiplier N (actualCuspSmoothProfile N hN i)
    (actualCuspSmoothProfile_spec N hN i).2.2.1

@[simp] theorem actualCuspQuotientSmoothProfile_projection
    (N : ℕ) [NeZero N] (hN : 0 < N) (i : actualCuspBasisIndex N hN)
    (z : UpperHalfPlane) :
    actualCuspQuotientSmoothProfile N hN i (orbitProjection N z) =
      actualCuspSmoothProfile N hN i z := rfl

theorem actualCuspQuotientSmoothProfile_measurable
    (N : ℕ) [NeZero N] (hN : 0 < N) (i : actualCuspBasisIndex N hN) :
    Measurable (actualCuspQuotientSmoothProfile N hN i) :=
  quotientMultiplier_measurable N _ _ (actualCuspSmoothProfile_spec N hN i).1

-- This descends the inherited full-H AE equality to the ACTUAL quotient
-- measure; no arbitrary quotient section or new representative is assumed.
theorem actualCuspQuotientSmoothProfile_ae
    (N : ℕ) [NeZero N] (hN : 0 < N) (i : actualCuspBasisIndex N hN) :
    actualCuspQuotientSmoothProfile N hN i =ᵐ[carrierPushforward N]
      (actualCuspHilbertBasis N hN i : QuotientL2 N) := by
  change ∀ᵐ q ∂Measure.map (orbitProjection N)
    ((volume : Measure UpperHalfPlane).restrict (gamma0Carrier N)),
    actualCuspQuotientSmoothProfile N hN i q =
      (actualCuspHilbertBasis N hN i : QuotientL2 N) q
  apply (ae_map_iff (orbitProjection_measurable N).aemeasurable
    (measurableSet_eq_fun (actualCuspQuotientSmoothProfile_measurable N hN i)
      (actualCuspHilbertBasis N hN i : QuotientL2 N).stronglyMeasurable.measurable)).2
  simpa only [actualCuspQuotientSmoothProfile_projection] using
    (ae_restrict_of_ae (actualCuspSmoothProfile_spec N hN i).2.1)

theorem actualCuspQuotientSmoothProfile_finite_ae
    (N : ℕ) [NeZero N] (hN : 0 < N) (s : Finset (actualCuspBasisIndex N hN)) :
    ∀ᵐ q ∂carrierPushforward N, ∀ i ∈ s,
      actualCuspQuotientSmoothProfile N hN i q =
        (actualCuspHilbertBasis N hN i : QuotientL2 N) q := by
  classical
  induction s using Finset.induction_on with
  | empty => simp
  | @insert i s hi ih =>
    filter_upwards [actualCuspQuotientSmoothProfile_ae N hN i, ih] with q hiq hsq
    intro j hj
    rcases Finset.mem_insert.mp hj with rfl | hjs
    · exact hiq
    · exact hsq j hjs

def actualCuspSmoothFiniteKernel (N : ℕ) [NeZero N] (hN : 0 < N)
    (h : BoundedBorelFunction ℝ) (s : Finset (actualCuspBasisIndex N hN))
    (q r : Gamma0OrbitSpace N) : ℂ :=
  ∑ i ∈ s, h (actualCuspNativeEigenvalue N hN i) *
    actualCuspQuotientSmoothProfile N hN i q *
    star (actualCuspQuotientSmoothProfile N hN i r)

-- The descended kernel is literally the original smooth profile products
-- after pullback at EVERY pair of upper-half-plane points.
theorem actualCuspSmoothFiniteKernel_projection
    (N : ℕ) [NeZero N] (hN : 0 < N) (h : BoundedBorelFunction ℝ)
    (s : Finset (actualCuspBasisIndex N hN)) (z w : UpperHalfPlane) :
    actualCuspSmoothFiniteKernel N hN h s (orbitProjection N z) (orbitProjection N w) =
      ∑ i ∈ s, h (actualCuspNativeEigenvalue N hN i) *
        actualCuspSmoothProfile N hN i z * star (actualCuspSmoothProfile N hN i w) := rfl

theorem actualCuspSmoothFiniteKernel_ae
    (N : ℕ) [NeZero N] (hN : 0 < N) (h : BoundedBorelFunction ℝ)
    (s : Finset (actualCuspBasisIndex N hN)) :
    ∀ᵐ q ∂carrierPushforward N, ∀ᵐ r ∂carrierPushforward N,
      actualCuspSmoothFiniteKernel N hN h s q r =
        actualCuspFiniteKernel N hN h s q r := by
  filter_upwards [actualCuspQuotientSmoothProfile_finite_ae N hN s] with q hq
  filter_upwards [actualCuspQuotientSmoothProfile_finite_ae N hN s] with r hr
  apply Finset.sum_congr rfl
  intro i hi
  rw [hq i hi, hr i hi]

theorem actualCuspSmoothFiniteKernel_integrable_ae
    (N : ℕ) [NeZero N] (hN : 0 < N) (h : BoundedBorelFunction ℝ)
    (s : Finset (actualCuspBasisIndex N hN)) (f : ActualFullCuspL2 N hN) :
    ∀ᵐ q ∂carrierPushforward N,
      Integrable (fun r => actualCuspSmoothFiniteKernel N hN h s q r *
        (f : QuotientL2 N) r) (carrierPushforward N) := by
  filter_upwards [actualCuspSmoothFiniteKernel_ae N hN h s] with q hq
  apply (actualCuspFiniteKernel_integrable N hN h s f q).congr
  filter_upwards [hq] with r hr
  rw [hr]

-- Exact finite smooth-kernel action with the ORIGINAL Borel multiplier.
-- Both output and input representatives are transported from the SAME
-- constructed basis. The remaining infinite-kernel step is still OPEN.
theorem actualCuspSmoothFiniteKernel_original_action_ae
    (N : ℕ) [NeZero N] (hN : 0 < N) (h : BoundedBorelFunction ℝ)
    (s : Finset (actualCuspBasisIndex N hN)) (f : ActualFullCuspL2 N hN) :
    ∀ᵐ q ∂carrierPushforward N,
      (∫ r, actualCuspSmoothFiniteKernel N hN h s q r *
        (f : QuotientL2 N) r ∂carrierPushforward N) =
        ∑ i ∈ s, (actualCuspHilbertBasis N hN).repr
          (actualCuspBoundedBorelMultiplier N hN h f) i *
          actualCuspQuotientSmoothProfile N hN i q := by
  filter_upwards [actualCuspSmoothFiniteKernel_ae N hN h s,
    actualCuspQuotientSmoothProfile_finite_ae N hN s] with q hk hq
  calc
    _ = ∫ r, actualCuspFiniteKernel N hN h s q r *
        (f : QuotientL2 N) r ∂carrierPushforward N := by
      apply integral_congr_ae
      filter_upwards [hk] with r hr
      rw [hr]
    _ = _ := actualCuspFiniteKernel_action N hN h s f q
    _ = _ := by
      apply Finset.sum_congr rfl
      intro i hi
      rw [hq i hi]

end
end ImbalancedChen.Part3.ActualCuspSmoothFiniteKernelDescent20261027
