import ImbalancedChen.Part3ActualCuspResolventJetAbsolute
import Mathlib.Analysis.Complex.Basic
import Mathlib.Topology.Algebra.InfiniteSum.Order

-- SOURCE ONLY / UNCOMPILED_ZERO_CREDIT / READY_FALSE.
-- Positivity for the actual positive shifted-resolvent power kernel.
-- These inverse-power multipliers are not rapid spectral test functions.
-- All inherited actual ONB, eigenregularity, counting and API holds persist.

namespace ImbalancedChen.Part3.ActualCuspResolventJetDiagonal20261027
noncomputable section
open Set
open ActualFullCuspEigenbasis20261026b ActualCuspEigenbasisNativeLabels20261026b
open ActualCuspSmoothEigenprofileFamily20261026b
open ActualCuspResolventJetAbsolute20261027
open PlanarWeakDifferentialMultiindex20261026b
open CanonicalTensorHyperbolicLaplacianForm20261024z

theorem actualCuspResolventJetTerm_star (N : ℕ) [NeZero N] (hN : 0 < N)
    (k l : ℕ) (α β : MultiIndex) (p q : ℝ × ℝ)
    (i : actualCuspBasisIndex N hN) :
    star (actualCuspResolventJetTerm N hN k l α β p q i) =
      actualCuspResolventJetTerm N hN l k β α q p i := by
  simp only [actualCuspResolventJetTerm, star_smul, star_trivial, star_mul_star,
    Nat.add_comm k l]

-- Conjugate symmetry swaps both points, both jets and their order budgets.
theorem actualCuspResolventJetKernel_star (N : ℕ) [NeZero N] (hN : 0 < N)
    (k l : ℕ) (α β : MultiIndex) (p q : ℝ × ℝ) :
    star (actualCuspResolventJetKernel N hN k l α β p q) =
      actualCuspResolventJetKernel N hN l k β α q p := by
  change Complex.conj (∑' i, actualCuspResolventJetTerm N hN k l α β p q i) = _
  rw [Complex.conj_tsum]
  apply tsum_congr
  intro i
  exact actualCuspResolventJetTerm_star N hN k l α β p q i

def actualCuspResolventJetDiagonalDensity (N : ℕ) [NeZero N] (hN : 0 < N)
    (k : ℕ) (α : MultiIndex) (p : ℝ × ℝ) (i : actualCuspBasisIndex N hN) : ℝ :=
  (1 + actualCuspNativeEigenvalue N hN i) ^ (-((k + k + 7 : ℕ) : ℝ)) *
    ‖testPartial α (actualCuspPlanarProfile N hN i) p‖ ^ 2

theorem actualCuspResolventJetTerm_diagonal (N : ℕ) [NeZero N] (hN : 0 < N)
    (k : ℕ) (α : MultiIndex) (p : ℝ × ℝ) (i : actualCuspBasisIndex N hN) :
    actualCuspResolventJetTerm N hN k k α α p p i =
      (actualCuspResolventJetDiagonalDensity N hN k α p i : ℂ) := by
  dsimp [actualCuspResolventJetTerm, actualCuspResolventJetDiagonalDensity]
  rw [Complex.star_def, Complex.mul_conj, Complex.real_smul,
    ← Complex.ofReal_mul, Complex.normSq_eq_norm_sq]

theorem actualCuspResolventJetDiagonalDensity_nonneg
    (N : ℕ) [NeZero N] (hN : 0 < N) (k : ℕ) (α : MultiIndex)
    (p : ℝ × ℝ) (i : actualCuspBasisIndex N hN) :
    0 ≤ actualCuspResolventJetDiagonalDensity N hN k α p i := by
  exact mul_nonneg (Real.rpow_nonneg (by
    linarith [actualCuspNativeEigenvalue_nonneg N hN i]) _) (sq_nonneg _)

-- The diagonal is literally a real norm-square sum with the same actual
-- labels and sufficient power. No separate positive kernel is substituted.
theorem actualCuspResolventJetKernel_diagonal_eq_density
    (N : ℕ) [NeZero N] (hN : 0 < N) (k : ℕ) (α : MultiIndex) (p : ℝ × ℝ) :
    actualCuspResolventJetKernel N hN k k α α p p =
      ((∑' i, actualCuspResolventJetDiagonalDensity N hN k α p i) : ℂ) := by
  unfold actualCuspResolventJetKernel
  simp_rw [actualCuspResolventJetTerm_diagonal]
  exact (Complex.ofReal_tsum _).symm

theorem actualCuspResolventJetDiagonalDensity_summable
    (N : ℕ) [NeZero N] (hN : 0 < N) (k : ℕ) (α : MultiIndex)
    (hα : α.1 + α.2 ≤ k) (p : ℝ × ℝ) (hp : p ∈ upperChart) :
    Summable (actualCuspResolventJetDiagonalDensity N hN k α p) := by
  have hsingleton : ({p} : Set (ℝ × ℝ)) ⊆ upperChart := by
    simpa only [singleton_subset_iff] using hp
  obtain ⟨B, hbound⟩ := actual_cusp_resolvent_jet_absolute_and_uniform_bound
    N hN k k {p} {p} (isCompact_singleton) (isCompact_singleton) hsingleton hsingleton
  have hs := (hbound α α hα hα p (by simp) p (by simp)).2.1
  simp_rw [actualCuspResolventJetTerm_diagonal] at hs
  exact Complex.summable_ofReal.mp hs

theorem actualCuspResolventJetKernel_diagonal_real_nonneg
    (N : ℕ) [NeZero N] (hN : 0 < N) (k : ℕ) (α : MultiIndex) (p : ℝ × ℝ) :
    (actualCuspResolventJetKernel N hN k k α α p p).im = 0 ∧
      0 ≤ (actualCuspResolventJetKernel N hN k k α α p p).re := by
  rw [actualCuspResolventJetKernel_diagonal_eq_density]
  constructor
  · simp
  · simpa only [Complex.ofReal_re] using
      tsum_nonneg (actualCuspResolventJetDiagonalDensity_nonneg N hN k α p)

end
end ImbalancedChen.Part3.ActualCuspResolventJetDiagonal20261027
