import ImbalancedChen.Part3ActualCuspResolventJetAbsolute

-- SOURCE ONLY / UNCOMPILED_ZERO_CREDIT / READY_FALSE.
-- One actual native spectral cutoff controls all finite high-mode packets
-- on a compact product, at all allowed jet pairs, for power k+l+7.
-- All unchanged original ONB/profile/counting/API holds are inherited.

namespace ImbalancedChen.Part3.ActualCuspResolventJetSpectralTail20261027
noncomputable section
open Set
open ActualFullCuspEigenbasis20261026b ActualCuspEigenbasisNativeLabels20261026b
open ActualCuspResolventJetAbsolute20261027
open PlanarWeakDifferentialMultiindex20261026b
open CanonicalTensorHyperbolicLaplacianForm20261024z

-- No enumeration of the actual basis index is chosen. The same finite
-- excluded set is selected before the jet pair and both evaluation points.
theorem actual_cusp_resolvent_jet_uniform_finite_tail
    (N : ℕ) [NeZero N] (hN : 0 < N) (k l : ℕ)
    (K L : Set (ℝ × ℝ)) (hK : IsCompact K) (hL : IsCompact L)
    (hKpos : K ⊆ upperChart) (hLpos : L ⊆ upperChart) (ε : ℝ) (hε : 0 < ε) :
    ∃ s : Finset (actualCuspBasisIndex N hN),
      ∀ α β : MultiIndex, α.1 + α.2 ≤ k → β.1 + β.2 ≤ l →
      ∀ p ∈ K, ∀ q ∈ L, ∀ t : Finset (actualCuspBasisIndex N hN),
        Disjoint t s → ‖∑ i ∈ t, actualCuspResolventJetTerm N hN k l α β p q i‖ < ε := by
  obtain ⟨g, hg, hgpos, hbound⟩ :=
    exists_actual_cusp_resolvent_jet_summable_majorant N hN k l K L hK hL hKpos hLpos
  obtain ⟨s, hs⟩ := summable_iff_vanishing_norm.mp hg ε hε
  refine ⟨s, ?_⟩
  intro α β hα hβ p hp q hq t ht
  calc
    _ ≤ ∑ i ∈ t, g i := norm_sum_le_of_le _ (fun i hi => hbound α β hα hβ p hp q hq i)
    _ ≤ ‖∑ i ∈ t, g i‖ := le_abs_self _
    _ < ε := hs t ht

-- A real spectral threshold replaces the arbitrary finite excluded set.
-- In particular the bound is independent of packet cardinality and every
-- actual multiplicity slot above the threshold is covered.
theorem actual_cusp_resolvent_jet_uniform_high_spectral_tail
    (N : ℕ) [NeZero N] (hN : 0 < N) (k l : ℕ)
    (K L : Set (ℝ × ℝ)) (hK : IsCompact K) (hL : IsCompact L)
    (hKpos : K ⊆ upperChart) (hLpos : L ⊆ upperChart) (ε : ℝ) (hε : 0 < ε) :
    ∃ R : ℝ, 0 ≤ R ∧
      ∀ α β : MultiIndex, α.1 + α.2 ≤ k → β.1 + β.2 ≤ l →
      ∀ p ∈ K, ∀ q ∈ L, ∀ t : Finset (actualCuspBasisIndex N hN),
        (∀ i ∈ t, R < actualCuspNativeEigenvalue N hN i) →
          ‖∑ i ∈ t, actualCuspResolventJetTerm N hN k l α β p q i‖ < ε := by
  classical
  obtain ⟨s, hs⟩ :=
    actual_cusp_resolvent_jet_uniform_finite_tail N hN k l K L hK hL hKpos hLpos ε hε
  let R : ℝ := ∑ i ∈ s, (1 + actualCuspNativeEigenvalue N hN i)
  have hR : 0 ≤ R := Finset.sum_nonneg (fun i hi => by
    linarith [actualCuspNativeEigenvalue_nonneg N hN i])
  have hlow : ∀ i ∈ s, actualCuspNativeEigenvalue N hN i ≤ R := by
    intro i hi
    have hsingle : 1 + actualCuspNativeEigenvalue N hN i ≤ R :=
      Finset.single_le_sum (fun j hj => by
        linarith [actualCuspNativeEigenvalue_nonneg N hN j]) hi
    linarith
  refine ⟨R, hR, ?_⟩
  intro α β hα hβ p hp q hq t ht
  apply hs α β hα hβ p hp q hq t
  apply Finset.disjoint_left.mpr
  intro i hit his
  exact (not_lt_of_ge (hlow i his)) (ht i hit)

end
end ImbalancedChen.Part3.ActualCuspResolventJetSpectralTail20261027
