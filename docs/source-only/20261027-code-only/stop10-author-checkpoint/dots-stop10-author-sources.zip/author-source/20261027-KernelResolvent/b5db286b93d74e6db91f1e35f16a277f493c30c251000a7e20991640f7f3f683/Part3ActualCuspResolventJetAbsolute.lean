import ImbalancedChen.Part3ActualCuspSmoothEigenprofileFamily
import ImbalancedChen.Part3ActualCuspSpectralWeightSummability
import Mathlib.Analysis.Normed.Group.InfiniteSum

-- SOURCE ONLY / UNCOMPILED_ZERO_CREDIT / READY_FALSE.
-- The original cuspidal ONB, native labels, smooth representative family,
-- compact jet budgets and multiplicity count retain all inherited API holds.
-- This is a two-point kernel primitive, not an abstract operator resolvent.
-- An honest sufficient power is k+l+7: the two jets cost k+l+4 and the
-- remaining inverse cubic weight is summable by the actual quadratic count.
-- No derivative interchange or whole-quotient kernel representation is claimed.

namespace ImbalancedChen.Part3.ActualCuspResolventJetAbsolute20261027
noncomputable section
open Set
open ActualFullCuspEigenbasis20261026b ActualCuspEigenbasisNativeLabels20261026b
open ActualCuspSmoothEigenprofileFamily20261026b
open ActualCuspSpectralWeightSummability20261026b
open PlanarWeakDifferentialMultiindex20261026b

-- The multiplier is the power of the ORIGINAL positive shifted native
-- eigenvalue. Both factors use the ONE already constructed profile family.
def actualCuspResolventJetTerm (N : ℕ) [NeZero N] (hN : 0 < N)
    (k l : ℕ) (α β : MultiIndex) (p q : ℝ × ℝ)
    (i : actualCuspBasisIndex N hN) : ℂ :=
  ((1 + actualCuspNativeEigenvalue N hN i) ^ (-((k + l + 7 : ℕ) : ℝ))) •
    (testPartial α (actualCuspPlanarProfile N hN i) p *
      star (testPartial β (actualCuspPlanarProfile N hN i) q))

private theorem shifted_weight_jet_cancel (x : ℝ) (hx : 0 < x) (k l : ℕ) :
    x ^ (-((k + l + 7 : ℕ) : ℝ)) * (x ^ (k + 2) * x ^ (l + 2)) =
      x ^ (-3 : ℝ) := by
  rw [← Real.rpow_natCast x (k + 2), ← Real.rpow_natCast x (l + 2),
    ← Real.rpow_add hx, ← Real.rpow_add hx]
  congr 1
  push_cast
  ring

-- The constant is chosen before the index, the two points and all jets
-- within the requested orders. It is valid on the full compact product.
theorem exists_actual_cusp_resolvent_jet_cubic_majorant
    (N : ℕ) [NeZero N] (hN : 0 < N) (k l : ℕ)
    (K L : Set (ℝ × ℝ)) (hK : IsCompact K) (hL : IsCompact L)
    (hKpos : K ⊆ CanonicalTensorHyperbolicLaplacianForm20261024z.upperChart)
    (hLpos : L ⊆ CanonicalTensorHyperbolicLaplacianForm20261024z.upperChart) :
    ∃ A : ℝ, 0 ≤ A ∧ ∀ i : actualCuspBasisIndex N hN,
      ∀ α β : MultiIndex, α.1 + α.2 ≤ k → β.1 + β.2 ≤ l →
      ∀ p ∈ K, ∀ q ∈ L,
        ‖actualCuspResolventJetTerm N hN k l α β p q i‖ ≤
          A * (1 + actualCuspNativeEigenvalue N hN i) ^ (-3 : ℝ) := by
  obtain ⟨C, hC, hleft⟩ :=
    exists_uniform_actual_cusp_profile_compact_jet_bound N hN k K hK hKpos
  obtain ⟨D, hD, hright⟩ :=
    exists_uniform_actual_cusp_profile_compact_jet_bound N hN l L hL hLpos
  refine ⟨C * D, mul_nonneg hC hD, ?_⟩
  intro i α β hα hβ p hp q hq
  let x : ℝ := 1 + actualCuspNativeEigenvalue N hN i
  have hx : 0 < x := by
    dsimp [x]
    linarith [actualCuspNativeEigenvalue_nonneg N hN i]
  have hw : 0 ≤ x ^ (-((k + l + 7 : ℕ) : ℝ)) := Real.rpow_nonneg hx.le _
  have hab := mul_le_mul (hleft i α hα p hp) (hright i β hβ q hq)
    (norm_nonneg _) (mul_nonneg hC (pow_nonneg hx.le _))
  change ‖(x ^ (-((k + l + 7 : ℕ) : ℝ))) •
    (testPartial α (actualCuspPlanarProfile N hN i) p *
      star (testPartial β (actualCuspPlanarProfile N hN i) q))‖ ≤ _
  rw [norm_smul, Real.norm_eq_abs, abs_of_nonneg hw, norm_mul, norm_star]
  calc
    _ ≤ x ^ (-((k + l + 7 : ℕ) : ℝ)) *
        ((C * x ^ (k + 2)) * (D * x ^ (l + 2))) :=
      mul_le_mul_of_nonneg_left hab hw
    _ = (C * D) *
        (x ^ (-((k + l + 7 : ℕ) : ℝ)) * (x ^ (k + 2) * x ^ (l + 2))) := by ring
    _ = _ := by rw [shifted_weight_jet_cancel x hx k l]

-- A single summable majorant controls every permitted mixed jet on K×L.
-- This is stronger than a separate pointwise convergence assertion.
theorem exists_actual_cusp_resolvent_jet_summable_majorant
    (N : ℕ) [NeZero N] (hN : 0 < N) (k l : ℕ)
    (K L : Set (ℝ × ℝ)) (hK : IsCompact K) (hL : IsCompact L)
    (hKpos : K ⊆ CanonicalTensorHyperbolicLaplacianForm20261024z.upperChart)
    (hLpos : L ⊆ CanonicalTensorHyperbolicLaplacianForm20261024z.upperChart) :
    ∃ g : actualCuspBasisIndex N hN → ℝ, Summable g ∧ (∀ i, 0 ≤ g i) ∧
      ∀ α β : MultiIndex, α.1 + α.2 ≤ k → β.1 + β.2 ≤ l →
      ∀ p ∈ K, ∀ q ∈ L, ∀ i,
        ‖actualCuspResolventJetTerm N hN k l α β p q i‖ ≤ g i := by
  obtain ⟨A, hA, hbound⟩ :=
    exists_actual_cusp_resolvent_jet_cubic_majorant N hN k l K L hK hL hKpos hLpos
  refine ⟨fun i => A * (1 + actualCuspNativeEigenvalue N hN i) ^ (-3 : ℝ),
    (actualCuspNativeEigenvalue_inverse_weight_summable N hN 3 (by norm_num)).mul_left A,
    ?_, ?_⟩
  · intro i
    exact mul_nonneg hA (Real.rpow_nonneg (by
      linarith [actualCuspNativeEigenvalue_nonneg N hN i]) _)
  · intro α β hα hβ p hp q hq i
    exact hbound i α β hα hβ p hp q hq

def actualCuspResolventJetKernel (N : ℕ) [NeZero N] (hN : 0 < N)
    (k l : ℕ) (α β : MultiIndex) (p q : ℝ × ℝ) : ℂ :=
  ∑' i : actualCuspBasisIndex N hN, actualCuspResolventJetTerm N hN k l α β p q i

-- Both absolute convergence and a common finite bound follow from genuine
-- actual spectral counting, with every multiplicity slot retained.
theorem actual_cusp_resolvent_jet_absolute_and_uniform_bound
    (N : ℕ) [NeZero N] (hN : 0 < N) (k l : ℕ)
    (K L : Set (ℝ × ℝ)) (hK : IsCompact K) (hL : IsCompact L)
    (hKpos : K ⊆ CanonicalTensorHyperbolicLaplacianForm20261024z.upperChart)
    (hLpos : L ⊆ CanonicalTensorHyperbolicLaplacianForm20261024z.upperChart) :
    ∃ B : ℝ, ∀ α β : MultiIndex, α.1 + α.2 ≤ k → β.1 + β.2 ≤ l →
      ∀ p ∈ K, ∀ q ∈ L,
        Summable (fun i => ‖actualCuspResolventJetTerm N hN k l α β p q i‖) ∧
        Summable (actualCuspResolventJetTerm N hN k l α β p q) ∧
        ‖actualCuspResolventJetKernel N hN k l α β p q‖ ≤ B := by
  obtain ⟨g, hg, hgpos, hbound⟩ :=
    exists_actual_cusp_resolvent_jet_summable_majorant N hN k l K L hK hL hKpos hLpos
  refine ⟨∑' i, g i, ?_⟩
  intro α β hα hβ p hp q hq
  have hb := hbound α β hα hβ p hp q hq
  have habs : Summable (fun i => ‖actualCuspResolventJetTerm N hN k l α β p q i‖) :=
    Summable.of_nonneg_of_le (fun i => norm_nonneg _) hb hg
  have hs : Summable (actualCuspResolventJetTerm N hN k l α β p q) :=
    hg.of_norm_bounded hb
  exact ⟨habs, hs, hs.hasSum.norm_le_of_bounded hg.hasSum hb⟩

end
end ImbalancedChen.Part3.ActualCuspResolventJetAbsolute20261027
