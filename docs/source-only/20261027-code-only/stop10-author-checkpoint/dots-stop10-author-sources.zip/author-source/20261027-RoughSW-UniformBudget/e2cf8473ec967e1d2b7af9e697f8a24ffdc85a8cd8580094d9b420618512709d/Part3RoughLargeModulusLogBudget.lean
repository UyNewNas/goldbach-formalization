import ImbalancedChen.Part3RoughAuxiliarySW
import ImbalancedChen.PowerErrorBudget

-- SOURCE ONLY / UNCOMPILED_ZERO_CREDIT.
-- This pays the actual large-modulus discrepancy, uniformly before q,k,b,
-- the carrier, and its bounded coefficients. There is no upper bound on q.
-- The small-modulus rough character estimate remains a separate supplier.

namespace ImbalancedChen.Part3.RoughLargeModulusLogBudget20261027
noncomputable section
open Filter Topology

def largeModulusConstant : ℝ :=
  3 + 2 * |MathlibNt.SieveTheory.Richert1969.richertReciprocalTotientConstant|

theorem largeModulusConstant_pos : 0 < largeModulusConstant := by
  unfold largeModulusConstant
  linarith [abs_nonneg
    MathlibNt.SieveTheory.Richert1969.richertReciprocalTotientConstant]

-- A literal real threshold for every natural interval endpoint H in
-- [x^theta,2x]. The exponent A+1 pays the exact reciprocal-totient log.
theorem exists_auxiliarySWError_large_modulus_log_budget
    (A theta : ℝ) (hA : 0 ≤ A) (htheta : 0 < theta) :
    ∃ x0 : ℝ, 2 ≤ x0 ∧ ∀ x : ℝ, x0 ≤ x →
      ∀ H : ℕ, x ^ theta ≤ (H : ℝ) → (H : ℝ) ≤ 2 * x →
      ∀ k q b : ℕ, (Real.log x) ^ (A + 1) ≤ (q : ℝ) →
      ∀ (S : Finset ℕ) (α : ℕ → ℂ), S ⊆ Finset.Ioc 0 H →
        (∀ n ∈ S, ‖α n‖ ≤ 1) →
        ‖auxiliarySWError S α k q b‖ ≤
          largeModulusConstant * (H : ℝ) / (Real.log x) ^ A := by
  have hdecay : Tendsto (fun x : ℝ =>
      (Real.log x) ^ (A + 1) / x ^ theta) atTop (𝓝 0) :=
    (isLittleO_log_rpow_rpow_atTop (A + 1) htheta).tendsto_div_nhds_zero
  have hpay := hdecay.eventually (gt_mem_nhds (by norm_num : (0 : ℝ) < 1))
  have hpower : ∀ᶠ x : ℝ in atTop, (3 : ℝ) ≤ x ^ theta :=
    (tendsto_rpow_atTop htheta).eventually (eventually_ge_atTop 3)
  have hlog : ∀ᶠ x : ℝ in atTop, 1 ≤ Real.log x :=
    Real.tendsto_log_atTop.eventually (eventually_ge_atTop 1)
  obtain ⟨r, hr⟩ := eventually_atTop.mp (hpay.and (hpower.and hlog))
  refine ⟨max r 2, le_max_right _ _, ?_⟩
  intro x hx H hHlower hHupper k q b hq S α hS hα
  have hx2 : 2 ≤ x := (le_max_right _ _).trans hx
  have hxx := hr x ((le_max_left _ _).trans hx)
  have hL : 1 ≤ Real.log x := hxx.2.2
  have hLp : 0 < Real.log x := zero_lt_one.trans_le hL
  have hxp : 0 < x := lt_of_lt_of_le (by norm_num : (0 : ℝ) < 2) hx2
  have hxpθ : 0 < x ^ theta := Real.rpow_pos_of_pos hxp theta
  have hDpos : 0 < (Real.log x) ^ (A + 1) := Real.rpow_pos_of_pos hLp _
  have hPpos : 0 < (Real.log x) ^ A := Real.rpow_pos_of_pos hLp _
  have hDlower : (Real.log x) ^ (A + 1) ≤ (H : ℝ) :=
    ((div_lt_one₀ hxpθ).mp hxx.1).le.trans hHlower
  have hHreal3 : (3 : ℝ) ≤ (H : ℝ) := hxx.2.1.trans hHlower
  have hH3 : 3 ≤ H := by exact_mod_cast hHreal3
  have hHp : 0 < (H : ℝ) := by exact_mod_cast (show 0 < H by omega)
  have hqp : 0 < q := by exact_mod_cast hDpos.trans_le hq
  have hmin : (Real.log x) ^ (A + 1) ≤ (min q H : ℕ) := by
    rw [Nat.cast_min]
    exact le_min hq hDlower
  have hminpos : 0 < ((min q H : ℕ) : ℝ) := hDpos.trans_le hmin
  have hD_eq : (Real.log x) ^ (A + 1) = (Real.log x) ^ A * Real.log x := by
    rw [Real.rpow_add hLp, Real.rpow_one]
  have hPD : (Real.log x) ^ A ≤ (Real.log x) ^ (A + 1) := by
    rw [hD_eq]
    nlinarith
  have hPH : (Real.log x) ^ A ≤ (H : ℝ) := hPD.trans hDlower
  have hunit : 1 ≤ (H : ℝ) / (Real.log x) ^ A :=
    (le_div_iff₀ hPpos).mpr (by simpa using hPH)
  have hlogH : Real.log (H : ℝ) ≤ 2 * Real.log x := by
    have hHx2 : (H : ℝ) ≤ x ^ (2 : ℕ) := by
      have htwo : 2 * x ≤ x * x := mul_le_mul_of_nonneg_right hx2 hxp.le
      exact hHupper.trans (by simpa only [pow_two] using htwo)
    have h := Real.log_le_log hHp hHx2
    simpa only [Real.log_pow, Nat.cast_ofNat] using h
  let C : ℝ := MathlibNt.SieveTheory.Richert1969.richertReciprocalTotientConstant
  have hCLog : C * Real.log (H : ℝ) ≤ |C| * (2 * Real.log x) := by
    have hlogH0 : 0 ≤ Real.log (H : ℝ) := Real.log_nonneg (by linarith)
    exact (mul_le_mul_of_nonneg_right (le_abs_self C) hlogH0).trans
      (mul_le_mul_of_nonneg_left hlogH (abs_nonneg C))
  have hmean : (H : ℝ) * C * Real.log (H : ℝ) / (min q H : ℕ) ≤
      2 * |C| * ((H : ℝ) / (Real.log x) ^ A) := by
    calc
      _ ≤ (H : ℝ) * (|C| * (2 * Real.log x)) / (min q H : ℕ) :=
        div_le_div_of_nonneg_right
          (by simpa only [mul_assoc] using mul_le_mul_of_nonneg_left hCLog hHp.le)
          hminpos.le
      _ ≤ (H : ℝ) * (|C| * (2 * Real.log x)) / (Real.log x) ^ (A + 1) :=
        div_le_div_of_nonneg_left (by positivity) hDpos hmin
      _ = _ := by rw [hD_eq]; field_simp [hLp.ne', hPpos.ne']; ring
  have hAP : (H : ℝ) / q ≤ (H : ℝ) / (Real.log x) ^ A :=
    div_le_div_of_nonneg_left hHp.le hPpos (hPD.trans hq)
  have hraw := auxiliarySWError_norm_le_large_modulus S α H k q b hS hH3 hqp hα
  apply hraw.trans
  change (H : ℝ) / q + 2 + (H : ℝ) * C * Real.log (H : ℝ) / (min q H : ℕ) ≤ _
  unfold largeModulusConstant
  dsimp only [C] at hmean ⊢
  nlinarith

end
end ImbalancedChen.Part3.RoughLargeModulusLogBudget20261027
