import ImbalancedChen.Part3HeatFactorialScalarBound
import ImbalancedChen.Part3RapidSpectralCoefficientWeights

-- SOURCE ONLY / UNCOMPILED_ZERO_CREDIT / READY_FALSE.
-- Quantitative exponential absorption of an inverse-cubic spectral weight.
-- No spectral count, trace, or desired heat estimate is assumed.
namespace ImbalancedChen.Part3.HeatInverseCubicQuantitativeBound20261027
noncomputable section
open HeatFactorialScalarBound20261025a RapidSpectralCoefficientWeights20261026b

theorem heat_polynomial_le_inverse_cubic {t x : ℝ}
    (ht : 0 < t) (hx : 0 ≤ x) (q : ℕ) :
    Real.exp (-t*x)*(1+x)^q ≤
      (Real.exp t*((q+3).factorial : ℝ)/t^(q+3))*((1+x)^3)⁻¹ := by
  have hw : 0 < 1+x := by linarith
  have hb := pow_mul_exp_neg_mul_le_factorial_div_pow ht hw.le (q+3)
  have he : Real.exp (-t*x) = Real.exp t*Real.exp (-t*(1+x)) := by
    rw [← Real.exp_add]
    congr 1
    ring
  rw [← div_eq_mul_inv]
  apply (le_div_iff₀ (pow_pos hw 3)).2
  calc
    (Real.exp (-t*x)*(1+x)^q)*(1+x)^3 =
        Real.exp t*((1+x)^(q+3)*Real.exp (-t*(1+x))) := by
      rw [he, pow_add]
      ring
    _ ≤ Real.exp t*(((q+3).factorial : ℝ)/t^(q+3)) :=
      mul_le_mul_of_nonneg_left hb (Real.exp_pos t).le
    _ = _ := by ring

theorem heat_polynomial_summable_and_tsum_bound {ι : Type*} {lambda : ι → ℝ}
    (hlambda : ∀ i, 0 ≤ lambda i) (hs : InverseCubicSummable lambda)
    {t : ℝ} (ht : 0 < t) (q : ℕ) :
    Summable (fun i => Real.exp (-t*lambda i)*(1+lambda i)^q) ∧
      (∑' i, Real.exp (-t*lambda i)*(1+lambda i)^q) ≤
        (Real.exp t*((q+3).factorial : ℝ)/t^(q+3))*
          (∑' i, ((1+lambda i)^3)⁻¹) := by
  let D : ℝ := Real.exp t*((q+3).factorial : ℝ)/t^(q+3)
  have hD : 0 ≤ D := by dsimp [D]; positivity
  have hmajor : Summable (fun i => D*((1+lambda i)^3)⁻¹) := hs.mul_left D
  have hnonneg : ∀ i, 0 ≤ Real.exp (-t*lambda i)*(1+lambda i)^q := by
    intro i
    exact mul_nonneg (Real.exp_pos _).le (pow_nonneg (by linarith [hlambda i]) _)
  have hle : ∀ i, Real.exp (-t*lambda i)*(1+lambda i)^q ≤ D*((1+lambda i)^3)⁻¹ :=
    fun i => heat_polynomial_le_inverse_cubic ht (hlambda i) q
  have hf := Summable.of_nonneg_of_le hnonneg hle hmajor
  refine ⟨hf, ?_⟩
  calc
    _ ≤ ∑' i, D*((1+lambda i)^3)⁻¹ := hf.tsum_le_tsum hle hmajor
    _ = _ := tsum_mul_left

theorem heat_polynomial_smalltime_bound {ι : Type*} {lambda : ι → ℝ}
    (hlambda : ∀ i, 0 ≤ lambda i) (hs : InverseCubicSummable lambda)
    {t : ℝ} (ht : 0 < t) (ht1 : t ≤ 1) (q : ℕ) :
    (∑' i, Real.exp (-t*lambda i)*(1+lambda i)^q) ≤
      (Real.exp 1*((q+3).factorial : ℝ)*
        (∑' i, ((1+lambda i)^3)⁻¹))/t^(q+3) := by
  have hS : 0 ≤ ∑' i, ((1+lambda i)^3)⁻¹ :=
    tsum_nonneg (fun i => inv_nonneg.mpr (pow_nonneg (by linarith [hlambda i]) 3))
  calc
    _ ≤ (Real.exp t*((q+3).factorial : ℝ)/t^(q+3))*
        (∑' i, ((1+lambda i)^3)⁻¹) :=
      (heat_polynomial_summable_and_tsum_bound hlambda hs ht q).2
    _ ≤ (Real.exp 1*((q+3).factorial : ℝ)/t^(q+3))*
        (∑' i, ((1+lambda i)^3)⁻¹) := by
      apply mul_le_mul_of_nonneg_right _ hS
      apply div_le_div_of_nonneg_right _ (pow_pos ht _).le
      exact mul_le_mul_of_nonneg_right (Real.exp_le_exp.mpr ht1) (by positivity)
    _ = _ := by ring

end
end ImbalancedChen.Part3.HeatInverseCubicQuantitativeBound20261027
