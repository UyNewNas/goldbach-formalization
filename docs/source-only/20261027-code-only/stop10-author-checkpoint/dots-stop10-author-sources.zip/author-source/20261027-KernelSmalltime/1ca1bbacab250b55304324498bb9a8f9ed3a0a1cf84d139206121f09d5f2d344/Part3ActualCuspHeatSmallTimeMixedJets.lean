import ImbalancedChen.Part3ActualCuspHeatSmallTimeWeights
import ImbalancedChen.Part3ActualCuspSmoothEigenprofileFamily
import ImbalancedChen.Part3MixedSpectralKernelNormalConvergence

-- SOURCE ONLY / UNCOMPILED_ZERO_CREDIT / READY_FALSE.
-- Quantitative bounds for literal ordinary mixed-profile heat series.
-- Constants are chosen before t, i, and the compact-product point.
-- Spatial orders a,b incur coarse t^(-(a+b+7)); no automorphic angular t.
namespace ImbalancedChen.Part3.ActualCuspHeatSmallTimeMixedJets20261027
noncomputable section
open Set
open ActualFullCuspEigenbasis20261026b ActualCuspEigenbasisNativeLabels20261026b
open ActualCuspSmoothEigenprofileFamily20261026b ActualCuspHeatSmallTimeWeights20261027
open MixedSpectralKernelNormalConvergence20261026b
open PlanarWeakDifferentialMultiindex20261026b Gamma0ActualSmoothQuotientCore20261025a

def actualCuspHeatCoefficient (t x : ℝ) : ℂ := (Real.exp (-t*x) : ℝ)

theorem actualCuspProfile_compactJetGrowth (N : ℕ) [NeZero N] (hN : 0 < N) :
    CompactJetGrowth (actualCuspNativeEigenvalue N hN) (actualCuspPlanarProfile N hN)
      upperChart :=
  exists_uniform_actual_cusp_profile_compact_jet_bound N hN

theorem exists_actualCuspHeatMixedJet_smalltime (N : ℕ) [NeZero N] (hN : 0 < N)
    (alpha beta : MultiIndex) {K L : Set (ℝ × ℝ)}
    (hK : IsCompact K) (hL : IsCompact L) (hKO : K ⊆ upperChart) (hLO : L ⊆ upperChart) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ t : ℝ, 0 < t → t ≤ 1 → ∀ p ∈ K ×ˢ L,
      Summable (fun i : actualCuspBasisIndex N hN =>
        ‖mixedKernelTerm (actualCuspHeatCoefficient t) (actualCuspNativeEigenvalue N hN)
          (actualCuspPlanarProfile N hN) alpha beta i p‖) ∧
      (∑' i : actualCuspBasisIndex N hN,
        ‖mixedKernelTerm (actualCuspHeatCoefficient t) (actualCuspNativeEigenvalue N hN)
          (actualCuspPlanarProfile N hN) alpha beta i p‖) ≤ C/t^(mixedJetOrder alpha beta+3) ∧
      ‖mixedKernelSeries (actualCuspHeatCoefficient t) (actualCuspNativeEigenvalue N hN)
          (actualCuspPlanarProfile N hN) alpha beta p‖ ≤ C/t^(mixedJetOrder alpha beta+3) := by
  obtain ⟨A,hA,hbase⟩ := exists_mixedKernelTerm_majorant
    (actualCuspNativeEigenvalue_nonneg N hN) (actualCuspProfile_compactJetGrowth N hN)
    (fun _ => (1 : ℂ)) alpha beta hK hL hKO hLO
  let q := mixedJetOrder alpha beta
  refine ⟨A*actualCuspSmallTimeConstant N hN q,
    mul_nonneg hA (actualCuspSmallTimeConstant_nonneg N hN q), ?_⟩
  intro t ht ht1 p hp
  let w : actualCuspBasisIndex N hN → ℝ := fun i =>
    Real.exp (-t*actualCuspNativeEigenvalue N hN i)*(1+actualCuspNativeEigenvalue N hN i)^q
  have hw : Summable w := actualCuspHeatPolynomialWeight_summable N hN ht q
  have hbound : ∀ i : actualCuspBasisIndex N hN,
      ‖mixedKernelTerm (actualCuspHeatCoefficient t) (actualCuspNativeEigenvalue N hN)
        (actualCuspPlanarProfile N hN) alpha beta i p‖ ≤ A*w i := by
    intro i
    have hb := hbase i p hp
    simp only [norm_one, one_mul] at hb
    calc
      _ = Real.exp (-t*actualCuspNativeEigenvalue N hN i)*
          ‖mixedKernelTerm (fun _ => (1 : ℂ)) (actualCuspNativeEigenvalue N hN)
            (actualCuspPlanarProfile N hN) alpha beta i p‖ := by
        simp only [mixedKernelTerm, actualCuspHeatCoefficient, norm_mul, norm_star,
          Complex.norm_real, Real.norm_eq_abs, abs_of_pos (Real.exp_pos _), norm_one, one_mul]
        ring
      _ ≤ Real.exp (-t*actualCuspNativeEigenvalue N hN i)*
          (A*(1+actualCuspNativeEigenvalue N hN i)^q) :=
        mul_le_mul_of_nonneg_left hb (Real.exp_pos _).le
      _ = A*w i := by dsimp [w]; ring
  have hsum := Summable.of_nonneg_of_le (fun i => norm_nonneg _) hbound (hw.mul_left A)
  have hquant : (∑' i : actualCuspBasisIndex N hN,
      ‖mixedKernelTerm (actualCuspHeatCoefficient t) (actualCuspNativeEigenvalue N hN)
        (actualCuspPlanarProfile N hN) alpha beta i p‖) ≤
      (A*actualCuspSmallTimeConstant N hN q)/t^(q+3) := by
    calc
      _ ≤ ∑' i, A*w i := hsum.tsum_le_tsum hbound (hw.mul_left A)
      _ = A*(∑' i, w i) := tsum_mul_left
      _ ≤ A*(actualCuspSmallTimeConstant N hN q/t^(q+3)) :=
        mul_le_mul_of_nonneg_left (actualCuspHeatPolynomialWeight_smalltime N hN ht ht1 q) hA
      _ = _ := by ring
  refine ⟨hsum,hquant,?_⟩
  exact (norm_tsum_le_tsum_norm hsum).trans hquant

end
end ImbalancedChen.Part3.ActualCuspHeatSmallTimeMixedJets20261027
