import ImbalancedChen.Part3HeatInverseCubicQuantitativeBound
import ImbalancedChen.Part3ActualCuspSpectralWeightSummability

-- SOURCE ONLY / UNCOMPILED_ZERO_CREDIT / READY_FALSE.
-- Actual original multiplicity labels; same fixed-N quadratic count 9527748.
-- The inverse-cubic route deliberately gives the coarse t^(-(q+3)) loss.
-- This is no Weyl asymptotic, uniform-level estimate, or trace identification.
namespace ImbalancedChen.Part3.ActualCuspHeatSmallTimeWeights20261027
noncomputable section
open ActualFullCuspEigenbasis20261026b ActualCuspEigenbasisNativeLabels20261026b
open ActualCuspSpectralWeightSummability20261026b RapidSpectralCoefficientWeights20261026b
open HeatInverseCubicQuantitativeBound20261027

theorem actualCuspInverseCubicSummable (N : ℕ) [NeZero N] (hN : 0 < N) :
    InverseCubicSummable (actualCuspNativeEigenvalue N hN) :=
  inverseCubic_of_rpow (actualCuspNativeEigenvalue_nonneg N hN)
    (actualCuspNativeEigenvalue_inverse_weight_summable N hN 3 (by norm_num))

def actualCuspInverseCubicMass (N : ℕ) [NeZero N] (hN : 0 < N) : ℝ :=
  ∑' i : actualCuspBasisIndex N hN, ((1+actualCuspNativeEigenvalue N hN i)^3)⁻¹

theorem actualCuspInverseCubicMass_nonneg (N : ℕ) [NeZero N] (hN : 0 < N) :
    0 ≤ actualCuspInverseCubicMass N hN := by
  apply tsum_nonneg
  intro i
  exact inv_nonneg.mpr (pow_nonneg (by linarith [actualCuspNativeEigenvalue_nonneg N hN i]) 3)

def actualCuspSmallTimeConstant (N : ℕ) [NeZero N] (hN : 0 < N) (q : ℕ) : ℝ :=
  Real.exp 1*((q+3).factorial : ℝ)*actualCuspInverseCubicMass N hN

theorem actualCuspSmallTimeConstant_nonneg (N : ℕ) [NeZero N] (hN : 0 < N) (q : ℕ) :
    0 ≤ actualCuspSmallTimeConstant N hN q := by
  exact mul_nonneg (by positivity) (actualCuspInverseCubicMass_nonneg N hN)

theorem actualCuspHeatPolynomialWeight_summable (N : ℕ) [NeZero N] (hN : 0 < N)
    {t : ℝ} (ht : 0 < t) (q : ℕ) :
    Summable (fun i : actualCuspBasisIndex N hN =>
      Real.exp (-t*actualCuspNativeEigenvalue N hN i)*
        (1+actualCuspNativeEigenvalue N hN i)^q) :=
  (heat_polynomial_summable_and_tsum_bound (actualCuspNativeEigenvalue_nonneg N hN)
    (actualCuspInverseCubicSummable N hN) ht q).1

theorem actualCuspHeatPolynomialWeight_smalltime (N : ℕ) [NeZero N] (hN : 0 < N)
    {t : ℝ} (ht : 0 < t) (ht1 : t ≤ 1) (q : ℕ) :
    (∑' i : actualCuspBasisIndex N hN,
      Real.exp (-t*actualCuspNativeEigenvalue N hN i)*
        (1+actualCuspNativeEigenvalue N hN i)^q) ≤
      actualCuspSmallTimeConstant N hN q/t^(q+3) :=
  heat_polynomial_smalltime_bound (actualCuspNativeEigenvalue_nonneg N hN)
    (actualCuspInverseCubicSummable N hN) ht ht1 q

-- q=0 gives the actual multiplicity heat-weight sum a coarse t^-3 budget.
theorem actualCuspHeatWeight_smalltime (N : ℕ) [NeZero N] (hN : 0 < N)
    {t : ℝ} (ht : 0 < t) (ht1 : t ≤ 1) :
    (∑' i : actualCuspBasisIndex N hN, Real.exp (-t*actualCuspNativeEigenvalue N hN i)) ≤
      actualCuspSmallTimeConstant N hN 0/t^3 := by
  simpa only [pow_zero, mul_one, Nat.zero_add] using
    actualCuspHeatPolynomialWeight_smalltime N hN ht ht1 0

end
end ImbalancedChen.Part3.ActualCuspHeatSmallTimeWeights20261027
