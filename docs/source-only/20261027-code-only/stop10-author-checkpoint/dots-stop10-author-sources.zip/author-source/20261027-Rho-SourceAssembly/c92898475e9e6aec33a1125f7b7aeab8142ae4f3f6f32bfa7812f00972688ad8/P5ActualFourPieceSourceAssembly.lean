import ImbalancedChen.P5ActualSafeGlobalCoefficientGlue

-- SOURCE_ONLY / UNCOMPILED_ZERO_CREDIT / NOT_ROOT_ACCEPTED.
-- All four signed pieces are paired at the same complete physical q.
-- MAIN, AP and centre are different tests of the literal same coefficient.
-- No smallness of any AP test, density bound, or currentK estimate is assumed.
namespace ImbalancedChen.P5Z.ActualFourPieceSourceAssembly

noncomputable section
open Classical
open scoped BigOperators
open U1011OriginalFifteenNativeGridCells U1011OriginalMaskSmoothBoxRealization
open OriginalJointPresievedCompiler OriginalOrdinaryCommonBetaModel
open ActualSafeGlobalCoefficientGlue
open MathlibNt.SieveTheory.BombieriVinogradov (trueLogarithmicIntegral)

def pieces (inner : Bool) (S : Finset Row) (n N : ℕ) (eta : ℚ)
    (nu epsilon xi : ℝ) (hxi : 0 < xi) (fine mesh : ℕ) (delta : ℝ) :
    Fin 4 → ℕ → ℝ :=
  ![safeBankCoefficient inner S n N eta nu epsilon xi hxi fine mesh delta,
    OriginalCommonBetaGlobalBankCoefficientGlue.reserveCoefficient
      inner S n N eta nu epsilon fine delta,
    OriginalGlobalPOUBankCoefficientGlue.endpointBankCoefficient
      inner S n N eta nu epsilon fine delta mesh xi,
    ActualGlobalUnsafeDensitySeparation.globalCoefficient
      inner S n N eta nu epsilon xi hxi fine mesh delta]

def testedPieces (inner : Bool) (S : Finset Row) (n N : ℕ) (eta : ℚ)
    (nu epsilon xi : ℝ) (hxi : 0 < xi) (fine mesh : ℕ) (delta : ℝ)
    (Q : Finset ℕ) (F : ℕ → ℝ) : ℝ :=
  ∑ i : Fin 4, ∑ q ∈ Q,
    pieces inner S n N eta nu epsilon xi hxi fine mesh delta i q * F q

theorem actual_jointSigma_eq_sum_pieces {n N fine mesh : ℕ} {eta : ℚ}
    (hN : 1 < N) (heta : 0 < eta) (nu epsilon xi : ℝ)
    (hnu : 0 < nu) (he : 0 < epsilon)
    (heBudget : epsilon < OriginalCommonBetaActualParameters.epsilonBudget n eta nu)
    (hxi : 0 < xi) (inner : Bool) (S : Finset Row) {delta : ℝ}
    (hdelta : 0 < delta) (q : ℕ) :
    jointPresievedSigma n N eta ((N : ℝ) ^ (nu * epsilon ^ 2))
      ((N : ℝ) ^ (nu * epsilon)) (U1011NativeMaskPhysicalBoxAtoms.actualE S N) q =
      ∑ i : Fin 4, pieces inner S n N eta nu epsilon xi hxi fine mesh delta i q := by
  rw [actual_jointSigma_eq_safe_bank_three_reserves hN heta nu epsilon xi hnu he
    heBudget hxi inner S hdelta q]
  simp [pieces, Fin.sum_univ_succ]
  ring

-- A common enlarged carrier is allowed. The total four-piece coefficient
-- cancels outside the true support before the test is evaluated.
theorem actual_signed_test_eq_four_piece_test {n N fine mesh : ℕ} {eta : ℚ}
    (hN : 1 < N) (heta : 0 < eta) (nu epsilon xi : ℝ)
    (hnu : 0 < nu) (he : 0 < epsilon)
    (heBudget : epsilon < OriginalCommonBetaActualParameters.epsilonBudget n eta nu)
    (hxi : 0 < xi) (inner : Bool) (S : Finset Row) {delta : ℝ}
    (hdelta : 0 < delta) (Q : Finset ℕ)
    (hQ : jointSupport n N eta ((N : ℝ) ^ (nu * epsilon ^ 2))
      (U1011NativeMaskPhysicalBoxAtoms.actualE S N) ⊆ Q) (F : ℕ → ℝ) :
    (∑ q ∈ jointSupport n N eta ((N : ℝ) ^ (nu * epsilon ^ 2))
      (U1011NativeMaskPhysicalBoxAtoms.actualE S N),
      jointPresievedSigma n N eta ((N : ℝ) ^ (nu * epsilon ^ 2))
        ((N : ℝ) ^ (nu * epsilon)) (U1011NativeMaskPhysicalBoxAtoms.actualE S N) q * F q) =
      testedPieces inner S n N eta nu epsilon xi hxi fine mesh delta Q F := by
  have hext : (∑ q ∈ jointSupport n N eta ((N : ℝ) ^ (nu * epsilon ^ 2))
      (U1011NativeMaskPhysicalBoxAtoms.actualE S N),
      jointPresievedSigma n N eta ((N : ℝ) ^ (nu * epsilon ^ 2))
        ((N : ℝ) ^ (nu * epsilon)) (U1011NativeMaskPhysicalBoxAtoms.actualE S N) q * F q) =
      ∑ q ∈ Q, jointPresievedSigma n N eta ((N : ℝ) ^ (nu * epsilon ^ 2))
        ((N : ℝ) ^ (nu * epsilon)) (U1011NativeMaskPhysicalBoxAtoms.actualE S N) q * F q := by
    apply Finset.sum_subset hQ
    intro q hq hn
    rw [jointSigma_zero_off_support n N eta _ _ _ hn, zero_mul]
  rw [hext]
  unfold testedPieces
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro q hq
  rw [actual_jointSigma_eq_sum_pieces hN heta nu epsilon xi hnu he heBudget
    hxi inner S hdelta q, Finset.sum_mul]

theorem actual_density_eq_four_piece_main {n N fine mesh : ℕ} {eta : ℚ}
    (hN : 1 < N) (heta : 0 < eta) (nu epsilon xi : ℝ)
    (hnu : 0 < nu) (he : 0 < epsilon)
    (heBudget : epsilon < OriginalCommonBetaActualParameters.epsilonBudget n eta nu)
    (hxi : 0 < xi) (inner : Bool) (S : Finset Row) {delta : ℝ}
    (hdelta : 0 < delta) (Q : Finset ℕ)
    (hQ : jointSupport n N eta ((N : ℝ) ^ (nu * epsilon ^ 2))
      (U1011NativeMaskPhysicalBoxAtoms.actualE S N) ⊆ Q) :
    jointDensity n N eta ((N : ℝ) ^ (nu * epsilon ^ 2))
      ((N : ℝ) ^ (nu * epsilon)) (U1011NativeMaskPhysicalBoxAtoms.actualE S N) =
      testedPieces inner S n N eta nu epsilon xi hxi fine mesh delta Q
        (fun q => 1 / (Nat.totient q : ℝ)) := by
  simpa only [jointDensity, physicalDensitySum, div_eq_mul_one_div] using
    actual_signed_test_eq_four_piece_test hN heta nu epsilon xi hnu he heBudget
      hxi inner S hdelta Q hQ (fun q => 1 / (Nat.totient q : ℝ))

-- The source partition and original fallback remain literal. This is a
-- source upper bound with three distinct tests, and supplies no AP saving.
theorem original_source_upper_four_piece_tests {n N fine mesh : ℕ} {eta : ℚ}
    (hN : 1 < N) (heta : 0 < eta) (nu epsilon xi : ℝ)
    (hnu : 0 < nu) (he : 0 < epsilon)
    (heBudget : epsilon < OriginalCommonBetaActualParameters.epsilonBudget n eta nu)
    (hxi : 0 < xi) (inner : Bool) (S : Finset Row) {delta : ℝ}
    (hdelta : 0 < delta) (Q : Finset ℕ)
    (hQ : jointSupport n N eta ((N : ℝ) ^ (nu * epsilon ^ 2))
      (U1011NativeMaskPhysicalBoxAtoms.actualE S N) ⊆ Q)
    (hB : 1 < (N : ℝ) ^ (nu * epsilon))
    (hwB : (N : ℝ) ^ (nu * epsilon ^ 2) ≤ (N : ℝ) ^ (nu * epsilon))
    (hw : ∀ t ∈ U1011OriginalSixteenJointNearCapCompiler.ordinaryTuples n N
      (U1011NativeMaskPhysicalBoxAtoms.actualE S N), (N : ℝ) ^ (nu * epsilon ^ 2) ≤
      U1011OriginalSixteenJointNearCapCompiler.Z n N eta t) :
    currentChenUpsilon10 N + currentChenUpsilon11 N
      (U1011NativeMaskPhysicalBoxAtoms.actualE S N) ≤
      (∑ t ∈ U1011OriginalSixteenJointNearCapCompiler.fallbackTuples n N
        (U1011NativeMaskPhysicalBoxAtoms.actualE S N), U11Adaptive.weight N t) +
      trueLogarithmicIntegral N *
        testedPieces inner S n N eta nu epsilon xi hxi fine mesh delta Q
          (fun q => 1 / (Nat.totient q : ℝ)) +
      testedPieces inner S n N eta nu epsilon xi hxi fine mesh delta Q
        (chenQuotientPrimeAPError N (trueLogarithmicIntegral N)) -
      testedPieces inner S n N eta nu epsilon xi hxi fine mesh delta Q
        (chenCentrePrimeAPCount N N) := by
  have hd := actual_density_eq_four_piece_main hN heta nu epsilon xi hnu he heBudget
    hxi inner S hdelta Q hQ
  have ha := actual_signed_test_eq_four_piece_test hN heta nu epsilon xi hnu he heBudget
    hxi inner S hdelta Q hQ (chenQuotientPrimeAPError N (trueLogarithmicIntegral N))
  have hc := actual_signed_test_eq_four_piece_test hN heta nu epsilon xi hnu he heBudget
    hxi inner S hdelta Q hQ (chenCentrePrimeAPCount N N)
  have hu := original_joint_source_upper hN heta hB hwB
    (U1011NativeMaskPhysicalBoxAtoms.actualE S N) hw
  change jointAP n N eta ((N : ℝ) ^ (nu * epsilon ^ 2))
    ((N : ℝ) ^ (nu * epsilon)) (U1011NativeMaskPhysicalBoxAtoms.actualE S N) = _ at ha
  change jointCentre n N eta ((N : ℝ) ^ (nu * epsilon ^ 2))
    ((N : ℝ) ^ (nu * epsilon)) (U1011NativeMaskPhysicalBoxAtoms.actualE S N) = _ at hc
  rw [hd, ha, hc] at hu
  exact hu

end
end ImbalancedChen.P5Z.ActualFourPieceSourceAssembly
