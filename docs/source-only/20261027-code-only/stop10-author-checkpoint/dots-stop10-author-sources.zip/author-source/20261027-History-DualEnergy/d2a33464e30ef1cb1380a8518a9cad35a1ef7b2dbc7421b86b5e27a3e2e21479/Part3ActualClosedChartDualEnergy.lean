import ImbalancedChen.Part3ActualCompletedAllModeBridge
import ImbalancedChen.Part3ActualChartResidueEnergy

-- SOURCE ONLY / UNCOMPILED_ZERO_CREDIT / NOT_ROOT_ACCEPTED.
-- The full completed-m series and the true signed right coefficient are
-- combined before the finite level Cauchy inequality. A level test xi is
-- arbitrary data, not an assumed spectral estimate or replacement beta.
-- The closed-T COST2 is upstream of squaring and must still be paid.
-- In particular this does not identify a full-base beta with two chart
-- betas: all mixed lower/endpoint pairs remain in that upstream source.
-- Native y=0 is retained; nonzero y may also map to residue zero.

namespace ImbalancedChen.Part3.ActualClosedChartDualEnergy20261027
noncomputable section
open Classical Finset CommonSmoothCutoff
open ActualCompletedSquarePushforwardSourceOnly
open ActualCompletedAllModeBridge20261026b ActualChartResidueEnergy20261026b
open ActualReciprocalSquarePoissonSourceOnly ActualClosedTCountLicenseSourceOnly
open ActualRestrictedChartWeightCountSourceOnly ActualChartTagHeight576SourceOnly
open ActualM2FinitePoissonAdapterSourceOnly ActualSeparatedRowPacketMatchSourceOnly
open ActualPositiveLatticeSmoothCoverSourceOnly ActualLogTagHSupportSourceOnly
open SignedResiduePushforwardEnergy20261026b
open OriginalSmoothPoissonTail.FiniteOperator20261026b
open scoped BigOperators

-- The rectangular carrier in the all-mode bridge adds only zero beta
-- values. This identity applies to the literal signed residue sum,
-- including residue zero and arbitrary nonunit multipliers a.
theorem joint_right_eq_native_right (U : Finset Source)
    (lambda : ℕ → ℂ) (omega : ℤ → ℂ)
    (q : ℕ) [NeZero q] (a : ℤ) (z : ℕ) :
    packetRightCoefficient q (jointYCarrier U)
      (fun y => beta U lambda omega (z,y)) a =
    packetRightCoefficient q (nativeY U z)
      (fun y => beta U lambda omega (z,y)) a := by
  have hsub : nativeY U z ⊆ jointYCarrier U := by
    intro y hy
    obtain ⟨zy,hzy,rfl⟩ := Finset.mem_image.mp hy
    exact Finset.mem_image_of_mem Prod.snd (Finset.mem_filter.mp hzy).1
  funext v
  unfold packetRightCoefficient
  symm
  apply Finset.sum_subset hsub
  intro y hy hn
  have hb : beta U lambda omega (z,y) = 0 := by
    by_contra hb
    apply hn
    exact Finset.mem_image.mpr ⟨(z,y),
      Finset.mem_filter.mpr ⟨beta_ne_zero_mem_image hb,rfl⟩,rfl⟩
  simp only [hb,ite_self]

-- Both coefficient energies have been supplied by original arithmetic:
-- the complete left alias by positive-cutoff Parseval, and the right
-- by the signed native pushforward. No final energy hypothesis occurs.
theorem level_series_total_sq_le (U : Finset Source)
    (lambda : ℕ → ℂ) (omega : ℤ → ℂ)
    (M N : ℝ) (hM : 0 < M) (q : ℕ) [NeZero q] (a : ℤ) :
    (∑ z ∈ nativeLevels U,
      ‖carrierLevelSeries U lambda omega M N q z a‖^2) ≤
    (9*M*(M+(q : ℝ)))*nativeResidueEnergy U lambda omega q a := by
  calc
    _ ≤ ∑ z ∈ nativeLevels U, (9*M*(M+(q : ℝ))) *
        energy q (packetRightCoefficient q (nativeY U z)
          (fun y => beta U lambda omega (z,y)) a) := by
      apply Finset.sum_le_sum
      intro z hz
      simpa only [joint_right_eq_native_right] using
        carrierLevelSeries_norm_sq_le U lambda omega M N hM q z a
    _ = _ := by rw [nativeResidueEnergy,Finset.mul_sum]

-- Finite duality retains xi inside the signed level sum before norms.
-- It loses only the displayed true l2 norm of xi; it asserts no spectral
-- saving for a family of levels or moduli.
theorem dual_level_series_norm_sq_le (U : Finset Source)
    (lambda : ℕ → ℂ) (omega : ℤ → ℂ) (xi : ℕ → ℂ)
    (M N : ℝ) (hM : 0 < M) (q : ℕ) [NeZero q] (a : ℤ) :
    ‖∑ z ∈ nativeLevels U,
      xi z * carrierLevelSeries U lambda omega M N q z a‖^2 ≤
    (∑ z ∈ nativeLevels U, ‖xi z‖^2) *
      ((9*M*(M+(q : ℝ)))*nativeResidueEnergy U lambda omega q a) := by
  exact (ImbalancedChen.Part3.complex_finset_cauchy_norm_sq
    (nativeLevels U) xi (fun z => carrierLevelSeries U lambda omega M N q z a)).trans
      (mul_le_mul_of_nonneg_left
        (level_series_total_sq_le U lambda omega M N hM q a)
        (Finset.sum_nonneg (fun _ _ => sq_nonneg _)))

-- Actual closed-T/sign/dyadic-f specialization. The physical endpoints
-- ceil(-4 F Htag S), floor(4 F Htag S), divisor budget and true tag height
-- are derived by the existing native supplier. Both completed scales M,N
-- and every original lambda/omega phase stay literal.
theorem actual_closed_chart_dual_energy_le_576
    {B : ℕ} {sigma kappa c0 : ℝ} {e : MediumAtom}
    (he : MediumAdmissible B sigma kappa c0 e)
    (D delta g l : ℕ) [NeZero (g*l)] (Z : ℝ) (tag : ℕ × Bool)
    (m : ℤ × ℤ) (negative : Bool) (u : (ZMod (g*l))ˣ) (k : ZMod (g*l))
    (hq : 0 < D/delta) (upper : Bool) (fj : ℕ × Bool)
    (q : ℕ) [NeZero q] (M N : ℝ) (hM : 0 < M) (xi : ℕ → ℂ) :
    let a := signedResidue negative e.residue
    let U := fBlock (g*l) a (e.Q2 / ((D/delta : ℕ) : ℝ)) upper
      (tagFrequencyBound tag) (scaleF e D g) fj
    let lam := actualModeLambda e D delta g l m negative u k
    let om := actualModeOmega e D g l Z tag m negative k
    ‖∑ z ∈ nativeLevels U, xi z * carrierLevelSeries U lam om M N q z a‖^2 ≤
      (∑ z ∈ nativeLevels U, ‖xi z‖^2) *
        ((9*M*(M+(q : ℝ))) *
          (collisionFactor q a (Int.ceil (-actualTagPhysicalY e D delta g tag))
            (Int.floor (actualTagPhysicalY e D delta g tag)) *
              actualChart576Budget e D delta tag upper fj)) := by
  dsimp only
  apply (dual_level_series_norm_sq_le _ _ _ xi M N hM q _).trans
  apply mul_le_mul_of_nonneg_left
  · apply mul_le_mul_of_nonneg_left
    · exact actual_chart_residue_energy_le_576 he D delta g l Z tag m negative u k
        hq upper fj q
    · have hqnonneg : (0 : ℝ) ≤ q := Nat.cast_nonneg q
      positivity
  · exact Finset.sum_nonneg (fun _ _ => sq_nonneg _)

end
end ImbalancedChen.Part3.ActualClosedChartDualEnergy20261027
