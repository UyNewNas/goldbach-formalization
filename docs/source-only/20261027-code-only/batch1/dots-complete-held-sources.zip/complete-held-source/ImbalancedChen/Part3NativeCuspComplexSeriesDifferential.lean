import ImbalancedChen.Part3NativeCuspComplexJetMajorants
import Mathlib.Analysis.Calculus.SmoothSeries
import Mathlib.Analysis.Normed.Operator.Bilinear
import Mathlib.Analysis.Normed.Operator.Prod
import Mathlib.Tactic

-- SOURCE ONLY / UNCOMPILED / ZERO FORMAL CREDIT.
-- Real Frechet differentiation of the native all-cusp complex Eisenstein sum.
-- This includes the first derivatives of both first-jet sums. The hypotheses
-- are only positive level and Re(s)>1; no series derivative is assumed.

namespace ImbalancedChen.Part3.NativeCuspComplexSeriesDifferential20261027
noncomputable section
open Set Filter Complex UpperHalfPlane
open scoped Topology UpperHalfPlane MatrixGroups BigOperators
open ImbalancedChen.Part3.RealEisensteinSeedLaplacian
open ImbalancedChen.Part3.Gamma0GeneralCuspWidth20261025a
open ImbalancedChen.Part3.NativeAllCuspEisenstein20261026b
open ImbalancedChen.Part3.NativeCuspComplexLogJets20261026b
open ImbalancedChen.Part3.NativeCuspComplexJetMajorants20261026b

abbrev Plane := ℝ × ℝ
def upperDomain : Set Plane := {p | 0 < p.2}
theorem upperDomain_isOpen : IsOpen upperDomain := isOpen_lt continuous_const continuous_snd

def firstLift : ℂ →L[ℝ] (Plane →L[ℝ] ℂ) :=
  ContinuousLinearMap.smulRightL ℝ Plane ℂ (ContinuousLinearMap.fst ℝ ℝ ℝ)
def secondLift : ℂ →L[ℝ] (Plane →L[ℝ] ℂ) :=
  ContinuousLinearMap.smulRightL ℝ Plane ℂ (ContinuousLinearMap.snd ℝ ℝ ℝ)
def coordinateLinear (a b : ℂ) : Plane →L[ℝ] ℂ := firstLift a + secondLift b

@[simp] theorem coordinateLinear_apply (a b : ℂ) (h : Plane) :
    coordinateLinear a b h = h.1 • a + h.2 • b := by
  simp [coordinateLinear,firstLift,secondLift]

theorem coordinateLinear_norm_le (a b : ℂ) : ‖coordinateLinear a b‖ ≤ ‖a‖+‖b‖ := by
  simpa [coordinateLinear,firstLift,secondLift] using norm_add_le (firstLift a) (secondLift b)

theorem hasFDerivAt_coordinateLinear {f : Plane → ℂ} {p : Plane} {a b : ℂ}
    (hf : DifferentiableAt ℝ f p)
    (hx : HasDerivAt (fun t : ℝ => f (t,p.2)) a p.1)
    (hy : HasDerivAt (fun t : ℝ => f (p.1,t)) b p.2) :
    HasFDerivAt f (coordinateLinear a b) p := by
  have hpathx : HasDerivAt (fun t : ℝ => (t,p.2)) (1,0) p.1 :=
    (hasDerivAt_id p.1).prodMk (hasDerivAt_const p.1 p.2)
  have hpathy : HasDerivAt (fun t : ℝ => (p.1,t)) (0,1) p.2 :=
    (hasDerivAt_const p.2 p.1).prodMk (hasDerivAt_id p.2)
  have h1 := (hf.hasFDerivAt.comp_hasDerivAt p.1 hpathx).unique hx
  have h2 := (hf.hasFDerivAt.comp_hasDerivAt p.2 hpathy).unique hy
  apply hf.hasFDerivAt.congr_fderiv
  ext h
  have hsplit : h = h.1 • (1,0) + h.2 • (0,1) := by ext <;> simp
  calc
    fderiv ℝ f p h = fderiv ℝ f p (h.1 • (1,0)+h.2 • (0,1)) := congrArg _ hsplit
    _ = h.1 • a+h.2 • b := by simp [h1,h2]
    _ = coordinateLinear a b h := by simp

inductive FirstSlot | value | x | y
  deriving DecidableEq, Fintype
def slot : FirstSlot → JetSlot
  | .value => .value | .x => .x | .y => .y
def xSlot : FirstSlot → JetSlot
  | .value => .x | .x => .xx | .y => .xy
def ySlot : FirstSlot → JetSlot
  | .value => .y | .x => .xy | .y => .yy

theorem kernel_differentiableAt (w : ℝ) (s : ℂ) (c d : ℝ) (p : Plane)
    (hcd : c≠0 ∨ d≠0) (hp : 0<p.2) :
    DifferentiableAt ℝ (fun q : Plane => kernel w s c d q.1 q.2) p := by
  have hQ : DifferentiableAt ℝ (fun q : Plane => Q c d q.1 q.2) p := by
    unfold Q
    fun_prop
  have hlog : DifferentiableAt ℝ (fun q : Plane => logBase w c d q.1 q.2) p :=
    ((Real.differentiableAt_log hp.ne').comp p differentiableAt_snd).sub
      ((Real.differentiableAt_log (Q_pos hcd hp).ne').comp p hQ) |>.sub_const (Real.log w)
  exact ((Complex.ofRealCLM.differentiableAt.comp p hlog).const_mul s).cexp

theorem firstJet_hasFDerivAt (j : FirstSlot) (w : ℝ) (s : ℂ) (c d : ℝ) (p : Plane)
    (hcd : c≠0 ∨ d≠0) (hp : 0<p.2) :
    HasFDerivAt (fun q : Plane => coordinateJet (slot j) w s c d q.1 q.2)
      (coordinateLinear (coordinateJet (xSlot j) w s c d p.1 p.2)
        (coordinateJet (ySlot j) w s c d p.1 p.2)) p := by
  have hK := kernel_differentiableAt w s c d p hcd hp
  have hQ : DifferentiableAt ℝ (fun q : Plane => Q c d q.1 q.2) p := by unfold Q; fun_prop
  have hqx : DifferentiableAt ℝ (fun q : Plane => Qx c d q.1) p := by unfold Qx; fun_prop
  have hqy : DifferentiableAt ℝ (fun q : Plane => Qy c q.2) p := by unfold Qy; fun_prop
  have hlx : DifferentiableAt ℝ (fun q : Plane => logX c d q.1 q.2) p :=
    hqx.neg.div hQ (Q_pos hcd hp).ne'
  have hly : DifferentiableAt ℝ (fun q : Plane => logY c d q.1 q.2) p :=
    ((differentiableAt_const 1).div differentiableAt_snd hp.ne').sub
      (hqy.div hQ (Q_pos hcd hp).ne')
  cases j
  · simpa only [slot,xSlot,ySlot,coordinateJet_value,coordinateJet_x,coordinateJet_y] using
      hasFDerivAt_coordinateLinear hK
        (kernel_deriv_x w s c d p.1 p.2 hcd hp) (kernel_deriv_y w s c d p.1 p.2 hcd hp)
  · exact hasFDerivAt_coordinateLinear
      (((Complex.ofRealCLM.differentiableAt.comp p hlx).const_mul s).mul hK)
      (jetX_deriv_x w s c d p.1 p.2 hcd hp) (jetX_deriv_y w s c d p.1 p.2 hcd hp)
  · exact hasFDerivAt_coordinateLinear
      (((Complex.ofRealCLM.differentiableAt.comp p hly).const_mul s).mul hK)
      (jetY_deriv_x w s c d p.1 p.2 hcd hp) (jetY_deriv_y w s c d p.1 p.2 hcd hp)

def jetSum (N : ℕ) (g : SL(2,ℤ)) (j : JetSlot) (s : ℂ) (p : Plane) : ℂ :=
  ∑' v : AllowedPair N g, rowJet N g j s p v
def rowGradient (N : ℕ) (g : SL(2,ℤ)) (j : FirstSlot) (s : ℂ)
    (p : Plane) (v : AllowedPair N g) : Plane →L[ℝ] ℂ :=
  coordinateLinear (rowJet N g (xSlot j) s p v) (rowJet N g (ySlot j) s p v)
def sumGradient (N : ℕ) (g : SL(2,ℤ)) (j : FirstSlot) (s : ℂ)
    (p : Plane) : Plane →L[ℝ] ℂ :=
  coordinateLinear (jetSum N g (xSlot j) s p) (jetSum N g (ySlot j) s p)

theorem rowGradient_tsum (N : ℕ) (hN : 0<N) (g : SL(2,ℤ)) (j : FirstSlot)
    (s : ℂ) (hs : 1<s.re) (p : Plane) (hp : 0<p.2) :
    (∑' v : AllowedPair N g, rowGradient N g j s p v) = sumGradient N g j s p := by
  have hx := rowJet_summable N hN g (xSlot j) s hs p hp
  have hy := rowJet_summable N hN g (ySlot j) s hs p hp
  unfold rowGradient sumGradient coordinateLinear jetSum
  rw [(firstLift.summable hx).tsum_add (secondLift.summable hy),
    ← firstLift.map_tsum hx, ← secondLift.map_tsum hy]

-- The local rectangle gives genuine uniform bounds in both spatial variables.
theorem jetSum_hasFDerivAt (N : ℕ) (hN : 0<N) (g : SL(2,ℤ)) (j : FirstSlot)
    (s : ℂ) (hs : 1<s.re) (p : Plane) (hp : 0<p.2) :
    HasFDerivAt (jetSum N g (slot j) s) (sumGradient N g j s p) p := by
  have hB : 0<p.2/2 := by linarith
  let A : ℝ := |p.1|+1
  let D : Set Plane := Ioo (p.1-1) (p.1+1) ×ˢ Ioo (p.2/2) (3*p.2/2)
  let u := rowJetMajorant N g s.re s.re ‖s‖ A (p.2/2) (3*p.2/2) hB
  have hu : Summable (fun v : AllowedPair N g => u v+u v) :=
    (rowJetMajorant_summable N g s.re s.re ‖s‖ A (p.2/2) (3*p.2/2) hs hs hB).add
      (rowJetMajorant_summable N g s.re s.re ‖s‖ A (p.2/2) (3*p.2/2) hs hs hB)
  have hmem : p∈D := by constructor <;> constructor <;> linarith
  have hb (q : Plane) (hq : q∈D) (k : JetSlot) (v : AllowedPair N g) :
      ‖rowJet N g k s q v‖≤u v := by
    have hx : |q.1|≤A := by
      apply abs_le.mpr
      constructor <;> dsimp [A] <;>
        linarith [neg_abs_le p.1,le_abs_self p.1,hq.1.1,hq.1.2]
    exact rowJet_norm_le_majorant N hN g k s.re s.re ‖s‖ A (p.2/2) (3*p.2/2)
      hs hs hB s ⟨le_rfl,le_rfl⟩ le_rfl q ⟨hx,hq.2.1.le,hq.2.2.le⟩ v
  have hd := hasFDerivAt_tsum_of_isPreconnected
    (f := fun (v : AllowedPair N g) q => rowJet N g (slot j) s q v)
    (f' := fun (v : AllowedPair N g) q => rowGradient N g j s q v)
    (u := fun v => u v+u v) (s := D) hu
    (isOpen_Ioo.prod isOpen_Ioo) (isPreconnected_Ioo.prod isPreconnected_Ioo)
    (fun v q hq => firstJet_hasFDerivAt j _ s _ _ q
      (primitive_coordinates_nonzero v.1) (hB.trans hq.2.1))
    (fun v q hq => (coordinateLinear_norm_le _ _).trans
      (add_le_add (hb q hq (xSlot j) v) (hb q hq (ySlot j) v)))
    hmem (rowJet_summable N hN g (slot j) s hs p hp) hmem
  exact hd.congr_fderiv (rowGradient_tsum N hN g j s hs p hp)

-- The chart is the native all-cusp series, including its central factor.
def cuspChart (N : ℕ) (g : SL(2,ℤ)) (s : ℂ) (p : Plane) : ℂ :=
  (1/2:ℂ)*jetSum N g .value s p

theorem cuspChart_eq_actual (N : ℕ) (hN : 0<N) (g : SL(2,ℤ)) (s : ℂ) (z : ℍ) :
    cuspChart N g s (z.re,z.im)=cuspEisenstein N g s z := by
  unfold cuspChart jetSum cuspEisenstein
  congr 1
  apply tsum_congr
  intro v
  simpa only [rowJet,coordinateJet_value] using kernel_eq_normalizedSeed N hN g s z v.1

theorem cuspChart_hasFDerivAt (N : ℕ) (hN : 0<N) (g : SL(2,ℤ))
    (s : ℂ) (hs : 1<s.re) (p : Plane) (hp : 0<p.2) :
    HasFDerivAt (cuspChart N g s)
      ((1/2:ℂ) • sumGradient N g .value s p) p := by
  exact (jetSum_hasFDerivAt N hN g .value s hs p hp).const_smul (1/2:ℂ)

end
end ImbalancedChen.Part3.NativeCuspComplexSeriesDifferential20261027
