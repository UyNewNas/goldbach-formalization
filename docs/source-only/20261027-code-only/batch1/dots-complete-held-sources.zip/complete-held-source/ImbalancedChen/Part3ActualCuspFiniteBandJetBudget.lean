import ImbalancedChen.Part3ActualCuspSmoothEigenprofileFamily
import ImbalancedChen.Part3ActualCuspBasisIndexCounting
import ImbalancedChen.Part3ActualCuspQuadraticSpectralCounting

-- SOURCE ONLY / UNCOMPILED / ZERO FORMAL CREDIT / READY_FALSE.
-- The actual ONB compact-jet and multiplicity suppliers already exist.
-- This new leaf pays a finite two-point kernel jet sum by the actual
-- multiplicity-card budget. Constants precede the cutoff and finite set.
-- Native spectral labels, original ONB indices and chosen smooth profiles
-- are literal suppliers; no final bound or spectral certificate is assumed.
-- All inherited Dots API holds remain unchanged.
namespace ImbalancedChen.Part3.ActualCuspFiniteBandJetBudget20261027
noncomputable section
open Set
open scoped BigOperators
open ActualFullCuspEigenbasis20261026b ActualCuspEigenbasisNativeLabels20261026b
open ActualCuspSmoothEigenprofileFamily20261026b ActualCuspBasisIndexCounting20261026b
open ActualCuspQuadraticSpectralCounting20261026b
open ActualLowCuspSpectralSubspaceFiniteDimension20261026b
open PlanarWeakDifferentialMultiindex20261026b

-- The finite set retains every original multiplicity slot.
def actualCuspFiniteJetKernel (N : ℕ) [NeZero N] (hN : 0 < N)
    (s : Finset (actualCuspBasisIndex N hN)) (a b : MultiIndex)
    (p q : ℝ × ℝ) : ℂ :=
  ∑ i ∈ s, testPartial a (actualCuspPlanarProfile N hN i) p *
    star (testPartial b (actualCuspPlanarProfile N hN i) q)

-- Coarse fixed-level count, with multiplicity, for arbitrary finite bands.
theorem exists_actual_finite_band_quadratic_card (N : ℕ) [NeZero N] (hN : 0 < N) :
    ∃ D : ℝ, 0 < D ∧ ∀ L : ℝ, 0 ≤ L →
      ∀ s : Finset (actualCuspBasisIndex N hN),
      (∀ i ∈ s, actualCuspNativeEigenvalue N hN i ≤ L) →
      (s.card : ℝ) ≤ D * (1 + L) ^ 2 := by
  obtain ⟨D, hD, hcount⟩ := exists_actual_cusp_quadratic_counting_bound N hN
  refine ⟨D, hD, ?_⟩
  intro L hL s hs
  have hcard : (s.card : ℝ) ≤
      (Module.finrank ℂ (actualLowCuspSpectralSubspace N hN L) : ℝ) := by
    exact_mod_cast actualCuspBasis_finite_band_card_le_finrank N hN L s hs
  exact hcard.trans (hcount L hL)

-- Orders k,l lose k+l+4 from the two genuine profile jets, and 2 from
-- actual spectral multiplicity. The estimate bounds absolute mass first.
theorem exists_actual_finite_band_absolute_jet_budget
    (N : ℕ) [NeZero N] (hN : 0 < N) (k l : ℕ)
    (K Q : Set (ℝ × ℝ)) (hK : IsCompact K) (hQ : IsCompact Q)
    (hKpos : K ⊆ CanonicalTensorHyperbolicLaplacianForm20261024z.upperChart)
    (hQpos : Q ⊆ CanonicalTensorHyperbolicLaplacianForm20261024z.upperChart) :
    ∃ B : ℝ, 0 ≤ B ∧ ∀ L : ℝ, 0 ≤ L →
      ∀ s : Finset (actualCuspBasisIndex N hN),
      (∀ i ∈ s, actualCuspNativeEigenvalue N hN i ≤ L) →
      ∀ a b : MultiIndex, a.1 + a.2 ≤ k → b.1 + b.2 ≤ l →
      ∀ p ∈ K, ∀ q ∈ Q,
      (∑ i ∈ s, ‖testPartial a (actualCuspPlanarProfile N hN i) p *
        star (testPartial b (actualCuspPlanarProfile N hN i) q)‖) ≤
          B * (1 + L) ^ (k + l + 6) := by
  classical
  obtain ⟨A, hA, hjetA⟩ := exists_uniform_actual_cusp_profile_compact_jet_bound
    N hN k K hK hKpos
  obtain ⟨C, hC, hjetC⟩ := exists_uniform_actual_cusp_profile_compact_jet_bound
    N hN l Q hQ hQpos
  obtain ⟨D, hD, hcard⟩ := exists_actual_finite_band_quadratic_card N hN
  refine ⟨D * A * C, by positivity, ?_⟩
  intro L hL s hs a b ha hb p hp q hq
  have hW : 0 ≤ 1 + L := by linarith
  have hterm : ∀ i ∈ s,
      ‖testPartial a (actualCuspPlanarProfile N hN i) p *
        star (testPartial b (actualCuspPlanarProfile N hN i) q)‖ ≤
          (A * C) * (1 + L) ^ (k + l + 4) := by
    intro i hi
    have hi0 : 0 ≤ 1 + actualCuspNativeEigenvalue N hN i := by
      linarith [actualCuspNativeEigenvalue_nonneg N hN i]
    have hiL : 1 + actualCuspNativeEigenvalue N hN i ≤ 1 + L :=
      add_le_add_left (hs i hi) 1
    have hleft := (hjetA i a ha p hp).trans
      (mul_le_mul_of_nonneg_left (pow_le_pow_left₀ hi0 hiL (k + 2)) hA)
    have hright := (hjetC i b hb q hq).trans
      (mul_le_mul_of_nonneg_left (pow_le_pow_left₀ hi0 hiL (l + 2)) hC)
    calc
      _ = ‖testPartial a (actualCuspPlanarProfile N hN i) p‖ *
          ‖testPartial b (actualCuspPlanarProfile N hN i) q‖ := by
        rw [norm_mul, norm_star]
      _ ≤ (A * (1 + L) ^ (k + 2)) * (C * (1 + L) ^ (l + 2)) :=
        mul_le_mul hleft hright (norm_nonneg _) (by positivity)
      _ = (A * C) * (1 + L) ^ (k + l + 4) := by
        simp only [pow_add]
        ring
  calc
    _ ≤ ∑ _i ∈ s, (A * C) * (1 + L) ^ (k + l + 4) :=
      Finset.sum_le_sum hterm
    _ = (s.card : ℝ) * ((A * C) * (1 + L) ^ (k + l + 4)) := by
      simp [Finset.sum_const, nsmul_eq_mul]
    _ ≤ (D * (1 + L) ^ 2) * ((A * C) * (1 + L) ^ (k + l + 4)) :=
      mul_le_mul_of_nonneg_right (hcard L hL s hs) (by positivity)
    _ = (D * A * C) * (1 + L) ^ (k + l + 6) := by
      simp only [pow_add]
      ring

-- A bounded primitive multiplier on a finite band pays only its supremum.
-- This hypothesis supplies coefficient values, never a kernel conclusion.
theorem exists_actual_finite_band_weighted_jet_budget
    (N : ℕ) [NeZero N] (hN : 0 < N) (k l : ℕ)
    (K Q : Set (ℝ × ℝ)) (hK : IsCompact K) (hQ : IsCompact Q)
    (hKpos : K ⊆ CanonicalTensorHyperbolicLaplacianForm20261024z.upperChart)
    (hQpos : Q ⊆ CanonicalTensorHyperbolicLaplacianForm20261024z.upperChart) :
    ∃ B : ℝ, 0 ≤ B ∧ ∀ L : ℝ, 0 ≤ L →
      ∀ s : Finset (actualCuspBasisIndex N hN),
      (∀ i ∈ s, actualCuspNativeEigenvalue N hN i ≤ L) →
      ∀ w : actualCuspBasisIndex N hN → ℂ, ∀ M : ℝ, 0 ≤ M →
      (∀ i ∈ s, ‖w i‖ ≤ M) →
      ∀ a b : MultiIndex, a.1 + a.2 ≤ k → b.1 + b.2 ≤ l →
      ∀ p ∈ K, ∀ q ∈ Q,
      ‖∑ i ∈ s, w i * (testPartial a (actualCuspPlanarProfile N hN i) p *
        star (testPartial b (actualCuspPlanarProfile N hN i) q))‖ ≤
          M * (B * (1 + L) ^ (k + l + 6)) := by
  classical
  obtain ⟨B, hB, hbudget⟩ := exists_actual_finite_band_absolute_jet_budget
    N hN k l K Q hK hQ hKpos hQpos
  refine ⟨B, hB, ?_⟩
  intro L hL s hs w M hM hw a b ha hb p hp q hq
  calc
    _ ≤ ∑ i ∈ s, ‖w i * (testPartial a (actualCuspPlanarProfile N hN i) p *
        star (testPartial b (actualCuspPlanarProfile N hN i) q))‖ := norm_sum_le _ _
    _ ≤ ∑ i ∈ s, M * ‖testPartial a (actualCuspPlanarProfile N hN i) p *
        star (testPartial b (actualCuspPlanarProfile N hN i) q)‖ := by
      apply Finset.sum_le_sum
      intro i hi
      rw [norm_mul]
      exact mul_le_mul_of_nonneg_right (hw i hi) (norm_nonneg _)
    _ = M * (∑ i ∈ s, ‖testPartial a (actualCuspPlanarProfile N hN i) p *
        star (testPartial b (actualCuspPlanarProfile N hN i) q)‖) := by
      rw [Finset.mul_sum]
    _ ≤ _ := mul_le_mul_of_nonneg_left (hbudget L hL s hs a b ha hb p hp q hq) hM

-- The literal unweighted finite two-point kernel inherits the same budget.
theorem exists_actual_finite_band_kernel_jet_budget
    (N : ℕ) [NeZero N] (hN : 0 < N) (k l : ℕ)
    (K Q : Set (ℝ × ℝ)) (hK : IsCompact K) (hQ : IsCompact Q)
    (hKpos : K ⊆ CanonicalTensorHyperbolicLaplacianForm20261024z.upperChart)
    (hQpos : Q ⊆ CanonicalTensorHyperbolicLaplacianForm20261024z.upperChart) :
    ∃ B : ℝ, 0 ≤ B ∧ ∀ L : ℝ, 0 ≤ L →
      ∀ s : Finset (actualCuspBasisIndex N hN),
      (∀ i ∈ s, actualCuspNativeEigenvalue N hN i ≤ L) →
      ∀ a b : MultiIndex, a.1 + a.2 ≤ k → b.1 + b.2 ≤ l →
      ∀ p ∈ K, ∀ q ∈ Q,
      ‖actualCuspFiniteJetKernel N hN s a b p q‖ ≤
        B * (1 + L) ^ (k + l + 6) := by
  obtain ⟨B, hB, hbudget⟩ := exists_actual_finite_band_weighted_jet_budget
    N hN k l K Q hK hQ hKpos hQpos
  refine ⟨B, hB, ?_⟩
  intro L hL s hs a b ha hb p hp q hq
  simpa only [actualCuspFiniteJetKernel, one_mul] using
    hbudget L hL s hs (fun _ => (1 : ℂ)) 1 (by norm_num)
      (by intro i hi; simp) a b ha hb p hp q hq

end
end ImbalancedChen.Part3.ActualCuspFiniteBandJetBudget20261027
