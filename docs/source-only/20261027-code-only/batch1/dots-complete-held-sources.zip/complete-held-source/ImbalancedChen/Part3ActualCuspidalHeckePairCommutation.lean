import ImbalancedChen.Part3ActualCuspidalHeckeRestriction
import ImbalancedChen.Part3ActualBoundedHeckePairCommutation

-- SOURCE_ONLY / UNCOMPILED / ZERO_FORMAL_CREDIT.
-- The original quotient L2 commutation is already supplied by 3fc73c.
-- This leaf constructs its missing action on the SAME full cusp space,
-- including a single commuting family indexed by actual good primes.
-- Its inherited full cusp operator dependencies remain on the Dots hold.

namespace ImbalancedChen.Part3.ActualCuspidalHeckePairCommutation20261027
noncomputable section
open MeasureTheory
open Gamma0ActualSmoothQuotientCore20261025a Gamma0QuotientCellPushforward20261025a
open ActualBoundedPhysicalHecke20261026b ActualBoundedHeckePairCommutation20261026b
open ActualCuspidalHeckeRestriction20261026b ActualFullCuspResolvent20261026b
open ActualPrimeHeckeQuotientDescent20261026b ActualPhysicalHeckeL220261026b

variable (N p q : ℕ) [NeZero N] [NeZero (N*p)] [NeZero (N*q)]
  (hN : 0 < N) (hp : p.Prime) (hq : q.Prime) (hpN : ¬ p ∣ N) (hqN : ¬ q ∣ N)

-- The restriction keeps the actual canonical quotient representative.
theorem actualCuspHeckeOperator_coe_ae (f : ActualFullCuspL2 N hN) :
    ((actualCuspHeckeOperator N p hN hp hpN f : QuotientL2 N) :
      Gamma0OrbitSpace N → ℂ) =ᵐ[carrierPushforward N]
        quotientHecke N p hp hpN (f : QuotientL2 N) :=
  physicalHeckeOperator_coe N p hN hp hpN (f : QuotientL2 N)

-- Representative substitution is paid by the genuine quotient trace
-- congruence theorem, which already contains the actual null set transfer.
theorem actualCuspHeckeOperator_comp_coe_ae (f : ActualFullCuspL2 N hN) :
    ((actualCuspHeckeOperator N p hN hp hpN
      (actualCuspHeckeOperator N q hN hq hqN f) : QuotientL2 N) :
        Gamma0OrbitSpace N → ℂ) =ᵐ[carrierPushforward N]
      quotientHecke N p hp hpN
        (quotientHecke N q hq hqN (f : QuotientL2 N)) := by
  have houter := actualCuspHeckeOperator_coe_ae N p hN hp hpN
    (actualCuspHeckeOperator N q hN hq hqN f)
  have hinner := quotientHecke_congr_ae N p hN hp hpN
    (actualCuspHeckeOperator N q hN hq hqN f : QuotientL2 N)
    (quotientHecke N q hq hqN (f : QuotientL2 N))
    (actualCuspHeckeOperator N q hN hq hqN f : QuotientL2 N).stronglyMeasurable.measurable
    (quotientHecke_measurable N q hq hqN (f : QuotientL2 N)
      (f : QuotientL2 N).stronglyMeasurable.measurable)
    (actualCuspHeckeOperator_coe_ae N q hN hq hqN f)
  exact houter.trans hinner

-- Pointwise finite arithmetic is transferred to native full cusp L2;
-- no commutation or bounded realization premise is introduced.
theorem actualCuspHeckeOperator_coprime_comp_eq (hpq : Nat.Coprime p q) :
    (actualCuspHeckeOperator N p hN hp hpN).comp
        (actualCuspHeckeOperator N q hN hq hqN) =
      (actualCuspHeckeOperator N q hN hq hqN).comp
        (actualCuspHeckeOperator N p hN hp hpN) := by
  apply ContinuousLinearMap.ext
  intro f
  apply Subtype.ext
  apply Lp.ext
  have hleft := actualCuspHeckeOperator_comp_coe_ae N p q hN hp hq hpN hqN f
  have hright := actualCuspHeckeOperator_comp_coe_ae N q p hN hq hp hqN hpN f
  rw [quotientHecke_coprime_commute N p q hp hq hpN hqN hpq (f : QuotientL2 N)] at hleft
  exact hleft.trans hright.symm

theorem actualCuspHeckeOperator_coprime_commute (hpq : Nat.Coprime p q) :
    Commute (actualCuspHeckeOperator N p hN hp hpN)
      (actualCuspHeckeOperator N q hN hq hqN) :=
  actualCuspHeckeOperator_coprime_comp_eq N p q hN hp hq hpN hqN hpq

theorem actualCuspHeckeOperator_distinct_good_primes_commute (hne : p ≠ q) :
    Commute (actualCuspHeckeOperator N p hN hp hpN)
      (actualCuspHeckeOperator N q hN hq hqN) := by
  have hnot : ¬ p ∣ q := by
    intro hd
    rcases (Nat.dvd_prime hq).mp hd with h1 | heq
    · exact hp.ne_one h1
    · exact hne heq
  exact actualCuspHeckeOperator_coprime_commute N p q hN hp hq hpN hqN
    (hp.coprime_iff_not_dvd.mpr hnot)

-- The actual normalization survives the restriction with no new bound.
theorem actualCuspHeckeOperator_norm_le :
    ‖actualCuspHeckeOperator N p hN hp hpN‖ ≤ (p+1 : ℝ) / Real.sqrt (p : ℝ) :=
  (actualCuspHeckeOperator_opNorm_le N p hN hp hpN).trans
    (physicalHeckeOperator_norm_le N p hN hp hpN)

theorem actualCuspHeckeOperator_comp_norm_le :
    ‖(actualCuspHeckeOperator N p hN hp hpN).comp
      (actualCuspHeckeOperator N q hN hq hqN)‖ ≤
      ((p+1 : ℝ) / Real.sqrt (p : ℝ)) * ((q+1 : ℝ) / Real.sqrt (q : ℝ)) := by
  exact (ContinuousLinearMap.opNorm_comp_le _ _).trans
    (mul_le_mul (actualCuspHeckeOperator_norm_le N p hN hp hpN)
      (actualCuspHeckeOperator_norm_le N q hN hq hqN) (norm_nonneg _)
      (div_nonneg (by positivity) (Real.sqrt_nonneg _)))

-- Native finite families no longer require a separate N*p instance
-- from their consumer: positivity constructs it for every good prime.
def GoodPrime (N : ℕ) := {p : ℕ // p.Prime ∧ ¬ p ∣ N}

def goodPrimeHecke (N : ℕ) [NeZero N] (hN : 0 < N) (p : GoodPrime N) :
    ActualFullCuspL2 N hN →L[ℂ] ActualFullCuspL2 N hN := by
  letI : NeZero (N*p.val) := ⟨(Nat.mul_pos hN p.property.1.pos).ne'⟩
  exact actualCuspHeckeOperator N p.val hN p.property.1 p.property.2

theorem goodPrimeHecke_coe (N : ℕ) [NeZero N] (hN : 0 < N)
    (p : GoodPrime N) (f : ActualFullCuspL2 N hN) :
    ((goodPrimeHecke N hN p f : QuotientL2 N) : Gamma0OrbitSpace N → ℂ)
      =ᵐ[carrierPushforward N] quotientHecke N p.val p.property.1 p.property.2
        (f : QuotientL2 N) := by
  letI : NeZero (N*p.val) := ⟨(Nat.mul_pos hN p.property.1.pos).ne'⟩
  exact actualCuspHeckeOperator_coe_ae N p.val hN p.property.1 p.property.2 f

-- This includes the equal-prime case. It is a single actual commuting
-- family on the full cusp Hilbert space, independent of spectral type.
theorem goodPrimeHecke_commute (N : ℕ) [NeZero N] (hN : 0 < N)
    (p q : GoodPrime N) : Commute (goodPrimeHecke N hN p) (goodPrimeHecke N hN q) := by
  by_cases heq : p.val = q.val
  · have hsub : p = q := Subtype.ext heq
    subst q
    exact Commute.refl _
  · letI : NeZero (N*p.val) := ⟨(Nat.mul_pos hN p.property.1.pos).ne'⟩
    letI : NeZero (N*q.val) := ⟨(Nat.mul_pos hN q.property.1.pos).ne'⟩
    exact actualCuspHeckeOperator_distinct_good_primes_commute N p.val q.val hN
      p.property.1 q.property.1 p.property.2 q.property.2 heq

theorem goodPrimeHecke_norm_le (N : ℕ) [NeZero N] (hN : 0 < N) (p : GoodPrime N) :
    ‖goodPrimeHecke N hN p‖ ≤ (p.val+1 : ℝ) / Real.sqrt (p.val : ℝ) := by
  letI : NeZero (N*p.val) := ⟨(Nat.mul_pos hN p.property.1.pos).ne'⟩
  exact actualCuspHeckeOperator_norm_le N p.val hN p.property.1 p.property.2

theorem goodPrimeHecke_actualResolvent_commute (N : ℕ) [NeZero N] (hN : 0 < N)
    (p : GoodPrime N) (f : ActualFullCuspL2 N hN) :
    actualFullCuspResolvent N hN (goodPrimeHecke N hN p f) =
      goodPrimeHecke N hN p (actualFullCuspResolvent N hN f) := by
  letI : NeZero (N*p.val) := ⟨(Nat.mul_pos hN p.property.1.pos).ne'⟩
  exact actualFullCuspResolvent_Hecke_commute N p.val hN p.property.1 p.property.2 f

end
end ImbalancedChen.Part3.ActualCuspidalHeckePairCommutation20261027
