import ImbalancedChen.Part3Gamma0ActualSigmaHeatResolvent
import ImbalancedChen.Part3ActualCuspEigenbasisNativeLabels
import ImbalancedChen.Part3ActualAllFrameHeatResolventReduction

-- SOURCE ONLY / UNCOMPILED_ZERO_CREDIT / READY_FALSE.
-- The existing native heat operator is evaluated on the constructed genuine
-- cusp ONB. The native graph, rather than an assumed heat diagonalization,
-- forces its original Sigma coordinates to have the stated support.
-- Transitive immutable Dots API holds remain in force.
namespace ImbalancedChen.Part3.ActualCuspHeatNativeDiagonal20261027
noncomputable section
open Set MeasureTheory
open Gamma0ActualSmoothQuotientCore20261025a
open Gamma0ActualFriedrichsOperator20261025a Gamma0ActualHeatGenerator20261025a
open Gamma0ActualSigmaPlancherel20261025a Gamma0ActualSigmaHeatResolvent20261025a
open ActualFullCuspResolvent20261026b ActualFullCuspEigenbasis20261026b
open ActualCuspEigenbasisNativeLabels20261026b
open ActualAllFrameHeatResolventReduction20261026b

theorem actual_native_eigenvector_heat_apply (N : ℕ) [NeZero N]
    (u : QuotientL2 N) (λ : ℝ)
    (hu : (u, (λ : ℂ) • u) ∈ (actualGammaFriedrichs N).graph)
    {t : ℝ} (ht : 0 ≤ t) :
    actualGammaHeat N t u = (Real.exp (-t * λ) : ℂ) • u := by
  apply (actualSigmaPlancherel N).injective
  rw [map_smul]
  apply Lp.ext
  have hg := (actualGammaFriedrichs_sigma_graph_iff_lambda N u ((λ : ℂ) • u)).mp hu
  rw [map_smul] at hg
  filter_upwards [actualGammaHeat_sigma_action_ae N ht u, hg,
    Lp.coeFn_smul (λ : ℂ) (actualSigmaPlancherel N u),
    Lp.coeFn_smul (Real.exp (-t * λ) : ℂ) (actualSigmaPlancherel N u)]
    with s hs hgraph hλ hout
  rw [hλ] at hgraph
  rw [hs, hout]
  change (Real.exp (-t * actualSigmaLambda N s) : ℂ) *
    actualSigmaPlancherel N u s =
      (Real.exp (-t * λ) : ℂ) * actualSigmaPlancherel N u s
  by_cases he : actualSigmaLambda N s = λ
  · rw [he]
  · have hmul : ((λ : ℂ) - (actualSigmaLambda N s : ℂ)) *
        actualSigmaPlancherel N u s = 0 := by
      change (λ : ℂ) * actualSigmaPlancherel N u s =
        (actualSigmaLambda N s : ℂ) * actualSigmaPlancherel N u s at hgraph
      linear_combination hgraph
    have hne : (λ : ℂ) - (actualSigmaLambda N s : ℂ) ≠ 0 := by
      intro hz
      exact he (Complex.ofReal_injective (sub_eq_zero.mp hz)).symm
    rw [(mul_eq_zero.mp hmul).resolve_left hne]
    simp

-- This evaluates the restriction of the ORIGINAL actual Gamma heat.
theorem actualFullCuspHeat_basis_apply (N : ℕ) [NeZero N] (hN : 0 < N)
    {t : ℝ} (ht : 0 ≤ t) (i : actualCuspBasisIndex N hN) :
    actualFullCuspHeat N hN t (actualCuspHilbertBasis N hN i) =
      (Real.exp (-t * actualCuspNativeEigenvalue N hN i) : ℂ) •
        actualCuspHilbertBasis N hN i := by
  apply Subtype.ext
  exact actual_native_eigenvector_heat_apply N _ _
    (actualCuspHilbertBasis_original_friedrichs_graph N hN i) ht

theorem actualFullCuspHeat_basis_norm (N : ℕ) [NeZero N] (hN : 0 < N)
    {t : ℝ} (ht : 0 ≤ t) (i : actualCuspBasisIndex N hN) :
    ‖actualFullCuspHeat N hN t (actualCuspHilbertBasis N hN i)‖ =
      Real.exp (-t * actualCuspNativeEigenvalue N hN i) := by
  rw [actualFullCuspHeat_basis_apply N hN ht i, norm_smul,
    actualCuspHilbertBasis_norm N hN i, mul_one, Complex.norm_real,
    Real.norm_eq_abs, abs_of_pos (Real.exp_pos _)]

theorem actualFullCuspHeat_basis_diagonal (N : ℕ) [NeZero N] (hN : 0 < N)
    {t : ℝ} (ht : 0 ≤ t) (i : actualCuspBasisIndex N hN) :
    inner ℂ (actualCuspHilbertBasis N hN i)
      (actualFullCuspHeat N hN t (actualCuspHilbertBasis N hN i)) =
        (Real.exp (-t * actualCuspNativeEigenvalue N hN i) : ℂ) := by
  rw [actualFullCuspHeat_basis_apply N hN ht i, inner_smul_right]
  have hi : inner ℂ (actualCuspHilbertBasis N hN i)
      (actualCuspHilbertBasis N hN i) = 1 := by
    rw [inner_self_eq_norm_sq_to_K, actualCuspHilbertBasis_norm N hN i]
    norm_num
  rw [hi, mul_one]

-- The genuine squared image norms have the doubled native time.
theorem actualFullCuspHeat_basis_norm_sq (N : ℕ) [NeZero N] (hN : 0 < N)
    {t : ℝ} (ht : 0 ≤ t) (i : actualCuspBasisIndex N hN) :
    ‖actualFullCuspHeat N hN t (actualCuspHilbertBasis N hN i)‖ ^ 2 =
      Real.exp (-(2 * t) * actualCuspNativeEigenvalue N hN i) := by
  rw [actualFullCuspHeat_basis_norm N hN ht i, pow_two, ← Real.exp_add]
  congr 1
  ring

end
end ImbalancedChen.Part3.ActualCuspHeatNativeDiagonal20261027
