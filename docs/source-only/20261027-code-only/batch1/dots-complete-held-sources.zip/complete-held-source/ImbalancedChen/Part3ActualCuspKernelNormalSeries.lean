import ImbalancedChen.Part3ActualCuspSmoothEigenprofileFamily
import ImbalancedChen.Part3ActualCuspSpectralWeightSummability
import ImbalancedChen.Part3SmoothMixedSpectralKernelSeries

-- SOURCE ONLY. UNCOMPILED_ZERO_CREDIT. Transitive actual spectral API holds retained.
-- The only analytic test hypothesis is scalar rapid decay on the nonnegative axis.
-- All basis, eigenvalue, multiplicity-count and compact-jet inputs are supplied.
-- This is the literal original cuspidal spectral series, with its original index.
-- Identifying its integral operator with Borel functional calculus is a later step.
namespace ImbalancedChen.Part3.ActualCuspKernelNormalSeries20261027
noncomputable section
open Set Filter
open scoped Topology BigOperators
open CompactC2ProductMollifier20261026a PlanarWeakDifferentialMultiindex20261026b
open ActualFullCuspEigenbasis20261026b ActualCuspEigenbasisNativeLabels20261026b
open Gamma0ActualSmoothQuotientCore20261025a
open ActualCuspSmoothEigenprofileFamily20261026b ActualCuspSpectralWeightSummability20261026b
open RapidSpectralCoefficientWeights20261026b MixedSpectralKernelNormalConvergence20261026b
open SmoothMixedSpectralKernelSeries20261026b

def actualCuspKernelTerm (N : ℕ) [NeZero N] (hN : 0 < N) (h : ℝ → ℂ)
    (i : actualCuspBasisIndex N hN) (p : PairPlane) : ℂ :=
  mixedKernelTerm h (actualCuspNativeEigenvalue N hN)
    (actualCuspPlanarProfile N hN) (0,0) (0,0) i p

def actualCuspKernel (N : ℕ) [NeZero N] (hN : 0 < N) (h : ℝ → ℂ)
    (p : PairPlane) : ℂ :=
  mixedKernelSeries h (actualCuspNativeEigenvalue N hN)
    (actualCuspPlanarProfile N hN) (0,0) (0,0) p

theorem actualCuspProfile_compactJetGrowth (N : ℕ) [NeZero N] (hN : 0 < N) :
    CompactJetGrowth (actualCuspNativeEigenvalue N hN)
      (actualCuspPlanarProfile N hN) upperChart := by
  intro k K hK hKO
  exact exists_uniform_actual_cusp_profile_compact_jet_bound N hN k K hK hKO

theorem actualCuspNative_inverseCubic (N : ℕ) [NeZero N] (hN : 0 < N) :
    InverseCubicSummable (actualCuspNativeEigenvalue N hN) := by
  apply inverseCubic_of_rpow (actualCuspNativeEigenvalue_nonneg N hN)
  exact actualCuspNativeEigenvalue_inverse_weight_summable N hN 3 (by norm_num)

private theorem upperChart_isOpen : IsOpen upperChart :=
  isOpen_lt continuous_const continuous_snd

theorem actualCuspKernel_mixedJet_majorant (N : ℕ) [NeZero N] (hN : 0 < N)
    {h : ℝ → ℂ} (hh : RapidOnNonnegative h) (a b : MultiIndex)
    {K L : Set Plane} (hK : IsCompact K) (hL : IsCompact L)
    (hKO : K ⊆ upperChart) (hLO : L ⊆ upperChart) :
    ∃ u : actualCuspBasisIndex N hN → ℝ, Summable u ∧ (∀ i, 0 ≤ u i) ∧
      ∀ i p, p ∈ K ×ˢ L →
        ‖mixedKernelTerm h (actualCuspNativeEigenvalue N hN)
          (actualCuspPlanarProfile N hN) a b i p‖ ≤ u i :=
  mixedKernel_normal_majorant (actualCuspNativeEigenvalue_nonneg N hN)
    (actualCuspNative_inverseCubic N hN) (actualCuspProfile_compactJetGrowth N hN)
    hh a b hK hL hKO hLO

theorem actualCuspKernel_contDiffOn (N : ℕ) [NeZero N] (hN : 0 < N)
    {h : ℝ → ℂ} (hh : RapidOnNonnegative h) :
    ContDiffOn ℝ ∞ (actualCuspKernel N hN h) (upperChart ×ˢ upperChart) :=
  mixedKernelSeries_contDiffOn (actualCuspNativeEigenvalue_nonneg N hN)
    (actualCuspNative_inverseCubic N hN) upperChart_isOpen
    (fun i => (actualCuspSmoothProfile_spec N hN i).1)
    (actualCuspProfile_compactJetGrowth N hN) hh (0,0) (0,0)

theorem actualCuspKernel_all_derivatives_termwise (N : ℕ) [NeZero N] (hN : 0 < N)
    {h : ℝ → ℂ} (hh : RapidOnNonnegative h) (w : List (Fin 4))
    {p : PairPlane} (hp : p ∈ upperChart ×ˢ upperChart) :
    pairWordPartial w (actualCuspKernel N hN h) p =
      ∑' i, pairWordPartial w (actualCuspKernelTerm N hN h i) p :=
  kernelSeries_all_mixed_derivatives_termwise (actualCuspNativeEigenvalue_nonneg N hN)
    (actualCuspNative_inverseCubic N hN) upperChart_isOpen
    (fun i => (actualCuspSmoothProfile_spec N hN i).1)
    (actualCuspProfile_compactJetGrowth N hN) hh w hp

-- This states convergence for genuine classical differentiated summands.
-- There is no normal-convergence premise and no derivative bound supplied by a caller.
theorem actualCuspKernel_all_derivatives_normal (N : ℕ) [NeZero N] (hN : 0 < N)
    {h : ℝ → ℂ} (hh : RapidOnNonnegative h) (w : List (Fin 4))
    {K L : Set Plane} (hK : IsCompact K) (hL : IsCompact L)
    (hKO : K ⊆ upperChart) (hLO : L ⊆ upperChart) :
    TendstoUniformlyOn
      (fun s : Finset (actualCuspBasisIndex N hN) => fun p =>
        ∑ i ∈ s, pairWordPartial w (actualCuspKernelTerm N hN h i) p)
      (fun p => ∑' i, pairWordPartial w (actualCuspKernelTerm N hN h i) p)
      atTop (K ×ˢ L) ∧
    ∀ p ∈ K ×ˢ L, pairWordPartial w (actualCuspKernel N hN h) p =
      ∑' i, pairWordPartial w (actualCuspKernelTerm N hN h i) p :=
  kernelSeries_all_mixed_derivatives_normal (actualCuspNativeEigenvalue_nonneg N hN)
    (actualCuspNative_inverseCubic N hN) upperChart_isOpen
    (fun i => (actualCuspSmoothProfile_spec N hN i).1)
    (actualCuspProfile_compactJetGrowth N hN) hh w hK hL hKO hLO

theorem actualCuspKernel_derivative_summable (N : ℕ) [NeZero N] (hN : 0 < N)
    {h : ℝ → ℂ} (hh : RapidOnNonnegative h) (w : List (Fin 4))
    {p : PairPlane} (hp : p ∈ upperChart ×ˢ upperChart) :
    Summable (fun i => ‖pairWordPartial w (actualCuspKernelTerm N hN h i) p‖) := by
  obtain ⟨u, hu, hu0, hb⟩ := actualCuspKernel_mixedJet_majorant N hN hh
    (wordIndex w).1 (wordIndex w).2
    (isCompact_singleton (x := p.1)) (isCompact_singleton (x := p.2))
    (singleton_subset_iff.mpr hp.1) (singleton_subset_iff.mpr hp.2)
  apply Summable.of_nonneg_of_le (fun i => norm_nonneg _) _ hu
  intro i
  change ‖pairWordPartial w
    (mixedKernelTerm h (actualCuspNativeEigenvalue N hN)
      (actualCuspPlanarProfile N hN) (0,0) (0,0) i) p‖ ≤ u i
  rw [pairWordPartial_kernelTerm upperChart_isOpen
    (fun j => (actualCuspSmoothProfile_spec N hN j).1) h
    (actualCuspNativeEigenvalue N hN) w i hp]
  exact hb i p ⟨rfl, rfl⟩

end
end ImbalancedChen.Part3.ActualCuspKernelNormalSeries20261027
