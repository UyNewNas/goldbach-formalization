import ImbalancedChen.Part3NativeAllCuspEisenstein

-- SOURCE ONLY / UNCOMPILED / ZERO FORMAL CREDIT.
-- Literal native first-half-plane domination, with the original allowed rows,
-- actual width, and central factor 1/2. This supplies a Mellin-integral majorant.
-- No continuation, L2 membership, scattering, or completeness is asserted.

namespace ImbalancedChen.Part3.NativeAllCuspEisenstein20261027

noncomputable section
open Set Filter Complex UpperHalfPlane EisensteinSeries Matrix
open scoped UpperHalfPlane MatrixGroups Topology BigOperators
open ImbalancedChen.Part3.PrimitiveEisensteinParameterAnalytic
open ImbalancedChen.Part3.NativeAllCuspEisenstein20261026b

-- The row mass is the exact norm of the native seed on the entire vertical line.
def rowMass (N : ℕ) (g : SL(2, ℤ)) (z : ℍ) (v : PrimitivePair) (σ : ℝ) : ℝ :=
  Real.exp (σ * Real.log (normalizedBase N g z v))

def realEnvelope (N : ℕ) (g : SL(2, ℤ)) (σ : ℝ) (z : ℍ) : ℝ :=
  (1 / 2 : ℝ) * ∑' v : AllowedPair N g, rowMass N g z v.1 σ

theorem rowMass_pos (N : ℕ) (g : SL(2, ℤ)) (z : ℍ)
    (v : PrimitivePair) (σ : ℝ) : 0 < rowMass N g z v σ :=
  Real.exp_pos _

theorem norm_normalizedSeed_eq_rowMass (N : ℕ) (g : SL(2, ℤ))
    (z : ℍ) (v : PrimitivePair) (s : ℂ) :
    ‖normalizedSeed N g z v s‖ = rowMass N g z v s.re := by
  simp [normalizedSeed, rowMass, Complex.norm_exp, Complex.mul_re]

theorem normalizedSeed_real_eq_rowMass (N : ℕ) (g : SL(2, ℤ))
    (z : ℍ) (v : PrimitivePair) (σ : ℝ) :
    normalizedSeed N g z v (σ : ℂ) = (rowMass N g z v σ : ℂ) := by
  rw [normalizedSeed, rowMass, Complex.ofReal_exp, Complex.ofReal_mul]

theorem rowMass_summable (N : ℕ) (hN : 0 < N) (g : SL(2, ℤ))
    (z : ℍ) (σ : ℝ) (hσ : 1 < σ) :
    Summable (fun v : AllowedPair N g => rowMass N g z v.1 σ) := by
  simpa only [norm_normalizedSeed_eq_rowMass, Complex.ofReal_re] using
    normalizedSeed_norm_summable N hN g z (σ : ℂ) hσ

theorem realEnvelope_nonneg (N : ℕ) (g : SL(2, ℤ)) (σ : ℝ) (z : ℍ) :
    0 ≤ realEnvelope N g σ z := by
  apply mul_nonneg (by norm_num)
  exact tsum_nonneg fun v => (rowMass_pos N g z v.1 σ).le

-- This identity keeps the majorant tied to the actual native series.
theorem cuspEisenstein_real_eq_realEnvelope (N : ℕ) (g : SL(2, ℤ))
    (σ : ℝ) (z : ℍ) :
    cuspEisenstein N g (σ : ℂ) z = (realEnvelope N g σ z : ℂ) := by
  simp only [cuspEisenstein, realEnvelope, normalizedSeed_real_eq_rowMass,
    Complex.ofReal_mul, Complex.ofReal_div, Complex.ofReal_one, Complex.ofReal_ofNat,
    Complex.ofReal_tsum]

theorem cuspEisenstein_real_re (N : ℕ) (g : SL(2, ℤ))
    (σ : ℝ) (z : ℍ) :
    (cuspEisenstein N g (σ : ℂ) z).re = realEnvelope N g σ z := by
  rw [cuspEisenstein_real_eq_realEnvelope, Complex.ofReal_re]

theorem cuspEisenstein_real_im (N : ℕ) (g : SL(2, ℤ))
    (σ : ℝ) (z : ℍ) :
    (cuspEisenstein N g (σ : ℂ) z).im = 0 := by
  rw [cuspEisenstein_real_eq_realEnvelope, Complex.ofReal_im]

-- The triangle inequality uses the proved native summability, rather than a
-- supplied domination hypothesis about the final series.
theorem norm_cuspEisenstein_le_realEnvelope (N : ℕ) (hN : 0 < N)
    (g : SL(2, ℤ)) (s : ℂ) (hs : 1 < s.re) (z : ℍ) :
    ‖cuspEisenstein N g s z‖ ≤ realEnvelope N g s.re z := by
  have hsum := normalizedSeed_norm_summable N hN g z s hs
  rw [cuspEisenstein, norm_mul]
  have hhalf : ‖(1 / 2 : ℂ)‖ = (1 / 2 : ℝ) := by norm_num
  rw [hhalf, realEnvelope]
  apply mul_le_mul_of_nonneg_left _ (by norm_num)
  simpa only [norm_normalizedSeed_eq_rowMass] using norm_tsum_le_tsum_norm hsum

theorem norm_cuspEisenstein_vertical_le (N : ℕ) (hN : 0 < N)
    (g : SL(2, ℤ)) (σ : ℝ) (hσ : 1 < σ) (t : ℝ) (z : ℍ) :
    ‖cuspEisenstein N g ((σ : ℂ) + (t : ℂ) * Complex.I) z‖ ≤
      (cuspEisenstein N g (σ : ℂ) z).re := by
  rw [cuspEisenstein_real_re]
  have hs : 1 < ((σ : ℂ) + (t : ℂ) * Complex.I).re := by simpa using hσ
  simpa using norm_cuspEisenstein_le_realEnvelope N hN g
    ((σ : ℂ) + (t : ℂ) * Complex.I) hs z

-- Schwarz symmetry is a direct identity of the same signed-row series.
theorem normalizedSeed_conj (N : ℕ) (g : SL(2, ℤ))
    (z : ℍ) (v : PrimitivePair) (s : ℂ) :
    normalizedSeed N g z v (conj s) = conj (normalizedSeed N g z v s) := by
  simp only [normalizedSeed, ← Complex.exp_conj, map_mul, Complex.conj_ofReal]

theorem cuspEisenstein_conj (N : ℕ) (g : SL(2, ℤ)) (s : ℂ) (z : ℍ) :
    cuspEisenstein N g (conj s) z = conj (cuspEisenstein N g s z) := by
  simp only [cuspEisenstein, map_mul, map_div₀, map_one, map_ofNat,
    Complex.conj_tsum, normalizedSeed_conj]

end
end ImbalancedChen.Part3.NativeAllCuspEisenstein20261027