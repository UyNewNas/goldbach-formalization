import ImbalancedChen.Part3ActualCuspBoundedBorelMultiplier
import Mathlib.MeasureTheory.Function.L2Space

-- SOURCE ONLY / UNCOMPILED_ZERO_CREDIT / TRANSITIVE DOTS API HOLD.
-- Literal finite quotient kernels and their strong integral reconstruction
-- of the ORIGINAL Borel functional calculus. No new operator is defined.
-- The final smooth infinite kernel and its integral interchange remain OPEN.

namespace ImbalancedChen.Part3.ActualCuspFiniteKernelAction20261027
noncomputable section
open Set Filter MeasureTheory
open Gamma0QuotientCellPushforward20261025a
open Gamma0ActualSmoothQuotientCore20261025a Gamma0ActualWeakRieszResolvent20261025a
open AllNormalizedCuspAnnihilator20261026b ActualFullCuspResolvent20261026b
open ActualFullCuspEigenbasis20261026b ActualCuspEigenbasisNativeLabels20261026b
open GenericBoundedBorelCalculus20261025a ActualCuspBoundedBorelMultiplier20261026b

def actualCuspFiniteKernel (N : ℕ) [NeZero N] (hN : 0 < N)
    (h : BoundedBorelFunction ℝ) (s : Finset (actualCuspBasisIndex N hN))
    (q r : Gamma0OrbitSpace N) : ℂ :=
  ∑ i ∈ s, h (actualCuspNativeEigenvalue N hN i) *
    (actualCuspHilbertBasis N hN i : QuotientL2 N) q *
    star ((actualCuspHilbertBasis N hN i : QuotientL2 N) r)

theorem actualCusp_coefficient_integral (N : ℕ) [NeZero N] (hN : 0 < N)
    (f : ActualFullCuspL2 N hN) (i : actualCuspBasisIndex N hN) :
    (actualCuspHilbertBasis N hN).repr f i =
      ∫ r, star ((actualCuspHilbertBasis N hN i : QuotientL2 N) r) *
        (f : QuotientL2 N) r ∂carrierPushforward N := by
  rw [(actualCuspHilbertBasis N hN).repr_apply_apply]
  change inner ℂ (actualCuspHilbertBasis N hN i : QuotientL2 N)
    (f : QuotientL2 N) = _
  simp only [L2.inner_def, RCLike.inner_apply']

theorem actualCusp_coefficient_integrable (N : ℕ) [NeZero N] (hN : 0 < N)
    (f : ActualFullCuspL2 N hN) (i : actualCuspBasisIndex N hN) :
    Integrable (fun r => star ((actualCuspHilbertBasis N hN i : QuotientL2 N) r) *
      (f : QuotientL2 N) r) (carrierPushforward N) := by
  simpa only [RCLike.inner_apply'] using
    (L2.integrable_inner (𝕜 := ℂ) (actualCuspHilbertBasis N hN i : QuotientL2 N)
      (f : QuotientL2 N))

theorem actualCuspFiniteKernel_integrable (N : ℕ) [NeZero N] (hN : 0 < N)
    (h : BoundedBorelFunction ℝ) (s : Finset (actualCuspBasisIndex N hN))
    (f : ActualFullCuspL2 N hN) (q : Gamma0OrbitSpace N) :
    Integrable (fun r => actualCuspFiniteKernel N hN h s q r *
      (f : QuotientL2 N) r) (carrierPushforward N) := by
  simp only [actualCuspFiniteKernel, Finset.sum_mul]
  apply integrable_finsetSum
  intro i hi
  simpa only [mul_assoc] using
    (actualCusp_coefficient_integrable N hN f i).const_mul
      (h (actualCuspNativeEigenvalue N hN i) *
        (actualCuspHilbertBasis N hN i : QuotientL2 N) q)

-- A pointwise, absolutely integrable identity for the literal finite kernel.
-- Its right side uses coefficients of the existing ORIGINAL restriction.
theorem actualCuspFiniteKernel_action (N : ℕ) [NeZero N] (hN : 0 < N)
    (h : BoundedBorelFunction ℝ) (s : Finset (actualCuspBasisIndex N hN))
    (f : ActualFullCuspL2 N hN) (q : Gamma0OrbitSpace N) :
    (∫ r, actualCuspFiniteKernel N hN h s q r *
      (f : QuotientL2 N) r ∂carrierPushforward N) =
      ∑ i ∈ s, (actualCuspHilbertBasis N hN).repr
        (actualCuspBoundedBorelMultiplier N hN h f) i *
        (actualCuspHilbertBasis N hN i : QuotientL2 N) q := by
  simp only [actualCuspFiniteKernel, Finset.sum_mul]
  rw [integral_finsetSum s (fun i hi => by
    simpa only [mul_assoc] using
      (actualCusp_coefficient_integrable N hN f i).const_mul
        (h (actualCuspNativeEigenvalue N hN i) *
          (actualCuspHilbertBasis N hN i : QuotientL2 N) q))]
  apply Finset.sum_congr rfl
  intro i hi
  simp only [mul_assoc, integral_const_mul,
    actualCuspBoundedBorelMultiplier_coefficient, actualCusp_coefficient_integral]
  ring

-- The integral coefficients converge in the actual cusp Hilbert norm to
-- the ORIGINAL restricted Borel action; no diagonal replacement is used.
theorem actualCusp_original_integral_hasSum (N : ℕ) [NeZero N] (hN : 0 < N)
    (h : BoundedBorelFunction ℝ) (f : ActualFullCuspL2 N hN) :
    HasSum (fun i =>
      (h (actualCuspNativeEigenvalue N hN i) *
        (∫ r, star ((actualCuspHilbertBasis N hN i : QuotientL2 N) r) *
          (f : QuotientL2 N) r ∂carrierPushforward N)) •
        actualCuspHilbertBasis N hN i)
      (actualCuspBoundedBorelMultiplier N hN h f) := by
  simpa only [actualCuspBoundedBorelMultiplier_coefficient,
    actualCusp_coefficient_integral] using
    (actualCuspHilbertBasis N hN).hasSum_repr
      (actualCuspBoundedBorelMultiplier N hN h f)

-- The same strong integral reconstruction in the ORIGINAL ambient L2
-- space, with the original resolvent functional calculus written literally.
theorem original_borel_integral_hasSum (N : ℕ) [NeZero N] (hN : 0 < N)
    (h : BoundedBorelFunction ℝ) (f : ActualFullCuspL2 N hN) :
    HasSum (fun i =>
      (h (actualCuspNativeEigenvalue N hN i) *
        (∫ r, star ((actualCuspHilbertBasis N hN i : QuotientL2 N) r) *
          (f : QuotientL2 N) r ∂carrierPushforward N)) •
        (actualCuspHilbertBasis N hN i : QuotientL2 N))
      (borelFunctionalCalculus (actualGammaResolvent N)
        (actualGammaResolvent_selfAdjoint N)
        (laplaceBorelCoefficient (actualGammaResolvent N) h)
        (f : QuotientL2 N)) := by
  rw [← actualCuspBoundedBorelMultiplier_original N hN h f]
  simpa only [map_smul] using
    (actualCusp_original_integral_hasSum N hN h f).mapL
      (allFrameCuspSubspace N hN).subtypeL

end
end ImbalancedChen.Part3.ActualCuspFiniteKernelAction20261027
