import ImbalancedChen.Part3ActualPrimeHeckePhysicalFourier

-- SOURCE_ONLY / UNCOMPILED_ZERO_CREDIT, 2026-10-27.
-- Original quotient measure carrierPushforward and literal Fourier integrals.
-- Derive the amplitude of the actual descended Hecke function from height one.
-- Then pay the manuscript normalization R(n)=sqrt(|n|)*rho(n), including
-- both different sqrt(p) factors. No transformed L2 or PDE input is assumed.
-- Scope: real K order nu >= 0, including the threshold nu = 0.
-- The principal imaginary-order spectral expansion is not supplied here.

namespace ImbalancedChen.Part3.ActualNormalizedHeckeFourier20261027
noncomputable section
open Set MeasureTheory
open ActualPrimeHeckePhysicalFourier20261026b
open ActualPrimeHeckeQuotientDescent20261026b
open ActualHeckeAllRealK20261026b
open ActualHeckeDivisibleFourier20261026b
open QuotientRealKFourierCoefficient20261026b
open ActualRealMaassFourierK20261026a
open ActualPoincareSpectralCoefficient20261026a
open ActualMaassFourierODE20261026a
open ActualFourierBesselConjugation20261026a
open Gamma0QuotientCellPushforward20261025a
open ComplexOrderKBridgeSourceOnly

-- Exact square-root scaling of either signed integer Fourier index.
theorem sqrt_abs_nat_mul (p : ℕ) (n : ℤ) :
    (Real.sqrt |(((p : ℤ)*n : ℤ) : ℝ)| : ℂ) =
      (Real.sqrt (p : ℝ) : ℂ) * (Real.sqrt |(n : ℝ)| : ℂ) := by
  rw [Int.cast_mul, Int.cast_natCast, abs_mul,
    abs_of_nonneg (Nat.cast_nonneg p), Real.sqrt_mul (Nat.cast_nonneg p),
    Complex.ofReal_mul]

variable (N : ℕ) [NeZero N] (U : Gamma0OrbitSpace N → ℂ)
  (hU : Continuous (testLift N U)) (hU2 : MemLp U 2 (carrierPushforward N))
  (hC2 : ContDiffOn ℝ 2 (maassChart N U) upperDomain)
  (nu : ℝ) (hnu : 0 ≤ nu)
  (hPDE : ∀ z ∈ upperDomain,
    -(z.2 : ℂ)^2*(partialX (partialX (maassChart N U)) z+
      partialY (partialY (maassChart N U)) z) =
        (1/4-(nu : ℂ)^2)*maassChart N U z)

-- The actual transformed rho is its defining literal height-one Fourier
-- integral divided by K. Only the original function has analytic hypotheses.
theorem actual_quotientHecke_rho (p : ℕ) (hp : p.Prime) (hpN : ¬ p ∣ N)
    {n : ℤ} (hn : n ≠ 0) :
    quotientRho N (quotientHecke N p hp hpN U) nu n =
      quotientRho N U nu ((p : ℤ)*n) +
        (if (p : ℤ) ∣ n then quotientRho N U nu (n/(p : ℤ)) else 0) := by
  have hK : complexOrderK (nu : ℂ) (modeFrequency n) ≠ 0 :=
    RealBesselTailKSelection20261026a.actualRealK_ne_zero nu (modeFrequency_pos hn)
  change coefficient (maassChart N (quotientHecke N p hp hpN U)) n 1 /
    complexOrderK (nu : ℂ) (modeFrequency n) = _
  rw [← actualTestFourier_eq_coefficient]
  rw [actual_quotient_hecke_realK_all N p hp hpN U hU hU2 hC2 nu hnu hPDE hn
    (by norm_num : (0 : ℝ) < 1)]
  simp only [Real.sqrt_one, Complex.ofReal_one, mul_one]
  simpa only [modeFrequency, mul_one] using
    mul_div_cancel_right₀
      (quotientRho N U nu ((p : ℤ)*n) +
        (if (p : ℤ) ∣ n then quotientRho N U nu (n/(p : ℤ)) else 0)) hK

-- Actual normalized Fourier/Hecke relation. The two coefficients have
-- inverse sqrt(p) and sqrt(p), respectively, because R carries sqrt(|n|).
theorem actual_quotientHecke_R (p : ℕ) (hp : p.Prime) (hpN : ¬ p ∣ N)
    {n : ℤ} (hn : n ≠ 0) :
    quotientR N (quotientHecke N p hp hpN U) nu n =
      (Real.sqrt (p : ℝ) : ℂ)⁻¹ * quotientR N U nu ((p : ℤ)*n) +
        (if (p : ℤ) ∣ n then
          (Real.sqrt (p : ℝ) : ℂ) * quotientR N U nu (n/(p : ℤ)) else 0) := by
  have hs : (Real.sqrt (p : ℝ) : ℂ) ≠ 0 :=
    Complex.ofReal_ne_zero.mpr (Real.sqrt_pos.mpr (by exact_mod_cast hp.pos)).ne'
  have hpZ : (p : ℤ) ≠ 0 := by exact_mod_cast hp.ne_zero
  rw [quotientR, actual_quotientHecke_rho N U hU hU2 hC2 nu hnu hPDE p hp hpN hn]
  by_cases hd : (p : ℤ) ∣ n
  · have hdivweight : (Real.sqrt |(n : ℝ)| : ℂ) =
        (Real.sqrt (p : ℝ) : ℂ) *
          (Real.sqrt |((n/(p : ℤ) : ℤ) : ℝ)| : ℂ) := by
      obtain ⟨m, hm⟩ := hd
      rw [hm, Int.mul_ediv_cancel_left m hpZ]
      exact sqrt_abs_nat_mul p m
    simp only [if_pos hd, quotientR]
    rw [sqrt_abs_nat_mul p n]
    calc
      _ = (Real.sqrt |(n : ℝ)| : ℂ)*quotientRho N U nu ((p : ℤ)*n) +
          (Real.sqrt |(n : ℝ)| : ℂ)*quotientRho N U nu (n/(p : ℤ)) := by
        ring
      _ = _ := by
        rw [hdivweight]
        field_simp [hs] <;> ring
  · simp only [if_neg hd, add_zero, quotientR]
    rw [sqrt_abs_nat_mul p n]
    field_simp [hs] <;> ring

-- The literal Fourier integral equals R(n)*sqrt(y/|n|)*K_nu, with actual
-- physical height y. This is derived, rather than a normalization premise.
theorem actual_fourier_eq_R_physical {n : ℤ} (hn : n ≠ 0)
    {y : ℝ} (hy : 0 < y) :
    actualTestFourier N U n y = quotientR N U nu n *
      (Real.sqrt (y/|(n : ℝ)|) : ℂ) *
        complexOrderK (nu : ℂ) (2*Real.pi*|(n : ℝ)|*y) := by
  have hnR : (n : ℝ) ≠ 0 := by exact_mod_cast hn
  have hs : (Real.sqrt |(n : ℝ)| : ℂ) ≠ 0 :=
    Complex.ofReal_ne_zero.mpr (Real.sqrt_pos.mpr (abs_pos.mpr hnR)).ne'
  rw [actual_quotient_fourier_eq_realK N U hU hU2 hC2 nu hnu hPDE hn hy,
    quotientR, Real.sqrt_div hy.le, Complex.ofReal_div]
  field_simp [hs] <;> ring

-- The normalized transformed amplitude acts at the SAME physical K mode.
-- In particular no spurious p is absorbed into the Bessel argument.
theorem actual_quotientHecke_fourier_eq_R_physical
    (p : ℕ) (hp : p.Prime) (hpN : ¬ p ∣ N)
    {n : ℤ} (hn : n ≠ 0) {y : ℝ} (hy : 0 < y) :
    actualTestFourier N (quotientHecke N p hp hpN U) n y =
      quotientR N (quotientHecke N p hp hpN U) nu n *
        (Real.sqrt (y/|(n : ℝ)|) : ℂ) *
          complexOrderK (nu : ℂ) (2*Real.pi*|(n : ℝ)|*y) := by
  have hnR : (n : ℝ) ≠ 0 := by exact_mod_cast hn
  have hs : (Real.sqrt |(n : ℝ)| : ℂ) ≠ 0 :=
    Complex.ofReal_ne_zero.mpr (Real.sqrt_pos.mpr (abs_pos.mpr hnR)).ne'
  rw [actual_quotient_hecke_realK_all N p hp hpN U hU hU2 hC2 nu hnu hPDE hn hy,
    quotientR, actual_quotientHecke_rho N U hU hU2 hC2 nu hnu hPDE p hp hpN hn,
    Real.sqrt_div hy.le, Complex.ofReal_div]
  field_simp [hs] <;> ring

-- A genuine physical eigenfunction hypothesis implies the normalized
-- recurrence. It does not assume existence of a Hecke eigenbasis.
theorem actual_eigenfunction_R_recurrence (p : ℕ) (hp : 0 < p) (eigen : ℂ)
    (hEigen : ∀ z ∈ upperDomain,
      primeHeckeExpression p (maassChart N U) z = eigen*maassChart N U z)
    {n : ℤ} (hn : n ≠ 0) :
    (Real.sqrt (p : ℝ) : ℂ)⁻¹ * quotientR N U nu ((p : ℤ)*n) +
      (if (p : ℤ) ∣ n then
        (Real.sqrt (p : ℝ) : ℂ)*quotientR N U nu (n/(p : ℤ)) else 0) =
      eigen*quotientR N U nu n := by
  have hrec := actual_hecke_rho_recurrence N U hU hU2 hC2 nu hnu hPDE p hp eigen hEigen hn
  have hs : (Real.sqrt (p : ℝ) : ℂ) ≠ 0 :=
    Complex.ofReal_ne_zero.mpr (Real.sqrt_pos.mpr (by exact_mod_cast hp)).ne'
  have hpZ : (p : ℤ) ≠ 0 := by exact_mod_cast hp.ne'
  have hscaled := congrArg (fun w : ℂ => (Real.sqrt |(n : ℝ)| : ℂ)*w) hrec
  by_cases hd : (p : ℤ) ∣ n
  · have hw : (Real.sqrt |(n : ℝ)| : ℂ) =
        (Real.sqrt (p : ℝ) : ℂ) *
          (Real.sqrt |((n/(p : ℤ) : ℤ) : ℝ)| : ℂ) := by
      obtain ⟨m, hm⟩ := hd
      rw [hm, Int.mul_ediv_cancel_left m hpZ]
      exact sqrt_abs_nat_mul p m
    simp only [if_pos hd] at hscaled ⊢
    simp only [quotientR, sqrt_abs_nat_mul]
    calc
      _ = (Real.sqrt |(n : ℝ)| : ℂ) *
          (quotientRho N U nu ((p : ℤ)*n) + quotientRho N U nu (n/(p : ℤ))) := by
        rw [hw]
        field_simp [hs] <;> ring
      _ = (Real.sqrt |(n : ℝ)| : ℂ)*(eigen*quotientRho N U nu n) := hscaled
      _ = _ := by ring
  · simp only [if_neg hd, add_zero] at hscaled ⊢
    simp only [quotientR, sqrt_abs_nat_mul]
    calc
      _ = (Real.sqrt |(n : ℝ)| : ℂ)*quotientRho N U nu ((p : ℤ)*n) := by
        field_simp [hs] <;> ring
      _ = (Real.sqrt |(n : ℝ)| : ℂ)*(eigen*quotientRho N U nu n) := hscaled
      _ = _ := by ring

end
end ImbalancedChen.Part3.ActualNormalizedHeckeFourier20261027
