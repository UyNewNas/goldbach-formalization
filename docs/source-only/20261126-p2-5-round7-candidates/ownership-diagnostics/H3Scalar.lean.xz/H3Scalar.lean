import Mathlib.Tactic

/- Local scalar diagnostic only. This does not reproduce or accept the
   full87 module or its literal 99-row H3 source. -/
noncomputable section
namespace Round6H3Scalar

abbrev Point := Fin 8 → ℝ
def A (s : ℝ) : ℝ := (1 + s) / 2
def D (s : ℝ) : ℝ := 57 / 64 - 3 * s / 2
def R6 (t : Point) : ℝ := A (t 0 + t 3)
def mu : ℝ := 25 / 128

example (t : Point) (hw : R6 t < D (t 0 + t 3)) : t 0 + t 3 < mu := by
  change (1 + (t 0 + t 3)) / 2 < 57 / 64 - 3 * (t 0 + t 3) / 2 at hw
  change t 0 + t 3 < 25 / 128
  linarith only [hw]

end Round6H3Scalar
