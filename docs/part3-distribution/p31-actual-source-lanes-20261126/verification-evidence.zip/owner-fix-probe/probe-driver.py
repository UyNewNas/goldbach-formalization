from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

root = Path('/workspace/p31-actual-source-lanes-probe-20261126-r2')
base = Path('/workspace/p31-poisson-lanes-20261126')
payload = json.loads((root / 'payload.json').read_text())
attempt = root / 'evidence' / ('attempt' + str(payload['attempt']))
attempt.mkdir(parents=True, exist_ok=True)
assert not (attempt / 'report.json').exists(), 'Do not overwrite an existing attempt'
(attempt / 'probe-driver.py').write_bytes(Path(__file__).read_bytes())
report = {'scope': 'Strict integration probe only, not final commit acceptance',
          'attempt': payload['attempt'], 'status': 'RUNNING', 'stages': [],
          'source_manifest': payload['sources'], 'provider_sources': payload['providers']}

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save():
    (attempt / 'report.json').write_text(json.dumps(report, indent=2) + '\n')

def run(cmd, name, cwd=base, env=None):
    start = time.monotonic()
    print('START ' + name, flush=True)
    logfile = attempt / (name + '.log')
    with logfile.open('w') as handle:
        handle.write('command=' + json.dumps(cmd) + '\n')
        handle.flush()
        result = subprocess.run(cmd, cwd=cwd, env=env, stdout=handle, stderr=subprocess.STDOUT)
    report['stages'].append({'name': name, 'command': cmd, 'exit_code': result.returncode,
                             'elapsed_seconds': round(time.monotonic() - start, 3),
                             'log_sha256': digest(logfile)})
    save()
    if result.returncode:
        print(logfile.read_text(), flush=True)
        raise RuntimeError(name + ': exit ' + str(result.returncode))
    print('PASS ' + name, flush=True)
    return logfile.read_text().split('\n', 1)[1]

try:
    for item in payload['sources']:
        src = root / item['path']
        assert digest(src) == item['sha256'], item['path']
        destination = attempt / item['path']
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(src.read_bytes())
    for item in payload['providers']:
        assert digest(base / item['path']) == item['sha256'], item['path']
    report['base_head'] = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=base, text=True).strip()
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=base, text=True).strip()
    if payload.get('bootstrap', False):
        run(['lake', 'build', 'ImbalancedChen.Part3ActualReciprocalSquarePoissonCore',
             'ImbalancedChen.Part3ActualLiteralPacketIntegral'], 'reused-provider-cache')
    envmeta = json.loads(run(['lake', 'env', sys.executable, '-c',
        "import json,os,shutil;print(json.dumps({'lean':shutil.which('lean'),"
        "'lean_path':os.environ.get('LEAN_PATH'),'sysroot':os.environ.get('LEAN_SYSROOT')}))"],
        'tool-environment'))
    roots = [Path(p) if Path(p).is_absolute() else (base / p).resolve()
             for p in envmeta['lean_path'].split(':') if p]
    objroot = root / '.lake/build/lib/lean'
    (objroot / 'ImbalancedChen').mkdir(parents=True, exist_ok=True)
    # Lean resolves a project package at its first root. Supply the existing
    # provider objects there by links, with exact bindings to the accepted tree.
    for item in payload['providers']:
        relative = item['module'].replace('.', '/')
        for suffix in ('.olean', '.olean.server', '.olean.private', '.ir', '.ilean'):
            donor = base / '.lake/build/lib/lean' / (relative + suffix)
            link = objroot / (relative + suffix)
            if donor.is_file():
                if link.exists() or link.is_symlink():
                    assert link.is_symlink() and link.resolve() == donor.resolve(), str(link)
                else:
                    link.parent.mkdir(parents=True, exist_ok=True)
                    link.symlink_to(donor)
    env = os.environ.copy()
    env['LEAN_PATH'] = ':'.join(map(str, [objroot, *roots]))
    env['LEAN_SYSROOT'] = envmeta['sysroot']
    report['effective_lean_path'] = env['LEAN_PATH']
    report['environment'] = envmeta
    version = subprocess.check_output([envmeta['lean'], '--version'], text=True).strip()
    assert '4.33.0-rc1' in version and '62eed1db4d67327ec8120be05f1a1b0847d74561' in version
    report['lean_version'] = version

    def provider_objects():
        result = {}
        for item in payload['providers']:
            relative = item['module'].replace('.', '/') + '.olean'
            resolved = next((p / relative for p in [objroot, *roots]
                             if (p / relative).is_file()), None)
            expected = base / '.lake/build/lib/lean' / relative
            assert resolved is not None and resolved.resolve() == expected.resolve(), item['module']
            result[item['module']] = {'resolved': str(resolved), 'parts': {
                str(Path(str(resolved) + suffix)): digest(Path(str(resolved) + suffix))
                for suffix in ('', '.server', '.private') if Path(str(resolved) + suffix).is_file()}}
        return result

    before = provider_objects()
    report['provider_objects_before'] = before
    save()
    for item in payload['sources']:
        if item['module'] not in payload['compile_targets']:
            continue
        obj = objroot / (item['module'].replace('.', '/') + '.olean')
        for suffix in ('', '.server', '.private'):
            Path(str(obj) + suffix).unlink(missing_ok=True)
        run([envmeta['lean'], '-t0', '-j1', '-M12000', '-DwarningAsError=true',
             '-o', str(obj), str(root / item['path'])],
            item['module'].split('.')[-1] + '-strict', cwd=root, env=env)
    after = provider_objects()
    assert before == after, 'Provider objects changed during probe'
    for item in payload['sources']:
        assert digest(root / item['path']) == item['sha256']
    for item in payload['providers']:
        assert digest(base / item['path']) == item['sha256']
    report.update(status='STRICT_PASSED', provider_objects_after=after,
                  provider_objects_unchanged=True, source_hashes_unchanged=True)
except BaseException as error:
    report.update(status='FAILED', error=str(error))
    save()
    raise
else:
    save()
    print(json.dumps({'status': report['status'], 'attempt': report['attempt'],
                      'stages': len(report['stages']), 'evidence': str(attempt)}), flush=True)
