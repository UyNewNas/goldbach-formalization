#!/usr/bin/env python3
"""Bounded source-error continuation inside one serial, externally time-limited P1 job."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import time

BRANCH = 'work/p3-6-original-u5-20261125'
MAIN = ('ImbalancedChen.P2ActualPairPlanRunSupport',
        'ImbalancedChen.P5OriginalU5PhysicalRho',
        'ImbalancedChen.P3OriginalU5PhysicalModulusCap')
EXTRA = ('ImbalancedChen.P5OriginalU5NativeRootCover',
         'ImbalancedChen.P3OriginalU5FreshFifthSquareSupplier',
         'ImbalancedChen.P3OriginalU5AllSourceSquares',
         'ImbalancedChen.P3OriginalU5AllSignedSquares')
FAILED_MODULE = re.compile(r'^Compilation failed for (ImbalancedChen\.[A-Za-z0-9_]+), exit 1;')


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def git(project, *args):
    return subprocess.check_output(['git', *args], cwd=project, text=True, timeout=30).strip()


def wait_changed_source(project, failed_pin, module, deadline, record):
    """Only a changed blob for the precise failed module permits continuation."""
    relative = module.replace('.', '/') + '.lean'
    old_blob = git(project, 'rev-parse', failed_pin + ':' + relative)
    wait_until = min(time.monotonic() + 300, deadline)
    watch_now = time.time()
    record.update(watch_started_utc=datetime.fromtimestamp(watch_now, timezone.utc).isoformat(),
                  watch_deadline_utc=datetime.fromtimestamp(
                      watch_now + max(0, wait_until - time.monotonic()), timezone.utc).isoformat())
    print('P36_SOURCE_WATCH_CLOCK ' + json.dumps({
        'module': module, 'commit': failed_pin,
        'started_utc': record['watch_started_utc'],
        'deadline_utc': record['watch_deadline_utc']}), flush=True)
    while time.monotonic() < wait_until:
        try:
            git(project, 'fetch', '--no-tags', 'origin', BRANCH)
            candidate = git(project, 'rev-parse', 'FETCH_HEAD')
            git(project, 'merge-base', '--is-ancestor', failed_pin, candidate)
            new_blob = git(project, 'rev-parse', candidate + ':' + relative)
            if new_blob != old_blob:
                record.update(resume_commit=candidate, failed_source=relative,
                              old_blob=old_blob, new_blob=new_blob)
                return candidate
        except (subprocess.SubprocessError, OSError) as error:
            record['last_watch_error'] = str(error)
        remaining = wait_until - time.monotonic()
        if remaining > 0:
            time.sleep(min(15, remaining))
    record.update(failed_source=relative, old_blob=old_blob, wait_expired=True)
    return None


def run_group(project, initial_pin, targets, job_deadline):
    """Run only an approved target tuple; preserve all round logs and exact pins."""
    project, targets = Path(project).resolve(), tuple(targets)
    if targets != EXTRA:
        raise ValueError('Unapproved verification scope')
    journal = project / '.lake/p36-supervision' / datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')
    journal.mkdir(parents=True)
    events = []
    emitted_bytes = 0

    def emit(message):
        nonlocal emitted_bytes
        data = (message + '\n').encode()
        emitted_bytes += len(data)
        sys.stdout.buffer.write(data)
        sys.stdout.buffer.flush()

    def run_and_tee(command, name):
        nonlocal emitted_bytes
        path = journal / name
        with path.open('wb') as output:
            process = subprocess.Popen(command, cwd=project, stdout=subprocess.PIPE,
                                       stderr=subprocess.STDOUT)
            for data in iter(process.stdout.readline, b''):
                output.write(data)
                output.flush()
                sys.stdout.buffer.write(data)
                sys.stdout.buffer.flush()
                emitted_bytes += len(data)
            code = process.wait()
        return code

    def save():
        temporary = journal / 'rounds.json.tmp'
        temporary.write_text(json.dumps({'targets': targets, 'branch': BRANCH,
                                        'rounds': events}, indent=2) + '\n')
        temporary.replace(journal / 'rounds.json')

    pin = initial_pin
    while True:
        git(project, 'fetch', '--no-tags', 'origin', pin)
        git(project, 'diff', '--exit-code')
        git(project, 'checkout', '--detach', pin)
        record = {'round': len(events) + 1, 'commit': git(project, 'rev-parse', 'HEAD'),
                  'targets': targets, 'command_timeout_seconds': 2400, 'started_utc': datetime.now(timezone.utc).isoformat(),
                  'runner_sha256': digest(project / 'verification/p36/compile_p36_local.py'),
                  'manifest_sha256': digest(project / 'docs/part3-distribution/continuation-20261125-p36/SOURCE_SELECTION.json'),
                  'target_source_sha256': {m: digest(project / (m.replace('.', '/') + '.lean')) for m in targets}}
        events.append(record)
        save()
        emit('P36_SUPERVISED_ROUND ' + json.dumps(record))
        tests = run_and_tee(['python3', 'verification/p36/test_compile_p36_local.py'],
                            str(record['round']) + '-runner-tests.log')
        if tests:
            record.update(exit_code=tests, status='RUNNER_TESTS_FAILED')
            save()
            return {'exit_code': tests, 'journal': str(journal), 'commit': pin,
                    'stdout_bytes': emitted_bytes}
        command = ['python3', 'verification/p36/compile_p36_local.py', *targets,
                   '--build', '--strict-owned', '--verify-owned', '--timeout', '2400',
                   '--packages-dir', '/workspace/blue-member-build/.lake/packages',
                   '--toolchain-dir', '/workspace/toolchains/lean-4.33.0-rc1-linux',
                   '--source-manifest', 'docs/part3-distribution/continuation-20261125-p36/SOURCE_SELECTION.json',
                   '--reuse-verified-bundle', '.lake/p36-imported-tagged']
        built = run_and_tee(command, str(record['round']) + '-runner-output.log')
        latest = json.loads((project / '.lake/p36-build/latest.json').read_text())
        report_path = Path(latest['report'])
        report = json.loads(report_path.read_text())
        record.update(exit_code=built, status=report['status'],
                      report=str(report_path), finished_utc=datetime.now(timezone.utc).isoformat())
        save()
        result = {'exit_code': built, 'journal': str(journal),
                  'commit': record['commit'], 'run': str(report_path.parent),
                  'stdout_bytes': emitted_bytes}
        if built == 0 or time.monotonic() >= job_deadline - 120:
            return result
        match = FAILED_MODULE.match(report.get('error', ''))
        if match is None:
            return result
        module = match.group(1)
        log = report_path.parent / ('compile-' + module + '.log')
        record.update(failed_module=module, failure_log=str(log), failure_log_sha256=digest(log))
        save()
        emit('P36_WAITING_FOR_FAILED_SOURCE ' + json.dumps({
            'module': module, 'commit': record['commit'], 'report': str(report_path),
            'log': str(log), 'max_wait_seconds': 300}))
        # The complete file remains available for evidence; usual short errors
        # are printed in full immediately without another queued read task.
        body = log.read_text()
        emit('P36_FAILURE_LOG_BEGIN\n' + body[-100000:] + '\nP36_FAILURE_LOG_END')
        pin = wait_changed_source(project, record['commit'], module,
                                  job_deadline - 120, record)
        save()
        if pin is None:
            result['stdout_bytes'] = emitted_bytes
            return result

