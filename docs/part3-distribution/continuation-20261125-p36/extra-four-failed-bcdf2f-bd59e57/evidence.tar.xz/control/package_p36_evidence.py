#!/usr/bin/env python3
"""Package an already successful P3.6 run; never compile or create proof credit."""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def package(project: Path, run: Path, destination: Path, scope: str) -> dict:
    project, run, destination = project.resolve(), run.resolve(), destination.resolve()
    if (destination / 'RECEIPT.json').exists():
        raise RuntimeError('Refusing to overwrite an existing successful receipt: ' + str(destination))
    report_file = run / "report.json"
    report = json.loads(report_file.read_text())
    if report.get("status") != "VERIFIED_OWNED" or not report.get("strict_owned"):
        raise RuntimeError("This run has not completed strict/kernel/axiom verification")
    targets = report["targets"]
    files: dict[str, Path] = {}

    def add(name: str, path: Path, expected: str | None = None):
        if not path.is_file():
            raise RuntimeError("Missing evidence: " + str(path))
        if expected is not None and digest(path) != expected:
            raise RuntimeError("Evidence changed: " + str(path))
        if name in files and files[name].resolve() != path.resolve():
            raise RuntimeError("Conflicting evidence name: " + name)
        files[name] = path

    for path in sorted(run.iterdir()):
        if path.is_file():
            add("run/" + path.name, path)
    for command in report["commands"]:
        add("run/" + Path(command["log"]).name, Path(command["log"]), command["log_sha256"])
    audits = [s for s in report["commands"] if s["name"] == "owned-inventory-audit"]
    if len(audits) != 1 or audits[0]["exit_code"] != 0:
        raise RuntimeError("Missing successful complete owned inventory/axiom audit")
    for target in targets:
        entry = report["modules"][target]
        if entry.get("action") != "compiled" or entry.get("strict") is not True or entry.get("exit_code") != 0:
            raise RuntimeError("Owned target is not a fresh successful strict compile: " + target)
        relative = target.replace(".", "/")
        source = project / (relative + ".lean")
        add("source/" + relative + ".lean", source, entry["source_sha256"])
        committed = subprocess.check_output(["git", "show", "HEAD:" + relative + ".lean"], cwd=project)
        if hashlib.sha256(committed).hexdigest() != entry["source_sha256"]:
            raise RuntimeError("Owned source differs from the recorded Git checkpoint: " + target)
        for path, expected in entry["objects"].items():
            obj = Path(path)
            suffix = obj.name[len(Path(relative).name):]
            add("objects/" + relative + suffix, obj, expected)
        for stage in ("compile-" + target, "replay-" + target):
            matching = [s for s in report["commands"] if s["name"] == stage]
            if len(matching) != 1 or matching[0]["exit_code"] != 0:
                raise RuntimeError("Missing successful owned stage: " + stage)
        replay = (run / ("replay-" + target + ".log")).read_text()
        if "replaying " + target not in replay.splitlines():
            raise RuntimeError("Missing exact replay line: " + target)

    # Preserve the current successful state and the prior local compile logs
    # used by unchanged dependencies, without claiming a fresh proof for them.
    state_file = Path(report["build_dir"]) / "state.json"
    if state_file.is_file():
        add("lineage/local-state.json", state_file)
    for entry in report["modules"].values():
        if entry.get("action") == "reused" and entry.get("previous_log"):
            old = Path(entry["previous_log"])
            if not old.resolve().is_relative_to(Path(report["build_dir"]).resolve()):
                raise RuntimeError("Prior local compile log escapes this build")
            add("lineage/" + old.parent.name + "/" + old.name, old)
    for index, imported in enumerate(report.get("transferred_verified_objects", [])):
        receipt = Path(imported["receipt"])
        add(f"inputs/transferred-{index}/RECEIPT.json", receipt, imported["receipt_sha256"])
        original = json.loads(receipt.read_text())
        add(f"inputs/transferred-{index}/evidence.tar.xz", receipt.parent / "evidence.tar.xz",
            original["archive_sha256"])
    for name in ("lean-toolchain", "lake-manifest.json", "lakefile.toml"):
        add("config/" + name, project / name)
    for name in ("compile_p36_local.py", "project_cache_reuse.py", "test_compile_p36_local.py"):
        add("verification/p36/" + name, project / "verification/p36" / name)
    for name in ("verify_part3_continuation.py", "verify_part3_distribution.py",
                 "Part3DistributionAudit.lean", "verify_variable_envelope_boxes.py"):
        add("verification/" + name, project / "verification" / name)
    add("packager/package_p36_evidence.py", Path(__file__).resolve())
    if report.get("runner_sha256") != digest(project / "verification/p36/compile_p36_local.py"):
        raise RuntimeError("Verification runner changed after this run")
    manifest = report.get("source_manifest")
    if manifest:
        add("inputs/SOURCE_SELECTION.json", Path(manifest["path"]), manifest["sha256"])

    declarations = json.loads(Path(report["declarations_file"]).read_text())
    if len(declarations) != report["declaration_count"] or any(
            r["module"] not in targets or set(r["axioms"]) - {"propext", "Classical.choice", "Quot.sound"}
            for r in declarations):
        raise RuntimeError("Declaration inventory changed or violates the axiom boundary")
    counts = {module: dict(Counter(r["kind"] for r in declarations if r["module"] == module))
              for module in targets}
    destination.mkdir(parents=True, exist_ok=False)
    archive = destination / "evidence.tar.xz"
    hashes = {name: digest(path) for name, path in files.items()}
    with tarfile.open(archive, "w:xz", preset=6) as tar:
        for name, path in sorted(files.items()):
            tar.add(path, arcname=name, recursive=False)
    for name, path in files.items():
        if digest(path) != hashes[name]:
            raise RuntimeError("Evidence changed while being archived: " + name)
    result = {
        "status": "VERIFIED_OWNED_MODULES_ONLY", "scope": scope,
        "p36_closed": False,
        "mathematical_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=project, text=True).strip(),
        "targets": targets, "module_declaration_kinds": counts,
        "complete_owned_declaration_count": report["declaration_count"],
        "strict_compilation": True, "bundled_kernel_replay": True,
        "complete_transitive_axiom_audit": True,
        "allowed_transitive_axioms": ["propext", "Classical.choice", "Quot.sound"],
        "compiler": report["compiler"], "dependency_pins": report["dependency_pins"],
        "source_sha256": {m: report["modules"][m]["source_sha256"] for m in targets},
        "objects_sha256": {m: report["modules"][m]["objects"] for m in targets},
        "started_utc": report["started_utc"], "finished_utc": report["finished_utc"],
        "archive": archive.name, "archive_bytes": archive.stat().st_size,
        "archive_sha256": digest(archive), "files": hashes,
    }
    (destination / "RECEIPT.json").write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n")
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project", type=Path, required=True)
    parser.add_argument("--run", type=Path, required=True)
    parser.add_argument("--destination", type=Path, required=True)
    parser.add_argument("--scope", required=True)
    args = parser.parse_args()
    record = package(args.project, args.run, args.destination, args.scope)
    print(json.dumps({k: record[k] for k in ("status", "targets", "archive_bytes", "archive_sha256",
                                             "complete_owned_declaration_count", "p36_closed")}, indent=2))
