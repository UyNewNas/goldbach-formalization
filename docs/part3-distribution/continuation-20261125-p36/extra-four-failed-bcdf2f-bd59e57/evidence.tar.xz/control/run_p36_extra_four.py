#!/usr/bin/env python3
"""Run precisely the next four owned targets after sealing the MAIN evidence."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tarfile
import time

sys.dont_write_bytecode = True
ROOT = Path('/workspace/p36-original-u5-20261125')
CONTROL = Path(__file__).resolve().parent
PIN = '45428d4ef7eac2f19dfd17a3d3a9a4d0903296ce'
MANIFEST = 'ba82cc31a3931c89cf86f59ffe8edbf0f007946df3dcf16e79f99304b69f2965'
MAIN = ROOT / '.lake/p36-audit-continuations/20261125T141852.230874Z'
MAIN_ARCHIVE = '95c14de12928cf047491db283d098ce99de6a789e25b4074c00f154dabea986c'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    deadline = time.monotonic() + 3450
    assert sha(MAIN / 'evidence.tar.xz') == MAIN_ARCHIVE
    parent = json.loads((MAIN / 'RECEIPT.json').read_text())
    assert parent['status'] == 'VERIFIED_OWNED_AUDIT_CONTINUATION'
    assert parent['parent_report_sha256'] == '5e8ef35a629f17056b6daf1ce57605c887cc0ddb5e762976c17500d20c18f766'
    assert parent['archive_sha256'] == MAIN_ARCHIVE
    subprocess.run(['git', 'fetch', '--no-tags', 'origin', PIN], cwd=ROOT, check=True)
    raw = subprocess.check_output(['git', 'show', PIN + ':docs/part3-distribution/continuation-20261125-p36/SOURCE_SELECTION.json'], cwd=ROOT)
    assert hashlib.sha256(raw).hexdigest() == MANIFEST
    import supervise_p36_extra_2400 as supervisor
    import package_p36_evidence as packager
    result = supervisor.run_group(ROOT, PIN, supervisor.EXTRA, deadline)
    print('P36_EXTRA_GROUP_RESULT ' + json.dumps(result), flush=True)
    run = Path(result['run']) if result.get('run') else None
    if result['exit_code'] == 0 and run is not None:
        assert tuple(json.loads((run / 'report.json').read_text())['targets']) == supervisor.EXTRA
        destination = ROOT / '.lake/p36-evidence' / ('extra-four-' + run.name)
        receipt = packager.package(ROOT, run, destination,
            'Four original-U5 root/square supplier modules only; MAIN owned stages remain separately accepted; P3.6 is not closed.')
        data = {'status': receipt['status'], 'path': str(destination / 'evidence.tar.xz'),
                'bytes': receipt['archive_bytes'], 'sha256': receipt['archive_sha256'],
                'complete_owned_declaration_count': receipt['complete_owned_declaration_count'],
                'targets': receipt['targets'], 'mathematical_commit': receipt['mathematical_commit'],
                'receipt_path': str(destination / 'RECEIPT.json'), 'driver_exit_code': 0}
        print('P36_EXTRA_EVIDENCE_READY ' + json.dumps(receipt), flush=True)
    else:
        destination = ROOT / '.lake/p36-evidence' / ('extra-four-failed-' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ'))
        destination.mkdir(parents=True, exist_ok=False)
        archive = destination / 'evidence.tar.xz'
        files = {}
        if run is not None:
            files.update({'run/' + p.name: p for p in run.iterdir() if p.is_file()})
        journal = Path(result['journal'])
        files.update({'supervision/' + p.name: p for p in journal.iterdir() if p.is_file()})
        for name in ('run_p36_extra_four.py', 'supervise_p36_extra_2400.py', 'package_p36_evidence.py'):
            files['control/' + name] = CONTROL / name
        hashes = {name: sha(path) for name, path in files.items()}
        with tarfile.open(archive, 'w:xz', preset=6) as tar:
            for name, path in sorted(files.items()):
                tar.add(path, arcname=name, recursive=False)
        assert all(sha(path) == hashes[name] for name, path in files.items())
        data = {'status': 'FAILED_NOT_ACCEPTED', 'path': str(archive), 'bytes': archive.stat().st_size,
                'sha256': sha(archive), 'driver_exit_code': result['exit_code'], 'result': result, 'files': hashes}
    (CONTROL / 'RESULT.json').write_text(json.dumps(data, indent=2) + '\n')
    return result['exit_code']


if __name__ == '__main__':
    raise SystemExit(main())
