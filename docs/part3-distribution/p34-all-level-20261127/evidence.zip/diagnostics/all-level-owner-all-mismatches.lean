import ImbalancedChen.Part3AllLevelContinuedMaass
import Lean.Util.CollectAxioms

set_option pp.fullNames true
set_option pp.explicit true
set_option pp.universes true
set_option pp.proofs true
set_option pp.deepTerms true
set_option pp.maxSteps 1000000

open Lean Elab Command in
run_cmd do
  let env ← getEnv
  let modules := env.header.moduleNames.filter fun m =>
    m.toString.startsWith "ImbalancedChen."
  let allowed := #[`propext, `Classical.choice, `Quot.sound]
  let names := env.constants.fold (init := #[]) fun names name _ =>
    match env.getModuleIdxFor? name with
    | some idx => if modules.contains env.header.moduleNames[idx]! then names.push name else names
    | none => names
  let mut serialized : Array Name := #[]
  for idx in List.range env.header.modules.size do
    let imported := env.header.modules[idx]!
    if modules.contains imported.module then
      let data := env.header.moduleData[idx]!
      if data.isModule || !imported.importAll || !imported.hasData then
        throwError "Expected complete legacy module data for {imported.module}"
      let owned := names.filter fun name =>
        match env.getModuleIdxFor? name with
        | some i => env.header.moduleNames[i]! == imported.module
        | none => false
      unless owned.qsort Name.lt == data.constNames.qsort Name.lt do
        let missing := data.constNames.filter fun n => !owned.contains n
        let extra := owned.filter fun n => !data.constNames.contains n
        liftIO <| IO.println s!"Serialized and defining-module inventories differ for {imported.module}; missing={missing}; extra={extra}"
      serialized := serialized.push imported.module
  unless serialized.qsort Name.lt == modules.qsort Name.lt do
    throwError "Missing serialized module inventory"
