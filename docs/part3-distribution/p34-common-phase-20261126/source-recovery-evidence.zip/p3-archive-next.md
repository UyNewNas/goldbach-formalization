# P3 cloud archive follow-up

Target `Part3OriginalMediumPhysicalE3Block.lean`, 6,566 bytes, SHA-256 `1ed9fec9d526f866fff9a29f9d8d0fa96d63def2a8b1e4e7a42ad759a8989982`.

## Archive fingerprints

The P3 cloud archive inventory (`40f5ad5e17b3433d8b02028b5a1a6aef`) represents 2,560 paths as 420 distinct SHA-256 fingerprints and five large paths without digests. `p3-archive-dedup.json` partitions these into the following groups.

| Group | Representatives | Path instances | Representative bytes |
|---|---:|---:|---:|
| Byte-identical to prior target checks | 285 | 2,343 | 124,189,068 |
| No matching outer SHA-256 in prior receipts | 135 | 212 | 432,123,256 |
| Unhashed entries over 150 MB | 5 | 5 | 1,877,522,418 |

Read two existing Git stores with `GIT_NO_LAZY_FETCH=1 git cat-file --batch`, requesting only the 1,434 blob IDs in the prior target scan. Recomputed SHA-256 and Git SHA-1 and checked size for all 1,434. Reused the 17 verified outer archive SHA-256 values and recomputed the raw identity of the separately inspected `518b8c575232e0b702e8e985c30a7ff3462fae40` XZ blob. The 285 matches consist of 284 resident Git blobs and that XZ blob. The local receipt paths and their cloud matches have the same suffixes. There were zero local read or identity errors. No archives were decoded or source recovered in this comparison.

## Remaining hashed representatives

Full cloud representative paths, byte counts, and digests appear under `uninspected_hashed`. An unmatched outer digest leaves its contents unclassified, including candidates with metadata-like names. Conversely an unmatched outer container may hold known inner bytes.

| `/workspace` location | Representatives | Bytes |
|---|---:|---:|
| `(directly under /workspace)` | 2 | 3,040,964 |
| `chen-imbalanced-semiprimes` | 2 | 307,901 |
| `p21-log-audit-20261126` | 1 | 44,304,524 |
| `p210-public-receiver-20261125` | 73 | 229,514,211 |
| `p25-q96-20261125` | 15 | 10,919,590 |
| `p26-higher-object-export-20261126` | 1 | 3,145,836 |
| `p29-unit-tail-20261126-8131f7d6` | 8 | 18,481,487 |
| `p31-poisson-lanes-20261126` | 4 | 153,496 |
| `p35-full-height-20261125` | 2 | 115,728 |
| `p36-classical-20261125` | 5 | 19,391,856 |
| `p36-private-delivery-20261126` | 14 | 5,372,083 |
| `rescue-export-20261126` | 8 | 97,375,580 |

The four P3.4 roots `p34-cusp-packet-20261126`, `p34-primary-clean-20261126`, `p34-dyadic-clean-20261126`, and `p34-common-phase-20261126` have zero new representative paths. The 25 remaining P3 representatives can be addressed by these exact roots and their relative paths from `uninspected_hashed`.

| `/workspace/p31-poisson-lanes-20261126` relative path | Bytes |
|---|---:|
| `docs/part3-distribution/p31-poisson-lanes-20261126/failed-run-evidence.zip` | 24,133 |
| `docs/part3-distribution/p31-poisson-lanes-20261126/source68-recovery.zip` | 44,889 |
| `docs/part3-distribution/p31-poisson-lanes-20261126/queued-run-evidence.zip` | 7,344 |
| `docs/part3-distribution/p31-actual-interface-20261126/verification.zip` | 77,130 |

| `/workspace/p35-full-height-20261125` relative path | Bytes |
|---|---:|
| `docs/part3-distribution/continuation-20261125/continuous-height/p35-height-94cff537-cbcebb66105f4036a00789cc806ce176.zip` | 80,665 |
| `.lake/p35-test-seminorm-0ef2ad29.zip` | 35,063 |

| `/workspace/p36-classical-20261125` relative path | Bytes |
|---|---:|
| `docs/part3-distribution/continuation-20261125-p36/extra-four-failed-bcdf2f-bd59e57/evidence.tar.xz` | 2,098,068 |
| `docs/part3-distribution/continuation-20261125-p36/main-three-3aaf-audit-continuation/evidence.tar.xz` | 4,559,760 |
| `.lake/p36-warm-common-verification/20261125T192229.255882Z/evidence.tar.xz` | 4,516,604 |
| `.lake/p36-audit-continuations/20261125T182111.303105Z/evidence.tar.xz` | 3,857,508 |
| `.lake/p36-audit-continuations/20261125T181506.742457Z/evidence.tar.xz` | 4,359,916 |

| `/workspace/p36-private-delivery-20261126` relative path | Bytes |
|---|---:|
| `proof-repairs.bundle` | 10,395 |
| `warm-word-retry-33bc456.bundle` | 8,237 |
| `modulus-margin-retry-192afed.bundle` | 39,251 |
| `wall-cover-retry-d2f33cc.bundle` | 9,566 |
| `beta-strict-retry-53f4288.bundle` | 8,029 |
| `common-checkpoint.bundle` | 25,505 |
| `warm-formal-verification-9b16c5f.bundle` | 19,856 |
| `next-proof-repairs.bundle` | 9,538 |
| `rounding-payment-retry-dbc0538.bundle` | 8,211 |
| `strict-interfaces-3e87c2a.bundle` | 9,786 |
| `warm-cover-next-2c996f9.bundle` | 32,511 |
| `checkpoint.bundle` | 90,618 |
| `audit-timeout-3e87-payer/evidence.tar.xz` | 2,319,644 |
| `audit-timeout-3e87-foundations/evidence.tar.xz` | 2,780,936 |

## One bounded cloud pass

1. Submit one read-only decoder for `uninspected_hashed` only, using the exact paths and verifying each outer length and SHA-256 as read. Run the 25 P3 representatives first, then the eight `rescue-export-20261126` representatives, then the remainder. Exclude the 285 known representatives and the five large paths. Consume the `check` and `visit` logic of `targeted-archive-scan.py` without executing its local inventory code. Keep the depth limit of 10, handle ZIP/TAR/GZIP/XZ and `.b64` or `.base64`, and rely on actual content or recognized wrapper metadata. Stop on the exact match.
2. Check the target basename even when size differs and hash every exact 6,566-byte payload. Inventory container entries without extracting trees and descend into supported wrappers. Before re-decoding an inner wrapper, reuse a `known_inspected_sha256` match if its prior wrapper was actually processed under the same semantics. Cache newly visited wrapper digests within the job. Inspect decoded JSON and JSONL for source-bearing text or explicitly base64-encoded payload fields. Classify metadata only after reading structure and checking candidate payloads, and record parse/codec errors. A target digest or name in metadata is a pointer. An old `.olean` is a compiled artifact. Recovery requires the exact source bytes.
3. Include the 12 standalone Git bundles and any selected nested bundle. Read the pack into an isolated temporary bare store with network and lazy fetch disabled, then size-filter resident blob objects through `git cat-file --batch-all-objects --batch-check`. Check exact target basename when it is available in bundle trees. Report missing prerequisites or thin-pack base objects as explicit coverage limits without importing into an existing repository.
4. Apply a 150 MB per-container limit and a 2 GiB total decoded-byte budget. Use a deadline 15 seconds below the configured task timeout so the final receipt can be emitted. Report attempted/complete representative counts, nested duplicates, type and member counts, metadata payload checks, exact matches and size/name mismatches, and explicit path-specific errors or limits. Retain a hit only after exact byte count and SHA-256 verification. Treat a queued, timed-out or truncated job as partial evidence. No cloud job was created by this comparison.

## Large paths left open

These five paths were outside the inventory hashing threshold, so byte-identical deduplication and content coverage remain unresolved. Equal sizes alone cannot identify the three TAR paths as duplicates.

| Cloud path | Bytes |
|---|---:|
| `/workspace/p210-public-receiver-20261125/.lake/p210-public-receiver/inputs/bootstrap.zip` | 413,971,373 |
| `/workspace/p210-public-receiver-20261125/.lake/p210-public-receiver/inputs/bootstrap.tar.gz` | 413,971,227 |
| `/workspace/p210-public-receiver-20261125/.lake/p210-public-collection-45611402948-receive02/collection-tail.zip` | 221,637,364 |
| `/workspace/p210-public-receiver-20261125/.lake/p210-public-collection-45611402948-receive02/collection/bootstrap.tar.gz` | 413,971,227 |
| `/workspace/p210-public-receiver-20261125/.lake/p2-private/ci-imports/45611402948-1-687c35f8ef01/bootstrap.tar.gz` | 413,971,227 |
