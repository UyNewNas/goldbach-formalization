# P3.1 recovery log check

Both selected archives were resident at commit `5b9a6548bf2cd18f48b2858a881701b033b6f722` in the local `goldbach-p31` Git store. Their byte counts and SHA-256 values matched the P3 cloud inventory exactly. Reads used `git cat-file` with lazy fetch and Git network protocols disabled.

The three Base64 values that previously produced JSON `Extra data` all decode to UTF-8 JSONL. Each physical line is a valid JSON value. The first object ends on line 1 and the remaining lines account for the trailing data reported by the whole-document JSON parser.

| Selected payload | Decoded bytes | Valid JSON lines | JSON strings checked |
|---|---:|---:|---:|
| `source68-recovery.zip!p2-large-output-page000.b64` | 15,346 | 31 | 106 |
| `source68-recovery.zip!p2-output-page000.b64` | 62,279 | 211 | 580 |
| `queued-run-evidence.zip!setup-output.json/output_base64` | 854 | 4 | 22 |
| **Total** | **78,479** | **246** | **708** |

The target-only check covered the decoded texts, their raw lines with and without line endings, and the JSON strings and recognizable encoded fields. It found zero exact matches, zero 6,566-byte candidates, and zero target-name or digest references. The result resolves the three JSON parser limits for these named payloads. `p31-recovery-log-check.json` retains the verified archive identities, encoded and decoded fingerprints, and counts. The check read only these three payloads.
