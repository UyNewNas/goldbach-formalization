# P3 archive resume

The first target-only archive task `facdcdac8fbd434da09a827014184a67` exited 0 in 28.658 seconds with a partial receipt. It verified the outer fingerprints of 57 representatives before the 2 GiB cumulative expansion cap. Of those, 38 completed within the decoder's scope and 19 had coverage limits. The 2,127 checked payloads produced zero exact matches, zero same-name candidates, and zero 6,566-byte candidates for `Part3OriginalMediumPhysicalE3Block.lean`. The full locations and decoder messages are in `p3-archive-result.json`, SHA-256 `60b4daca9c09c53d1c605da533f2e6f75545ed0cb3b8d076fcf1c6faf36f7507`.

## First-pass P3 and rescue coverage

All **25 P3** representatives had their outer fingerprints checked. Eleven completed and 14 were partial. All **eight rescue exports** also had their outer fingerprints checked. Six completed, including the two standalone JSONL exports. The other two reached the decompressed container limit before the TAR members could be enumerated.

| Partial entries | Count | Recorded coverage limit |
|---|---:|---|
| P3.6 private `.bundle` files | 12 | Eleven declare one external prerequisite commit and `checkpoint.bundle` declares two. Isolated `index-pack` exited 128 for each, reporting 8–17 unresolved deltas. No resident blob inventory was obtained from those bundles. |
| P3.1 `source68-recovery.zip` and `queued-run-evidence.zip` | 2 | Three Base64 objects decoded successfully, then whole-document JSON parsing rejected trailing data. The receipt does not establish the text format or contents beyond the failed parses. |
| Rescue `priority-objects.tar.xz` and `evidence-receipts.tar.xz` | 2 | The decoded TAR spool hit the 150,000,000-byte container cap at the next chunk, 150,208,512 bytes. Neither decoded TAR reached member enumeration. |
| P2.9 `qualified-unit-tail-count.tar.xz` | 1 | Two JSON members, `borrowed-actual-imports-bindings.json` and `consumer-actual-imports-bindings.json`, were 27,062,843 and 27,063,729 bytes and exceeded the 24 MiB JSON document parser cap. |
| P2.9 `qualified-unit-tail-count.tar.gz` | 1 | The decoded TAR fingerprint matched the previous partial TAR. The decoder skipped reprocessing and retained the partial result. |
| P2.10 `collection/block-24.zip` | 1 | The 2 GiB cumulative cap interrupted expansion of `new-objects-and-receipts.tar.gz` before enumeration of its decoded TAR. |

## Resume scope

`p3-targeted-archive-resume.py` covers only the 78 original `not_attempted` entries. The embedded manifest preserves each original path, length and SHA-256.

| Cloud root | Representatives | Outer bytes |
|---|---:|---:|
| `/workspace/p210-public-receiver-20261125` | 62 | 161,412,495 |
| `/workspace/p25-q96-20261125` | 15 | 10,919,590 |
| `/workspace/p21-log-audit-20261126` | 1 | 44,304,524 |
| **Total** | **78** | **216,636,609** |

The resume adds the 38 complete outer fingerprints to the prior 1,452-digest skip set. The 19 partial outer fingerprints and the recorded duplicate partial inner TAR fingerprint are tracked separately. A matching inner wrapper stays partial and is not decoded again. The older receipt has no complete fingerprint inventory for other nested payloads. The five unhashed paths over 150 MB stay out of scope.

Run `python3 -B p3-targeted-archive-resume.py --out /workspace/<fresh-resume-directory> --seconds 840` under the same 900-second task limit, 1,024 MB, and one CPU. The cumulative expansion cap is 8 GiB. All other limits are carried forward, including 150,000,000 bytes per container, 384 MiB temporary storage, 640 MiB Python address space, and the 840-second internal deadline. Four times the first pass's measured 28.658 seconds is about 115 seconds as a planning estimate. Archive and JSON composition determine actual runtime. The script retains the complete JSON and gzip/Base64 evidence marker. The resume receipt alone covers the 78 previously unattempted outer paths.
