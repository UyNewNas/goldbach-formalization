"""Read-only lookup for one registered original source; no source synthesis."""
from pathlib import Path
from collections import Counter, defaultdict
import base64
import gzip
import hashlib
import io
import json
import lzma
import os
import re
import subprocess
import tarfile
import zipfile

OUT = Path(__file__).resolve().parent
REPO = Path('/workspace/library-files/p34-proof-work')
OLD = Path('/workspace/scratch/dcb7c80f70a4/p34-historical')
TARGET = '1ed9fec9d526f866fff9a29f9d8d0fa96d63def2a8b1e4e7a42ad759a8989982'
NAME = 'Part3OriginalMediumPhysicalE3Block'
SIZE = 6566
ENV = dict(os.environ, GIT_NO_LAZY_FETCH='1')
SUFFIXES = ('.zip', '.raw', '.tgz', '.tar', '.tar.gz', '.tar.xz', '.tar.zst', '.b64', '.gz', '.xz')
counts = Counter()
matches = []
named = []
issues = []
bundles = []
size_candidates = []
archive_receipts = []


def check(label, data):
    counts['payloads_examined'] += 1
    is_named = 'originalmediumphysicale3block' in label.rsplit('!', 1)[-1].rsplit('/', 1)[-1].lower()
    if len(data) != SIZE and not is_named:
        return
    digest = hashlib.sha256(data).hexdigest()
    row = dict(location=label, bytes=len(data), sha256=digest, exact_match=digest == TARGET)
    if len(data) == SIZE:
        counts['size_filtered_hashes'] += 1
        size_candidates.append(row)
    if is_named:
        named.append(row)
    if digest == TARGET:
        matches.append(row)
        (OUT / (NAME + '.lean')).write_bytes(data)


def supported(label):
    return label.lower().endswith(SUFFIXES)


def visit(label, data, depth=0):
    check(label, data)
    if depth > 10:
        issues.append(dict(location=label, error='archive recursion depth exceeded 10'))
        return
    suffix = label.rsplit('!', 1)[-1].lower()
    try:
        if data.startswith((b'# v2 git bundle', b'# v3 git bundle')):
            bundles.append(dict(location=label, bytes=len(data)))
            return
        if suffix.endswith('.b64'):
            visit(label + '!' + Path(suffix).name[:-4], base64.b64decode(data), depth + 1)
            counts['base64_decodes'] += 1
        elif data.startswith(b'PK') and zipfile.is_zipfile(io.BytesIO(data)):
            with zipfile.ZipFile(io.BytesIO(data)) as archive:
                for member in archive.infolist():
                    if member.is_dir():
                        continue
                    counts['zip_members_inspected'] += 1
                    loc = label + '!' + member.filename
                    if member.file_size == SIZE or 'originalmediumphysicale3block' in member.filename.lower() or supported(member.filename):
                        visit(loc, archive.read(member), depth + 1)
        elif suffix.endswith(('.tar', '.tgz', '.tar.gz', '.tar.xz')) or data[257:262] == b'ustar':
            with tarfile.open(fileobj=io.BytesIO(data), mode='r:*') as archive:
                for member in archive:
                    if not member.isfile():
                        continue
                    counts['tar_members_inspected'] += 1
                    loc = label + '!' + member.name
                    if member.size == SIZE or 'originalmediumphysicale3block' in member.name.lower() or supported(member.name):
                        visit(loc, archive.extractfile(member).read(), depth + 1)
                    elif member.name.endswith('.bundle'):
                        bundles.append(dict(location=loc, bytes=member.size, unpacked_elsewhere=True))
        elif data.startswith(b'\x1f\x8b'):
            counts['gzip_decodes'] += 1
            visit(label + '!' + Path(suffix).stem, gzip.decompress(data), depth + 1)
        elif data.startswith(b'\xfd7zXZ'):
            counts['xz_decodes'] += 1
            visit(label + '!' + Path(suffix).stem, lzma.decompress(data), depth + 1)
        elif suffix.endswith('.tar.zst'):
            issues.append(dict(location=label, error='zstd wrapper not decoded'))
    except (OSError, ValueError, tarfile.TarError, zipfile.BadZipFile, EOFError, lzma.LZMAError) as exc:
        issues.append(dict(location=label, error=str(exc)))


manifest = json.loads((REPO / 'docs/part3-distribution/p34-20261125/source-resolution-historical-supplement.json').read_text())
for name, expected in manifest['external_archives']['archives'].items():
    path = Path(expected['path'])
    receipt = dict(name=name, path=str(path), library_file_id=expected['library_file_id'])
    if name in ('goldbach-rebuild10.z01', 'goldbach-rebuild10.zip'):
        receipt['scope'] = 'Split duplicate: payload checked through the verified standalone rebuild10 tar.gz.'
    elif not path.exists():
        receipt['scope'] = 'Archive not resident; retained extracted rebuild01.bundle and all its Git objects inspected separately.'
    else:
        data = path.read_bytes()
        digest = hashlib.sha256(data).hexdigest()
        receipt.update(bytes=len(data), sha256=digest, manifest_digest_matches=digest == expected['sha256'])
        if digest != expected['sha256']:
            issues.append(dict(location=str(path), error='archive differs from prior recorded identity'))
        before = counts.copy()
        visit(str(path), data)
        receipt['counts'] = dict(counts - before)
    archive_receipts.append(receipt)

sources = defaultdict(set)
for oid, locations in json.loads((OUT / 'historical-archive-locations.json').read_text()).items():
    for commit, path in locations:
        sources[oid].add(('historical-index', commit, path))

# Reuse existing object/path inventories. No remote fetch is permitted.
repo_specs = [
    (str(REPO), None),
    (str(OLD / 'rebuild01.git'), 'cfdbcd9106428af5f3a61ebbc78b6bfb55c2f083'),
]
for path, tip in repo_specs:
    prefix = ['git', '--git-dir=' + path] if path.endswith('.git') else ['git', '-C', path]
    result = subprocess.run(prefix + ['rev-list', '--objects', tip or '--all'], capture_output=True, env=ENV)
    if result.returncode:
        issues.append(dict(location=path, error=result.stderr.decode()))
    for row in result.stdout.decode().splitlines():
        if ' ' not in row:
            continue
        oid, filename = row.split(' ', 1)
        if supported(filename):
            sources[oid].add((path, tip or '--all', filename))

stores = [
    str(OLD / 'history.git'),
    str(REPO / '.git'),
    str(OLD / 'rebuild01.git'),
    str(OLD / 'other-bundles.git'),
    '/workspace/scratch/dcb7c80f70a4/p34-delta/blobs.git',
]
store_objects = {}
for store in stores:
    result = subprocess.run(['git', '--git-dir=' + store, 'cat-file', '--batch-all-objects', '--batch-check=%(objectname) %(objecttype) %(objectsize)'], capture_output=True, env=ENV)
    for row in result.stdout.decode().splitlines():
        fields = row.split()
        if len(fields) == 3 and fields[1] == 'blob':
            store_objects.setdefault(fields[0], (store, int(fields[2])))

git_receipts = []
missing_objects = []
for number, (oid, places) in enumerate(sorted(sources.items()), 1):
    if oid not in store_objects:
        missing_objects.append(dict(oid=oid, locations=sorted(places)))
        continue
    store, size = store_objects[oid]
    result = subprocess.run(['git', '--git-dir=' + store, 'cat-file', 'blob', oid], capture_output=True, env=ENV)
    if result.returncode:
        issues.append(dict(location=oid, error=result.stderr.decode()))
        continue
    places = sorted(places)
    label = oid + '!' + places[0][2]
    before = counts.copy()
    visit(label, result.stdout)
    git_receipts.append(dict(oid=oid, bytes=size, store=store, locations=places, counts=dict(counts - before)))
    if number % 200 == 0:
        print(json.dumps(dict(progress=number, archive_oids=len(sources), matches=len(matches), counts=dict(counts))), flush=True)

report = dict(
    target=dict(module='ImbalancedChen.' + NAME, bytes=SIZE, sha256=TARGET),
    scope='This new target only; original 59-name/55-digest scan was not rerun. Only exact-size payloads and same-name candidates are hashed as source candidates.',
    counts=dict(counts),
    archive_receipts=archive_receipts,
    git_archive_blob_receipts=git_receipts,
    git_archive_blob_candidates=len(sources),
    unavailable_git_archive_blobs=missing_objects,
    bundle_members_reused=bundles,
    exact_matches=matches,
    same_name_candidates=named,
    size_candidates=size_candidates,
    issues=issues,
)
(OUT / 'archive-targeted-results.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(dict(completed=True, counts=dict(counts), archive_oids=len(sources), checked_archive_oids=len(git_receipts), unavailable_archive_oids=len(missing_objects), exact_matches=matches, same_name_candidates=named, issues=issues)), flush=True)
