#!/usr/bin/env python3
"""One-target P3 archive resume of the 78 previously unattempted outer paths. Use a fresh --out directory inside /workspace.

The embedded manifest is derived from p3-archive-dedup.json. This adapts its
companion targeted-archive-scan.py's check and visit rules without executing
that script's local inventory. There is no workspace traversal or network use.
"""
import argparse
import base64
import binascii
import bz2
from collections import Counter
from contextlib import contextmanager
import gzip
import hashlib
import io
import json
import lzma
import os
from pathlib import Path
import re
import resource
import signal
import stat
import struct
import subprocess
import tarfile
import tempfile
import time
import zipfile
import zlib


MIB = 1024 * 1024
CHUNK = 256 * 1024
CONTAINER_LIMIT = 150_000_000
EXPANDED_LIMIT = 8 * 1024 * MIB
TEMP_LIMIT = 384 * MIB
PYTHON_AS_LIMIT = 640 * MIB
GIT_AS_LIMIT = 256 * MIB
GIT_BUNDLE_LIMIT = 24 * MIB
GIT_OUTPUT_LIMIT = 8 * MIB
GIT_FILE_LIMIT = GIT_BUNDLE_LIMIT + MIB
MAX_GIT_OBJECTS = 20_000
MAX_MEMBERS = 50_000
MAX_ZIP_INDEX = 12 * MIB
MAX_JSON = 24 * MIB
MAX_JSONL_RECORD = 8 * MIB
MAX_JSON_ENCODING = 16 * MIB
MAX_DEPTH = 10
MAX_ISSUES = 10_000
MAX_CANDIDATES = 10_000
MAX_LABEL = 4096
TARGET_NAME = 'originalmediumphysicale3block'
UNSUPPORTED = ('.tar.zst', '.zst', '.rar', '.7z', '.lz4', '.zstd', '.lzip', '.lz', '.z')
SUPPORTED = ('.zip', '.raw', '.tgz', '.tar', '.gz', '.xz', '.b64', '.base64',
             '.bz2', '.bundle', '.json', '.jsonl', '.ndjson', '.tbz2') + UNSUPPORTED
B64_SPACE = re.compile(rb'\s+')
B64_TOKEN = re.compile(rb'[A-Za-z0-9+/_-]+={0,2}\Z')
HEX = re.compile(rb'[0-9a-fA-F]+\Z')
ENCODED_WORD = re.compile(r'(^|[_-])(b64|base64|hex)([_-]|$)', re.I)


class CoverageError(Exception):
    def __init__(self, kind, detail, stop=False):
        super().__init__(detail)
        self.kind = kind
        self.stop = stop
        self.location = None


class Found(Exception):
    pass


class JsonObject(list):
    """Preserve values under duplicate keys when examining structured evidence."""


def bounded(value, limit, kind):
    if value > limit:
        raise CoverageError(kind, f'{value} bytes or entries exceed limit {limit}')


def digest(data):
    return hashlib.sha256(data).hexdigest()


def signature(head, name):
    name = name.lower()
    if name.endswith(('.b64', '.base64')):
        return 'base64'
    if head.startswith((b'# v2 git bundle', b'# v3 git bundle')):
        return 'bundle'
    if head.startswith((b'PK\x03\x04', b'PK\x05\x06', b'PK\x07\x08')) or name.endswith('.zip'):
        return 'zip'
    if head.startswith(b'\x1f\x8b'):
        return 'gzip'
    if head.startswith(b'\xfd7zXZ\x00'):
        return 'xz'
    if head.startswith(b'BZh'):
        return 'bzip2'
    if head[257:262] == b'ustar' or name.endswith('.tar'):
        return 'tar'
    if name.endswith(('.jsonl', '.ndjson')):
        return 'jsonl'
    if name.endswith('.json') or head.lstrip().startswith((b'{', b'[')):
        return 'json'
    if name.endswith(UNSUPPORTED) or head.startswith((b'\x28\xb5\x2f\xfd', b'7z\xbc\xaf\x27\x1c', b'Rar!', b'\x04\x22\x4d\x18')):
        return 'unsupported_codec'
    if name.endswith(('.gz', '.tgz', '.xz', '.bz2', '.tbz2', '.bundle')):
        return 'invalid_wrapper'
    return None


def receipt_label(label):
    if len(label) > MAX_LABEL:
        return label[:MAX_LABEL] + '@label-sha256:' + digest(label.encode(errors='surrogatepass'))
    return label


def name_matches(label):
    # Same basename test as the local visit/check pair.
    return TARGET_NAME in label.rsplit('!', 1)[-1].rsplit('/', 1)[-1].lower()


def should_visit(name, size, target_size):
    return size == target_size or TARGET_NAME in name.lower() or name.lower().endswith(SUPPORTED)


class Scanner:
    def __init__(self, manifest, out, seconds, expanded_limit):
        self.manifest = manifest
        self.out = out
        self.target = manifest['target']
        self.target_size = self.target['bytes']
        self.known = set(manifest['known_inspected_sha256'])
        self.prior_partial = manifest['prior_partial_sha256']
        self.deadline = time.monotonic() + seconds
        self.expanded_limit = expanded_limit
        self.expanded = 0
        self.temporary_bytes = 0
        self.temporary_high_water = 0
        self.counts = Counter()
        self.seen = {}
        self.limits = []
        self.size_candidates = []
        self.same_name = []
        self.exact = []
        self.outer = []

    def charge(self, count):
        if count > self.expanded_limit - self.expanded:
            raise CoverageError('expanded_bytes', f'cumulative expansion exceeded {self.expanded_limit} bytes', stop=True)
        self.expanded += count

    def reserve(self, count):
        bounded(self.temporary_bytes + count, TEMP_LIMIT, 'temporary_disk')
        self.temporary_bytes += count
        self.temporary_high_water = max(self.temporary_high_water, self.temporary_bytes)

    def time_left(self):
        remaining = self.deadline - time.monotonic()
        if remaining <= 0:
            raise CoverageError('deadline', 'internal wall-clock deadline reached', stop=True)
        return remaining

    def limit(self, label, kind, detail):
        self.limits.append(dict(location=receipt_label(label), kind=kind, detail=str(detail)[:MAX_LABEL]))
        if len(self.limits) >= MAX_ISSUES:
            raise CoverageError('coverage_receipt_count', f'limit of {MAX_ISSUES} recorded coverage events reached', stop=True)

    @contextmanager
    def snapshot(self, chunks, expanded):
        size = 0
        sha = hashlib.sha256()
        with tempfile.TemporaryFile(dir=self.out) as spool:
            try:
                for chunk in chunks:
                    self.time_left()
                    bounded(size + len(chunk), CONTAINER_LIMIT, 'container_bytes')
                    if expanded:
                        self.charge(len(chunk))
                    self.reserve(len(chunk))
                    size += len(chunk)
                    spool.write(chunk)
                    sha.update(chunk)
                spool.seek(0)
                yield spool, size, sha.hexdigest()
            finally:
                self.temporary_bytes -= size

    def check(self, label, stream, size, sha):
        self.counts['payloads_examined'] += 1
        named = name_matches(label)
        if size != self.target_size and not named:
            return
        if len(self.size_candidates) + len(self.same_name) >= MAX_CANDIDATES:
            raise CoverageError('candidate_receipt_count', f'limit of {MAX_CANDIDATES} candidate receipts reached', stop=True)
        row = dict(location=receipt_label(label), bytes=size, sha256=sha, exact_match=size == self.target_size and sha == self.target['sha256'])
        if size == self.target_size:
            self.counts['size_filtered_hashes'] += 1
            self.size_candidates.append(row)
        if named:
            self.same_name.append(row)
        if row['exact_match']:
            stream.seek(0)
            original = stream.read(self.target_size + 1)
            if len(original) != self.target_size or digest(original) != sha:
                raise CoverageError('exact_bytes_recheck', 'candidate bytes changed during final check')
            with (self.out / (self.target['module'].rsplit('.', 1)[-1] + '.lean')).open('xb') as output:
                output.write(original)
            self.exact.append(row)
            raise Found

    def visit_stream(self, label, stream, depth, expected_size=None):
        try:
            if expected_size is not None:
                bounded(expected_size, CONTAINER_LIMIT, 'container_bytes')
            with self.snapshot(iter(lambda: stream.read(CHUNK), b''), expanded=True) as node:
                self.visit(label, *node, depth)
        except CoverageError as exc:
            if exc.location is None:
                exc.location = label
            raise

    def visit_member(self, label, stream, depth, size):
        try:
            self.visit_stream(label, stream, depth, size)
        except CoverageError as exc:
            if exc.stop:
                if exc.location is None:
                    exc.location = label
                raise
            self.limit(exc.location or label, exc.kind, exc)
        except (ValueError, OSError, RuntimeError, EOFError, zipfile.BadZipFile, tarfile.TarError, lzma.LZMAError) as exc:
            self.limit(label, 'read_or_decode', exc)

    def visit(self, label, stream, size, sha, depth):
        self.check(label, stream, size, sha)
        name = label.rsplit('!', 1)[-1].rsplit('/', 1)[-1]
        stream.seek(0)
        codec = signature(stream.read(512), name)
        stream.seek(0)
        if not codec:
            return
        if sha in self.known:
            self.counts['known_nested_skips'] += 1
            return
        if sha in self.prior_partial:
            self.counts['prior_partial_nested_skips'] += 1
            self.limit(label, 'prior_partial_duplicate', f'SHA-256 {sha} was partially covered at {self.prior_partial[sha]}')
            return
        key = (sha, codec)
        if key in self.seen:
            self.counts['same_job_nested_skips'] += 1
            if not self.seen[key]:
                self.limit(label, 'duplicate_of_partial', f'{codec} payload SHA-256 {sha} was only partially covered')
            return
        limits_before = len(self.limits)
        try:
            bounded(depth, MAX_DEPTH, 'recursion_depth')
            if codec == 'zip':
                self.visit_zip(label, stream, depth)
            elif codec == 'tar':
                self.visit_tar(label, stream, depth)
            elif codec in ('gzip', 'xz', 'bzip2'):
                self.counts[codec + '_decodes'] += 1
                wrapper = {'gzip': gzip.GzipFile, 'xz': lzma.LZMAFile, 'bzip2': bz2.BZ2File}[codec]
                inner = unwrapped_name(name)
                with wrapper(fileobj=stream) if codec == 'gzip' else wrapper(stream) as decoded:
                    self.visit_stream(label + '!' + inner, decoded, depth + 1)
            elif codec == 'base64':
                self.counts['base64_decodes'] += 1
                with self.snapshot(b64_chunks(stream), expanded=True) as node:
                    self.visit(label + '!' + unwrapped_name(name), *node, depth + 1)
            elif codec in ('json', 'jsonl'):
                self.visit_json(label, stream, size, depth, lines=codec == 'jsonl')
            elif codec == 'bundle':
                self.visit_bundle(label, stream, size, depth)
            else:
                self.limit(label, codec, f'no supported decoder for {name}')
        except CoverageError as exc:
            if exc.stop:
                if exc.location is None:
                    exc.location = label
                raise
            self.limit(exc.location or label, exc.kind, exc)
        except (ValueError, OSError, RuntimeError, EOFError, tarfile.TarError, zipfile.BadZipFile, lzma.LZMAError, zlib.error, RecursionError, subprocess.SubprocessError) as exc:
            self.limit(label, 'read_or_decode', exc)
        self.seen[key] = len(self.limits) == limits_before

    def visit_zip(self, label, stream, depth):
        # Bound the central directory before ZipFile materializes its entries.
        end = zipfile._EndRecData(stream)
        if end is None:
            raise zipfile.BadZipFile('ZIP end record unavailable')
        bounded(end[zipfile._ECD_SIZE], MAX_ZIP_INDEX, 'zip_central_directory')
        bounded(end[zipfile._ECD_ENTRIES_TOTAL], MAX_MEMBERS, 'archive_entry_count')
        stream.seek(0)
        with zipfile.ZipFile(stream) as archive:
            for count, member in enumerate(archive.infolist(), start=1):
                bounded(count, MAX_MEMBERS, 'archive_entry_count')
                self.time_left()
                if member.is_dir():
                    continue
                self.counts['zip_members_inspected'] += 1
                if not should_visit(member.filename, member.file_size, self.target_size):
                    continue
                loc = label + '!' + member.filename
                try:
                    with archive.open(member) as entry:
                        self.visit_member(loc, entry, depth + 1, member.file_size)
                except (ValueError, OSError, RuntimeError, zipfile.BadZipFile) as exc:
                    self.limit(loc, 'zip_member', exc)

    def visit_tar(self, label, stream, depth):
        with tarfile.open(fileobj=stream, mode='r|') as archive:
            for count, member in enumerate(archive, start=1):
                bounded(count, MAX_MEMBERS, 'archive_entry_count')
                self.time_left()
                if not member.isfile():
                    continue
                self.counts['tar_members_inspected'] += 1
                if not should_visit(member.name, member.size, self.target_size):
                    continue
                loc = label + '!' + member.name
                with archive.extractfile(member) as entry:
                    self.visit_member(loc, entry, depth + 1, member.size)

    def visit_json(self, label, stream, size, depth, lines):
        self.counts['jsonl_payloads' if lines else 'json_payloads'] += 1
        if not lines:
            bounded(size, MAX_JSON, 'json_document_bytes')
            self.json_values(label, json.load(stream, object_pairs_hook=JsonObject), depth)
            return
        line_number = 0
        while True:
            self.time_left()
            line = stream.readline(MAX_JSONL_RECORD + 1)
            if not line:
                return
            line_number += 1
            loc = f'{label}!line {line_number}'
            if len(line) > MAX_JSONL_RECORD:
                self.limit(loc, 'jsonl_record_bytes', f'record is over {MAX_JSONL_RECORD} bytes')
                while line and not line.endswith(b'\n'):
                    self.time_left()
                    line = stream.readline(CHUNK)
                continue
            if line.strip():
                try:
                    self.json_values(loc, json.loads(line, object_pairs_hook=JsonObject), depth)
                except (ValueError, RecursionError) as exc:
                    self.limit(loc, 'jsonl_parse', exc)

    def json_values(self, label, value, depth):
        # Walk one node at a time. Keep labels bounded for deeply nested metadata.
        def walk(loc, item, key='', hint='', nesting=0):
            self.time_left()
            bounded(nesting, 128, 'json_nesting')
            if isinstance(item, JsonObject):
                self.counts['json_objects'] += 1
                encoding = next((val for key, val in item if key == 'encoding' and isinstance(val, str)), '')
                for field, child in item:
                    hint_for_field = encoding.lower() if field.lower() in ('content', 'payload', 'data', 'blob', 'bytes', 'source', 'body', 'value') else ''
                    walk(f'{loc}/{field[:240]}', child, field, hint_for_field, nesting + 1)
            elif isinstance(item, list):
                for index, child in enumerate(item):
                    walk(f'{loc}/{index}', child, key, hint, nesting + 1)
            elif isinstance(item, str):
                self.json_string(loc, item, key, hint, depth)

        walk(label, value)

    def json_string(self, label, value, key, hint, depth):
        self.counts['json_strings'] += 1
        raw = value.encode('utf-8', errors='surrogatepass')
        if TARGET_NAME in value.lower() or self.target['sha256'] in value.lower():
            self.counts['metadata_name_or_digest_mentions'] += 1
        if len(raw) == self.target_size or name_matches(label):
            self.check(label, io.BytesIO(raw), len(raw), digest(raw))
        encoding = ENCODED_WORD.search(key)
        hint = hint or (encoding.group(2).lower() if encoding else '')
        if raw.startswith(b'data:') and b';base64,' in raw[:512]:
            raw = raw.split(b';base64,', 1)[1]
            hint = 'base64'
        if hint in ('utf-8', 'utf8', 'text', 'plain', 'ascii', 'none'):
            hint = ''
        parts = re.split(r'\s*[+,/]\s*', hint)
        if len(parts) == 2 and 'base64' in parts and set(parts) & {'gzip', 'xz', 'bzip2', 'tar', 'zip'}:
            hint = 'base64'
        # Screen by length or decoded magic before attempting unlabelled data.
        compact_length = (self.target_size + 2) // 3 * 4
        if not hint:
            if len(raw) == 2 * self.target_size and HEX.fullmatch(raw):
                hint = 'hex'
            elif len(raw) >= compact_length - 2 or raw[:4] in (b'UEsD', b'H4sI', b'/Td6', b'Qlpo', b'IyB2'):
                probe = B64_SPACE.sub(b'', raw[:32])
                probe = probe[:len(probe) // 4 * 4]
                try:
                    head = base64.b64decode(probe, altchars=b'-_', validate=True)
                except binascii.Error:
                    return
                if len(raw) <= MAX_JSON_ENCODING:
                    compact = B64_SPACE.sub(b'', raw)
                    if (compact_length - 2 <= len(compact) <= compact_length and B64_TOKEN.fullmatch(compact)) or signature(head, ''):
                        hint = 'base64'
                elif signature(head, ''):
                    hint = 'base64'
        if not hint:
            return
        if hint not in ('base64', 'b64', 'base64url', 'base64-url', 'hex', 'hexadecimal'):
            self.limit(label, 'json_payload_encoding', f'unsupported payload encoding {hint[:120]}')
            return
        bounded(len(raw), MAX_JSON_ENCODING, 'json_encoded_string_bytes')
        try:
            if hint in ('hex', 'hexadecimal'):
                chunks = (binascii.unhexlify(B64_SPACE.sub(b'', raw)),)
            else:
                chunks = b64_chunks(io.BytesIO(raw))
            with self.snapshot(chunks, expanded=True) as node:
                self.counts['json_encoded_strings_decoded'] += 1
                self.visit(label + '!decoded-payload', *node, depth + 1)
        except (ValueError, binascii.Error) as exc:
            self.limit(label, 'json_payload_decode', exc)

    def visit_bundle(self, label, stream, size, depth):
        bounded(size, GIT_BUNDLE_LIMIT, 'git_bundle_bytes')
        offset, algo, prerequisites, filtered = bundle_header(stream)
        if prerequisites:
            self.limit(label, 'git_prerequisites', f'{prerequisites} prerequisite commits outside the bundle')
        if filtered:
            self.limit(label, 'git_bundle_filter', 'bundle advertises object filtering')
        preflight_pack(stream, 20 if algo == 'sha1' else 32, self.charge, self.time_left)
        self.counts['git_bundle_decodes'] += 1
        # Pack, index, output files, and all Git temp paths stay under --out.
        reserve = size + GIT_FILE_LIMIT * 2 + 4 * MIB
        self.reserve(reserve)
        try:
            with tempfile.TemporaryDirectory(prefix='bundle-', dir=self.out) as tmp:
                self.scan_pack(label, stream, offset, algo, depth, Path(tmp))
        finally:
            self.temporary_bytes -= reserve

    def scan_pack(self, label, stream, offset, algo, depth, work):
        env = {'PATH': os.environ.get('PATH', '/usr/bin:/bin'), 'LANG': 'C',
               'TMPDIR': str(work), 'GIT_CONFIG_GLOBAL': '/dev/null', 'GIT_CONFIG_NOSYSTEM': '1',
               'GIT_NO_LAZY_FETCH': '1', 'GIT_ALLOW_PROTOCOL': '', 'GIT_TERMINAL_PROMPT': '0',
               'GIT_OPTIONAL_LOCKS': '0'}
        repo = work / 'pack.git'
        with tempfile.TemporaryFile(dir=work) as stdout, tempfile.TemporaryFile(dir=work) as stderr:
            def command(args, stdin=None):
                for fp in (stdout, stderr):
                    fp.seek(0)
                    fp.truncate(0)
                # Child commands never use a shell, remote or the ambient Git config.
                result = subprocess.run(['git', '--git-dir=' + str(repo), '-c', 'pack.threads=1',
                                         '-c', 'core.deltaBaseCacheLimit=16m', *args],
                                        cwd=work, env=env, stdin=stdin if stdin is not None else subprocess.DEVNULL,
                                        stdout=stdout, stderr=stderr, preexec_fn=git_limits,
                                        timeout=min(45, self.time_left()))
                stdout.seek(0)
                stderr.seek(0)
                if result.returncode:
                    raise CoverageError('git_isolated_command', f'{args[0]} exit {result.returncode}: ' + stderr.read(2048).decode(errors='replace').strip())
                result_bytes = stdout.read(GIT_OUTPUT_LIMIT + 1)
                bounded(len(result_bytes), GIT_OUTPUT_LIMIT, 'git_command_output')
                return result_bytes

            command(['init', '--bare', '--template=', '--object-format=' + algo])
            stream.seek(offset)
            # The underlying descriptor position must match the pack header for Git stdin.
            os.lseek(stream.fileno(), offset, os.SEEK_SET)
            command(['index-pack', '--stdin', '--strict', '--threads=1'], stream)
            info = command(['cat-file', '--batch-all-objects', '--batch-check=%(objectname) %(objecttype) %(objectsize)'])
            objects = parse_pack_object_info(info, algo)
            self.counts['git_resident_objects'] += len(objects)
            names = {}
            checked_blobs = set()
            for oid, (kind, obj_size) in objects.items():
                if kind == b'blob' and obj_size == self.target_size:
                    self.visit_git_blob(label, command, oid, 'size-candidate', depth, obj_size)
                    checked_blobs.add(oid)
            for oid, (kind, obj_size) in objects.items():
                if kind != b'tree':
                    continue
                bounded(obj_size, GIT_OUTPUT_LIMIT, 'git_tree_bytes')
                tree = command(['cat-file', 'tree', oid])
                self.charge(len(tree))
                self.counts['git_trees_inspected'] += 1
                for mode, name, child in git_tree_entries(tree, 20 if algo == 'sha1' else 32):
                    if mode not in (b'100644', b'100755') or not should_visit(name, -1, self.target_size):
                        continue
                    if child in objects and objects[child][0] == b'blob':
                        if child not in names or name_matches(name):
                            names[child] = name
                    else:
                        self.limit(label + '!' + name, 'git_missing_tree_blob', f'blob {child} unavailable in bundle')
            for oid, name in names.items():
                if oid not in checked_blobs or name_matches(name):
                    self.visit_git_blob(label, command, oid, name, depth, objects[oid][1])

    def visit_git_blob(self, label, command, oid, name, depth, size):
        loc = f'{label}!{oid}!{name}'
        if size > GIT_OUTPUT_LIMIT:
            self.limit(loc, 'git_blob_bytes', f'{size} bytes exceeds {GIT_OUTPUT_LIMIT}')
            return
        data = command(['cat-file', 'blob', oid])
        if len(data) != size:
            raise CoverageError('git_blob_size', f'blob {oid} size differs from isolated Git inventory')
        self.charge(len(data))
        self.visit(loc, io.BytesIO(data), size, digest(data), depth + 1)

    def outer_archive(self, row, workspace):
        path = Path(row['path'])
        if row['sha256'] in self.known or row['sha256'] in self.prior_partial:
            raise CoverageError('allowlist_identity', 'previously attempted fingerprint presented as uninspected')
        if not path.is_absolute() or not path.resolve(strict=True).is_relative_to(workspace):
            raise CoverageError('allowlist_path', 'archive path resolved outside the supplied workspace')
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        with os.fdopen(fd, 'rb') as stream:
            details = os.fstat(stream.fileno())
            if not stat.S_ISREG(details.st_mode) or details.st_size != row['bytes']:
                raise CoverageError('outer_size_or_type', f'expected regular file of {row["bytes"]} bytes, observed {details.st_size} bytes')
            with self.snapshot(iter(lambda: stream.read(CHUNK), b''), expanded=False) as node:
                if (node[1], node[2]) != (row['bytes'], row['sha256']):
                    raise CoverageError('outer_fingerprint', f'expected {row["sha256"]}, observed {node[2]} and {node[1]} bytes')
                self.counts['verified_outer_fingerprints'] += 1
                self.visit(row['path'], *node, 0)


def unwrapped_name(name):
    lower = name.lower()
    if lower.endswith('.tgz'):
        return name[:-4] + '.tar'
    if lower.endswith('.tbz2'):
        return name[:-5] + '.tar'
    return Path(name).stem or 'decoded-payload'


def b64_chunks(stream):
    pending = b''
    saw_padding = False
    for chunk in iter(lambda: stream.read(CHUNK), b''):
        compact = pending + B64_SPACE.sub(b'', chunk)
        if saw_padding and compact:
            raise binascii.Error('data follows base64 padding')
        split = len(compact) // 4 * 4
        pending = compact[split:]
        if split:
            encoded = compact[:split]
            saw_padding = b'=' in encoded
            yield base64.b64decode(encoded, altchars=b'-_', validate=True)
    if pending:
        if saw_padding:
            raise binascii.Error('data follows base64 padding')
        yield base64.b64decode(pending + b'=' * (-len(pending) % 4), altchars=b'-_', validate=True)


def git_limits():
    for kind, bound in ((resource.RLIMIT_AS, GIT_AS_LIMIT), (resource.RLIMIT_FSIZE, GIT_FILE_LIMIT)):
        _, hard = resource.getrlimit(kind)
        resource.setrlimit(kind, (min(hard, bound) if hard != resource.RLIM_INFINITY else bound, hard))


def bundle_header(stream):
    magic = stream.readline(128).rstrip(b'\r\n')
    if magic not in (b'# v2 git bundle', b'# v3 git bundle'):
        raise CoverageError('git_bundle_header', 'unsupported bundle header')
    algo = 'sha1'
    prerequisites = 0
    filtered = False
    count = 0
    while True:
        bounded(stream.tell(), 64 * 1024, 'git_bundle_headers')
        line = stream.readline(4097)
        bounded(len(line), 4096, 'git_bundle_header_line')
        if not line:
            raise CoverageError('git_bundle_header', 'missing pack data')
        if line in (b'\n', b'\r\n'):
            return stream.tell(), algo, prerequisites, filtered
        count += 1
        bounded(count, 512, 'git_bundle_ref_count')
        if line.startswith(b'-'):
            prerequisites += 1
        elif line.startswith(b'@object-format='):
            candidate = line.strip().partition(b'=')[2]
            if candidate not in (b'sha1', b'sha256'):
                raise CoverageError('git_object_format', f'unsupported bundle object format {candidate!r}')
            algo = candidate.decode()
        elif line.startswith(b'@filter='):
            filtered = True
        elif line.startswith(b'@'):
            raise CoverageError('git_bundle_capability', f'unsupported bundle capability {line[:80]!r}')


def pack_octet(stream):
    value = stream.read(1)
    if not value:
        raise CoverageError('git_pack_header', 'truncated pack entry header')
    return value[0]


def delta_target_size(data):
    pos = 0
    value = 0
    for _ in range(2):
        value = 0
        shift = 0
        while True:
            if pos >= len(data) or shift >= 56:
                raise CoverageError('git_pack_delta_header', 'invalid pack delta size prefix')
            octet = data[pos]
            pos += 1
            value |= (octet & 127) << shift
            if not octet & 128:
                break
            shift += 7
    return value


def preflight_pack(stream, ref_bytes, charge, time_left):
    header = stream.read(12)
    if len(header) != 12 or header[:4] != b'PACK':
        raise CoverageError('git_pack_header', 'missing pack signature')
    version, count = struct.unpack('>II', header[4:])
    if version not in (2, 3):
        raise CoverageError('git_pack_version', f'unsupported pack version {version}')
    bounded(count, MAX_GIT_OBJECTS, 'git_pack_object_count')
    # Bundle REF_DELTA IDs are either 20 or 32 bytes. Determine algorithm from caller.
    for _ in range(count):
        time_left()
        first = pack_octet(stream)
        kind = (first >> 4) & 7
        arc_size = first & 15
        shift = 4
        while first & 128:
            first = pack_octet(stream)
            arc_size |= (first & 127) << shift
            shift += 7
            bounded(shift, 60, 'git_pack_size_header')
        if kind not in (1, 2, 3, 4, 6, 7):
            raise CoverageError('git_pack_object_kind', f'unsupported pack object kind {kind}')
        bounded(arc_size, CONTAINER_LIMIT, 'git_object_bytes')
        charge(arc_size)
        if kind == 6:
            for index in range(9):
                if not pack_octet(stream) & 128:
                    break
            else:
                raise CoverageError('git_pack_delta_header', f'invalid offset delta length {index + 1}')
        elif kind == 7:
            if len(stream.read(ref_bytes)) != ref_bytes:
                raise CoverageError('git_pack_delta_header', 'truncated delta base object ID')
        decoder = zlib.decompressobj()
        decoded = 0
        prefix = bytearray()
        pending = b''
        while not decoder.eof:
            time_left()
            data = pending or stream.read(CHUNK)
            if not data:
                raise CoverageError('git_pack_fragment', 'truncated packed zlib stream')
            got = decoder.decompress(data, CHUNK)
            pending = decoder.unconsumed_tail
            decoded += len(got)
            bounded(decoded, arc_size, 'git_pack_declared_size')
            if kind in (6, 7) and len(prefix) < 16:
                prefix.extend(got[:16 - len(prefix)])
        if decoder.unused_data:
            stream.seek(-len(decoder.unused_data), os.SEEK_CUR)
        if decoded != arc_size:
            raise CoverageError('git_pack_declared_size', f'declared {arc_size} bytes, observed {decoded}')
        if kind in (6, 7):
            target_size = delta_target_size(prefix)
            bounded(target_size, CONTAINER_LIMIT, 'git_delta_expanded_size')
            charge(target_size)


def parse_pack_object_info(data, algo):
    width = 40 if algo == 'sha1' else 64
    rows = {}
    for line in data.splitlines():
        oid, kind, size = line.split()
        if len(oid) != width or not HEX.fullmatch(oid):
            raise CoverageError('git_pack_inventory', 'isolated Git returned a malformed object ID')
        rows[oid.decode('ascii')] = (kind, int(size))
    bounded(len(rows), MAX_GIT_OBJECTS, 'git_pack_object_count')
    return rows


def git_tree_entries(tree, hash_bytes):
    pos = 0
    while pos < len(tree):
        sep = tree.index(b' ', pos)
        end = tree.index(b'\0', sep + 1)
        next_pos = end + 1 + hash_bytes
        if next_pos > len(tree):
            raise CoverageError('git_tree_format', 'truncated object ID in tree')
        yield tree[pos:sep], tree[sep + 1:end].decode('utf-8', errors='replace'), tree[end + 1:next_pos].hex()
        pos = next_pos


def priority(row):
    root = Path(row['path']).parts[2]
    if re.match(r'p3[0-9]-', root):
        return 0
    if root == 'rescue-export-20261126':
        return 1
    return 2


def scan_manifest(manifest, out, seconds, workspace, expanded_limit=EXPANDED_LIMIT):
    scanner = Scanner(manifest, out, seconds, expanded_limit)
    rows = sorted(manifest['uninspected_hashed'], key=priority)
    scanner.outer = [dict(path=r['path'], bytes=r['bytes'], sha256=r['sha256'], status='not_attempted') for r in rows]
    stop = None

    def alarm(_signum, _frame):
        raise CoverageError('deadline', 'internal wall-clock deadline reached', stop=True)

    prior_handler = signal.signal(signal.SIGALRM, alarm)
    signal.setitimer(signal.ITIMER_REAL, seconds)
    try:
        for row, receipt in zip(rows, scanner.outer):
            prior_limits = len(scanner.limits)
            receipt['status'] = 'partial'
            try:
                scanner.outer_archive(row, workspace)
            except Found:
                receipt['status'] = 'exact_match'
                stop = 'exact_match'
                break
            except CoverageError as exc:
                scanner.limits.append(dict(location=receipt_label(exc.location or row['path']), kind=exc.kind, detail=str(exc)[:MAX_LABEL]))
                if exc.stop:
                    stop = exc.kind
                    break
            except MemoryError:
                scanner.limits.append(dict(location=row['path'], kind='address_space', detail='allocation failed under process memory limit'))
                stop = 'address_space'
                break
            except (OSError, ValueError, EOFError) as exc:
                scanner.limits.append(dict(location=row['path'], kind='outer_read', detail=str(exc)))
            else:
                receipt['status'] = 'complete' if len(scanner.limits) == prior_limits else 'partial'
    except CoverageError as exc:
        scanner.limits.append(dict(location=receipt_label(exc.location or 'run'), kind=exc.kind, detail=str(exc)[:MAX_LABEL]))
        stop = exc.kind
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        signal.signal(signal.SIGALRM, prior_handler)
    status = ('exact_match' if scanner.exact else 'partial' if scanner.limits or stop
              else 'hashed_scope_negative')
    return dict(target=scanner.target, status=status, stop_reason=stop,
                cloud_inventory_task=manifest.get('cloud_inventory_task'),
                resume_from_task=manifest['resume_from_task'],
                resume_from_receipt_sha256=manifest['resume_from_receipt_sha256'],
                prior_partial_outer_representatives_skipped=manifest['prior_partial_outer_representatives_skipped'],
                counts=dict(scanner.counts), outer_status_counts=dict(Counter(r['status'] for r in scanner.outer)),
                outer_receipts=scanner.outer, exact_matches=scanner.exact, same_name_candidates=scanner.same_name,
                size_candidates=scanner.size_candidates, coverage_limits=scanner.limits,
                known_outer_representatives_skipped=manifest.get('known_outer_representatives_skipped'),
                unhashed_large_not_read=manifest['unhashed_large'],
                resource_use=dict(expanded_or_reserved_object_bytes=scanner.expanded,
                                  temporary_high_water_bytes=scanner.temporary_high_water),
                resource_caps=dict(expanded_bytes=expanded_limit, container_bytes=CONTAINER_LIMIT,
                                   temporary_disk_bytes=TEMP_LIMIT, git_bundle_bytes=GIT_BUNDLE_LIMIT,
                                   git_blob_output_bytes=GIT_OUTPUT_LIMIT, git_file_bytes=GIT_FILE_LIMIT,
                                   git_pack_objects=MAX_GIT_OBJECTS,
                                   python_address_space_bytes=PYTHON_AS_LIMIT, git_address_space_bytes=GIT_AS_LIMIT,
                                   archive_entries=MAX_MEMBERS, zip_central_directory_bytes=MAX_ZIP_INDEX,
                                   json_document_bytes=MAX_JSON, jsonl_record_bytes=MAX_JSONL_RECORD,
                                   json_encoded_string_bytes=MAX_JSON_ENCODING, recursion_depth=MAX_DEPTH,
                                   coverage_events=MAX_ISSUES, candidate_receipts=MAX_CANDIDATES,
                                   wall_seconds=seconds),
                inherited_scope='Known nested digests retain the local or first cloud attempt scope. Prior partial digests remain open. This receipt covers only the 78 previously unattempted outer paths.',
                selection_scope='Regular archive entries were selected by exact size, target name, or supported suffix. Symlink entries are not followed and unlabelled nested formats may be outside this pass.')


def embedded_manifest():
    decoded = zlib.decompress(base64.b85decode(MANIFEST_DATA))
    length, = struct.unpack('>I', decoded[:4])
    manifest = json.loads(decoded[4:4 + length])
    hashes = decoded[4 + length:]
    if len(hashes) % 32:
        raise ValueError('embedded SHA-256 list has invalid length')
    manifest['known_inspected_sha256'] = [hashes[n:n + 32].hex() for n in range(0, len(hashes), 32)]
    return manifest


def emit_marker(tag, path):
    with path.open('rb') as stream:
        sha = hashlib.sha256()
        for chunk in iter(lambda: stream.read(CHUNK), b''):
            sha.update(chunk)
        print(f'BEGIN_{tag} bytes={stream.tell()} sha256={sha.hexdigest()}')
        stream.seek(0)
        for chunk in iter(lambda: stream.read(2250), b''):
            print(base64.b64encode(chunk).decode('ascii'))
    print(f'END_{tag}', flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, help='fresh root-owned output directory below /workspace')
    parser.add_argument('--seconds', type=int, default=840, help='internal deadline, at most 840 seconds')
    parser.add_argument('--print-manifest', action='store_true', help='print embedded allowlist and exit without reading archive paths')
    args = parser.parse_args()
    manifest = embedded_manifest()
    if args.print_manifest:
        print(json.dumps(manifest, indent=2))
        return
    workspace = Path('/workspace').resolve(strict=True)
    if (args.out is None or not args.out.is_absolute() or not args.out.resolve().is_relative_to(workspace)
            or args.out.resolve() == workspace or not 1 <= args.seconds <= 840):
        parser.error('require a fresh absolute --out under /workspace and 1 <= --seconds <= 840')
    args.out.mkdir(mode=0o700, exist_ok=False)
    out = args.out.resolve(strict=True)
    _, hard = resource.getrlimit(resource.RLIMIT_AS)
    resource.setrlimit(resource.RLIMIT_AS, (min(hard, PYTHON_AS_LIMIT) if hard != resource.RLIM_INFINITY else PYTHON_AS_LIMIT, hard))
    result = scan_manifest(manifest, out, args.seconds, workspace)
    report_path = out / 'result.json'
    compressed_path = out / 'result.json.gz'
    with report_path.open('x', encoding='utf-8') as report:
        json.dump(result, report, indent=2, sort_keys=True)
        report.write('\n')
    with report_path.open('rb') as report, gzip.GzipFile(filename=str(compressed_path), mode='wb', mtime=0) as compressed:
        for chunk in iter(lambda: report.read(CHUNK), b''):
            compressed.write(chunk)
    print(json.dumps(dict(status=result['status'], target=manifest['target'], result=str(out / 'result.json'),
                          outer=result['outer_status_counts'], limits=len(result['coverage_limits']),
                          unhashed_large_not_read=len(result['unhashed_large_not_read']),
                          known_outer_representatives_skipped=result['known_outer_representatives_skipped'],
                          prior_partial_outer_representatives_skipped=result['prior_partial_outer_representatives_skipped'],
                          exact_matches=len(result['exact_matches'])), sort_keys=True), flush=True)
    emit_marker('P3_ARCHIVE_RESULT_JSON_GZ_BASE64', compressed_path)
    if result['exact_matches']:
        emit_marker('P3_EXACT_LEAN_SOURCE_BASE64', out / (manifest['target']['module'].rsplit('.', 1)[-1] + '.lean'))


# Frozen resume input data. Use --print-manifest to review paths and digests.
MANIFEST_DATA = (
    'c-qvw2VBp4`#(;Lj6{(p%BVEndz2X>k&F~c-m}u)Mk17vLL{=OjL0V0dqk4V>{V7mWK@3F+qus<xo^(x{J-~o_xL}~<Ka-B@w%?p'
    'bv?&xyc;wa<2l(hf(!GJB24Wjn+67pkpYsaovAAq7J&~5^Yifw;sORsqF-d7tM9~cKY<JAhdTrW3;w27ru@VRDcsbKA}PwsG~AcN'
    'NDAJHN+K&u0xOajB{LKy%QDMhtjvmxh{zmEi4-nMGR84HDiIRR5f~@ZB+D@@!?Fx!I>pLV2ndc8z5Rlsq@al4u!-IgT)01cG=az@'
    'Cz29M^EiRyBEusXf-yYFp&Z3YGK?uQ$d?QEl|=6VB`8xn2=Dii1w{q~{4r<(#aSA~X&k;RI5G&LN3BdlxCmeP8r$gLF#qrnPLOOv'
    'Fch&4iR1(P1nV$Kko=;gFl+cu3Pmx})+T`S|M6>V{enUwBf@R@;NXbxh%he1W|ChBMD~}X!7%!NH5!<58=px(9}tG26eNct{<8xT'
    'f&&61A;K>>$eJMGMFfJe1oQh_5zMyE3nDnbfO^T=-x%cI$moA`u+|}Aeo<V6WGnbt`vryshr#659V=>0F|>e_G9$?d`h!t=DV^dM'
    '6dnR`K(qYTGv9TKDF@9eAS8!K62c0!j4MAUB@$yek*6t%h2g@m2vX){QYLYkXAqnxp|M$>k$9;NKwt<-63icg<NxznQUJ>uCI6+I'
    'Ohr~8SV_PcLLe|q5D9@NX_;VI0wq`;BUuLKO-2z4;lI6tkR*zcBmrRv7AF|CPLL=`;0RjZL1Os721y{COz<4d%K`#ZMj;YGlLU{@'
    '3@^(JBjXIhATp1mI6)B<$*?%e$RvwP5+<XNitlHV#_@U&68qO6ag-A!3B?$UW>J*JMS&u5ipF4835Me^5oKipr3HZ&P?3UJhVG!C'
    'f?=WsT*C3XGszGnQ|~j0{$M60653h9c#fnvQN&3?gc-qbhNW<x7X%iQB@w8Q5ny(CMuho<v``oY{R-1dFm-1VXK0eF?;vsF2Q$gC'
    'f<&^Yz)B*`inNGOtbhr!2-7MOJS)jGg)tPv3nGJ%papmqCnbTPB#03~`R{s?Vi3B%gCu@Xt|%xNL8Nh(AXpK;3*#t)A!(MUP!8uP'
    '7Kh@b7z$%0XjxQ1L<Z$}s8eWEf<y?qZjdy>(Djb41p1?yL^%?{Ie|nN5NjaZNF3lshIlBEV+EN*1c?!7kwXz&AOsqUTV^rnWLXfQ'
    'hwBDO(JWc-Gl~9SCRvy^K?DiQ<04K`Ec6_Qk~EYfOG_+?V-$z*7{c)=OVAPx@X0YipP-8wUX<nUcoHK)&enU7)DI|xmL(7XC?T?-'
    'wLu(m94n(xtH2+Wgn|~waVSep89$3s6e&>9krGex5+OjJ)}2WfNCvC-AlZKnlEMX!fLa9LWS}$^f&`|-Nr97~K4lVRd4wfF{E!qO'
    '15e5fE1^8R3+9@`Y3Vx(p;)s1dlLEAATdP51&EW8d0sJ61TJ70ObHDFf#G?S1VqAUkbMYfJ{Hsg=o+442ps$X54`wikTeDkk09!O'
    'CVxO79B3L$LIfUzNhCq`fDuJ#nuFe>Xb}TxO90Y<1C?l;5G4cwGL;31kXb~c1%muDNED|)1=c@>{6GxgA`~Z203(Vdj)OLZ+GSB7'
    'L74$tj7rd_oX80b2aU>sT%`#>C=O>x2FGY#K)&lq7OQ{7gERjcB#knlLV0L6m@^6$cnbcLd4N^;2$mP&r-aCG7|3!66cGhPu^$2k'
    'g$u9*A5oVlDW?7v5B38W0(dA>9L<6t0ELP$D2q^}h_NyhE8q$VrivzU3FZ+;2oy9AC?J3rf}uzf9GdvuOd?=Y>U}1EfUYzn69^bB'
    'P&xwCsQ`g6l8A_`5;=}TurdoXD1+A`2$aVtk!KiG=9C8IAgJ%ql>u0;ci{Pf;(=-f>j;8d=|2)9Y2XJIzLW#v=W%c)G%d(HCF2-}'
    'K?`CEwE$ZpG$L^*{%r;8&maMbsd_Kh9|Va}7)Ro$2(bajlN>GM1R*1!>_m>{c!@$3UQhxDz>xr@z?k4LnY_p{62g#m6%WcXSiSp6'
    'l>XNs5m_X`gh11wAbfBz7bGwu7)lzK7#OqCe=JLqI4kf34Y~mQ6fg+EhysnH^mi)*EDmwjdru-i;z<r=QK&u!M?m+0eiLPhVo~T-'
    'U<~L&1VLm8p;3}yaL@>th+qWHa{>eiY57jp(Kwj0dN0=>%_Iz(r9rg`tbnt$2$~IQlED@Eh9HszhC?Jdh7<)7%2T97fg%87p<o37'
    'SPuD~LU5$s(G~dty7GXoBCsLY4Th6QFoZbE;RwqMI0?~WAki6G2G)RVASg>p2qlXI$W)w=0Ey}EfrqB+UDn}0a3KiLJO*M7jFpHA'
    '49P+3VIadnv5`10$Os4I!ALx`r-(>A!ULm1Rxnb)c}4GiH<Qq_^>4L)(31>CAtFzJwF0RF)5zl}OM{Bz5t)|2Az~r`FK8kWY%>j#'
    'Mnot~qCx#&2q`iG|J`aG0<Nsyd-4ZCQWSV%O0kTr3=@M&63>yqA2JDQRt8~*E8YUcfB+f@r)5Tzcma4s5aHjLT!%t1Xk`?yk41GQ'
    'xNuv9g@}V9!h!?pCM!$|j|`M-gTL*dh1;Sef`V3qP*B_O;K(pR`hh+oWq?$IQkK>MdPtU}MVdkpgkVUS0vpXzkPJd%5Qc&ek_DD#'
    'C=5ph5R4K{)tPq;6h4jCUrKP~7gIvgG*IZzQzFP9;!yz;NfD&Jgdr@Aa18uOh+xfe925o$HdYovao_;(kQ?{`4YGuVY_WLVl#m$1'
    ')?Z3c{1;O~fW>AQ;-@JQ5tai5NuweHzK#Iuk^sO(9>GP3TxJ0(SQ2zLC4Flp_#q)MBDexUfWOgo8;1m8TAx+&t0|!ok|1#Arzrt5'
    '2=FN4-~bUyl1N|ys1_NBp1?&)S({-bf{{>2j7*Y}%%Xra03$Mn3X)XUJz)fc*1^mFeU)Ipj3uB%DC(yvk(H!z$~q6pfc63P2^@&w'
    '2u(l;xI%~U!6Hv_D8Zr>%ahPs4Co_9B54d4>ZAlD1WMIoO0Zu}359_~rGJ_dLZC>V2JMG}E}|KlmqFx+xWw}iK4?QIADjbKA!48m'
    'P{3f|8yWisw**GY{CAAQ5@bE5g!uK8fLi}~m7t=s*$H$i5tK{|gn*HRD1g#upd>i>0EVYTkzhe$K?6!8j31GC5y2se9L-~Ou>=Fj'
    'Tz@Gcei=&`79sGT!z&IALJMHufmb;OxD^9v;ed`M8p?r@L2{Aca8Z%P5rN`xWi6Z+2!+aU#YTNc!fbu&66}|C31BPB{=7=S1@XKn'
    'fCxpQ83cjgBo+l?76=e<3?xdT2xVK20#Jg!5Jf>2l|q656(L)vN^lfoP`V!BmHyR~;3P`W_)k;9Aq+wb7$@U`%-{qH-UCz!N3jA5'
    'fATWe4}fQyK)_nz1i}&=ya>Y}%g{zB{$1nH7){k93IA%9u!K_L<X`9#9Osq8UZ6Zso|8FQ5*b;d2?B-mu$)Bmtb}5e1ezXdhGQ{;'
    'Bv=vBjMCs#k?-J@VzGLxl3!J?v|_K2pQ~32<5)?S00=~$5fBh%ECLh-KAdMn5vM7RLP!z?5~c`-hr*C)90S)1uR#TZp}tQEU7uLO'
    '{4%^^G(r75B@7FoAySmGd?<^+$H3WuCK3QDsCX9QW^o<_D+N*wasu^4f&BqBkFf$H;B~8n!~t*Wk#T;tN*D?x7=rvXB^aadgv7`Q'
    '$;*_or-%~*4jM$@IOrZysTmpY20RYX4a);3k&?1JE^rbe)@2+NA;AjQBbcDSEKG2Wf$sUaFrk$LV^AUlA&4Y!4hu3xS=51kB3O!H'
    'F%DuOL9%iTEz2wpf5iw{k_ALiR<*vvR~kY8e~=QAq!5I~eqJV$vJwqag97RC+o4)etsvWRNnj;X;t)(AP)3BbN<1rbG{ex~3K?aQ'
    'TG{FSzH_j81QP=NRmuT(kCW`reILQg3ThDWB8EdmkrBY&Q6h#zGB^Uq5rjiQtce0Ih~VsS2mn-z46+U&h33EaeN25e4*Kg0CNzco'
    'T$m_sg+W1>ur#nL!;=CbL9ik!lc4dH^<f@U4$0A!D3CZKP=X+UkO$+;Bk&^rpX6&jE|}oIoDyXt2Kl)#;c-zpUId1j2HPy6h_Xn)'
    'd{eXV3z@=bgpx^IghVJu9{_AI5+E3nC>hK%_Z^lfD<<_=CBMqTgc1q%bCW~hf^wjh!fBbu!QlX)(yVfrKqe^;B)WhiGOa8pafF27'
    '0!g#7;+Zjq;t-CN>F=-vq3Y8LQ@_eM2!Yb%&l^WTpc+86^EBu*9)iM^Wk(DEln1gQBoJ$aD8ZL2`|Sk6NEojyz<^?rWSo${6DCSY'
    ')?=0Ys-h=x7R2|@8An+}r7(=<c^uM$qMWkZ0(upfa1`foiAH#i0*8kotRw=yAh@#F1jPchjC1mLjDxXcJvI*Zt6GhMpOeI2q(s?6'
    'gwF?_p+Tt=l0@<thai#?xXddTN=RNgR7^5F2HsZyvnPTj=1`iWF`Tb!g-K9A^;jjp+Bjg+K-K?zbpWsvTrDXg90__HYJr7*5h+pP'
    'QI0`5iNH9VV_8&06#!u=gpmb6Ck_)OLIg`(r%FHoq4n4}_^-k%$a&E8KVNASS%handtvZ>vSMWr@HOxbiN`ToU^xtd&H_zFP@I5)'
    '_mOyzZW6|D1SVtXcPUY<Fj0?E?N=9HSx^uR`*T6hv#bEIa6H3MBB@-Wzy$zXiGlJF2~Oldy8#%n6bopB3pg|oBI7v4vjoL5)OT0{'
    'd|jU#IpnW44hAy)FLo^`2^_z~QX&B|RXKd1+&lrWB~euAAaKYCuQ)#nhfMGsK@iYDB&nPi0y+}$@6;<&pHdC^<<$X{1%x2}Vs(H6'
    'v#T5kCj?BQP>v87Qo?yfz=9VBPN6Z3!4*12U>KqVm4bln1Ia7Vtblz_!bE*C&M&K1jDnn?f3a&J0J+l2A#z!!1x6H<Yk3$1C%~`3'
    '@v(%&f^efS9)K9y5C_G^LbWJoUKsSd?LGvl*If(xmjykT`M=oPB4rU6n3YjMlx2j)CFRf=!vn!!3=N$CR3o4u%6Kq?BF-rH23Q$`'
    'CczmIqw3zA01~E9rXCsRR~H9pkgh2EbB{xEBoHcSc^n6Hg_2TEcM~iCrE+pa2Ajiy0AnOpW^kNGI0_gCCnypVl-qCUcj^`ScAK}}'
    'ss#V#Dq+F)|GaT<PPvo-=mD%NqJSDK%TqGO(L4YL4~CJHlym$tFfdJG1V=!Vp*++c!a(Iv!go#>q3Uth0>^$CUTK^_{~{$kfFuvB'
    'q%5!s1Sxa4fD#ywLvbN2j1?3qBSAvI{NWTz$tbDZ^k4}D2N@!LmlDWmePYS4k}yrM6iNTZ;sC$`#`0itG3AH>4S)i|okeJjVt9!~'
    '1u%LdORx-~T(QDM8Hxu|h2sn-Ng|DWf98g)Pb~S>l&}yvnBku<G|C*X5`Ze8Cx8TjGRoB!s1=z*DCHy}*g%9vNabRva)C=CNS@;f'
    'USK7hAvyWG115BRZsg$9FK^_q%39;kSJhAvRKKz-&dC5HJS9mW)PZzKfu=#x^8$tmh_W&*i3Co7#1T18Swe#J5MY?UPYGS0Rr0GO'
    '3=>Dwe*v$`(isPe6jVDXR2)RTL~_c>S>=$sO!BzQi^?@lUO81FD0gg84qhh_yi7}w!n#k7pjqb6118vyQ$kvYvechh5QBwqTgZ!_'
    '>?d&FjvD^sSCloRhO}0K^b3mo?N_p&6d+>WT#)D;795QrKf0=KiZcX_Q-}ytO-Q^_?<}}4990fjQLIej1T+N0;~ay4C<h5fQv@TB'
    'k_6^fAgMarFbwhwYsvqYctlAE7Nsz6!IujQ_vRuZq`;5}1i`&Q;QcT*lEYC{<`l-GQAxQ_g2=oCf>J<u3L^y>^pip!H1sRY5j+MO'
    'lH(XcR?ZM(RNd1+4DnwLEg(4BTaJ_hyk*WWATmtymZJPbDF`a?M{&WQD2|ZI`5gdlj8^{2D?5n{OEM%YDYs2Xf(L=4tcSCrBoP8M'
    'lz;$`^B7hKs=!nId!+im1QsT7%9Q;P-(SW>%LJi#K;@vX40cdC2g_j+Esz39ARMYJ7{H$}Z33@sgi#Eb1X>aVS|U(htV7iBUIzcK'
    '_m+1^Sg;R(NS$Ite;633EkYn9loLT@VjK_%unJBy05=jZasrqZ5tSH@1+*Ypm_m*N9V-)@q#V(b>+XnuJEZ>KoUsth`!`%vP$M!('
    'ME`ou;C~>#fCgz1`V%052jh+^r_ebDq&CZ=gb0pI0%1-eFpa20;2cGu$^#0N#j-k~vGB(KE+U4Y&|u*aq7>oHfx!%kki;K@B1%gf'
    '&L}cbRu(hhe;7^xqbMhAl_v{Oj6^e-gi{iWfB-^ikrIIO5EM~P2@!SY3osJ>Z_by%1qBBw&nNmfn8DJ(Y~Tnao`UH?lv{MD071yI'
    'OrbJDiUi9lTLm;&XmF08ss&uR?u%l|^D^qr6NHQWS0j=F0uaRe&%nlq2M2wlvELcsk9Na;+-@QSM@tgL5uo7_<zhBTqX>zKG$u1B'
    'M}y=SIc1j}6ppfsitva8!&IKkL`!vXUkU!-tK0umNpcedf;rJ!4hRlbSPi25Cw}{Jj2JJ-fDuY~2*)Fg%%Uhn1OH@jS)_OhOg|?B'
    '=s-|VpaMZDR)&{&1lWzMdlwD#9r9nTP}wiYFGBJbg8v<_NgRnGhy+!NP?F4YJR?E*@i03qBJjKjGLsVtQRWzBS4z3YEs4q{5#<;S'
    'O>uScpT-%6{vQ<SZ#?i@UH&^3V8C*TC`=4s3ve4NGXh7@;5;EnR2F4S#t;!S77bL!av&W+iJ<UWfKpZ_n7R%FVe!8i-0!lNw2ln&'
    'iR8jWNwoe=<c8b+Id0pKFqom>$Z$o02ZxE_HcIdPOC%^oQ9Q#@42)P1NQTA%3P}RvXhtNJLy@$gT#>{%6a|OLND?X2%GN7Kzzp(y'
    '9nlD`oF-}N|5GrcALkPk93J5(e0#-jGh+R1My$g_0{kMZr3s2bu&xsy7bf_Ev9RH}aET)RiOK|-;FV_q(V#LYWy@1kW(b&@rGUaH'
    '@CGD76C@xe0nsQoTA>yN0l`R-!Nj_zm?ja5LH=h^eOHX%UQ|aOf2+j_|1^UvCP0(XoU+UzeOqHDL=;p#LxApr&QpXXkRD3VJWY|P'
    'qy!5^N+BS+WO(tPu@VFhW)J)KyEWDU!9LbpqzDoG-dBH`G3y{`t0+maWD$T9w!h=VKRlXsAm<nKN2YAT1N;L22+PaL)ITUVI><XX'
    'G6J|EOoAE?mx3a`ePFnExW8XWi1LgtTsi#n+sAp!VZnjFKU@!{P!yEs1%Pz}7b|iI%P}CTQ9`*GN-686b>H>PnubJp|GA-o@XDcI'
    '5N`;`A6!HQ3fPn*aa_hEN~TGYASDq14CfgUp($CA;U$nnT>0g<8;Ia(gTuT-xUdL6pu2w)hqC4I{TqHC%4Ac7l6e$n5m6=*I1kh}'
    't30g?tT_gytz6{gB^m({BM{2r7Xsl)5km!@hKiOE`JX3^1+;+qQXWb7$D~;^D6TA(QMRFxTmXP2AjzMv`c?$L&yAI-NYl!5C`cLH'
    'r2x7?<S>R{1zrXq2TdrFP-T!G3}ZQ5Idp-8Zw6fq8lUH6iADdD1M*P@#7m&rSPbQHMUjde#}N$1At1X&5=cd)l{GFzpl}`xvGQ0H'
    '6r+{%0<7Zk0UG}2mk57*%7>LHP$A44N=Z;$VD=~(5+}$wIClgz3N1*o@*p~8>qy`z<+MJ?9Eb?0MkFu*=YJYFj#`HV`-KC#TL*AK'
    'Quv=e`HcpZ(!#Apzwn4KKR)s|rSkK){6-|yw?Kj+1rz@<W(L720aGq&ia3k2%7eL}3poHB5s_s{;!si~QGrC2i)<_}fmUWkMmd%*'
    '%OV1X?!P$Z&`2o~3MDKu$odaa^4q8>2@<G~vGPn9mgQ*)$Du(u8nhunV>m`DYv&?3X<X@J<;p5eFd}dSPAMmhz8^I-u@EW!4%&Zw'
    '{kIPGi<oE~%#Vi&5C5}eK+6ay&yXC?(qI5t<v{`{j**aHS`-8V5ph`=2muhqEBAFMfO3oiUQ!O)^TaQGeI0!L24{7?pQb38Wx*~m'
    '%8?Eh7nO6m7>bJm0*t{btAQM}2sj}g+K5)J6Cuje^AHR?J4yV@q*1>w*;$KHfYKln>t-Q1ScWl#aDHLoHaytP0A<e`*a`G4&@K<<'
    '!IC_VU=k)EC`XXItn{dIs*&XZBuD^io<unm=n7IrgXG}2zcqwtE-cU*UJRumMZhm$t_A4LKL-Pb4gdlL8;&Xm93+ax!2!Vlc#NfF'
    '<%xUBW34zu#+4g*ys}gZqf%Cv7*W8*zcrX|&!GkN708A80O9>MB4uA(2B-SRh(rNIJvcaw;Yj5K0V{~0u>epd86!mStsJC*R;~_X'
    'fNS5@5EvR$?qdiN&m-91OHY7;p$e}3HX0F=aa<7o9E~J^(*XJ-7@YieRfq!G69gIsMUGIMOhZ!(ECNL%Val^3frStbq&rQ3>!Kv|'
    '?~I0*A~<WMzlDf@42Q&J0%Mpzhr>uH^dwDycENy_K}(B3F9=F0M=b~u!%2`an8-puu^1S6mWSlAm@I-XCMcBrJHruz0|NnB1Yb$;'
    '2bck#`C}L|!b7G=PT9d`5lR$EN>q;Y3(Ecii;%3cWedU|a86*Mx|MxQ3Wi4@jN)nJzg@y|a9AK0U|rY0ShGAz0r%EvEYRt=Od<qW'
    '3Sb{zl9cUIC|{TvUU}e-Bnqe~;{-G{$UsUVYnJC=V3YuEjQcyI3X&#7SpTHKK@m{2#G?c&DyKbIl%#OwZBP;-)Co@V$|D*`9B6?6'
    'C5~}CDf1YxGKotx_`<(4j&G}2enCFgV6_85PyJrUynv8+ox-6=Wt#*1mxyzigkuc!9K1w%G&3->a`6qA3`$l6eI*j$r$w;WI4LU!'
    'HUKF9RvrJNgrQ=jFwmdCOSr@+H>>^}4x!vW!-;RtVZ&L3Km<`%uG3&LI1X9nlxNP0P_+!q7Yk{_SrQyRCju~X0*+ySyMTUc@^7<-'
    '3BV*W`{!W5l`DpUS57m5Q2O?KNet{Bm;zD+=>}ZD6C@{tn-e);C6SONnj)auln4JH^xtZ#A9d5WWnhHFB$y4*=|Di>$v7Alt{i?>'
    'o_YluLSO*%fU#sj+02(wg2ZVOSMJIGXJurEzkGq|lqn6GMo)O-yik`Kde*0<Ufzx2$@fPjs0J;lIQyhlqvgq|4fIDn{UXn+whexo'
    'baC6KqP8FQIK>UkRnfV(?o`Z@!PyN4bvW+dFvD&68~X##^aFigX4<?>oYcGZ$eyW(E_rNlZIGZhI*Ff72Mu?M)4Hq~A4w+Z9JFrc'
    '5Hl?CX@Xj<U4ystgIhU7dM32^TKedcWk6DSGh+M4PmeDr>h5a%vfrr&A0kGMG)o%TGN5ni2YH-IbCFgb+;7LhXOG^Q7^K}B-=In('
    'X5h2Fy|e@SCvTpR73+6O)J-j9tkym@5l+TUY0}W@L990!cqq-gyw+~aBD;%CcLgt~-LbySxOeM|Vsy$HO4o-tT{akCH2tKtiyRYj'
    'HvMcgQ=@vY?Ss*Ym3~)=hJ_mpa=+eP`C>-n<%>7zK6e=L&h**Bfc_c=Z%1oidFR})JR#D5%1&?75%Sfd4>@mFrggulRp!~Sy3($F'
    '?a+y{8-DV%Wb?F72R2XfS(_AZuNB)Tu6oVeiDAixNA)(Wrd6EOO-dK8aoTI)b@gM%*;)-V5AI(+^ep92@hL8A(k=s)(AfCFstp4l'
    '2Rw12Tv2XunfIXVs1F10-D>K$&$YjX%Jfx(BlcxoSa!+&+T_$k$7^ixJvz(Q@O}THf;Sge8mR1e`{|Csm+5hGj>}X10Y+M(*EPzr'
    'vnFh6*msM`-4YX(W2-Kmnd3TZ{^dDqo(z7PIb~+_{eX^<vyUgg*ij)=G*|U{R<UQ8h4%Vl!s5)uxgFnBg(r_cH*cErdaIpI9kh?A'
    'rg`dVRfe4D`J^NzYWf(})ekebsK2(Ya<Du2A}yb<Rjr+z)phoTuDJ&8LxxVWAJlvAN5k!1ESv*tW|vbQHJjATyo$R9*sw<C%^a2&'
    'de|(EDCZV$?z(VGSh$<Pu>0X^gZJ%SaQ=bz(Fy5$UGFY_Z`SB`msz8i>{cti<oI^`8BMj!MNEy`^!tqmx(s!Xe-P-l`hD_#x4`)o'
    '%(Rk6O~yS@%lrIFlij|dMol#<-)zvAwLUM68dy!CYMt~hbJc97+R2&7zz<n9qnB^ocYVF>a;>Z5P7dm?=ASvo{j^;<Zmf3Z`fk0F'
    'rO`xX6Li<gwzZby8|+Zczh9-@+5B_qUa?&5{=`U?kB>jD6h9ax5oKS*g_3sSmm9H;Z3pPJNAA8-d)nc`nV|GtZS;(DwZ>erwwd3u'
    'QG|Cp9|u+A7xDd5iq&=2n>Se!ZF=u<!}7i634%^;!g$@u%Tu1sTv4UDYhfexo`atjmv0DcskzcG(CtXvv~X?Hj>is7eqwaEB=0Tl'
    's_wA<LEg&t3s!E?*=rbBx$ffVL3cmoFORxC$LL5J)y-3VSg8E0=?s@nWiv`s8`v@K#%ujMT74Nm&fu+jLG?Csb>CzC!#|l{ncd#N'
    '`jbhCxGM5kfX^hy^dW|?Tus+s{i1&6byzFouD5)WpBhh!SRD24&FAakhaGRW9hKYZy<K&s26iL9<Ggif2|q^b+R8P%Hyh{X+;5LG'
    'Uzjtdk4ofmJ&nO#4sM+OWm~mp^TrMw>t8m=aDHB^VWVs++r)-2=_wj(pF2)TMPs90%=KN+G5k>Dn<vcYznArsdR#kw?kJL~v0i;='
    '+JdKT($Wi`9RINKa_ZBV+AUsM&sW_Y5>mPAjlafm?a_}OXt=)|sA;-&&_?9(Gxen=2RltjT6royX~~Xl8ZRCjl=Lp8uDGmfQImAx'
    'Zfm=1Ir{!4Cp&Kn*>hO6)51n$p7qKYk)`9;b?7~RE#s<v4I6K5JjGWpG{9<I|C#{fMt(!zo(z^bEyH{ItxFm%UQu<^w_=-q5AF72'
    'ONLezJZdz%)1ba_1wBrxEgW63tVnJzW?H+AI)rWB==6^E3O&|nXJ0Js!Qhbwa#f|q)gZLJM=Rs~4_jKiSfKsrd_x2EMz^>1Sz!LO'
    'dGW5IJ>=KI%TJFo18!A?wRS%i{c6>R;A@SZ4gTObVd$Q%V|?bl(HvbA+<AK6j$`%P8lBl^W;1?i&qkGZ#>Mn^JKF92iH*JH-GBYy'
    '#=fP|H5~@rR-NE-xEjCRxbgj21!d>PwDWuse(tiD_q(&#nDbOd`kL;=C0sWz-Nwx=9DL^4Je%TNY>GzPR+#%X4P6%Ks<CF;u6<Y3'
    'B1beH+qb6Q&fHFJC^96&ZdH@r%rg6c>=T+UYx3@1X+PDjF@J40=G<tf<r=)f3fE1tr=IHRX4l*g+b`Hsvb>B=YaDfaVbsKwRfFE2'
    'Bfmt(FQAjc?vx%%o^;HiNz?Kfhg2Ic9g`BW?4aSOCf#%0<_{%X2R?ZlWxB0ThUTEG4r{IiH_i*2|C+ziqSG}0-O+Dc`JmKl|C*vQ'
    'cY_sS8J;U=)igfWYL^MRwuezoMs2yzyORE@wNC4MI^S?^6hAAa+U|v>fxeODRi~7#_kppJF9ld;3!mLrdhfj<>Am&6dF7?1S<>4M'
    '?jJL^b@c6iZTKAj@O!&E1XBDZzRQh$w_V<x)U;eZX3pclriWEV7EWEEy8L;Ljl@i_?Ei)Oa$&oA?JUjVZ(sBr$z?=ee5mu)EzGER'
    '=fVu*J`d;aYV<J0$XIQXrcc@S_fI2k*cLxZU9}z={^i8iw+k(&h}`w`_islg7i!M=WMa73RcElD<F>=EE@?E<-%~hYa;KiFy5D;D'
    '>2auvW^%yu?uOTe#QnvuUtgHaE_<}pV@x}9m#SMwwoK^0qe^psv)NXoI~G-?rdX)lnA6uqI(_P@nK|)cfS$YB@ut@_&m_HC-Qr>9'
    'wf0r7hR$5wwq<OP?fLS|E~Y)5XS7^tY1%}6<rBA$HM0%|Sm_AqDV<jh8Iz*lVs-jb^QI2{S0?8)VLRM#c{!-$LxbTV$Cu2}Z(LFn'
    'cXjlIEANkt=q_ziIou>_k=`1uGx-I#b5d928qQ3+JSwo=smHjv<)>3}ALlJirUhOoJ-X*sc}(`i0|wrj9dpPckB(HhLF-8CvE4f@'
    'YpT05{Alr$!}Ep?JKr##weA&Hb<NEAw9b>24+28pA8>5iWz_2A`=531INq}v9>7LjyEFNc)m87;H@lSXS?%}St7$*_%yhQ_9aT#Q'
    'C!%%*+!ggL_N#3DbH;}^d%5w>fD=u}o%9-UqcZN<$tnHs>CD(0eAhRlqf_7Vyar{f`&lpS)HJZx12?Q1nzKgZ<BVnL=F|J<6}^>C'
    'd|l?!Y|p~Tk~K}|L?rIJ_Gs0tXHoNOwjMcEJpLA|+O>mwK}cn{Cu5IVH_dNjMjn~nDCKIyf{An9N%8HNw>B%B`ui{4qq8?UJiKZC'
    'VE5r(lhw|3d)z$ya_t%i&2@Ih@A0W;+>YIyC_ebwOl8bUN#(fB{T3%$k$E?D#lpO$cGKGD^y-|TRblM&zL`hJMTg+l>JOswG7Iny'
    'evfY~(do9nuiBO3o*iAnyCBWP52xFQ6mt7jjz<cWfo$ILv_qSkH(Be21ZO>+bmL32NfkBiQ{76M?hMb{#q0KL)2oT`aF5D6L%;4Q'
    'SouUvz1gy7rk869JkC3Ne{^+UIV5XhWl1b{`OuqF%YBAd7e+K6ZnCu@pXux8Or9~5wquUZ$5L~XCJpQVam<7YzqYHJe`%;w7-w+f'
    '^a%EPd<S}-#mW%A12cV1Rng<F8#Zn*(xOyfPFT||GwV9<Zg^EIvaRWXKIhJ?RsX2s>Utn&%2=)F?695G@U4OCZZ+HOdvxWZJuSy='
    'i}sZET{#td;AXs_wRXvU$Jg|xj<k9DC%1luN9I3M>(%XCT(hHA;WOrp{M@2pUWC;aa>(fp+<_xKmO3nIR9%}l&~CMnhDMauMYHM_'
    '{sVeYabvFZp5vc9Q)SYmL6N;aJDo!(Ta28fKIoWtd5e%6rM@#dNA-?9wKe|Mi{`T;S33`!>{gj7boFrd;q+Qm#BblsEorbk&%gPs'
    'D7EgX8K$K}hb0GWyZNvUH4{(OM&9Mj-|YT)^W+#=cdoA%a%lXUglE2~3Ab`LEm<s`(mt&BxZ5zt$u*lt9347*(VP|4*l6tG`DgLv'
    'U1HBX&Z4znw&-m;wXfMZ*Kum6@h$0_)kEaPRqIzCDDr5%CVoO`%V86o-%i_b#yu>d&*7!otvw#kC`o+q*2jCC<urD9(C3yTN-dwh'
    'zZ@K&ayN9|$Jcv@Svt-uw;Q6Zv7%q0sX>TQ%T%J_>VWWrme-RzF6r{3U0C4$k2T(gp`lS}dr!1-n$&V_^MbcJ`dg<h+0}KP|K&|d'
    'pP~jhEFUEnZg5s@xc?~DGA~iRQKF95=-rzvqPKV6H(<}~o<X?El^Jy5a_gN1n_4xT>XYJ8y&;?XKoZLuj5iqB`{k0+SgBrgC3VSm'
    'v_>nnh~g*bAFa8)r}v^SsSk&Yv6_DWlUkgh+vAOY^Ut(Rt2QlpBj-aw%aaoB8_)H=Q6y<~p4iFf_I=yNDz~pE4{PPpa@f4CeH*t6'
    'n9FtP(ctC41??Yb4E=Px(J9p9*>3gSt+FE87he04e(dt%>t}`^(a+KEL1%6>X@~mwuP`0h_)4qGZ}yap==Hv;K;y;8L96>sd7wXZ'
    '(ZTLty7g5HOVsNX(yD09z`2CZkfavR%i4WB&$l=<v+JE(Llesjcc4asZgHz;Q#K_UwSCe_Z^4F>s}?qX9@;N)vE9J-1&x*rRyCj`'
    'ofZ>=-K}1CcR9SP$;(_Pv*UN3sFqYsuRh5pG`g=cqo<Cw_-gr^3+*>IIug_VM1w-Zzyn(I3GKI)LEG;V6)7!sCV73bigjC}Gr&Dv'
    'eXl1%6_z#}vV&Ul^zF-aM-LwvrxWY3!!feO*mVnYX8ArGP`;<f)1u5>johnjV*2Uy-ZN8Y>H7kw1g-Q3M)#)Wt~ppE+?&3m+&_Lp'
    'QNPxzy?3r(pmRTcy=%{g@zYYTWmgSq`S@e@*M#f0wGWJ*rg{C*_WaGd&DWKb=UwUC*59VL89O!qYFT*cI{R1cjy7z*cuv8gP+j|B'
    'SZ(GEK04mz)o?4vh#JpDNa=;SEqz{j#fFa2DbWo-cC@qWgSO%n_0B$twVUoQI~38Z)Ba~g4=c~?ET*37&hF&aD!1)}hvrX57cEMX'
    'Kd*^Pi|{yqw|pko*L>F1p1LO-PY068e2(<dNf#Zw!6!E^%lNkGt*2(S4F;}cB6RbeOCLRCT7>nncHVu&B)U;=y%%Gtp<i6v)?CsI'
    'N)6YoVYbWXV(x}#Mu+u|Y4I`Q$f=`mJXiAbvghUwzfj7w)+=-~+_g4;iFJ?ueO%^ubJ0C0NJ|oo3A3vjY+izC>mF&D7lurq8Pk7b'
    'LEh8Lr1gxRgw8PCiBWqdU$9?vb9L*CVlt_RzV&!={_fU0KCI9mn_k$spjFQ&t_}2$a2Zvtb0^sDJdWJam~_q2IR0E=o3RNeAA4<j'
    'A2DvzgPBn(1#OzHT{Zpm<1VVPcd8ASq@L_Zb`G$L?ob@&eXV^5ZtR;jt|Q~mIofNM4cw8G-sRbWQ|gzdch8zW?|$?1t^Br~pVcPj'
    'nQ3N1_j``hUw%1%Iqq_iH*#al&UBBG%gt*KhQ2dtv)tKw)oF|Q%}m^?FJ4cLYij7aNA`?#%5v)FZic_tYjZg9QNW!AhrQ=@Ntjr<'
    'uu*E-3ArY8UQO$`PP^M3kDbuw62CK)%Z!?D=IAqnZjk@V>0W34;Mg&bHc$3WMaSj0DLR&Ir_<y@JD1xLHJ4)6U#C<vN4~3c-><W_'
    '?-i~15p8a01lgx&INm<ELK-=M=^z*uFj<wxL!Q2@TBv8`+)uCZj*3^EuG_sSTz=3KX{MtUGStpKxVw4!^5`~$@-@5ZHMwQ`e&wlA'
    ')ZMd1x%jebt5w<NE3#_F?ONqv$%hu?=?&^JI7w)--_6%Y-Zf;%>NN)p&(^r)ot%8@MsUZ+#YuW@dtU^_#3wv%vSmIy@vODR^uYXH'
    'rM(~J6wBQ+#y>o+7kdL4*Y4dr^WJ7}Lhl?f4IP`kz;)5=w-2RJW0yr7eV}(ZG;p?~li|m*i+6Kx=mcK3zrY4evQV8Do72jOy8le?'
    '&Y~vCH|7m-Ax~vIzc7W{9GzzA?y!V)coS*ZO=s<Ey@z2Dd7tLY{j7dD)gv;AT3=o?!t?0$@t>BS?>_(Kj$FOh*PTOK^~WzSXxTu;'
    '^YbA4rcd2tPG(K9-f8jHchB|FdKL3lTv#_~(-ln3eA*a~McwzexJx};ZBdij^1;T1m(<#FT07O-ThVq~#;=~1KYYCR;`bv>g4M9s'
    '5#G(UzIe}R%STt$_Ss-~Y4>jPyE&toOKD+ot=gJR8Zh<2K(7@awb~Y(?G%{*<Z{@ozNbo;ES{b^d1B^Aqd8|1R&>6!+WLfs{)qLH'
    '`|OWSUC=znDb%P%rRBVhPj2}q_K?jE8HRM2>ZI>~#MeG}-BLexQ~UkiE|sg()^g`eM>w08?O*kIPfr*9K>wqU@8>=(F)>O$Hm9&p'
    '*W${?s?DpsT*vI%eQR#}N&0bD%hmaXvn$?p7}|IH;F)}bu7^I2P1@(w>Q$H0(tHd3gwNXsYhI42*xPvAqIZW)wWYxOV?}vHe*D_1'
    '2HSRe>aQ$J?a{jg7tSnv+MzFVGWCVLc|RAL=%iL)wor4VgMP^doheI<Ke!6*7QL}8dtSXPWzm!7pFBG!<ZZmUKyR`BhXDzmwU?f`'
    '#0_1XpZ#oG$EDq8Ur}EgIY@LElCDzgV6ZUyx#>lF!_dLwV#jQ2bF;VZ=@~9QD^?En4n21GbB(saI*&-p-M*76mvl;bJI%}&-?3x='
    'vZC{Pi=s<b4!Yl0#o*e)4zr4Gx{hId%MNLOc&7H|dW+ZHC+6hvE7KCo^ZgCpy`)w9IPSAcZq$P?npkBx=6HX*2Wp|S-<=LVTWRNH'
    '*m~Tp_d6{nv{H*&{h-f)2kUaQZ|*l~T=Rq<-Ry;jj;bMTnUHN!*<gh<ywjdb+FLBHnKX9_y))s_mEMmdj`zn5-O!@a#{M%OE|acT'
    '7?o$t(0I^x%#gS_bFVy|Ul!wEZKRzlJ+?TtM`wkxOk7{IbE2JH+Ff;1y1``Y_*HuY4j3i8Ug(+9>0|Y$inXm<t}m=KbaYD6Z({AN'
    'U6Inc_SylXO<(UnZ(*UAKdyLDtmo3`)k~wzk5ApC^>pT(+3!yc?`Cv(M#y9`DXZO=5wEhY&=0s1qfB$|=4+^49(SQn+dIKV@1C7D'
    '@wgLsVf<^y(?czvN2l2Zu6P=fm)G)0gQb2)1C3iG)O5UiRd2V$@GfOJTYTrqSx33jL4z}<th3k7IU^cpr<JCut@T>7JbCD-Yw4?v'
    'O5*j#esBtOM11!L8_)4JzJ4wH<i7T&D$gGBDRN6`d-myp{0Hru57k?&J)^e3G2NuESxT?6jTs+DsM9M84!IZXP76O{b*kjf+Zwy8'
    'R86qS%za1KhD>Gfph;&uKU9vLJ!JGH)gg9KS5~i`dNy#yOq2Lvmu{oFr!*8-UinycXnsuY+{bhGP#=1~;nOUdmQ<Qtn$yYH^hHLV'
    'k#NA~-OSj5?;p(4xRI@&Z(tX(A)a+Jsm`1@E}`w%<UZSvoo#t--lb=s?(B+2tztCw3seeM?`oIQ>BZ`K(z3m%iQeJ8U1GdjQWggj'
    'g*T`BFC2C}z0req8NpEl_Lw-;4)<KpBhPE`@eWzU!hU-%+x7a|d5_knJ?-v%%6PnJ#59NLR55>Xa{S?G2YpX`2rJqVJ8Fsl!Y;$x'
    'j|-`>-!;#SxHjl{;ggx_pQnZ&@6{wwD|*&kjZsmoW&34QYfz`m&ZQY1EBByUeNQy=IeE=y^uv4MU&pn&(|c+A9n*cIM--Y)qtd9c'
    '?M%oSE}CCn_#0iZZtwZJK}nl;9Xik5wmI%}^U2-&YK)z{G$1*6*Dj;wo=LVoXNQgqz3A8>!dI#cvz#pGr!F0~^Fx!5WOwIAyJDx_'
    'e0{^X=a;m^4u`zX`PD?U_Eo9%I{P)EYpJnUTJiHYexobC4jVXanrDZTdxxr-OpO`o^7Pj3osSulD`uOQY;{+oUwWRhH#~T=L;0ci'
    '&m_+&6>byuX%7jy@#M_weqE28x7yKq&V{oeNKJA5{zcb{*zvVbtzyPbJWS}HiyN=wa(F{Kr|j-es?<zpEbjK%BI5oPv#+Y*&P7=9'
    '<aGULhu8c2EFF0wWc<Z>rYR4_&;6Q*mZ!8CWHfHeXnVSM>n#^sHu5!=1|eAo7}IQe*4yUo=mwvf#U$LAd4A&^Gn;K+^LJ@p(RX_5'
    '<T=mu#OPg7XHWF?3#cH6hB_Z>X?$jMVRH5U@{2v6j}*+;m=R*_r~7D(y#Lg6wJ~i(xw>et4q=Y_CS8kRotEpH@dnka8y)-9{Fvd8'
    '65qz|Bfe}hzaHW4G1WEbo$KW-Rc5C@Cfj`)mA|gr`abW@Roy(6G{;}VZ}k_A!HccO-wMLaY9Be+vTh}<rnR0GGXAvRqW0a7Ts@P0'
    'GsWY<$12tNLpw6-#hFppjvBsToqDZLSR3zf<<%XRqIBc-S|z<>Z<TdCdB{Be^NL%CavEqX?>0z#LH~ydn#tA^((G$3HeHW9*zruQ'
    'd2-_-_dM5*9{x9Pg>=&F`tbFwuyulq?~F8I=krdgM=s~A$~fN5zgJq0|Cn0*^wh1BCiK^J*Xpo-N5nzRP6L8_?Av&8m}B6Kmmhle'
    'CZ|l(IJPgg<ML;N5%VxPe0nFRNgnQ*N16;b_UgL)`3pVy;m6Ke(`)<n`miW1sduksopO5Dp4Pa~^mMUSTKBw9^0RpjzV6Vy_@dy('
    '1csV;YC>mihx7e&d`|4{Tk$br<Qjkb#Cx}T-ySi{B-QwO>q_hF&c==JzY9t}CXd&idTtGNzvm?3(dPr?n2Y^e?j|>X8r#{l`ta$^'
    'yM~RqHDKT?cRKIhjzKfty@;I{JpZxanQ>=yXWInTu8lM4b2RR4)zosW#h#sa@N~<|=KDuaDgC^qP3I}2j+}_~8XeJ<TeRT)?hbAT'
    'M(^sLLd_g7Dc^r?tp3x^@s)SOCT+WS<6h5`TGMVPZJU0o;N@Ylb<_8B{F=U9)^uLCF@J`8%OOiQTQ-Xx+wjxTSfdjO<sNt4qjFp1'
    'YNfe$-s7E}M0#W|UY<E>=l&0IXUf}Np5(1Fa{U|b_MBj~N1d;(YBS@C;Vqwn=o=pF>=6dbjtX!3^-Q0;;pmBmV;`$@etu%9;q2Ga'
    'v_Wg;XT5HfJIY;c*o<7~xmHbA<gK|}S<wX<?Dgacv)%m#*LHnKvm}G51;<X9G>PqAZMvekCL^iK04!$NQY382un?6#2fD<)OS<a+'
    'yqovLz5B-)jlFd2ahJu`U(0;N6Jz?NoY_c~&8l3%wM@A*Pv`diEinyJ#(Q+x^dxtfioe7ALcgT!OInYgeBAC~vvP4r)r)PN<J=x;'
    'b~&|7Yok|(ibI<}PB~hbGsduHQvRhjaYkb{r*7@ib6le?#i>a%pQwy~9DinV+thJ-8<L;pu5VU-Wnt2cJ`dh^z|GGOdZ_+sQ1<zc'
    '9pcxXiOw&7U#smJryUVi;@^LJx=oTr-|FhtG2Zj_)8dYKzSgz04mTpLx1Yg$FX%Q8xpWe-nAW_FuxXKf(RIIf1t!t8M`tcD+yC`I'
    '?Y6HoyP1r%Yiu!R--aOu_TvJ|pS89g)iZnMywb&9A2zrhIDU|<K0kP^Mc$;R+s>WXe{J2#zBx^`b{zL!_NJl!v#wSfqE3rcRKCUG'
    'W@T&TM&%DG?mW44^;YQE;|Ak5WbqH4*c>M|c~l}6r+S8zX}IOaW*NO4XYt{oe!|qM&;Cg4$l@%#a8h}y<*@zQ8MoIPe{JYGYvs*_'
    'O%7)6JaM@oV=5l7HKE6%iQ$$bt`xOcwQ6(mE%Mm4VPCVew+Al2TfO0=>Vz_v*JIzvmcg3GLS5$g?8vgINP07L^UQa`f@=ZtE~8gx'
    'Z*wP(-?ofP@jmJsA3kuL<<{m+=Qvh)z8<*fv5URgRi8r^eHJ8H&M8nq)m$PU=5{{!XxM$3eQnskW7K7n#hEW!V&wsoEf@6~an@<c'
    'ImeMTyMr%hhn||VC?d#T`gF2v*{un2tGZhrTXyl_PSL{BsNd?#i-+6HI`j!mDo*`!-+W!d_)@Fjt}T1&>Rc~Avp7;MWM3J-;9UQE'
    'C4<9`HuKs$w)pzxeFwX?T35>Wp(EF99~Bt2W!dbsVlT~0ZbiK=tugKGxZLAH*FL>m)&)GgXw)!xpJ)5sdmGvpu2{cf-ZmjHe@u&B'
    'H?q1qo0Gzt`Ja++FAqIkJ*@N6w~yBEIS{^Kx}~1K#={rAx~_kp`LsvmhiV5u{})X!cFLl|4Z{2Om^Z8WrVq2IEiJn4UdP9W4>F%V'
    '+UMcRk=MKSY5IQYOOL7J)cQuZRlkUoc0JLi{KVXSIZ1cAR*iJ_<;=prJ~z=i*7o+z!}e+iUI%u4_&FzKa{xYnRL>*5XBwQ3OF;FO'
    '&nsPOZWlV^Om#71)y^PO4W+pur*^g9IOl77-f)1eV@ZtqrsTnHnTsC=T7?MB5+4>Nw%I21d4Hn1`vyKrPvfB0;7KFaH^12-q_x$;'
    'wW`j~<0>vv!qY+9CZY{Sj&$4Fq;0C^kw<67HSh0hRaCHZa>S62IhLVI<_(+p9(&sO{EUx_`Hx<~H%(?*EVmxw{qpM&<NjBYM>KO?'
    'VKAbXYvbVcRNJY#8^}Pr*6AkJA^Y?^S+ffxJ+}?8(b(j0FRjbO9-j<DiZc&+7+x}cXI(rX&mRdf;T!1PsZjU6w!v`I!>u`qT~B26'
    '-IutZIb{88cDI)e8uneaa70h!!xz_8l!boBCi=N*rQ228cHQv8#`3JJo;%~#1D%X+tn0mO_m3*O&t$&ra%4qiSVioTO*Z}B#5%ui'
    'vFmh9a`xOQ70*_;Zr7(>-}r|%&j*}KT-kb<&B3_jipE2->9I9Cd`})S{4A*VUa$J>-Q2lL_FXJL_0HzlyygD0JY)Lr`egEY()+bH'
    'Yd6RGw>_}$Wbmo=Ddui-Y(Dv}sqnD%@8PiFQOuL7`-jii-`|wd(xJuMJGV@{7Rt7LRFir&U3w|naYKCkEDiUknZ=8@L=HdT{K{o!'
    'pCE&NwlSM`FJF4BbHB80F48gvoj>zp=Pj4=w@(i#J$-5A>4UbnT4p32oUDI%@A6kGvX;+wG01ZG<dC1{em1_#y-`cGkp^m|^S0g?'
    '+AGI-9QS0f>%>VlI#aJSxL_Y?ZyQ#$Y%S7d$+(eQJK0uf_Vmh2pSyGD%<T3<W|aEx-P9!M#;{JekiKJDPP|uQetgHs316HwmXCew'
    '>p!Z+;@Gsn&qp)qvPX#1h4{s>CD+q0p4Z%N>#?X~;|05$jV7i?e@)L8D{c)!7HS+jciqHi<YuSS<<=L&+HdK;si}L}*`xD^CwQm('
    's3ZArj~ERJnT&ROY5AZ}o^wX<s`cwyAFMIA5er(}ynP1^FMpe?GWbJc%%I$%<SLE3W~TOUuPwD6ArN<%rF*iliTBzK-+rTC+Vw&0'
    'OR_aX&w4D*G5k_iH8)QG)ztxct+1(@!oHK;-t}%a)1^y#{Iyy#x4(<k5!F;Vc-Yq&b4Oz<Zt668eLONIso2(gLu9kV{T6?0qPus('
    'qo-qhZ(P{B5L><fM!SJM&uM4%@p7Qc+Mal6(dJpl$FF0Hje2JcUflsZ`Joa2WTQr^wRd#m_=ru%Zh!pH${#(gacqH4UeKOM?DCN7'
    'W-H9@Crv!EtlR#=;y3r4wR^Vf>y_E}j>BQE)q8QoeY?(^5;coUbGs$=vDe5q@`}3DPfgct!L)M2MN#eX-aXGX%-B9^V)?MoPW!Sy'
    'H(OV+VyOPPNdEr3hSbHa@9=TwOao(#kxzRU^t16{pJ(|*ST;JacQRpT_*U&w)A4xpIfH2~=C8J|&Fd4prg_Q@<nubCC%boMHO$yU'
    'X2c}oasBQzZ)c>x@YH6#-C}X|*PE04A7r%MIc})!DZB9<uHtDf)yF2B^R!(u)`u8c7G))^aX->b-*#Z$6Nf|hG@sxX&MxSB<cNpg'
    'Iiq!~r^{n5ZdH$m(vJ2!4<xerFKhLQrXN!GJ})1?b5POxg>7s*Uh1l<Ml<O%EC$^%*)`tp9ntOW$@dpDo-)zzW@=#ifuqKSs^6Kk'
    'XP4R19vkrmT`Gv)^L1B#_0oB6K2gK=is!?RNLk|e#f8^5?Jag4q-pV$ID{75(Hy70fBNe)bKExHB6Tlt&$kYXw;bSnJ5b%wkT^Gq'
    'v3@cAT%)-B$(0`tz95$BJGXmvy=Lf}OUHH1`=^msk@{J!&QFdyS9sYeQ{})N^<$4+ZA%XKkGvMHRdJx4w0YGuXs0%*!y0Lh?72&&'
    'N#{;kCh>#s=rmJvA91_dkPKbZ+q=zrj}Eo@3D>*D7BX{RE=oA>QnAagy1dJU+7fc+**W~{RkL<v<Xm}jaA<Nt>1)k)0p`IT8ppWI'
    'yLl?)rt`tU&mV1bHi+1}we48{Fj}QJ=Gd#=RjFM+Of}!=L~ib@e&q61l^2c;Pc%C)u4(>Z_p<z(8w=Og%&G0W_+=`208fiuwkL7u'
    '5zUg8NsZc0?5VCU=Uy0Gk=!&n;!}?+<TYw-0#kOvSO3--4`bU_GY`0p%DFvASNEjqCf)S(?&O1qo97NFH1a_AJm0aQqQR6BXD;Gd'
    'qOd`g&7A6ffuc;fX6m7Z)i)|<#(4J{UA4l^=G0R65t(N!qQ>Uke=v-~{M9>L>pCp0%`)}blLOGTo)N6h96z<acQ;OT>K~_19aOvX'
    '+G@iL^K1Jj%*pN6<W*|7EqZ<(MX#vh-2L~rYg6x%WsBE`!=$41TR*=zIYo6!Z1IUc`<GxPr$@}GX<tC&9!FDsW1Q{=7p0dZ3wb$N'
    'EiO1YY^~j&-2`v6vb!7YX!)|@a)&8bUG}2QKlzlrb`4*X&=~jYxgnwD$=V5z=s~%CcXa0?+>J+l$Q*bz=Y;F$vT)tFE7f0nW(9Vt'
    'SWe45oo+rD9_n-2w#ME<FYHZ}(MW5f(}u$y@9tLI@ryt0yRpZ}Tix8<W5=~`w$DFlL@TSylgvzQ?lAWJ7?0>@jLKe4dwi>vyU38!'
    '8y8wf*d*qzH!|qFYa`Y5&=l)iu1w=-yCne~Q|6YfDevC4aBRg3hoPlc?xrl``qy?1f4zjUFfth*-{it+yDqtE`>So#mfcj(lh!qL'
    'J3KMGa&A;1L#|)^;i6PA*>XoJ*L*?oDLa#l%2TV2AAHFe9NhO}V}>t4#_7OEr&N#MttpkfYS^Jg=V#(;|1mnHV_z;Bz=V%F@@k>u'
    '*DoVH7KA4@xY}}8*@-Sy5hNFLz3GGorNfx`t(M;RTP^I>iLb>vpX?YCjMEky26oSG)wuRr;x&T#uwdkuY@Z2Q#FywM*8^^)AD>x1'
    'YW|j|*1g)UxyNtc#OepPT^gJ@{?X}E!_0CA3R{+VkJw#vLvz=vLn@*417mjD(&3sPHB;;?A00)Cj3?QxJ8O3Q_QIX*x>yj0X7?S!'
    'g8TTgOubaUV^e+pYeKsNDbIXg#Jx6tPkR_oUT@cv&CVXJ&K>LW-0R?IPP^6MixX(4vqe4BZ8{uYV`cy7rk%rvlqk~3Wl_v$)129w'
    'n%NWHW;BXl(%9bN{?x(RbFSJser?g_b5Zdn$Fz^VS5H5d&~5wj!p#Ob_ZwO*Ul!Esvz=3-miD<zoj2xZe+iF#tC1LzKIh)VL9gWP'
    'txA*owd`p(+G|T{OL2jeFkc=Lk!72HUboV}r@{QYo1PmTvh`YN=i9}os`!QWvVNnM8TQ#`HZ}Q;VPs^toW&~6{bIV0in5zBFu}dg'
    'v0gE{YNI~7k>>Bu-rig+S@$d&Ira7XVG9@A&FpnCWyA3YEi)3CNySs|Fqe09XO>j!PE~D_R-qYWYImDn>bia3nU3dIA~x=WrnQZW'
    'wmR+h^{~fA+c_sst7h4i`-R44I9P8r4u4ted3!)aPVR%J3+G<jaXTpNn2%UxS99!Y*~PVIGfWQ}yPsAm>3&qK9@4iq*K~_va`ceJ'
    '(e`QuMtIfmhP8aa+lLbtZB&_>@j6AnqjwjJdzeAw#U}PWbmxrkRZ=lO^zA6N?4)j~VXXc!{J3Br+H&>mM(uF>(XAVN-p158K791`'
    '>F&LAcel71Fd^ZlS~G*psPs0qd+bHGFP`I6duTY!yfQ$wyqVVf_1aR`F3z9li7sA=y?Fca*O%U?+FEq_Mz3Y9v)5d9Q9C=MU|N5R'
    'C2vxymj<1Pv5)lbF#r0hYu%bU&5Cj&y{^ptd}7DCsTmWx?J7EWVQQlNG|hpND~eXR?e5xaq+al<Mb5fQdLL>Lsowv6)-u&?o$Mcv'
    '-kR8^;dCcz(JddlOTMY<eV4V$c$Kj`XVs_`TCo@GpMOm1XglUvj9={ua^0LoH}97j<epk#vv;2O@^zCvy}GqAIkG!%y!Pp+*CQiN'
    'ytnH+#4M-u=?#t9A5_p`K{=Y;W;qV`+3l$M*qp0A6uB#=GV}-?yS?w{Q7v+vZ71|Vx~+ZX*t#scprd*_vk!R*`%`a*w#u|wGJTc)'
    '{AePopk=pwx1Npe>^wzv-P_~;0SQ3%ze)KqV3SXAkI)4{Ant$BIWD+T5j{<Q@9;3Pbn3p(u?h-2PGZI%3^(>TH3Y~NY-mn4Dm{GR'
    'yd|s2zkCA(?%K8GBk~2q+F4@_P1?R}ZcRs#=sl%X_{rvlw#H;w><~1npr0svSLg`GMGL}3xydW1&ON1V>yDJPD2F-hijKse;bG<!'
    'JHmqv+0O>#_ZY%|cRlT{>JkjhFQNV3l1J32?#j5K*O1-XY)b6MhPyL6i#{+1OfI8ZHGJfKNpMTo)?PZ3%qLca0Fi{6ZpJb;p*}(+'
    '6JK8$x$g+|MXG&pfLEgf<uoYba=WcC%G6695I$r;v}rezbyo;6BS;0oDq4tC7hAa&%cbW3p9a$m5<Y?7V+Mpzc}=N<vDnCjT`F{S'
    'S5+KuH+jTkzKS!Hkv@%-mUCTA;a(i-EQW_>c*gQ;d~r|7DneGC6HBgyHa?J&$tkM%&E$#)^A*pRQA<ITtw1!O;JW{0F2=bls6MEb'
    '@__k0E!Y|4=A;t1OF5MakxST~B=Pe6fKDerhd!zuc<E7_7Iu}H5;G~B!8nc2HCWrV)!0MsN<3L2-#*tfBInVSUEThKh)*Di9z9a0'
    'uIE}GFh+-!?C5!fb3X%O`Mre+jKZQ|@7_c6yYT1#kE^F4qTuPGTtSxJD?co;9aM<6yOTc+<PFC?;{a0Faxts8qFQ^#F|5P}5kE=*'
    '!`-Wp*9t0_wctk+_oLWFT^yLCAAgQioDw0oJU>jeYZiZzpxCb}DjU|ekx4J+-Ro1-6hpTu>YBMrT|ZUOhbkYYL0rkiB=l;`wUoj_'
    '2*n?vWU%R#ScZEde?M*+;hXI9YUSP^LU0@#71|@oe)g0Xx_DzPs+19#20ywmnHzX}2u4m9lSMcUu?DI{H2p<g&M`7RZC6_O!av7h'
    '1}KcWo=*;U+NPc>PKa;s7)V1k5#x-vJ-9tZ3_sVue4Rebq)Wy=H~J7%_}F!Jkhrx6{_Oy2rh&oZ@IU7~nC?t~9fC<gK~RdWJM=*D'
    'BGi+ke*$}^5?kISA3yC&)A<O&or6`ol!|j+u6xp`ITT7Zy-M*KXh})}RzM{j4H)<f?t{(ypKUiv4fbNeN<Q1}vtJ)^U1H(0%|LX@'
    'AH%(??d0MIEq3zn<)T;1a07+p?beDXgBPpsc0jo5#MStQtunDWFTew?OL*=&QgeMH-0#0x-Zc0V=0M2tGj)w$5rg1-dqgL=I_T0k'
    'I!Qzyx0KnHyF0}}gFw<9EMe9dV&lS>Y0@GBL+tmzv_HAIX$6<vcAp2z20-w@?!88!SY4JklAWpBlDQToFr?3eNI)w?ogNgHfk5=W'
    'N%Qq)ybMfOdqL!8XXG2UyT(%a0*;PQqR-m)GC=~+nLLBuPT$*r6L4uxHUV_Gt(`U_MzlyQQ{=M_vOxmlml3^w4Jn69$l+F-B}~+d'
    '_I8<)bs#AAp$u>Qx<Nyp%UJnTl?F9kVPX^x5~mC)htvi1y`5bQEh~QdA3_TOK^h=-!L~QdeL@zQ@JJyt7`gWvCD);ugxQMIltL9s'
    'mp>n|v4uv1B~%?0Mnq!cw}<Ryj%Tw?^usa49zsDH@%N8KR~o4nB~np>f&-y6Gv<3np73S^XaU4=tU^vO&+6JT_g9P2O?QGjN)YY9'
    'v$*kIF}kbt#lh8uJVJYJvX(v+U-HId|GC`$Gom!$ik&MnFDj!VJRBcq!a|wOr)V%=FvN!QJw})i49@ZK9cn)?QLuLZ8gxC-2SX!{'
    'w9S3vd$mNb&SQ0v0@!qA19n-o21H}=Ju`!Yi$g1;75Ou}L-|T&Hh6A>MzVR07+x?@7&g|8Mmv#M+CwxDUX9$qo@L$)9G{LwDG{RS'
    'OBO<^b1;mu2Th#2c0)o^bqFGZ26?!A6xJ0An|USx$=39Pn*ao$XcO<R_d`g%To%{n*E>+0r0w-8R66CP$y0m8j$-$4VfkG9YeP?Y'
    'AzYKXe~85tX_Udj8@h2<!ipYpap3zTy=84CG(&8y!u%bcwRPscjatRW&iodr3mXb)abM6IG`u64kVAmS{V}?;0FoHVCT;nAfKZw+'
    '?|<43=C{KvxDl4BHA9wn4DG|r*&_HsbAv_C@BC-JR_-36{axUWNw8dZ^h3Be#BB>(a%c$Jkam!wOju=gRJ22Ng1^Ab<WKIRpG0H<'
    ';9v6s0aSfFvdp?|`<?NF6FzB!x8mrG3eIa%u0*4CQvX4-@Y}o-#Nt0hl@BQk&PF&_6n)SoY)Z5C`b4+XK1FSooDw0FdP~r|-!p}L'
    'M=^0tA@LTBKU_r5=|tO3F<%dj7Sp{RcD4PO%yTT99L^B9HF9IZ2RuEaGeqZUVu^%320;H;4E-3&n=I_F5-k)Ie9XXZda&_&+eHLP'
    '4lD#a$Kls5`U~Y6HkvJ(Lt{Y@ba8K#9-4m}utg@nDj%T>GivabO(P<CJ>yB)1G{(>)=;^uY%M)gcSVGlCz*4&#e^C9a{Jb%jq*&#'
    '<`jddRLs!efrHw^-bN1SKYP5JNS5aY5mdP*D2Q*vifN_KS<gH=_^TqXrA9G#lGVgyWio<YL+VZ4N+L=PN`r_;c3b*V_nf;&u0}qx'
    'e~~O2QtbWQT^qbO)C$eMe8kAZBW2i;T{lWVM@CXbA`bpdX2gNo!P|5~d0P!u7{aO0fl*r|ZI--dnnu82L7I#wmht0N{YBqJgu$z{'
    '04SHl^_Ir2aPBiqr$;}jR1DVtl+fr^7`3)@pnstL*-c705+eTB`$KFym`7Yye4Q(zWvS7iF+I*uo$CLSuKtI<nI<I|nGAnl2}gk*'
    'Bsn_m4hpDlm{bPd%Z(W#YWGH3?V8tF+60sT6G!0OxxjTLzwceJ3nxo4TxE8MGrP={4dg|t7pIS61xMj3eqb-u(~y8d%U@od=jy@z'
    'O7l}!;@wJxIXd+;bx0kQqHdQul=Kk2e2Nb;3edW{erD>S8ydCd-op1|)JQww!6(JY>K9teFUJlsp=)OlDsK!)*lm@9j?9{L=}0_@'
    'G>8y;FVP(8tdzCMl3y~LG;tynhQaPv1uVKK&PZ&$ISi|z>MAba<6ivCCa5Q+)Z$~PSx)f>+I~o{Hb}|h%+WRL7y4bAgX!tH)0NR?'
    '1l4jP`B+i1#HT|(^hpSSpbom}1PMGBZUeR8TkP~lxhE}DL31KC!cLGKV@Vo~K`x#_z#gvY9kz4q2$z2An=AM{G=c9Yf1V*Y0ZA(d'
    '`s}(m&R0TdgezFwEYA^@7kDjh5a*iI$?;0^nn^PeychF;<ghi8ZqFFI@^qdnUC)F@X=w|k<A0F}07*fol?<kZ4}WfwFGF3lbFwTi'
    'BYChE6@sBL{_hm7XGudV#+o=={-ZCzrkRj(Y^3YOa4n~h8Pb+9ECYh<mq|#-z(v%6Hs;+PD|sX;0IN*MW?UQtDe8Z+C1$J7p-HEH'
    'J;>>ekRtYv61oElfeEjmotSzb!IQ$il37F@N=e8k$0vWTe_k%)C|H(1i9#m)V$O8iv*BQ~2o~eQ8A;HOMY{%_*^j6}omPRi0+|?l'
    'NjgnA@<Q?Q=dP`4mr5hrV2PuBq@mRdH#XThmm&AfzL$&A_Aqh9NUP@JLP|52WuYI+EXm#KP==cL1yjNc1|+ichjb<qi7I43&PqDq'
    '5v;T!<PI6ZKJ(pmlJ-5Tr(C3WeEjhQ<R`KTx=K&mkOr-IsJiXc7;&+|kk8z8g+<XYQQmA--U}Wp+Ddd%h=nw2=v|^^OwN@$?r-He'
    'US|>;GE<IBb0a`_>q>o(g4KvgBDjbJZ=kPVNay=%G?U4{5wTR-ks*VwmP&u+VWzPLFE(iMZ;$J3rfc83D4!`>TF1WG52+WIo=TG<'
    'RpEyIhjm(?a~m%@9Cz1;fUG}&|Ls{m>6K_%u1c_PZa2eR2YJ{tqZgbY&BzoGLShTJQaiy4XqizHcS^d^E6V*&f-Mis7=o{D;-2DT'
    'z2?Z?^^}4uoL1^=VM@zvZMblss5H>4_u#vqd+=~ctm}@l0^0raNJj>A)k@OT0fI|lJ-u{mf3ed^r{R$btaSQ!7ix&6*0}W&2}>Iz'
    'p9Bb)#}j5aL*tvJqaE2l2Z3$VD>(pDA}SA9=1XhbBVEG%8lDhWueTr_Vf)Yc6T26tt$(>gM^(U{lS_vWr2Cbi{obss7Lg&EYuOAR'
    'U#jJkHJ0D-6}HB|=u7hQR=DprXvJL3>)i&5otCR$pcuf5wh^W$qn0c~OiTwme+CuSVC<OtfZ4sGPm5~+S@fxT#8g-#5PyVT^-MBK'
    'FR5Trc;1GT<3>+f#0pMm0NfyI5H}p_Cq8`nFibVmMhhecbtJKn=^hYOPoZf~0PTw~Ur>pXbiVRo>`X}>0IaWo235wQjfgS;zQxHA'
    '%(z1O8J`Q>SdjF?icDHYIvnk#TA&g4dD`fJ6_y7uyalZ!=O!3<kLq2*Jxv$gSd3cLEeoHNKb_5Cckdp>^Y8VgN2}oDhw7b*W=&ac'
    'AR(li)x-%fHtOKd`|*epn1V+y984~wfuS(=yiIO^1I9{Y;&Ik+#w4z5g?L7U=V#U>?qM@}VoAW*WKDFL{ZeL8*AH|1e7pIFY5&C?'
    'ia>4~$PbpSUBJ=}_)VZwD(5jlg<)O)h_ooArK1rQ8|y-IWq6W#p$hmsolUA7<I*cK9mGYZ5IqR;Q+@8$pcy5$&699J0pbfrh)t}O'
    'Nb0OsVbf}pIb{`6V=>LpEpfAT<yK(zFX{Vn@lCa9_q@MV3aK%^bKch7>$0k08RSdL6TaIk3-u9P|4qfIT!3dZo9@&hdawTAdhVJG'
    '?-0o|Yj~21EM<mDoK52CJrUF9F!xhv=(Zsaf@(xj&Pzpeat3^({Itir@J=V<(*F7oG0n33fDMb&5+8hc@qifcC>r8Pi8>F3c1|hZ'
    'mvf@MoX+t#zf$He_jO%kmke0X$T~ILpH~1w0!~O|Cp{+td1P+9w5Sn|YK%uWgtcl~fkv@Oq)R!H*-l-=qoKMzO>@7x;R$Gf%8dGj'
    'lpeR;vq9b=KJy$+xlV3g%L@73x?MtXn-N3~92ESH)CeSBj{sip0<;ftj81b-clhlUk9PXt@)do@;tf^V*2A~J?*LPA(q?@8;!dZy'
    'S|)ZS^vj(Iq&zgR&!*pJCH|#-wCGtj+0ZXhW=_0d@N*hVqvGg;L~Tv81EBZf;&t?*_ICtDd^EMQlTQnr!6PCjIVBbCrOfz%qyj<A'
    'TKtV|@5`)3AYh5sV^38%@_OMIH`X%Q@JDmAjBE1j7>@&WNstkZic%{Y1y6IWCj}CopxQ1ioBdV9{Y?&#vaS(4?)KJDi;0wjDo^=h'
    '5n~XWX?^Mj{zgc%CM=FVK;ThXd+Y8^3_(@+UQh>ahs!Zc!3B8;oN2zUH|VjtO-*9+70+jfEdg5KKTr&*LIWl^F$iXSeogYq+hfJ_'
    'mvLe?;9Y+JsnoyZQBVy9j_>hZRl(Kvya_m!8?46zKHMCi@rx@-%B}BA_E01!pWk0H$@PROea_bIlALwYFAe)=f^Dq0VinSP7*Hj!'
    '98}r4yH%8?^47`T(0ANb3@wM+I?u|q@7F^yYfvekE%&U7!Iz}m1FY#D6K^S&&o_e4QWIN7vExs}y-+hw#e%(%;v@aBF)!MUeo!nK'
    'aDaNf6(Ko~d2k(^M^J=P2Y<v_M+#T!NQQtV?WlkiF|jrr%Z+TnUKdD@uu%hQ#S>LZBh`Z7m%y@bMZ!Kpt2flYTxak)XLRsTr%`4Q'
    'Oi?`z1v++hlvE5Xk$~~QtGSteB=){A_f{Han^D0R!LPnbsTYk$I)^R)t;{(g4r^^3nAf{w4z8jzdQuPhD&EY0Ow$~D1)W}|q?q5m'
    '>B7rZG5eS2-s6{`Qc`ekM!*6$T<JxK##}`#jqV4$H-T8680%Vq4~0~|zfy7*6pD6Lh`Bt1J@+Kpr1PFun9?1m?#YI<Cw;($s8VzV'
    'N6V%iskM2SCm4;g{~d!Yt0y=P>6mhS=Tnh7f>MN>o!_u^Cc0835Z0$)B)shF6|up&KDElcbIq0HpHh?cbhXPZ_N?Xkm7g~z!MH9&'
    'gM}+slbih%^mTx6)>D$2e#gPQ8h5^;OKoUV%0A8eAGX!5&yb>Hs-$yk{Zpi`SnrI#6(-=ko4O}ooX=}pa3D<t&Y<{ndnMV2s8hW+'
    '#8-&;;X;d6=2G0HyF9Gx*v?=p033z%Hk|kcz*E1-IOpexx<RY>#C+g@vr@bzS;gUAC1dz-9P3v`A5<M?EB1`j9<EtiqQVYyGR7ca'
    'FO(GLfbQVioyYzy5>zznt!nC(O2}uYD_hrJy>Y#@w8E0ddf5x@gW0B?gH&+29>$IQ=OxTk`poB~zz)74t{yf|?FknSgc1CDZd9+v'
    'ZAQ5`Vn6mL+J$mO)A*dEghze~3x;0!^iW|BBvj^W6nx_A^(F@%bBhnAfPQOe7B7ieHAv(Y9J&Al`&Cm7ZbvM<rUOyB1F0t#_iS_L'
    'vJ-EutWI)d{?*!@$yHxXOlkTN@BSm&rhX^+ZCMy9Gl{h>3tB$|DajVW8dZYE?&%IKZX{;QhKq@%Tyepj;Ry$6&@?MHmNaTDA63u5'
    'a1DY=kgc}1M|tUil%+|)xa6UPqN?U6aJY!%kXCPzfklJ*06?(U?inNLrt%vm4gHH>k7aCg1#Z_@KUQ-!YPeUA7{2*TC*^X^F6LsN'
    '?V-KTcgszc+#RP|V^(}LfO7~N)9OYflKv)Wm<4=4iKcls5JrcGM9CHvfmV>ehM~_NMgWv{GC88Zz2sc001Ys6U9hCP8<NdSwN{ZC'
    '*d{g?oGOLgZlNAK!fX6r1IEdD!zyg=C`{Rb1y-nh{#P<Lx4rf(*m*<F=w#3G5Cx10T%a(A$lG@f7*^GDhYdqJ>@9>ZggJK>uU;u*'
    'j@(~^fp0RNzc(jruvZEPJdq6k3j-3jw{z9Us#q?1D^@ajfzHoj$`@_02v?g4DXzs9ID=WekRj<LL7068sBN;o5ZgvxLmnO)R#&LP'
    'Pl`+We=T;^tli*tVE-`}xo5tR3cbs1XYbyc09UhXKE?Txt3b8X-~Mk$8b4m@#!?vv{G1{W?-!94vsbwm@Y)E)tp8TzUgGN&_PS)&'
    'uZDNvO+^Tzqh13PxmVVqMwnY4a+Nn^+_ka77Ga<|`|p~N)g%q(PJPay^H>2JrZH&SQ|tJYjChU^|Nk8X1-F8*$bW32CxIj?xmYIk'
    '*|Z2CsbuL4LIgJ4o*e)Ox0>#c43}sfVwPpB0$5!0ul$yy;!Nyrqy=1Ju)CSyQ^jSE;5`3ugsoiGkXU1Xn?<vD(92W|&Jv$qqQnsf'
    'mQwmjUgMV67Qn#_Ls+4{Lib_J7sg9D5}J1{foAOp4_K$Kx6=IsM#-#;KUl7ok?~Rp0FHH!r>G&s`Ot7#OQ9`_s~1nUp#RCp$XKte'
    'hua2ia+_Dmb1`YK7g?&!gZQ)_%Zp5_-*_pIV_31LD@@>YrWjs)T9rX`BM$=E0hob4JXTe3y6WfDGFZJ9*myoXCisQfc8#(BtjJHl'
    '1c~#fw9zNw^D%3yGg$_FQ7Z8jz*&6?*A3B_yKg~8KZ91EZq9uH7xO00b6FV+u0($rV2I#KQ(&_gwe5RnMc&$_w~x30Up!O@L0KOr'
    'dIsyEcG6&gES<7HjYdO=o6UE$0{9#l<6pn>Hd%!_Ek&N}aVq(=Y^ipKqCP|=D#LW%Ij%{cz$bh5&RK|>ZKnVPJQ)?S(NG}vNT@b#'
    'Qr+NcN;ZP&#4QBi_F1GDY#|r3rg3zg4(4nakRZ<1BS#z7O}UXD6#I6OY+0uj)8_Js*90Pn=cSd&5Hx5sitpoxw*{<D6jt@sn_002'
    '(cHClm9$UKWXP$2g{qEFJ+(n1JA#6oygtPOU|IIz6n_kEOpIhU@2<NzXFdxSTSWXddXW6HG;&u;W?BybCOi6L0xa^i8m$UjaW+KH'
    '(KfA!AN=ugpku0&lv*k_C(#4&ki?9$Uhmp=UaGF|s8-96w?#C?o_>sf4O*oSPJ;o_e)R2FuOcZ?`aS92ZhWG0nx1;dR>m<nZ(5}$'
    'ZKV_8V8OtF8Nl!r?4opoGJVtx+HArckxFCBIa;hFTf9ECg+njH6)8nEXA`QbHTaW>V<Z*Z2sldeURuII*m-dQtm0<s*3t&2?{qI9'
    'z>CjIxHP23YU7&1Yg<n<SCp4J$V4<_pF^#Z#BWjBYg?^$+Mwg~tE!UHDO+d2C%(|^Y>Vw$xX)p1$%iBYYmdkgU=l*q!O{8m16!Ut'
    '5c#bIQAhCbNud|L@1HD+PWIvic?obOPtM*Zj$6F*oCWK3uO#5&FmhLvJh+5<KNtO7F@<xPv@GjadRxFnmagS8v`K$yW&+8xNd8!O'
    'CN(%NH=P+MJQP_J!&~WPriHF!p4^3q!VD}Gwoh!pIfi_RcJc$weHPqRU|eHBNSo3(I?p;rWSa3@46c9km?Rv`S(!B&<_u+8p<IXY'
    'HIa-=_ZyND4)Ib$$7Wu&(e&&$N;=rRasnl@-CVdG1`J?gQ~%xyeBm^&`|pblmix_|IN&uCA%AN+j9mPC@DrYxhVaKpcv*UkvQu0n'
    'PZiqM;O^MEXJ7no)?FUjlOc58f$L+pJ(wfE2&Z!eeGiG{rYNS{R<*7irCmq2AVgCc=ABGS)b#I8nc=`gU=y2R=6@fD=T)$y?p=2G'
    '8O=QU7m$pDiMyI^szni#I|~aBd<C7}DUh6OVqKTT(bOUjjl=CCGA7M$j7SKB9504=8A)h-4>g(_QC+-Sw&U@{dVuJ?fGt9lAFtL{'
    'oIN5*aQDJ6+BI+Rxn0LAAt&O?c_nEp!$iVjh}D@N2jt!SVrvFX4OSLx8C}-PVkLYRyI}M!2&xxig|$u^oHx{Ot|~$99xV}+5MCw-'
    '?+%mzU!RCUKlPnHt4i74s<#v|r!$WwYN6}W!Con{+x)H#Dl<B0?U4enT-AOcs*MKe9ueAY51ZvrD_%JWa^f<7_A|y-fFLfzN-Nv('
    'h<~LE18$l9F*#FhCSH}Mv=zw`V$K?@Q+)aL#K3HSY(b8*z)b)P_NfXYiC(@7Mdfj6iQJBJ7uxT5AdBc0O<Dlsy=H0mKw_ARI9}0n'
    '%t$jD0lN)*XX;?-TApz>8?n^Nsj~*5_O21+)L##3^~A)n^Ty#HBu5>NxSlNc8Fi*QeTZCSp(XI&+g~>kfa8$4kc$Vf0?I%gXLHUu'
    '3F;wVrkB`k@IaNR247QGtUX=mEr2*H%S2mBbeM<(fAX{p8W+%1G{(0`C0~5|3p<i2eEu*_n2N70Ap0A)ihb|~#Bh$rf2COyqF;><'
    'tDT_Ti+<I2Qnc(}cV=0CjH#5hirpQyy#Mc?SYM533&`9;%b7qz78cY$cQ-5F_L6u>RrrC4X=78h9ABeq)8+Q+!(=BeJ;vfRY9Sp&'
    'pHS3Sr?Z_3e3VZIwqL@VG!H)8I{^0=$Sz3=F7CNd?>I@q0ej$?xefE(x?mMi$|~LS$V?gOyTY;qe?Ec%3$|#L*Q=wSeldtUf?ypv'
    'cwFX;6b>c=0^7@KWw^G*f~`q<6ATcLR!S6skYHU*E3KQPDE)2-6fW!C29Yvw(l+SJP)0dvY(9vJ;$Ul%2Lb!t^my_EA6U715q~9S'
    '{g`*u$OAP4{{cpv`(U8PaI1%+CSr*Ma0&v!vACprGx?lZ`e2uXSQaQk&S1o{#^Ye*uylrp88e8=JLuFkgU=8a?$}es%5Ma*!C?pZ'
    'Qjh;Nt?Agg#}fTNHM5#SW{gdpLhDJ4DG+d5)nN%c)bMm3UdIS{oQc9&K+oEIx4<F$p^%eQ7cvE-7GWN}U@5Ib7OyjyK6yu{)A(?-'
    'p&n-i>#jhHH{ZAWd|^+XW}j4L616lY@dfbbvPKt{WQ2*lGvVWhNah~7Hesg8>oA+HrFt&)=l!J8M=>!~E<-LK76I^>F0+h`o?-T-'
    '!DklHU&mm^_KyT){~}jZMNcW8ES||aYA8-%0%BzQfIz3!+@tTxVQdK;{q0iC-awYV;>nGiRF%bj*kWg%dkhdq!70Hc!XGE%ctZ0|'
    'mzI5;rLS|=tn!ev0AhR8w3^OA)`ou-NGpZGnS-Y69A22LEY`+Dd&0_m^J0y?7u}pt;Wi~LnjpRoi3U`TOsam7A587z6jx~@A7Yi)'
    'yk4-1QHsoiN)$J%;d2wN>@`FzwC5*ZAQ8?h<YL0v!2BM>#(otX5%2UIpakzY;d#%LcET_~Zf)=F?_%6y_>WIhGx!{yF{nw&Gq5Vt'
    'IP+4*94CzGSu9?|ZesWoF&K>RMTbRcPmmslces^C#k@vo%WGZ5A7>8$RAUsps;{BkI&!7M>I&pjmfY{2T~DmC#7n5zsBBx32V+Uf'
    'F?qGG*(qhHh6{X9hgq7(mn?ZxO)h{v5Ca74q+@cI(j1e>Io%Oik)4hcl!C;m^R4tb?F&e;qqLxwd}Eud_?C4_s##(8ca0nmw-iQ='
    'x&c<%*d9^A-1TZqP-C8OQDpF}3R7-ziAWVHF|tZuhzB2Jv(qHn#U2lEt7Fd(a$R(W12?zV!|*Gj8*}sw*v0=Bf#RURGNTm__+!-Q'
    'gs$t~?OSOAWHTf=Yh-vzT3V*n`hiaY_Ti5P9ApQ9J%+aPkn+#zZf}fefkW8P30x10<V-D`9lPL8&}0iH=R-31Y&HNfu+ZsWw|c!p'
    '5H?*WVg${JchVN<SY#LAH~R1bY^HwU$0msxAT_0<24C$|YYGf|{0eo9sAS=aouwIjO{ID$=&L(BpBPaQr*TPd2U*=Kj5(0MN@Wvt'
    'Z_*Fh`LEgBtYRb2Q^A0mbkp$HqIT4EI#AtPd1Z5&{LQb;GRnFI0DaWlG-l3hG(@`)1=N!yS!rjEm1V<->7I@MoHHJ-2_(4gO-8O?'
    'K?vzRFt)`Ys!`$1)n-{}!?A1j%H4@ccZkC?3{GyyKD}lb5YblANPYMvhGvE;z2!MDBPZWIo*P*&DY^Re2bBD~MbF@!IogbCk7k+6'
    'fk`&>KVG{0$~*-{;q8lUr4OX*6?UobitbHI)n`z&cQDsMxjp_ax+UV^LUs#6>~B}hWeGyGG;i8c9%o$~1IX@g0||{_=I;y2wIpM#'
    'Atl3A#G1j4yNtLUy=Qj|rxu-0@H=keD%~HAv5K_dMKMpp7(8(DgV=Ro_h-NBK>W9eKxQ<PtDD^JGviclfRmwsRyo+-l-x7z9B1C5'
    'p7TUO_COq?ZJSmvFEQqe+obMh&&BHT(1Pe3A7}BldW%ZFL-DJ^<n8?LZO9tmHW=`H**E=_l5_ZmQD^d-LnL9W#3q7Wv{vjet<Gg;'
    '&Aeb9{l#>K+Dv9r6=)JyOraZHApO6*m0tJ(=FRP)DL(M2*0RUy=m_GXl4unh+b$E%3`-?A9NMvw{SEUOP^jdwp#3@+-0}+;C1@q6'
    ';z@Dyf$^zwiSsohurJIOcN3})MN+<3NL8`|7HCk-P=Mf3yr>)CFgCPVNKII+6c3+JP5~@5WP!dTjA-tLr_3J2KQLo9m-%t5EMD5|'
    '_;8v&YhM1@ZdUwLFli^yoqj7!*WDl=Ar_nm5g+t2Uw21_g7w1|^-+`#LTM;$PvPHNxOr@VHz#JTe8SeatI>u}ii{rj6wccLYH296'
    'Iq&Et>u$)AOIH~v*=*y7CE?nlR6<GXcZBz?>S<#^EwPh6quwPSAdQ0DmXSA5=(mCjG$I)OcU-@2foW_SBN>49oEM3%97=5x+}$?M'
    'JusfvEv#^RGXl67)oE|tuQ?<7tHnY(s}GC)H;Wa_G;EcTNARI*0#(q43u&7*7D$qpnNkqua46H-<Q_+OKgB~L`xko(B0#~{d1<^g'
    '3P@{9vWGf#C`Z8n5$N|H)%RxqDRaogER@7u<!T}k;36u#GBZ${wu^jY`)_dCnj%mX3^-BT3g&aE3~F7lwRM>}@~_M30Yqv?UZQ16'
    'Ax{Zou#0xd85vC75Nckk|2W+BX%sYevY}GFvXbvs;wZgz0rrUK)gih*@oJsTPp(npnd=(*+=R+L5@Quk+Y+aY??RMfhF7!JplZ*C'
    'u1P_N4b?Y04?dMFY^rLS>kGQ!<agc;ndSIoCTjs`7GI#9yR0`hMcEvGeo=w?;y}l|hTNcf6h>8Da%)~&)i~-~^<1$o`7Pla|Gegq'
    'Oc55vhY_H&KHEz6nrnDb04+wSb^e+8Es6;!fvDHN1*6!ygh(II4)vS6cWdCA{6hJf)q}Di-rM#a5AE0t+c4U1;n%G0bDtlSuWRK8'
    'uccO_TX@#e>ajPz&mc`Z>906m11TJ<AyTDsplj%)^Rgbz?+)7{uC#6F%MTGqVucEO-dsZZuK-_Iplmm{^I@509={Nn=0A1gm7ehL'
    'Mbi1AmVH7$kAs&cnrx}spRjnsH6(3B;snf&tRs4V%pD&+tI=~&T6JvsCv7c{IZ4Pzs9k4Y_57abic>@rnG(#Xm9gXgsP_J$3T;MR'
    'c3haNNr0|g|4V}l5aMk}5pyxs)|lCb>)bTt*KJ_k|0b0NXJ<$tLAB#xq|=8YBon2@<2M9VBl~S?pKXqn!3$yiig?`D-lPwwN<cv{'
    've(yP`ClS7%xJXVCvBD40Z|1<S{|75KGKb0Ctsa^f=%Gy{Hl3dY&EP1{B7d``IRc-n-5NIcFcY$XRVn4+k$0KFp=mNn&}Sv?rsZ('
    'vy0e|8N&$XKJJzhT4JCvA}$PG`vs4BfGox4DQ;hDcDBrOKT{YuQ*ei^;qx;6KOfw<JIK08P^KuZt!{n$(Ay+=W#Q8ez7>@dPYMOO'
    'ufe0k@?rq@bzuL)`EH->d;@9PWzBWXLj3wT^Eq~@pVxmBXtVsa90npL(QdVsCgO3pmgwmN|0#8|7&{*j`D$P+tt4s$hUIb+-)`5y'
    'k_g>8&w)L&(!)vtDorDruk~n|&jX*HL2_JqaBkUR;8^N|P9h1O=EUDI1cK+G49*?=?eABYmrxcv3vTWoeI}tL+IB}*Uc-0$0Q8u('
    '<Ga}{M>x=bwFxRTv2ObgeffXzvK&4aErv}{GGa(RGw@L?BDEnbgsVRL8gBrEfYc4dXn?5Qp_LYmP<W3?lxCSP_ukHs8w-TiaBoWS'
    'J>2cbE&yVQ2I&T|gfPcIJ7&4nbTc`}oUGvp;BRea&SDi0H$nu(MoFi?eV7Zs&}tBkCcS$C^P;{j+HZ{;40-apGpWzy`~QJx9PMu3'
    'cqzL{Az~jqdH?D-RBxPKnhctQok8#*WmJU{%L*{52Mm;=Q*Pp28?qE4J#Vkq5Gln<7=Tuwt8{!owEgFAa#sdn)cbD*Vb-2F_;1mP'
    '6KL1Yva@3CVuUsKhlEdpYOJ0pEAA<XxnKvJNpI9(^m4&Vsl6ET(Eph`3c*1g3}?~QPOEB8kQpJndvD{zTipb3)H%&OY3$}?JR5M_'
    '95O5owoC8Y8tfJwb#MS&>|?=?f&M81(oS=kT?!No9=L5fipa@F`aB=<Y;aS|0uH(v9V*IFe9>TVoI8~$n4TD#4MPk#T15{#UvO$u'
    ')oh4IAeoY%$U=f}lrZiD`#fihNAE~bfOTtHS#WaEmuC4+yoOKjg@Xj`bxjz3o$vwZc&92(o_)&6zHoq4_ZkSw_)!j}QX30Y<Hyx@'
    'GmwZ|*#@?noZ*T@sBp`OQn#Ii3DKA!7P?@9IfA1Nb0Ek8m0}Lh1&>`Zr*O_yri|{W>GNDzSMd=AO*Z~9U~7)lsB_snE`MsEzj3dz'
    'Xt6sy1>D=adO%yxH8vS)tCpaW&5aXXD3Jr8Lvix*B}%lxk7sV_w#)F)1iUU-O1Ard@YG2gnNVT6{&F9te23B6cGEwiHX6xUC4c#c'
    '4V4@w2khMW3_^r^QF1c3giHB@vp6U4MXjHXV)kzj4^u>fg#}<mTSGJWc5-)^8~{%T65~xY;E!Dn^ssQ>E*b^u;@ye?sdgTb%5smb'
    'u=V;j`=f-I&7jACSlcu{%-OEw4~oQ4bfJ6JS#q`o#MHT5=`}FG^AacKFZqpBFf1oLmn3ZyECR9B4|80Bm4M*|`A}z|2S;WOTkPxZ'
    'pZZin@+1&~JWuxx(sPDqr!{fnjCy9=jaU~D$AUq8?485kQ3IkfU_^+GadWn!V%%WyYfwzQ1hP7wL?_kllqoUVAljskHI{kl5_9CC'
    'jCygs@PkL}zK;~u-nWm81G24kid_OGn8DV$b941h)_8Hm*11>&1MjL#XN5h$&VaDVhhMh5v?|^H@N@^}G)<88AT*9d3p#H@Z$K%k'
    'nB24!F|m}^3V3k2y>tyB6*(dNI%=<{==9bmF~w80lk*8S##A!9<a#&ZpmZe3H)#MKE5q+hC-v0Mh6@Y>Ard~c5!r5GY9UTxwsgf{'
    'bOKZpYi51d(&2~QbEF{|rOM&RFXl_Y&{2P&By|m@|5gDGjA_FE2^wYrk{Cm!FFac<%|(<Sv>;TRD0Q_*<Sw9TIzq_>J3b37q9Yt3'
    '+e6aI+96@!n*=@+<#oz*!7N4|ie-&p?poiu@~&6ux_aJqeBsI-VgO7tI(6!5RpZ9}ZW$1Msz)6>rhR#oJ$HUnXCn}V;jLlb%yvH4'
    'b^&yX0hy!L5(Z8UpX$`z<g3?^B9p3Gp%Q@W$aYqJxMhGxA9X^@h`i84yXkP0Q4h{^K$8pGZ|hijz;<#Irm~+rWeu4Q8XE7RQoP00'
    '3~IvX?TiqtrYMRUU3QD}p`<*SH??!oS6X@svSQ3pvf*ZqQn03xE?jFJPj<mo1(-E1os5lOd7Za)mw+KN5-iX^ms@{6(bcoZ5O&f~'
    '9n?k(W9qekC)<X8-`4<@UUIu*gr&EJ>6@={1a{i3$1FrrBgom29dtXfIp<}k+a&gX;~k%G)RBwxh<4|qSKiz->5M=<;y*@BCtfuI'
    'yViVM$nlr6mCJ_VXm<Gg`J}~i%Eo%ai#hLJ=73AXX&6$x@fKXJzC{&H%y$D=)lRIlukqs!E3`K?aqUpT+690ohvX!V&1mTK7<U=W'
    'sIBVGP8G#!9i-^Q1sonTSK!~}%a;$TF>xR(Fn2!N+Le4UET_&*at&(qlR{sAcgM~5S1Ko8(`<Z5KX;8zG3F!H?m-d46s7OB8f0`_'
    '5PN-0b>4u}K*z`z&Uh@<TfOj#Ha8VEjz;ePGjYqHwXh2P0;bFHT9kw`h<I+-*AG8Fi54230$nVNu&`~m&D!T63_roZ$^f3bzj$)('
    'A^%`_wIP_(G-_a62Xg=>Y-_&v(=N<a!xs`eSa}&YS{(c_^H0dXVYv&x4!qR~h(X=oE*-jeaK3S-TzNqCjyfAB_hag@OPd_^Hi&T7'
    'Vgw86wZ0-aqhH~t#d%R;85OyyyE$n8eC@?jv&EqvVixxNxTxvdbvyG?!g*756MM1NsdU(Dp;wh8NAqpH34b>2M1FV1hs#^EU3pg1'
    '1Z+v(lhC@U!su0%g4JU3pGLE$Q^xEb{5b0}^?Ajb{tPP*Y|E_`X?9O}2=u2<W+jsd!$l&AFx|Xn>v{w03ttQnsOP6L4Pu{v2s>m_'
    '!&RKvIiVrt@EfWLeR>sW-?$4#pZ%bCbA+DwSH>dS2dVo#h-?g;*&1T3VtO2<zd^9LM^f_4iK7G5=r97-%^Z2>w`KlBCB(36etJHI'
    'aW`b8^}g!}AL@btQ+=CE+-iaofEseHH-EU6Q+iZh39<!Z3SurIZ}lG3+h_O|Bj2MrBx?o{v+eR8hkAdo(E1nHkNgS*9{T#8aZ@d)'
    'eDfp;&@)<}gTeC#y?TQlJzXGF*t$99uY!k9P=7%D1yQox$r4ZDX28S^z<P}To|%ekUp0}b(dJ8&DA9Ko$ujMCqwXe1W`E6Qj(U`u'
    ')vt71r=5lQ6DIkGsz-2{!!94BT0vczG|q=7U3#G7sfkB4=G{IJryUwNiT8dcQqux=_2FJE)J!_CN_wW6$p&FpBiUn-=manWt)>S)'
    'TqSDMT_wmD?Uv_8b9%5}8#@401+;SggM3pO?my58fKXtk1eXPkL$~T%je570wp&b2;5vy;k{Na#+rEek!!-yZU{3w>xyvp+%X-H#'
    'i8HJ|_}ETJV}l)&&RT10S0xyAnN^~2pej1vg?j7dsyNTu1(4)@fbBW$oK%t*DX3ci?mK>LFSjGVnR{<jPe8<uS~4;uKHPhmg<r|{'
    '$X}|)d9}?AcSxtPlY7WDR=O`Ys~4}&(MnlMBr-$Ea36I{#}wJ|4UO~SoqQ~KK|={tUhZB_#?e07m%zp}?rMA4XR$%o(zDP$KzvPx'
    'ASJg;iT7oic43(=?~==9=uk7NtG=F9ceW5d&wOGhY^s(EKd6&8St8xXezCOD#tzq<Xiryoh^aBY{Csy!vT`sxE01M^FsiPohGPLd'
    'AGI|TtCxo@3L?xd^nA!WsRtRdJmKk^9Q$tIX_z<ZI%tV)JAmedO^1;CwSD7?WGnX8{BcY#E&hDKPxYP)SO(5IQ+a3`ovS=%<bE}G'
    'CcenR=A*X%`KKr}K!)%5a%Ie-N2&%o5`X_VJbs3c#*^IpOJ67ZmnA*k&YV^OkF3{m+NIhDN(fgPlzyqo>ysp@qh<5@JvSY;M9f7V'
    'to%KaSOG+tM=`Y<h<^jrdap@dIImexr?`HKE{LOxJd4z~k`MU9^C1Xt4Sx+y!4$X;Xi4C5j@mBBHPE|ClSJlSXV6$eD$fNQuYXq&'
    '#I(+z0wUY1?#sg7C{9O{nx;$l#*|snx5=#bA%BiU3we8yCL`d*r>ma`p|ECt<A~AUD{ZS2L^m_|hkwPjTt6h^5ZFb%*9o_m>UHuq'
    'Q>s--VP=%OdS}exbAQbfCw;?-DFh?1b`%e(_qI#Fh}@#}9UviAoZV+6bbsGY(e!MuTv|H_bxPF9vm{Hsx78G4phIW_M%z8g_J88V'
    'r(iFhr=JlrqYjvOWd1{d%yRT4@FXHW{<qVAJ%9pIY^wgFlBZ8TEMyhK{52yFtu^X+hG;n${!~y6_JE4^C@Z|~t6UD2fLx^<VY#5U'
    'WcAINE$#q;f`b{VM1ZOo*8sCu-1U&&7DPq%h9bF$D`+5l%pDqJd*`m9BY?&{lSF!-JF7rsHt^j6yjYRPNYO<Ijf<JlbHka9^MJ<x'
    'T3Tn7W5q+P{y}NXiD$1n0i#aDC{?I6q4@d<!+_)WKr0=mN>7(Ck!L5eA#t+<GLDMv7#fI;|4MGTOo34F2cUSd@HY-zk3RW_kZe8f'
    'Tl^6StSpOadNxJ`3V~x=QuDSg{zrO&gunIgZOGm|uH!Vu&(u_W%<tp5zJX@`_^WXfexZe<E6V-2mEn96`~(N<ba*iSSv=BjzJYh<'
    'IC*~umkAQBEtr%P8AnfI*?YP)hYRWy{c#SgQi03J=RHLQ{B&tkO;=M5dm(S3D(3^MRp5ZXkMm$1j)Bc1P7j{)aOT^YWRcZmuqB5&'
    'qzA*bd#qHoW_JJM>w(yDXDv$s0^l{WwrvDcmc6Hn_bb%+{s{))pWCn;eS!8s^s@0UQ%`*QcCb6{%So;q4Sv0wN$VpFR>!N*Sb_$w'
    '3i<@hqfyc_-C&Pf;H*SwV5$08|CfNHYJ++dYl1doJKydEorGf70yc-OCLw7*>sZlPqMRFeu{TM5B7$*G3U8_eJO>&T?R%6jB(hPy'
    '!^W7xJV+jNB<l6doPx-VJ2KHZCC;*@K53MWR$AI1^)ejSFMQ8pG=8!cdxFmX(fQW5cHL-nN|BPVDU(9v2F-_3$ZK>7V!Pr$fP&mg'
    'LKYX3-DamEKT*lx9@Ba!N0AbK$fPW|+Ser6IfFl63%fx<5tVzo982I&^y3PDFHUp<F;<g-ytdoBm4lKRsA^P*!j1$cdPAvwTwfLe'
    '8Y^cXR<*zzPa1mKSc8*fi!)oc8w<VyX+B%?@>p$_gOoWQq0KD<jzw*X3WK#a=Ol?DmfWsRA0q1q%AxEd<p||my(&T|6kb_XMuXpJ'
    'd!55|YiD*=4uohqLft76j-OdbFw7?h@5TZJD})ZAp?f<EtG8;<>z$?(h*B(W(F~zTp(bbX8hGzLl7tTq)Xe5g98<ll5;ZBb^i;)<'
    '`z3rc;i^y^z&~YeXoMEBvE8)_^Y}PZbc>2gic>MPj4Qlhp9?dr?2&4{e}oqJyZPDk*VWEu2}%4dKib^^e>$}ZFdo3XeW595O@uu|'
    '9$Z38me;rRA~(=yD{m}}qjwbSNgjOrWk3;BMucnboZFqRZPh!c2)aI9qTSc$eN@w(OmDoUSSpXZRD`6ZJD%hDw0QP7-<)W(JBhQi'
    'y+FbC1N+ALdaaI+LWJE7)Q2A{T{(fsvxGMYzzJ6v1X`9ue1@r`(GQv)2891k9!rAW%3@enI$0DW!3%neG!zCHmdbhjwknq&2899K'
    'QZ_3nXY-+-bd2`gkO<(`8ke&3oC6fJktzOYv4uyCTuyL-O1-k~5h3&_z&OuCNn3hcD}h1M6e!)OYlY51FCG6L=-_F1DP!m4v_cwy'
    'it{p0KNPqkW5;At`GzsON@91$d=;^*mdTptN4|V4zGpC$#6Ce9IG~J*xQ0=d18DVN*U2&OMQq)h%!+YGew)2txx=l{eaw;u`i6%v'
    'vcay<$Ee?FAuee`owC5HJD!qR2JALc?M2PiQHHG7HTb0SopS%u7!ZV&rtDn7*dPNw4F)JCW+qChVTQpcUr5W99?&LyfQ@jRHNWP9'
    'h=kw5iK|Bjw<PG}0fy9oToKjF1TpGpWO#vw1$+MD;5|ujIr%13Wgk(qfQJeLqux8lZ6(c-ejle*WRyR@V~%?6dULVz$)z!`CWkAN'
    'K>&&kbk6u)7MaP_dO=(U#pG_oI&*J~cjava^M@>(U=J%X&bm=)h+)b!9T9iC&jIA5q_nM+lso3e>xWYdLgXQwFTNy87h=K$z>QD*'
    '&B$4h#WDd<p<0k!hlh2ZL!@hHCvIAR(kmAMH$uSaA<gUl@$B-!dDx{H+lP$1qmkttT?d&0-=?kJs3|Ve_`OQ6jY8h=(2mVfJ%~!6'
    'VpfB^5Y0l+O~T-3>$VDjuGBk~d<)bP=X2VB`-p3sJgG~H`eB4$SR{HL8A8{Z@6F_J&a<X-=eYr96o{5FRO&0sz)6*&2HX;emwT@Q'
    'N5%UQrJ#dSw=B@vV~DX<IXp~w;jq8%o1Dgb4J+qTZ?*RKAsJIaUH9ySyoj>J63jq@-@4?H23ELMk(HUc)niO44D7AxH^V-S?1;Mq'
    'TFE~OU=Km{?M;P?tmfeHcX=LV)XB03#hte5HHgq=3z8nS^M}mVV^NzOdXjcz&W6OCZ3q!?*~OqKj)>GnwDF|*%9WodtoQF!;q;KJ'
    'Yq~l#TpE+*@RLZV=7`&4^D732*CFX10|DOh$5d~Z4I-^OUhnPT{%zsE5Q!%QEiQYlm-#mKuA<)xqaHh@6*BxQ%d2KzF}Ziz)`{&8'
    '(4=u4>ccp+TRx6)zy`sH(2^R-3L~5y5F7L#q>2kvf+WwGjUrHhJ|l}~$ujv^?D3-M=BFXS^B?i-K8hr7vo>TsH^njl{zX+ytvohe'
    '>3uToqKk!-v~9g20*W)d#FK^RhKPKF#i2E(8iFl!YhHQ<375TTnWqqmL5f4L!va9E?%ZKn^DFBh3cZDiLk$$BrdTK@kS;w7W{PkN'
    'OD#Bvw^cj(2<&<zrCsKR`6MtaxI~#oe~n{u6pD`(Q>#^sf~L>2o>d!|Mo&(b%FiEhNj)a|G9AAJL5lVgGHy`NzoE}0fBw?O`XMC@'
    'JQ!Yfk?1(ntr=%PtcwA`<Z=+>L1M=J>bOt+neKig{t_k3$e!B)LNht*!;2v0&vKJ&So+b$^sj0g^Vc!TC08RtwTzvuw0-MLkBck3'
    'XnGw$OwvJqnC@8<q_Z$D_$Vz@ZXjSnSC3nqkBc`8Ols(1!|$k>+xU`6J*d7qi1vhM20OV#ASr*(K#M&D%Mk?ad{*Oebl5M7%H2JP'
    'VWquy*6#;f#nueOJc~;fTf*{KOTY%|C5IXhtip)fdJee$UWZ$B$GhX!=Zj`$(_~rQdU4T^w#^SXHOWF^GlK2`h#D;1v_OvxB8zSi'
    'gjD$Tdym;}{8{c^%@xJvcA;51UYDP7Yz<MH)r*T=I#5+i&1*;)?fOt&AjMrKtVlSP9!#V3jLU|nRExTQ{~b6+&MT$b@qU8L%EO>a'
    'bcVik{&1IQS?U0n2#dVRSM=a?q9Chz1$Yqz8=K7N798#a%O5a6b78}Vl#9beEh)~gKn<Q3ZzQtk2Y^N~=e;r$^_J+<%@8k6nv2IC'
    '*2#X9UsyFZq(v;Q58Xn=!o6^T=i&xL!*9`omW$sA;b#r0%={mYP#GkM=uruZqz$1hc3}@stm&6(u#6A;E_u}7!boMX^n~FQTX?v~'
    '$*bfRT4i&1G<nGumW(O~Orp29s7;Up*F%D5aQ<lTWzCHSVs)9wZMFGGri?nYis@zJCFZK2mIC;M@vi`0_@_xqu$0#A1O2?bWQ>&)'
    'F15uj?a7;9zar-0ZV5Q%!oPzZB%E$bbFJ^SK8%(b2B)2@10QjXw`#>&9V&Lk61M?Qb##yrwX%uHXpHqsiQ$((w=<~7iI5l#-kuGg'
    '%d>lM8n5@1Szx6_B#kSrzI>(wy%CLdv_xNwpCp6zEXQC)QSG&8a`e}IC5<^cvl^39x(vov7oNv*)evzzpLh=Sa96E*J$(U5-Hk_g'
    'iG0^26H_#K)ob#(gc}$5^lTl^Me%K}#k6`Sl#P62XjxQoIqZqfwW3qrsBuPiY^J_4_I)@j4$G7JzKw#ocEyY_CSqj^;)S;3(Y)5E'
    ')sArR7X}O{q_@4L6^)Q8DeDC)2vj52Jf)WlXmT&bA=y4JR-)UWICB}1V~wnFcnmE0OX;<#|E$pFuPe*;cz&VjWH&`?^{JszRgJI7'
    'Pz}9aK)aB@?<KGs9fGx*RBx(wO{RCXGMi+%vW>q$m>N?zvN1Nh<w#_Nc*-XPAGm$GKA(r|!=HnbX^qoqn;M#dLkdR;E?}^NR@W>1'
    '8dsiV3E1YkZdbR})s6HSgJt>YB@V{U+H8{Aat)#1_8gs(ZcAA>sft|7j*bGzLltw)-qA*WN}PX6OzzrJ5;v%=+w~pK2MHZ!J&t49'
    '7DxoRxP2P72!w(FY@;P{j}OjHM01inZs9uhf{!;uxexyTtV@HE>$PD-APfZe^iR{&b{oL-YKK!3Mvp;5GE`u8<v_lUbq>cCF}&5f'
    'yW-jFx<C3)wz)8>8IP3a<uprVR+1))_;D)A3ZwRPv#Fen;>j9ICdK$eU5}wy41^I+FSI`doKZFfPCX0PRA8tomY_yuSuOLEc#qDW'
    'XIsOZt+-&<OJ2+q9o-pK_iHnSvz#-1m?Sp;-;gw+S=>7nj`rS%pyGsA2asVp2*+<{G7~SVO!YPsl8`yz5IypuTXwO(Muflok8WBv'
    'Po)9iqgD*h8s5R)dXPoTT~{;kQm~R~eRil&2kl4b{5lJMUH4)nC!eTifRLcYK%^t9Q%vF)E=E=49SwrW`%ZsV6HH(DuQZ~H#gPcg'
    'RR{<I17s+A{nJV44daMi*{uKtK>EL)zL21Civw(M(3+7sif2A@dIr>ht9qaHW}|fuv{?8Gt+FZ-^yB;f%`K5y<zx(R(aT{;{T{;g'
    '29o$i3MUum#w;z*bLTPw!cdWACGmLtqQ*_-tb89Y$e1UT2d_rwG+2GKih=ypk?@hFV=NCXpP2p$yW2r65}E&v@d96*|2f)9w5n$Z'
    '0lJZ@UDKbcCwMsb>L%RWh=xWU@t$Gb$`itf#iRic7E6(_aR!LA`Zr59t4;d4Na?yi`TCXSu!EPo(Jn>~fYp(*#ge90oj%(%|KDPR'
    '*HWyn(d*41BuU$=KU|^bR)mqq>IY^^m3ZJgD8`dl(cr;59;$petmv<kJPs)t`UjE7NT1cY@aF)AXpwocW7-<Gbz`*>*^n=|=s?FQ'
    '5&4nRL-;bJ+?iVsD&6S4hn#l&V{8dB3f@F`ww_5fUmub7^&>~@TxWU=i~GEa%@TV6Qx0UbB@Jds9{jx9q^6P&g56H+FWWOH)^BU1'
    '&KPAf-%;}GZwGjxtb(E;Roaq1k(QS2ux310v$@$~Q?}i82@`VV3Lb_iD`*XkFM*Pt%>GuG+O&26B4;zp{g);)7JD!{@$yS=MWWK7'
    'F9wpUD3KrR=h$o{6i|mnV&*;EG)B5BFz7-skah2-uNRWW?!qXJjr~=~zJtqR!Epo$LD7)p!^(*w58&+@PWF=S=uVv+h;mho(;x16'
    'zBge4DyA^Y4cYEb^Kh%et>=>kv{f@wQrE@{U}Sms>sh1-w|8Q=|H4kR1L)A~OGuL=-wMp*$Bgpo(%q`$Y@nOm6G*~U9+1KCVL(SI'
    '?xmAv4*0i8$CUFUojWJZq*Whd2%JnZqFX4zQN-^>XAYCiv*5$lE@)L~sln2CKiVa^lwd=A99rme9yOdX+P#zEJ1RYB{U7^cjC>W*'
    '4Uk;b40wKxf}$$D%vrrVO-_^O#|;QsRDBv`4HQy8URA21QD;2HhIS=rQF*aYfdZ5D)OuSW&_F!J-=1s+p_YoS?+y4~5O&_yQap(Y'
    'tzncM09nc$*>MZ#%RA`a<T4m4o%nX!!R0X91@_lpjwqBrm;8pOBdP@i%2bCh^;fZ&$=5;cdOptbJ4y;L!2^_1yf4u<N?~U**i9o#'
    '7)~FahgfR){~V)-$#(=ns|=J>gOH(LFDHlhB3EdE{4;#Ie1NYtvimol<aT4%fM%4h*Upz1_rMS2H~_6>ej1<*vmz<G{hhIvfq-&N'
    'u^*JP4-HqF-yzo}kdn^T6p=0lG>u{?v4r`uyEmZ9IWUy|-id+n<M+2tetl#76{1*j^V2H*7-g}>Db7rE>TZ<;t@%{20rondt?2o?'
    'K(RZ<y^`~l9<Y~}=-oPk7P^(eP2njh&jfUl+bBH=jOm@`r-|ZQKy<(l6-}$^m~55pbSL-uElo9ul%7j9i+{@VSr-fTUsN)am`c3l'
    'a_^R!!L6ww!C^us;z^Bhmx8WU=#iTN;f0>p*Hyqf$=#ONAEyv+C~I8=?j~a8@olW?${~Q$TWr9JMYkdDRo0gkbtHPx=U)Nz9hXmT'
    'oTjaQAk8_Oj|~%@mlu<_YGRjl1~F!b&nDA_I4&H%#3lEIt?pOfI0CJ#R2Y=e>nWFz<oaYt>~;+gS{(R|Gbr{ItrGBjP9>7$q8}nw'
    'ksp_<M*SKxwCN5j=@Ep>;vRY{-`vsRpZz)RSyOs-YgCuXiq(5hcjS%|vVD|xHcyo*ejfe=b3<0HxspZFdpDQffZ}yQ&r;{<sCD^h'
    'MW^F-wsG5XWn28cB4h_GoadNQSK`7~2<^XOp+VK1VR6cDbrD2){$Uu@3UX~UwtATog#bTY*lS+Fqx@pS#^aKv7kIrxKw#SOm;q@O'
    '>SLKM!L?f%#IALUy(!I2wX+KBJh`rs0v@l15C{sSE%cd5eeQ#f5ZJ0d4mt#FgREhKU(7Wb2nbTN&!;_ItYMkr6B^l1xP_Glvxac}'
    'd;9$w8Ryc=V4<;P(gA!=4OE&${PpUw4?yF_H=wz?!6%N89TRP=T^#5#S(?13YIK@{zWjD=KV%%a^=jS<CSp{qS-?Lk_!A)KMr(gY'
    'KZ%-|Ux~%a{yP_qqqi`2#JAL%rm82CN9zXY`^5?4?46pXie4oe>yHOl><b{15EaUHjA%?q@%t_+Ly7?r#8R5jcP_|cCXQPV&7$0L'
    'IkG^6W=7N9_h<@pOHb*x{pp(C8^{<L&!65E8&td)R7?85rGzfrW2-*4D-=ZlQsJ83K>-*^l$SV{QVzS{ZJ}%uAHgP{1M46x=;|e@'
    '4lJ7LU*Tpp@@}m=I-8C(Gyub;8hhC*eoK-HLk?cOuppZT?+`iX{6}$JKnH!pTgkc#6f|fRvy|PhtI?SC8}^%H_}0XCw@4m+oJ@*J'
    'eO+7@xwoS|E<NZ}T$5botaF>bJAtNkPpPG{lYw{;pjgdZ>hv(CQmUt;q<QkUmuQ>udxX1vRR-9_Kl3diSr+;Uu{-7<eI?<5V8Bk*'
    '`$3!lHL>GA-;~JrZrK%lUfexLp?!COR3zK8n(HVz0mGbXd9dUhu{>n;Z}3V9Wk<RW7go2zae!cw`tn5(G{~HD-+_^ru>`&Ld#YBZ'
    '9sCcnAfML?qih<0|KxD|&fJ`he6Pj0ebamuBl`)h*JA-8cscTg&EHk{RgEWsXLFpRJ1>%=3E!~itIVlzLpq(4*QudOAGZdvpR)1}'
    'OwgRK10-uerKrVGc}p;)8=bU6*nwzjKV0Wwvaxp==arohQfr?6kuzYG!oMEJ{)P{><8xs<3-^&+HxIdZ0H&RLa0k2x2C0j)O5_rW'
    '!q>LOo3te*7fj0{h8`A_c3Pd}3}7LQ@Zhydozxqn>|+uh9J#naZ%-BR6s`Juu&$mtOu?X*UVskFiWCVYb9cn7uP%u}1{&?0n9T3;'
    'WYeB&z}I)A@%%eM?Rtq^4=EDISq|o#!D%7N6N4e0GkBkxX(62j{Q4}hyvu{dX2QhWu{~2^Av1<%YA@SNTOFUzeo?fvEK80{k*7gw'
    'Qk^w+Mqsin_>yc&<7IuYF4dpnN!nERgTvRxeifshgna=ADyc4bV2AditDMs>-cX<ASUzl*jvXuE%nUZjN2tiaw!?AKi>=Hrdc$dN'
    ';c=jSnD|#1AIo!*(E0$+J<?dmsb${R(M|#lz`oK-%zU7;M0%Q8d0GuDabexga=6Oqyci6px-DfY5?(+J0+XQH=*uLYG}{l{0yVj6'
    'z?!CV5a-z`%7G#{i(DxLZ<e6&1}PX87NQTx>;Y-Pa=2WkIxX8<U8`)Ce1aj_iMXKp$D=J4F(<{8C~^MD<R!0AqIVUh3=WFeMm{*L'
    '{!O7PvTrND6iBH-M(ZZ^jN<3t;J8+igJP^bl2T%}fIFdkwD4%=oJsSAh-XgJTc}g{9V4V83RG#V=BmqiT>+t@AKzKrBJdmkJ@fEW'
    '1@DfCn8yb%a*pHl*qh}N2vMQ2@BvS20BVV)2U$iLI`44#8f-YU8I<;_UIiUx2>zl$Zu_e34EeBp-7}kUf|l4R)PTw-Tppu1>Cekt'
    'F|ndo)gkI;HDiO&b|?Tw1OL@*;dy=pp9A}UN;FfM!#|>0hvMaVfmtXvRt)c{!sccjRcfX4Dn50FD&f)Sh;O2Yau;k+bte+pqAGG|'
    'A2<C~ZkbzWwjkdIEgNneA<3e;Prq6UYT5NB&nSJf<fH+w{3w<O)tw~s9;gKG_B^7$IqnMSRhc1`Uy19mTZ^e}U#X12V8gqepb49)'
    'pH-sKW~_yIg2&lA`tk^Wj7MCkr3>;~rcr`CVBXkb^i-nO1yC9*ZY788kLAC9eSBwL(VFf>WqR`%19J$A&iSJ?AY}+z(J~<~xaYBj'
    'kK|S3L`9sc<mBs5A|w?tXe6V%JR(BGFhV$nXnO93ou5!uV%-vCikPK(VTp>T5&EO_GLXz5t%H~W%E-}F>sso?bn~;(4h1z6-pND3'
    'kNc!VnDxs?emD*L%&?9PDYrBio8*+~_#k!yIvUuyS8AkWT{Ik?v^uqyWQbIxt;iJ@bsQPkI27f$`O3Bo>z<_k0M&T8^3Q)?4kZ|D'
    'zT~;-nwt+4b>D1@&y#kmhT^3L{K&m3FBdVvt}@s~z9GCiHB^k^S9Ge2__WJ!dbg!XQd`P!+azI2jbyDhyZd}%%tZjR+@JfsYAH9g'
    '(j28r@N3sfy-i&b_HqXDS2C23$*PbFU*9r*0zyxjgtw(l^24gMei(VFp|Q49Q$%q5?u3-pFP2&AsG24UC|0G7*tfdc$<x(~>^+sd'
    'yQ~`(pKQck@^rI3qCPqc=!m7YX=Jnw7GsD+>^KrJJx?5S=rwIl5uD!$FiawPr`)Bzx<UH#=O#JHTKg_~aI}Adr=^R6)y%3^qa|XZ'
    '6{V%o9Y`5Y$0KxmL%kdZI`t$^=OKQ&K@dlV^S=F>5rd{NO78nU+e$?uAtaCuyM}r91IWBmnq2pO-RBW7Is~TD?8bf;v82}mjZ&;i'
    'sN9twf%M&Dqv!|3$}_6zWFn^798Rn?D$(?WEZgf`rVeA!;;*YIus6(YGyysR2I{8*HGzCJSE<s*wj&WnhVz84(Lz$6SoZrAX9KwP'
    'FyN;XceSsqDeK4KOH%iZeG=IQ_cQW^G@?x_xCIVI10JUp{Xz~8ZOv^ikC5J~7G+lkEw93i#CH%eizl}Lojj*4&6tT*Y=yN97ex*%'
    '$S;^?A*XvW))J%CkU9z$Cdj9CZpi{*RASV*J|#JXLS*3;P*)z7(2rv+vouD`CI6?`a%o<Jn`6UO{+4Rr5-#N^tw1HE;O1GwKhScI'
    'Sazr6;w>4H`K$Xv(_Qk$F0TRrH6fo{T6fJ?36}Ka^6IDVy}nW&&X**}V&<_CNoL+WRX3HY$@5N4(LR)2b#|yqNRxE`crgJg)U`dH'
    'jZX5#QtCpKBQEab!E%7@)`zH5dDy3M8NX`v`%>G5oMSIh@7YZ75E%>@j9NxD-r}fP5(EJm1Zi|(a7N5$r`H~@3E5dO@Yj6{2s_Vz'
    'nYyTfu|3H*7~CsPAGy$aFoMDk*gciqjoznHYrUy8bUvuK+|@t?%?aT;fl>m*W7JJ1ol*4p9z*21gdwEi`ZcKP?`pKbnm9Ja=Fd!4'
    'b2Tv#K4?Haq#=uDKV<b?E^VmmDbvMRvdGkWvj#amI}jDm;opLV17$Xo7IUh|-kPZYjPD~Q!p-Nv)(-u{y0SPu5%JRHdC-n7DYysK'
    'pDd~n^{XfQ1lUD^%_KC<{475kVHd8|=Z>eJ*`|h1wxX&MeJl;!>W@>(;xZ2+lEZrfjy~*P3C|-{AALgmYI~|J<?sNkd{7-*;jqMT'
    'QZT=~2QQXPuNBf&L9C0PdfuvXqYhi6I!HXd@CMPu0i^F?47aUk$vE=?%vB7e(O9a&!a~fQvH9^uz)QZADV%&pR9aEv;x-Yz161U&'
    'RK2S6qh_x)Ax#f~-7|Uf5JVcvTW}|p+iv+`Oh-iIU1h6{NTzpn8&QTab_()X&Z?2ROHV~Ti&h8@&=J;Lj-spDzzkD#StX9plGJ2F'
    'Y+J>1WzM3p$-X180T>er?bfVQhlP(Gnau(^8e9G03Ti2GXUj(rB6ah-xD)|TU&gFyR@SI-g9oT)Jdp#=spd9Mwkpm;pmoaD)F<fT'
    'DlM#<t}Cz@L;sXMs#@fS@5V$tN`wE#7Z{3LGPoYMvuUjZahJRlIt#0yHGf1(8*Hr1*A1hqW(vCi<qd`TC8n)4DJ$$<J2C*Jn#B>w'
    'ThT7IG1c|Gj{v^S!Bso#IasZkn;#gaYRRbbjSTfp37xWRYqNF-m$pVFCwm?d(ekaDXEtEl&iXCIRR#5EXJ^kx5KCF}9nO9MBHq8p'
    'AXcr*(_{l>uUb-n53X+w-U3^+njbW87xr)S3JG%pv|_Gypqt&sc4Ka{6WB&w00ae@4QKhlqUcm%@1VA``IfHWCh(P*NyH<)%|c`>'
    'V-(MDi9k(J0p!c9ev<(<jccyzRZI>a;==sspXNm^?6Mp3xua)UJ<$m3OTRrzz&Ech$HiLsYTGi89qC?0NZ>TSz2-1d5@cO~Svsz8'
    ';E%5}nbHwjp`KGE>?u-Cs%&5=pO7{ng@qPhK_yi&;exM(qtV!_UxgdUr63f)?lQ<}i{QW>keS<KNV`!n(7UhJ*M@R_D(4W8c1(qE'
    'ad7pt1->JBM-*z1Y2JD#ToAAbIWTvtZR=_^Wnh`#GZh6ctNIV8c!hM^<TR51Mg*`AP#G(}8qF^II=dz8uXP0`t$e@agCw*F>SY1|'
    ';&iYO=lpq-7Gk`U7!jxmd}(qg`nx`A84Rc@T8oE&!eX!zM+m3G#^9*gbcM(j^J9N0KD4hIQw8=_gR3iNl31`Z&IWX~5E7ZWQwPTb'
    'ij<uSmp_qZnrgFw*;&BjlTNTrg6e&}>TSJ@oh{(ijC#4E&Aye|TlQ!*_uD||LCLUnXdY##tcsC2*gL?SH)Fyv*MbgWiu(|g68<^X'
    'S4yzOWh7P&0*>fyKYaP&mJBg+^RX<}O2&xI*pIZK*f+5D=DGZzX(3N><muouQwtTyWV=lNm>72A{UNO1@vpH0+s(QRqCQ3YSgj?g'
    ')N}K~Jih#DNVTtP%v6?WX*jV{<Ga9habuo}oC4@+*3aA)X;mK2@VQi+R02VkCT+21Y|PpYoPQW<!Qni*Zckq`?1^*W=b`HaOiS{F'
    'SDUgZXd#*fNT=cjr5f7LhrS2bmPh}<K~-HeLef@g&VsTqsoipbjnnhf(%P>t9eX(wG%ky0C|BTYbBGz3&m^*F=z4A+YJ<ki;Yqd+'
    'EBwaBQ3!P-^!;R(@gZ;~{P(iY=fr`37ELTf`DZk<3#I$Or~|zSH?g7l2v8>FU%#^7FNfLi2UnilYUIT&&{1TGOZ7DEW0`nZ=$b^D'
    'Za1>z+QFz2bDDME&mg!>7xi8FlEtb{$p3lvzU(ab9Wt{+<a6#4HSYgqJjvS#S347}pA050eDE0@Nc$1iu+Fn?`}TXsTrS&89G(1L'
    '0)ZSe{DPT5O5?G~&^~%mWNEX&G5ZI{+FH{MFPDcE9EKU#uAjiWN-K(kgsxQP@{qI@WHO7}E}%|pmJ*JRQs?y02p&D|&TO2YLL!8H'
    '$Gfy6$qhu~U_HA-(NG~b2o@wLNv3@3?$!mk9!ZmynfSCUOsK(N)~DF5oJML(xeKFMvqCl^3OTw=fL8;v<-4?curhMfr@DJrv`i<T'
    '9v|ezv~VlQDGd-X0UjY1(p0p7Rh@k&<^g*!>V(%`^<IwyVHf2>=3~UK;N?T8^`5kbftb+i!Gki+xQO~aj!L3_9%QtC?5#S6P%KZ%'
    'xb3vKl?|B{>nNaGjrq<FMQS;LG+)ZmQLZ2!v}b!$vum`}bD@zBVN=ZV^_undkb^M|FuzucTSJD?0M^D^ajdl063Fl+;__6?{;hF4'
    'YbRK?90K-RNZlgyUz{3=*5b93?k{M>zqhC~`Bdao3Q&r+6;$Jz1jCVsIHJo*$@R6vZ`?bU$i~#l;bYuCL^PKmexHjfya3J|Q$KG)'
    '81J>xI_l-iF7|?&10OOoMj`47HMX7ZEIq?vt-xtlFx<9+!EBN=+^RSt-E_vIbe=XWGh@`@Dj*0Op5A+Gzu>l%tI&84w$I<Rb@X-='
    ')3Uft#U5Ebaz%3YOsghA7Pq#r#+{jZr3~jaNhfQeP0J`gamFvNR#B0zE__FT!vVI`Gk=4d6OPj%o?#;6QnQ)oz@c_ZBYEn=LF&q='
    'iu$(uEIN)Z=~(&i&yzh+{LuIC#xYNmSt)%KJeUVD$LqHfmEQiN+qC%Rr<&7$f=?a%yrn`~#ow98`-SK9?Zmen^B9wMiX5@l?Yau4'
    'cKZzbk#N+&nWCY(r&bx)Ri(Gi;yxV{Dd8PCcnUl1fX#+Q$HE~>WBW5Cs4zGMkAAog6A|owS4%*#4Z|(;o=qelnKdquC!NcMPZ3X2'
    'uZFm3`0R<?gpSlAvo(!T82o6OL!9oBP9?e9(N1`m4neq$x_6<4bRUvcFRSu{A<Bt+H5M+AU248et*4O_iE+4-B*xuTP){x~i}Olw'
    'FC4$(m)%+Nqg(y>_Zn*q=i#`qV_9(-=Hme2r?|tP%=F7e>%!62mJj}^&`b#+{u{XABJrK-{7kgWy1LFXifFK6Hwjun$Mu0>va}`P'
    'l;pVV+4(h+n}iv9U^)?QE#o4s1=Oe+fZk9W8&iuQSHZaV+Q!z$H3*K>E1O{Ru39`_#04q$#~(JZ<Qu+K+wQpplZv&8@;OUhc;koS'
    'Lg^Q4s^YAs3^+J>VwOG6ykfaeb!v~IJ(`Y?2x*HIn~CNAX|qa^nMiLo7z}C8ewn##q)GcdeRZGU*5TQ4F4ac|=PpSUaghiGTnKg8'
    'e%-l%9^_TOl|K}1DSp~%12|7?OZeb!HrPDAX%k)#npwGoRg@oYF7RZZWEd1GR_c0tKYK{>9d(!*_TmE!zOcE=nruxuJ36z?ScVhV'
    'Fmiqt%h>B9#(Dv5pHzIEf#A8!s^Ta))ak`emqDuFsr&PrGb3p~{mKb^Q{r7mXt}xV0e2>9`G&VHe1uov596c{A*w97bjfPd9^--2'
    '_v*R!(C;83$^Twv#umgbKZt?s)K8q#KAm|{mN7%ZCN;Vc{E3@)BzYTdTmwr1Nls<k9wvtc#0Qs4XUbBR%mBJW`%Abpqzh);J^Olb'
    'bF0-%7=>!^*PUrSyu^=T$5*<EOKHsrh^Z%Jd~gOR%Mqigi)!+B4=19o!1}!&`$W2$Mx4RmSCQG=zxn@Do6_p|;ktx{;k=Z>Sk1{B'
    'x*xj1clqsAQzhf9Yh55Muw>6f>fCW>e=CM_c2<i`(4e})P7+9)f?0wpw4(uZbGqB$w;wAcNk_-}f!ES8c3!&aEgQRA+gxJ#6#^{Z'
    'BT&~uf<TUCQG=_<HKASh&W^hI@3l(rq`7U_JUDVcm?+|R{eR?>#>`)SQX<DbVqm)uSqggeL)B=~vqP*rc6ORrl;PAo8zi2|WsFM2'
    '1eLokK}%dP`WSsaIubw?RSP(d$3$lN0jtveAlmIwg0Q>wam<CS5rvRhB}?T<f-}^q#nlfcN|yK!L8P+ZXL7tnI>350)1r>0-zpBU'
    'Xebv0pRq;d=}etfh;Nn*-Ko5ajY!oIij?dSGMu`3{kVfq=VU;kV_0{8t}P-pfAqYh6jgx-=r;?*z}1OBxxTN^Ylpk+zZ(-hg-62%'
    'Rd&3*Jl4Heg=?ch1X(XnDKo+(b2DfJ)<4c%9?aIuyH>pD4YgSnbh(>LG!*6<7$OJ`7Pvo0tH5Tl|4MEVkS@Idxda%~B{H2OG4eBx'
    '<gjkKMhz67bU0WDR$lpSA>6$e>YWHVS1vf3<(bWip=Nr7jief0ET0N4EwvtGAc?(hHrhfkv+&@J8i|~xT6YvZ<frBbqY|P}hzm_)'
    'u$R63Hx2D(9pWIlB=S7Zq7Fk?#^jQ$=b}X$-?hPyfg!#}1qjXE<$2)xOlSnPE7OSOAK1f5f!6uz7esYW=x)B$J&1=Mze;?ogS03p'
    'YH_D)thD|>@hOOj7SseAN-DoamcS>nWs6Jsio54-(JW%<9X|zP<r;6nx$0FSom;<VB)|Yy0Z;29kc%W)3Y#j5;`b6W)PqA}Xw$vF'
    'Wof^kI&(KQ0CCQ`eg8P98&T)u)lSZ7h6*Ez;MASgK`Otgbr2JG%?%P0T>MC9))VV;^r`kmZ)oa;TYPg<iGRP)H#5mPl6x77$sYYy'
    'ywfEO&ToSPh{<Uc!%&tw1@FK6G7WT3WRyTp7_!>KRi}@%L@Z+X_Ae8^iSYhe?w`O$pK+I-dmt3Auz_Fa#<BL^m=pH#x;}SwYa{|1'
    'ejC7Vl<vY{QgoarKxkIwXL}e@EX%p6QypZn;ITcZ$>+e3Zj1`O4+PQ1wZRTulZM?2<)Kbf^2zsE^gJ-3%Id(kNu<Sz<2YLtTVNz+'
    ';m><qr6`&JvUl|x#=hIgE%3nkw*}T5ft*qa9`myF5Q4r(n>}e*xr;ifSBop2Ve7$o%9URogikmK)2ea1GHMXNC+CATbER>KvpzdA'
    'OzFXap~_aP&CX+u1rRiJ12-h76-{_iyHQ;N%I>I<I)=fFZzcQtyFc;k60bQhezv4F%)Cr*?g=Wp()oNFr3%5;K}uqn)8>tf&82vy'
    '^S39iz}6?$yzrPAP$#QqZTZ3g=N{M>D!M45coeK8PY;7sNC=vQNsBf^(d$HM=<vcxJ6}B^@1=+{nzcNtr@$7II&Dltp}?2N@R}3B'
    'K8V6gAvF^oL5`<njL$o$<mu@1J7N`8K?Dy2d-LXc7NEjSwE@J~Rd7#+8Bne<k&;}sS_4dasrEjGpfPC8hm68sn5H=W{T!eKV77b-'
    'KGT05-b)?h-Y`)re#cU;6BNRWV}sV4RlW>rpuOzb=8!_51{%o^doU-0O;*jI%<#gJ>Ajf0*VN~TF(6cBi;_!?*ltc*;O59-ta?Y{'
    'NV>w8tRg{rY!VS$*OSTZ11CqXe)9P{QzN8zkT+7V#`VIv$p1!BTC8g<C=`iT>Cg|&j#%&GAlh2pB%@oAxq8CS5SM4?i+`JpUF4|d'
    '<Bfh^!WP%_mIl(@XEi6bT@%9AA3dw1!fH|Ip&;J39Ii~nEmS!LcY){N`lI*>1;oQKprw=wr^+;Zh6ooE>d1rco)`i-Pq3n5-Pb~?'
    'c(}t`Ud*m_2q4EH*v~iT2k+BCltJj<avI}`y-J=SegDID>g2MFR^7nm8!k0o;LDVd+QQ7J<H*p#2@<l`>J7u6kPm_dh2!e_CFdX1'
    'bg2&Sv}JmZy1g8GOg1Mksp`YuZMy#3kLOkqQK8=oMR@{geOyA~yg1v}yyIR&|FFaG!mZLzt&Ti__w9OeGFK#C{Hfxi<QEC(uZs9`'
    'd}hQ23pFAm-fOV;BHqO$=B*V@=G|89B~a_a44KIl-k8J=Af_V^1O-61$P_+?0kWl1PXIELmIFgYTch=tGLOWhR7@$Z1k29cA7UmP'
    'xCOtd;Pi8<^)kSiw<Karl7_^q8;hwcL?m9&LyCEbB#KFKnBQU<(2`q%QJa+<%lgEx#??pJm5CcBTa<dx=*oQFnRy+em7YqQJR}E6'
    'QbxqalQ)|yIFk58wxiS{_SKO7^+Ws7F7;iT76S)XK0?I^-w4-c`XDlk`b$p*6cziJSZ}WMW>GGo(`B{);84XR_?Z84BGaK4G%4r5'
    'K~VYk5^}m4<*GoZ@x2aAK!e3^#|P93(pCK}oQrIf+;l?8#w&6-*fSW57|rnyU>(L8PEbfK!g@?1OXcKMR@EwJ{Dd6PEb-=0fuL-K'
    'w>ZWtjoza;(}^rnERMhq@24_fG)+@AutUCMs=~53`6$Lej=6WKZpWaDXVZ24JAumbuyISoykz0O6owEOzq!VF6^X)Tx0387#{eZ3'
    'o=rN0m;!MN&(c2iN^%7gMis`1a`tJxgXXI_UQ+Tn+~i0JVK2gJFqIdaZm+k4c-_XL$bYS!UC#^E2!X)8&W+6#-D(slWE#{B!h+r<'
    'VZ6q`12TO>q$Wy4X*(Ub)LUaZ1iqhM2Tm`U70=(;cJ;?8J{9?j5(GINZUM(x*zr$?g}7l!8toG|)hkdj7%#^<6fM!Qg`pz?sqRLN'
    '6J@^qXzWU1xzV5-`v4Hlp}ognR$RONu1zlT*N*)@qWOv;nhw}aj=$m2R5Q}G>{`dO0e8aqr8Ob;nn$5X<A>4B9VPYc^S>NkQ>a7e'
    '-e||rfcq8?Z0A41M!jHyUem!tx0(HgpXw4-O;{OxVU5S$IbOCjb|}gV<so$@JSiohgaHIxChLx4qrA4diu1?pA^3oDDvdhiX{2T&'
    'AS07}+<3a9emDrD9{RW6q07h!@3z&ag|SC0T1DH!oU-dVn=FN71+$WFWvI-Y3v$RyV^nG|25QXFNvfi>2)j{u(DC6K=`G9OvXB;W'
    '!B)sxg1P)oQtFzn%a|>kVsrVZdeJS66qa*kY?tJPAVSDt0uZ8#k}=k3xRl5uC;$tS1@Lf<@BXN>VH*#hGV;imKY^hY%dXiv2M1`y'
    'u<^u3?Hw%>!A$TgamS=GGf&95GqGYSneDh1$};77wcKDprjb5TgedNBw>C$etn0|fkHY3*tHcA&H5%*1zK3|{BMfr?fF}49)|?AD'
    '0Sd_NBhM#6jIwrTaK!;sesvkkMw2hW%n{f70W5ZyUJ}UdrqI`!i~(u_VBMyG1l?L=j1MjE+@^CNC7`zC$KuHa1G*S3(wbWAM5eyc'
    'I+0D6X|nc@_U>t!UU^|dD~`z-t}A6UFW)U~iRG~Km3`RBeL54NLyYy8R9Pm*b1KOj4HBKFYGIg=fCs$nGQYU_)nksRZ!@ueIYzq*'
    'YKO@$4&|C<@R@b>PV3A`gKEy#onVFGP8Dw#K~i5s95cykgLxUX1hEBD%OjgeZ&>ZccT2uBjQ91WH2*cty$Z>lw;*pZwetqfQQF-e'
    'chNMs3^h?nBkduB^Jo@-jI7DF??_enHGCcgphCsjQpUsKJ*RMG<}Tbv&$VuXK>*41`r&~Os$>k83*Ak%@bAI`K=#C3)CskLV}hL+'
    'l$pwXPJDX%+;(J&d`(lAYeaK2zCZpAQu5*!ND)d9Z?wvh&j=jf7PoTSBnM+O!P%T=1G`FOojQY+PN;`hb>zySF%KOw(8;IiBKkk<'
    'vS)mR+Gzi~@m!uP+ZhFx6THf*VJ-_7@iTxfh6km}?NmlZR(&tAYpS&`qr?CsRtw7#PRy=0dJD0dri)FgP)6?gt3hj9mp5|zp=BX+'
    'lpf0|2zBL6kGD#sUfG4+0HC`^rAZ=&Q`WOJbVo8+r?SgGPbt|xmG~NFxXO^&r9QNLB)mCU6knQd{8ll~$NbBhZJA4yexTp8;+#~Z'
    'EZy#72Ld3~5=f!zgND#_s?y7%GA;?9LPn(%4Ki=)q+ObI>Z3pbklbc{>4`V##zV`jb71ra#i%Dl$_pE^<kGT%FMId6MV8}q`lU~b'
    '{G-d%L+Uzw3o?x&85<Mw0+F&Yjm*sSxO=7PoING3!dJ`MHpX!IqSCt12E%mth<(ldrGWV^v;xRCm^*W;bt%j&)quoLy9R3v;21YV'
    'g-BLA0!WIj_lwta1rYYP=n>3K!5SDa9=C09E7lZ_N@`%j<IA8oURpr}qGl%y1|iIAfICR}h=7KXU|~qV9LgVy?8{}E%2I>&z+y&i'
    'E3eFbHZo}Oe`@Z3*Q|nPU;9y(92B1Q6F4;o<7jd87-r1Z!Y@;zueM2*QNFm0Cn3VNCO~iy;z~5^)T4Srd!Ee-_RQG!T=+fR257(N'
    '1)`Bvq2OC?nyVwM{+X`ejg-w=1|u!INYqAO0#l8li20Wi1da`pnXkgLToyxJfIZEVlyH$9H-zA|kD^l2v{0HyPWZu5OG4}sITLVc'
    'u=mZC7h7borOj5|FSwS|iC;*DvYF~(wwgk5s5(Mxvv|#)>;Q-^wG&#-v1V<Jpl5N5H(~lvjr5~HTT<(5=JCzEP!YEw;H+Icl(l83'
    'wHaq1_O5f^2W?K0`l52>Tu9Cpk{i<Gq656V59^O8z*%P8>Ai9#MfW@OiwkSVooUWz`?yvfIZ<AxFbr|D^drM5^OjZZU=eMS%$m*#'
    'rUcGxL(3(gX?zkig^2AX)P^+mwMyn+L&+pTh|6xW4P(x41X2~V*R942WUjzy9ZIilaTd;x1_HyN1|KsQAJoo%3aR5N{&+KHaOM1q'
    '5E_Jbg6X}wj}xHNjIkJx)q&2P1ALy7penS%o@uubEA5D5)p{GkZr!TOPO);{fEUiX?3bAuv5uh3i_lQqN7ic{a>UIRnG4L(n4ZBo'
    'H`&h3csrzuP*=8QTYgk6hfzYnHr4Lm#Z=ZFCA^wILyykr)K?#bmqb159l{R;#)3v|GbFPlxiCPeKr_Ysb?MJPDTndGlgNV&c%QS5'
    'F?62)w$ypkKn?ZzqvCrM0N~Gd5Nwfu;*G98fJ)p{UDRh?*=vz4Zm_D5@>~q)aW&754sn<}auU1)l+x;St}cG3)JG7+0X+jmAV79@'
    'M$gZ$!CHzmd0%`cnZ92uyrITofT6Uu_hEQJQU4i>tk2K0ryUy(#2Trc85P%1Ul5GaP!nWVHw}Mvy=S!Fx6IGXzeS1!Wi+T{4zp6g'
    'Hjba<NEjkRAxFz5XoD>(5RcF%jbO1Jt)+S7wIZS=>b9Jc1oYe%%5jvtmJ#>tPY%#V)tU#c{N^3yFHm1u&fex}?Jd<^W{w$OG#f+5'
    '>Vwd7S|MXI0h@nr-uQFVe;iML%1^6QPB5YLDK|fD*HzGRkt-l$w{vxt;@~5KL4gR79^$lc3bzdUWAUvp-;2<B<`N)E3&<Hbc$=mi'
    'rLzUzu3#@+OfDSGlPN95oruto9le*;zHh>;pfWYnQ}IhXBjns~{g)x|zZ!;EjUv#sJSH5Lh9djc;{E-y)`nzA{LAw5`}mMhZQyH*'
    '=F!l-2lYL_A||UHtGKo(Hkk>_WS4=8pvo*)QX088YxvOALQ$W<HhFH@At6Mug=jcbp2^6t!j1CQrH4~R1DnwHXGSS^8RzFC!<JV1'
    'u56eds!=RSOe$-RfV0bvFI&+A6G`@{bP!9Is}Tt3DE*r_m8ET3+It75u#ko_^cB&r9!jcPHN4K4vwO(S!i;nfY7&eu0fbm%Puu(-'
    '3;NN?9L9%dG!p)Y=~vW0@r#hRmjWw1`#cuTN6`6fl;_dyX|Sho-^WR&_`UU`_UHs1nHmxa0{JiI8#J-v#of{)h6Z=Xv3yqp(wUa&'
    'bK4Y{;yMT4p&p_KwPRuqDYeo*vc2zy+ZW^Eev&J46M>?8+5v_pOwycPLusKQBUaK&;3?^XQc%04YzcE5=Gf2G<uS-|jWqZvFtvEV'
    '1;o;boiF%Tr#fsRS`PU1BYZj_J#_0`*AFXc&TzC`XGzko6vjrPON&2^rs?B(8kc!$4YgxNWa4Nb6(B1W5`xm*3cBF{u~tX8eT>ZZ'
    'Sa>EsYUK}r^FGtm#s-hRAtBQ7!syJR>@%maVKjYxX+FDGH&aF<I(KE`S%@f~^1;&<Um$4>A~@L^hBRSWOZmaHs1|qt)@#1Y%S)hs'
    'y>-(vI_qocJlm6SJB0fn5(?5`v2ufZh9lXUn7dngp25?E%kBD<&f0n~72(AjS4}R`2UMTN9=fR3iL=|G8uinOB^X5-tg6@ndb}}%'
    '*yBNvD%PJIJ{SEItIjc?$}ZE3hZ+=Kk4IE02s{Zx_}tv&WCfd}LC+iXSkO5=$Q9Gd%5IA*Z>X1*F^B*EgGw|hn99Eq(T=`MoG+dn'
    'wGGqTMP+6XSPE{(J@FaEkZ=tM^cg>QGWCW1ESDn);A+$@pk(8S%vSF*Qqmm)c#zUh<u1SKo(lCiZ3_3RCyvxT+Sy@Y6>~!7`~-3j'
    'o$&Nt>e=0&N%0&G-BL0z_r26mAj>lj=Xf-YC^^@k+?Q(W(Gd$Oy$T0b{i4$WO~2HCkI2tq4w9hI+ruIt3D;2b34s}SC-}boM)yu1'
    'djHhqFnMR@V3s=X*{(<wPWKVwJxU!2av62tuVtv8SPRt{_NVKjjGyNtSNiv?%kXJR0U;BPfya+W*RQd-UUt<kZSQFG3QzM)%ZJ`y'
    ';z~MZhwRptxH7A(p|)0)DTmco;yxeaykss$>vXc!apui3Hvmb)vr(XJE;(Os;1Jc*1lsvdwjly{Rk47KIIf=X1T+Mxao2vZ=xYnP'
    'PA}FW%#W5nQxkYTMX{SwO)oM4SKl4UD{-=dM`rF0IV;vn;Lc`3^ba|#`s!MuHommOT2YSQ-AMHTIL1DkW_{LZu*d!MWaW0(p%AMD'
    '48gF9bj2hUwpZO}24kNien-}(pXzL#!p}1JR`af^&jW8mg1KHk_Rfj940ua30UFlL6UednU*|{ndWEX=0@lb5_U=GCLuCTc7d41r'
    'chlDBoE;@O!`8cBX`%H#HMF`o56mY+`)Xb!hvB>Xx4YLN0|YT$)`mu^hiI(`Wn_MV;t7bQ4cZw*?Tp1esQlMB_WAEib~+g2vdd7G'
    '(vT_A-eYW=4P*Bu&d9yfkHptyjPIwo1Mo(;toMa`O2_8Gz8H$L$fTI?JD&uU^`+N&QjJTZqMr#jThjr_%RH^c9y%efx}xK;`Z878'
    'YMs}4bzh4=%pvxa9q2j<ae)hNou0v8^g(xn;wf;Z{tVZbk60YO;9(E1H}dh!>kw-UB)5XCY4DPc33I%%+}+p2eY}$j;A%R*oJGPP'
    '1VM{WU_kHDmxXgFOsN1bzwFn?EW_Z*++v^A<;Zk-L4`}oYyTMZ8Xg1IYS#1kk6_qmMt*+OMNfDVy%mXBnApIt2R$w0N$g5wz-Ds?'
    '7hu?N4y+KU@Oe7-X-l61h_M{UzJ7Q8;*&)QP(n3dhQQd6t7CcbAzO@2{s&t;#3JaPo>VJuqd;s54bK#0+wa($>!91}ocHzY9=t<u'
    '!~0m<rdIAgYu0h3tpovJzo6KlG`vZ%ZwxtN_F^fqZVm7N-iFW}pcWwLM(|5+Iak=lQ<$XOujtuaTsi?`A+2_J_yuPP?=puR0tZnc'
    'IW5@#j7O8-_ucaBpTeU}nm0D970RZ@^*~P8P2->)ANAP*2dBD)FG8)Ad5kfiSq}*^799w|9C}%t5}%Am0P@*ZN<lb;40^^On2f!Z'
    'b{5uRbq+Qg0A3oW!XL-J!pqrZTcDrV^TlC7WTfz0dC|al5NY)ns%KyaHLcvl!#UZCM(osZAg@0-cQPqGJ5WG+J%v1YCF|k;*fC#)'
    'QIy%NYpHc<5y0fu)-mp!QId&;b@>+M&K6-1C^e6{o9)@wEOq(MN-SJ7h9%*fsnFta?RfqtKxq3YpA~dY&uiJ_4;jZDf@hO!C;LDr'
    '@J<xq24fDv2$93{TD}L6@#)$KntgcE4mReO&smDbp<;MnVffjE8z4a?qGOUz=iJ(-Sx>d?0Zsc_s1ZJ@KeMd)l(F?>)2XW=)-L(h'
    'Y=GLq$O2+h*N%(JKpYXiE|qa2Z1S_U)27D)CZ^FYKc(8yIPlOGIm}XZ+Q<MRh}BT2eiI+ByAv4UCE81y7be=*N660HMyCYAArD&i'
    'mm~#E;su+QBqGp+hV2+Y671Uu>n-oPs6TZXyoM?;^_gCGmBKOp^cw}|-)N{35_j8EAgJTu2bwETaB-Bznm=4LrGSShcfwt%zY#bC'
    'i?7>PP3hLcR#c<!2;gyj=z}hjpL1vT#)8{tNZ}u~2vpl%@B2+lYUiuXVAgzmNR0?wH4kkgKP0!6FL==LE|%NBT#({L3S>wUX=>k3'
    '(sfSF>olnHqaf7UYopu5y$Rd%>|6vDFk6$GIRMW}muGx%8AyuPwl--s{WY=oqjKByu$gXrJw%i9O^~R2VIGM5M==>-0Li{BjTN#l'
    '1+&~QMlO<ph>oG?WKVG`6S3aoRicJ|@6ffsyL1<LpV!<-#~f}>tD@uJh0i88qlbB!+q>ckVl2_Kez$>H<m22}W*l|T1<+0TP<4^;'
    'JHQ$82o##oFhy^X-hYV@s)O8Uqro${i0E)19mog$jzSXG;rW{lM1n*w4*uM6=H=ZtU!`>w?KH~KlyE^3L!xd(c*Fx?3b>P^+)c2m'
    'u}0lITTw>%kSF|;!Wpe#TjKc&N`HXh7F}ggkaVQC^8wv{6`X|zJ`RYNq8c!VV`vR4BkDWC@DE};r4?i}LXX|VXWA+=!%X~-QB}q^'
    'qFoJ#N5VnZq&1GViUjIJaQEHGz|Q*DhjI(s*neZAmISW%nuwV9oxP%$A)iO%-3i_Vmk4^n?ur2QAJSB?i!o)x&QY{sp+S_4`+%R;'
    'jl$j}w5%>>%Y!6OK44ysZjqOfWomjkPVd!p$Sm_C5#HWI3{h_|AS^7aP;Gm)7Zdnw%4n)k_yhX46V4*3Rtnxx%c!{Buj+EHcv3fB'
    'Gol!Lg#gn}ENKBhY1_9Vi?iN!>Wyk>M*kWpF{`J%-(nVzhyESaGoS-P*Q)!eWggy|yCoZIpFl>c9};k?g<1!I?;?RARhXe<sUMqp'
    'V$$BUQ`bPEK}kpToSSBPJ{IE)oncmTy>eL0z;nJ=Z3N!FqQ>^%Z~S^XPm2zneZlta<6NA1yQ}NVRa|zZJR08V`Cu@tNRJcTCWtQY'
    'p!(y_nWwjtZ{q5skVXWd?%Uq=Iv91BMO-%CX2rNi6+VwMqKI8T{_?1~_T<95JOtl)uFq64eZ9ex>9&r@=ri`z(3+C-X{>35(mj_?'
    '_#)qW2%!N&*LbDWUe$!b7-W1DYih5PokBv_7B>?2cl+OkLrTibaMd}T;>_!c_mK>9)t)CCR!s3lbv@34_{`snb{!|Tu;PlbZ9vAn'
    'm%Avvsk8-aB>~!3k(b&sdKll#v(Ld};I>X7^|j#aWoGsf4|room$`SnERtzg@4esI3YBXkoQ!)@cJi&8$1sa4+1l;)%SL|qpIY7<'
    'o^;>dg2AF?ap?8mpj!1&$7E)**>v2OU`s*!I&++LzHHy|lxz<qn9;rq_L8c_h+u>pq&AsBK0w$RSBrOx!_?qA5B(}-it!^^AZXR='
    '@l!J&6CT+^S$A#|7-yw}SKHuUQ>e?&8ChX?_DkcG=_Cd->H&x48XX{dg|Y=T-8kToho~!FXS>rOGRiRkqjz`pBAqJSe6y?n$cH4B'
    'xSZhT#I!pTG;SLadZ65qeM;-0z!RUxucb3(D5A|c`fK4+`g7GJbm$E4DjGchr@f==kq>Yr3&OLw>qiKu<}2Y>Ctl7#_aCJ^^=Myj'
    'E=x7r*%Fl9spgHTmMN-J8SLS3nEiP~QPGekaL897x?umVLry%Kl2*Aw8fKs1GAiM4qs>6_<}Ikh^y_eq`fedu^yD$$_sgRE?qbSS'
    '{L|rhL<W$2??DfEGYr{xTm?SFWFJ|871qXn#;}xW6hh&QGF^#8w-Y!ZnrZdF$?{EHz`X$M?%Ccq*vIBj9HZgO2oyAK4OhSNAww!!'
    'kKkTCNUCdE0x$<DgE>c{0tMmHJ6^AYS@?@#gc6y|RTN&E@RX-SJZ2~wIjB<onXBQ`#otMZCm4Bx7aBL9`cAbmLH9kij0XrlN2l>j'
    'AsXT8xhi3PsJhK5W1Kvvj9<?5lON@&d5p)exQ(GOR6gQ+YRVAIsIWWSb+vM{GekPZy?P#c#+R|bvBxUCBr4*LqMfm?4ozSW)`cD5'
    'PS0?aK2nmunzaC6CtRYZ(JkVeY2i<EirnmX;)nqMjvLi`#ja~j{~5GS&69EpxI*HsS&Zyb@!l&VF_H=V#qB7fULNP}l1Yc$9DGJc'
    '50v8CC-_caz-R$MuvKwnT6~rNuK)v2-fJ=fB*3I~Z`|VN?y3wV>Rs;^u+OYtwmd-iSacz$S_%v3QQ5aRX%yn^wnmmBIDTw<_|TBt'
    'MFzM+-JR&tvL;v%(SQ!Zfv4jYM$xv7MD$E~8N$wv%fkfg?~@?C^tSS!rK8aQLowqsv*P&n&H#!Bs9KNHvB+9AWvZ<f=Eb+%`Z!&2'
    '!o1@}_@iMi&}tk!Nv-0~xa_{47u;BOb0pNsj!B#L(PZO+&XoHC#XkquccN1G&qqQtZ>)k|Y!6ZeRt3?U*UICt#6p<-92A=S^vIcS'
    'xg;m9LF8nclT4(QnHzXgxK-o$HS##zwz2~vz34s^h-ajh@_l<e+++@zw97C;MyTW!c61MQ872SNd;RVprYAMH@9O+?loq0jZORmB'
    'UR>lDbK9luZWf!jcuPhAiLGNC$K*UN5Rk`LtPyi)K7`~S)OY4Ysf}m->>L(GtA@O|Q9Op5V$<<ksJg_>S6k#Lbo;6s*lXp-otR~&'
    'tFdaU=LfRKd4R9vfYysH{{rMfIaA>ZNtnY{JCA;+l>BH3X-V}zhT43VR5+icjBw=NJx>sXCKONP-S1bUqzS+1?C#J*#YJfEXHU1s'
    '^ycLSrd|vIs2@&f$-)_G=aM}uOdjWUIpcstZIfI@Pb1|B%9q@QT|G&QdFUvmf-cr^kb_+hI&0q8x**g|bpz!q`M$tj*<Lf+gKnGK'
    'Y!Ht?rWruuxD^UOl+V`9c5vl{{tIXzN$oB}Y6+Y_?%wZhVvL47ty6p10fwA%dAjAn95&-sg5>yQ`h|kzm;eHPk<0qHU2*e8ZKyiC'
    '8As*Esq7*Ef#VuH;jBQC+K}N{L4PtH!sm{haJMsVpS0!~1KvCLHCx~$swnT$9j;Q54__dF2q>yRMfYG=ta#=kSoEqCr6;}zh}PKM'
    '=4cp9qBl|;EjyO@B+R*io5AK(E=w9|@jxCn%_XVg7Y-0uJiwX>D%8<yIqt_IM`7lU{dwz+Kc-QKiP)Z8b03U8XrOihG{D2yuENmL'
    'akb{cBP{lMwpTi1z3X55pi4tyDAS)E&q^il78%zQ5FF;yJd{u<hF-z>YshfQ9Mn=G=I)!)g_(^gtS>#3_9W*>Ah>+KiMY%~!(Ul{'
    'N$HnpY9c0Q9lr)*dIa1r6#3__F?pGJ(Rt9XIkdx9Nc<@5(NwK7@6&rgR}Q1pV>Rcr%?XC02X3thIEokrsv1(-C|e|H4#U1DCYQ$U'
    ';U(w9+DI(4&v=wkU~JwRxllAiK<+~meq@lMs2iKWD{1G=Q%s9xp^C#xak>JfRlr=i<RcdG@l}KAMifMOND1fO8U$tB`~7Bfr!oA)'
    '9dxVW<Gk^YK{Fe|pC%vm&h+Q|tj-jO{>Z6^WF!m&+z{D&Sq8+q=gF6IkNt3Zf1c<GJjmO`T8MWPxbOB4?fpf5zcyq#enp49TRWTG'
    '`xfXVinEFhju!XU0!l)WGPsiP0B-G2JY*C1UN(ja+mGllRJmAU4K;)CUz8_C$}S51_oH?FCuE*OnjVvback&2A1#?d*JZj1xQDX>'
    'zZ9w9>@?gZCUc#Vy=CE^((CAsq6on_u@TXRscv*J{*!FD?y6{lWjD~zZD`(KP7Uafm4_}xUmf&aSexqtOfK6QZ~eF9Dj?kM9e^U9'
    ';Fsu{?nE3I*Q<=K{t2IT+Payk4E?$Uw_?!}!<N29x1H#s>P06uOlVRj5%Z?^Qr@65FmD}=h-6WbNn{B0C|>Bm;vCgc{`6rEA0ia`'
    '9BBAIHO=--P5)9~sPi6TwM6MS)j*nVn%LM$yzP-C)6~cO(b-ih`rQw|$_YiaBxmVH%n*e5$wZ?J*>xjBjPZ&vL1F{tY(FJ3eXsdA'
    'I_l|F-Ry#94D7!%*T5I6ZeN}(%<!=_1HE1G&cXSo8zbqv^Qk9;*K$Jv-tkBxdTat^MF*-TC47V!Z|)#fz9i}Th095UuMP%!RfGXi'
    'u)F{DE81*Dwg>f<+Q<=}qJHWZ{8MRL>CHfGwkMtcdZSC(;JGgTJ}c=4=6|jdc#-Nd;q;s8O)`*v5EPPO&$(|it7?*_G;slmLQK<V'
    'qwVTDvIRM(9%k`&7Am(2kezfiG!P_Xuj`NLWYDIAMK0<^p2aXd;K76yrHkq!32p<<aOsMtfos;dxIjvFT#M?10vXAB)V8KH<Q%Wa'
    'a)m1V^fT)Mcid}?0p<`H@3^I(qK47xgd2l4#+kg-K1T4yJb;*PDG60j{iypneJq*kDvqS;$N`!Zze0+CSeWFLAZvMm&#`-ja+TUs'
    '@R@&GEwqH{;sbqa#J-8A9W`A;=E4R9Db|xV0yH4dq4R=rLOMn39T`M?n?#d7ASey*YGUA~0i)wf9`BO7M}YMk#9kEZF{wjM6&3}q'
    'MF$}acfg0D%y-y5ah<b2KhY0)oRuBxXvI&i<z&oDlTRUwo+ZcK{|DDOW-m9wPM2+JRt)Uxjqorh^>Wz|AW<~cNa^{XBeAf7#N!&t'
    'vZ1vPB|JUr$3!f4IYbp;#y49hU%@<=Ua0b>M@DDs@2odB>mU{D+Q6j!mzUZ*4?F+W3@|NUP7%%4VRxP(ZCDxPKAY?8K_-*VyVTgO'
    'nSVLM72#qD>7Y4hDMT-LJ3C|%U=8i;MH*~QTiAYd<5|A1RTW`f6`D)WWe9mQtcSiJ!moSmR)$C3%Tj{FpD~`>=5=MW?9L?&gXmQ)'
    'vv9{hhLu9>nn&&$QXxdF7D=MS7InxjwAI6KVTfJE3Ki25Um?ouqSG6n;v)}cJ7_QgWU*nM?XTC4qmKwA>_4zJT)(dDqg|wK093Jp'
    'wCSX=1?*jL{CP`?;`q>#@4(irx7=RrrIE=HUn3ABK*WpVM%Q%SegDv?T76l+5(j|_z)<z<%!$86DTT)HHYz)X#4TJo?$IHKAF;h>'
    'M3`OzfLqV)5+1h{#(&mSBOinwPD$om9-{68nTUt{^yKC8)<WX#9ikiX1Gm(;haiwrKYQZYcRRibke+lN=RDeU58cr1rWx+_S|g2%'
    '5s(u;sw15XF%l<a6~0-1Cz_24&E>G|sM#3YF{~BDpbZ**QpH0+4l$egY?=E<3kg48k%D0D#F8Z8_XJz7ByX6H+oC3nJ+0`Rn?h7h'
    'A&x;1K7;q}8>e0L9kxrSwp1+-(5FA`IW#~r4DD9?-Bl|`<*GC8KRA8G3oGjva-qxrEj;^Evc7FLhVFduR|VT|034z2lwK^WW3w=S'
    '{kC0$OS;3Ys%9?%EHon8K<>dzA8^O+sNKpmD`yv!)(jrc#8(2BstJ-|$@pd~@kyQp04u8QtVK6V9*(6u)ybaIcITtD^q*%`92PuI'
    'Ht|t^yvCI7w63Huvjd{{$jOPL4&$$uh^*16>~?>?zEaj4y`~@TzU9#^kVk*@8frv;+f)!p4V$}gTKXXPDf-qm&#~?9{bSawS;(4j'
    '2q#c_DVtXmblRPtxVmP`n7U(@?`}}<B>R4E!J3vQ<e>k!&xtR*-dE&<N?$t-Fzn9!GnOXrRtjF}D=e)i6i=@Y5Ppq2A56Tgz@m|o'
    '3hz{1Vz=t=a!H36*ET7|UGu+Y#P<q?={$jgAHi|?nxiXOZyL()b3wz`Vmyh$Y0rT)o=U@-^P7T}eANUp059sx$xR*axzBucINyPI'
    '7B!ReMns2}4+1W!5vwOo0<R$VRZmv$$my_=?@IH|xD$QI3Ou4wZ(@Q6Sh4M%yCE>65k7hF1sg=;(2>xuo(;V~%?hmvsT|vtaFZdP'
    '$=rJnkWvWn1)%3WeWM{+vd9Nk^&f}2(bpXl2t9-|JUYxyV{ZWPPOQ*qbRo=aX98v_5X?w69Nw$1cg{p<P7Oemihz>v+grT%3x^-Q'
    'O0OU*0CRn;dd>QkhNMgnn&{~7l9ciBCqZ+$NYJXW+tK=-^~?=r%d*S&Bs_Z`JwK#})y+lmd1tF<4)Tqp6G`~|!@-&PO`&Cgk{I^Y'
    'fdktqG-rG9k-6ZCn*`{w8u2L2iiv=QJZ9SQG+o36vfE&C4jYp3m7|FcVnN4V!CX$WZ&=dcMl;0qt4c1k>&NY-`Xg`g_@;n~fiNZ='
    'M5S3WBKH26A&}r>wtpD_Q*nF+>2g-_|4O@treg2|>cP5LhBd=nzD~!9Ov-&puGgmzp0w8T9BL2eo#e#R!r)u-MTVl(Wsx)MTx|Ws'
    'T}Xxb5wofCAVDAk7tJCJ*{?X43~T}*cVwq-695LF0|J(=xD-$FeHydHf{6j^u1SCdTRlJ~oRrl<9AQzTVc6Zh=El$RrMs?BxBA|3'
    'D6^=%vvwS%GW5k8l(Z>EZpWg3-Sl1ZwTl@<7~X91v?gHm<(Ei^GKB^ICFS!h;*1RWT+zkyz|Y!G%KxL=#zfGW49EXeJ^hA1q?eJE'
    '$6t?GBS($$$!})t9|wF4U)<DWS>J)`vV#|lx49&<Iks&OL#T%G)MMC2gvh3Qol^x2v6V3(1e{w~->K<tLLuubFpt9W)=tW9vT~wF'
    'oeknRpckYmm8a&9h9HMi7zq}T`461(-#L+%xJ3PHaCoKoVfx1TXT-LwR6y+xncH^(ydzTc0bY5FS}6e!6_!;IJYyy(88@rHruL1g'
    'qNB%>BcyxtM^Dq!*W_RY*z@D-qR}^3$3$Hbe58o>zjt&{8_w?YZ%QVSPit!D1oG_U{{(nxhji;%)7ur`&(Uqf<nLVbfD(Q}gSTc<'
    'lU&xFrAuGUMJy_VdM-FR)rz8o+)@hkC8vhYjg?=v!CnIaGygK?`W>nP3B^x_@+Ae{fq4w{QbkqBKU`MJ&&k{%6aw)}aYzDp_}z{U'
    'VIt#}Cq^FhZtnVRt<Zf`$ap&Z%2g>z=qR%7Pbn8pntUW8T}xo}$lvkF*xOJ!WS1EC6QUP_!n@l?=c`?%V|@$qaU>`86m_3f#OeA?'
    'XWBbXPM%)Y#5pwf^>(Xk;HEn>f$vfE6zKOHCyk(bAMQ^FbX3{qOQ83zv(4Q9>Cw)zb7x@n6-o#^1Wk!n)=9&s&y1Re=VeI&b;_gJ'
    '9vyL(tT5O0NW~@t*A%8JwJlBo{XZMA&oTBEp|2A;Iz$P7IKamBYtimfl>1_#^}zf9ISBS0su>C_^u(>`PI?ZXbWl$9g4`Y9A^XQ%'
    '+laaPcbpjCsmQ9j<xOy5^5ujZDY&Thu$ieMxfS-?_%&lFuq3ZI6>D_q@zQXpq(H4<<HqmyKyh10k=OGqlX4@ZH?ha-fK5rKLlj=*'
    '*onhi19^n@PbN4Uc^6?F0_F)r$qox9!R?%^A8MQYKoF;BWC6VPUC|mFNi^Z9twO|~v$s=w#xel!_32qYvnxn@88A@xXTG&~x$a)$'
    '&)|M!!5Mdj`oH3cHmR8L&XV06VfRh;cs0YN_OD(*xCc{*`UStYsdFB=oFei|m(F*?p;=z`j#CJIcNHrUqt*9e6j-KoF)un36aDQi'
    '+k%~D{<F{amKNKqo%ot_0l7kjs8$!|N$EIR_oYG<w2;-8cw=Ywxb6zk{L`^ht~hst481hRX#Ji6Yb?~PweyTGF-ku6%hpfNtu1XR'
    '75Lnu(FZG6rq7jid|{qM@w}sotRM9D>v~IhDN&aK{rs50SQO`kZ6!=mxb&$*=@K15*Ghf&8zWe*RfTrj0XuK;0Z&_s%KWwyo;%&W'
    'U@MYl_3iKXv2Y(!Ew)W7h%BaCt;Uh)B_p#W$)&BRJid~S_sb#ox{<J)SuL6SJb_S^*~l5s1?c6vHKu8?5ESho5cfLw_TnbTKMKL%'
    '7!j{KlC@;;w-as$x@2)lyZ%|!P^$j;JKpxVvJ4-bJ_j*N!q?P}(a&jn;2`<komy5z0ev<2cx0d4!Pc=)IYh9^Pyxfo#$4B*Tz|UW'
    'Eio@0V%bmlc_$$31nZH8sg!d^>%KYiJ}oz{{kG_u>9;G3?sQ=IgEdDC=H7v30-Fy?b!4~5^Ri2&gpNO?Ixrp=yo6%-h=}V2jmsf`'
    'J|1tm`w>)Og&4~OmdC7CpY|KQMSxNGi_CdP>w-OgLGc%G)=^JYyzAP)SKoeubaam+9!G=uB-IpM*abw>Gg!>J42A}Z{(!?p0C8?$'
    ';Q5kynsJQzNx>Gh@TH2UfDBa35H#aTwc#hbe*_^&47ZgT;{z@ETHu1fcT%~D+v2=0HgLIE_wcUK>Qce(v{SyoU5QlrcCsm-(*Lqt'
    '+1EVrC~Qd5Ibp(O8jvvrn7pal*R~e<p3P%24|Vwj+kv17GnpT)7k}Z3)mW`{vB~^$pnZP%pN?|g?Z~IFwnmMpEF%h>quZVOov{D;'
    '^M|@d-u9yTt0`+I#2jg!@zj$gZ((iI=ree*fL<CiPB2Ovg|^c9vuzXTiij(RqGRVlKGB_w+~K$+a|HC~!lrR@UeKcXwB;Yxp!Emx'
    'zB;(ANWQ<wPrapr=Ol5e??#hTI$&4%(zKQ%N)uQdHYyM`3-8HF#Wv4*e_jo-zHGs433lH3<|wdqA2*uIlLa63jW=ScDK_l{5ggVU'
    '_=bqM;V|0y=TN&V!1H#hT-arOo~-I*)0bvP2=j$tWeT!nw+&DF^<A^act&ee%~d2gFUSZ|pRFDixDGZXo#Mere}l{W8vBps3?SWq'
    'u}`^*xF8|5J?zy}OO8i?pJg=Hgr3*?P1>v{a>@Q<(KrE*h>x%Ey2N(}@YwL2TdWS#Im2xGRs6x8H*ccalRT~|kg^-NJmy~HHuefq'
    'whiL>ux2g$hTPC3+Z;U;(OA_{Plu<(Zh<=P{-<ze2Jt`N?fRMflAuFzXAPeOvs56!&!?<v{`~`<t{ciPn&9Pxl1}yerbBT!)^W&>'
    'V>=Tv7E~j5^Q@ixRVEfOUY&5{m6$*Ku~ig=m^ASX!Q@q=y1TqtL&qX+q}e6Dg`_^VeO_ey=vyq=9keeykPZH<1~hQj=GJ_&0=jq3'
    '6a@C7d?X3`=#ULsC_K6Q=>&aC8yeMEuL*Mvqc$aAyk^)=OF&@!ZfV|xLIXf{`usPkeAWQQ3F<5_K;IxI+JavQC2P?9Z$hA^-7SXz'
    'fqeeo$IQhMPgjM<1wF`Hraw$1cr}>(an3<%nPP0gDd#EhUQ#V9kj<@t?C2KlAYykoBaFWMd|{84(iwLFfCt(`+Wbk9dND8jN)1k7'
    'hKOp^d&*G!k;6>Q>CJ&JBO8c>Il*12G9zv=77daBjxUcO!*MJ8#O!uaQtO;8*}!oW`WhQjP=)~YD=q5fqgnD96Rsis0+aki=XrKq'
    'tsvid0N4&8(f`q~PDx3yash`ruFZk{cQs0(<pcnFDqrML4ZSJ2?Cq#EC+>^B2K0t9OfgsegU>*b6w4B~Od^x`nhvh;b|nr^v8;<H'
    'K+4v=FjkcPit2%AkShP5JBB<&bt79Weo}s;S=7eI;69vfHC6iktJmC2a4mSWVfmHW?1ae2)ai}i7W3y$Z}699i@PWNw;7o)!1U3c'
    'Wy^|?+JgTeV44{9@Awo5udw<0wfC(4K7ZIPsp_?|FVz-lfk|!x9x@UFa1(fkN<ag6PvXt~K$#yF@)9!DOD0hLsCx1Vv~<}*cOR4W'
    'NGeZMNm{u6eI1>}%NsTR)v2?Xe05l;M6(sgtniz6Egg=O%h~MyxMjq1ZlIT>5?+;1!fdf}aOXnbC#a}fi7pZ_U|f;@zPqRKGzzLq'
    '6}+e`A4QC~?J5g+F<ipYJjCg98(vEO$})XO!1)@ysW78E|0BuEV=*uN=F0p%ShF7zn}%)v*WU&$Ph4BYC0)A1VHxkI(B<1s2KIqU'
    'J?uGN{<q)%1N33_jvgNf(4qryvZG$LB>0<Zfd$mBFS%8=9=+`UcN_f>82k?U?P^xSWOD;IhtS>`N%uGJ5E9TN$+ENmnt@$y%eXwC'
    'kEBjY<+_1EF>(iFZFYG3Kp9@}o!fT`_=ZC'
)

if __name__ == '__main__':
    main()
