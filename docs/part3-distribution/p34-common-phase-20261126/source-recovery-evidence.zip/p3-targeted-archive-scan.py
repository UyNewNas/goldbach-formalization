#!/usr/bin/env python3
"""One-target P3 archive scan. Use a fresh --out directory inside /workspace.

The embedded manifest is derived from p3-archive-dedup.json. This adapts its
companion targeted-archive-scan.py's check and visit rules without executing
that script's local inventory. There is no workspace traversal or network use.
"""
import argparse
import base64
import binascii
import bz2
from collections import Counter
from contextlib import contextmanager
import gzip
import hashlib
import io
import json
import lzma
import os
from pathlib import Path
import re
import resource
import signal
import stat
import struct
import subprocess
import tarfile
import tempfile
import time
import zipfile
import zlib


MIB = 1024 * 1024
CHUNK = 256 * 1024
CONTAINER_LIMIT = 150_000_000
EXPANDED_LIMIT = 2 * 1024 * MIB
TEMP_LIMIT = 384 * MIB
PYTHON_AS_LIMIT = 640 * MIB
GIT_AS_LIMIT = 256 * MIB
GIT_BUNDLE_LIMIT = 24 * MIB
GIT_OUTPUT_LIMIT = 8 * MIB
GIT_FILE_LIMIT = GIT_BUNDLE_LIMIT + MIB
MAX_GIT_OBJECTS = 20_000
MAX_MEMBERS = 50_000
MAX_ZIP_INDEX = 12 * MIB
MAX_JSON = 24 * MIB
MAX_JSONL_RECORD = 8 * MIB
MAX_JSON_ENCODING = 16 * MIB
MAX_DEPTH = 10
MAX_ISSUES = 10_000
MAX_CANDIDATES = 10_000
MAX_LABEL = 4096
TARGET_NAME = 'originalmediumphysicale3block'
UNSUPPORTED = ('.tar.zst', '.zst', '.rar', '.7z', '.lz4', '.zstd', '.lzip', '.lz', '.z')
SUPPORTED = ('.zip', '.raw', '.tgz', '.tar', '.gz', '.xz', '.b64', '.base64',
             '.bz2', '.bundle', '.json', '.jsonl', '.ndjson', '.tbz2') + UNSUPPORTED
B64_SPACE = re.compile(rb'\s+')
B64_TOKEN = re.compile(rb'[A-Za-z0-9+/_-]+={0,2}\Z')
HEX = re.compile(rb'[0-9a-fA-F]+\Z')
ENCODED_WORD = re.compile(r'(^|[_-])(b64|base64|hex)([_-]|$)', re.I)


class CoverageError(Exception):
    def __init__(self, kind, detail, stop=False):
        super().__init__(detail)
        self.kind = kind
        self.stop = stop
        self.location = None


class Found(Exception):
    pass


class JsonObject(list):
    """Preserve values under duplicate keys when examining structured evidence."""


def bounded(value, limit, kind):
    if value > limit:
        raise CoverageError(kind, f'{value} bytes or entries exceed limit {limit}')


def digest(data):
    return hashlib.sha256(data).hexdigest()


def signature(head, name):
    name = name.lower()
    if name.endswith(('.b64', '.base64')):
        return 'base64'
    if head.startswith((b'# v2 git bundle', b'# v3 git bundle')):
        return 'bundle'
    if head.startswith((b'PK\x03\x04', b'PK\x05\x06', b'PK\x07\x08')) or name.endswith('.zip'):
        return 'zip'
    if head.startswith(b'\x1f\x8b'):
        return 'gzip'
    if head.startswith(b'\xfd7zXZ\x00'):
        return 'xz'
    if head.startswith(b'BZh'):
        return 'bzip2'
    if head[257:262] == b'ustar' or name.endswith('.tar'):
        return 'tar'
    if name.endswith(('.jsonl', '.ndjson')):
        return 'jsonl'
    if name.endswith('.json') or head.lstrip().startswith((b'{', b'[')):
        return 'json'
    if name.endswith(UNSUPPORTED) or head.startswith((b'\x28\xb5\x2f\xfd', b'7z\xbc\xaf\x27\x1c', b'Rar!', b'\x04\x22\x4d\x18')):
        return 'unsupported_codec'
    if name.endswith(('.gz', '.tgz', '.xz', '.bz2', '.tbz2', '.bundle')):
        return 'invalid_wrapper'
    return None


def receipt_label(label):
    if len(label) > MAX_LABEL:
        return label[:MAX_LABEL] + '@label-sha256:' + digest(label.encode(errors='surrogatepass'))
    return label


def name_matches(label):
    # Same basename test as the local visit/check pair.
    return TARGET_NAME in label.rsplit('!', 1)[-1].rsplit('/', 1)[-1].lower()


def should_visit(name, size, target_size):
    return size == target_size or TARGET_NAME in name.lower() or name.lower().endswith(SUPPORTED)


class Scanner:
    def __init__(self, manifest, out, seconds, expanded_limit):
        self.manifest = manifest
        self.out = out
        self.target = manifest['target']
        self.target_size = self.target['bytes']
        self.known = set(manifest['known_inspected_sha256'])
        self.deadline = time.monotonic() + seconds
        self.expanded_limit = expanded_limit
        self.expanded = 0
        self.temporary_bytes = 0
        self.temporary_high_water = 0
        self.counts = Counter()
        self.seen = {}
        self.limits = []
        self.size_candidates = []
        self.same_name = []
        self.exact = []
        self.outer = []

    def charge(self, count):
        if count > self.expanded_limit - self.expanded:
            raise CoverageError('expanded_bytes', f'cumulative expansion exceeded {self.expanded_limit} bytes', stop=True)
        self.expanded += count

    def reserve(self, count):
        bounded(self.temporary_bytes + count, TEMP_LIMIT, 'temporary_disk')
        self.temporary_bytes += count
        self.temporary_high_water = max(self.temporary_high_water, self.temporary_bytes)

    def time_left(self):
        remaining = self.deadline - time.monotonic()
        if remaining <= 0:
            raise CoverageError('deadline', 'internal wall-clock deadline reached', stop=True)
        return remaining

    def limit(self, label, kind, detail):
        self.limits.append(dict(location=receipt_label(label), kind=kind, detail=str(detail)[:MAX_LABEL]))
        if len(self.limits) >= MAX_ISSUES:
            raise CoverageError('coverage_receipt_count', f'limit of {MAX_ISSUES} recorded coverage events reached', stop=True)

    @contextmanager
    def snapshot(self, chunks, expanded):
        size = 0
        sha = hashlib.sha256()
        with tempfile.TemporaryFile(dir=self.out) as spool:
            try:
                for chunk in chunks:
                    self.time_left()
                    bounded(size + len(chunk), CONTAINER_LIMIT, 'container_bytes')
                    if expanded:
                        self.charge(len(chunk))
                    self.reserve(len(chunk))
                    size += len(chunk)
                    spool.write(chunk)
                    sha.update(chunk)
                spool.seek(0)
                yield spool, size, sha.hexdigest()
            finally:
                self.temporary_bytes -= size

    def check(self, label, stream, size, sha):
        self.counts['payloads_examined'] += 1
        named = name_matches(label)
        if size != self.target_size and not named:
            return
        if len(self.size_candidates) + len(self.same_name) >= MAX_CANDIDATES:
            raise CoverageError('candidate_receipt_count', f'limit of {MAX_CANDIDATES} candidate receipts reached', stop=True)
        row = dict(location=receipt_label(label), bytes=size, sha256=sha, exact_match=size == self.target_size and sha == self.target['sha256'])
        if size == self.target_size:
            self.counts['size_filtered_hashes'] += 1
            self.size_candidates.append(row)
        if named:
            self.same_name.append(row)
        if row['exact_match']:
            stream.seek(0)
            original = stream.read(self.target_size + 1)
            if len(original) != self.target_size or digest(original) != sha:
                raise CoverageError('exact_bytes_recheck', 'candidate bytes changed during final check')
            with (self.out / (self.target['module'].rsplit('.', 1)[-1] + '.lean')).open('xb') as output:
                output.write(original)
            self.exact.append(row)
            raise Found

    def visit_stream(self, label, stream, depth, expected_size=None):
        try:
            if expected_size is not None:
                bounded(expected_size, CONTAINER_LIMIT, 'container_bytes')
            with self.snapshot(iter(lambda: stream.read(CHUNK), b''), expanded=True) as node:
                self.visit(label, *node, depth)
        except CoverageError as exc:
            if exc.location is None:
                exc.location = label
            raise

    def visit_member(self, label, stream, depth, size):
        try:
            self.visit_stream(label, stream, depth, size)
        except CoverageError as exc:
            if exc.stop:
                if exc.location is None:
                    exc.location = label
                raise
            self.limit(exc.location or label, exc.kind, exc)
        except (ValueError, OSError, RuntimeError, EOFError, zipfile.BadZipFile, tarfile.TarError, lzma.LZMAError) as exc:
            self.limit(label, 'read_or_decode', exc)

    def visit(self, label, stream, size, sha, depth):
        self.check(label, stream, size, sha)
        name = label.rsplit('!', 1)[-1].rsplit('/', 1)[-1]
        stream.seek(0)
        codec = signature(stream.read(512), name)
        stream.seek(0)
        if not codec:
            return
        if sha in self.known:
            self.counts['known_nested_skips'] += 1
            return
        key = (sha, codec)
        if key in self.seen:
            self.counts['same_job_nested_skips'] += 1
            if not self.seen[key]:
                self.limit(label, 'duplicate_of_partial', f'{codec} payload SHA-256 {sha} was only partially covered')
            return
        limits_before = len(self.limits)
        try:
            bounded(depth, MAX_DEPTH, 'recursion_depth')
            if codec == 'zip':
                self.visit_zip(label, stream, depth)
            elif codec == 'tar':
                self.visit_tar(label, stream, depth)
            elif codec in ('gzip', 'xz', 'bzip2'):
                self.counts[codec + '_decodes'] += 1
                wrapper = {'gzip': gzip.GzipFile, 'xz': lzma.LZMAFile, 'bzip2': bz2.BZ2File}[codec]
                inner = unwrapped_name(name)
                with wrapper(fileobj=stream) if codec == 'gzip' else wrapper(stream) as decoded:
                    self.visit_stream(label + '!' + inner, decoded, depth + 1)
            elif codec == 'base64':
                self.counts['base64_decodes'] += 1
                with self.snapshot(b64_chunks(stream), expanded=True) as node:
                    self.visit(label + '!' + unwrapped_name(name), *node, depth + 1)
            elif codec in ('json', 'jsonl'):
                self.visit_json(label, stream, size, depth, lines=codec == 'jsonl')
            elif codec == 'bundle':
                self.visit_bundle(label, stream, size, depth)
            else:
                self.limit(label, codec, f'no supported decoder for {name}')
        except CoverageError as exc:
            if exc.stop:
                if exc.location is None:
                    exc.location = label
                raise
            self.limit(exc.location or label, exc.kind, exc)
        except (ValueError, OSError, RuntimeError, EOFError, tarfile.TarError, zipfile.BadZipFile, lzma.LZMAError, zlib.error, RecursionError, subprocess.SubprocessError) as exc:
            self.limit(label, 'read_or_decode', exc)
        self.seen[key] = len(self.limits) == limits_before

    def visit_zip(self, label, stream, depth):
        # Bound the central directory before ZipFile materializes its entries.
        end = zipfile._EndRecData(stream)
        if end is None:
            raise zipfile.BadZipFile('ZIP end record unavailable')
        bounded(end[zipfile._ECD_SIZE], MAX_ZIP_INDEX, 'zip_central_directory')
        bounded(end[zipfile._ECD_ENTRIES_TOTAL], MAX_MEMBERS, 'archive_entry_count')
        stream.seek(0)
        with zipfile.ZipFile(stream) as archive:
            for count, member in enumerate(archive.infolist(), start=1):
                bounded(count, MAX_MEMBERS, 'archive_entry_count')
                self.time_left()
                if member.is_dir():
                    continue
                self.counts['zip_members_inspected'] += 1
                if not should_visit(member.filename, member.file_size, self.target_size):
                    continue
                loc = label + '!' + member.filename
                try:
                    with archive.open(member) as entry:
                        self.visit_member(loc, entry, depth + 1, member.file_size)
                except (ValueError, OSError, RuntimeError, zipfile.BadZipFile) as exc:
                    self.limit(loc, 'zip_member', exc)

    def visit_tar(self, label, stream, depth):
        with tarfile.open(fileobj=stream, mode='r|') as archive:
            for count, member in enumerate(archive, start=1):
                bounded(count, MAX_MEMBERS, 'archive_entry_count')
                self.time_left()
                if not member.isfile():
                    continue
                self.counts['tar_members_inspected'] += 1
                if not should_visit(member.name, member.size, self.target_size):
                    continue
                loc = label + '!' + member.name
                with archive.extractfile(member) as entry:
                    self.visit_member(loc, entry, depth + 1, member.size)

    def visit_json(self, label, stream, size, depth, lines):
        self.counts['jsonl_payloads' if lines else 'json_payloads'] += 1
        if not lines:
            bounded(size, MAX_JSON, 'json_document_bytes')
            self.json_values(label, json.load(stream, object_pairs_hook=JsonObject), depth)
            return
        line_number = 0
        while True:
            self.time_left()
            line = stream.readline(MAX_JSONL_RECORD + 1)
            if not line:
                return
            line_number += 1
            loc = f'{label}!line {line_number}'
            if len(line) > MAX_JSONL_RECORD:
                self.limit(loc, 'jsonl_record_bytes', f'record is over {MAX_JSONL_RECORD} bytes')
                while line and not line.endswith(b'\n'):
                    self.time_left()
                    line = stream.readline(CHUNK)
                continue
            if line.strip():
                try:
                    self.json_values(loc, json.loads(line, object_pairs_hook=JsonObject), depth)
                except (ValueError, RecursionError) as exc:
                    self.limit(loc, 'jsonl_parse', exc)

    def json_values(self, label, value, depth):
        # Walk one node at a time. Keep labels bounded for deeply nested metadata.
        def walk(loc, item, key='', hint='', nesting=0):
            self.time_left()
            bounded(nesting, 128, 'json_nesting')
            if isinstance(item, JsonObject):
                self.counts['json_objects'] += 1
                encoding = next((val for key, val in item if key == 'encoding' and isinstance(val, str)), '')
                for field, child in item:
                    hint_for_field = encoding.lower() if field.lower() in ('content', 'payload', 'data', 'blob', 'bytes', 'source', 'body', 'value') else ''
                    walk(f'{loc}/{field[:240]}', child, field, hint_for_field, nesting + 1)
            elif isinstance(item, list):
                for index, child in enumerate(item):
                    walk(f'{loc}/{index}', child, key, hint, nesting + 1)
            elif isinstance(item, str):
                self.json_string(loc, item, key, hint, depth)

        walk(label, value)

    def json_string(self, label, value, key, hint, depth):
        self.counts['json_strings'] += 1
        raw = value.encode('utf-8', errors='surrogatepass')
        if TARGET_NAME in value.lower() or self.target['sha256'] in value.lower():
            self.counts['metadata_name_or_digest_mentions'] += 1
        if len(raw) == self.target_size or name_matches(label):
            self.check(label, io.BytesIO(raw), len(raw), digest(raw))
        encoding = ENCODED_WORD.search(key)
        hint = hint or (encoding.group(2).lower() if encoding else '')
        if raw.startswith(b'data:') and b';base64,' in raw[:512]:
            raw = raw.split(b';base64,', 1)[1]
            hint = 'base64'
        if hint in ('utf-8', 'utf8', 'text', 'plain', 'ascii', 'none'):
            hint = ''
        parts = re.split(r'\s*[+,/]\s*', hint)
        if len(parts) == 2 and 'base64' in parts and set(parts) & {'gzip', 'xz', 'bzip2', 'tar', 'zip'}:
            hint = 'base64'
        # Screen by length or decoded magic before attempting unlabelled data.
        compact_length = (self.target_size + 2) // 3 * 4
        if not hint:
            if len(raw) == 2 * self.target_size and HEX.fullmatch(raw):
                hint = 'hex'
            elif len(raw) >= compact_length - 2 or raw[:4] in (b'UEsD', b'H4sI', b'/Td6', b'Qlpo', b'IyB2'):
                probe = B64_SPACE.sub(b'', raw[:32])
                probe = probe[:len(probe) // 4 * 4]
                try:
                    head = base64.b64decode(probe, altchars=b'-_', validate=True)
                except binascii.Error:
                    return
                if len(raw) <= MAX_JSON_ENCODING:
                    compact = B64_SPACE.sub(b'', raw)
                    if (compact_length - 2 <= len(compact) <= compact_length and B64_TOKEN.fullmatch(compact)) or signature(head, ''):
                        hint = 'base64'
                elif signature(head, ''):
                    hint = 'base64'
        if not hint:
            return
        if hint not in ('base64', 'b64', 'base64url', 'base64-url', 'hex', 'hexadecimal'):
            self.limit(label, 'json_payload_encoding', f'unsupported payload encoding {hint[:120]}')
            return
        bounded(len(raw), MAX_JSON_ENCODING, 'json_encoded_string_bytes')
        try:
            if hint in ('hex', 'hexadecimal'):
                chunks = (binascii.unhexlify(B64_SPACE.sub(b'', raw)),)
            else:
                chunks = b64_chunks(io.BytesIO(raw))
            with self.snapshot(chunks, expanded=True) as node:
                self.counts['json_encoded_strings_decoded'] += 1
                self.visit(label + '!decoded-payload', *node, depth + 1)
        except (ValueError, binascii.Error) as exc:
            self.limit(label, 'json_payload_decode', exc)

    def visit_bundle(self, label, stream, size, depth):
        bounded(size, GIT_BUNDLE_LIMIT, 'git_bundle_bytes')
        offset, algo, prerequisites, filtered = bundle_header(stream)
        if prerequisites:
            self.limit(label, 'git_prerequisites', f'{prerequisites} prerequisite commits outside the bundle')
        if filtered:
            self.limit(label, 'git_bundle_filter', 'bundle advertises object filtering')
        preflight_pack(stream, 20 if algo == 'sha1' else 32, self.charge, self.time_left)
        self.counts['git_bundle_decodes'] += 1
        # Pack, index, output files, and all Git temp paths stay under --out.
        reserve = size + GIT_FILE_LIMIT * 2 + 4 * MIB
        self.reserve(reserve)
        try:
            with tempfile.TemporaryDirectory(prefix='bundle-', dir=self.out) as tmp:
                self.scan_pack(label, stream, offset, algo, depth, Path(tmp))
        finally:
            self.temporary_bytes -= reserve

    def scan_pack(self, label, stream, offset, algo, depth, work):
        env = {'PATH': os.environ.get('PATH', '/usr/bin:/bin'), 'LANG': 'C',
               'TMPDIR': str(work), 'GIT_CONFIG_GLOBAL': '/dev/null', 'GIT_CONFIG_NOSYSTEM': '1',
               'GIT_NO_LAZY_FETCH': '1', 'GIT_ALLOW_PROTOCOL': '', 'GIT_TERMINAL_PROMPT': '0',
               'GIT_OPTIONAL_LOCKS': '0'}
        repo = work / 'pack.git'
        with tempfile.TemporaryFile(dir=work) as stdout, tempfile.TemporaryFile(dir=work) as stderr:
            def command(args, stdin=None):
                for fp in (stdout, stderr):
                    fp.seek(0)
                    fp.truncate(0)
                # Child commands never use a shell, remote or the ambient Git config.
                result = subprocess.run(['git', '--git-dir=' + str(repo), '-c', 'pack.threads=1',
                                         '-c', 'core.deltaBaseCacheLimit=16m', *args],
                                        cwd=work, env=env, stdin=stdin if stdin is not None else subprocess.DEVNULL,
                                        stdout=stdout, stderr=stderr, preexec_fn=git_limits,
                                        timeout=min(45, self.time_left()))
                stdout.seek(0)
                stderr.seek(0)
                if result.returncode:
                    raise CoverageError('git_isolated_command', f'{args[0]} exit {result.returncode}: ' + stderr.read(2048).decode(errors='replace').strip())
                result_bytes = stdout.read(GIT_OUTPUT_LIMIT + 1)
                bounded(len(result_bytes), GIT_OUTPUT_LIMIT, 'git_command_output')
                return result_bytes

            command(['init', '--bare', '--template=', '--object-format=' + algo])
            stream.seek(offset)
            # The underlying descriptor position must match the pack header for Git stdin.
            os.lseek(stream.fileno(), offset, os.SEEK_SET)
            command(['index-pack', '--stdin', '--strict', '--threads=1'], stream)
            info = command(['cat-file', '--batch-all-objects', '--batch-check=%(objectname) %(objecttype) %(objectsize)'])
            objects = parse_pack_object_info(info, algo)
            self.counts['git_resident_objects'] += len(objects)
            names = {}
            checked_blobs = set()
            for oid, (kind, obj_size) in objects.items():
                if kind == b'blob' and obj_size == self.target_size:
                    self.visit_git_blob(label, command, oid, 'size-candidate', depth, obj_size)
                    checked_blobs.add(oid)
            for oid, (kind, obj_size) in objects.items():
                if kind != b'tree':
                    continue
                bounded(obj_size, GIT_OUTPUT_LIMIT, 'git_tree_bytes')
                tree = command(['cat-file', 'tree', oid])
                self.charge(len(tree))
                self.counts['git_trees_inspected'] += 1
                for mode, name, child in git_tree_entries(tree, 20 if algo == 'sha1' else 32):
                    if mode not in (b'100644', b'100755') or not should_visit(name, -1, self.target_size):
                        continue
                    if child in objects and objects[child][0] == b'blob':
                        if child not in names or name_matches(name):
                            names[child] = name
                    else:
                        self.limit(label + '!' + name, 'git_missing_tree_blob', f'blob {child} unavailable in bundle')
            for oid, name in names.items():
                if oid not in checked_blobs or name_matches(name):
                    self.visit_git_blob(label, command, oid, name, depth, objects[oid][1])

    def visit_git_blob(self, label, command, oid, name, depth, size):
        loc = f'{label}!{oid}!{name}'
        if size > GIT_OUTPUT_LIMIT:
            self.limit(loc, 'git_blob_bytes', f'{size} bytes exceeds {GIT_OUTPUT_LIMIT}')
            return
        data = command(['cat-file', 'blob', oid])
        if len(data) != size:
            raise CoverageError('git_blob_size', f'blob {oid} size differs from isolated Git inventory')
        self.charge(len(data))
        self.visit(loc, io.BytesIO(data), size, digest(data), depth + 1)

    def outer_archive(self, row, workspace):
        path = Path(row['path'])
        if row['sha256'] in self.known:
            raise CoverageError('allowlist_identity', 'known fingerprint presented as uninspected')
        if not path.is_absolute() or not path.resolve(strict=True).is_relative_to(workspace):
            raise CoverageError('allowlist_path', 'archive path resolved outside the supplied workspace')
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        with os.fdopen(fd, 'rb') as stream:
            details = os.fstat(stream.fileno())
            if not stat.S_ISREG(details.st_mode) or details.st_size != row['bytes']:
                raise CoverageError('outer_size_or_type', f'expected regular file of {row["bytes"]} bytes, observed {details.st_size} bytes')
            with self.snapshot(iter(lambda: stream.read(CHUNK), b''), expanded=False) as node:
                if (node[1], node[2]) != (row['bytes'], row['sha256']):
                    raise CoverageError('outer_fingerprint', f'expected {row["sha256"]}, observed {node[2]} and {node[1]} bytes')
                self.counts['verified_outer_fingerprints'] += 1
                self.visit(row['path'], *node, 0)


def unwrapped_name(name):
    lower = name.lower()
    if lower.endswith('.tgz'):
        return name[:-4] + '.tar'
    if lower.endswith('.tbz2'):
        return name[:-5] + '.tar'
    return Path(name).stem or 'decoded-payload'


def b64_chunks(stream):
    pending = b''
    saw_padding = False
    for chunk in iter(lambda: stream.read(CHUNK), b''):
        compact = pending + B64_SPACE.sub(b'', chunk)
        if saw_padding and compact:
            raise binascii.Error('data follows base64 padding')
        split = len(compact) // 4 * 4
        pending = compact[split:]
        if split:
            encoded = compact[:split]
            saw_padding = b'=' in encoded
            yield base64.b64decode(encoded, altchars=b'-_', validate=True)
    if pending:
        if saw_padding:
            raise binascii.Error('data follows base64 padding')
        yield base64.b64decode(pending + b'=' * (-len(pending) % 4), altchars=b'-_', validate=True)


def git_limits():
    for kind, bound in ((resource.RLIMIT_AS, GIT_AS_LIMIT), (resource.RLIMIT_FSIZE, GIT_FILE_LIMIT)):
        _, hard = resource.getrlimit(kind)
        resource.setrlimit(kind, (min(hard, bound) if hard != resource.RLIM_INFINITY else bound, hard))


def bundle_header(stream):
    magic = stream.readline(128).rstrip(b'\r\n')
    if magic not in (b'# v2 git bundle', b'# v3 git bundle'):
        raise CoverageError('git_bundle_header', 'unsupported bundle header')
    algo = 'sha1'
    prerequisites = 0
    filtered = False
    count = 0
    while True:
        bounded(stream.tell(), 64 * 1024, 'git_bundle_headers')
        line = stream.readline(4097)
        bounded(len(line), 4096, 'git_bundle_header_line')
        if not line:
            raise CoverageError('git_bundle_header', 'missing pack data')
        if line in (b'\n', b'\r\n'):
            return stream.tell(), algo, prerequisites, filtered
        count += 1
        bounded(count, 512, 'git_bundle_ref_count')
        if line.startswith(b'-'):
            prerequisites += 1
        elif line.startswith(b'@object-format='):
            candidate = line.strip().partition(b'=')[2]
            if candidate not in (b'sha1', b'sha256'):
                raise CoverageError('git_object_format', f'unsupported bundle object format {candidate!r}')
            algo = candidate.decode()
        elif line.startswith(b'@filter='):
            filtered = True
        elif line.startswith(b'@'):
            raise CoverageError('git_bundle_capability', f'unsupported bundle capability {line[:80]!r}')


def pack_octet(stream):
    value = stream.read(1)
    if not value:
        raise CoverageError('git_pack_header', 'truncated pack entry header')
    return value[0]


def delta_target_size(data):
    pos = 0
    value = 0
    for _ in range(2):
        value = 0
        shift = 0
        while True:
            if pos >= len(data) or shift >= 56:
                raise CoverageError('git_pack_delta_header', 'invalid pack delta size prefix')
            octet = data[pos]
            pos += 1
            value |= (octet & 127) << shift
            if not octet & 128:
                break
            shift += 7
    return value


def preflight_pack(stream, ref_bytes, charge, time_left):
    header = stream.read(12)
    if len(header) != 12 or header[:4] != b'PACK':
        raise CoverageError('git_pack_header', 'missing pack signature')
    version, count = struct.unpack('>II', header[4:])
    if version not in (2, 3):
        raise CoverageError('git_pack_version', f'unsupported pack version {version}')
    bounded(count, MAX_GIT_OBJECTS, 'git_pack_object_count')
    # Bundle REF_DELTA IDs are either 20 or 32 bytes. Determine algorithm from caller.
    for _ in range(count):
        time_left()
        first = pack_octet(stream)
        kind = (first >> 4) & 7
        arc_size = first & 15
        shift = 4
        while first & 128:
            first = pack_octet(stream)
            arc_size |= (first & 127) << shift
            shift += 7
            bounded(shift, 60, 'git_pack_size_header')
        if kind not in (1, 2, 3, 4, 6, 7):
            raise CoverageError('git_pack_object_kind', f'unsupported pack object kind {kind}')
        bounded(arc_size, CONTAINER_LIMIT, 'git_object_bytes')
        charge(arc_size)
        if kind == 6:
            for index in range(9):
                if not pack_octet(stream) & 128:
                    break
            else:
                raise CoverageError('git_pack_delta_header', f'invalid offset delta length {index + 1}')
        elif kind == 7:
            if len(stream.read(ref_bytes)) != ref_bytes:
                raise CoverageError('git_pack_delta_header', 'truncated delta base object ID')
        decoder = zlib.decompressobj()
        decoded = 0
        prefix = bytearray()
        pending = b''
        while not decoder.eof:
            time_left()
            data = pending or stream.read(CHUNK)
            if not data:
                raise CoverageError('git_pack_fragment', 'truncated packed zlib stream')
            got = decoder.decompress(data, CHUNK)
            pending = decoder.unconsumed_tail
            decoded += len(got)
            bounded(decoded, arc_size, 'git_pack_declared_size')
            if kind in (6, 7) and len(prefix) < 16:
                prefix.extend(got[:16 - len(prefix)])
        if decoder.unused_data:
            stream.seek(-len(decoder.unused_data), os.SEEK_CUR)
        if decoded != arc_size:
            raise CoverageError('git_pack_declared_size', f'declared {arc_size} bytes, observed {decoded}')
        if kind in (6, 7):
            target_size = delta_target_size(prefix)
            bounded(target_size, CONTAINER_LIMIT, 'git_delta_expanded_size')
            charge(target_size)


def parse_pack_object_info(data, algo):
    width = 40 if algo == 'sha1' else 64
    rows = {}
    for line in data.splitlines():
        oid, kind, size = line.split()
        if len(oid) != width or not HEX.fullmatch(oid):
            raise CoverageError('git_pack_inventory', 'isolated Git returned a malformed object ID')
        rows[oid.decode('ascii')] = (kind, int(size))
    bounded(len(rows), MAX_GIT_OBJECTS, 'git_pack_object_count')
    return rows


def git_tree_entries(tree, hash_bytes):
    pos = 0
    while pos < len(tree):
        sep = tree.index(b' ', pos)
        end = tree.index(b'\0', sep + 1)
        next_pos = end + 1 + hash_bytes
        if next_pos > len(tree):
            raise CoverageError('git_tree_format', 'truncated object ID in tree')
        yield tree[pos:sep], tree[sep + 1:end].decode('utf-8', errors='replace'), tree[end + 1:next_pos].hex()
        pos = next_pos


def priority(row):
    root = Path(row['path']).parts[2]
    if re.match(r'p3[0-9]-', root):
        return 0
    if root == 'rescue-export-20261126':
        return 1
    return 2


def scan_manifest(manifest, out, seconds, workspace, expanded_limit=EXPANDED_LIMIT):
    scanner = Scanner(manifest, out, seconds, expanded_limit)
    rows = sorted(manifest['uninspected_hashed'], key=priority)
    scanner.outer = [dict(path=r['path'], bytes=r['bytes'], sha256=r['sha256'], status='not_attempted') for r in rows]
    stop = None

    def alarm(_signum, _frame):
        raise CoverageError('deadline', 'internal wall-clock deadline reached', stop=True)

    prior_handler = signal.signal(signal.SIGALRM, alarm)
    signal.setitimer(signal.ITIMER_REAL, seconds)
    try:
        for row, receipt in zip(rows, scanner.outer):
            prior_limits = len(scanner.limits)
            receipt['status'] = 'partial'
            try:
                scanner.outer_archive(row, workspace)
            except Found:
                receipt['status'] = 'exact_match'
                stop = 'exact_match'
                break
            except CoverageError as exc:
                scanner.limits.append(dict(location=receipt_label(exc.location or row['path']), kind=exc.kind, detail=str(exc)[:MAX_LABEL]))
                if exc.stop:
                    stop = exc.kind
                    break
            except MemoryError:
                scanner.limits.append(dict(location=row['path'], kind='address_space', detail='allocation failed under process memory limit'))
                stop = 'address_space'
                break
            except (OSError, ValueError, EOFError) as exc:
                scanner.limits.append(dict(location=row['path'], kind='outer_read', detail=str(exc)))
            else:
                receipt['status'] = 'complete' if len(scanner.limits) == prior_limits else 'partial'
    except CoverageError as exc:
        scanner.limits.append(dict(location=receipt_label(exc.location or 'run'), kind=exc.kind, detail=str(exc)[:MAX_LABEL]))
        stop = exc.kind
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        signal.signal(signal.SIGALRM, prior_handler)
    status = ('exact_match' if scanner.exact else 'partial' if scanner.limits or stop
              else 'hashed_scope_negative')
    return dict(target=scanner.target, status=status, stop_reason=stop,
                cloud_inventory_task=manifest.get('cloud_inventory_task'),
                counts=dict(scanner.counts), outer_status_counts=dict(Counter(r['status'] for r in scanner.outer)),
                outer_receipts=scanner.outer, exact_matches=scanner.exact, same_name_candidates=scanner.same_name,
                size_candidates=scanner.size_candidates, coverage_limits=scanner.limits,
                known_outer_representatives_skipped=manifest.get('known_outer_representatives_skipped'),
                unhashed_large_not_read=manifest['unhashed_large'],
                resource_use=dict(expanded_or_reserved_object_bytes=scanner.expanded,
                                  temporary_high_water_bytes=scanner.temporary_high_water),
                resource_caps=dict(expanded_bytes=expanded_limit, container_bytes=CONTAINER_LIMIT,
                                   temporary_disk_bytes=TEMP_LIMIT, git_bundle_bytes=GIT_BUNDLE_LIMIT,
                                   git_blob_output_bytes=GIT_OUTPUT_LIMIT, git_file_bytes=GIT_FILE_LIMIT,
                                   git_pack_objects=MAX_GIT_OBJECTS,
                                   python_address_space_bytes=PYTHON_AS_LIMIT, git_address_space_bytes=GIT_AS_LIMIT,
                                   archive_entries=MAX_MEMBERS, zip_central_directory_bytes=MAX_ZIP_INDEX,
                                   json_document_bytes=MAX_JSON, jsonl_record_bytes=MAX_JSONL_RECORD,
                                   json_encoded_string_bytes=MAX_JSON_ENCODING, recursion_depth=MAX_DEPTH,
                                   coverage_events=MAX_ISSUES, candidate_receipts=MAX_CANDIDATES,
                                   wall_seconds=seconds),
                inherited_scope='Known nested digests retain the coverage of the local target-only scan. Previous wrappers are not parsed again for structured encodings.',
                selection_scope='Regular archive entries were selected by exact size, target name, or supported suffix. Symlink entries are not followed and unlabelled nested formats may be outside this pass.')


def embedded_manifest():
    decoded = zlib.decompress(base64.b85decode(MANIFEST_DATA))
    length, = struct.unpack('>I', decoded[:4])
    manifest = json.loads(decoded[4:4 + length])
    hashes = decoded[4 + length:]
    if len(hashes) % 32:
        raise ValueError('embedded SHA-256 list has invalid length')
    manifest['known_inspected_sha256'] = [hashes[n:n + 32].hex() for n in range(0, len(hashes), 32)]
    return manifest


def emit_marker(tag, path):
    with path.open('rb') as stream:
        sha = hashlib.sha256()
        for chunk in iter(lambda: stream.read(CHUNK), b''):
            sha.update(chunk)
        print(f'BEGIN_{tag} bytes={stream.tell()} sha256={sha.hexdigest()}')
        stream.seek(0)
        for chunk in iter(lambda: stream.read(2250), b''):
            print(base64.b64encode(chunk).decode('ascii'))
    print(f'END_{tag}', flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, help='fresh root-owned output directory below /workspace')
    parser.add_argument('--seconds', type=int, default=840, help='internal deadline, at most 840 seconds')
    parser.add_argument('--print-manifest', action='store_true', help='print embedded allowlist and exit without reading archive paths')
    args = parser.parse_args()
    manifest = embedded_manifest()
    if args.print_manifest:
        print(json.dumps(manifest, indent=2))
        return
    workspace = Path('/workspace').resolve(strict=True)
    if (args.out is None or not args.out.is_absolute() or not args.out.resolve().is_relative_to(workspace)
            or args.out.resolve() == workspace or not 1 <= args.seconds <= 840):
        parser.error('require a fresh absolute --out under /workspace and 1 <= --seconds <= 840')
    args.out.mkdir(mode=0o700, exist_ok=False)
    out = args.out.resolve(strict=True)
    _, hard = resource.getrlimit(resource.RLIMIT_AS)
    resource.setrlimit(resource.RLIMIT_AS, (min(hard, PYTHON_AS_LIMIT) if hard != resource.RLIM_INFINITY else PYTHON_AS_LIMIT, hard))
    result = scan_manifest(manifest, out, args.seconds, workspace)
    report_path = out / 'result.json'
    compressed_path = out / 'result.json.gz'
    with report_path.open('x', encoding='utf-8') as report:
        json.dump(result, report, indent=2, sort_keys=True)
        report.write('\n')
    with report_path.open('rb') as report, gzip.GzipFile(filename=str(compressed_path), mode='wb', mtime=0) as compressed:
        for chunk in iter(lambda: report.read(CHUNK), b''):
            compressed.write(chunk)
    print(json.dumps(dict(status=result['status'], target=manifest['target'], result=str(out / 'result.json'),
                          outer=result['outer_status_counts'], limits=len(result['coverage_limits']),
                          unhashed_large_not_read=len(result['unhashed_large_not_read']),
                          known_outer_representatives_skipped=result['known_outer_representatives_skipped'],
                          exact_matches=len(result['exact_matches'])), sort_keys=True), flush=True)
    emit_marker('P3_ARCHIVE_RESULT_JSON_GZ_BASE64', compressed_path)
    if result['exact_matches']:
        emit_marker('P3_EXACT_LEAN_SOURCE_BASE64', out / (manifest['target']['module'].rsplit('.', 1)[-1] + '.lean'))


# Frozen input data. Use --print-manifest to review paths and digests.
MANIFEST_DATA = (
    'c-qvx1$Y*@_CJo4;##1T7AVD~G&32=;4X{1Q!<%MTdGtj?!}9{yD#qUvbejuyHog`bnWfkvT*O-`|bb#?DMd@<>e(OIp-sp<V><;'
    '-B)(=ilpIwJkqOlH?QDOD=LV4mG){t!y|G1@BqJn5E@jMTLDqQ4g9-A1TY#@4Ob2dWr1ELz059=Ji@EArfOPAuLyrCs~Y@KiCc!v'
    'nPI82W)n@bZQG!-VH*~)kWCHE(y+yCnG#dt3fHM3Q%hG3N(^EcME2@Y(u)O!Mp?cAA)R<gWN3I7-$)t}2w$xrTcwuDCEdgd#uhP='
    'jAUY}RH7Q?HjF7MBp@UrjI&5?`TElce{Ok|Zr#msbVSu`g=3}~*fL}!X^LT4*e14aTJQ@q387pe)Ksx%Yl>t`nr!H@flSM^l|RFl'
    'CCNYt!C*t9LSXjfl3rmn(jWc~pXku=z=$x)xKEg@dNUprgphYQ52gVyIzMk39uVmt%p(JsH}4c+@esznAr4KFWUUk|Mk&9pFbNKW'
    'W(HCbHmO8p%aRSMQqB~GY9_ZNObtn~3|%u!+17|{Yn*F_VW?a;G)cj-N%)_GHe|`rlt0ESeP_&(UBbBK9T6H84nwpli;Vcjh&%tw'
    'h!J6iB%4^`SfUc<60<F;*c`^D+t@M{9bua*2F2J`VBQrI=|m;EA=?a7ZvHu9Ng{@#{r!lUKM(N^2sUXDg^|I4d2m2jct9|Z@Cl<~'
    'Jlv;o5bZ>(_|p)W`_2KKevc?V1SFwST?4`rj^8vGqm;`s!G@)9gQ@U~u1N4RL=D@tv0-8?W6i*}Z83@rovE11s-@@}F%5_D6Jn_9'
    'KOBEJ58^c9_c=$JPZNJ03JK*|R4O5r($!*~p&_1;{@k-hXpm)6=I>c0G^7JmK~y;R^!BVA5CnM_MT0z>@D}j@zkkhN<5n%E%cd;J'
    'I+vLV%b{w9Y%;7UOx9#VEY&b18|hrJESqVvW+F|okfmyprZLGOZh|yT{Z4UU)!U8=3i9^n0e=3Gzh{){V}&viIY5xN6%Y{_9$-dA'
    '284$Au+WgmfRHFE{^!q6|Mt_+sEFUbDE^Co`%Xh)wyk2_o0*K8rUvV++6uxNMUZi@$}mm_fRe~uC<d&zZm5V+ji|`hp|lKHwiT?3'
    '1jeQ;Guf80ZkT`~l1gOAbP00YmJ|wk{^wj^6>0c8Mfa__C>2BlfBkLvs>t}%2nh`j_C^9i0Sx{+ZfsB!(2F8i6ed=Z!g!fV#ga?1'
    'Vlhi6SXT^2EE#j8%3PLAPLa&8$pI4`#w{r-!P@uWLi6^AG4pWmP*dcbH}4!48vaKJnh#}+hXEk}_WKcuB8HAtMkGTeh>InHY1eeI'
    'Mo>>0;;PAE`8YRho2rTe(=IC#A~I%*ZR-e7(E*r|0gFn$H{Y5!3!)M6l=dHHo;Q4n5APfqPQ7ga6adJ8Ac)drmMz=fCe#X7b)Vk>'
    'GtsCGl>vHlNj7A{Y^1=lNR|nxV?hv%8-~R-3V901Vk$5h3?W-m6^p`x8AM}$My;qSkO2BWids;accgzf=iZo7+nYvN0g>L0pa1)~'
    'AtDe17NUwSNfxIJV`3_*i8<lA1W^K*0NNnnD+=sKWo$6Xg8T&vmTamx#tq1Wl>aF1-)l?rj;2sjEHpS60`0`Z18n$Ud=$TbwuuC#'
    '57j2CDj{;KzmLu$Fl18$WUwV!Qcc1XZgZqVe2giw%prWp4MjFJn_>lmMHE>Ka09^9jMp*0S0GV!6_I}!-CtKH!XYpMN=7P$5r(?^'
    'PGDT()HGy(5<nFKL<0b%!O~y`Ny=24aa%D22CCH1A%U4rZO~H|03%Wr>>xw{M1e`P|7~CrfJiA_krh?{PGCs0L5*?%AEHRA4q;jb'
    '<3M=`76}H=bP!uQVg>*XAqZ;GR4rKoiiDE1k;96Cti(`=-@{D98<c9KcO*c@A3*6%1b^t3=F<_l8gdZ8<j+sVe_!J1rt3P)y$blj'
    'nFMG^WdiVS+7zS<u>pq^TUAs@Ur07CL#e4uClUw6OKomQe-0i9U&pfXza0Euw5=*DHb{SfaVRhgQ%TaXA{$&6r4F=f*gBAy4C<Fc'
    'T2Td2-Ih!XafK;}U<ajzB?GYWpA9}7cqX6|w|v5Wvpe1qQDO0PCdrA9pTJz&Oy(dhs0l;DjAIqX3Y2SdqU!)?vPdA=wh0oJ2moI*'
    '7&5T|(vv!jUo|8UTK}c-+W}@c_l}GT3*w26Tj3g4IWrLjX9k)Pl&h>uhAByk0u&6iWHZ7om|`d&a7PHKplpx~sSgW6nB%-Fk}hfg'
    'rE!N-D*$Fao?8;lb_LK90AB*b$Yk(1Hh2tGwJk-pY>+DogJpn0f-eM34vBAQ47{O^ILBB4oN_QjI!5TfH0(b=6#AQM_D%pe|2q9('
    'VS(s0ix9wk189wK!YqrM#DXu^EDQ7{V;BangLy_6vW!#E2@=B^N8Hh1z;8;%e?N?Pt(NH6K|E?QSWp{TFd*Hsz#IYFNyxGdO&0{F'
    'A{|piG^o#biv;Wde<Q30hjMT%Sxp0^`e$Po^%)ev!z2DESxNQ@3lFuT7&xcDT?8AHG7y+4L!w9wTr)^_3kVE;*9JplSs+I+)`^J-'
    'WWNMvRpA&ZR5FQbYL1#ylO;iXe?)>4k3>S=VNqrf82{g9Jp3=L=I|L78WaR;AjFpfT3%9+Y$)XSKZ<0ZKR@7Oiai-`jQ?r}WN_jX'
    'l0*T?NWi->3u_wY8q|WV!<eD4HTXxRpvJ&!tH>~Ij)CwHiZ`<kK|+~J4t5}kf<)x6L4tmiD5Ai0h*F&a&*@C0AB-4-x+DaHci<8L'
    'Fa|ON&;x3>pvV*%gbFc9f|Zm(yCnHa>VFMVrzSWf$;2kCnS#I(0I68u<(LZ51HOTv7TyO`50E5M3>~S&Qm`p3AOMSFkO)><PwF70'
    'L{`#Nhz58D+8-EHg7TBW_z^-tC|iUpl!Bp^AbTNrn==Z6foLjtSD-6u0%0W#5~w%HS5o?GkQ#^^E|?SqBrpJif&};gX>D3e@Dwnb'
    'qJbKPpFz&5Ah9iCaRa<N{GKH-$C?Deswa6(Vl|O;)re_B093)uFtBc_I<`Pus}zhq0Iw!9rb?#F1q*OhhN{#IN#-ikOn_lK!AgP~'
    'BuO1)qMI!om>Pqn(=EwRRlpP*ECj5nElLceiKWUAFXs@pWCM9<L^nWpfig6RqGQLER8<Kjc}>cRp)1!p;Htr~Oa+AlscRspz;h52'
    'JUJzTCu9!UYf@rMK>Zd77LbxexDO&FKvxM=eUhiE{MR4>B2~>0zyh)c3KG^3>=bA#8A}+_QDVA~1F8n5N|Fp_*`RKa!em(o%CQpE'
    'q>f}Y>C-ilJxvo-zhTJ0A;bm+L%~lGIi5Hzl`2AYVnPwqFc>Tl2nq;1-B7?6SWuLT<DMqyBhWla4m`4w$VwucGNe+F{K#NBU=aLV'
    '1%x5gGIf{$Dy+Q(w#KwoTgA3X5H?jCv;Z)O$rAvNswzpol2Rh*Y8gy1M1Cq_M~PVq1AMg=!%#qpnz9P$B4JwsDPYEbLg5@xmNNu`'
    '8!N;}06YptNv>VxM6@fYIa@I)uq8vVWEz-$U5$TMWP+O}HYT9VZ4(L<T$H8~kh26FABa8KmS8Fpt|TOPk_VXx@PKx+I9NLZr6x8%'
    'pwv{XiQN#U5YRh7EH-dFV>**8O|YnHYmmXP&<vCUPACQdZj(G+6In?h3nX#bq^d^2SE-5xD<WfJ0MvldHDnuf4b=#P)di^v>j~2$'
    'o-gSdEU%J4pktz|Nlzh4VozQS##KXN2B-qV(k-MJOlGzP%W5em*h^iLLEf6o0#zsJrfFc%0wDDuMkJXDYEmOfF9wuE(iONvVL%jy'
    'q8JwZT{6`aqUwgJfkCFi?Q2XUnrv_=S&1QwNYsQpg+f(Sr05BGlITf}u8Ne{N=j5km@*X+i<n^kRbWiOQ-**w4Q2yLa>8^=IBTXb'
    '9g^D?4=XI2SyDn-r|JJ+uv&?%qyfvuENbZ{7JC8))EotU4(Vv<+)%NsQDn*>)g_PsTnG511n5%(=rt|dPQa5gc(A1B$;6)Gf=vVg'
    'AkIjD6_F(kbgV5wt^$8(T*44KhP0$&{08Vga34^S+*D1jFsM_<l>~LD$w?k$A}&P3LaTvS1l<j(DF_mn603}I$WL393=<hDh#yr`'
    'Y~V?o7+f;pPr+JKtn&mEq8UlAU6n-6WXRwu7{m$6)f7j7z*fpKEQt;RftaSG0wT#^vk(H!XMj2YU1MrQ!5Vl^;6;bW9I`5F4m<5h'
    'wUUWxSI{&vN6Z8}EFS70n`lVaDb${(TOidz3UHeelj~TqI6~s=661<(Ag(h-b=;QMKm{f}g(M;dz)tDdRDcmJRhVZ5au>X^iNzBV'
    'KvJkvYEecg6e<O|sw;p{6cd$TSvMI<P?Lt7^oj>3Vw!b{fC@FC++fW#iJ2PwW19f0@D*T{;irm4s0^|k0!0=>!hSFr5*J_zzQU0w'
    'HInp-M^40r03O;J)xizxpimK!45X=+Y}k;jfGaAPDqY1K))B0-1eymF5WtH<G*tzMW+hlj1U4nfS27WF)rmMUL=;du4DytTlPBCl'
    'mLVd?7=pD8SV3DnmQo~B)-00{Nj%xNIEA1Rpeq4bPIBN$MDakjf^`%Jx}g44S=E6b4ERea5Wk7RmFPONP0hwKm7xS>K`p?RNJm^8'
    '@Us&H2}qpuI|GRXDQhxSv1CDP!0{^8ZLBCZ0%d1Wotj)jf)_;K05}{_3XBPc#WXF0a75Gu8(9WP`pso2k;eqcwp1`7P;?Rq9}MO~'
    '73UXpS?piIm__{=hN@zNiF24B^oR}&q7aMeSke>h3>a9JlKxo;N{lC|WJr*G1dGR3px-Q;YlZ~1O2xrF6Cosy+(;@R7&L-xAz8sD'
    'We^}tOTwpG7))7`r)y#>34=CtP;Ja$*w8J|Y><-#3;Bi+=U_N2l@irrDx{~SSxi#^V<BM~04zlbDFmY=M^}^xx|)El7O)}M4MMpJ'
    'h7cPRBg14^oTimQq7&T))_~bSlA&^>*_Hw_6)PN&SWgH%x}M~+4kzM55YW5~VhxOyB{8B>C_NcuI4Cw1o6JTO$b)bb%2Pb}LMAXO'
    '%!;fsYzn=XU?rhuliq42Qj<j1kYy@htw8F)GMZR2bWm|7vULs)QMLehK@(YEn{|*h7Sd#{gZhz?Y7u58*sVk0%96Y$6A4n&z!Pi2'
    'G8#54jKsM~Rp1X>1vP7fu*1SzfEZw)fv|29i<=C1gjw+avh6@2GL*9Py<@>Y6r*=oct9r_$$eOWcR;W>trX$o7^38@0mNg~Cfr8S'
    'ufaw5AS3>OXLx9k<79>Nh^S!h^Xn;=2p>sB5@<CDMe_Oe)O;fPNEOd~6isZc1N5kds$04yA*2x1*1$#^8cc@52_hPNk<AR9Xfl=<'
    '2u7}J4(l$1!q=swn-YwEa7t8N2MYc6lrS4ayu@TnwLt1~85ugF1b$U4aRLT|!jQnm+7>7d3;+*v13%C~mKZQw26mhhRVGH#O^Jkm'
    'a7q-g*n}wGoDvHe6cnT`SqOZc0@TF;z%3JD3nI4-fC@tuC-ZrHDZvjFMl5gzjKP2Dj)kLwFipxV`OzuSk*X+|d~-^`3<5k_7#twd'
    'I9GuMAX{u8dIejW*qb3-AzXrqu~n7Zh6G3hFk;IR<J{3b$%;7anuJ**|1g$-64A78PKhlhjf#C9m56Isk^vkjW27rooT~&ngfF&C'
    'jY^6kX@;pnZ4uB%gsZxYnZuNTgpjl(oD%tmr$m!MqUztA5`}51se|^DKo{vmH*F9(7Urf2;e$4W^uZKVg(ZVBkN|^$Z)`apZWURz'
    '%>;~NC~6W;iSpx90&4x+St42DVJFZjS2SB^3X@gE5~sWfqy&X8Af{$niUAS}3XrQXeq@^#!Z3+cHytmFs4__Aq?;1uhp~hhNWtHR'
    'R}2NBGqCT#tCRq@$^b1C=$Pw}4#Wn@rGmqiECVB^Q7rbt#c^ezGAwLV0unZoQkTd-tV;k}4ddHc0xrljEe0Y~f?{Ayq1=#wn3)0s'
    'j=)55O%adfGyo;23(I1*B@zh&6hc;Zya*)|Nl!v})qiwKuqr7!{^pcWM3By8YGY;-tVrNJK!s4vU=sXl+F(Bbo^=I*wZaNA6bc`b'
    'Wte3sBMB!c99{nYHHZHp3IAx87~(<)R{utqU~GzO%Ah<XliJkg7O}amC=yJMLAh=kT#_{onjUh78nU7)h6U3s>EKjR0(jL7ISI4m'
    'N7bt?>=pX9devlVaGL`VSSDczM45qrqQHln#ImriQ4Oi81SG5}#Dv7Kbu5Exh0jP#AzH#I(UTHO$PdG-tSj2Lr-T>)8kVMs?L*rF'
    'J_gPPG~ocKpyCaP+rTCWRt=;Y%n9U^2KEQkylgPSuw#~}81N<u8Rti{glHha5c=kn$VBi2CpJ<|ar2xQSYa462%{9LM-@3^1Kxng'
    '0lG0v;3Soc?QupqvK$#lLMm9{Bm@)bhlL522~^Lwg^4Z>j6sSh3bRz;90O#E*wit^%{Yx1GKE-FkgSyGwryZl+^?~@%@7m2S_$w~'
    'N7DZfrbJaWgbexHX(BE}3#p-j^!T+M1gKV!?U*xztMM0)6^U3dt=u%kRS}|tD<oo*T0H4ZSUGYMf{7yiDCK~=$Exvd-=~<iKn-yT'
    'l2Bw>gn_-&EE&UOPz7Uzs03ooVkWb|*<lC(RErI=4j@H06Z$@ql!YVx_=btDp>GQl;Z}$Q!o<*lRf(xGg+s8GWUHX@#s07<i$ij{'
    'W-%2LrZL7q$cwv}2tH)~i+oMO4HNvsQz9P3pl=Hk6I<eV5g2A2Y_laHu}MJU)hzsmt;sslY!zED5#s0rfUT?o1S785V4i6LED<{<'
    'Nth)+%EF3>ME<tPQLwoCCvH~TCI*KCfT|nfFoCUV6eK#6kgbdDBr5K?GF3Nh;hANkQPH+TPk<#zOG+!O{V3xgMbg!87Y;*^4WQah'
    '9dw!rL1D4&C<B0si`ohYv8GrY{&MlWT|tD)rr3Z1#lmf@*a?J*NXaD3k{?y{Di%l5zs)#e6IGLC-83;wizHF;v<37k=2*fMa~+vf'
    '1BWLggIj<v2#d`oNEV=FOzi}WBO7WG7LNR*T1|tWtIFR@iFk$x-w!;agHl&GS528B#6{q?37CRaQyeN*i7A8kWnA2OPyv5*s>|4P'
    'w8APVpd`$aA1xd(X`t%Ay*r?ZtHBT=qAKWd$OQxH#nLQpN|Z>HD>B8@FeFP70Agr}*bLB#$`)5Fu*42o0s=@%!otBn3a=pNLDPSG'
    'r_nNyX@K^U;qSABl|kTZ;7@Q9%Q`ctjG(eWlPMZyGI$?uf^_3Dp`sy+lweAP6;_f^s{QEZs{smv7~dB3reQFMg_?wD;+`|tFaxmV'
    '1k%S+s6|1$iTg2{0ce96h5|x1#+qp;nnAP#SOR>Vln-*$A1xeNToC^DQwxoQ<L8EEDIinD;RA8=1i)66BvC=&kdY~zpN3&3OsXgf'
    '6p*Tl^FlyJ7EYjEQBq1Z^uxOYk^u;z{LStF1+yy-ge#&GghUlaRE|v{V8IKEOLL-?n4n_>!>~AH3If{)l9%fSlM|A#l9Y_|!|GKQ'
    'mo=rod1}FcTy=4X+_rT_EC#9#%0mIj0PU_whUln<LB^T@#D=(`En@?+MVxsdQi8{Q2qo!L3;l-$J(&5wdA6n67BH}3OU$xuWMD21'
    'oe>iVMkYE`0#FT;K$Mwa1}#j)y#Yfsx+0iZvgUYm0!UbsND?y6k8Td=AYCQn+a5=yDiA7Yd5i&FA*ICWZp8qg6emY)usIY27~zIZ'
    'FcuetfpM^+sWKC{-=qZU6~*_VOtLJ&Kb$27*#2)94yNK#0-y)5t|f^EgodfvGSy8c8Yd!14snj(1_stuS)mFPnPfulAp)7>*b+=|'
    'k(Pu{EwKE<@Ty})`kN^+0VGXeC9%QE6xF7fNs4S@NG@c+SV55z4if_A4{MTUORBi(VJHZL4B-i;1ZFfTvE)ZdSXT^9)&FL50AN8j'
    'Ofb2!IAWj!pnz~UkS=S)<c7q+=vjth5Jg<E!j{cMOF7Z|iE?h~DB+nKH7T*=N2f$IqXaYj?Ttp80xJQi0(y#$l@bwGTOe0#iZpSO'
    '5NsgQkt!~RiVIv^QB7(pCNnrDDzy_FFwv9pK@Qe__(6^#_8Pyvt0q~X`o&XmY6Faz8s{L?fpk@->!9dOCd&+oooQ|<SOJM+QPGeN'
    'W(_D;!U?BDPs%L$Q4$s{%=Ev3SFv?QL6L%L2Zf43)N_@Jle6NGyRDkoHZ5_D(-fyln7CsrQTQBJOk3wLg^qoXb%Xps|KE;=_Ajj#'
    '6YDUjdBfDG30o-I0X)c(eQAj08y*^sP~zQ~L>mbWS+LX!H$}c1;J&aV4p?c1tzrcVf|!^R1fm=yn64>=shoqkWvXL;AA){hFZrLu'
    'V{sO0@o-<}Ps1a8X=Ef14vRzx`+~qrG&YrDNwTS6JYC}ALJ6`>4uX;)Q<GI@gMJd^p+mjuR54}HkdzX|7H5cM&G9r4QU0f)1%*cY'
    '+EF~nS2O{Q3g^Cm+jt6o6&(@9`5gdlSr`9liYJN0P>E`Aaoa>yOb|F?Kisf5R~Qr&LjdHaEZdG9w3P27)jtU=oKvx6f5i8<ap|_A'
    '2oER@`r2Rz#W`3ibDgP7RS=cLh5;3g2LX!3gD{PNNzgfCI#(pqv4;lyS%UxPwdETY9_j}m;*g9|;+?{PW|_hzYJtd<DG&&-3f2k0'
    '4L2>yz_eHrC)5D6Pz_i@N<qik3gzO6mhJdNJpPdS|8m8`WZz$LQJ_Xth$a2~n!&$7d;tyW7Sty|f(gc55~t890jX`6l45})<Dy{*'
    'f@PGrf~lrR@$DM9>G+tzfIs-ZMZ_=(3M?Yh;*q|;cNI<?6h(tlOoU9d#byTlOU4Q?ia22_Ityro>qO>Q;|2l&B<YsMfb)=q#3`W!'
    'ZQcPRrT^u6F&YvYBKp>S2Qv&Em<=2OH#JxuByQ1341%z2Ta#?0T8d$aM+G`qXmF08su>p7eI;4+%WzyL2p9cNBZ}`H@B3$99U?+Q'
    ';%V%62Kb}g5^t($TM(SixkeSx@S>3tkgbGN+0td3NK^;OZ&C4-9Tbjuii%9cVVL5b0y=lZeG&Zk)$Kn@N!leSlv=)aP-v)NHHh+G'
    '_$~1mWs})}5h6T9O+;)%k{}xRUxIB*Gc_>%)CSOjpddk+q6sTwauWf&QOCPzpzqNCG(+uxkbp?;%R;}$Yn-YwLZTNI(zxiZNI0aQ'
    '39DluW||hrOlm2XO^J9aC9ZLEOI#8W$7pnoI^w^M3DN%#lJr*|_%$!T#{vW_mnFf%0JZ?P88%^5(ZP8_kdiIBe#^)Ljim#X85E=='
    'C=m%h3s7p<3b7OPD98V1aKFo5)jLY`@(;KEcr!zU&!6M=2@8i6620(2fro}$5v4@!{k8q5rfDXj8i5frrV<?k6sn3$bz-UFP^8Yp'
    '6-m*J7aS(xT(x!a=#?t4f~I4?M9~UN)wTa97%PDKg@i^#1~A8$PQ<T>cSKlFz#pyT9pa<m%pZ(JDU(KUP5BopW42<7UO+mi4AD~#'
    'Sz?8NxeW~{OcU=jP;^BF#8e;}aibM-kufBz7LhGSQ>?2<Bk2Dusszax{~-r?oOtJWnMtBWzS!pA@q5gQC4s6Z3g|AVJRvNB^dv<$'
    'bxoDH2o{o5Lm;|r>i8lPMZsY9<nKSN@eT_0`>o~nAHDtmFk{{!P*$C|uw;>d6Mr;b{mr9!$9IhXeWpr91O)^q-rZM4AR!S4TdH8t'
    'Bmx*@VMk4_N)&^Ul`Vsco(>SFcsqck*#>A5BfcxNncy_0gunaJ1<5-sG#~;h#5;(F@Q6R-`c_N)zxgA-wf_%~3i-43?_V9cCLsoN'
    '#(}Rv@oTnXgN?yp-w+U$&bTeQk%{LAjB4V@HgKIv6)IjsB145bE*tsoy`cYUe7}N?7Jp+d6i~KHBF{k()|f2r^;y`!hUnvj!I43J'
    'TFAD+a!RVDN=%i+y(a^fR3nB(#3^puwveO#*T3Hh`@b4o$0#24-Nj?F5#Qy|Af~v)sEEspV6>4cdXJf4yT$QXqH%GxoI{~8qDhp2'
    'G1a-O5YyonC)inx{wMKK78yl@yaPfac{pI(pYQ2OK#Yk!)q{K!1Sa~Z7>22Hj7@+Q9rTo<%UIUMezOJc6En@G;+m(f5DRb>Y7xNH'
    '(Yg^;`)+4#fCU!C|MISou<(G;@PNoJfBUWwzyv0GFjEs;KQ|3=Q(wZe3fZY!j48;%wivadBgqsOVl==?Sp(n~C)rKKQ99{Z1tt9-'
    'jnx6-7!L^h#$cIci1R84<edeMQQ^o`0fEJJSlI-)12oeW4pKr=!G$R@XTZ6JgvHZhadS37qjjQv@5LrRI<G<&1pQ^OTKu(Zz#jtB'
    'WSTNe4}g$N6qs<}DX_S<F3vyOx;V)RmIMP(DKY~?tf&@ud};?@2q`1~N27IoS5`dTCqA_*upZMiOVLaNiz}tJI2C7sIM!ttj<_c;'
    '`UNS9F8Y@ulV~bTv}i*HC~V7)c>qO>{=<|NvRJTOfCYt@c)rS_bB{uaxJ`i-Tf7L3Q%)pXC`c{-ZW2*s)3Pk8O2p*cLZD+LiD?+z'
    'x8nFVDI}hA{YT^c`<0h$1C~sjz$Hvm#WN=?{D=;Q1Ljm`s%R$x)owBZzh%SF6y1<i88DF|plJtUG6(|o@gI#bn1%${pdb=oZ;%F-'
    'sf+d;qWcICsd$AGH8s$AT)g8#+!M5ztP|i(QRfH{8YH1+g9TwwfevFNx;QWQAC1wD@9zKiBNgRg7~t56I8|j}OB|J#C2WaT+vtYa'
    'kcVtQ8Z%5;GIepI4+#=MGEB3oumtV>zk4VTYrk)*ds{q6Y`b@Hto+bW8}c)Z282hHGNVGQApRFA31$>DvI*pDs3u0T&|eZ&RNy%a'
    'sF(mEnYM1KvJU7a+Q}QDouMweJ3G2IB4hoZj5Yo>Jn&&4Vjc;<0Tcwdq9r<N$_*$gNwr1iAQ+5hU@VCn^`fP}E&6DRW_1+V0?&{s'
    '9)Q5`#hx*-7<SYe7;J&`Plg@;+C;Ei!8F_tRPL{17l&bNZY4T)i-D;}Dv=3Q#R(#VS>UliP;fvc3xmIhnbk$>0GX;r{2n3!NP}4y'
    'FEK+7=S7U~KlJ|2j0cIgvxp}(zYg1yZHyU9bl98$jxj2>X4UvRg_;Z^hk*vCpa3Y40syXoAho$Hn#^LTP$*QcD<-HRM~r|(H~z`6'
    'O&&?Th4NvMzl~ePwjvXf=(q`&K(XiwxFOl14BWY;%Hq|J;_#MY$yfzr1ik_UgdqdNg2W^6U$$jxlA<L%i=v``RE@vAV~Y8676|Gt'
    'Br?$f+sK4<P^maQV<644RLv6CiI{k{X&}`Q$3-*=MhIpCidCGU&>#>65wV|Q|BD#=$0ccph6e-YIVwnR!;~~&g~SnsgDAAY%9#{o'
    'j{<}y4s}2|LRy%jEf}|$WZ4*q8MG!apt$T|QV2m~CgIdEzcKkI!w=z|BfY;5fi?rR!c9prEOB@Zh)u)d8z6B(PH?Q6qT`H;!L}$G'
    'WH&Wc+mwNxRm^qjxE~_kru9z-9KU5RlusD#63jz>PjAa)2&N*@!2?|by4k>en93Z>1Yid~EncR|kt{C!f+d3rv^Xc0qJUtsnSxbY'
    '98?o8KXiN}4*5sP@>@mzVLl?fF(=}_X`<s+#PwY8d7@DzHh_+qWsCcUvdtLSMJk$dTTp}qQU#<iSV~nhIJJO`D8sVj{agTW=^tnL'
    'uP_*&F`#IHM2tj-jl}MRBwF-<0upb&1Q#pIRP3*)mO(LaI_P?8Yno^eYl1wrxvnWt5~7EiW5XgSZRsCn_jh1KrA$^N;6XzdZTdym'
    'b6`YEvt&SPo!h!Nw+k3eOtEnWd9P3f^fcvSg5?B_S+Hn+s{E6&{<?7#84%1vqax$;LZtY=zM|(ZZ=3^A*A?5OFq2@dO|CMSbVIba'
    '(x_>QcCO;ZY&sO9E*{4N<tpOJAu(lc+m1{LvJe?q`!9!Ji*o(#&2xVVq^)=#@vm<o_6-s*Sx)dS;*hAIpg#pEBsF;0|IS_6zkbFi'
    'AS5g*GQ!6U4UL2%rD1>B07zssvaJ7KjV6)Z_5=fxWl0<#)s+A4fc}k^Q1P#yN|IUoxB6E7@QnUf2m9}y>G{hjp;7`vLZd@`p|E(k'
    'FHkj@FJQm;J>>}Bh`@lbF!3sHnW#OIrH}6XqV}llTEhc=SzR}sZ#?{ZlL0A1Mm|4q=ZkaJJ-w2-wY>Yu9`@NM^lt2t<sVMwdb_q('
    'pN1P!xLljPxBK|IOOn;ezbi2L+@@1rl-c~iE!h9@yizZRcCD17S%q<1kF{9PAlU%dR<UMZJ*081KABFWjfqlYUAA~<sNB8L(7OYi'
    'zLZY(aztph%2BNcWd3^Z*0JJ2u}?E7E8c&&ePU?#)oC7A+neldWV2=kVt>jSRQ29lyM2m`mY%9^wUt{Q+<KKa_k?R5lD%{8{?mi1'
    '6|)4_7{0jk{GI`Ot?c8DlajM;=Vg2P^hlSy<c*%bYVg(xzE8iDZZoFzk@TxWM}Ap3CujRtb53@5xu2Y$t6%Fx?wTHb_juQ{yN4Z^'
    'd?1>{rQDM1MysK(1I{SPk1xo*;p^3DkNTyVGImk+hn1VW@_H~TsD^Xym#wm#dR065(*aR|Jy!X8HL=f}e7o%Bv<c;oWV+uv`RCWA'
    'J-;;UGAQ|n*2RrYS@s2I9PKwNHl|Fbo>lsMp82v%_;B|ft_x=9DQcz4dvDatTI-6nJ@dZcpiIf<ZP_@b;Q_7k^ACOIcU_%3MaP~o'
    'byFq}z8!R@mexR`WAFRcS<>n4PuDJ{4_M!zhI5L()9XgApMQALu`*}7jT>71tPy%mpYP-TrpC#mFOE#honqz74_9)3>f6U&R`0G`'
    'O^-|+&pF>;GQabp<W-mEy?QBcik;Js?H}A=;D{50XWprMcV3VF(bt0tMh)6E{L#wi?0LqNZ67>e+o)KUIj5Ck`;QDM_~Ko}@D2xu'
    '^{zdq<f>ZvvusZ}p|xwK*J1lB+_^NmQ{OfzXWX2(G}SYoca=+Tc{JgW`6cC-Zu3hFI$UBy?&kFyb}dt<(z^HVD~c4W9UM34sn#NH'
    'kyC-Tr%MEtGCYcAs66F(i&A4FpVG05ON?3?9?>*+qw5h)^Tv?4rhTuc`KeyR<}o*do6dMMd}Gt#5zk5QOSjUszvHy&<CC<;iUn~_'
    'Dd!(5Q0LPuzsDZQO7_sc)N(yRKO6I$_Vh<Ty`3M|YRba(=jQlK$#kauo;o$00_P2GzOVFCoX2VZxizkrCPpi-(@CqR<@!>*L$Z}A'
    '4_$wkrEt-Y_tsfYovwF@O7Z^o`)Sr&k67jYCu<bXGW65=p4D^JboE46pE%vke|Ue$<kdM{^K8h}=9G7-5m{45`sVYioHEa&m>Q!`'
    'r*fH7G~M`UuWPrHKV4UJ0CU+ephNa<Q$|1NKlNSO)uU3Us!;dt>8A^Vv!<OE5ZrWopWYE!ybA8z+U<_Vwo98{>J3s=o^xZ<G|!RK'
    'mb$ES4}LxSNUJ(m-yWLM>GEKY?Gv=Jty4AXXg^5buU?`1{qBuRR+===Gb^xQ$xj{H=YE;$=;!4{Q~B?#5%HnusX?B(y+7o=WKECS'
    '8RXZs`sDiVPa1g5IrAyi{%7IY@|3vfH~em%u90Iqy?XKST*S8O7jm`SQ0PtR&##^3^Dza7&6X~iZ8DvmHgnD5JR6o>_e2>-Eo)OH'
    'Mbs`==ek9<EbRMf`RCRd(^RHL;Qc!8BQ|Ag)Uwp;oIS(H<k8Nv9#-!$PU_j|(GdTU1tYemxv;zFh&Q%dZ27bM4(>qXoadxkHDTo4'
    'oD(J=zq9M@!V}}}cK@=pZKj9QuhtKHz4}F<^R6tdZryNh{`jY~UO(4ah;BbfH8Jm&LY-r$?Tv{YzjC?rquaSJRl290sy97zT<qbi'
    'IZB^h<`$TDPvJ#jYqzB=G%9tQ2NmZwneP%%qT#i`OnKg|PoC!IG(G%XI|h}UT_Y|iPwIe%FZYDnG?V)^w;Y#}kDdDNg8%d7ZsoIh'
    'w!75u-O*dA2NkMQwa?M=dz?nKdOqo-?P<;PZrXCIym(=)S9;ryJ5#T!Do?mkw^?rc-D~GFA(Cf{Y<V``%v$Wx$Sk*hNuE1Z>dVWk'
    'j4XOL<LT8W*Q#HSpSZh&)V%mEJV*1L(NCto4LzIsLEX32J2zbWa~r>5FVeO;8Ctk+)q?HZa(V1uU!YWni4{`6zS6#Xjix)wzS+I7'
    ';;`$_Zk%5~F*+`P&C4k}*W30PUrv+e`oN?254OqI`ccHe6K#E89XLyV(dJH`S?=^DTDEQWG#QIk_8V5}L66#}y`*TL=SBU~cbpX5'
    'z<Flx)$30=MKwv&u4-JhRT~O5l~Db;rKhJ`Lnf68TCzKBy_uV?p7QKfI*oaDja)nRs^T+ovZ)Og*{xku?#pnt`L;46mtLB3U!Rbs'
    ')2>mSx{RJ)=gmR&Q&h}IJvRKxy{*H$?yQ_H{nLJ1Q>K~NW^~x3E$%JTmD|vCL_;-4@ST^Pyp~s)o3_sU{4-C5rr8ue;+c6qbD`dW'
    'YocE?Fhj<D4vaf_zj^Md;d5J08yJ^1x0^@tGqpzld>t5P__3hkOW4Qe(|p&R=dLgPFPwUuwm|I5{LSCbTVBw=+}Xy110$}j$seql'
    '$IK$<*I%ypVo%!QGujNk9h`n!ie|@qO-(uF;j&VkbS_@wllJNGid0_)rfvN4QH5r7ZuF6xE?=95dz@Z1YHpq?H;1fFeRH%&9;dEp'
    '{qC=Lb2sw5&*@v^rq4l*Kkfeda#Zmi7Ckrl&C6!PkEb2{A+P(`1}=32sxRO6<d}16x3$MRcPmt3dbx|QKHTn@BJJ>?hvnSQv7sAJ'
    'KYMn#n=$Fu#1?Jx6|MK~;`XJT%dLEuc4LM?C0i9d`EK0kVkyoKu3C@p+k2)!QRQt-*XB;U(w|McKlaIt%s1zq^?diFVgDJqvi1z|'
    '`Q_=nB3>10_scr1xL3MV)9y5VA2)DIP)Qdyd353F_1lbg%RFQ9#G>gd*O)eZSvn*C`FfA*TzZ?VaoDc$gWb|xitBTx)!|cbwl^uq'
    '7p2&iuG1LTnVI$<I(m88xTzc5`%gI0GC1Gf+qh`)4}0w@wU?&r9enuSj<pw`c3;wEb8g?X1(&HOTNKnHa_5NhZdb0*r1aTWMeI0z'
    'XWOubjebcUV|Z8W^X_bc+WTDYOuG@(@y+Jy>5H_SG5q?+>{qH^E7ds2=ydi<w__#G_&&Q(<lfpD0T0`zucq(s+q7oEl=tcml}aC_'
    'r&28~Gu<a}S%-)Wj~8C4xjTLPJ#Cwuf8FQ7o*p%>x%68Xdewh!!CF<HZc284Mm6tIh0+IqX@T9}HC#5+`F+1hlZ*DPvFYSXzWeK>'
    'dKuP^in=s2{ou%<>(AbrKJY=O5ph3n-+Q{lMI&X2{LPPsy)JvF-45^chjJEBw+~7^`b_epT?W76G5N^LQd4Wy2%NaqWnFYcMEXN@'
    'n>TLT&FNs-+ZiKHe3@A}?d;Nd-r!#Qo9?{Y#k%n|Ly9)jc#2)6u4mqzP2F@MyLEii#L~SzmsKo0Ak*_aes40g2s=_aG)Jl%oi@!o'
    'it`8DK0n^2?3}7jr%qQWSTCXo%3!_S=NWdKZcMQ&ioFgtHcgqZby3E2v)ZE2`FFdX|CFKY^El6OO)sTi6|rfxnY}{Jis|w+Zt?m`'
    '!>=okPP^ljD#N4)UMJ#?w)myC@B0SLr`4a|<@KeW@`<f4_D=C@{P}of#>RPnPHxWg52&r~FThvG)gQLghQxMlRO5Y{&d&pK&B*vE'
    'xy$iBxzF!wVw{V~uMaCWEzHbM`p$fJ@^*;@3m14~(o#O|JhSY)`RB~$?q@PZ<?`BG<>3BVsotk(&|vej9_=zkF9~0zHU2qx_Qecq'
    '{C7+nvo>q{<<YJA`cr#*ZoUx1GR+!)z4|kKQ9-@v<PS}&9p66Ufm6k@2m55$Q8J?6;AS5)C*KrVa;aK>Uw*oId-;i#$E5!JWz$ck'
    'XLvX}cgl36z~{_?HOp&#+MKF1IB<CX6kWU4iK_Uq)<LOTv1VOU)!FI$G;`Sbd;a|jcdFEL@6Rz8A7vaEHKX=V-I~50$4a!Q?MGcR'
    'KaW|ln2t|2Wm90rft{SnjhpLruVJI%LCY`P%&GOq<FcSv%SJ42etU7Z?soPe{+ZC$4lf2g@E<qe;)X@z$MU^dwz=Le+o*cCxW!F&'
    'G;BO(@YK(8EBWRx4`QAc>AC;*d_BwK%$0n4RV{F^L3^itc<JQDslx2B@8(R~e6mH3nK7O3Wo^{C_RHQ2_BRh7P-WZ1EIC@-?ssYE'
    'jhBAD?Thy|8i#z$+T>pGyKhc}#*Dt&aoGE3>lziWKJ01f`dOT(Ry*#MJIo{NI3@XvpolHS&kZj)zR06|;lUf<$N9Q<?AU3-y4~4o'
    'b<H{}<I$HcZa?=Pzq-V*z!QsNKXj^Dc}h#`_=4IglW*K1XWcY3RqCNGZCkBbR4jT$;q^7w4yq7>Q=ICjAD`mA>gb|u$$R;YZt;1+'
    '68ctECMD~TyIG~j<6Fu1T%%uW$9!5jXLE`?edm{3GcT{LH0IN|oAuk2?0fx#Qy-SS{ENVhAN5k%a%MF>YHtmh5<B2}o*};HPx4HK'
    'yA<-feBCEaip%GQH_BEoYolQ$s;0>oG=vr@pX~8ZBRy|8H~g?G^<JsPgEgtvWSbx9dHn3B$vaPsJ-5H{cDH42<@I?B^X8NM0;hWY'
    'l;%{n6ED`@Z&LBiyQ9vJn$?+6t;Y?whGVvr`&727Q}|HViecFv^jI|1BiEfmt|J%hnLaAb!;aO4jxGI@=h4*T>!!@DahJ?pLYtR-'
    'R<7Q*)#)B@s8wLsl{+afz3cmVk1-(i^%VUoxOiJnro1@pxj6Oq?w-4o9d{4joN0uT<>l*;6<3w#qqDknZTq2Q&!*#DYBryoYF%rj'
    '9lw{n{z`4;-ItGN@7T7zy-Uv)E2~FkZZ~_>vVs0LYd&3D{_e?nt5Y|BSE_q8mr85<yG(p@wAO%3lW%xj>%C#-mN<5;@5-lvF$+#s'
    '%aO9usyQQFu1}uRphEJP-s8?Lc~>Xv?e|N*4mfu?%jQ<S)1JGv;?Uyk8E0R5y6IHmT!E!36)<`oI&(kb-t00@^6f~TaqQruTRUbi'
    '(@6d@ub&wmQ}0RRlGP*QT8}~Z4iCxd_oQvlj%{2nWslgoqi};8xvU<k3i}QHvgrDxt&tfDZG3R@=Ii~dPHT6w4=U6&+lE{>ZWg`U'
    '>g1SM`{T?$6Czvua`kC{TD9oFGZnJ$uD&l=9d0h;?`vh3>Mrox&}V+0%U&1n7Wk6vr)eZI`=Q$RZrvoA!>f4LUb8)Kbm~g3kJ@Ps'
    'KQ+h|cPwqlxQOg=WQBdO`_+hf(czW4XMP{KeeaGJt*4p8mJHd@`0zcF!}WMm_tmowjrT5Jqe{IIW$R_%!ua?Bd6WWYoQ+KbymFME'
    'Fz;~vzWuw`Sa@{P-4m*JzY2;=qwHNet?hQW%$N%^a?Cxg#+G;U?x2oXlVj!Esc!8iA5U{MTZKCflDTcCbKm9I(Aj6zE_B7Y>)Gmg'
    'Vh$e9*>1p|+ie%UiEO{<M*mJJj^<21YkJ>(w~M6gdF8YF_;Gs*s)d6}M&~~r?t9iVKW+CSXM<)j2dkG!d;h1Ev6G8D*t|E@vA*Tz'
    '_Z@aU<1g6)mj5y^XZHtQ^9Gc=R=w}zPrsb#bK;~gI^Sm1<QA7sWc;$F<Ey+mr_}bIzOUGb40)S=K5}kcpY-kx*4nM3YR#`zws`^k'
    '#x>`*p|^srjNIlstjK^auScaGH(|FO*Kt@}jy{Ff<lEJ=bIxPts*ZGCrx69J`}Nb49ePshT48fbyEeBLck>-5wLg^e<jy6fUD6%S'
    'SMPFU+_CO+&S@#<HGB2C`9_ynRZnG#X_E82b4Z!VbE{w8GL<*0N%AxIqh$W;JoWEBemBasWbJCMX;waeQs`Xi7ssb;X^k?tWD09o'
    'x=d)fqLZgY=d5!mZCTfJ7k%DL+uKsRdf?;+Jn3`E=}U@EogdeJ_4LZc&5lPmxz;IPH<qQ_*wo+8UR}TbjG3F=55(2mw5Qv}^PvTA'
    'pN@5Hy6#a(_m}~<(=8ogbUEPd+&B18#e0=*Ejw+Oo7>^$F4vytQTu$aUKOoW;6=wPo4q==TQai2m_aXZ@|Nu;MeexadSy(y;pd0d'
    'ucz*v`|xlNx;T15@#dAs8<k%~xtDdB_008Vc;u!JgNJ-fbz)qLs90^z)00hF?>N`t!^B_8jd;9rgX^<%wL503flrLgnk+@@k9EqV'
    'zuUa~p7}kzR~38dzxG@!*XP5g9-dui(J9%fXzw;H#+2Kb`KoqvMzOeYS#K;Hb<8Oj&9o|&XGy*E(hf6vA8OpeckG*Hc|)D#XOX@c'
    'Gkx+MoXd=U_od1L_hW0;6ur8v6*)E`yic}V1-jPkb>pYDQ{QLGb@V`?;6ry#gb%E`_ulxieaCg{GVi^|;Qa%p7Ctt^d$+S&lR4e0'
    'Y>XZ^GGq5z9X&F?E<SAGor{4(%i9IEx`*ZORm&}KyMLL`*%JedMV=dd>%E>aVHQ2;)ueXO`x~c!Tw9@@TX5ix+t)YTy_DBu_|Cz{'
    'tCTqXI!(%q@7gwKvwF?NA)Z~``kZ;1${aQ5`K$a5tFEZq-%M6w>xXu+>uY6uQsmyfL&e+%d|X~P?TPNs*QIGc=G8W@EIjynJIiiz'
    'C}!5XWXo5zcAIv5T=`0uFxx-sZvLud&$vhS;*GT9&{|GM3yezJtg_ps1ui|t=Xu+J<s0+D=l;XblSYrZlkr3A!UHxfyfD&rtlQg~'
    '16qGM_Ml#$hGP#cd9b|T#Bzg9rJ5L3$EsX^a*8jNbB~IC=yjxwd&j!%d$w7g^FpQU`})=Mn>wwoZ^xb6KE`FqJ-bCz@iqS4UXL#{'
    '`ep9|{&?lejgwCP;yNb!(zH6)tER|(c2xd>CoeQ;L;UY=&GPnv(~EPNpOx#fY?(Q2!qBIO0&~B5tf#C}eSPWSsmm)KUEaC3*;S+T'
    '4X2KSUhNA#@Vay@_Z;mnzFAeQb2g_=Gj3F=d1LmnEEhKBO%r#=Y?a|r3zwAcdhr2EioH%Yl{YT5_E?ss#m?r<SgYfe&bLlgx*fTz'
    'hV0%{I(aWmVE>zw__^mEPv`b?zLBd<{XT<-oVq*We)qu79$Cim+r{>-b(xySR?dxC)unXl30G5j>B+iz$4p-rwAo|8vr(-_7kdBs'
    '!}D1=vd%gF+P!+MShsZEwX-}QUHHq{%^r)sUVoUmnCqeTr^obcJu!O5#OR{CdM(OyxBuWlZ}v7W>#?n0ST{9xe!fplp3Fa`-=Mo&'
    'dM&$p$T{VS_J^zFx)SQ~>cPIeEv^I~?(nSozJ|pgMo%amJoRqarcGJ5Cz}|sBREgy0dWPdo^f4Mxp9&E%a-~Nv*+)i_v+N0+hcZ_'
    'EX(#=d6rDLH^FIE+nG~_H*9%!@(hnlF|O_2)(WnU{5OW?8SI<q+}S02)_d-KePFBK$)=-o9k{#s&<)Rw4PD1(>G$Pm^~rgw78qUe'
    '{=&KMo21gG9o^de=$Z);`%CV<bme7S=`&hfXx{$ocgzawMQ}*h{jJ}=Za1iYt79qam+o|G#;jfkf~WS+du(u_JYJ9HZt`H8OTFsf'
    '^QSjA20EW#;&v!^>Bt2!M$^2X=XGg6AXmHLRaWdgkoD}aV-G%DSsg8v?4H)`Xo}-AR_B`=+NtK+ytTeGZauR6rnX~u<)5#Ns<!S#'
    '>55+qug$b*ZN4iX=H4FDq<7`M+G+Dhx0r3cxA^aV8-8+S&z9o@M-^%8**+|;%<5qUl(Tgn9>3E+)yG~DyDFv&&J;axh;z$MMsd$c'
    'z2c-=^9tXa+hW>UDO1(m8T|H~E!FDgwTQ3nvt6k)(Q{>A|L7*iy?SdCw08OOs{QJv{q!i%<CM2&>u1R><$RUD@Q~$;`|Qiutz1>-'
    'cHJfh4G&$t+G9%VSRcOw4V!g5Qayj9KYtxwyc=^HH?h&Gx9Q%i<!Yy1-Luz)XXo=&_%vZ?{;h2f2E;|?@K5oj?SZe6CGO>EJK^-h'
    '7XhuFe{J+r@7}HR?^)N-DQ~at&FbB~xMtODlJ``B#p8c&?xa6%y|;|}mJ9ixZhiBBx9;)0Y3KD>>W7@av;SGO65D?%xiZJ#!v{bR'
    'dSSO3C(oWVI()fXvU|HO+Z4BheLA?*+qNKIttI8|ymRvEH@57@Vv*NR75JJmqV`GobhpWF(UqTVtTM6L?ywF=hIx&?X??7gvE$Rx'
    'IqP_|U)rjSUMa`YBUw}X=iznG{LRE`i9YaU#(a9R4;i`-IN$%5g;xrcTK@IW>a?faYQ3!0dYISlR;xQ5*j+Us=(*akW9^+;^XzYR'
    'eE8>$Pmff1*o+mOSwOMAe7G)kw>R$X>(nNvWq&@o&P6GT{bSE|H)>6BD`4jSJR|ka4;gp5*T3YSrg@W3i;A9$Y~G?*gOFDZPAq*_'
    'VBh=Ur9ZShG`sAaDz6T{yRb8MaG-O*j8D#W$9i|T7$O(=a;vhB(ezTb-Z=(_b=Vg$#<Se^Gy9iZ7~SH=`*$fvG%QHwSp7Sl-QoVo'
    's8w;!fLSq>Pd&L(@8sk>o|!IH>Ur^g!981x#(bQ5aqF^V&Qr?P$uhFW%>ikLdv~5t=1Z|f=lX0Zxc^Jh;b~4b-_)RBi@*yP!wRJ>'
    'ar4>5@Y$@Mf4>QA)x$z5x1U%xeeSNZffXk#3vBZR@9Xt**UmMvH_w!R&dSIwX$#d1Ex&%@kw(>n`#pYJp_1C8xAV^RJqu2GP!|;q'
    'w<G!%s@1hc^Lg9THO|wv#FU4RT<x3h3uo&4rCP<eV<yB_syM08vPxg}IUi2H?{uaK<u-k=9}G+Ob!GM=kB*-2Otdb0I~UGU`Ij2Y'
    '{C2OY`uzQXW-|lJ483--(&Z+N@{Y@MF2`%{C57{(x&A6-_)fb+mR<*E%GWD&Ww$<VR@)q@k#&u__(QwGUZ1z^TfDkan~ODndeU6q'
    'bZupwey<+&>=HWSHfufiN~^*?15%bqGfzLLW8aeLi_a>ycGVR;x%i2q8(a0b_i<^?!aZ7U-`%rqtH=^`%*Z!u@;BYwYIV8MTK}3|'
    '4+ReC>2|kp%<HS+U6)@wf33ovOuaA1F7Lbd=;Lixj`VNzn3+|J%q%>6;h}!bv(}%uxOj%>cF8~N=;^V0z|$62n|Iofc|)cN4GORI'
    'T@tIdSTc6Xyq2przU{OBX|5ApeO;Q(c|k7^4t2U!_{{X2{Z6@G^g9}TzJ)QUN$yEI*o$fvCJ$M#V|Vg)w^I~;xO<}epl7^yotY!%'
    'Kg+hEWpk%S{WjDdQZoJ2O*2oteqIFCZF}bqS<(Cv%{3=1Lu~F|M|bYdo33ZM&t6kc$IXo`Qd90eX(9?A-zY3amCZ%^yox;&_^_;R'
    'mvtN4c(gmV^LCN3-e2$gS-aa*8@+#_c7NdOsWj{8W5Zl7Utiii+2{@}iY&Ubp;3y!%5RPb#4b6O>GqxXD_WGAHa6_tqveJBG`*F!'
    '$lghr7Pig*eCy)(J$4*l*2X=q>!D*g`*^fjJnrWr722mRa(Y~B|2ru<+>Y7bE!VjAt_y}g*f1x<=ToC%`&GH|CO<CvOP!mkKGa$A'
    '%lrH>v-U?Hdiv%|mIi&YM224qtg&Kpsn}vwKYz~A-FJlBgg!f4Kg(X+JHkWtUa?>HKb$>d*s(pRSnrHE*`hIJPM!;Rbu@4EmmU2_'
    '7TEZ8^Oxmc`<KnztaO@UgV!&ppSw)^pr;RVc(<&ur2nvcW81!6&~)>zE$ZiA>dq>*sq5Y42X}8gJ9|&nW$81m+~qszMRK<XB}y*n'
    'w9nEy9V)gh!~I!y>ZdoJU%7Ma%*BrFcIED{V7__dPN`kWq86`FvAq?-?mIW#&~v`W<Mzeg-gFz#>)ppd)U(;?`S^I(r{jt@+L&eT'
    '<vDr2CT}os+J#Z+w#-|#`^3??y>QUa1Imx-5>dR#sgs$fPhWicqPp{JqpwSrtO%ZR_49%~DLdb<_pIFuyLf2YogM29_FFl>)brRE'
    '4Hx%+#YUbDvR8XNIdGZo-gUWnpV7WM{9_`1YG3^4jOhngf8P4pPh)P^D^uW%-_~MPM#dH&d^CmRR4?l0hQbGLHM(va&)jPi>~tdU'
    '*m;k#%1?v36(3Wv$$?tq4_0p$w<h$&l8$=^kBJNk<RA9jpLDTvpXud_@0@gG%POl_agS;<PK<3_YT(unQtat*pRO03J)pzAlA$HC'
    'R><yh?)3h#QBGm&@0%kJ*0^@5ZupK2ZP&FseeT5iEhVzezDEM2W;0i`4DPga(x3^a+onC%^kl_jGrcNRpVH!Ri7FNA%?`SG#3Om='
    '`qrLn)+H}<eCnL3!<Mt)Lv1owJU_og?V>81IpV|c%Tqe;``oDT#Fw|`tlb>3pl@;4K<Ar}Dwde@X5QWMQExw24hVdd{z#$udPMGs'
    's^y0b%(&?7Ky7K}5^H9gF%fl&_HE^N^Kr9tC90%<Gx2eYUhSQ#M(0X(1l=pKJLl8gL)I^gy;9;`v)cZ&K*ZOFc{A<Ib@{@!GESSH'
    '1(&$_aoOm_L3l*V3fn97&;3iE0g~&KVfQ8$E#0x-{?DgL$$YuzIY~OLzjw9g!ogoXP4}8U)h~5VwP<+Vrt`+$3@#bQG7P<Wa%j%w'
    'tje3+pUW*UJGnY<$yB#%lQ|hL<PXbH^5oG~-6HG1Usk;1_+gE@ypivw`K90cvF7`>p%?P@FE+)yzVG9&_4Cv?HM~iN22*o4sn{S*'
    '=o~Fquj~ud;L<rJ=k*R-@7mfZaJX6P<uyw=FRFZPLXj@zKe&gTp0~Ay`!TOq-luDB3PfRf&19}uo~QCXyTE<X&7YSIEwOuU)%8O+'
    'lC9nk29<rBEP2)GqncDeZ$CAdt`&1Dn9gm3)4dfbbCp=|s8sO-cB&2iF5YmNTh?fBZAtU@Dc0<t_qfRRsjtJI_Z+{dRJ9j9Yro9A'
    'dSCb9ONR7#{$NIqd{y#Qjk#IsVa<a>r{!o=YD=Ht&(qXjqPL4%>Az>I`$v|l(wvkJUJV&Ce*KZBdta5>Ic!Scz}DSstp1SqS=TqS'
    'E__+sGcecY^?O41&KX^_>EKcy{AWII;S*TC@`794@4UOdZGV~Ti$-UyocZOIi+S6QvVE$gjIEe{;<4!J3u0mhIyb*N@ATNEQH?j('
    'ep0W0m5|)ke7Y}QGiBn=!qp}$ug515X+-}cg_j;Xw4!g=y?w`~?c3sWG3(seE#2I<t()>>>ij8#>gAqa`9tMH6Ph20DRQml#4IS8'
    ')4gFopKn-kS?%`pPTdAwy2iQmI+g5jnW!>8;U_1}LPf^6Z}xK`pXX^SwB0m$$f}0@mw49icQ0_=qI9w68x^{Us<z46<=Um9yH+;q'
    '{HeC{ly)!u16yVu+jBzj#~t(Z`?pZ7!!cufUOG4V$S-ME__P>PFwMv{8CofQqrXmGVm-fD2aR&xdGK6bzh;YT?R)BdB;0dpxkc%l'
    '-#@TpMB@Rzll@YmLoc^`)DP<>m3>_NMwLyq=Y~$7GdstYxT2-3qnR&Uz9L0DeK|Zu-M2%#*V)ieo$h?KfLEE9XD50$VagRUaqWD$'
    '%e8!sSDddl;anZhOH0yrJkVn7GWSpS-wo;G_T)^>P1)pLY1#TcWnWdw(7#@h$uVcYs2gh3E4e-8I6Jh_*M37<$x|=5q<*$5s(b8d'
    'AKwL08Maj$`#xRvb)9eBZR3Cb@VZg*jE(2>{Z!##miblMR@U$5+Woj#&Ibi=KkIqgqte{EGxE!O-ljJ1EOZ{{?HipYCUViv%kST2'
    '3zYUb?;Pp3DP(Pwe4_rj0#gfIkL|L3QrV5iPrtZUJ4=OpRol+1dZqHVwlmgY)O>}@i%U+$jtwarTcwQiA&<75j#YEY-gIQ|r|x4q'
    'dE!bH4kn+wqGgw-jXu^|zvN?v+0UmobUPSjULTfRJM!}@-2R|faQ8gu!@7~xO8FTN=lew#PrZ3vH>I@uOQ&P$JK*SpxqH_u`eend'
    'O;vi%%sBcy`Z(L;&YD&8lh0kN&h0)F_o;RzV?GbJQF|A=uCY#k{(7Nn;ElPtR<&>Fv$u4I{AcildY^Z8KG@o4d^<m-;r&h}`ON0q'
    'Gr0NuwCPUet=H1t!G{lwEU|rii-3b3vyImEZqq)~%irWHJy&fWY8-m}#Z5{7cHFv$Pdlutb8^n8oIVAQl}PENlga&x)wz;)b%%gg'
    'O4*lt-W+zmOQK)(cb46PTek0*>PpwOs|!plzYvcs@?5DjBKx$jZCxG~?c(fns`btH=>E_SV~?L(wC;3+I%$i2Rklh;ucU47wz2QC'
    '{ezn>zNltDOdtN-D5iML+Lwb<xw|U|yAtn5eGjJYbEw<vw_6@56Wwa(dvY$W;frItvKOr};r{^-K=8jcEOi;C63Tma$<WbBr2@O%'
    '1;OM{FWbIHb=GqZ@Vo9cF6|3$vJf>BIUEUAKeGY~CMBjGg-zWP3<OtH-259gaiBq87Nb}p{>z5fJbutPitLky%1-dJY5eXd%>LUo'
    'gvg0v@1BRTq^{HDyitzM=kEz0Y$$J72Ek#a-ns%csmgC}>f^6V8g#a;7+z~~Hv-gr!R<l!l`HmtD5yy_sze39(bWR$MghYNyI>2;'
    'zE|kW*{IN={fYiWl<bu?yEB)5nYD{izX{tBjRzQcKLrJ5xXexPjth=-`99M%);6JrIOxM@8QRBK9WN4uyH#1P+)NY{!~>}mnwmW|'
    ';o_=_NYETuF}3Qkr|<xM+e=||>5F5h139ICSIjmx9$^dxanStO^n`q0Kw9^lRW8MtS5&3PDRy4E;Nem>GHV4P)+<t%7MTTzdu%bG'
    'TXZ=SiD?A3-l%^`M}ZkOyae6vET@Ag*133zxI7B&l{~B$X(VJ_cGS4J;II%j^NwaI@4j+n(xa{V>%@HneSXx#L%EhR+s0Ih{UFXa'
    'Gg!ctXnaZDZ_=9Ej$^v6rVq?XLaqL}s|qs*ojp}IOt?g`Jz{iM9a;9JO4Y8zQ2OX|6oJ$H|39W}CGeX!W<N>U;Zt#E#xMOlDHn3_'
    'b{tkM9L5_`<g`50B>QVOXsA9`+B{cReqbOBw`+}55-ibrBO)%{I6GooSa<0-0=8igY7(8ZHE_nLku7vCi@2j48YZ)-HY>e-E!t2x'
    '2zNS`Y$TG3=%DUB7|>qu>q1fI)83MqVMqQebMKZoDI6YZg$m5ZIw!aUx%@5!nb`%pWugmJzIk)>igwUAHKUaF&1LX=DzTMe4Up8u'
    'Iv%9-#h)GF`=m{8M9l~|V$LvN6Yf12lKg7431!>u0U-}2>16L~TodPB?2|}1b6LObkw*XfR9KL6ivZOTv*^Po_jEO3eAf$j0OwLT'
    'g{>-I;1ZEQC1U<ECd4FgZ!<S3r%FAm5(xg*i`Fza_K;Tlt7mu)H2Zf7*KFFF!i4TwkF4e`Kp3FkVz8+>8E+VvZ>4JE#>G-2xJqNJ'
    'mS0q~{n!b!p1lHbH{l&QfS6MW_z99aD&xQ~(j9s_qR1n{+>x>$Cn+?&h(u30tBp1LnFZ$=Bnug0|ArsClIdvcf$tslH&`8eqdGr2'
    'LZ^~;H5^WpeEK4;hzSX+c=DtNg_a0ALg0T*5Q)_~M*j~M`qI?TMwj?OpMt@LJg}S4sv54~0W6!DZb14vNsA5;$<HRJ%d7iyb@B#_'
    'aGHtVc}(qQuoCBvMG-$bT3xJ_5oC~MhL2`Xbfzzw$`tf#KN^qTsp=fPFI}BFXeS)^)awwLMOm2}L$4!$j`16Hbv&+=0!u}FJy~`-'
    'eM*K`L%~3N6a-oLRW&H}$lR*bWi3C_R)6pHQjwH8gh0)br^4Y8q>DIu)PLPL(Xl-^mi!cd0~VL?32q`f+&7p|u(!t~%AGJSS4@By'
    'fp;v%RsX(Ns4t1c#sj80?rCv;q(UvN9dqpdTii%=uDIdmk&4!_+-`EgXJq#}{lV4f&7sJoBD@_}#sb?tz-0VSME<xUtQ(GZPn35%'
    '1kM~Y_frA>Vr=r_c$26Cf28k{86;mPDc>?0b<GMpJ`{;+K-=(-aq?L?=)@G~8-5wVGs0s#aS@-02Ol##S``5LuQ>fi;^Y73w6==0'
    '57}&ZhS>xR8l`rc7XGz6WL5iHU;{n|LWI*u1MUnC^`j7FD<@0(jATw-i$G#KYS)<9_pQ>#*g%;TtDw<N1jvKVfJZ5o@sj+QZo_;#'
    'bzdQm*Phlq3rUA|Ni|*5iu%K`qJN}#JhRfg%zukJfC)-_@Y0@Dv?~l&7jK@EOB9wty$^K-NA;$e1Ft1J<XWwZ76F1uHj~<CI?rg8'
    '1w@$=r0t}%uAW((4t~r#>iCT$FI?$-Y5v1CqKT8);OH8-#hfm-jAZQZ3bjBy79PK}x@r){cJEen!}U5uPb049=GX>^_5v|dZmtPD'
    'helIpv_=EuC}I4)b+df*albcyutfS<54cM&cs?*Zq3uQ$=&Q~o1s@~!x`w%x*>Mu3E|!9x8IN}~cFqwz%T+%I-Ll0tE4DsK`7vOV'
    'PjQdX1wkP0f6+NExKa^4O@8n2FtT*&zR$4=3Or6?#vcqf_Bb^J$Q5j8PBtn%eBrz$tI5B70|f5cwdEu71;g4|V+~E(zHDwyN0I0~'
    'rB(RJ=7qM#WLWGFG^(JVD0^4v2**VW!bQ2sE2qvqrETkul(Z;^IqZs##Gm0|<`g@^gALiw2ITh`!hd%??XKz)49qW~{oayC)Tr*t'
    'xS`jO-P&wQ?8k<?GdqhuFb7O7qgpk5<b6qSOV`$3I+M&NR)heNgqm)~GB%+;LL?JkUm3aY2=zs(eQ<zRqXXqMDB^OvtuV^eOCAtD'
    'WI(iOH<EQ%2r(l_1;Hv>h*TF_xfaW%=Kr4t(+m<mf!|{Wgim=*se`fD$b?-gbahu%9B(&y#ACjSGnA1&jg*#iT}|O$9O^8Fhh})j'
    '@@sr?Psu7mR-O|}u7ox|kdnzMs`$<1iU;!*&zDh4L6ogPG@#(R|70%4xhtqXsFm`7`8_Sz8RX`q61Yn_l?std*q$Wu^8A2KCqIWi'
    'svUUgQJWTam6;MVDV)JLjn6e$+qKo$L+(mESt8#*17i8Tg$azpqG0ddL-V`v=l_qZry-)?>7ragmfkBrEU_I_h_<_vKMmv!$35c!'
    'QrL1atGJ?Cd&V)W#0C*RN&v&%tB}_UDwwt4M-%s>*hO6&n4}+nj#QiyA-6m~Ototkf03ZruPQ1V*0zyJFXr9rQ`8hgw<+qHxl3I?'
    'RnUhjAErTE$;2e|YRt8i!a@keAE9Kh>6KW9dm?{7ZW-a5?DJ~n-XB7692*tdBguaDloz^qV=bzb5t#-*x-gj=czXy&P8X9!I1RA|'
    'szfyXMP1G@GCplrTKK|0$6*F2jJlpr4tLt7o-0m>Z|@jLLp2fOjJG|wJw*&Z*S~z7KFp*`#y&Ut5LEcsb#{=rwFmy~0BWXz!Q=2h'
    '=RBD1On@DNNkKtSimp5KK=C5flcRqEd!`aw-X$MD?Mu`72*I6$RlAgmb6&1{(x^EUN;bVp@fv7JN&;3uB^(VH_zUiX&HJBiH%blm'
    'V!=v2+wQYpA8}n`;j_&^bjlyYy{qly;s-5u^6%xMSIck%h2-tliYJ2?tM7I|xa!2!_=c@Au{kfm1FlPW?mAL)eIwlOzggZi_!H(p'
    '$ni6Ejb9Oi;Cy>TC%8K3(l|OvL?5@5*_FFH#X*BW(j6>e))->r!k1~%A_7C~_rJ71xw&Ztm)&-s2g(LO@WAf9Mxa<-mN$}}soRpd'
    '79}vG&x1%nD?^<g6qbQN^u9^+^=7;bOjvtC<Ys5&8@9W~QuzXoj!>e{+V(O*0??T}gWgWx+kg{rX-+l)bh)jaHX}x~NGwz2vktOB'
    '0^^qvy?zZThfB!eR+}YE)Qk3ZnUZxNDE6TYZ~VGJL!Qf6`Baq#HC<t16b=%n3@L}y1@yh0T?{QNe)=Cm3jskIAa=pFH_UxP7Mbu!'
    'Au<@b_ZlVFp_zo)iqn)r6-t*sAF;88MuR0(9TY}HV&k`m>}8H;vrY8FF~lB1K^pP*k40A+sTL(tQG$X4p)@n*dq$q{W&>ye#Br=b'
    'PB72v+A{Z7i_uMYf;&nO?ZC6R@m?{ytMtXe)rCAldv3CpJ``W_#$*4v-2OA7G~kMzD>E-Dqar*UA7{csna-zZFkdjlhVwl}m=Fxk'
    '@$nsMKQK|ScK;f5J<tb3BaXDqedBwzM6b?cb&&$tbY%l}S+oX3WAQyRgM*7hE29<pGrL3iN@X^9Zi7a$d5sueFi{vb){RCxkyzS8'
    'G!R~m+`yh?-V7X{jzuXEqUlQ(LaK8xjIsw!oV#{ILQ-`IB7+8bxO^1W6$+bqCIHFS^n;rK1fXaW@2~emNWEMZ*XGwdP@JUg^(s_4'
    '<)q0|d&G`n_i$nPT>EQ7PkA9+le&M1#T03j!NME5aaY2M9&&Nu`y{<(Z6-8BY^}ol9iFvy=Dv+u#mCP47N`pw3Tbg)&>J+oBbtyy'
    'fXDqYy0ZY17|AAW`Fwy-nlSHw+79No!z{QFmZ~*FmUj&8!_3(t_(5}nMbGd2XTDbM9-{qS;EqYKTzB+CxHrUY3tMt%2-=W#kfKaj'
    'Wpz}vLv@0`z|7=N?xLSWWC7q`^8x`>eLS+vx^4TN@q-gSX@j@o=!^=^Yf`R6qjggML9_7Nyc5LYKSY%eDGSa<I9C*X&?Rh2v-bK#'
    'x70pGZI+x8A(VPc(7WF=g?vXbaZMrd7K}e!M9=9&+fFfG4~-Vny&iV8{g}*iESwz95V$pRW5NeKJ)<*3=V@Yzggpj8|5ptC7|NS0'
    '?5`3n6cl{Sz;1f5@p{`uCci2lp$ju=@Rm&@B6&UIN!bItcof!9xvXq0JyUl@gqSCpbGXHX8TxYj)~1c}OvmOFgQ!%@(BOfC+QZ&P'
    '4(LC7yqidt=LQi}xh5!xZ^MddrO#Q<JUaNRBCn-JF?W*H#AIbMf?Y%EP2EZ&N)1Ybh(~r?`cn6tyGO1@KC*w2EE-bm{oGv}yg1Yf'
    '&AxoZ$ipLL*pXc~N<c?OQbi&T{!M1Yf!e{_bV7Ms4OSS!snCH@TO@6kyk?q5KdDp<*8h~y=v5fCwsW9=p#IrSN;wiD{@43MY&)1o'
    'TvdFXE23qo(V#Is&QP7||C6r%hrXF6B^a3ue_shlfgU6|I_(Y$sBV~42Hwk!86s-;Mq2Hf*IC*Glm8P(;M}>ubtS*=U9bx$OEFw!'
    'c8D{(%#{t~MXDF4k75N!;VOP$FVxeJfI`b(UY+Oa!Tn0}Q&-~MN`*N(^)z)z9h9POmpYX65WReg4>AhSy1Ra6>Y*DNwdUT!_hZyZ'
    'JK@16#mMRxTFWoT4l$u?XAmlH3`y8+m4c4Unsn(%Jc%@j5PL7t9O|r;waJoSGMhAUA{2(f?pFmYx+u;_Y`i%PtD)*DF5u%{{LCh('
    'C#BTlW2jk9@dw&|NUt_X$>Pk>HR~7pU7CaG>ABOD(PjkIaw7RyQL@CRLq7CL2!Nmty6FT7JQr>QwcuOq^hdcTEmT2sA~nKJkR4-5'
    '8jV3No<YDKuIU}NbL<G0e(Ren_&hX$?<aqrAvgg^D+l`Qx;V~PLTQ96Sllen5tSEsEp8C!n$*ehO7faXGZDNO^MK^AHIi=67`yUx'
    'o-19?ghpv;3#H?KkqH1vLo3FbI9vXsFTkdmkaBFK>&0*_r;r)amN6^?g6x+`NXWoN)POeT-5x7>Bq{)_Ovq+j90Mupf3hWJtIwfH'
    'r+z)i>5Y&g_Ky;}0}6o&ub`cndLO})!oHGOL>)>=$S21qf3AOCF5)OymOqI?Cj4T~blbDxV6zAo<H8w9(2qsC2A$cDs6m}pfwlsf'
    '7<)-NO*!&H@$%=ct!kG_BidkzqkW{I)eAQ^**TXX_szbSi_-Qmam7fh=Hfz1GnZwdAIdDr-Re+=n)n4%!V3l@vh#;@CK8D%WI)bJ'
    'I^Yqkv?1gU8NojD-F1@oJ*%f&q<4J$@dV^2vI)9MPuq|Nt$3)q?bH}?vB8kf+;xRT(J)coY*pS19xK{PbW(_gG-~KwqGe3Zl{)Tk'
    '<vCtw5*sp8j!bhSKzQp)eUF0Gh)E*2hy`z;uU|;#`)V|k$-fb?RN9dtgRYiJf8}AOu?8<TX!385>usiM-@7QEDOy^`zS$3{7nhz&'
    'lOk2&hW>|jTAy<pFFG7|*N1?tKY;)3Sw88NXj!gGuy1ZR!(0b>*fXOSoFL7}6c9pU3%F7{!3t=ZQ4@Dcy3s4j{Z4`{56l>XuWjO<'
    ';$yw$$lmpof-9U>>TF?3%WQ49aG$6&(5v_0yPtdTa7nD|j<N#U{qsmi26WX*($oQhOJF^{bZdXH(@Ce{kqWGI`ga#<h^E%K^%4n7'
    '8zY|t2$;tcW;jFRo28>2**^z?ZPP0`08=6=4_M|)YuqDU!u=Ya5Ld6aARS@*&-fF&7pAR$xkE=)z@C#!hYzItm7x9JtgIH1A)0I1'
    '3?E;r<&!m*-|!W-#=q!G^72-=?>1<~T+Qp<28x}Qt6-oQz>BsKrYED8EJI982RnZT71m(vnEQa)y`oQxYXDjFsd~gzSR)XBgkJSb'
    'GD<J0U{QG9hLqz*Pg=wZPG|t!AZidd9P1}OeEBd;HPc25BnEXPv5@H=5LHj1X-@#{i!fhMiIQ}_@?q>uNge>KuYd+s#-fdgG625C'
    '$q~%BLi!n>3*1<c^uvlwT1Gk??WJ0v5%+o8=ztZL2Qa(^tt96r7<iBBUBW$07u{HlTGcHJpOinH&0%-%9>w$T^`%Fv;Nyqtor-2n'
    'S#BU9q?^^m2{1P5;LrQ<h!U8BM=u;qE~9~=F!sDnZh!;EN@L=2)^Nrou4{#OMug{Q)+O#?GkRi4z}RF>bea89W>MD<bNhU|`G;x$'
    '#T|-3ZX3uCmaSdD(hc}cpi?U6F+qi4UH^!*D5RyM5fvNjLUUz!l6j#D_&l9WsvP6eD>5C#MWzrv2=Y^X?$w|fCAQ6za6tj$3r2`d'
    'td&UWtX5&uYLhu-6;fj{&Co4zvvuWGVD&HQ`*HD2wQ2Xfzf}sUF}`!&*4^u}s$m)AOUo0!+baw85nTUG#i?9?XEdAc)FFDW{@{A<'
    'nhfs{$unzsl8P*4hDw}G;^{pR)8;VuQ)uY6Ar69SL{ZL5MRRfne53rd$Gh-OC*son`VcYAvipDyi_;Pxe0cGI81N_>;z@}*4~2G4'
    'Dc_fKqP?8X@i)Ix<}dekU1OIFSkK5hHQb+907C*!NMt8HCjoh6ZoIUp5sqq%M>mAEYFdFtu}P#$Ig;5<UBsiIx;;&Ezq;WGXn@L$'
    '`h}Dpx81Wr-XT8o98I}Sb53{o?G=x9`rz^veaGSrRoT|Vx4`cJQ*qK}eEi~0r?^@sb|v)7oe88oG_cR6-)ANMrG2#MSvJ|wFHvSr'
    'ykPKi8cU<%=z~OUO|t`__u}Gp^rH561Vwx_wX>5?3!K3tA|^Q{744<W_<*DWLCjkGjcxDCtVJMTiPmFJRXOr{;TSj8GTHD)bF++V'
    '^6VIo19eG|5sivcD;fn)bFC)@5}u&iE-jn=RmA;G4v@005j^hp)=-Oyl!Gcy`C<`c5SwXz>IVKsNV6s^jy^!(QCWNI?oA9qRrp>|'
    '2X2SUF-*Y)c?g_ozOFauvARu7V)GTxXNN5TTHrrW45>l`CO9z&W_*54^2*y|#q^hPVm9Die*me}zvNL+4F!(x@m*EH)%LszIF%c$'
    '#{)jx9G~%vD@n?&?@abkBq*QXUoy${geiT_*6xy=b<!^l`)7h}thizo(s>wAC9oV+*}1z_l&135$==X++*J%MhuS*N%Czs-LosVm'
    'DV{C&tct;xq}&6n=^hhrDVEPSg3nSDTSl?tPs6=XGfu^Vy^!J~{jo7G+KqltEE#Zsdc74PIgfd89h^r{gi;58#92oQSL#THfF<py'
    'fE6*ZHXO^1Y`|U@NRO~l18T(+RZ1h(g5a0HvTsGgK0>QE)W2M3@H%I7@KC2wW)MtKJq-mqc6F3g3@nj=@xZIOnSLbpzA*Pz8fKeO'
    '!56`=zDlVVjYm3%E&r{|IUx>fZ5)`_yJHTnqBD9@5BVzI%zsSN9D4<wUZ$j&-@WO=%T+P^m*?K&m!MKoaBfDx0ykXgMTo{+MJ$c('
    '2fR0dSf3c{T7VCQRKCAbauyVdc2$VEJc2#<B-y0%o>rLB9jETehO{Srz=fz%bOlGtrX8uZd6*{{jk5n8gDk5jI1cHUa(w4gkvf7>'
    'gq)q<uyrQ7QY8@9r(h(!?CTY=!MQ%Q%Di*UmE@mNll649%Psb-<@uGLHzvWjE<}TcD_4`7{S@?dfN<7RlA3<U!MqxGzM@NQXj95Q'
    '&HEp=)vnKwqGPJ0b8G!mq_0@-jK38o;Jll<CtsY;Yg=$2O$5%M_;Y(D*@vi8y*I>Hi1^_`i&o}R+@-rbtn1j$U@HI|h4eO@_yxdI'
    'zsNY}=ZLyNtN6rx;DEDIyd_!1;a(+U_;4KSS4JOH9cC-`jME;jSzDsQ4s$ZbAYd<)6z72M;M<+Y{w)$zH0!Nu>Xk~!XQwM$*I&JH'
    'y|uK$lE-@43+;p1rk#USaJe4Fjr`{&%vAc!=cK?6z9Ft2Hc#yd7Y>9G{CaLw=4%vu;_LM$2Oe{a52k>AYiJfPiCHyB<P{vc00a9~'
    'Qw?rMEWD-zQMv=ECl>c?bLX-XZ>_9Oa%BG1+MUT&UrkJD`VsH`Big2ZC;4qz7%DS~wJr-<KLaVr7Qq@-g2wLY4lQmZX3K_)iKSd|'
    '!JXj=2WikWD>jxiYAqjC&%kgEf=ZCBwzfxk>4B7`Nx-<|p@gEU<|lBth~$t~Z;^pTgZcnKu-EPxBk88{8zv3?i(ijrY;y%}*H=GQ'
    'b2VzXSC1IJ`AjF}a?UR1VxR4yz0Y^cO_kgor(0uId^CV_2piMtMkJE{CTN%id_Re%c{dP7hlfPT78QY3kiUkZ&mTqrly)*XqQAZ5'
    'T&n;LFmqk7q`MoE%}cdbkr~(~HW!>Kh23tU9y`Ko{9gmc$$7&nZ0{&c*?|RCsC@ocGB>xq_AJ<WL(b@A&+-rjj0s$zFo($7cMTX;'
    ')pLgpLp$s(gfE0ScNVW+DPxY@UxR^fGM>LTCv31+3I{xq4E_rP61TT=)yJw>E_y3gGI@c{&tl3KZLkPen+Ykd#TGb&S-p@U=_Emz'
    'eFms)vc3@8MqWc69vW6xsKQT*OZtB;cGaxi;C5jDF&DXKzK{yN%WY@x-kJbcvui%Z`I4(ZwbbAKZ$}zGUh2kD83+8FA`kBukruO8'
    'xfbx+2*s@bR^(pd>lOC8WY({Sci>G$2%@820~EPe)}cn2TOV?jH)PzkvBDN%pgQ~Snvm5b4dzaL&Y|;I0UM?<Xxmfk_>_!zju8L<'
    '9Rvlpg0RScY@#QDBr3UBCiU602q39s=?p>yHr$>a00+04?vD(YXdPmfWvl{NT=TE|mZRcK>~5q5Tw<`hnc!2!Wsl%I|8Rt@T-K0S'
    'V}F}Pvv|<UR1D4%pI)NG5eAl0`bl2nme&@*!3;xKp}s=*VaylCOF0sncP)Wt?FbK8r?0ot{R2kHtcyQbu9lJUQV0N!b&sd0A;kI6'
    'a9K;CEsCobPqv`{$;il9udIjL25oYiSIToSX|NYrs?CG=v>wZgOsn5`DUf4Wv8O9c;B=-KUVK`WL3ASz0@(qWfj&G|RdBlM=hQM-'
    'y%yMbK0GG)h1qtEvHz^dPrn3-^QW}YC*kukYpXL^27FN}@fE;XeG1nN(U`k$K}J7=R-bOpeE}EqCeCwN84IpNe;8nh;7U_qvlzAQ'
    'duK)7+NHOTxBy=~R0u&?A0~PR>!EhiV1O*0vOkSRLx`KrceDcd92nzYzw$O&g*q)op6qcd`Lt}Qc88)qL?tT2bly3xNuR(cd-l#*'
    'h?;Gu00cZ46|vD!AofV8Hf>Vf;A%=Xg6YI91mN~rq!?@=7qg~ube#_7Y#5Lr&ekJG8`e#^kslQMc9CpZrxnxY@`%?2B8caumB|n^'
    'Xf%rN<A=8etWFeG_0^kMu?ErHwRM%WPtRn?sepy5j!-?dK_WYXf}FfQ#R6bi_TdzN3~o$}WH#@vyEtb)3l>{M{55)z{IfK2S4w7D'
    '4*(`R`eOnt^0gYR3R`hDM9<MSt%x7|@o}JIs*{vjDmEw41MrZ<jI&<v+IC*5uJ5Q;%aFH4G{v5NjDHPUr4LSn0nvW+?O3lODN*`8'
    '>ECXAqH>y^ddODBF*t8pr6z5q6X9UNz=0XS@D=Q$bb~T|)C}5e!W@xGW6L>OtR!2!KDC8IFT)inMKxy=s;V{klZj&_7260nO7dP?'
    'Pcv7PmpaHqG-IDbt&+rVQQB);t#;a=<MgYllF}(#XTT@E(CloB?OM3cVQk5VBm!%X$Pr)?Le#<0`S$}`o;ncutp!m>@bF2Y7rpPF'
    'EQ(I{;skjKa3xR9-X@M)yz`s|>vgXr;NmcHSCl-sgnB<0{arDIbD6X(>sNYPz(tm><ubHMe`#g{$+JlQSa>EiI4(Dx87MpySro%t'
    '>1C#cu4A6ug^0ooEETp-Y`{5&e2I4Q1I>LF+*M#)V?aoo(l<KKI!0ug@mvh9fAg3m9L!mnH5%p&Wm=(Jhw(L$j7;|%k`fN_QbWgP'
    'UbWHm>^Dj}*u8QBC9~aJxE%%zU}97M-U@u-G_U*biw&0h&73&kH4`C!YdVZv{Cn^do|uO4$4PiudW^DDTqI8w+ScIi*t%z5{BG7='
    '9@>*3bl!pMW4Aq+Bfkiza|L}5iRGp!rrTDvt{kOZN4FqEQyJ!+OiR@C?@pQFz(ZgYn_=dEABX2vu%qr>cJ~?0Jo*=qjDv~0nr^B^'
    '5tBO$3lDq+o!%*soNQuUm&MW4A`gwj?IJQJ&2NlI2!k9ihIkoCXnYSfnj2AFyj!;8@x*$7=)Hg~LX;n`)>fQ7B1v%f!Z6x3Z}7QY'
    '*2`igd>6Z5^eqUg7h;9AP8ysy)NigTLGB(c5tI;KCJ65ilmK6!h(SN~oj$8d+1{$R6fvhWk0olM>(aqqDYD!At_><PI%w^Y0<T=v'
    'ejuui2I(FV+HDV;<xeYKIS6v%GJp0n##VqJF2hPI+wq8hr3(XYnf)<2Q*9<*m8P^6$r57D8mv=%`SrxWY=3M)j<di`01Ni13L=SK'
    'z6(X=acPO%j&m2<?|2}K=oU>{0OP%8Y4<>4n2I=F(R0j5Ga3QA4SQ$mVCh<(aW)&V)XJ%|2BG$@5#-cg4{G(q#If_n;U6SN9geu3'
    'EcY38raFCyTx6jo@ZZ~CHxYp2khzeH2e1OlKpkgu&N&I{Az!AK*lh4Xm8k|_Q&+4#UFa=<I4jFUTS|18hy#D}v<w;-&{Q<Ww@4*l'
    'eESPKk|})tFix0?uPq?^8@Gym@CL+ij>dnbSrejPjSs7xpxujp)pt^~>|b|gS$~YFl(mZ89k#sx@1Iy-jc5zV+(OHlKtdK4)IWDO'
    'E8q5#cu7_Gfr)8jQ?(plqiWOT_UglACoVn4;xuX@9Ymi{)K{mooeF%EPY1SN!kaV?KHED0_ZP@6NeV9Rxlr#oNx}hp;F-A%^WC~&'
    '6;aA6-Sfyy8R@&ivIBoUf&mM*XqDHiqn~~;h&zH{9XWVh=8O~$CISN6%W7q~w#9<2NqQ3u5Rg_%6oHUnT}&&jo1`fHZU_`E>)i&C'
    'GH}v1=*v(>IcaP@h>GH1Ymx^6``z?-@&g}Oxq1<QC1(AYchtxOH3R<vMx6U#pvG{khoUB8i3D&80>QDkq<b^@oLTx{mxEXqC_>I)'
    '#InZYVC1lLhKCt5h{`+Y)HQ?85Eky(Q^m?}1hK(k2l!Ht|23`Y*ty3N{XaFcnnPxcO`SsPNsK8Fa9h=32|LvAbRJ&E2zZ={!dXDi'
    '+I+XbA^V|_lT;Tn1)~;W9=%{GtwR>CGnhVkN2k;HaI~QwX9er7K#MouxBGlyPo8F<RAmyiG$!!{@aM8d7nWp%iM%u6<A+G*9=SGQ'
    'rpfCto35pLF7@aAq|!$*F;y-@E*};F@R%;MjEtUP_NBpR7SUhFV8-^31Z4jrS5!q$DW5E!$vSE%PGACJWcz?Xr`6n}@5*6p2^{_H'
    'QqA5#mcHW2jhs}K#eLXfXP$cu5J$l&!6d>TC*pWQ^G=tReVnDQbJnc#kh1_{d(^a=&Oz3Oe-%h8g~6GFrtBPEn5-<;#zT9;%6#);'
    'jlCD$oKWF5B`umDz7B~7RE|ulevuzc?c)?zX(JzEmDjvpu!>QN%!5i4H>=@u6RzwvL@c!DCtn~D&MV|%!r8$59>m6e6&w-o^c<iB'
    '?>OOk&y;q;FhFi?@9pnm++z5TPg67a9G)?#Ny#&?D$_XgQpOx7jOtk|Uc+u;_!BW0jPFH<MQKlv9)@?gl}5$9Mrq4yUBw?~4**nS'
    '6uhdhq1-xhrNin9<WrX1@19*xtg^&QsM)A&TapK3Ny;&KwXfMJWvGS=d{Bp3n#Y$cc~ea;fIScc1ni_^a+lH^lgK&U5m}L)juVuE'
    '#HsVG^f~PdNU@`|pq6}No2&SibxNvPVfS~991ph?Mvb}wR@vAdQNi5xYD`dLo^VlQ@T>|`ZgGi76)G{ZN?(WvA7r!BB-+Iu4{)nv'
    '&ku54bcO>rx7Wk)E20~7^bFX={}+McpujSt6%Y7h)aZn+>)-8LX#!+3BsptjcuHDYrq%j^PXYGfj|LoM2Z23?w)2qk&*^S&jA(&F'
    '*w6`F4~yhXEu0;@;7-tF3nu47GWcvZ05P!8>0h^cy+aT-T_<7$&53u?7U)=H7vMMg@B(b6e&NR^i5Va@rK1L4?Nn<D414?vb&RNF'
    ';fkH58GB8odMN0tJ3F5kQ4yzcNpA;P-7AbakiSZ06LfFV583&z+1#vRBhOR8fSPpE@YkYt)O9*g-CKEObDI3kugx;bx&;7z)Z8>?'
    '&TKS9yATD`lO$PbXO5L+!-(mgjsKi89<B)_xb96xu3te2={+#E#UQFt;my@%S!lztYxc_BiAi^e!!ry{Zpc2pW*89BR?$d(_$7vB'
    'hAO?~IWQw9-#wliSuZKM`t%2s{JTZZ;GH?zjBAf(nahDmHuOJUy8OyK1x4ZQi*2P3r0W%Ssqc#JO-t2hP_%b2*Fm{G{w}&D;^0Dd'
    '3qtH~SIlJzLbNn*+EN~8T^s|*?r#GLjbP^Q3(B=5W2_-1!&StZ!Hv6&xE;M`cMGQ$olo#PZsIE4AC0k!wBSWCPr?{HaPouLbzt{r'
    '-lCrKL_zjI9HVWURxd9x=8M~;?q<)$>haKm=o}ws@wR%4O1?w!tHR{%{O@hZ8s9b;@O;@f{gsk)_=Ztu@|!~>VXVX^f?c#$>@cm)'
    'WoFI1U>^O&bcWhYW>OVs5?4&28(kp%zr2-R_yOk4?V%|?@Tu0a$Li<^;-Zph6&u?w6V41vB{&?~v61}^^BGX6<guXrIvCvY3m7G6'
    'C8**_ar1%ksd9<)H6ySu%ocYOst-j{zE?<9vH})pP|Z+);8DD&8{jZDv{^_^SgjNfpHNN#EHq?+z9Woi?uMt#9>hN|V>XxhajYy}'
    '+U)pnnm%h@{@HF;{8KP#C(xaKD@@njARi$XoCgsf^fF&}M}~s+!xr^Xlnz2^C~QyR-&?qOY=Ac>X03d}*0`(DhEIx&9`_W^+W~56'
    'D6~26=q2lJ$dOA|87SFo<A){T+M-lKN$Yon_pRz_V?iyklRl%~B_AM-g4~voH&E!ef(kSu82)!$zixqPY#JjOfcBghiLM+<Z4%tw'
    'HqSjUp4Tm`aC<WXxEa-HZ{4psBl@ewLOQDti~To?70fhjm61pAp=$zF(1r_Xn>7|ll9!oM5aw_w)7s=7M|eNQLn8YZdkP{z!Pj|e'
    'A`##sD!ei?P@A@kd}I4>aN3$8P!tR}QQQjVbEyn!U9h!vnK|;W%jp3`YDZq8WlAAW31hH}cF7qTOx+M_UaJ2%-1TV`G<LF~QoXX0'
    '?^fa{y>tQgi0IWJx<2u0oy||KQRA8G8v5LX%03cf6;9g{r;P7HlwyWgv(}($&xWo^L5L02H#-kLl`L$kYMSc{y5Zz^-VK@M_+%z)'
    '0caLqpq;y{H#SAt9DjaMf%@V=$GnEzpn4QWRb6sxUR%{T>Ra_(u`c;7;T!+F=8#Mg7R84VptC;PO7@y-cu@c?MyPfEnfWb>2`GW6'
    '*S`g$*t&#BAJ7i<o4a>w;G6tH`I^;(vLN2u_8kxH*bLh++Hc|4tnPE4AC#|a<p-~&R-;>Z*3#;+H@?pxO*`qYI9>xO9IGKxrE;Ka'
    '=%n+q9?kC#+aj*CZRpDn5lCW%3VYsMLi(=&Us#}QH@EX)nPwip5SZpab>o$u@b5*^`J$G6LO+j#mnNEQsoI~gc)~R#ZA9V(%#N%h'
    'dVkCvA3dwlb5UA#Z22c`Esr@#$VaGMXJ7UFp6H5GL=%}3%&3*I<Nm1j{-FwOMqPGXn5#*Eu3Z01g9{MiZAcMwG1b<X*@o-fH00N9'
    'VBP;Fl?G>LNFYJA<6xxIhaw~srN!en1XUyZZEBxwj+Ma+Vf~7D+}GZu52s2%K`^q{*J1fzA~wuuwBILfmDvGN1xH#QnDai;jbSHW'
    'oqvK&;NbkKd0T8XtO)#V;{y4WD&m_DPHuM0eko_InE=~@Wl%7Y=ogyl4*TwI3x%_b*pC^*2<ATSmJ(WGpfMsY3|{*Mk9vSC#pWq)'
    'Uu$-@%yU0e7&udKhpplBGW|av+_*c)x=B!`D6Xw;ef!YcBza}w(+$2Al@m`21-Y-mqr>uI0QYrZ|HJuipY41DY1(DYb<INj`Z)7B'
    'cB!A&e-vo5{IwhgA|}ypwUs8~ak!S~=>z{Mb+Z^d9}xL!U@Wa9Y6OPmauVNe*T9kp-8#>KJ+sooN&zZOBbu-EXqnFgpPoT-TzPPA'
    '*<#>W>Vr-q37+P}-!TM&=b;SF9sKR@SC^Mi7CQ@W?jL<7p(WaOM^|3Mcl!YJn6=}(*)2yn(0{cFDm1Zf`wo5ifAF##J{K*9O;9po'
    'NIo<0Q7j_0AuNQeKKmMP0EB?l4a8`GsNJEJ7L8DNk4cnfnJ@R=&X5}mgw}9xO7T71?Z++vVu=Rn2C;-N$3Qz~xz%(tImeu=;RxVw'
    'ZD!756%RK;1jR;4r@wue3%}565RE3idjj*KzAf5sjT;Pk^13sr&*c06foL4<Zr^w*yGbEpA3S;g>Nr$yoL-s?nuDD|@E~PWg%ZmO'
    'FsTO&l%i8^;$0iE6e2xuuh$SM#Yz}}R-mhNd_c7Q=WlXX24U3uZv|o2o;dh#(TNji*UqxDV(nstHTQ>vPl9T!o+vBsDTujX2b@W7'
    ')L`^-!Aq&V81m5nnL7%>K^+Wd(bP_>YEF<DA-j8T<HK9s1aQ<j%{*!B=43n@aNHa+EDg3x@7fyd79DkP09@>2!H<FdDFV_?bD3QV'
    '6bv4?Z90m`$w&G;AM$K)Q_KPmx)~iR%2IsMU~rr}l_;2=7@7@33^-av4?ACQYE#v0h({oqlAp*zf^d{D?gaZhXNyPgNKk-vYg$=w'
    'a?zJ&`A)osPw$0;1nqTA7=4}a0qA(ADo&n#%E`WPfK>My2+H_T4y95X3smFB)pj$Gh+EkPwwj#bibSYz%ZO69orDR|m>?FqV1hY<'
    'qYZN)$N`mN4$lRTT`{L{&Q+$2?x^YWTv%7}5d}>){xM){j?}1g**h+OYM{Syud!&cJ3Iy4+q-%|ThBE%8EUJRppwmv6J02g1E523'
    '^7180w84*OZt1qm@X!RjE?7#o`+xA%NgJ6^VY>cuAEtbV(b{&?KcY4o$yp_T`G*aa93}_s-1!VbgnLnPGPi_F`Gd1KC-6nBpN?Yo'
    'Zx0VsM1q9{U`1O)Gx&CLcbFUiPX`j?O*G(-T@LiHaNjN(1?uA6iUFy19+Ap&kFBuv`ZoKcgqY2s$ADPdG(ODPuH+Aj#87mhd)8TU'
    'wgtr0xm@WrFu?N?C+08tjZ`o!Cp?!VZ4)d4vDFWAhG(ZWapH`6X55Wf7ZAsSL453;!{1Q@qB3Aah>dY`wxVL(VDW2EOuPiLI-W!)'
    ')$NoiG1?&7q>eR~dFc{!<e`jualP<^N9?|j6xH6hkBkGdt#yiB0w$Qj*12<Y^-k7!am3cSSOf#_s!V5vJ;2U@u*rvCw!E||-Tv@&'
    '2j(<Qko6!mjzkMOZ$ocDDXN&<v=lM1l-3G(aJjv74IvddA^bXOuczqr)+RB<Q?--x2{y)5GP~q@H{qakB*`~v03IvD?@TB4)Xs(r'
    '3<Dt&KC}_pZeeO6PGPom#b9&-R1<4veb>_Ahuw3eAsMC0;m9xMOTf@kf1o6F4W|EA0S=65!v6^xW&x5IL!~b~TP@8+lpnMpRGcVv'
    'wMXPGplLcn$pt$;3oW7}93k67(#qN)Vc?qtJ`?42%5=djMjnb~jbQFt-?{RxSLwQX-gSK8${u0>Ofx!l>S|Tv#{F&?5Pqsh9XzIe'
    'd6YeOep6>75QO2aVcyJkKG${ubcz9)qt+4zP7R;x)ZOH(*N`HUs#>8Efa}P1R(-f-fJYy7Ld%G}&_lcFaFkIG&U8SN3)^q&Sb4y9'
    'aucSqpFCv^nGPBn@1at>#nlXI!sqRb5Ui#siW*&Z!BqvAH7=cujbM45w{@3*Au|#z&_9=3e?HOGv&Rs2(oh}LMhj!=wSOnuhJN4I'
    '0F_>HyJLi<w}$DPuW<x++O5YdL{cNj*^wP|JFz+EWvAOD_J89YpKsKWi}Q$f=b~5M+%)NoKt19=MolMPH3GZVd|b%!m$Q}2hT&*-'
    '`26{##d6BVdcuo2?_TDBOT%dxQoQjNT&})F6-~@{16b8gth2B2;|?pdH#KqXP{P^;fG3CKB#zB!==2zO8O*4y>dsCT#cCa-=)?sa'
    '9y3?q-{s4f52`V7AS*C;KHJ)rd@(Gi&P{R+YV?yrUw?PU&G%O-CtuTSd`LfcjZQJ<Bh~If5yBLu@3tCbbX*X7eN1)UfYU(7$QRCd'
    'EY(}R@QOA!6*i7W?*B7!%b>Ne3jG46%kf&2gffVDZr9fjKR$^T8lD1OEQ_$PZMMzY=O7F}!NAG@p1Z$za_u4iV0g75nA0?BU|a`t'
    '048i}zW38E%vHk|5<6IV88=!S{4w)S$iHE^3%?G$)d`3}-QO-9x_5BCai&~(K=qC~8z=W;>ak0k9Q8JcaMxl43+c7KA~>U8;ituU'
    'QDPYtxv9H3X#afe#Zt4yp&nuu_WZc0>DzTX^HRcjQ*{%2vDT?{*lVFzl_W>=ZM_M9Htj@ycgBayTeMwyR?`G*N#2vtx~anGRh5F('
    'V)CCxv!+wV>>m6$>oWCu#hU&MD-UeTtrcl@Pk9LRr%z@jlL*5_B8f2Fyk_fq1M3T43=pX2r!oy<pMMBDWKzRboY*;`A?5HJstJ91'
    '6=>hM3r3&)pm=kHp7>YBBHIV4`#p$k44l~-Vyt3%9HqZOu((H3^2~{&1Jvj+0@lqOdFQuf{zN6juxoyLK80~NWTo}K>j)p}f&f!}'
    'n@rqlf)juma;`UjxRz6TR9*?P1!4+fE+TLB9@N`s_!cAIqd6pN1`)IE@*anJf3VQ{7ub*d3Irbd`krx9EvJ0*Bni+nTAzc#^9H?o'
    'gC0FyAXM18Ip(i|hfh#{K>P(!vfRlMPvK_3#0|iDjQ^gQifdmrk*U$<OOq(kcNWPq?RTT@CP-#~&1Q~zl$zDAbX=#Mh4~XE`G=}U'
    'aGAp{AEa7AU70k_hbLWnpyR2DM>OW$J`krJ8aRpfekM}W0(bS{UM<v2I<QK5rkcqHVOJyBW0B|tFaxco2R>XSYSdjN$QSLF=SFjS'
    'x0SYAOitiBiB6Ikb{*Tkhzr9t2qIuk{qwoYE<MY7$1#aBtUmbIPDo>e9h1&lYim~}7<HLdqHv%pI^KnP>*cCA&)Nl$<b8ncIqjTO'
    'k{2ncTL11lerzwdBfpt@Z&Ob|#Ex1rG9*6Sdzpn_$@j=#s>XS>%?)=*r?HcJ$Te2FFE^_fug}p+SxY1`L&<O-bxg+;+3^jH^WvR+'
    'EO<df2~=M0UQWi*KH8VS#x(9~d)a5PLD$l=&^|zXO@<&Pw@ZolWtw(jnJ({=%Vp?LGpeh;o>h0Y5I)a*Vkc~>mJ2_qlQ&r+-N$~h'
    'w9>{7*PLiiS9pl2F~0nKcTKW#Fgq)cWrHxPuBe7%0X!eIH503shb;;s%r5kN$UCVA8L~X#>6;w;Zs2K{H|aWPiETT8=7dd$ko&cL'
    '<BDV}_SXDyOfN0|e85ljo(ot8&N@?hXd9iYJZ9v6HFqYy$in8Mw*UF3C^SHZ@Az_M%%VrC209Xd|2RB;hL6UR-1|#kC;OKrJ>Jfo'
    'RsoN!*KyjV+6PJqR~nRlsmkk<B&nli^ZGqE9kxWwMINmDJ(5@fM43l1wHt_k1Jru2NnSXwSx=|9eu^%Lql-L?)VGok_`~xd2yYF4'
    '4NbumxDRMa;Bt=IF32^|yGoNp=3QsdSVAh#1skt_R}sXt&YuDz+pF%&!rmxON0XYSOZUc<S<$!2to9*)jzkN2dyyt1;Kiq_p9rC_'
    'W`5&{(cdd=s}n>wGx&#p#kE{NB;yd+MZMPvx0mX5@-|bdRY_rHl)HLo%;9r?%@Zem!-**bBd~T952^RIOTUQRqV*jhAy%B-XC!og'
    '-%io=Y_D8eI|y}3)XB3XOTD+%6k?!5Xah#uJ<9ff;>D+6FP^8L5i+9=n0RFVLx9Y3^d;~lB0m1N(|<jH0#a<M{-ctoPd+SU6~p{B'
    'BM+@L>Uf4|IT-#_P!0BgiuNcgyzZ-94wisir5s_optof8&6zFk0D*#o8LC8psu<S*vsc{pklq$VMfQdwxri%hAbZRm8f1ItuAw7<'
    '#ypcmdY?P1Kx8)X-2uE<k;h2UMF@?HnbC8@nT_*+#{XJcXO&~cL#+NmY0QaduR8&wPQ)lxs5PPZ`U%5;<M%)-9j8i9moSlMC$b@N'
    'vjZ}YitQL0h>ibBZn;c>Q1Az!c(L#|4qT5u`G=5fJ?>ll5eTd-i)wl{Mg$6hV_Q=5wk`fgdVz$$_3v%S-aW44G{(==RD8_u<GH?p'
    'X8!oAaT9)_g`+FV{kWCkd=mTw2kUfrF#cIQ(r><jcjh>Ge+QQd60I$mloT09Ph#17x-^Fi>J<HP4y;mv%gE<FMFsqHX;V#CQw@6|'
    'Z=ovZ1FKcwfWMFPU>%Nu%_B|^p7L<!+nHpM)nu?GhdQJO!?k;?RJCSy|Ksa{*l}kqO92AlHL|vC1XGs1r;7J0)cF1h2H>CDupE7X'
    '_CWNq@h?+PeEN2<JMPO#t{V-0y_-qvBMer@tI$}22CfSF1k9sR(lXs(k6YlZL}*~C`dI&$fTL=IdK7DdHe);A?gX8LV%GvThpi?d'
    'X+P^&(O9CK8+frdNqr)MaZd_wssua-8Wrt(lrJQ*QNF{*n8G|r9&{w?^~{`t$c#HO(K#i~vZg+1l#W(f+935Z9M>;=&tf!wvKD)S'
    '&i>K)*0*-uXmm=ElCUY0LgWU`hf>IEbO~a+;y-|b+)6?g7n9v)ry@U5$>1K-dM8Jb5`M^}EV$a&B-uHGKVJ*GK|v9fd%7G;;7|19'
    '3V$z7bOJF}lYzXp+q;#6k{YOLREWZk1SWbzseN2u76BS7XCGFzz#C5*dfHfnlVpoCTeceuz5;1JTl4Z*ZI*+SIUb?SEdq{3ZHfwm'
    'wKnG@i6WNVu1+5!>j%oA>?7p}<y^fgLMRkoSye`Z-)VcD!*y$Cc2*9AXgNaNDH4vKSx7L<CkOAw0tG9C4xyoYI}59~YS8PQrW1%#'
    'EN;;Zp-7=7XYm?%?>&-)4-VAK=1d$@y{r;7DYW!d#gF?Xd^6#yP#nNNWo>AL7P7J3wF>k2I8$_sib{%8F|>>;ykVaUGpy{9YQ2Ai'
    '7WljQ+4I-c&SnWo{4GD)-2s0(wFxjDz`T8-DQ8WDJwqN`LQ9s{xAY=6&}S=eER3Uf6zoYJeEVfU5mZKmYwn!eov&@xJEsV`K3$^S'
    '*XMmy)16FjyrozwkGoWaq@_Ea<N36B_Bh|1XtO(sv$MTG!S)0D#`$`!j*miw-3`=-A1hrsfylFjHweH9R~Q6ZmP34osiV;knjQv('
    '|4trDg5JtvSXMe&6eGb4dW$p^1{jvgdHl92mmda&0o+nHD=264p`Ub&_S}#N;MN+Kvh$n+6ts~k{%Em<M~z%gaDhs_vhEQf^eDhM'
    '&qGODdR!}kLDCc`-KcAY&Ot97{~qYzX?Q7P=j60P8i0!PGEYAgxFTc6WK#KtF}q4)cgB1bv8<NKn&wBod@R0aFqFhTK^i!qjEcC1'
    'QI-Q}^<dY@G4Dle-J8scaYufey<fS*t<ZhUk_P&QhcL3iuF%J*-)SK(X+oW{z^Xf*l351qHd5_H&DBwctk*U8r1PC}|I!!`gq5c3'
    'T*25N13nD~C?;kmN~vLn!6#ox%atC`CVYU6aGW*2=7NZX-@=KjM+Ubf=;Hx~)PP(O)yo7i>S$zmfrbTp{^H<0NpLy&CRAk~QL})D'
    '3In6wJH~A#&5?c|r&VN>Kfhy+dhU92vGU2KF|Q_vE0aM0iVbwm_+1v6$<=y6Tn5GDZo@irZ;W^4Z3Od&ESq2tD>2TxQE7-_$}}Aj'
    'ce~F4<fNput(25I=Em!XQwu`mA)GJ1Buf`!!UVvLPyEfuS&+pt0Z^e@kX(m{b)G|{YiK8KT7c3k7Xddy!092)>;CcV^1*r7r5W3Y'
    'jJu<e<s4lHnF8OYt=_09F4FkDO0SJV-tf?l%~3swN}ys^gS-&ULeNdZ;AiW$3V^QEJC%G3)Dq`&+JF0qYnwc&ON#nogkM-BdL9`<'
    '*P8Fm<Z#ZjrgP`H0cI44mN8W7E6c!1m7)gR5{Q?3uL4KK`w^v}gHpFF(Ai^%u~s=eOnBk2zwVoy#(NDb=TdLA_V*zfQ$bz#?1a3C'
    'vc(e2K!e}9<dFtexK@#snYz_uOeqZPt?4(zK8@^%y8~LuKMG(ELG|rTg^R4_;PH2P9%a<YvIoVTw(2#A&}Ivg9<}p_%+_O3n;m+R'
    'c4W?m#GGvi5pdbXpec@s)J3%Mr1{E~pC_#M?^NORkgIFDIy77wljZP}NT=qA+hg-928Y)n=^g_C-txy(Z<h@stvg=t?cn}x;lB`x'
    'Cj>1nd##uGHukQf-wLB1JEave{42|=W?wP6ciPs93siz6&zX%PP=G!oi)YC)`B?1nqUq+RA;I$>@$5c|ByY1eWIZ><G64QXRZXot'
    'HeKm`GVP*^g_E>xy&?jNGrYu;h3AHde1pZIHKrPZEp%&MdIbrWy=j@J5Q#yGL$JdFK(g-KVOjGl>mUlfg^5EA6sD$FC?=3DJqu=v'
    'a0^Q<IEc4ZJNgLhdLyM>=7#wsFe|u3nMQw&V{#OVj}=p^Rg8kB&$FIY8<<8<PL|5gA8|=NCi*fRzXU;w_7XB~P|&}j&m@2T(#HBB'
    'B@8?mUUre_IMb~eXF#lr0m0;Q5aU5&#{KHJPyLzhek1-8CCtd4+W|r|IqSoVAmz_;lWbV}(Z%$yY8&&{G0G)ZBSN)|ovpNe>r9V}'
    'E4*lW9Y9RdL4KI-SreqQFfaHhEmUqGU_w`qTbz%JHw#Q^=wZX}sF~aNl1V+NzB-8Zgl7gjxkMl-f6qXRJp{`U1nqoQ<8gG@FN(_D'
    'J&0kYy?55{2V2F~48%N(OBP$g@>om22I?h;8V{_(h}(J&xc**;TXe^}<JRYkW@gi5S>1YZ(U7*y4>$k?K>EKm$wFc?g6;u`8Z6wj'
    'K#vR}i*68vRQUCKkJ)bgS?*rV6~*Otp;<a!m!ENL4N;rbi;G=4P*qILYe*RF`cPgV#a$+>NH~@rOr!LS%Z8^^i@JaR9XLkLE2Y};'
    'euB)(!=OrZhQ4(EaF=LV>HwDri@eHL^x$-&Agg%=co75}o6P7I9PR_lA22|3VZ(-$i^D`MDbBAz4W1WoB(moRfJQOry)qN^mgv*X'
    '5HC)ei^m?;$$peyST#1JMJ%ol-9p8}y>Nl&;s!*+Z_$F5i{A+0XAP;${2z``86=44Q3;Bq4WTV|VGmEN>6dD-j1T)RdDP#+NM*3}'
    'gy9rhc(}*OtK=41Wpj8mdC3-*j4B6AqPMrGO^^cDLxN{;{%G%I&5Z_Pb(zR*wfRV<j5@T6>1E?3=Bl8U0{DdSuK-^7r%6h%l-BJ7'
    '{k*(njFl5EwZ$&&$(vxmBIe<42{`7$zk?kloNh~Vt?#uyjFuS&r=6?=A90PhYQ<U|Dt5&Zw*gOebdV6WvWdxPjP*;2;g>+SGpNXk'
    'kQfc#o(-SNvwLtFulJN$V5LPQjVrCbe5M1v5sh`UL|=@bB!l%V$6!TK?X_rf^w)hQjX65A8k17G48~R$p2u?45OF)7cn<Y&SFL(I'
    'eE~_`jYoHheAgrsQ#5(iYx22-8yEQWY#q-<@olcfw0b9$jeKKhSyXX3?1|2`qEp_eaYlA*roJ-veK;!)%ai)Pje@v##f&i~Vr2{B'
    'g|_3-yw<4Ij&Sf71`H^qx4oqmjgTrS>jf$ZR3q0srI!n6axcXp**-5;qT8T2a~Y9ijjVBa3@rIe>9wi<tkCAKE6etHexd1PH$`jp'
    'si9F-jjzd24ZU7KyO6-|C9oSEg0-4dZ>n}prgyb6n`F7NjlV#c8dEp2F*dv9NMwX~$|nRLxP7`lpNH(jpM#TWjniqH8k&Ja3P%Yp'
    'V6cK#*DL%QSDs`E*yg%!SGU#Gjr19VW%=nP4#v*fY?9h?4WZxm9G#MGOIbLnid@T%jsnO-6?4tr(MEnsoPSD8?%GlkH>j=K^&QU#'
    '2_0rVj$_#tNCddJeHyk1gn|HUqa|^V56(_RbCNu6;X3t#k2gfQ5B~qGOM{Z@wP8dc3<US|Pt(+P8^H8xhf@<qk3mB+RA6@HK)#N3'
    '4#yTTyw$q9;@RuEKl)F$xiG33kCf)+G)rVwk|v7yaVp9RqxN*Osho`B$r?*0#rQ*AkD*u$gb`0Kv_Ax#Q8oomJqy=VV5lmVphjg`'
    'E%TFjkItTFTf>~KxM0^yUd$66-5FK)YcqwjoHKoxBsTxwkTjuL+&dMH_TGn};)GWRkYPFq$8Tpc6ECVv^)?fdkU8KGJ@TSkcCo)k'
    'gunccZdx`^r2*ihRt(P?-of5_kVVX0S2OTZu##zgcBoJX?MLYRItzYX_hKX`pQvYmkf6mtq$8_SOyU<VMpfh;4T8w~PJdMsOken~'
    'G@^>dkqF9F2nYfLWGH(5(@E$J<A`0^t)9M+pmB=>Y;e$;kvWQIK5}{n)PSpcpY>*=bq=&x_zJDEDiZYL`~J->ky_<s3~$lPVM+ZS'
    '!u1A{_(cjQ7w5(-Ezfi3G6KR-k!2<Ec>JQqP35e7A1}z5CzJ=TM&~qGeYA>!{M3=~k)>lS4=taV{t3I=K`j!Q|BdkiU!4Cr+Df#l'
    'X9oegk*ZzOpQ<N#IQQx%+}wzUMjr8=Vcp6T!idGB0T32Tk+E?Gh_w1QOE#-b`npKzx<C2)mFBR6m%Gs}Mh<}0k+Q{-rdFLk+cf{*'
    'VuROGtgq4Q%^)O6+p9lZq32eFk;m!>W=oZL;5#VBlULE;!8;zRd^oJ=uai6uDH-|)k;q7&)w%HJ0ETFhd9q{L8n<<0wG!EoFSzJH'
    '$0-r{k<&x?GNjy@TMsJT=)H%WcKl;(2{H=aM0mEINi|;|k@oc?N9<f@dJK#Eyo${ddjL}oWV9s>W=J0VyxXLvk`IF2PV6t+Gbq+?'
    'YoyK?WisDU^6PI0c%iI<q9Ik<l0K1^mhG@+JXf>1*<w?+-E|2Qa^(shhA1m&4UI2>lAg@|R+!qfb^s!0Gt2##CNma$Fgo$_OK(M@'
    '(xEQ~lB+0@AMEGYY$Oy=hecxMJ=`=#x+^f~LNJhZ@20O8lE&`BD2|Q&Rmi@B%VNQC1PMXWkmSS4i6Rf+?HW$@lJ4kEog9dARgBXg'
    '?s>j9VFD_qFv|_u?oab@tHQ14lLfR@Gg4C5#tUF%dH3sCqzJcnVz~dpPP7B)(CkY{lOx{>%;U$5^6Jvvs^n~-o7@vf!c`uS!SG=~'
    'M=9>5lV%S1w@Js8^CO)*C(Wc)A7codOfsTdD8W(0??q=0lg+c>!`3cnRcNWf(s)1GCApMfLwp=s=yM)5oH5$Hli@omJ!t(O`(liI'
    '710flT-6MCevN{nD!t5Ey*o`#ljz3{2w7Bp8e|O=Qa@f*s-jV6JjRB0C1_E3u~2~mll9bkTOiOtJjLIhYzCp0imvYs_+Aip-qun)'
    'i3+V@lpO$B${g8o3+T%`=-%Wq7%H9kcH6<_Fxv(8*I$k(ls}jJhNmN{1q8}ehcES4v6#u%LG5}z&hk4-3NXO~lv2De(Kbq9XENAL'
    'BTE=gAD)L;YWe>hqld|N1VO6|lvIO|p<gd2hxZ~^Xo37Qe7byquQjs!H=g8nW7mLYl&{y$ml*fJ59Bxitz~{1pbWDjDZBlhv6g{='
    'a!s)xl(P>FSDW7<*CmjW&ear=E(SD>VkohM`Leq=pvpNgl>Xj{f$`(_w@!Y2WBe7OSaS2zD*YH`vBoLROmymQl?1K%RImZ|I-jlR'
    '`MW@|JI1||^OYX3mzU_>I)WCumF;vV_xUYNHHeg+OErss%JW$l3-(`BGLx7}yySB4mYTt>sUg8(LMGx#jd7QPu2txfn*rg4p4Zn^'
    'z&pv^me?Ps5N{}JT?FnXV&(B|tm?`kfYV!Sz=}n;A?{Vymlbs+deP@!0rVZ0Pi~y1t$rZQIh&6S6P=eAlecPOmvsg)W{1xv(}g%L'
    '9KOUQ_l2$QSKl}St*lfSl+o)cmyqQ8WJv6G4G&rz_>D6t_7$xX@O(}slH{TvB36+fm#aqo8Zxx$4lC&qgv;U{dMn@D(cz!{Iqq3g'
    'dUb15m&uCNdrx=djuNtcly){xl`4K7{sePFR<5~{MbdjWm)?NlbwSTk=jo_*`DjI_<94=j+j3=F{JkP%2Q8fEm{M2b!dD3Gzha?5'
    ')tzB+%5QZMM0x&U7}N@KZ8WxenG%HnKV8^sUcsaMV#CJclBO4Uy+c4?+VPkHX%*^YnJ&S#TN%Wzb&9<y%}uql3hX?&u8{&BuZ9o^'
    '3ZyOcnMr-_gN_i`sy+@n1Z{(?VS-=GH5mv9Qnb&fJzcC}nc@=~*-yBIl?JnhaQ%Dx{TdnP(#v3>v1QT$d`}Hjnne8d>ah<%<Hk3j'
    'xw^q8j*uM_ZLD1!=rUQFyr*h(nu5Okc5Odo9J%#s-U=pSRIFLRKPvbWAm>JFe?~uvnwejT#mfFW7mcI0Fm}YZ)S9NMCzD6(2I%|6'
    '3FGXYnx=|gB^v9G2UqM1Ad?Uk%65!sOi1zjE-FKc0TIMfn$UMH$YLgrTMx~m+;TaxK!j#S)7|%I3Uf<O>9+mpn%*187#Yu>-W3~E'
    'yckqV`oE=wF5F|QKDH|qMF3Lan%+SH7)g|uIG0imyWef0Y!V;ACZ7ZAAS~$WC8-W9n(ANSW;XI}tvfoKjx;m?!=)N~*(-iak_tl('
    'UcIm&n+ER?Ip_RGaa}+MeZyPHx(XCDXce=R-LI?BnDra>n`8La#CNwy9(|llib{Q5To$>vqdhJ?=u}*jT;;5Do4z}NrgcxLrLvQO'
    'co3ji&0OmAFs4$fr=z5K^0$|0oAG;uyM0v#*u_8dEg@MJ`U$Z+<{*6~;ecSkPSyKCoB%bk<3Hb&$oFp96?|UYJx8H^cY#zS+q0VM'
    'C^-ScoN9Tn<Q%a)Wc6?GN(p60x(*jsx59CNV3PXsMG!Q|oO9oSk(aRqz4m*mR;C^N53(Si*9xO-8i4=gaQx2PoQ-_1#khUbd=(@6'
    '39Z*-0U>xf@`cUcRrpnnCxK^koTEE0lA;OUu;;7Hsc=I&os-w8p-LaO2C<*A@(xVUoUa2UYe1!_#Zh@nFr*uuv_sf|Xlg%P=V7w3'
    'cNyoEoe)xMp8k<DV3oqZ9>@NM54PiTVLJ==kz6+qxp)AkoqKQxyaxuUi?d4P5{bgsw#J*ZB_$V3%OZvz7L;~co#YH)A&l_gwMw1T'
    '8>8%F5*{46xIk}D74a0U`g^dho;ggxpq5^M4$O)a2_<uP#H_C_i9rS$?VOm*@A72Ro@>C@cck(BJ3;MwiChmU631B%=9|H3A<7ej'
    'A)PaLpPFeQodx{*EU~=HgT-dT#N4qxQ(+-9hGuFn+e}*>pU-|#w6rWsj!TiJL26Q+HFic|vMu<MY)a#0eXuUopW;c{RQH3!*T#Mo'
    'qn?C)0S79nE_h&v_M)qt(=XmopXFFSY?qE5E8)xxHpoY)$iTM4ang&e%rAPwX>Z|ipnaJ5R~R45bCJ;c0M9+rSjVYl-q+Di0u8{v'
    '(n`#HptD4Jnpt^T4J>hC-Oh5j%ILfp45zv+WhxS0Kn((upxWrmB%U<e58MJZxoW_grg9MH*(u6_A~=g&DFknppzsDM7#0?y56J8R'
    'X~A;1T&6lL+gn|$Y?ge2A=!zzp!&z7Efz5+#gr&<{>kJeuTY|Q6{ZXhir7XzIIaFop)0a)E58&-sX<2TCiRTs=ilJCR*{2ZtUZ!a'
    'Vzz)gp?kFOXy%+r^M#0KPSjhdQ~4buq$3JcX{_d|%XwV^p`st(S==J<8~;7?@KXivj)<7Y2QPAt<Mh~@<q`-{p|S7*Pip{biKPcw'
    'Mj1NqaQPZ+IJ6m*_Nrb59c2jqqCsx^s_hK<uzcM!n{k4c*eTS2$|qbNqd4i$%Um(BqF2=+>Si@#gV1&;07e7<)okH;egvNb`+rI_'
    'Q<=j*qFRUI<#~ZwC^l9M@2SG(W*t>(rSmF2b%rY8(ddY8qK9%9Y*2M464|0Ea%dkn{Z($6TW7W)-v%ukZX6-WqPkDNS_*2}^(N0K'
    'eY51G0k8ZhmIu|HB=a7q1n>4dqQ5!r3h7muA(dZ=>#$pkscm1WjKN^TyPcp3o2j2wqS0oog?WO<**p632!D)6T&SfB@>`}+f;?c}'
    '*kbflqSgga8Y^xkhwP8#zkYpuXI{~o?nPyK^B4nj2#e17qctF92wKrHAuqV+v4xN1RpUfOoT}vH>rWyi6)|Weqq{sJLc}maIEH9?'
    '?uMP8P*q~x5@d>)rFvnBil-6!qx3S6%pk3Um;uVj(NybN>cw>Pv(XL(H51;+L&1;xq(qqY%SV1V4g1WnjtwcdG#8uXl<D{&b^<yY'
    '*tu6~q-0$*9G<i~wU=awRHUuQ6&H0J8Q3@!<+%CEwhZf@r2YWac)9Y=e_swI7;L`ex#^ml4-|FZY>Us6cB_Wsr3U=Sy(%vkF~P1f'
    '*hRh}ygD^hjN(^xs*Cuv%WrzOrAbm-%5d8xVM~o<tv0*+d}7Q+0JGem`@L!@H?-0mrAzQ@*Gj!jT@v<k2J%-jl#j`(kP2VlGJXO='
    'Pnm?brA_j~s<eI>d8whXwp3F@aQyCsl+`bmS?Z{oCJHE4rH$CPy4uOp)r;&smAt#G8x@~y#9i`qvpu3dIt%ECrM<dA`ts){Imuf4'
    'E_!gZe}bo_i-Oh6s#c>VVxkqLrO_Qo8BWI|bbCX+90oe|Bv0ode!4*rM~3sh{hASjrZGzH`##%BMIs?2kPW+rdG`azyi%H6_kP{y'
    '5imLgrqb-jeipH$*8+`FtV*cdl^=oh-D9KZ2gJ%Vs_A4Rrr8`$tTigp^n@(i>s+P|W6<KSt0}NI%xyFQIspdirvf#Bd^K08(#EzU'
    '5k`jdgs;&;QlD7%`xIvbxb-mLrxSOzudFHS$Kgv-_l<oL*#`GB@`W^_O)Izs4n_kWrxpD|4i9b3Z7z?H-l`U5R|YMw!i>as5HX7<'
    'w*Z|yr!CExiB)WcwG0<U4lKwom}ViTdok7$qtuW(3Kk~Fr*&@00$@~P)VV$-IfO!F;T2F<9+uFLV=c2ZM$9Gur`U37UW1!s!&Uy4'
    'YTptr<tVK{C8glzS;Ifja*tScr{v--8It*{`$E%Q^2RQ&0su83pIcgY%~uJQ^yKpDr|!MJQXbBiB*<dsu@OmT-aJ(|m8!|}PEFB1'
    'lwEaps7gqabpLoU0V>qBJ)VtD^2Ji>LX;ye?&QI8fbG_Ys8e~^r*Rp-YW4e4+l8ECFH!H=Oz;pH3>b`BMm65zs96#O0T~2obYXBt'
    '%x9<99<K@6Suya}eG3RX&wrV^sDZIP$u}6>D^4G|(0VX}!VcIymEDcrr&4RZsWo&ysJPtKKm^SR;W~j*0>op~O(vaD^!Xk`<hq0*'
    'q~ZECsOs-(w7{A;HpS-8OjdI>F%UjzKs}@(i)KG$^<6G)sOu@y#aOb))Oxc9IXycN70=<{f`tQRHj@@}s>t4&sQ--bBPGJk=fKtu'
    '{lmJlI6V>Z(&c&3jxH&<2i2b}su1<7C;J50MS;yEG|l`hKO12euGQy`r=QuThEKMlsuF!H4czLFQ_A8p4<eGodjgI=>|Y7bBUK-L'
    'Li=iasx9U40IYma9b4hB#BfqDzq|)8mQ1e|(p5pMi=TSls&b<aTcbKiJiYJ+(Zm6y?_mtLt!K$N^8w6N45ZOms=~rT%$>3M@kPK('
    'zLY7Pd`47SQRCt^5xoOc<giq|s`H~}uQee}4}sk?dGioN8p>O6Czac7`C&{)MC4s%tBpvecXb<4hB0;u@>tHQk-AGyMLmmF2oBH@'
    ')?ALFtJ=T}Q*>D+j?j|SWJ7FQ#dBrOqOr-oBe4M(6AA6stW$@Dj~<!L0y-L7{ox8~DRO7aM-U=)^Sihd0Z(7XtZ7!(sBwb_sAfEo'
    '1J0@DHcz%H&O@Me%GT5;=;A6ZteUPXuoy%Cls>9j<cIIZL_A7^|Hc;>id!<c9=Ee;tpjnFyc9YMtDrT1L`oZMtjyO9qpM~Ly8z`4'
    'h503>tu-kt>|HxD0HvD65y)H7F19h%^}UY(zRkf^JM1}Ft(lu27^Z5;sPc^r^-c+$vTSR!b_bWXMkObE9ud*<t(s>xVB606EyYy@'
    '^=M~j&qokTS@RvvegPuhzsDd}t;^G717)vTQhyJwZw=l8TeO-VG;bI7Z}SQXa{{ztu6CfC-NtrfZnG2EMqK~|1(^+J`M{#+RAKL+'
    'wzK(`uHYu{m6%DyBfZT+WGrJ8&v1!AO;G{l%dCEr0XB_muIg1x4j<ye{OF(NMJ?>I8}hlMXIVYb2<uC~JxahguP(>MTKH<)GLIeU'
    'UPVaYG`_v&Fj5j^U4U6Su5jRwuQQp_5n7?1Qzh&vQckLDU?`uEHXwzC7GFUnRWad$uY{w~*sEWK8_1;~6u<5=$Z3n<z#fp9+ha(('
    'Q8CcFuh!Rwa(*i35Ri6Eg>Z3j^|S@PBY8&@YLIE(dM8{Eun0LYcdKpdYBgnGncp)N1um=l52tvAblc=KlK(~oun$lfE4~`dF8eyW'
    'CG4+t1tzV0zvP1?v<T{D0s!K4un_0`d6O1myptFas0n;&awqz`K57{Zs47~EhkwFiuo6cIr^CkJsM&Od$QAQre<?n+uNqSY_Em$c'
    'D`%2eurkgDbhQu?nYmL3#{-I#oeGyfk!6}{vw_)Jz~hrnuuX#MeZA^!y^NhL;MI(JxuVU!mD*eOXf^lSK<Giquytr2WvHx*kvZ5q'
    'z??T@!ZFu^4q}S?5R(%AIo4N7u*GF0Rt*A<=xslI`QerfF>>><EY?cKh|SoKw4vBHu=eJ;{GVwdPjTew;4@PT706_}O#he|cH;dZ'
    'tl#mku>#x8x(uQ|Mf+H-C8^YN^TIs7{Ax(GuWQUymS|}>u~Xx_z;$tBo{F3T=xNr^+!kq79?$T(RGd@-L6#<Mv1V+{+76t57;3@c'
    'Ji2aAUo-59bKvKp>jX?o@`P8LvM6XFngvLw;svD|+Rul+2iKNI|G+_2T{J?{R%y<HvM{OLa)6D~^V8DWuP+^YITJK4i)ScT;B0e<'
    '8JN!`vS{dfZXarc#?0YKwht@(#>P<ybtClsWR~$Ea3=isvd`zlfqxcFEJXQdG_wn(`@pCJy$Cn4q4@|<CgoqhvfnR<+3*Kfp4@8W'
    '#VycLWQj}lH0@)Vcv$F~M4E0lvgF#qs1kFUb>Gh*xJ?)JUHOv5s!quNdG@~SEcYEUvqR)_?h-Zb|7ASM+Xz=X6Rn>NCN6yN85~Ia'
    '5!SHIvu^wLd&gWZ+e{pt{9Xcq95eianL$e9vB}UrdQoI)v%oR?2gll4(+w||hZP)#8Q89$z`IH-ii3o%ROa%Kv=wABi`y=sPHUDD'
    'j*e32^w0<%J?_qIoS#A>gnh@mv?Iw4MB`vRyF<}XAvXvXBq&LyeCzJk1-Kqbla`tIv@A@h!C=;>*sYvKYD>8bqgb;-HX;f+x=esq'
    '1GDA3w0f{Ia?_`}dsnnfC!Zc4<i)gbE6FJh5HJBAAr{h9w18EeeJADtdob#R*IxBrj{{*B<wE9T#INAxL#Xwhw78WGnHB3Opj(ak'
    '&JIOtIe|1^%F$7-ARe@5dsDM(wA6E<kq=>0%<}b`_4Sa0F%2-kR*G9ghS31l##?c$wAT{I@Fn8%RLuUZaXV`#ShgGj_FG8ZBJ*FI'
    '8j058wUh2IXvDv_s5JRh<Wve!inbM0<C+A+k%u^<%Sp-gwZm`RJC?}C)XL#w+&@G#mmq$hiz>VT&Ky%eZ$cRFwbDB3<;yPif|>&#'
    'GBZXY>IyZso$f3>!(pw!X;(1Zwt~TIk~G|^I3nG2#-nteHY_t^)Zr>12pgW>du+epwv?;Tcn`ME-?Vk~b`;aHxJ|_#Sv_(^a`#ND'
    'CP5arwy?&XnR=xR=QT+uYoSfcC_Zt<FRxZnk*+R$M}Wftw$w9!gPRkM(;=Q=BI8oCndiWvc1k08>cT<l%BYI^w)-qPjxOm~`R~t@'
    'Jy876_wdFsPm@_GeH1*H2QkO%w-c4#{-fKp_~xgY(|>|b9sIndLR!V&naKNv=k)Eww;b~rlXi+6vDWRn3Z{1Z4EvFA)WDgdp}MD5'
    '8P`>%x6a}|9TO?x9XWUkJMDnYhDFE1AxdNWGbE@mI0cV>xDFE$?0#2EK(P(OE%csEBp;bIE|4dk%Y{!7Pg1XjxM}$8iQI&a)FQJr'
    'jZql<XqrQu?vYL<x!ciBc$W@AxQ)7Zp@noGl2tFO@`EADiF-8`E|6VnzD%vBkrRn=xRWHt-BeIdE-{PqN^mb6zv7qOS@NS>{rLA9'
    'YYgY%xUpkdaT(_00O6;&!=KFb%SG$L(bkp^{;AMR2_XI(xZxu4o$CBdw9LA?&N7N<uwpj}T0zJ4fnl<=CE=9hxa`^aHIkcz8G2wk'
    '5pFHxBCQ3~s2PCXP#YUliy&9QxcAz|*2gsnj?^ogVDqk8JYU2GDfh=8Hn8LyzE#`qxdfAnwTbdMOI~>6hvGu%7i+5GtfmY&IC)~0'
    'J<q&ixleU!kD@)Aj*tjxixr!R<^E~2N|BjJZ#EbVY0rL{xoxCL`#pVipWxQv*>Nt_M+fIFNfdFB2nAdSb=ZF0xqu$zRlk)#6m2Pf'
    '+GztgPi#y0;BGe9JiciYUJsgCxr9}eA8s!2WS?Xh6e?EgdV4>6Nb((Zm>Txt0}Q^fxyzbtO*uO{v&~qB6W1_ueiqBv>m$Z`0d1dD'
    'e4T;dx$OaWCTjVHw=R5ySKtrhqz@sgEV*>aYSSL$fz$Wux%SZSAR@{CUS`G?#4bOGf$Y>zoYOv?c~O=zL&7FCx)A({n|CC68*W?!'
    'O94qvW!oMmhXuq3mrG~LQkKjBx<mU*xHF^+X52mddU12B)l3+LYVg;cX+6Bek737Gx`|6^%?OC8CuDqZ1}MuBqp6E(@^=p>qOQRD'
    'y&n5Sx|&9u!QfYs+1$VR|5KaN>iFThgoWX}l)_le$s4*Ky1{q(?Nw7H<E(34AT6+D&qV6nac6%khI4jSi%rm=y24HpNSlILf-1D5'
    '0d#Y^+u*k!D<nxr$NGWS(lK^ky6G(&yIb2_V)+#UEZ-wg*Fu6oj%87UtH?E>UG~n7y7}+5O7En(ZP+|GazB_T;&=Uj<deqCUw%>|'
    '$39|UyAN3kdh|opXwtJotUPvhnpl+K)I1v`p2=m5O2q_~yDmXXTrm0=eLgx8KowOBIF83eX88fD()}RX?NNfTyY+F*g{={VkXa>5'
    '<w$}v)TzbQ4<<^M_zyv(vfpQNyhS>|dNtFcj-}r!4zOq_7XzQMMdj&ComGf$mJHpgyo!xT)e(x6><}`Xx_SM$gHPvVK%rw;cYm%e'
    'A~k>XyrdLWfd}X}3&g<Hi9or&uh46UyX?Ok6Fr4T!v<A$yu3Wty;p^6qd^2&FHb2m!X$GuXav?j&RibM*2}wAyyy+JSrv4-n@cnl'
    '<{B6x2o4swKS!&;X0iWDZV`|!y#Toc7}F&(og*>wGmhl2Zn{Pd6rXfBSO`{L`E4QGy%*}82su|SIGW{|&55CAdW4On8eS})3N9_R'
    '9%LYiy>2$zLNK%N;EfuIoTXZK6g}jp<_Dt^qELtnO=GZ^z5F)~?PeX~Ah{&+JkO#ILs-V-lC0;VMH}C>!H<C<zDETJ&E4gB;QCBx'
    '1hp&Eh~*#H!%2bG`RW%$bx-JSzSKR4haSI5e5-@BC@5-ir)#XV{y_05h=~@|1RF{!zeSe7C$eRWOZkes=Wfv~V(1+|1!CnIZ^60h'
    'RU(~Rzh)%B09OG|>mrbgBv}fZDvILw5;N3;Lt<#ty}xB?zn?mDH#Gop&bod7IH(&@=i}8*&S{1UBZ=VDoz_7rzo~T)6L-xG5))kf'
    'NN3g)>vHs|_C;@K>V;c;b5n_bztA@`$vTpI8H&js{Z_owB@NDRg93=jX%)jzmO2IRzxy%`bWdcIKu;L5+QU_+kF-QAV)*ti6TgY@'
    '{#ovyz(${Om!5kd6tA#>U+2cL_THEi_VKztcXVqc0vdiBz;Bf9!eCN#oF_nNR^?}V7*Z_Dxv5hfWU=6}J*dg&z>sc?3cU{m(Z;pG'
    '4qcOm-3sNQPE+#9_gVBjFrmuoz_&@H#fjrMTNPViBxd2ydt9X`ngFtQ^&7^%+sG~O!1=cY)*OMHQVAaOvh)ywzDJuqX;`_7I;mHS'
    'E1qHN!FbA*Umb)`I0)0Kal0~V5WgqqgEe!daf!1&J2Fh^!GWR5R;$g<V~qt6G;{+uB&Zclcu~7iT>{GPsF6B`!HjPu`}?~;@#_+='
    'IWT^<q&3XEOmFT9D!bD8d>f?-!PY@aVwltBjf>5tc%}2VC$7NOC)T|1m>Ezft7dKa!T{$U*cU3gD57{2tRznlgH%WenuJM<Hbc?t'
    'L}}>o!bv+{Jt6O<h%=hCJgTR_7Lz({Ohci-m&fp$6Tv=+!b>4F6COd1r(}%JJE-L8=<_>b6;(k54+DGi=6V*O!cDaS#Mo7EPlg##'
    't}&64T(w#QOnRyIK8Bz%Xw8R=!e5xCIQ{(`pafvHd<j0&e;(dT9pm0GQ7V4NQm+#f!i!^r)|*wn3~Hdg?Ahj!LZAj3$q#!lCxT5@'
    '&7jQi!k4TfL3(Tw5nI=j$?XFtN3VYJ`8!i1q<4@vQm@AK!nw%*Mp0U<Yb+=fiC5{+56zBP@8claTHPe0TameX!p{(wXXlH5n~YuL'
    'sOIC1eqO>B*YlPJ(%ok@C$?P^!qy)>tE0kdQRtx{-nSgCOvEizIR$rt=ivII_z4BX!&_d=u5}0?$069yH|GcM(?OI$=-+Z0<BGjX'
    'o*;ey!*=TAvW!;Uz~vh*HD2J$l#trO%&6nY(7_23ve)Vj!=I23f(3=+>iQ+;AJlZI4)3&OdXBoi9D7VQCoie$!{2SX{@ah|RuNI5'
    '-wH)}0%?6*LgKtQ+t<9~UPJ$|!|=kb(oe09Jc0M^dU7&XBwqZf;-cgi3Fxni_;P$^#03jAA|u{wu=gU~#U$pf6;9^eR_!HF>%t6~'
    '$raw1#10^)BM$@xK)1*gK869ZrBY7-GLx1ALq%Jo^_Mb_#H3VADXs*|&fFhjCLFj0zp3E#bE@?+z?iorVoZ{T#H$;NsVhVzUeH5|'
    'd59#6NpYCpVj0kqTY^!Wl^o0Z#IMHHN7<E$8zx(ndeG>~eBPOP9io+<N}D_+2T4*!#Kx01n=3ey_(Zm&)FSrPkpA^U`_V4-U7HpI'
    '2Ub2p#R%UB*Jk=4GK>04PX!be`<Pg7uJmS6E}_$9wg2Ey#c#(4)C$s7{Vkk}Y?Rz|LdnJ}ayZyC7>gLq@eg1f#u-jfNG-y8Od?C='
    '<W*MHDrfwJ9MCNB=1_s4Y=yTt#w(59qd3!vEK)3vzz*-HGG8=JQ#G(dzGJGwvN-uD#y^g^cd2g2po?eIb^SYm%JQ&rOT@fn;lC7y'
    '5E#F?#(5Qq!e+OU>?OwlB^I7dI)s=4aSPAVKJ`j+1rtUU#))$FX}yEyt2tg$@;Kb&NC{yt!fG&;7o2Xdw}W`y#-hl7t({%Z3)KjL'
    'z`f3m%@y5h6ewgG)D6Od-X&qY#=rwIeM6)sN<?Wp9k|q6V>$%BpI!$}FPRn3-`IBb$0<G)`HB(*IUQ~R$646%PltuLVM!Y86F1c>'
    'P%#)U$2t@((XoZ0BLb=JMvW6?zWiwHN@2Otpd0%D5Y3^z$6r=lyZx?BF7nro{XU}kiXoZ~*iDYV;n7qx(zWbb$Fl)<!uX{%A@-U_'
    'p-AJ0(ajwt_3iV&99~nXL+IXU$IyWL77uLaKf*@6V1i!L!9%y1{e_?E5>-uD8GK=l$KE+!wlsDq$_wQobtXJ1C7^@>1Y9QTj$@;|'
    'wz`V*$Lt~afO0C0I^=1jW+NaYlYHEGx}$zL2%{eQx8I@5$O!MY)u)BAM=V-J+rpf(>p7b&g=7V@l5S<F%$y5y$V+2XYA^<B%+X1z'
    'qO=IRQFzet;Tq{J%ipq)7IDE=$XbHA{7zEpny$;3Eu3O=`KWr)EsPYFb7gFo<b@zY$YBByqKc9+)@Znt$Ra2J3zG%#aE<T&sIy@k'
    '51%sf$d^BXp%u%n**XUYXvMJc#76BMEfc{^@GEi0q%t#4$hkAIVk(*KxE9JX<$1N-U_hpkK2d}y?r*m?N1d$e$n7J~Cqay|c4u(K'
    '0aSi<8OuhKFTu<a*ZTo1c9>og$nB=k*O`m~Y64*0rho+9T4Rh4E$`f>b08(4w&cg+$r-LIWi&6}Ep3VAu=ACD*vWl56QM(l^_Nsx'
    'CdP9r$r}w4ou_JHn2>-6yzDZ+xcSv%j;L=lv3@y5y9#QD$uAD&nq}~rb@fi`%t?c4&exq_h2c&WZx=yQUqc)-$!ddn8MOql1yai+'
    'n@De1?ZtOXzBG*Y^`$ibHO;*W$(^?#Z!xv=2F_91-5z(*G`I{kQAs21A%pX17JrPa$+quERroc09tEI6#o1EE!{I%raAoE$+(*x~'
    'Zh}Do$@Ti-fe)%=43`VtO||gv!U90{#9Y(~wSi-Tofwpv%6(3Jdi&gVWQu%EQ<rN*b2Pp`{tZ&{;uc5|N)T_f%8}0q9N!kVa@!;a'
    'V>H3poM!{ON@SfngOyIGhgWsv%Aqk29Wv0#r|Ba4KkTw+e1zI)|GV*Ao-ErL1(p-M%Bo>53m5S-fG&myrONG8MnzVAFR^Q?wJ)Q@'
    '03%il%Mwn^t~PoLv6`lfO{!2v?)j@hYg?B$a{HlWA#;=-%P9zT<xP*bN~B)dh1~$4yGNx-B8F4evo&-_GFYdw%Rf&k**=x{8fLi4'
    'kl3X@w0tDIIaw56nr{47G0(^R%bIPOOO$?~-?QSJRHQ83?qdf6Ak`8`q3eT&&~&QO%c3$a37<knr4tP@Z|bC7nsw@<Kmm~4W_{_2'
    'H|fSh%dB%?^ajPKCq&8%8?xlmvVkvq_qaut<8=C^Pm27b%hW^aI(!Q<jUpKv6Y>I)vN4U!%=EZ>rRkhKC9c9(%i1=^aQULry3hv0'
    'bohvU&Hbf-`7X2q$TyffbE|bJ%q-P_#80~hYYgBRH$;U<RyzVnimmsH*K-9B_P6K}%uT@>7%(2UZE!2r6pl)2V8Y|epf_GxK?I^^'
    'CkzH5%xi!<Nco6>hLK=lNWUD)AB*hEWtz%TgZ98;Mr|vv%zZX8Xz_n)?tj;;f@fd*QI;GOp7j$rH3#Epar78w%-6y%Q=+f7NtIE)'
    'xQr(u!nP(ra1i23H0;!)dO~}i%?kF+*!EobJ>3Rqzvu;`kyWAKTW*@GBdq?JuHcQ7%~}Q{ExSn6MqdI`jiHG7ml6by4U?I#!n0f!'
    'LtTJ9&6O8hWU!^pR^2bSmeYw}NQSbR>S4B;LUE`%LTj^l&7bT5h%U7gTF$X%ZH=I3af>%$`cRGZqd;3y>ucum&Ad<%w;|xHT|1Pu'
    'WvI0oXCU^jbKeJTPLlefa^+k|&J~gy(&VB8yu1(Vk0`)dX58t$awSFgJM@bSYsZ~w&S(3$RvtM~UZ*e&akTU!!zuHYRqbFAZIaBI'
    '&IzUj&TK==C7@}15;TQ~?IqNPH1)Mg=3hg}BteMFZn6zy&Tj-#6|>i^#tUSwz-S#xuWfM_&W{EH!=MHqGZ!D!&Yc5%o|B*|w85Tf'
    'w-77sh-1}y8^Uhgs>@EXa^8R!&bsWEnHsT<pv;TVP~1n>YaMdL%@&yp%+Z*h!8teC&dqo`q>4~iwq{#?R4s>5LcliF?%%~!)*dCi'
    'nm|L3&gj%vAB2}gJ?kC94+O@7Mr|`Bvn07NK&U`7#r$>Y&p#=L@xqhHgAI6}vyL%zp8vMgdDB1*_4%XXdlUfR&vp=Ok$>Wiu0DWD'
    '+*DoEXI<HAku7eps*v(r4Crw+&yEgpm^*S3yaSZd>U6Fyey7w&5X1pJ14JM|c6LV3&#%E+iZpp&d?uN`Un{(!#$te>w6^zQctKJB'
    '8H=pX&$Fi;8xF)8sht@W*HB*&jM7jOWLGy0e|5cQwBNVP&&<C?iUegesALYaQouHjpX5jwB10iZ%O+@pEh-R?&?b#wu^z3ZdE~Vs'
    'q9y9KoRS3e+!o4ll)IJ@_v}v&&_>mo2d@0)9px`jUs=xH=4tIM)m>(e8DBITL&xfa&~jQKV>1Dpe{SCRbJKquPk+i!t5i-fq4X&?'
    'KW*1l&~lM0AY-?4b(Z4bBZ5JJ2$3G*v~UWy4Ekg7tuWt<(0S$(AW93!88~>GrW~cS1>UY;FI`M79L|#|EybOP(2yOym({*+!mOY&'
    'HPch^OFJXv+;9DtA@IK%hFFav(6u}!9F~S6`_|(9{j%1EWJvtW^7H%nkWg*lYm4U5(7gxsJ-;F*s~xMjwkS543Cm=cfr_BYELTz*'
    'xi@S0(9}XvpTIVGZrLFrM6rcvI8>g=$gskV^46t?Q$+)t(Dr9WDR&v?=Oe?GR{E}Nm>#N8EJ;i%YmR`k%Z@Kw(E}4n_Na6aOP8w='
    '2<RyNn>dxFZCcuU2dA)*hBEXO(XJj!s#`U@&X}`%$j-uybP#G1j4uI%SYuDy{2vSY(a9Xfhi5br{)g#T)IafykhhltD?Ix=7S2b|'
    '`D~Qu(d}ulr*PlLNv8O{^`rLa1Ra?g5(xtNFXkIGvEs$u(j$fjcgL}OR|C?Smg#fb6qw>V2j8I{q6f8OVh$;_(mt}i?}pnK<Kcdi'
    'D{>QoqI=o_h9*qXoLxg{p&=ty(o5he>4H*FyQORia~$T_&(-BI$a0M|_$e^8c)$h3(ukce_*bVoY$93?`1B)uIv_oC>s{9mD{0Pf'
    'v|MLN(ykQ7MxslLKaHm8<9QmFd1?){V@71+Xdo3JD-{xg(%lNW;Q+B#N4R~A%=TD#CO>NB4}kMN)6~WWkG>%x((%IR%%bcwr?Fu)'
    'eSK*@yH__;Mk6|RW#d_hD4+7d(-vPKX$>Mc*&2p4VOdN0!L+CrcmURGzRSx?pnkn|(=s~iYw0}OlW;qP`ydhu(qXZ3gL{S}*_xQU'
    'TY8?s(}c_I`jpPvdN38?#T!>mF46~7pT-`#sMd+I+o2lu(}^V*MH;NC*a3RHF@xCSL69oepBz3H{S>RtF`&vW(~E~16kd-<R4NEO'
    '2}AhY+~i~ho1;O`8}wMvIX%b~)5^+jiz{!amz6Px|NnzZG%1+MzY)=nzD%4io*cCe)7wR5W)N5kZpS_G8O4xr4G8oZKX)?qh5am-'
    'BM9JX)GeT7<A}^w?=n)-9Rhfe(of|szv`X}^*C(`_p2w4)IHkSVPO?>LgxGgau1#G^j_-O-JePE91h)5GBEeO)KDPHGY;o?G>s@Z'
    '*Pq;%YU|Mv3o5+|2Uh)}(*aGt)PIl2&tVRdpwQdHA|MIZQ1c0a8F(l7zWqk`P9J*z)Z{REXXap*I`7%8NEA-@5#l{c9SCw6b>OdM'
    'sGnF1)fo1t>!OUG=Ob78_pHnCX-WYh6OMt$k4M+9vAAA#)h=!CX!HtC^GwT!-e2NMI%bFL)|R+3tE{26R+TA-)mGv@ALG1aE=KEg'
    'vej|s%`!ItNyD>IplvQWUvJ<L)zbvp`A)VW0(VuhfQ&e<p6~=T1gUY?ez53k3%O1&)*;M~mOfJxcs@n3n^H|LG5}ZK9my+kvVuou'
    '?hZLC)=S{dW<vB2Ijs8XTB0_-w8L6aj^Eu#^#M4>KAUEJ)@ZQD{q$tzcGsa0s|5_fu!?lWBo($--Dd`4pCf)p)~288Y@Nc-GWb^W'
    'uBy)iZ$pB)UOx8DiMb4TOEUo)*3A>hvG`x-NB4S#s`LWZ$PV`IKs!Ta0?-#Vh+ucq*65raB{{>^yI*Oc^*%MUx;PKaCqw&cUL=R%'
    'yZg7h*C7K0F<sV%MyiKstq5ggeu3f%h@}nM8AR=j#XYF}*Esh1?@M+%7~`_bP?pk=Dbn6!Y?}>Z_a)BAz0;4x*JX_Fr?>;~M!2l^'
    'g?mcJ=E1%ginGY1nD9HF1eEoq*LhNnOQNEm2{&8Q0m;iet;HTXA+Nfk<FWcORoZHu*Lihci$BaE_LLpyItg)s3vQjB!C&-2cZ1?7'
    'aHjqY*O!l29KPUT53e`!@yzQGYYZf}f~{%rl8y;;yt3Tg*Tj9ilM3K!I=`Gn!XE@di%(!c@6nfqb16)z058An*T*cw;K|%#pVj5a'
    'ba_FAOUi5i81xz*1J-KR^Z1Wo*k?w5e$+)zcoMx8iCLJ~z^?~AE#pb-N@T!ha|ah-*l`Z55UB8ZI`?Typ8|-n9LK(Xcm3j%MF~(s'
    'HD89n*qiI1+v=S6_3R$JLvO?TSlgyn?mlbQaipyT0bswN*q}7LNwIGXIb!x=DY0%1@BrS1&>f%_Am~Q$OKv$=*u_(rq};FQ*<4&Y'
    '0b?Ppc6j&&X9@2zha3V2Q6V`k*#C@2li&B<^6a0&qfMGOHmeoNrpEO^PS{Q3pdBCe*#QTqx`i)7t(AF<F`rov2{INP2*DhBS)3A|'
    'j7I?S*;YzHID`y(#vquCy_I$r)?#%IHX8t58mGb^$G*bL*=1XxpV;%oVL@c1@LPG&z<3a8^%tsVU<Wm=+{D8<*@{N&)NmlLKR9<X'
    'DLp$-KzcoeJa{GR;s4k%UxiVW*{o}+b!id6<kr?P?wnDQiG_9f7Uj+sVGt-akGY%e+14y|`Oiu$Tr`Fy;hU+@;&JVG{wF|a`zW6k'
    'bWYD}+2juy#~p%alWQmYKqv4{6yOG94#5bK!}D6c2axgU+6bC`c+w6w=9kY|ipHU0cwb@o*@PP)K_#MNl27N{+NW7hwe0~-`&y_G'
    'KB_;ntof9&^<>kjt0C4d`POWJ+QG;IVpG?Si_1V95xy>!aUyK;v$fNv#{wp%(Jnuw+R-@h&=xt&QgzzM03wLhP^f+rAFsO;7~v(_'
    'OPd!a+Sf<O&fG?)1i~Q?TK1PD1x?}wo0cRZ(1eEV7(f#2+X(9|@4Bczbs4;dDlqk#UU!wkG5+)$1?S&rs1g!)+fyK@<KPFHD^PH8'
    'l*XDrTr{PChbVW#U8%njI0K8X+gDBL*1}d)qwfgdaee56E|Q;fXZOZ}+h<7OAGHWn+g|VcO-pL$tIc56e0)fa2wXJ}Z6iM<x0Nq='
    '(D5#o+rM0p;zbH%ND^sk-%rwYPR;8ysPdyA)Y@yK+r+&I+w<&P1Qjq_lbbmJ&q|kPd~g{^ir2O_X*K;dvG=2L+w`!RZhSpNlk-iG'
    'sC!`^i2O$}8DId(zAcRvvM&X*+%HBhl7Wbhq3C2!aVrzC-s4rGhJNqRwZFS`7kHo7+(^e9ZceMB<KTtQCO4ypd70b0;t66b(X)QH'
    'fm!6^+*oEDb<YLRP5DrDk?=df8S)4en$R#sZ;{@Ai4dxT+-Rf0Gq{N8a33AW2mOvh64&ARn+-&QL@y5h+;QgR-8WyQbrtP2%F&c?'
    'K@vlvZbW#*17QldlcL;Bu&S{}-8@@SM);5?{FA~NtzcW?`3g#ZfZ!HgWl@lHq_^_{-F_9Eg$6zjh?k-oFo$Dk4J#w+JHqe}VmqZ3'
    'WHdsL-Na|wDl@}O{Etyp#x|l|4Tnd<LD!@;j<$*f>O^q&-O0et`qzhY3)|R#W22S?uJ@XVnD?E%qL(3`N8{ZI-UOEjdcp3B0QDcz'
    'RIrONWy8)<v|*t^l#Kg;pVp1S-XyfFE@sPvBu_qIUXE^&myu;^dO1$-)pW=#^CJ=7-a`ygZ!jP%EUQp$d$ku6_-x8(s!;d?`nMC#'
    'BB@pi-cie_xZSVna;|t%H(oQM7<`2Q(@!jE0Y7Qmw<3$P-gWAYYG_9P8YnTVr@Y@{7LSMi9n~|S147rT`>ACf-kQ558*86HMyekY'
    'aH@q`2Y~M)fgx3xp=7Ban|Wf=-n3KKK%zlONA;YWW_msr;|!f)R&u>^Sj@n4zE^Do-oB#7_TX>)dOA;w4xN3$_U+?boO!#e>&sPK'
    'cBMQT-s$;ZFsw+A6Wk_<F7KfF<IkC=x07$;>Z6cG1flNR-t{^db(lq5Hr{5%xJMN}k29i(T|fTvsJZs!!n-^K-+8XjR55+M!ISB>'
    'j>zaU_SDdtlJjY-X@$}~mrwX2-+Bn40YcY!rPN;4guxhOd=zVHualiZLe~~I68Cre--Sa;%FJ-pIi2Fn>x%c040F|<CmU8w@kMn#'
    '&Vu;N--~t~C%3TTim`1##=MuiD7~q)1#2Y%+E<a6+A?|=-^{bm!DHaIP9gQR;Ou2)_7M+wV@H>{cfBl<X;<&P-`NV4Ya^VDdsBAu'
    't((U%i!0gM?e@z?e)ykS-W#5D-`;}3qGfUD_1~ac^-;%UX0q9I+?QZWLHjy$oOQlz-|>`e4<wk;z6<t}s>O(4gd3zbnL$24*cn%g'
    'cZ<W+;5!ffDrJiCBUvD5)$8$7GanNk*+W@(ZW9=1rGr=7;9pay%g-5EVR-gS<CN(n1~cjbhvga_AbN$e1vT9`;E;!?D_&>2(;+g-'
    'F#w}?cl9EjD%^attN+M{B$l|G;O4}%I}<c+8xeY-+>w1s>!H9CpU1DIGi4~E%{cmN;Zyo^)g*N24DTu$JpZS?qwA3ma3l-Dv$*R='
    '2&d*N;a4YK&OrAcr9Aa$UvDl;HQU(|l-;T3jj5I?s#6*4;c%G!c|=jskR@=)S0TD!|E@z$Je!hMxk4IdpWreo;c%nPK=S4-sKfN@'
    'aE<zIAz1X}G2i#gqWtb+%2oW+;dn#_kbLh!4|p>S*>_w8KEz}nS%4MR#(u`IlxY+~;fyj}iA1*(I3Sv7^}osTO<cge0PODB-Z$9C'
    '=1?4?;mZgVG;R%7zw#kNDq4@=UOh;vYgz&@2PuO&N1_4+;nF)^uY+0mi(!NknaoubUYqcgr$jtvC>lAaQvI2$;nT(6Nr@*Id4d-j'
    'H=z1XwJ|~WJ++Jn2tG%r@k}8a;(Kb!5X`8sJKS}(a<el;I>x<v9(u-?vA?m$D!n8s;*O%7v9AtIU=P-X9pFySaFsq%lE0d@0AMFv'
    'qNmX<;+tvVPjiag?04db0RN5~)qBORYfb+dv`)>FatgRY;;mVX>{9XGD<d(I3H-(FD572-=kAh8huj=|Mn?~n;@T(pPGG=j0YR`;'
    'ab#M2mH)2*15e&-G6E#Pq;+rH;^*$F3?%AZ?-sDntY5Y~K=@d6A*Wgj3+PeVw>W7O;_bFZmLfQQY<u|7klaNExI*2X=+d$#SP;>G'
    '4#I(_;}u5Hwv9yeOnDi?&W_8&1ncjUAieaq@}H%n(Emd*<1@43`1Z~KiU+7#kJGWpS~X>=trq6Rx7_+TU2(#^<3;$RVJ^^W96U*_'
    ';?KD3zMmJ|Sax$H)X9!XoA%LU<AKhU`vS#32iA9@QuxnDLNjlyf?jM7QUz88(VN%G<FLd+nEV_Rn)~#~nQyryC$2%{WSf&rq?MT)'
    'cv84k<M=i5INY|f10ucXJ`{*&q?Yo1dpz7^4w$sdFhWMC<P~;w4|N$O|JZx|?jWWoHMsBU{B)ESqKa+G6lq>u<QQ|?rR{DOo40sN'
    'MgWPeV;sliJT4HB$5*Tob7($<<R8>`=0vHDXZ`FP7DlUvytq+3hMQv3@mr|6#LZV*<U%=9;R;EZ!&W<wey5cDXbEXa^*@H%e3n!='
    'pQMa%<lj9{5QHWaPvqV2SEHl}zv%4l&_l&VXzyoFx5xD6<pri*3<0PgPH4%(8EWT}Ju6He=XN>cfJAMRTt!bK<p|1`+=X2|NsD>t'
    'D5Zif)^U)7T@N~I-q^Yz)J=5*<tzEVz+Ty2Gunf0o7-#<k3gmwK;pO+3P6<4*3EWs<%IqVXdp@LE<<VwoImc~?`>j?hCHoPd)Wbo'
    'oN{@(<-r^_<5hy>_+<Kpg5;P00)COp`nX+j^F?i_I=dN1<;SV)A^?Ho8a&~wK$6;!;aNd{G9JR`j+}6}Gj5-><{1OtJNGqP;3TRj'
    '@6sKvQjrf|Ab<!csz62eU{|bo<|0`1suZOsz6Xfb*xlx67)+u!QXDNimiQ#hxq+L(=2R|A8fo!B9yZM-sp1z75Li6Gnh7e@(Q7&G'
    '$0A2z=8pY&>y1CAQHP1xo?LSuj6P_fb^$cN!`QCE(9&_W=E5T^_IkEgI%B=-U;Cg-Lt-e?pB>LiCGQp)*AoyN=F>csP$-68!TD>*'
    'aLOFiQX=N=o6?1ujVP=yJ(Tt&=SU#9e7=de%tgarS$|3CmuPAtCTAVL24Z>y+%FXQ=dLk%nR(H9(62eP!&gZBDD2Txtuyb_dq7tX'
    'qts(H=d{fUhN1^<tq3@Z7zL^tQrak6Bxw%Az9%M^#_r)I=fv7bEVR#flu=-8-Ws`3G($k{0gMxK>_ZcNWRRk$8=Jr@Y3I#TOp9fq'
    'io;8Bx&ozDz+AcHBNp-TRfFk96hwJQ3FqD#1ZCX&{bqBgG5o_FbgSayyz!4gGaJI6CLi_A^ymAm&J>9L$f<{9Bn$)G5ZQZK2E@AO'
    '$(M7F{cw7Jp6CfY$lJtPh<6mY@AePv{Y8GiHe@<}MTfmxJDc767U(33vx*Il7WdWyN<xt`xRUSyZtYM!WE1yZHiik?kLWN|xmaQi'
    'HG}Y9lqW{YE(-nkqjmi!WS&Es9+QJ{Yv?>5Etx^rWx5HthqD5|6sh3sG~6X7bDfgCW#OLE>*$W62*Eh95z&UJZgesJlWe%|s%U~`'
    'H_*>*Xx?8=4d{=Rhb~259rRsTo9hBhF54Mz{kP*PAl&X9fFhpYm*|@AL>w5`tBkJx37>V^x|yjA{kjCVV$l-AmcB)|o#>+KMJF~)'
    'Xi_E-^QQMw-k>uuZyk+@WKoexWC-*qUg*H$9Mw_&^kEJkA{6=@X!t)h&Gt=A|59J5^B!WgMCmxyK$>ov*w{(D?U5zZ)W`hM*;Oj~'
    '-4DOY2}QLeXX!@F5QO;2M57GZbt6NJ@rp1(Vgu!DKP57KulYDS>giS8?1E+t?7uVDz!$4-U!E+?@Ub-my<PFn!TF~fBk8;IsV9Ti'
    'azg>$@kk<iYyxFP2dX9|e1sTp?jTjZB<cEv%SnT;4hDKvgaJ{oyZ`ko+H6I(2lbWO$Pu2Re(D$eQ)yf2%|LCoC!PO#qf6P~xi0=b'
    'E9nO2f36aEk?Jzx^qcBUGLU`{6p~@jxo<P8YLccjaRG@!Ow(th?dm(S1v#f4X7P3wDz^%dopdxb5F}%->yPPV(58b$F6u>|#V|eK'
    '!Gsm1i|Qf?ZUfG6>58X;Yu329KuUI8i|T^{8OeLpwx%@X9Iwc7g)02?GwT9(+-r=urJtgP(dvX7gEq#QywpBM@WwoVm~JTvRZ#t?'
    '`#F6qnd&Nzr0U24niRi6iho#`<dh(5d4SKcdxdh9+EehEe_JiIgzDl0eQU(NiKiVkT|?%=1_UYAlQsf0Akd-nf^tGSMe7|IM0}e>'
    'lRh9Q4ex4V;HCki<4YdzlDkKM^&7-q6zegmLroPH1+GO0Aq;oGhoa1P*gbKbvp+x44|$xG9qVYtPp;);%uAC`A&Z_R$KC%2*Ewb{'
    'H^NSrZE98w?CXv2FemkL*$^O6G}TDy`JW@Puz|$m8p*PuwGSmcJ?qCrEOt3W6=23UTPI(^JeOXm@}@^dXY22*H#h4b73<o-r2Utd'
    '+B*+B|J4jIEniL%&DLReo*`{m8RR~j>+C@$lg_);*shs>Il~p<VhQP>IcF(EFL*mUWD#Hu?d(MwY))I)estqmzOPjkVO<rPOV4Ep'
    'c{8ksz97P{d+b(*N8Za)g2SINp4;YiWwY$gB@Bb;RV}k{$3KRZLhPDH?ix}dM64D`qQn+;$S$<i!*F4UUB(I((-L1H%Iu=k8=vAM'
    '4`w@PFacz-VV>=;*N&r)2qf%3ur^%3uI!^-q;3FIv4XVeq_G9;U2yz)ON!$7(30=K)~&bPUhJij$q-*75F<dui{nPubl!dc(5PB{'
    'S-%nofeOG-_3X@vzeOp9#_%>OJB7q8TsiL1A%`Eay=O$2UIKty&+QT(w-m;I)>I=OgdR>w=3E}4?gN>Khy3*9<?_}-;_V%x8}I|S'
    ')VPNrkWxQ;;@NjQz6p??bROqC+H?=y(Cwxf?)6$Djf)YG6F#aVoeMD%Cu9}AS$-#)jS9`>u<fYX7~C<e6~v$o8huj5LqHBOoB3>+'
    '`$r22KVOl8VC}?`B;of2TdyQ<n2+0{CX79;=$xBER8Ap|K@dKJ_wE~~UGyEcOQ*I}Ef3JAKkYd*Kr#&NR{PymD@Wz3Gwwe)eZ>na'
    '>lbpN%l|Dr`%|*MZ8nDPeDGHV+iw6Iq3)DkEURO)Fn|5FU4u)y!>y`jF99qxBHBRi!Au`;$L^@z$}}ry7nIfv9?!&A0+*@@l3~gC'
    'W-IYYo&*3Zs_v{sH%lIlr90Khp3`>cqqX#(XH*;(JWe+8QGdL~l<u^yq%gAsqW8$jiK7nVua=0c(W&fqf4;s_)*QX2AMU>8(Jhci'
    'fAtz_M1R{<5J(N1yKq|iAowZz)-}(u?e6_!)~s2`ns5jwP<knwR}^&Gou9b6X3LnmW0vo3Q12xBes95=mM7$(|G3YIFTCDY<bz6I'
    'I}I@G&ipf$Cht}XUg;|=ttS*uuMZG@jXNJqysW^Yk&+7UR9#}X>hE$%hZxs3DaBp$zh=bu3We!Bfr1~warv5~D_L(E%I|YQ!`EUw'
    'iNa~mfi#{<!<zG(f|h*M1Tp|G>dVPZ9q+l%e04bAfp``*lk-MIhn5clE~yc#Cr$#dAoo>IR`1B^u#xXd^Uk;veaH$tqET;Rf(KZ!'
    '?Vh_KFryJZdGG}rMB~tr(662iy+F+htqG|d+m&#WA)d+Hdk>IO2=E1<=RJL+Az8A>2UhhThq}?%9TNyWgfl!k%uZu(0Ps$%&}eia'
    '%xq@@W-1WONH!eatFL#?L}^Y9K$MDrlJMJGy!Q)-AH7PiAS(cKeXM%T`jv*HOb?pq=<kx0@$n}?bGb;+s<GSA`kwX74Q0!+%l9Na'
    'dmlYNq=(hbMe%uOt7i`KjieJv`254cnfXnjWq^_x_SJy{+bJ|>d-0LE;EJ0B=&>5{D9wtAfQ39}+VM19#09e3U~&!{lJS+Ji4I~x'
    '$6mo)PP1=V(%?oj#PzF6F0|{%?WOu7Z}Ir1fQf-HCLKhjSu!H_{+J<<;A6Ib830ppd<E%pR`LHzyN0G>@B`|>x>$xa!(6^j$B9hJ'
    'eMzp@rw^XA*76)`59gia#M8pyTk=JQqSR%PGwWPz{lr~Jh4~S)sq!E}AOaW7A`IEDIF}4;0w8x}r*0Df2A~51mae!IPx5^lv&Djm'
    '0qd?wfCO7TKqj1&)j}L$QKMnl-M!|<&+?_au28r7-f<|isJydw9Hlb!#T%5gDMoI`qJQ1=UGlYy8AKS~Z1S`wVD#meNQg3p1^*@G'
    '^DN?w4EbEq#qz+<+E2>=qua(r(3uR!|5QEwhCig2k(I|^k69x}jq=HFX6zpad<<XQ)MQ!Tf$Fk@7mT;LB(piTZ4g7KhVs;7*hYlN'
    'rhA=J1q`v3F(3q-TUg(z>25+H>nkvi!t&Nm%5Ji9qDP$#;y9oeq$!oB=8uLThf^2{7LfT5obul}k(Rhb{cCV|rTAg`#`$N&wyab@'
    '?GBmScLBU3Qu6^`d5c;p0S^_HRS`U6CMX#<tG}l9jj5ue$C4wYd-F$6)6>`FU<KIo<Ljc)H&@3*T@iewi1xpCbWj`4?(=U-CXr8T'
    'YUc#<?BxFhcxi`p>siy=72wa&ZN%j7T=ReuenNw{W>S+})}5tGU(H1<Dua41I6BpeqJ-R13iKtXhR%(ZU$((s0|7JtGUoanssRbb'
    'Ploa(1>S*q4D?b(RmeYFR?E-H+#nPJ@k?<?0(bb`jt*fW<CZ5z9`tVR`faVyeN@PJI{eC2DM{!kvh7bP7fzadBqCi)VD!k}@yXcR'
    'P&s6m821yR7lOjO+ehcCU8Q4v3-WO!C-oF{pH;-^`b}rrJ5ElXUe?4pH1_p&t83t<J2QdrQS}t)_Z%mUpn4zfPX}~V+2%{2_pY<e'
    '-2ds(&a!i7VD%MB2s{K$iB{H0!>7-Tnuh0PNda}rquCxEah9ww*Y!xnCIi<LrYp5AP67Qt8?nzZ_7<V96FE9W34b`i#`SB_?oyQd'
    'VxjfG`~W!!_8qDj3M}-*t>{jA4xe;TPW6J^9pNGS$6VWpx%zjU7~iSLs=DP(aAET0gc~WisP(X!sUo=*_S^V1V<@mBuQ(NJbm{TZ'
    'aHym}tzqNF@Ag1(TS$@D^DL8cBcwO6$LoMiNvA^;UgX$`!&?J+g!WG+I2(BvVI2bI2}8*a3nszsoU9*eoBTi!r)XpWy!Ktu8XHM8'
    ';i;`c#GkXbQ+viT0PpqbSw6EXNP8JDQ1)lOwRpMiUgOW;eq_NJcZK@D;)ph>nDNe%-5g=}P4;*-!=?7GUO>19Q-}HmzqhG#9=V(%'
    '@=KS_cf+AsUiOYt2z_@ID-omB_hA%RrgSkcIujH9?Je7aoo4>C&-RuU+pC@UnsWiULWQVS7v@RnI9m6mLKL)+)t7i<XZE=63eo)2'
    'u~V)%cY_SQG{<QDo&jqt)U37hj4v@tKK9GjPtUC_Z73D^+@jG3D_5q^m34e!o<#Ayql&B_^!Dp|OL-|#mjeC#n88>S=Y(w~Oi{S>'
    'sYB@!9YNPhefJw9SguutcH03vZ}9<7TZ+p3wiBK^-MwHdl4kYo@At8AA5ty0O)H2jrdzGXk?18Ovn0u-t*AV{l8*PwA@{nGu$);f'
    'nfp9}P?g!p8P5gi<+?SdX|WI#?H~~MI`{VCCdWSt!QdDXuRD^pWbn5WZU?$#aY?)WS=3Of{`foI_PDYPADli1F-yYN)Q-{5X?x%x'
    '`Q4pbRzv}PHTZaBpWMOLu}?Wfu*y&Y!^g&4*PmQ}y521@FCAjpPxyH!AnXL|k%p<1b4TmGIr2U&H?IA*=$h%bD~s-QVEBVIM-1lP'
    'fo1}m4@z}px5)FdOQnR4KcqS^9v8fXV)%%N>jjO=A%H#}Z@K#sRAGe}%LJCktX7})8@)w<QTU6@c}MGlJ$^y)7jV{5PgT6@+Q3)e'
    'eu8v#k0TyOgZU)Y6kXT_MAI`^%(@JQ28#ZG!$kmbZeZZ~l6jhOjQL5y7PRoCil=}KRLl@G<4U#RC%b<HAxI3jl^Np$E%{pDg1~oD'
    'xry82ye~Fzxmfq`uF>jJ!S1wEzQA3HRQYzYDWB5+vRv8MJn<-ONYXiB!etteF$9>rsoK}J7WtmdV=@nQ`2^d6pb0aXAFUUE;fmE*'
    't#z@<{Bodue)*q{a^CI8r?9q0ji@Xm3Y??co%)@y|M~NWx<=miqWQCJ6X=SFD~F<E=RrQvos8V!xFmA~^yk8+adKYJqWQGtAJ(At'
    '2lBo;xUEROzsOI$rGn=qajNe|lT$iiSNYPkmLp0NSR6Jg5H$<$$x6jG&v}1d4Y9s#!E6b3-udPzuyh|cn#+>~AN7qlVyP)M?F11V'
    ')*ASRh`8Y}+WF^DyDPx+cB)+1WqqEk>SWWGW=9C~g<xe0vShanPx|#;v&VQwYg5ftBsed~2vVP|9u~L`HYA<m!AO6D%ljJpkL3&?'
    '-G8x9xr(?TA+<g1)l*B3M}VJYG}nZl*ZWP{tS55G{$tTN0gs4}ukgCWcL(s;@SIz$4%0cqZ2MLG!Jap7qS})@t|^eR8@N2?UgS3R'
    '3R1QW;`y*<E&GPt&?MU&JrmJb)lpA}r^If7I`00baApSaKi}>8nfsEULvd#fp9Hg1Ai&S3tZM%K1D>uM$}gJW<%E(>_4}qnaX8j-'
    '$d6+?6EYT5BX{$xo%~fM7BOC(aO9PkKl`y&6oi;G@eRS`RinDQyjerXB5tJFCBB8EKDK>cWc%n_EZH5jFFTM8{;UQxaM$M6e6j+%'
    'cg_?9_M&_w3H#`f4O%EXx%=q^eM=h})mX0ya}A?5C1AW}*iK78VEk@r-h@H}Kz924H>rHq0LBUGEH6OcASc>_UkD{@(EM*gpr+j|'
    'hX8?m{@=&U#Su?eg~tUw$XljAOeA<UnEY|hL28*|Y{4n#DezuWEh~`Ct$^(47VRKncQ_-AzWjV)kCxIIcL9J0+C$p>Ns@XoFZ@ak'
    'PGN?KYSeqmQ2dd@OwH-dfiEK)h=e)8U8yo7ZZQ@Ok^qh`k08TwEBwUlc2QF6oGsbFaTNL*8&Xh)0QD;^>gA(Z@);AZA^ifA{6yz@'
    'c3iC>-+2Jo4k6M1(XdWQNw9JOhdQp!f&F(iN}=Th0D3B4<WUX1DY)$Is5K|<i@pZ*hB8bsSN(&}K#>&761PkullYnruJCpx4o|VH'
    'izh(J*1a%Rl>Lh8foPB_|DQXCJVbRPTP%K3exq5`#>e13oNYB#`u(fd+)QvSc(h^pmD%is$j8*_jo%jY=T2|%mu8E*C;hh>nJ>Wf'
    '(Vk_?ijdlZ{~%zR81?V?6bP@d`TDi@to}ZK*e$8*wX!eO7HNS=ZUP=M5(01&c!x?r19(s3&Hg}{9~SZwGSy2aQ2nTS@(Hwb*+O?8'
    'll4d{PgF@-xc+?|oyE%=HU8D9vzUB!Sg1s^700abn|Cc8j+D#U?EbiA#B*+-m!uM2l~BTLv2t+dLf<E-s9T9H5-?y~k^a8Br|~oj'
    's!J8Ts4E{ujJWM83wSYH!qGg$>2n)iO8&|+eMrFh8oa46qdWg2$;)FgFa74q{5@E+9}=5}ZT{Ea1}#rqTg4?^y2D`^@2Ak^+fD}d'
    'fl58>IbQy^-~R*jVfBt49|+K*18}mVUbQ6nn`(gt)UPkORkj|z?EiNg{SX-Z4*KnCR>EX+12>1z-Wf^vH}4P<&?L#Sv;UfbU2V&_'
    'JfM%HPD<svfk82H2V`w_c>6#ZUhtjUckR^P!v'
)

if __name__ == '__main__':
    main()
