import base64
import hashlib
import io
import json
import os
import tarfile
import time

TASK_SCOPE = "Only the five previously skipped P2 tar archives; streaming read-only; no extraction, ordinary-file rescan, Git scan, prehash, or remote fetch."
PATHS = [
    "/workspace/p2-private-20261124/.lake/p2-private/evidence-resume-main-20261125.slim.tar.xz",
    "/workspace/p2-private-20261124/.lake/p2-private/exports/p2-owner-block02-20261124/original-owners/all.tar.gz",
    "/workspace/p2-private-20261124/.lake/p2-private/exports/resume-20261125-main-r1/all.tar.gz",
    "/workspace/p2-private-20261124/.lake/p2-private/export-numerical16-28-20261124/all.tar.gz",
    "/workspace/p2-7-20261125/.lake/p2-private/exports/p27-complete-20261125/all.tar.gz",
]
EXPECTED_SIZES = [460523228, 180870001, 582956068, 180765656, 584685232]
TARGETS = {
    "7bdcfdbbff4382da1ee4ba16ba9296b8995ceb11a43f78cf70af21f852549d39": 13577,
    "3057a949d9e0704484807cf004e9a50d0134dcdc6317a0628d18173ead3ccd4c": 14529,
}
TARGET_NAME = "Part3MediumPrimitiveShiuFiniteCover.lean"
MAX_BODY = 65536
START = time.monotonic()
DEADLINE = START + 160
source_bodies_emitted = set()


def emit(kind, **values):
    print(json.dumps({"kind": kind, **values}, ensure_ascii=False), flush=True)


class BudgetExpired(Exception):
    pass


def check_budget():
    if time.monotonic() >= DEADLINE:
        raise BudgetExpired("internal 160-second streaming budget exhausted")


def snapshot(path):
    s = os.stat(path)
    return {"bytes": s.st_size, "mtime_ns": s.st_mtime_ns, "inode": s.st_ino, "device": s.st_dev}


class ObservedReader(io.RawIOBase):
    def __init__(self, file):
        self.file = file
        self.sha256 = hashlib.sha256()
        self.bytes_read = 0

    def readable(self):
        return True

    def read(self, size=-1):
        check_budget()
        if size < 0:
            raise RuntimeError("unbounded compressed-byte read was not permitted")
        data = self.file.read(size)
        self.sha256.update(data)
        self.bytes_read += len(data)
        return data


emit("scope", paths=PATHS, expected_compressed_sizes=EXPECTED_SIZES,
     selectors={"exact_provider_filename": TARGET_NAME,
                "module_family_name_contains": "PrimitiveShiu",
                "historical_directory_name_contains_casefold": "sol6",
                "uncompressed_sizes": sorted(TARGETS.values()),
                "maximum_selected_member_body_bytes": MAX_BODY},
     timeout_internal_seconds=160, scope=TASK_SCOPE,
     duplicate_archive_bytes="Not prehashed; complete compressed hashes reported only if naturally consumed during streaming.",
     nested_archives="Not recursively expanded.")

completed = []
partial = []
errors = []
matches = []
total_members = 0
total_candidates = 0
total_bodies = 0
budget_exhausted = False

for archive_index, path in enumerate(PATHS):
    if time.monotonic() >= DEADLINE:
        budget_exhausted = True
        break
    before = None
    after = None
    reader = None
    member_count = 0
    candidate_count = 0
    bodies_read = 0
    last_member = None
    archive_complete = False
    archive_error = None
    try:
        before = snapshot(path)
        emit("archive_start", path=path, before=before,
             expected_bytes=EXPECTED_SIZES[archive_index],
             recorded_size_matches=before["bytes"] == EXPECTED_SIZES[archive_index])
        with open(path, "rb") as file:
            reader = ObservedReader(file)
            with tarfile.open(fileobj=reader, mode="r|*") as archive:
                for member in archive:
                    check_budget()
                    member_count += 1
                    total_members += 1
                    last_member = member.name
                    selected = (member.name.rsplit("/", 1)[-1] == TARGET_NAME
                                or "PrimitiveShiu" in member.name
                                or "sol6" in member.name.casefold()
                                or member.size in TARGETS.values())
                    if selected:
                        candidate_count += 1
                        total_candidates += 1
                        record = {"archive": path, "member_index": member_count,
                                  "member": member.name, "bytes": member.size,
                                  "regular_file": member.isfile(),
                                  "linkname": member.linkname}
                        if member.isfile() and member.size <= MAX_BODY:
                            handle = archive.extractfile(member)
                            if handle is None:
                                raise RuntimeError("selected regular member has no readable body")
                            body = handle.read(member.size)
                            if len(body) != member.size:
                                raise RuntimeError("short selected-member body")
                            bodies_read += 1
                            total_bodies += 1
                            digest = hashlib.sha256(body).hexdigest()
                            record.update(sha256=digest, body_read=True,
                                          exact_known_sha256=digest in TARGETS)
                            if digest in TARGETS:
                                matches.append({"archive": path, "member": member.name,
                                                "bytes": len(body), "sha256": digest})
                            if digest in TARGETS or member.name.rsplit("/", 1)[-1] == TARGET_NAME:
                                if digest not in source_bodies_emitted:
                                    record["source_base64"] = base64.b64encode(body).decode("ascii")
                                    source_bodies_emitted.add(digest)
                                else:
                                    record["source_body_emitted_earlier_for_sha256"] = digest
                        else:
                            record.update(body_read=False,
                                          reason="not a regular file or over 65536 bytes")
                        emit("candidate", **record)
                    if member_count % 2000 == 0:
                        emit("archive_progress", path=path, member_count=member_count,
                             last_member=last_member, compressed_bytes_consumed=reader.bytes_read,
                             elapsed_seconds=time.monotonic()-START)
                    archive.members.clear()
                archive_complete = True
    except BudgetExpired as exc:
        budget_exhausted = True
        archive_error = str(exc)
    except Exception as exc:
        archive_error = type(exc).__name__ + ": " + str(exc)
        errors.append({"archive": path, "error": archive_error})
    finally:
        try:
            after = snapshot(path)
        except Exception as exc:
            errors.append({"archive": path, "after_stat_error": type(exc).__name__ + ": " + str(exc)})
        complete_hash = (reader is not None and before is not None
                         and reader.bytes_read == before["bytes"] and before == after)
        result = {"path": path, "complete_member_listing": archive_complete,
                  "members_inspected": member_count, "candidates": candidate_count,
                  "selected_bodies_read": bodies_read, "last_member": last_member,
                  "before": before, "after": after, "stat_stable": before == after,
                  "compressed_bytes_consumed": reader.bytes_read if reader else 0,
                  "compressed_sha256": reader.sha256.hexdigest() if reader else None,
                  "compressed_sha256_is_complete_archive": complete_hash,
                  "error": archive_error, "elapsed_seconds": time.monotonic()-START}
        emit("archive_result", **result)
        (completed if archive_complete else partial).append(result)
    if budget_exhausted:
        break

attempted_paths = {r["path"] for r in completed + partial}
emit("summary", scope=TASK_SCOPE, completed_archives=len(completed),
     complete_archive_paths=[r["path"] for r in completed],
     partial_archive_paths=[r["path"] for r in partial],
     unstarted_archive_paths=[p for p in PATHS if p not in attempted_paths],
     total_members_inspected=total_members, total_candidates=total_candidates,
     selected_bodies_read=total_bodies, matched_sources=matches,
     budget_exhausted=budget_exhausted, errors=errors,
     elapsed_seconds=time.monotonic()-START)
