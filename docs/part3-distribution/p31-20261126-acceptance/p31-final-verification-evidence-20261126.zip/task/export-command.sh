set -euo pipefail
python3 - <<'PY'
import base64, hashlib, io, json, pathlib, subprocess, zipfile
repo = pathlib.Path('/workspace/p31-poisson-lanes-20261126')
expected = 'd28d340b0240dc5cd8658893d07b61637ee94aa2'
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
if head != expected:
    raise SystemExit('Unexpected source HEAD: ' + head)
if subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=all'], cwd=repo, text=True).strip():
    raise SystemExit('Working tree is not clean')
selected = ['.lake/p31-poisson-lanes-final-verification', '.lake/p31-shiu-windows-verification']
manifest = {'source_commit': head, 'source_tree': subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=repo, text=True).strip(), 'verification_task_id': 'c8f3589c6e604553bb5075f6c358270d', 'scope': 'Only the two verification output directories; no compiled object binaries or unrelated jobs', 'files': [], 'reports': {}}
entries = []
for directory in selected:
    root = repo / directory
    report = json.loads((root / 'report.json').read_text())
    if report.get('status') != 'PASSED':
        raise SystemExit('Report is not PASSED: ' + directory)
    if report.get('head_commit') != expected:
        raise SystemExit('Report source HEAD mismatch: ' + directory)
    manifest['reports'][directory] = {'status': report['status'], 'group': report['group'], 'declaration_count': report['declaration_count'], 'modules': report['modules'], 'report_sha256': hashlib.sha256((root / 'report.json').read_bytes()).hexdigest()}
    for path in sorted(root.rglob('*')):
        if path.is_symlink():
            raise SystemExit('Refusing symlink: ' + str(path))
        if not path.is_file():
            continue
        if path.suffix not in {'.json', '.log', '.txt', '.lean'}:
            raise SystemExit('Unexpected artifact type: ' + str(path))
        relative = path.relative_to(repo).as_posix()
        data = path.read_bytes()
        if len(data) > 30000000:
            raise SystemExit('Unexpectedly large artifact: ' + relative)
        entries.append((relative, data))
        manifest['files'].append({'path': relative, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
blob = io.BytesIO()
with zipfile.ZipFile(blob, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for relative, data in entries:
        info = zipfile.ZipInfo(relative, date_time=(2026, 11, 26, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        archive.writestr(info, data)
    info = zipfile.ZipInfo('EXPORT_MANIFEST.json', date_time=(2026, 11, 26, 0, 0, 0))
    info.compress_type = zipfile.ZIP_DEFLATED
    info.external_attr = 0o100644 << 16
    archive.writestr(info, json.dumps(manifest, indent=2, ensure_ascii=False) + '\n')
data = blob.getvalue()
target = pathlib.Path('/tmp/p31-final-verification-evidence-20261126.zip')
target.write_bytes(data)
print('EXPORT_METADATA ' + json.dumps({'source_commit': head, 'zip_path': str(target), 'zip_bytes': len(data), 'zip_sha256': hashlib.sha256(data).hexdigest(), 'member_count': len(entries) + 1, 'reports': manifest['reports']}))
print('EXPORT_ZIP_BASE64_BEGIN')
print(base64.b64encode(data).decode())
print('EXPORT_ZIP_BASE64_END')
PY
