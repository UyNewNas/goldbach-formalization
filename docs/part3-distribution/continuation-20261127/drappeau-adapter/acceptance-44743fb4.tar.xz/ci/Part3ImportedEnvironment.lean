import ImbalancedChen.Part3ActualSpectralTestSeminorm
import ImbalancedChen.Part3RegularPositiveMeasureExhaustion
import Lean.Elab.Command
import Lean.Util.CollectAxioms
open Lean Elab Command in
run_cmd do
  let env ← getEnv
  for moduleName in env.header.moduleNames do
    let path ← Lean.findOLean moduleName
    IO.println ("P3IMPORT|" ++ (Lean.Json.mkObj [
      ("module", Lean.toJson moduleName.toString),
      ("olean", Lean.toJson path.toString)]).compress)
