# Nineteen-module existing-repair selection

Blue donor: `10b89181754c78c0e77616677295ee2105de0bb6`. Repair donor: `48db3d603d632bc60037e149a55717832e4c04be`.

Only three exact published proof-only postimages are staged. No canonical source was edited.

| Module | Decision | Selected/current SHA256 |
|---|---|---|
| ActualUpperCountingInputs | PRESERVE_CURRENT | `b89d2c71bc253103320fa5296e9583f77fca365f842dac1502116a98b62826e8` |
| ActualUpperDensityAssembly | PRESERVE_CURRENT | `659aa3d8cfa50345f912ba070e30cd57a6caa1738e4146d1c051a7506f944cec` |
| FiniteUpperCarrierCore | PRESERVE_CURRENT | `0aafba57cdda976aa7ae8ac1857022fa09553d17fba48b1c71d278cd406fcfa2` |
| P4BActualPairOuterRamp | PRESERVE_CURRENT | `285f573a10ec11e833b05c7c06401705bf29fdfd351168ca5914ad19232cb41b` |
| P4BLabelledLogGeometry | PRESERVE_CURRENT | `1690b85ce51996a4de8b1831e72c78c1bae07aea748cc11e5a25039bc4a7ccfb` |
| P4BLabelledOuterPushforward | PRESERVE_CURRENT | `184aafce262acd91a2f8ab561a53cc09522cb14d8afad729d31ccf77fcf7343e` |
| P4BLabelledPairDictionary | PRESERVE_CURRENT | `6bcfb21ce23f34cefcbfaa226622d903420ec07c9ac2d8054e6f5ce064654fd9` |
| P4BLogGateOuterRamp | PRESERVE_CURRENT | `5054300786f1a40d3c93c967aa3032904f6d6dcbc53dcd56f93fda9567fb38aa` |
| P4BOuterCoprimeElimination | PRESERVE_CURRENT | `ea6b54f4d44071d1476e4015f1e51c002e5be72f9631778b9ae541bb3f0f8f63` |
| P4BOuterRampBoundaryUnion | PRESERVE_CURRENT | `c0d48d9ec2b1b77bf66a597a54a8950e9566c7ad17858bd1b43315d12466f03a` |
| P4BOuterRampRoughness | REUSE_EXACT_EXISTING_PROOF_REPAIR | `efe47bb459ca3bb6c6cd0379d916211e4acfeb12a9557233594d726b0314a3b7` |
| P4BPhysicalProductOuterRamp | REUSE_EXACT_EXISTING_PROOF_REPAIR | `8e76d2aaaf403472adc34387a2dd8afafe2efd0d73667e225425f0207b8107c2` |
| P4BSmoothGateUpperStep | PRESERVE_CURRENT | `7f51e436ec635bf89fbcf69f02e8c35f8b1a46df1183322f04c61dc69ea43764` |
| P4BSmoothPhysicalPairOuterRamp | REUSE_EXACT_EXISTING_PROOF_REPAIR | `fb94a636be604b4db784398bd495462c2c456c50f626012f68a56a8b5eff101c` |
| P4BSmoothPrimeVariableProfile | PRESERVE_CURRENT | `ca93e79e4022b473e0b2ce90e766b14d84eec76e15ba4b2eb79d32c34d0deca5` |
| P4BSmoothProfileCommonCompactSupport | PRESERVE_CURRENT | `d1d15d5d1383acb938a330eff86c47497bedcc3535ee20e2c65c06db4cf5772e` |
| RealPhysicalUpperWeightBridge | PRESERVE_CURRENT | `d12f225b912eae31c725341abab2a97ea7cce7b87998c630472e99f7bf2c1561` |
| RealUpperCountingAssembly | PRESERVE_CURRENT | `56bab762d3f765f5080a441910a8696e297bcd72801e13f4338b0ed7142a9a96` |
| UpperCoefficientPerturbation | PRESERVE_CURRENT | `e4d1d84fa128f7f84fb4f7d4f0b03acf8401312de1ceaed045de3aaf3b5d6e86` |

## Evidence boundary

The original normal, axiom, and exact-kernel stages passed for the three selected source hashes. The historical independent reviews also passed. Normal/kernel text logs were retrieved and their SHA256 values were checked against receipts. The original compressed axiom logs were retrieved with the explicit base64 file interface, decompressed, and checked against receipt hashes. The three Audit.lean sources were checked against receipt audit-source hashes. Historical normal logs contain non-fatal warnings; no current strict zero-warning claim is made.

These are historical acceptance records, not current-context acceptance. The blue profile root receipt does not make every canonical imported source an accepted source. The modern successful-groups checkpoint identifies the repaired sources actually used in that environment.

The root task owns current-context compilation and audit.
