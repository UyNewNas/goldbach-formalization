from pathlib import Path
import base64
import hashlib
import io
import json
import os
import subprocess
import sys
import traceback
import zipfile

SOURCE = os.environ['P34_ACCEPT_SOURCE']
TREE = os.environ['P34_ACCEPT_TREE']
ANCHOR = Path('/workspace/p34-common-phase-20261126')
ROOT = Path('/workspace/p34-fricke-final-20261126')
RECEIPT = Path('/workspace/p34-fricke-cloud-20261126/attempt-03-final')
OUT = ROOT / '.lake/p34-fricke-phase-acceptance'
RECEIPT.mkdir(parents=True, exist_ok=False)
provenance = {'expected_source': SOURCE, 'expected_tree': TREE,
              'worktree': str(ROOT), 'status': 'STARTING'}
environment = dict(os.environ)
environment['PATH'] = '/toolchains/bin:' + environment.get('PATH', '')
environment['PYTHONDONTWRITEBYTECODE'] = '1'

def checked(argv, name, cwd=None, input_text=None):
    result = subprocess.run(argv, cwd=cwd, env=environment, capture_output=True, text=True, input=input_text)
    (RECEIPT / (name + '.log')).write_text(
        'command=' + json.dumps(argv) + '\n' + result.stdout + result.stderr)
    if result.returncode:
        raise RuntimeError(name + ' failed, exit ' + str(result.returncode))
    return result.stdout.strip()

exit_code = 1
try:
    if ROOT.exists():
        raise RuntimeError('Fresh owned worktree path already exists')
    checked(['git', 'fetch', '--no-tags', 'origin', SOURCE], 'fetch-source', ANCHOR)
    actual_tree = checked(['git', 'rev-parse', SOURCE + '^{tree}'], 'source-tree', ANCHOR)
    if actual_tree != TREE:
        raise RuntimeError('Published source tree mismatch')
    checked(['git', 'clone', '--shared', '--no-checkout', str(ANCHOR), str(ROOT)], 'create-shared-checkout')
    sparse_paths = ['ImbalancedChen/Part3CuspPhaseCore.lean', 'ImbalancedChen/Part3Gamma0ActualCusps.lean', 'ImbalancedChen/Part3CuspScalingMatrices.lean', 'ImbalancedChen/Part3ActualCuspWidthNormalization.lean', 'ImbalancedChen/Part3CuspTranslationFourierPhase.lean', 'ImbalancedChen/Part3ActualCuspFourierSection.lean', 'ImbalancedChen/Part3FrickeNormalizer.lean', 'ImbalancedChen/Part3Gamma0GeneralCuspWidth.lean', 'ImbalancedChen/Part3Gamma0GeneralCuspUnitPeriod.lean', 'ImbalancedChen/Part3ActualFrickeCuspPhase.lean', 'verification/P34FrickePhaseAudit.lean', 'verification/verify_p34_cusp_normalization.py', 'verification/verify_variable_envelope_boxes.py', 'verification/test_p34_import_scope.py', 'verification/verify_p34_fricke_phase.py', 'docs/part3-distribution/p34-fricke-phase-20261126/SOURCE_INTAKE.json', 'lean-toolchain', 'lake-manifest.json', 'lakefile.toml', '.gitignore']
    checked(['git', 'sparse-checkout', 'set', '--no-cone', '--stdin'], 'set-sparse-paths', ROOT,
            ''.join('/' + p + '\n' for p in sparse_paths))
    checked(['git', 'checkout', '--detach', SOURCE], 'checkout-source', ROOT)
    provenance['checkout_mode'] = 'isolated_shared_clone_with_exact_sparse_paths'
    provenance['sparse_paths'] = sparse_paths
    provenance['source_files_materialized'] = all((ROOT / p).is_file() for p in sparse_paths)
    if not provenance['source_files_materialized']:
        raise RuntimeError('A required verification source is absent from the sparse checkout')
    (ROOT / '.lake').mkdir(exist_ok=True)
    packages = (ANCHOR / '.lake/packages').resolve(strict=True)
    (ROOT / '.lake/packages').symlink_to(packages, target_is_directory=True)
    provenance['packages'] = str(packages)
    provenance['initial_head'] = checked(['git', 'rev-parse', 'HEAD'], 'initial-head', ROOT)
    provenance['initial_working_tree'] = checked(['git', 'status', '--porcelain', '--untracked-files=all'], 'initial-status', ROOT)
    objects = list((ROOT / '.lake/build/lib/lean').rglob('*.olean'))
    provenance['initial_project_objects'] = len(objects)
    if provenance['initial_head'] != SOURCE or provenance['initial_working_tree'] or objects:
        raise RuntimeError('Fresh source/object preflight failed')
    command = [sys.executable, '-B', 'verification/verify_p34_fricke_phase.py',
               '--expected-head', SOURCE, '--output-dir', str(OUT)]
    provenance['command'] = command
    print('P34_FRICKE_CLEAN_START ' + SOURCE, flush=True)
    with (RECEIPT / 'full-stdout.log').open('w') as handle:
        process = subprocess.Popen(command, cwd=ROOT, env=environment, stdout=subprocess.PIPE,
                                   stderr=subprocess.STDOUT, text=True)
        for line in process.stdout:
            handle.write(line)
            handle.flush()
            print(line, end='', flush=True)
        exit_code = process.wait()
    provenance['gate_exit_code'] = exit_code
    provenance['final_head'] = checked(['git', 'rev-parse', 'HEAD'], 'final-head', ROOT)
    provenance['final_tree'] = checked(['git', 'rev-parse', 'HEAD^{tree}'], 'final-tree', ROOT)
    provenance['final_working_tree'] = checked(['git', 'status', '--porcelain', '--untracked-files=all'], 'final-status', ROOT)
    provenance['final_project_objects'] = len(list((ROOT / '.lake/build/lib/lean').rglob('*.olean')))
    if exit_code == 0:
        if (provenance['final_head'] != SOURCE or provenance['final_tree'] != TREE
                or provenance['final_working_tree'] or provenance['final_project_objects'] != 10):
            raise RuntimeError('Final clean-worktree provenance failed')
        provenance['status'] = 'PASSED'
    else:
        provenance['status'] = 'GATE_FAILED'
except BaseException as error:
    provenance['status'] = 'FAILED'
    provenance['error'] = str(error)
    (RECEIPT / 'exception.log').write_text(traceback.format_exc())
    print('P34_FRICKE_ERROR ' + str(error), flush=True)
    exit_code = 1
finally:
    (RECEIPT / 'worktree-provenance.json').write_text(json.dumps(provenance, indent=2) + '\n')
    payload = io.BytesIO()
    with zipfile.ZipFile(payload, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        if OUT.exists():
            for path in sorted(OUT.rglob('*')):
                if path.is_file():
                    archive.write(path, 'verification/' + path.relative_to(OUT).as_posix())
        for path in sorted(RECEIPT.iterdir()):
            if path.is_file():
                archive.write(path, 'provenance/' + path.name)
    raw = payload.getvalue()
    print('P34_FRICKE_ARCHIVE ' + json.dumps({'bytes': len(raw),
          'sha256': hashlib.sha256(raw).hexdigest(),
          'base64': base64.b64encode(raw).decode()}), flush=True)
    print('P34_FRICKE_EXIT ' + str(exit_code), flush=True)
sys.exit(exit_code)
