"""Bounded diagnostic probe; the final clean gate is still required for acceptance."""
from pathlib import Path
import base64
import hashlib
import io
import json
import os
import subprocess
import sys
import time
import traceback
import zipfile

ROOT = Path('/workspace/p34-fricke-final-20261126')
PAYLOAD = json.loads(base64.b64decode(os.environ['P34_FOCUSED_PAYLOAD']))
OUT = Path('/workspace/p34-fricke-cloud-20261126') / PAYLOAD['probe']
OUT.mkdir(parents=True, exist_ok=False)
environment = dict(os.environ)
environment['PATH'] = '/toolchains/bin:' + environment.get('PATH', '')
environment['PYTHONDONTWRITEBYTECODE'] = '1'
os.environ.update(environment)
sys.dont_write_bytecode = True
report = {'status': 'STARTING', 'acceptance_claimed': False,
          'candidate': PAYLOAD['candidate'], 'tree': PAYLOAD['tree'],
          'probe': PAYLOAD['probe'], 'stages': [],
          'source_sha256': PAYLOAD['source_sha256'],
          'expected_reused_objects': PAYLOAD['reused_objects']}

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save():
    (OUT / 'report.json').write_text(json.dumps(report, indent=2) + '\n')

def run(command, name):
    print('START ' + name, flush=True)
    tick = time.monotonic()
    result = subprocess.run(command, cwd=ROOT, env=environment, capture_output=True, text=True)
    text = result.stdout + result.stderr
    (OUT / (name + '.log')).write_text('command=' + json.dumps(command) + '\n' + text)
    report['stages'].append({'name': name, 'command': command,
                             'elapsed_seconds': round(time.monotonic() - tick, 3),
                             'exit_code': result.returncode})
    save()
    if result.returncode:
        print(text, flush=True)
        raise RuntimeError(name + ': exit ' + str(result.returncode))
    print('PASS ' + name, flush=True)
    return text

exit_code = 1
try:
    head = run(['git', 'rev-parse', 'HEAD'], 'head').strip()
    if head != '9ab1aa96da0b6be512f3040110748a5afb69c4c2':
        raise RuntimeError('Owned diagnostic worktree HEAD changed')
    previous_report = ROOT / '.lake/p34-fricke-phase-acceptance/report.json'
    if digest(previous_report) != '8ccbd04fe6d4bbb0c2c33a26a9b5c4822c068675f8480739cf4e5834c4be22c9':
        raise RuntimeError('Original failed full-gate receipt changed')
    prior = json.loads(previous_report.read_text())
    stages = {s['name']: s['exit_code'] for s in prior['stages']}
    for module in PAYLOAD['modules'][:7]:
        relative = module.replace('.', '/') + '.lean'
        if prior['source_sha256'][relative] != PAYLOAD['source_sha256'][relative]:
            raise RuntimeError('Reused strict module source changed: ' + module)
        if stages.get(module.rsplit('.', 1)[1] + '-strict') != 0:
            raise RuntimeError('Missing prior strict compile of reused provider')
    focused_report = Path('/workspace/p34-fricke-cloud-20261126/focused-04/report.json')
    if digest(focused_report) != 'e18bd8bb41d905e1aff804241d182e677c52671a14ccda2e6a79556592602f46':
        raise RuntimeError('Passing Width strict diagnostic receipt changed')
    focused = json.loads(focused_report.read_text())
    width = PAYLOAD['modules'][7]
    width_source = width.replace('.', '/') + '.lean'
    width_stage = width.rsplit('.', 1)[1] + '-strict'
    if focused['source_sha256'][width_source] != PAYLOAD['source_sha256'][width_source]:
        raise RuntimeError('Reused Width source changed')
    if not any(s['name'] == width_stage and s['exit_code'] == 0 for s in focused['stages']):
        raise RuntimeError('Missing strict Width diagnostic success')
    width_object = '.lake/build/lib/lean/' + width.replace('.', '/') + '.olean'
    if focused['olean_sha256'][width_object] != PAYLOAD['reused_objects'][width_object]:
        raise RuntimeError('Reused Width object differs from strict diagnostic')
    for relative, expected in PAYLOAD['reused_objects'].items():
        if digest(ROOT / relative) != expected:
            raise RuntimeError('Reused provider object differs from accepted packet receipt: ' + relative)
        for suffix in ('.private', '.server'):
            if Path(str(ROOT / relative) + suffix).exists():
                raise RuntimeError('Unexpected private/server companion for reused provider')
    report['reused_provider_objects_verified'] = True
    allowed = {m.replace('.', '/') + '.lean' for m in PAYLOAD['modules'][8:]}
    allowed.add('docs/part3-distribution/p34-fricke-phase-20261126/SOURCE_INTAKE.json')
    for patch in PAYLOAD['patches']:
        relative = patch['path']
        if relative not in allowed or digest(ROOT / relative) != patch['old_sha256']:
            raise RuntimeError('Unexpected source patch target or preimage: ' + relative)
        raw = base64.b64decode(patch['base64'], validate=True)
        if hashlib.sha256(raw).hexdigest() != PAYLOAD['source_sha256'][relative]:
            raise RuntimeError('Candidate patch hash mismatch')
        (ROOT / relative).write_bytes(raw)
    for relative, expected in PAYLOAD['source_sha256'].items():
        if digest(ROOT / relative) != expected:
            raise RuntimeError('Candidate source binding mismatch: ' + relative)
    sys.path.insert(0, str(ROOT / 'verification'))
    from verify_p34_cusp_normalization import validate_import_paths, validate_inventory, FORBIDDEN, lean_code
    for module in PAYLOAD['modules']:
        source = ROOT / (module.replace('.', '/') + '.lean')
        if FORBIDDEN.search(lean_code(source.read_text())):
            raise RuntimeError('Forbidden proof escape: ' + module)
    report['lean_version'] = run(['lake', 'env', 'lean', '--version'], 'lean-version').strip()
    if '62eed1db4d67327ec8120be05f1a1b0847d74561' not in report['lean_version']:
        raise RuntimeError('Unexpected compiler')
    tools = prior['tool_paths']
    for name in ('lean', 'leanchecker'):
        if digest(Path(tools[name])) != prior['tool_sha256'][name]:
            raise RuntimeError('Tool executable changed')
    manifest = json.loads((ROOT / 'lake-manifest.json').read_text())
    external_roots = tuple(path.resolve() for path in (
        Path(tools['sysroot']) / 'lib/lean',
        *(ROOT / '.lake/packages' / p['name'] / '.lake/build/lib/lean' for p in manifest['packages'])))
    objects = {(ROOT / p).resolve() for p in PAYLOAD['reused_objects']}
    report['parsed_dependencies'] = {}
    required_project_dependencies = {
        PAYLOAD['modules'][6]: {PAYLOAD['modules'][1]},
        PAYLOAD['modules'][7]: {PAYLOAD['modules'][1]},
        PAYLOAD['modules'][8]: {PAYLOAD['modules'][7], PAYLOAD['modules'][5]},
        PAYLOAD['modules'][9]: {PAYLOAD['modules'][6], PAYLOAD['modules'][8]},
    }
    available_modules = set(PAYLOAD['modules'][:8])
    compile_failures = []
    report['blocked_modules'] = []
    for module in PAYLOAD['modules'][8:]:
        relative = module.replace('.', '/')
        name = module.rsplit('.', 1)[1]
        missing = required_project_dependencies[module] - available_modules
        if missing:
            report['blocked_modules'].append({'module': module, 'failed_dependencies': sorted(missing)})
            continue
        dependencies = run(['lake', 'env', 'lean', '--deps', relative + '.lean'], name + '-imports')
        report['parsed_dependencies'][module] = validate_import_paths(dependencies, objects, external_roots)
        olean = ROOT / '.lake/build/lib/lean' / (relative + '.olean')
        olean.parent.mkdir(parents=True, exist_ok=True)
        for suffix in ('', '.server', '.private'):
            Path(str(olean) + suffix).unlink(missing_ok=True)
        try:
            run(['lake', 'env', 'lean', '-t0', '-j1', '-M6000', '-DwarningAsError=true',
                 '-o', str(olean), relative + '.lean'], name + '-strict')
        except RuntimeError as error:
            compile_failures.append({'module': module, 'error': str(error)})
            continue
        if not olean.is_file():
            raise RuntimeError('Strict compile did not produce its object')
        objects.add(olean.resolve())
        available_modules.add(module)
    report['olean_sha256'] = {p.relative_to(ROOT).as_posix(): digest(p) for p in sorted(objects)}
    report['compile_failures'] = compile_failures
    if compile_failures or report['blocked_modules']:
        raise RuntimeError('Strict compilation failed for: ' + ', '.join(r['module'] for r in compile_failures))
    for module in PAYLOAD['modules'][8:]:
        log = run(['lake', 'env', tools['leanchecker'], '--verbose', module],
                  module.rsplit('.', 1)[1] + '-replay')
        if ('replaying ' + module) not in log.splitlines():
            raise RuntimeError('Missing kernel replay marker')
    audit = 'verification/P34FrickePhaseAudit.lean'
    dependencies = run(['lake', 'env', 'lean', '--deps', audit], 'audit-imports')
    report['parsed_dependencies'][audit] = validate_import_paths(dependencies, objects, external_roots)
    log = run(['lake', 'env', 'lean', '-t0', '-j1', '-M6000', '-DwarningAsError=true', audit], 'axioms')
    records, counts = validate_inventory(log, modules=tuple(PAYLOAD['modules']))
    (OUT / 'declarations.json').write_text(json.dumps(records, indent=2) + '\n')
    report['declaration_count'] = len(records)
    report['module_counts'] = counts
    for relative, expected in {**PAYLOAD['source_sha256'], **report['olean_sha256']}.items():
        if digest(ROOT / relative) != expected:
            raise RuntimeError('Bound source/object changed during probe')
    report['status'] = 'DIAGNOSTIC_PASSED_NOT_ACCEPTANCE'
    exit_code = 0
except BaseException as error:
    report['status'] = 'DIAGNOSTIC_FAILED'
    report['error'] = str(error)
    (OUT / 'exception.log').write_text(traceback.format_exc())
    print('P34_FOCUSED_ERROR ' + str(error), flush=True)
finally:
    save()
    archive_bytes = io.BytesIO()
    with zipfile.ZipFile(archive_bytes, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(OUT.iterdir()):
            if path.is_file():
                archive.write(path, path.name)
    raw = archive_bytes.getvalue()
    print('P34_FOCUSED_ARCHIVE ' + json.dumps({'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
                                             'base64': base64.b64encode(raw).decode()}), flush=True)
    print('P34_FOCUSED_EXIT ' + str(exit_code), flush=True)
sys.exit(exit_code)
