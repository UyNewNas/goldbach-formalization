#!/usr/bin/env python3
"""Read only exact original entries of eleven preidentified thin Git bundles.

Writes a fresh private Git store and receipts beneath this script's directory.
No network, checkout, branch update, donor import, all-object scan or deletion.
Recovered text is parsed as data and is never executed.
"""
import ast
import base64
import binascii
import bz2
from collections import Counter, defaultdict
import gzip
import hashlib
import io
import json
import lzma
import os
from pathlib import Path
import re
import resource
import struct
import subprocess
import tarfile
import time
import zipfile
import zlib

OUT = Path(__file__).resolve().parent
PLAN = OUT.parent / 'archive-delta-plan.json'
DONOR = Path('/workspace/library-files/p36-warm-payment-20261126')
DONOR_OBJECTS = DONOR / '.git/objects'
REPO = OUT / 'isolated.git'
BASE_RECEIPTS = Path('/workspace/library-files/p34-evidence-staging/recovered-fixedblock')
MIB = 1024 * 1024
CAPS = dict(payload_bytes=32*MIB, decoded_total_bytes=256*MIB,
            git_output_bytes=32*MIB, git_address_space=256*MIB,
            git_file_bytes=64*MIB, git_seconds=45, wall_seconds=600,
            members=50_000, depth=10, payload_count=20_000,
            json_nodes=500_000, json_nesting=128, pack_objects=20_000,
            nested_bundles=24, text_parse_bytes=2*MIB)
TARGETS = [
    dict(module='Part3OriginalMediumPhysicalE3Block', bytes=6566,
         sha256='1ed9fec9d526f866fff9a29f9d8d0fa96d63def2a8b1e4e7a42ad759a8989982'),
    dict(module='Part3OriginalMediumDoubleLambdaColorWindows', bytes=7882,
         sha256='e034925f0c0fe6b3fbc1e74966848dadd66591910e7a074403151dbbb3e66f7a'),
    dict(module='Part3ActualFrickeNonzeroFourier', bytes=8079,
         sha256='926ee1b5e78c1a714fcb91405b6c85cc0c8d09dd32ad61c9135c2f15359a27fc'),
]
TARGET_SIZES = {x['bytes'] for x in TARGETS}
TOKEN = re.compile(rb'[A-Za-z0-9+/_-]+={0,2}\Z')
HEX = re.compile(rb'[0-9A-Fa-f]+\Z')
ENCODED_KEY = re.compile(r'(^|[_-])(b64|base64|hex)([_-]|$)', re.I)
WRAPPER_SUFFIXES = ('.json', '.jsonl', '.ndjson', '.zip', '.tar', '.tgz',
                    '.gz', '.xz', '.bz2', '.tbz2', '.bundle', '.b64', '.base64', '.raw')
UNSUPPORTED = ('.7z', '.zst', '.zstd', '.rar', '.lz4', '.lzip')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def file_identity(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=sha(data))


def save_new(name, value):
    path = OUT / name
    with path.open('x') as f:
        json.dump(value, f, indent=2, ensure_ascii=False)
        f.write('\n')
    return path


def env_base(alternate=False):
    result = dict(PATH=os.environ.get('PATH', '/usr/bin:/bin'), LANG='C',
                  TMPDIR=str(OUT), GIT_CONFIG_GLOBAL='/dev/null',
                  GIT_CONFIG_NOSYSTEM='1', GIT_NO_LAZY_FETCH='1',
                  GIT_ALLOW_PROTOCOL='', GIT_TERMINAL_PROMPT='0',
                  GIT_OPTIONAL_LOCKS='0')
    if alternate:
        result['GIT_ALTERNATE_OBJECT_DIRECTORIES'] = str(DONOR_OBJECTS)
    return result


def child_limits():
    for key, value in [(resource.RLIMIT_AS, CAPS['git_address_space']),
                       (resource.RLIMIT_FSIZE, CAPS['git_file_bytes'])]:
        _, hard = resource.getrlimit(key)
        resource.setrlimit(key, (min(value, hard) if hard != resource.RLIM_INFINITY else value, hard))


def git(args, data=None, donor=False):
    command = (['git', '-C', str(DONOR)] if donor else
               ['git', '--git-dir='+str(REPO), '-c', 'pack.threads=1',
                '-c', 'core.deltaBaseCacheLimit=16m']) + args
    result = subprocess.run(command, input=data, capture_output=True,
                            env=env_base(not donor), cwd=OUT,
                            timeout=CAPS['git_seconds'], preexec_fn=child_limits)
    if len(result.stdout) > CAPS['git_output_bytes']:
        raise Limit('git_output_bytes', str(len(result.stdout)))
    if result.returncode:
        raise Limit('git_command', json.dumps(dict(command=command, exit_code=result.returncode,
                                                  stderr=result.stderr.decode(errors='replace')[:6000])))
    return result.stdout


def donor_state():
    state = dict(repo=str(DONOR), commands={})
    for key, args in [('head', ['rev-parse', 'HEAD']),
                      ('refs', ['for-each-ref', '--format=%(refname) %(objectname)']),
                      ('tracked_status', ['status', '--porcelain=v2', '--untracked-files=no',
                                          '--ignore-submodules=all'])]:
        data = git(args, donor=True)
        state['commands'][key] = dict(bytes=len(data), sha256=sha(data), text=data.decode())
    for name in ['HEAD', 'index', 'packed-refs']:
        p = DONOR / '.git' / name
        state[name] = file_identity(p) if p.is_file() else None
    state['pack_file_metadata'] = sorted(
        [dict(name=p.name, bytes=p.stat().st_size, mtime_ns=p.stat().st_mtime_ns)
         for p in (DONOR / '.git/objects/pack').iterdir() if p.is_file()], key=lambda x:x['name'])
    return state


class Limit(Exception):
    def __init__(self, kind, detail):
        self.kind, self.detail = kind, detail
        super().__init__(kind+': '+detail)


class Pairs(list):
    pass


def target_names(text):
    low = text.lower()
    return [t['module'] for t in TARGETS if t['module'].lower() in low]


def signature(data, names=()):
    low = [n.lower() for n in names]
    if data.startswith((b'# v2 git bundle', b'# v3 git bundle')):
        return 'bundle'
    if data.startswith((b'PK\x03\x04', b'PK\x05\x06', b'PK\x07\x08')) or any(n.endswith('.zip') for n in low):
        return 'zip'
    if data.startswith(b'\x1f\x8b'):
        return 'gzip'
    if data.startswith(b'\xfd7zXZ\x00'):
        return 'xz'
    if data.startswith(b'BZh'):
        return 'bzip2'
    if data[257:262] == b'ustar' or any(n.endswith('.tar') for n in low):
        return 'tar'
    if any(n.endswith(('.b64', '.base64')) for n in low):
        return 'base64'
    if any(n.endswith(('.jsonl', '.ndjson')) for n in low):
        return 'jsonl'
    if any(n.endswith('.json') for n in low) or data.lstrip().startswith((b'{', b'[')):
        return 'json'
    if any(n.endswith(UNSUPPORTED) for n in low) or data.startswith((b'7z\xbc\xaf\x27\x1c', b'\x28\xb5\x2f\xfd', b'Rar!')):
        return 'unsupported'
    if any(n.endswith(('.gz', '.xz', '.bz2', '.bundle', '.tgz', '.tbz2')) for n in low):
        return 'invalid_wrapper'
    return None


def read_bounded(stream, cap):
    data = bytearray()
    while True:
        chunk = stream.read(min(256*1024, cap+1-len(data)))
        if not chunk:
            return bytes(data)
        data.extend(chunk)
        if len(data) > cap:
            raise Limit('payload_bytes', f'decoded bytes exceed {cap}')


def parse_pack(raw):
    if len(raw) > CAPS['payload_bytes']:
        raise Limit('bundle_bytes', str(len(raw)))
    marker = raw.find(b'\n\n')
    if marker < 0 or marker > 65536:
        raise Limit('bundle_header', 'missing or oversized header')
    header = raw[:marker].decode('utf-8')
    if not header.startswith(('# v2 git bundle\n', '# v3 git bundle\n')):
        raise Limit('bundle_header', 'unsupported magic')
    if '@object-format=sha256' in header or '@filter=' in header:
        raise Limit('bundle_capability', 'filtered or sha256 bundle not supported in this bounded continuation')
    pack = raw[marker+2:]
    if pack[:4] != b'PACK' or len(pack) < 32 or hashlib.sha1(pack[:-20]).digest() != pack[-20:]:
        raise Limit('pack_checksum', 'raw pack checksum differs')
    version, count = struct.unpack('>II', pack[4:12])
    if version not in (2,3) or count > CAPS['pack_objects']:
        raise Limit('pack_header', f'version={version}; count={count}')
    pos = 12
    entries = []
    total = 0
    for _ in range(count):
        start = pos
        v = pack[pos]; pos += 1
        kind, size, shift = (v >> 4) & 7, v & 15, 4
        while v & 128:
            if shift > 60:
                raise Limit('pack_entry_size', 'invalid size varint')
            v = pack[pos]; pos += 1
            size |= (v & 127) << shift; shift += 7
        if kind not in (1,2,3,4,6,7) or size > CAPS['payload_bytes']:
            raise Limit('pack_entry', f'kind={kind}; size={size}')
        base_oid = None
        if kind == 6:
            v = pack[pos]; pos += 1
            while v & 128:
                v = pack[pos]; pos += 1
        elif kind == 7:
            base_oid = pack[pos:pos+20].hex(); pos += 20
        decoder = zlib.decompressobj()
        decoded = decoder.decompress(pack[pos:], size+1)
        if not decoder.eof or len(decoded) != size:
            raise Limit('pack_entry_decode', f'offset={start}')
        pos += len(pack[pos:]) - len(decoder.unused_data)
        result_size = size
        if kind in (6,7):
            q = 0
            for _ in range(2):
                value, shift = 0, 0
                while True:
                    if q >= len(decoded) or shift > 60:
                        raise Limit('pack_delta_header', f'offset={start}')
                    v = decoded[q]; q += 1
                    value |= (v & 127) << shift
                    if not v & 128:
                        break
                    shift += 7
            result_size = value
        if result_size > CAPS['payload_bytes']:
            raise Limit('resolved_object_bytes', str(result_size))
        total += result_size
        if total > CAPS['decoded_total_bytes']:
            raise Limit('pack_resolved_total', str(total))
        entries.append(dict(offset=start, kind=kind, bytes=result_size, base_oid=base_oid))
    if pos != len(pack)-20:
        raise Limit('pack_trailer_position', str(pos))
    return header, pack, entries


def index_bundle(raw, planned=None):
    header, pack, entries = parse_pack(raw)
    if planned:
        assert len(raw) == planned['bytes'] and sha(raw) == planned['sha256']
        assert header == planned['header'] and pack[-20:].hex() == planned['pack_sha1']
        assert [x['offset'] for x in entries] == planned['original_pack_entry_offsets']
        assert len(entries) == planned['pack_object_count']
    result = git(['index-pack', '--stdin', '--fix-thin', '--strict', '--threads=1'], pack)
    parts = result.decode().strip().split()
    fixed_id = parts[-1]
    if not re.fullmatch('[0-9a-f]{40}', fixed_id):
        raise Limit('index_pack_output', result.decode(errors='replace'))
    idx = REPO / 'objects/pack' / ('pack-'+fixed_id+'.idx')
    lines = git(['show-index'], idx.read_bytes()).decode().splitlines()
    offsets = {int(x.split()[0]):x.split()[1] for x in lines}
    original = {e['offset']:e for e in entries}
    if not set(original).issubset(offsets):
        raise Limit('original_offset_mapping', 'one or more original offsets absent from fixed index')
    selected = [dict(**e, oid=offsets[e['offset']]) for e in entries]
    return dict(header=header, input_pack_sha1=pack[-20:].hex(), fixed_pack_sha1=fixed_id,
                fixed_index=file_identity(idx), original_entries=selected,
                appended_base_object_count=len(offsets)-len(entries),
                appended_base_objects=[dict(offset=o,oid=v) for o,v in offsets.items() if o not in original])


def read_selected_objects(oids):
    oids = sorted(set(oids))
    info = git(['cat-file', '--batch-check=%(objectname) %(objecttype) %(objectsize)'],
               ('\n'.join(oids)+'\n').encode())
    rows = {}
    for line in info.decode().splitlines():
        fields = line.split()
        if len(fields) != 3 or fields[0] not in oids:
            raise Limit('selected_object_metadata', line)
        oid, kind, size = fields
        rows[oid] = dict(type=kind, bytes=int(size))
    if len(rows) != len(oids) or sum(x['bytes'] for x in rows.values()) > CAPS['git_output_bytes']//2:
        raise Limit('selected_object_total', str(len(rows)))
    raw = git(['cat-file', '--batch'], ('\n'.join(oids)+'\n').encode())
    stream = io.BytesIO(raw)
    for expected in oids:
        oid, kind, size = stream.readline().decode().strip().split()
        size = int(size)
        if oid != expected or dict(type=kind, bytes=size) != rows[oid]:
            raise Limit('selected_object_binding', oid)
        data = stream.read(size)
        if len(data) != size or stream.read(1) != b'\n':
            raise Limit('selected_object_transport', oid)
        if hashlib.sha1(f'{kind} {size}\0'.encode()+data).hexdigest() != oid:
            raise Limit('selected_object_git_hash', oid)
        rows[oid].update(data=data, sha256=sha(data))
    if stream.read():
        raise Limit('selected_object_transport', 'trailing bytes')
    return rows


def tree_entries(data):
    pos = 0
    while pos < len(data):
        sep = data.index(b' ', pos)
        end = data.index(b'\0', sep+1)
        if end+21 > len(data):
            raise Limit('git_tree_parse', 'short object id')
        yield data[pos:sep].decode(), data[sep+1:end].decode('utf-8','replace'), data[end+1:end+21].hex()
        pos = end+21


class Scanner:
    def __init__(self, known):
        self.start = time.monotonic()
        self.known = known
        self.counts = Counter()
        self.seen = {}
        self.regions = []
        self.members = []
        self.strings = []
        self.limits = []
        self.matches = []
        self.candidates = []
        self.mentions = []
        self.decoded = 0
        self.json_nodes = 0
        self.nested_bundle_receipts = []
        self.literal_seen = set()
        self.oid_seen = set()

    def tick(self):
        if time.monotonic()-self.start > CAPS['wall_seconds']:
            raise Limit('deadline', 'internal wall-clock deadline reached')

    def charge(self, size):
        self.tick()
        self.decoded += size
        if self.decoded > CAPS['decoded_total_bytes']:
            raise Limit('decoded_total_bytes', str(self.decoded))

    def limit(self, loc, kind, detail):
        self.limits.append(dict(location=loc, kind=kind, detail=str(detail)[:6000]))

    def check(self, data, loc, names=()):
        size = len(data)
        named = set(t for n in names for t in target_names(n))
        if size not in TARGET_SIZES and not named:
            return
        identity = sha(data)
        row = dict(location=loc, bytes=size, sha256=identity, named_targets=sorted(named),
                   size_targets=[t['module'] for t in TARGETS if t['bytes']==size])
        row['exact_targets'] = [t['module'] for t in TARGETS if t['bytes']==size and t['sha256']==identity]
        self.candidates.append(row)
        for target in row['exact_targets']:
            p = OUT / 'recovered' / (target+'.lean')
            p.parent.mkdir(exist_ok=True)
            if not p.exists():
                with p.open('xb') as f:
                    f.write(data)
            if p.read_bytes() != data:
                raise Limit('exact_source_recheck', target)
            self.matches.append(dict(**row, recovered_path=str(p)))

    def note_mentions(self, raw, loc):
        low = raw.lower()
        found = [t['module'] for t in TARGETS if t['module'].lower().encode() in low or t['sha256'].encode() in low]
        if found and len(self.mentions) < 1000:
            self.mentions.append(dict(location=loc, targets=found, bytes=len(raw), sha256=sha(raw),
                                      classification='name_or_digest_pointer_only'))

    def visit(self, data, loc, names=(), depth=0, expanded=False):
        self.tick()
        if len(data) > CAPS['payload_bytes']:
            self.limit(loc, 'payload_bytes', len(data)); return 'partial'
        if depth > CAPS['depth']:
            self.limit(loc, 'depth', depth); return 'partial'
        if expanded:
            self.charge(len(data))
        self.counts['payload_observations'] += 1
        if self.counts['payload_observations'] > CAPS['payload_count']:
            raise Limit('payload_count', str(self.counts['payload_observations']))
        digest = sha(data)
        self.check(data, loc, names)
        codec = signature(data, names)
        row = dict(location=loc, bytes=len(data), sha256=digest, codec=codec,
                   names=list(names), depth=depth)
        self.regions.append(row)
        if digest in self.known:
            row.update(status='prior_complete_content_excluded',
                       prior_coverage_targets=['Part3OriginalMediumPhysicalE3Block'],
                       new_target_scope_excluded=[t['module'] for t in TARGETS[1:]])
            self.counts['prior_complete_content_skips'] += 1
            return row['status']
        key = (digest, codec)
        if key in self.seen:
            prior = self.seen[key]
            row.update(status='same_run_duplicate', duplicate_of=prior['location'],
                       duplicate_status=prior.get('status','in_progress'))
            self.counts['same_run_content_skips'] += 1
            if prior.get('status') == 'partial':
                self.limit(loc, 'duplicate_of_partial', prior['location'])
                row['status'] = 'partial'
            return row['status']
        self.seen[key] = row
        before = len(self.limits)
        try:
            if codec in ('gzip','xz','bzip2'):
                factory = dict(gzip=gzip.GzipFile,xz=lzma.LZMAFile,bzip2=bz2.BZ2File)[codec]
                with factory(fileobj=io.BytesIO(data)) if codec=='gzip' else factory(io.BytesIO(data)) as f:
                    child = read_bounded(f, CAPS['payload_bytes'])
                self.counts[codec+'_decodes'] += 1
                n = next((n for n in names if n.endswith(('.gz','.xz','.bz2','.tgz','.tbz2'))), '')
                inner = n[:-4]+'.tar' if n.endswith('.tgz') else n[:-5]+'.tar' if n.endswith('.tbz2') else str(Path(n).with_suffix('')) if n else ''
                self.visit(child, loc+'!decoded-'+codec, (inner,) if inner else (), depth+1, True)
            elif codec == 'base64':
                compact = re.sub(rb'\s+', b'', data)
                child = base64.b64decode(compact+b'='*(-len(compact)%4),altchars=b'-_',validate=True)
                self.counts['base64_decodes'] += 1
                self.visit(child, loc+'!base64', (), depth+1, True)
            elif codec == 'zip':
                self.visit_zip(data, loc, depth)
            elif codec == 'tar':
                self.visit_tar(data, loc, depth)
            elif codec in ('json','jsonl'):
                self.visit_json(data, loc, depth, codec=='jsonl')
            elif codec == 'bundle':
                self.visit_nested_bundle(data, loc, depth)
            elif codec in ('unsupported','invalid_wrapper'):
                self.limit(loc, codec, ', '.join(names))
            else:
                self.text(data, loc, '', '', depth, names)
        except (Limit, ValueError, UnicodeError, OSError, EOFError, RuntimeError,
                tarfile.TarError, zipfile.BadZipFile, lzma.LZMAError, zlib.error,
                binascii.Error, RecursionError, subprocess.SubprocessError) as e:
            self.limit(loc, e.kind if isinstance(e,Limit) else 'decode_error', str(e))
        row['status'] = 'complete' if len(self.limits)==before else 'partial'
        return row['status']

    def visit_zip(self, data, loc, depth):
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            infos = z.infolist()
            if len(infos) > CAPS['members']:
                raise Limit('member_count', str(len(infos)))
            for ordinal, m in enumerate(infos):
                self.tick()
                if m.is_dir():
                    continue
                childloc = f'{loc}!zip[{ordinal}]/{m.filename}'
                self.members.append(dict(location=childloc,bytes=m.file_size,kind='zip'))
                with z.open(m) as f:
                    if m.file_size > CAPS['payload_bytes']:
                        self.limit(childloc,'member_bytes',m.file_size); continue
                    child = read_bounded(f,CAPS['payload_bytes'])
                self.visit(child,childloc,(m.filename,),depth+1,True)

    def visit_tar(self, data, loc, depth):
        with tarfile.open(fileobj=io.BytesIO(data),mode='r|') as tar:
            for ordinal,m in enumerate(tar):
                self.tick()
                if ordinal >= CAPS['members']:
                    raise Limit('member_count', str(ordinal+1))
                childloc = f'{loc}!tar[{ordinal}]/{m.name}'
                self.members.append(dict(location=childloc,bytes=m.size,kind='tar',
                                         member_type=m.type.decode(errors='replace')))
                if not m.isfile():
                    if m.issym() or m.islnk():
                        self.members[-1]['linkname']=m.linkname
                        if target_names(m.name):
                            self.limit(childloc,'target_named_link_not_followed',m.linkname)
                    continue
                if m.size > CAPS['payload_bytes']:
                    self.limit(childloc,'member_bytes',m.size); continue
                with tar.extractfile(m) as f:
                    child=read_bounded(f,CAPS['payload_bytes'])
                self.visit(child,childloc,(m.name,),depth+1,True)

    def visit_json(self,data,loc,depth,lines=False):
        self.counts['json_documents'] += 1
        if lines:
            chunks=[(i,line) for i,line in enumerate(data.splitlines(),1) if line.strip()]
        else:
            try:
                self.json_walk(json.loads(data,object_pairs_hook=Pairs),loc,depth)
                return
            except json.JSONDecodeError as e:
                if e.msg != 'Extra data':
                    raise
                chunks=[(i,line) for i,line in enumerate(data.splitlines(),1) if line.strip()]
                self.counts['jsonl_extra_data_fallbacks'] += 1
        for n,line in chunks:
            try:
                self.json_walk(json.loads(line,object_pairs_hook=Pairs),f'{loc}!line-{n}',depth)
                self.counts['jsonl_records'] += 1
            except (ValueError,UnicodeError) as e:
                self.limit(f'{loc}!line-{n}','jsonl_parse',str(e))

    def json_walk(self,value,loc,depth,nesting=0,key='',hint='',names=()):
        self.tick(); self.json_nodes += 1
        if self.json_nodes > CAPS['json_nodes'] or nesting > CAPS['json_nesting']:
            raise Limit('json_nodes_or_nesting',f'{self.json_nodes}/{nesting}')
        if isinstance(value,Pairs):
            encoding=next((v for k,v in value if k.lower()=='encoding' and isinstance(v,str)), '')
            labels=tuple(v for k,v in value if k.lower() in ('path','name','filename','module','origin','source_path') and isinstance(v,str))
            for k,v in value:
                self.note_mentions(k.encode('utf-8',errors='surrogatepass'),loc+'/<key>')
                content=k.lower() in ('content','payload','data','blob','bytes','source','body','value')
                self.json_walk(v,loc+'/'+k[:200],depth,nesting+1,k,encoding if content else '',labels if content else ())
        elif isinstance(value,list):
            for i,v in enumerate(value):
                self.json_walk(v,loc+'/'+str(i),depth,nesting+1,key,hint,names)
        elif isinstance(value,str):
            self.counts['json_strings'] += 1
            raw=value.encode('utf-8',errors='surrogatepass')
            self.text(raw,loc,key,hint,depth,names)

    def text(self,raw,loc,key,hint,depth,names=()):
        self.tick()
        self.note_mentions(raw,loc)
        self.check(raw,loc,names)
        if len(raw)>CAPS['payload_bytes']:
            raise Limit('text_bytes',str(len(raw)))
        hint=hint.lower()
        encoding=ENCODED_KEY.search(key)
        hint=hint or (encoding.group(2).lower() if encoding else '')
        if raw.startswith(b'data:') and b';base64,' in raw[:512]:
            raw=raw.split(b';base64,',1)[1]; hint='base64'
        if hint in ('utf-8','utf8','text','plain','ascii','none'):
            hint=''
        if 'base64' in hint and re.search(r'[,/+]\s*(gzip|xz|zip|tar)|^(gzip|xz|zip|tar)\s*[,/+]',hint):
            hint='base64'
        compact=None
        if not hint:
            if len(raw) in {2*s for s in TARGET_SIZES} and HEX.fullmatch(raw):
                hint='hex'
            elif len(raw)>=min(TARGET_SIZES)*4//3-2 or raw[:4] in (b'UEsD',b'H4sI',b'/Td6',b'Qlpo',b'IyB2'):
                probe=re.sub(rb'\s+',b'',raw[:64]);probe=probe[:len(probe)//4*4]
                try:
                    head=base64.b64decode(probe,altchars=b'-_',validate=True)
                except binascii.Error:
                    head=b''
                if head:
                    compact=re.sub(rb'\s+',b'',raw)
                    possible_size=any((s+2)//3*4-2 <= len(compact) <= (s+2)//3*4 for s in TARGET_SIZES)
                    if TOKEN.fullmatch(compact) and (possible_size or signature(head)):
                        hint='base64'
        if hint:
            if hint not in ('base64','b64','base64url','base64-url','hex','hexadecimal'):
                self.limit(loc,'json_payload_encoding',hint)
                return
            compact=compact if compact is not None else re.sub(rb'\s+',b'',raw)
            child=(binascii.unhexlify(compact) if hint in ('hex','hexadecimal') else
                   base64.b64decode(compact+b'='*(-len(compact)%4),altchars=b'-_',validate=True))
            self.counts['encoded_text_decodes'] += 1
            self.strings.append(dict(location=loc,encoding=hint,encoded_bytes=len(raw),
                                     decoded_bytes=len(child),decoded_sha256=sha(child)))
            self.visit(child,loc+'!decoded-text',(),depth+1,True)
        # A JSON string can itself be a JSON document or an ordinary source payload.
        if not hint and raw.lstrip().startswith((b'{',b'[')):
            self.visit(raw,loc+'!embedded-json',(),depth+1)
        # Inspect explicit Python encoding literals without executing recovered code.
        if (len(raw)<=CAPS['text_parse_bytes'] and
            (b'b64decode' in raw or b'fromhex' in raw or any(n.endswith('.py') for n in names))):
            digest=sha(raw)
            if digest not in self.literal_seen:
                self.literal_seen.add(digest)
                try:
                    tree=ast.parse(raw.decode('utf-8'))
                except (SyntaxError,UnicodeError,ValueError):
                    return
                self.counts['python_texts_parsed_not_executed'] += 1
                for node in ast.walk(tree):
                    if isinstance(node,ast.Constant) and isinstance(node.value,(str,bytes)):
                        data=node.value.encode('utf-8',errors='surrogatepass') if isinstance(node.value,str) else node.value
                        self.check(data,f'{loc}!literal-line-{getattr(node,"lineno",0)}')
                    if not isinstance(node,ast.Call) or not node.args:
                        continue
                    fun=node.func.attr if isinstance(node.func,ast.Attribute) else node.func.id if isinstance(node.func,ast.Name) else ''
                    if fun not in ('b64decode','urlsafe_b64decode','fromhex'):
                        continue
                    arg=node.args[0]
                    if not isinstance(arg,ast.Constant) or not isinstance(arg.value,(str,bytes)):
                        self.limit(loc,'nonliteral_encoded_call_not_evaluated',f'{fun} at line {getattr(node,"lineno",0)}')
                        continue
                    data=arg.value.encode() if isinstance(arg.value,str) else arg.value
                    self.text(data,f'{loc}!{fun}-line-{node.lineno}', 'base64' if 'b64' in fun else 'hex',
                              'base64' if 'b64' in fun else 'hex',depth+1)

    def visit_nested_bundle(self,data,loc,depth):
        if len(self.nested_bundle_receipts)>=CAPS['nested_bundles']:
            raise Limit('nested_bundle_count',str(len(self.nested_bundle_receipts)))
        rec=index_bundle(data)
        rec['location']=loc
        self.nested_bundle_receipts.append(rec)
        objects=read_selected_objects([e['oid'] for e in rec['original_entries']])
        self.scan_objects(objects,loc+'!nested-pack',depth+1)

    def scan_objects(self,objects,prefix,depth=0):
        names=defaultdict(set)
        for oid,row in objects.items():
            if row['type']=='tree':
                for mode,name,child in tree_entries(row['data']):
                    if mode in ('100644','100755'):
                        names[child].add(name)
                        if child not in objects and target_names(name):
                            self.limit(prefix+'!'+oid+'/'+name,'target_named_external_tree_blob_not_read',child)
        for oid,row in objects.items():
            self.tick()
            loc=prefix+'!'+oid
            if oid in self.oid_seen:
                self.counts['same_run_git_oid_skips'] += 1
                continue
            self.oid_seen.add(oid)
            self.counts['original_git_objects_read'] += 1
            self.counts['git_type_'+row['type']] += 1
            self.check(row['data'],loc,tuple(sorted(names[oid])))
            if row['type']=='blob':
                row['scan_status']=self.visit(row['data'],loc,tuple(sorted(names[oid])),depth)
            else:
                row['scan_status']='git_metadata_read_and_bound'
            row['names']=sorted(names[oid])


def main():
    if REPO.exists() or (OUT/'result.json').exists():
        raise SystemExit('Refusing to repeat an existing local delta run')
    plan=json.loads(PLAN.read_text())
    selected=[r for r in plan['bundle_resolution']['bundles'] if r.get('local_path')]
    assert len(selected)==11 and sum(r['pack_object_count'] for r in selected)==200
    known=set(json.loads((BASE_RECEIPTS/'p3-archive-dedup.json').read_text())['known_inspected_sha256'])
    known.update(r['sha256'] for r in plan['exclude_completed_117'])
    assert not known.intersection(r['sha256'] for r in selected)
    scanner=Scanner(known)
    result=dict(status='running',targets=TARGETS,caps=CAPS,plan=file_identity(PLAN),
                scanner=file_identity(Path(__file__)),scope='Only 200 original entries of eleven exact bundles and supported payloads nested in those entries; no donor corpus traversal.',
                existing_completed_fingerprint_exclusions=len(known),
                checkpoint_not_in_this_run=dict(bytes=90618,sha256='00e2c10b9c479d56156822a7cf25d9a3c9bb45af667da1b6d4fe764e36d77c07',
                    prerequisites=['ff84f0706527fff718e3be59c448a4cc592d44fc','102c46c652fd10138071582aab083d7e3c0140dd'],
                    advertised_tips=['3e7550c0b796956d5146d982492b649507c3ca9c','e0cf45ba533922d9c06db118d7c169e083e33c5a'],
                    header_source='Parent-reported exact cloud header task 6717f756; raw bundle not supplied to this run'),
                bundles=[],original_objects=[])
    before=donor_state()
    save_new('donor-before.json',before)
    fatal=None
    try:
        git(['init','--bare','--template=','--object-format=sha1'])
        expected_sizes={}
        memberships=defaultdict(list)
        for row in selected:
            path=Path(row['local_path'])
            raw=path.read_bytes()
            assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
            rec=dict(path=row['path'],local_path=str(path),bytes=len(raw),sha256=sha(raw),status='indexing')
            result['bundles'].append(rec)
            try:
                rec.update(index_bundle(raw,row))
                rec['status']='indexed'
                for e in rec['original_entries']:
                    if e['oid'] in expected_sizes:
                        assert expected_sizes[e['oid']]==e['bytes']
                    expected_sizes[e['oid']]=e['bytes']
                    memberships[e['oid']].append(row['path'])
            except Exception as e:
                rec['status']='partial'
                scanner.limit(row['path'],e.kind if isinstance(e,Limit) else 'bundle_index_exception',str(e))
        objects=read_selected_objects(expected_sizes)
        assert all(row['bytes']==expected_sizes[oid] for oid,row in objects.items())
        scanner.scan_objects(objects,'original-bundle-union')
        for oid,row in objects.items():
            result['original_objects'].append(dict(oid=oid,**{k:v for k,v in row.items() if k!='data'},bundles=memberships[oid]))
        for rec in result['bundles']:
            if rec['status']!='indexed':
                continue
            ids={e['oid'] for e in rec['original_entries']}
            rec['original_object_type_counts']=dict(Counter(objects[x]['type'] for x in ids))
            rec['original_object_count_after_within_bundle_oid_dedup']=len(ids)
            rec['original_object_scan_status_counts']=dict(Counter(objects[x].get('scan_status','missing') for x in ids))
            rec['status']='complete_original_payload' if all(objects[x].get('scan_status') not in ('partial',None) for x in ids) else 'partial'
    except Exception as e:
        fatal=dict(type=type(e).__name__,detail=str(e))
        scanner.limit('run',e.kind if isinstance(e,Limit) else 'fatal_exception',str(e))
    finally:
        after=donor_state()
        save_new('donor-after.json',after)
        same=before==after
        result.update(donor_before=file_identity(OUT/'donor-before.json'),donor_after=file_identity(OUT/'donor-after.json'),
                      donor_state_unchanged=same,donor_refs_unchanged=before['commands']['refs']==after['commands']['refs'],
                      donor_tracked_status_unchanged=before['commands']['tracked_status']==after['commands']['tracked_status'],
                      fatal=fatal,counts=dict(scanner.counts),decoded_bytes=scanner.decoded,json_nodes=scanner.json_nodes,
                      payload_regions=scanner.regions,archive_member_inventory=scanner.members,
                      decoded_text_fields=scanner.strings,nested_bundles=scanner.nested_bundle_receipts,
                      exact_matches=scanner.matches,candidates=scanner.candidates,metadata_mentions=scanner.mentions,
                      coverage_limits=scanner.limits,elapsed_seconds=round(time.monotonic()-scanner.start,3))
        result['status']='exact_source_recovered' if scanner.matches else 'partial_negative' if fatal or scanner.limits or not same else 'bounded_negative'
        result['limitations']=['No coverage claim for unrelated objects referenced by original Git trees.',
                               'No second/third-target claim is inherited from prior complete fingerprints.',
                               'No Lean compilation or proof acceptance is claimed.']
        path=save_new('result.json',result)
        print(json.dumps(dict(status=result['status'],result=file_identity(path),counts=result['counts'],
                              original_objects=len(result['original_objects']),bundles=len(result['bundles']),
                              bundle_status_counts=dict(Counter(r['status'] for r in result['bundles'])),
                              limits=len(scanner.limits),matches=len(scanner.matches),donor_state_unchanged=same,
                              elapsed_seconds=result['elapsed_seconds'])),flush=True)
    return 1 if fatal or not result['donor_state_unchanged'] else 0


if __name__=='__main__':
    raise SystemExit(main())
