#!/usr/bin/env python3
"""Inspect two newly exported contents; never pass unverified PACK bytes to Git."""
from collections import Counter
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import resource
import struct
import sys

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
HELPER = ROOT / 'local-bundle-delta/scan_bundle_delta.py'
HELPER_SHA = '3e1cbe85fbe3f56c769f5ab5058cbd897d2db2801e0349f7ceae639171d80706'
INPUTS = [
    {'path': ROOT / 'fields-receipts/7161-b4ad558ae94a43e8e0f64ffdd0550a77dd86632b5fbedd80f21fcd7dab0d963f.git-payload',
     'bytes': 17237, 'sha256': 'b4ad558ae94a43e8e0f64ffdd0550a77dd86632b5fbedd80f21fcd7dab0d963f',
     'tar_ordinal': 7161, 'tar_data_offset': 1238461952},
    {'path': ROOT / 'fields-receipts/8417-a875a48de2881e09d1bde698c004a1bd8fb02630e50122e37ff36b1d4edeac3e.git-payload',
     'bytes': 60000, 'sha256': 'a875a48de2881e09d1bde698c004a1bd8fb02630e50122e37ff36b1d4edeac3e',
     'tar_ordinal': 8417, 'tar_data_offset': 2300680192},
]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def identity(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': sha(raw)}


def stamp(path):
    row = path.stat()
    return [row.st_dev, row.st_ino, row.st_size, row.st_mtime_ns, row.st_ctime_ns]


def main():
    result_path = OUT / 'result.json'
    if result_path.exists():
        raise SystemExit('An exact two-input receipt already exists; refusing to repeat the scan.')
    soft, hard = resource.getrlimit(resource.RLIMIT_AS)
    cap = min(value for value in (256 << 20, soft, hard) if value != resource.RLIM_INFINITY)
    resource.setrlimit(resource.RLIMIT_AS, (cap, hard))
    helper_identity = identity(HELPER)
    assert helper_identity['sha256'] == HELPER_SHA
    frozen_paths = [HELPER, ROOT / 'local-bundle-delta/result.json',
                    ROOT / 'checkpoint-bundle-delta/final-result.json']
    frozen_before = [identity(path) for path in frozen_paths]
    spec = importlib.util.spec_from_file_location('p34_pinned_bounded_parser', HELPER)
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    helper.OUT = OUT
    helper.REPO = OUT / 'not-created.git'
    helper.CAPS = {**helper.CAPS, 'payload_bytes': 1 << 20, 'decoded_total_bytes': 2 << 20,
                   'json_nodes': 5000, 'payload_count': 500, 'wall_seconds': 60}
    git_attempts = []

    def no_git(*args, **kwargs):
        git_attempts.append(repr(args))
        raise RuntimeError('No Git command is authorized before successful bundle integrity authentication.')

    helper.git = no_git
    manifest_path = ROOT / 'large-bootstrap-delta-plan/bootstrap-manifest.json'
    manifest_raw = manifest_path.read_bytes()
    assert sha(manifest_raw) == 'bb38a378d1d46334fb15a3151dba1d8df80129f5ee3462025a644ff18145f67b'
    manifest = json.loads(manifest_raw)
    known = {row[0] for row in manifest['completed']}
    scanner = helper.Scanner(known)
    raw_inputs = []
    input_before = []
    for item in INPUTS:
        input_before.append(stamp(item['path']))
        raw = item['path'].read_bytes()
        assert len(raw) == item['bytes'] and sha(raw) == item['sha256']
        raw_inputs.append(raw)

    raw = raw_inputs[0]
    prefix = b'PACKEDCHARS_FLAG '
    assert raw.startswith(prefix) and raw.isascii() and raw.endswith(b'\n')
    lines = raw.splitlines(keepends=True)
    assert len(lines) == 121 and lines[-1] == b'PACKEDCHARS_COMPLETE_OWNED_COUNT 120\n'
    records = []
    names = []
    flags = {name: Counter() for name in ('axiom', 'partial', 'unsafe')}
    offset = 0
    scanner.check(raw, str(INPUTS[0]['path']))
    scanner.note_mentions(raw, str(INPUTS[0]['path']))
    for ordinal, line in enumerate(lines[:-1], 1):
        assert line.startswith(prefix) and line.endswith(b'\n') and b'\r' not in line
        encoded = line[len(prefix):-1]
        pairs = json.loads(encoded, object_pairs_hook=helper.Pairs)
        assert isinstance(pairs, helper.Pairs) and len(pairs) == 4
        labels = [key for key, _ in pairs]
        assert len(set(labels)) == 4 and set(labels) == {'axiom', 'name', 'partial', 'unsafe'}
        fields = dict(pairs)
        assert isinstance(fields['name'], str) and re.fullmatch(r"[A-Za-z0-9_'.]+", fields['name'])
        assert 'ImbalancedChen.P2OriginalSaving19PackedChars.' in fields['name']
        for flag in flags:
            assert type(fields[flag]) is bool
            flags[flag][str(fields[flag]).lower()] += 1
        location = str(INPUTS[0]['path']) + '!line-' + str(ordinal) + '!PACKEDCHARS_FLAG'
        status = scanner.visit(encoded, location, ('PACKEDCHARS_FLAG.json',), depth=0)
        records.append({'line': ordinal, 'line_offset': offset, 'json_offset': offset + len(prefix),
                        'json_bytes': len(encoded), 'json_sha256': sha(encoded), 'scan_status': status})
        names.append(fields['name'])
        offset += len(line)
    assert len(records) == 120 and offset + len(lines[-1]) == len(raw)
    assert len(set(names)) == 120
    assert not scanner.limits and not scanner.matches and not scanner.mentions
    log_receipt = {
        'status': 'closed_exact_prefixed_json_audit_log', 'input': {**INPUTS[0], 'path': str(INPUTS[0]['path'])},
        'actual_prefix': prefix.decode(), 'classification': 'ASCII declaration audit records; not Git or a byte transport',
        'git_magic_accepted': False, 'records': records,
        'terminal_count_label': 'PACKEDCHARS_COMPLETE_OWNED_COUNT', 'terminal_count': 120,
        'actual_record_count': 120, 'unique_declaration_names': len(set(names)),
        'json_schema': {'axiom': 'boolean', 'name': 'ASCII declaration identifier',
                        'partial': 'boolean', 'unsafe': 'boolean'},
        'flag_counts': {key: dict(counts) for key, counts in flags.items()},
        'name_byte_lengths': {'minimum': min(len(name) for name in names), 'maximum': max(len(name) for name in names)},
        'whole_member_and_json_values_checked_for_targets': [target['module'] for target in helper.TARGETS],
        'new_source_matches': [], 'encoding_payload_fields': [], 'unparsed_tail_bytes': 0,
        'scope_limit': 'This exact member and its 120 exact JSON records only. No Lean acceptance or broader source absence inferred.',
    }

    raw = raw_inputs[1]
    assert raw.startswith(b'# v2 git bundle\n')
    split = raw.index(b'\n\n') + 2
    header = raw[:split].decode('ascii')
    assert split == 265
    pack = raw[split:]
    assert pack[:4] == b'PACK'
    version, claimed_count = struct.unpack('>II', pack[4:12])
    rejection = None
    try:
        helper.parse_pack(raw)
    except helper.Limit as exc:
        rejection = {'kind': exc.kind, 'detail': exc.detail}
    assert rejection and rejection['kind'] == 'pack_checksum'
    claimed = pack[-20:].hex()
    computed = hashlib.sha1(pack[:-20]).hexdigest()
    assert claimed != computed and version == 2 and claimed_count == 142
    bundle_receipt = {
        'status': 'partial_invalid_pack_integrity', 'input': {**INPUTS[1], 'path': str(INPUTS[1]['path'])},
        'bundle_header': header, 'header_bytes': split, 'pack_bytes': len(pack),
        'pack_version': version, 'declared_original_object_count': claimed_count,
        'prerequisites_from_header': [line[1:41] for line in header.splitlines() if line.startswith('-')],
        'last_twenty_bytes_hex': claimed, 'sha1_of_preceding_pack_bytes': computed,
        'pack_trailer_valid': False, 'existing_resolver_rejection': rejection,
        'verified_original_entries': 0, 'original_objects_decoded_or_read': 0,
        'git_index_pack_invoked': False, 'donor_objects_read': 0,
        'remaining_boundary': 'The supplied 60000-byte content is not an authenticated complete Git pack. An incomplete capture or corruption cannot be distinguished from checksum failure alone. No missing-tail byte count is inferred.',
        'future_selector': {'member_sha256': INPUTS[1]['sha256'], 'member_bytes': INPUTS[1]['bytes'],
                            'header_tip': '8c745b0ae79dfc56415da20b2bfd6b8925270442',
                            'header_prerequisite': '9b16c5f0580a60a574e2611fb4b81778dd407244'},
    }
    input_after = [stamp(item['path']) for item in INPUTS]
    assert input_before == input_after and not git_attempts
    frozen_after = [identity(path) for path in frozen_paths]
    assert frozen_before == frozen_after
    report = {
        'status': 'audit_log_closed_one_pack_integrity_boundary', 'targets': helper.TARGETS,
        'script': identity(Path(__file__)), 'helper': helper_identity,
        'exclusion_manifest': {'path': str(manifest_path), 'bytes': len(manifest_raw), 'sha256': sha(manifest_raw)},
        'scope': 'Only two new exact exported contents. Old twelve bundle payloads were not reopened.',
        'audit_log': log_receipt, 'bundle': bundle_receipt,
        'counts': dict(scanner.counts), 'json_nodes': scanner.json_nodes,
        'payload_regions': scanner.regions, 'coverage_limits_in_audit_log': scanner.limits,
        'exact_matches': scanner.matches, 'candidates': scanner.candidates, 'metadata_mentions': scanner.mentions,
        'remaining_boundaries': [bundle_receipt['remaining_boundary']],
        'input_stat_stamps_before': input_before, 'input_stat_stamps_after': input_after,
        'inputs_unchanged': True, 'frozen_previous_receipts_before': frozen_before,
        'frozen_previous_receipts_after': frozen_after, 'frozen_previous_receipts_unchanged': True,
        'git_commands': git_attempts, 'isolated_git_store_created': False,
        'donor_stores_accessed': False, 'cloud_or_network_operations': 0,
        'recovered_code_executed': False, 'proof_files_modified': False,
        'resource_caps': {'address_space_bytes': cap, 'source_payload_bytes': 77237,
                          'scanner': helper.CAPS},
    }
    with result_path.open('x') as destination:
        json.dump(report, destination, indent=2, ensure_ascii=True)
        destination.write('\n')
    closure = {'status': 'closed_exact_audit_log_only', 'bytes': INPUTS[0]['bytes'], 'sha256': INPUTS[0]['sha256'],
               'targets': helper.TARGETS, 'receipt': identity(result_path),
               'scope': 'Whole ASCII member, exact 120 prefixed JSON records and terminal count; no source matches.',
               'unresolved_pack_is_not_closed': INPUTS[1]['sha256']}
    with (OUT / 'closed-audit-log-identity.json').open('x') as destination:
        json.dump(closure, destination, indent=2)
        destination.write('\n')
    print(json.dumps({'status': report['status'], 'receipt': identity(result_path),
                      'audit_records': len(records), 'json_nodes': scanner.json_nodes,
                      'exact_matches': len(scanner.matches), 'pack_integrity_guard': rejection,
                      'git_commands': len(git_attempts), 'donors_accessed': False}))


if __name__ == '__main__':
    main()
