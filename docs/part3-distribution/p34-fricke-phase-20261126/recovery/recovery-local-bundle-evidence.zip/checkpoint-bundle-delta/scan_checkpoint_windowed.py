#!/usr/bin/env python3
"""Exact checkpoint-only recovery with two read-only donor object stores."""
from pathlib import Path
import collections
import hashlib
import importlib.util
import json
import os
import subprocess
import sys
import time

sys.dont_write_bytecode = True
TASK_ROOT = Path(__file__).resolve().parent
OUT = TASK_ROOT / 'windowed-v2'
PREVIOUS = TASK_ROOT.parent / 'local-bundle-delta'
SOURCE = TASK_ROOT.parent / 'cloud-recovery-first/checkpoint.bundle'
HELPER = PREVIOUS / 'scan_bundle_delta.py'
EXPECTED_HELPER = '3e1cbe85fbe3f56c769f5ab5058cbd897d2db2801e0349f7ceae639171d80706'
EXPECTED_SOURCE = '00e2c10b9c479d56156822a7cf25d9a3c9bb45af667da1b6d4fe764e36d77c07'
EXPECTED_PREVIOUS = '961156d1c99108c0a4723da37583ffdf9fa23b9c99ba16964b357e9b63c2c9cb'
DONORS = [Path('/workspace/library-files/p36-warm-payment-20261126/.git'),
          Path('/workspace/library-files/p34-proof-work/.git')]


def identity(path):
    data=path.read_bytes()
    return dict(path=str(path),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())


def save(name, value):
    path=OUT/name
    with path.open('x') as f:
        json.dump(value,f,indent=2,ensure_ascii=False)
        f.write('\n')
    return identity(path)


def env_base(alternate=False):
    env=dict(PATH=os.environ.get('PATH','/usr/bin:/bin'),LANG='C',TMPDIR=str(OUT),
             GIT_CONFIG_GLOBAL='/dev/null',GIT_CONFIG_NOSYSTEM='1',
             GIT_NO_LAZY_FETCH='1',GIT_ALLOW_PROTOCOL='',
             GIT_OPTIONAL_LOCKS='0',GIT_TERMINAL_PROMPT='0',
             GIT_CONFIG_COUNT='2',GIT_CONFIG_KEY_0='core.packedGitWindowSize',
             GIT_CONFIG_VALUE_0='16m',GIT_CONFIG_KEY_1='core.packedGitLimit',GIT_CONFIG_VALUE_1='64m')
    if alternate:
        env['GIT_ALTERNATE_OBJECT_DIRECTORIES']=os.pathsep.join(str(p/'objects') for p in DONORS)
    return env


def donor_command(store,args,data=None):
    # Every command sent to an existing repository is explicitly read-only.
    assert args[0] in ('cat-file','for-each-ref','rev-parse')
    q=subprocess.run(['git','--git-dir='+str(store),*args],input=data,
                     env=env_base(),capture_output=True,check=True,timeout=45)
    return q.stdout


def donor_snapshot():
    rows=[]
    for store in DONORS:
        refs=donor_command(store,['for-each-ref','--format=%(refname) %(objectname)'])
        head=donor_command(store,['rev-parse','HEAD'])
        packs=sorted([dict(name=p.name,bytes=p.stat().st_size,mtime_ns=p.stat().st_mtime_ns)
                      for p in (store/'objects/pack').iterdir() if p.is_file()],key=lambda x:x['name'])
        rows.append(dict(store=str(store),refs=refs.decode(),refs_sha256=hashlib.sha256(refs).hexdigest(),
                         head=head.decode().strip(),pack_file_metadata=packs))
    return dict(scope='Only donor Git refs, resolved HEAD and object pack-file metadata. No index, tracked status or active worktree files read.',
                stores=rows)


def movement(before,after):
    rows=[]
    for old,new in zip(before['stores'],after['stores']):
        assert old['store']==new['store']
        oldrefs={x.split()[0]:x.split()[1] for x in old['refs'].splitlines()}
        newrefs={x.split()[0]:x.split()[1] for x in new['refs'].splitlines()}
        rows.append(dict(store=old['store'],head_before=old['head'],head_after=new['head'],
                         refs_changed=[dict(ref=k,before=oldrefs.get(k),after=newrefs.get(k))
                                       for k in sorted(set(oldrefs)|set(newrefs)) if oldrefs.get(k)!=newrefs.get(k)],
                         pack_file_metadata_unchanged=old['pack_file_metadata']==new['pack_file_metadata']))
    return rows


def main():
    OUT.mkdir(exist_ok=False)
    if (OUT/'result.json').exists() or (OUT/'isolated.git').exists():
        raise SystemExit('Refusing to repeat an existing checkpoint run')
    previous_identity=identity(PREVIOUS/'result.json')
    assert previous_identity['sha256']==EXPECTED_PREVIOUS
    assert identity(HELPER)['sha256']==EXPECTED_HELPER
    previous=json.loads((PREVIOUS/'result.json').read_text())
    assert previous['status']=='bounded_negative' and not previous['coverage_limits']
    original_plan=json.loads((TASK_ROOT.parent/'archive-delta-plan.json').read_text())
    raw=SOURCE.read_bytes()
    assert len(raw)==90618 and hashlib.sha256(raw).hexdigest()==EXPECTED_SOURCE
    spec=importlib.util.spec_from_file_location('verified_local_delta_scanner',HELPER)
    m=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    m.OUT=OUT
    m.REPO=OUT/'isolated.git'
    m.env_base=env_base
    header,pack,entries=m.parse_pack(raw)
    assert len(entries)==39
    planned=dict(bytes=90618,sha256=EXPECTED_SOURCE,header=header,pack_sha1=pack[-20:].hex(),
                 original_pack_entry_offsets=[e['offset'] for e in entries],pack_object_count=len(entries))
    prerequisites=[line[1:41] for line in header.splitlines() if line.startswith('-')]
    assert prerequisites==['ff84f0706527fff718e3be59c448a4cc592d44fc','102c46c652fd10138071582aab083d7e3c0140dd']
    bases=sorted({e['base_oid'] for e in entries if e['base_oid']})
    assert len(bases)==15
    planned.update(path=str(SOURCE),original_entries_before_index=entries,ref_delta_base_oids=bases,
                   prerequisites=prerequisites,transport_task='31c27778abee4da0a61019e332dcf930')
    input_plan_identity=save('input-plan.json',planned)
    old_known=set(json.loads((m.BASE_RECEIPTS/'p3-archive-dedup.json').read_text())['known_inspected_sha256'])
    old_known.update(x['sha256'] for x in original_plan['exclude_completed_117'])
    all_three_known={x['sha256'] for x in previous['payload_regions'] if x['status']=='complete'}
    all_three_known.update(x['sha256'] for x in previous['bundles'] if x['status']=='complete_original_payload')
    known=old_known|all_three_known

    class CheckpointScanner(m.Scanner):
        def visit(self,data,loc,names=(),depth=0,expanded=False):
            start=len(self.regions)
            value=super().visit(data,loc,names,depth,expanded)
            if len(self.regions)>start:
                row=self.regions[start]
                if row['status']=='prior_complete_content_excluded' and row['sha256'] in all_three_known:
                    row['prior_coverage_targets']=[x['module'] for x in m.TARGETS]
                    row['new_target_scope_excluded']=[]
                    row['prior_receipt_sha256']=EXPECTED_PREVIOUS
            return value

    scanner=CheckpointScanner(known)
    previous_objects={x['oid']:x for x in previous['original_objects']}
    scanner.oid_seen.update(previous_objects)
    result=dict(status='running',targets=m.TARGETS,source=identity(SOURCE),
                input_plan=input_plan_identity,scanner=identity(Path(__file__)),helper=identity(HELPER),
                previous_eleven_bundle_receipt=previous_identity,
                prior_attempt_before_any_source_scan=identity(TASK_ROOT/'result.json'),
                mapping_limit_diagnostic=identity(TASK_ROOT/'mapping-limit-diagnostic.json'),
                retry_bootstrap_failure=identity(TASK_ROOT/'retry-bootstrap-failure.json'),
                effective_git_pack_mapping=dict(window_bytes=16*1024*1024,mapped_pack_cache_bytes=64*1024*1024,address_space_cap_unchanged=True),
                scope='Only the 39 original checkpoint pack entries and supported structured payloads contained in them. Donor base bytes authenticated solely for resolving this exact pack.',
                transport_task='31c27778abee4da0a61019e332dcf930',caps=m.CAPS,
                readonly_alternates=[str(p/'objects') for p in DONORS],
                excluded_prior_content_fingerprints=len(known),
                no_donor_mutating_command=True,original_objects=[])
    before=donor_snapshot()
    save('donors-before.json',before)
    fatal=None
    try:
        m.git(['init','--bare','--template=','--object-format=sha1'])
        provider_metadata=[]
        for store in DONORS:
            meta=donor_command(store,['cat-file','--batch-check=%(objectname) %(objecttype) %(objectsize)'],
                               ('\n'.join(sorted(set(bases)|set(prerequisites)))+'\n').encode())
            provider_metadata.append(dict(store=str(store),records=meta.decode().splitlines()))
        result['base_and_prerequisite_provider_metadata']=provider_metadata
        # Authenticate only the listed prerequisite/base bytes; do not scan them for source.
        authenticated=m.read_selected_objects(set(bases)|set(prerequisites))
        result['authenticated_prerequisite_and_base_objects']=[dict(oid=oid,**{k:v for k,v in row.items() if k!='data'})
                                                               for oid,row in authenticated.items()]
        result['ref_delta_base_byte_count']=sum(authenticated[oid]['bytes'] for oid in bases)
        del authenticated
        receipt=m.index_bundle(raw,planned)
        receipt['path']='/workspace/p36-private-delivery-20261126/checkpoint.bundle'
        receipt['source_sha256']=EXPECTED_SOURCE
        result['bundle']=receipt
        selected={e['oid']:e['bytes'] for e in receipt['original_entries']}
        assert len(selected)==len(receipt['original_entries'])==39
        new_ids=set(selected)-set(previous_objects)
        reused_ids=set(selected)&set(previous_objects)
        for oid in reused_ids:
            assert selected[oid]==previous_objects[oid]['bytes']
        objects=m.read_selected_objects(new_ids) if new_ids else {}
        assert all(row['bytes']==selected[oid] for oid,row in objects.items())
        scanner.scan_objects(objects,'checkpoint-original-pack')
        for oid,row in objects.items():
            result['original_objects'].append(dict(oid=oid,**{k:v for k,v in row.items() if k!='data'}))
        result['prior_original_object_ids_reused']=sorted(reused_ids)
        result['reused_original_object_metadata']=[dict(**{k:v for k,v in previous_objects[oid].items() if k!='bundles'},
                                                       prior_receipt_sha256=EXPECTED_PREVIOUS) for oid in sorted(reused_ids)]
        result['original_object_type_counts']=dict(collections.Counter(
            [row['type'] for row in objects.values()]+[previous_objects[x]['type'] for x in reused_ids]))
        receipt['status']='complete_original_payload' if not scanner.limits else 'partial'
    except Exception as e:
        fatal=dict(type=type(e).__name__,detail=str(e))
        scanner.limit('checkpoint-run',e.kind if isinstance(e,m.Limit) else 'fatal_exception',str(e))
    finally:
        after=donor_snapshot()
        save('donors-after.json',after)
        moves=movement(before,after)
        frozen_unchanged=identity(PREVIOUS/'result.json')==previous_identity and identity(HELPER)['sha256']==EXPECTED_HELPER
        result.update(fatal=fatal,counts=dict(scanner.counts),json_nodes=scanner.json_nodes,
                      decoded_bytes=scanner.decoded,payload_regions=scanner.regions,
                      archive_member_inventory=scanner.members,decoded_text_fields=scanner.strings,
                      nested_bundles=scanner.nested_bundle_receipts,exact_matches=scanner.matches,
                      candidates=scanner.candidates,metadata_mentions=scanner.mentions,coverage_limits=scanner.limits,
                      donor_observations=moves,donor_snapshot_scope=before['scope'],
                      donor_refs_and_pack_metadata_unchanged=before==after,
                      donor_pack_metadata_unchanged=all(x['pack_file_metadata_unchanged'] for x in moves),
                      concurrent_ref_movement_interpretation='Any observed P34 ref/HEAD movement is reported separately; root explicitly authorized concurrent P34 commits. This scanner sends only cat-file/for-each-ref/rev-parse to donors and writes solely to its new isolated store.',
                      prior_eleven_receipt_and_helper_unchanged=frozen_unchanged,
                      elapsed_seconds=round(time.monotonic()-scanner.start,3))
        result['status']='exact_source_recovered' if scanner.matches else 'partial_negative' if fatal or scanner.limits else 'bounded_negative'
        result['limitations']=['No source-scan coverage of donor base objects or unrelated inherited Git tree contents.',
                               'No new coverage inferred for extra targets from old primary-only exclusions.',
                               'No source installation, proof implementation or Lean acceptance.']
        path=save('result.json',result)
        print(json.dumps(dict(status=result['status'],receipt=path,counts=result['counts'],
                              original_objects=len(result['original_objects']),limits=len(scanner.limits),
                              matches=len(scanner.matches),refs_and_packs_unchanged=before==after,
                              prior_eleven_receipt_preserved=frozen_unchanged,elapsed_seconds=result['elapsed_seconds'])),flush=True)
    return 1 if fatal or not frozen_unchanged else 0


if __name__=='__main__':
    raise SystemExit(main())
