#!/usr/bin/env python3
"""Read-only, allowlisted streaming archive continuation. Standard library only."""
import argparse
import base64
import binascii
import bz2
from collections import Counter
from contextlib import contextmanager
import gzip
import hashlib
import io
import json
import lzma
import os
from pathlib import Path, PurePosixPath
import re
import resource
import stat
import sys
import tarfile
import time
import zipfile
import zlib

MIB = 1 << 20
CHUNK = 256 << 10
MAX_JSON = 32 * MIB
MAX_JSON_LINE = 8 * MIB
MAX_ENCODED = 16 * MIB
MAX_WINDOW = 64 * MIB
MAX_ZIP = 48 * MIB
MAX_ZIP_INDEX = 12 * MIB
MAX_TAR_META = 512 << 10
MAX_MEMBERS = 50_000
MAX_DEPTH = 10
MAX_JSON_DEPTH = 128
MAX_JSON_VALUES = 8_000_000
MAX_PATH = 1024
MAX_EVENTS = 150_000
MAX_EXPANDED = 4 << 30
MAX_ADDRESS = 768 * MIB
DEFAULT_OUT = '/workspace/p34-recovery-delta-20261126'
ALLOWLIST_SHA256 = '1ec8c01029cff0a7140e66581a29a36847538c125095271a6c334f56c57bb660'
CODECS = (ValueError, OSError, EOFError, UnicodeError, RuntimeError, tarfile.TarError,
          zipfile.BadZipFile, lzma.LZMAError, zlib.error)
UNSUPPORTED = ('.zst', '.rar', '.7z', '.lz4', '.zstd', '.lzip', '.lz', '.z')
HEX = re.compile(rb'[0-9a-fA-F]+\Z')
B64 = re.compile(rb'[A-Za-z0-9+/_-]+={0,2}\Z')
SPACE = re.compile(rb'\s+')
ENCODING = re.compile(r'(^|[_-])(b64|base64|hex)([_-]|$)', re.I)
PAYLOAD_FIELDS = {'content', 'payload', 'data', 'blob', 'bytes', 'source', 'body', 'value'}
PLAIN_HINTS = {'utf-8', 'utf8', 'text', 'plain', 'ascii', 'none'}
TEXT_SUFFIX = ('.txt', '.log', '.lean', '.raw', '.out', '.md', '.utf8')


class Boundary(Exception):
    def __init__(self, kind, detail, stop=False):
        super().__init__(detail)
        self.kind = kind
        self.stop = stop


class JsonObject(list):
    """Preserve duplicate keys."""


def digest(data):
    return hashlib.sha256(data).hexdigest()


def short(value):
    if len(value) <= MAX_PATH:
        return value
    return value[:MAX_PATH] + '@sha256:' + digest(value.encode(errors='surrogatepass'))


def joined(parent, child):
    return short(parent + '!' + child)


def limit(condition, kind, detail, stop=False):
    if condition:
        raise Boundary(kind, detail, stop)


def valid_member(name):
    path = PurePosixPath(name)
    return bool(name) and not path.is_absolute() and '..' not in path.parts and not (
        '\\' in name or '\x00' in name or re.match(r'^[A-Za-z]:', name)
    )


def name_of(path):
    return path.rsplit('!', 1)[-1].rsplit('/', 1)[-1]


def names_target(row, name):
    return row['module'].lower().removeprefix('part3') in name.lower()


def codec(head, name):
    name = name.lower()
    if name.endswith(('.b64', '.base64')):
        return 'base64'
    if name.endswith(('.hex', '.hexadecimal')):
        return 'hex'
    if name.endswith('.zlib'):
        return 'zlib'
    if head.startswith((b'# v2 git bundle', b'# v3 git bundle', b'PACK')) or name.endswith('.bundle'):
        return 'git_payload'
    if head.startswith((b'PK\x03\x04', b'PK\x05\x06', b'PK\x07\x08')) or name.endswith('.zip'):
        return 'zip'
    if head.startswith(b'\x1f\x8b'):
        return 'gzip'
    if head.startswith(b'\xfd7zXZ\x00'):
        return 'xz'
    if head.startswith(b'BZh'):
        return 'bzip2'
    if head[257:262] == b'ustar' or name.endswith('.tar'):
        return 'tar'
    if name.endswith(('.jsonl', '.ndjson')):
        return 'jsonl'
    if name.endswith('.json') or head.removeprefix(b'\xef\xbb\xbf').lstrip().startswith((b'{', b'[')):
        return 'json'
    if name.endswith(UNSUPPORTED) or head.startswith((b'\x28\xb5\x2f\xfd', b'7z\xbc\xaf\x27\x1c', b'Rar!', b'\x04\x22\x4d\x18')):
        return 'unsupported_codec'
    if name.endswith(('.gz', '.tgz', '.xz', '.bz2', '.tbz2')):
        return 'invalid_wrapper'
    return None


def inner_name(name):
    for outer, replacement in (('.tgz', '.tar'), ('.tbz2', '.tar'), ('.gz', ''), ('.xz', ''), ('.zlib', ''),
                               ('.bz2', ''), ('.base64', ''), ('.b64', ''), ('.hexadecimal', ''), ('.hex', '')):
        if name.lower().endswith(outer):
            return name[:-len(outer)] + replacement
    return 'decoded-payload'


def likely_zlib(data):
    return len(data) >= 2 and data[0] & 15 == 8 and data[0] >> 4 <= 7 and int.from_bytes(data[:2], 'big') % 31 == 0


def readable_head(data):
    if not data or b'\x00' in data:
        return False
    return all(byte >= 32 or byte in (9, 10, 12, 13) for byte in data)


class Meter:
    def __init__(self, source, scan, expected=None, expanded=False):
        self.source = source
        self.scan = scan
        self.expected = expected
        self.expanded = expanded
        self.hash = hashlib.sha256()
        self.size = 0

    def read(self, count):
        self.scan.check_time()
        if count < 0:
            raise ValueError('unbounded read')
        if self.expanded:
            count = min(count, self.scan.expanded_limit - self.scan.expanded + 1)
        data = self.source.read(count)
        if self.expanded:
            self.scan.charge(len(data))
        self.hash.update(data)
        self.size += len(data)
        limit(self.expected is not None and self.size > self.expected, 'member_size_mismatch',
              'read beyond declared byte count')
        return data

    def finish(self):
        while self.read(CHUNK):
            pass
        if self.expected is not None and self.size != self.expected:
            raise Boundary('member_size_mismatch', f'expected {self.expected}, read {self.size}')
        return {'bytes': self.size, 'sha256': self.hash.hexdigest()}


class Prefix:
    def __init__(self, head, source):
        self.head = head
        self.source = source

    def read(self, count):
        if not self.head:
            return self.source.read(count)
        prefix, self.head = self.head[:count], self.head[count:]
        return prefix + (self.source.read(count - len(prefix)) if len(prefix) < count else b'')


class BufferedAdapter(io.RawIOBase):
    def __init__(self, source):
        self.source = source

    def readable(self):
        return True

    def readinto(self, destination):
        data = self.source.read(len(destination))
        destination[:len(data)] = data
        return len(data)


class StrictCompressed:
    """Incremental XZ/BZip2 with explicit EOF, concatenation and trailing checks."""
    def __init__(self, source, kind):
        self.source = source
        self.kind = kind
        self.decoder = None
        self.pending = b''
        self.done = False
        self.members = 0
        self.padding = 0

    def read(self, size):
        output = bytearray()
        while len(output) < size and not self.done:
            if self.decoder is None:
                self.start_member()
                if self.done:
                    break
            chunk = b''
            if self.decoder.needs_input:
                chunk, self.pending = self.pending, b''
                chunk = chunk or self.source.read(CHUNK)
                if not chunk:
                    raise EOFError(f'{self.kind} ended before its end marker')
            try:
                output.extend(self.decoder.decompress(chunk, max_length=size - len(output)))
            except lzma.LZMAError as exc:
                if 'Memory usage limit' in str(exc):
                    raise Boundary('xz_memory_limit', str(exc)) from exc
                raise
            if self.decoder.eof:
                self.pending = self.decoder.unused_data
                self.decoder = None
                self.members += 1
        return bytes(output)

    def start_member(self):
        if self.kind == 'xz' and self.members:
            while True:
                self.pending = self.pending or self.source.read(CHUNK)
                if not self.pending:
                    break
                trimmed = self.pending.lstrip(b'\x00')
                self.padding += len(self.pending) - len(trimmed)
                self.pending = trimmed
                if self.pending:
                    break
            limit(self.padding % 4 != 0, 'format_error', 'XZ padding is not a multiple of four bytes')
            self.padding = 0
        else:
            self.pending = self.pending or self.source.read(CHUNK)
        if not self.pending:
            if not self.members:
                raise EOFError(f'no {self.kind} member')
            self.done = True
            return
        self.decoder = (lzma.LZMADecompressor(format=lzma.FORMAT_XZ, memlimit=MAX_WINDOW)
                        if self.kind == 'xz' else bz2.BZ2Decompressor())


class BoundedTarInfo(tarfile.TarInfo):
    @classmethod
    def fromtarfile(cls, archive):
        archive._delta_end = False
        archive._delta_meta = 0
        try:
            return super().fromtarfile(archive)
        except tarfile.EOFHeaderError:
            archive._delta_end = True
            raise

    def check_metadata(self, archive):
        archive._delta_meta += max(512, self.size)
        limit(self.size < 0 or archive._delta_meta > MAX_TAR_META,
              'tar_metadata_limit', 'PAX/GNU extension metadata exceeds bounded allocation')

    def _proc_pax(self, archive):
        self.check_metadata(archive)
        result = super()._proc_pax(archive)
        limit(len(archive.pax_headers) > 4096 or
              sum(len(k) + len(v) for k, v in archive.pax_headers.items()) > MAX_TAR_META,
              'tar_metadata_limit', 'accumulated global PAX metadata exceeds limit')
        return result

    def _proc_gnulong(self, archive):
        self.check_metadata(archive)
        return super()._proc_gnulong(archive)

    def _proc_sparse(self, *args):
        raise Boundary('tar_sparse_unsupported', 'GNU sparse TAR cannot be safely enumerated')

    def _proc_gnusparse_00(self, *args):
        self._proc_sparse()

    def _proc_gnusparse_01(self, *args):
        self._proc_sparse()

    def _proc_gnusparse_10(self, *args):
        self._proc_sparse()


@contextmanager
def regular_file(path):
    parts = Path(path).parts
    if not parts or parts[0] != '/' or '..' in parts:
        raise ValueError('absolute allowlisted path required')
    flags = os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC
    directory = os.open('/', flags | os.O_DIRECTORY)
    try:
        for part in parts[1:-1]:
            new_directory = os.open(part, flags | os.O_DIRECTORY, dir_fd=directory)
            os.close(directory)
            directory = new_directory
        descriptor = os.open(parts[-1], flags | os.O_NONBLOCK, dir_fd=directory)
    finally:
        os.close(directory)
    with os.fdopen(descriptor, 'rb') as source:
        if not stat.S_ISREG(os.fstat(source.fileno()).st_mode):
            raise ValueError('input is not a regular file')
        yield source


def stamp(source):
    st = os.fstat(source.fileno())
    return st.st_dev, st.st_ino, st.st_size, st.st_mtime_ns, st.st_ctime_ns


def read_limit(source, maximum, kind):
    chunks = bytearray()
    while len(chunks) <= maximum:
        block = source.read(min(CHUNK, maximum + 1 - len(chunks)))
        if not block:
            return bytes(chunks)
        chunks.extend(block)
    raise Boundary(kind, f'payload exceeds {maximum} bytes')


def decode_encoded(data, kind):
    raw = SPACE.sub(b'', data)
    if kind in ('hex', 'hexadecimal'):
        return binascii.unhexlify(raw)
    if not B64.fullmatch(raw):
        raise ValueError('invalid Base64 alphabet or padding')
    return base64.b64decode(raw + b'=' * (-len(raw) % 4), altchars=b'-_', validate=True)


class Scan:
    def __init__(self, allowlist, inventory, seconds, expanded_limit):
        self.data = allowlist
        self.inventory = inventory
        self.deadline = time.monotonic() + seconds
        self.expanded_limit = expanded_limit
        self.expanded = 0
        self.counts = Counter()
        self.boundaries = Counter()
        self.events = 0
        self.limits_sample = []
        self.region = ''
        self.regions = []
        self.matches = {}
        self.match_locations = {}
        self.targets = allowlist['targets']
        self.target_sizes = {target['bytes'] for target in self.targets}
        packed = allowlist['prior_selected_and_complete_sha256']
        self.prior = {packed[i:i + 64] for i in range(0, len(packed), 64)}
        self.prior_sizes = set(allowlist['prior_selected_and_complete_bytes'])
        self.prior_complete = {tuple(item) for item in allowlist['excluded_complete_117']}
        self.prior_partial = {tuple(item) for item in allowlist['prior_partial_18']}
        self.seen = set()
        self.seen_sizes = set()
        self.outer_identity = {}
        self.last_completed_member = {}
        self.p29_verified = False
        self.checkpoint = None

    def check_time(self):
        limit(time.monotonic() > self.deadline, 'deadline', 'internal monotonic deadline reached', True)

    def charge(self, size):
        self.expanded += size
        limit(self.expanded > self.expanded_limit, 'expansion_limit',
              f'decoded byte limit {self.expanded_limit} reached', True)

    def event(self, kind, location, **data):
        self.events += 1
        limit(self.events > MAX_EVENTS, 'receipt_limit', 'inventory event limit reached', True)
        self.inventory.write(json.dumps({'kind': kind, 'region': self.region, 'location': short(location),
                                         **data}, ensure_ascii=True, separators=(',', ':')) + '\n')

    def boundary(self, location, kind, detail):
        self.boundaries[kind] += 1
        row = {'location': short(location), 'boundary': kind, 'detail': short(str(detail))}
        if len(self.limits_sample) < 60:
            self.limits_sample.append(row)
        if self.events < MAX_EVENTS:
            self.event('boundary', **row)

    def exclude(self, loc, identity, reason):
        self.counts[reason] += 1
        self.event('excluded', loc, reason=reason, **identity)

    def check_target(self, loc, raw, fingerprint=None, name=''):
        named = [row for row in self.targets if names_target(row, name)]
        if len(raw) not in self.target_sizes and not named:
            return
        sha = fingerprint or digest(raw)
        for row in self.targets:
            if len(raw) == row['bytes'] or row in named:
                exact = len(raw) == row['bytes'] and sha == row['sha256']
                self.event('candidate', loc, target=row['filename'], bytes=len(raw), sha256=sha, exact=exact)
                if exact:
                    self.matches[row['filename']] = raw
                    self.match_locations.setdefault(row['filename'], []).append(short(loc))

    @contextmanager
    def verified(self, row):
        path = row['path']
        with regular_file(path) as source:
            before = stamp(source)
            limit(before[2] != row['bytes'], 'outer_size_mismatch',
                  f'expected {row["bytes"]}, stat returned {before[2]}')
            identity = Meter(source, self, row['bytes']).finish()
            limit(bool(row.get('sha256') and row['sha256'] != identity['sha256']), 'outer_sha_mismatch',
                  f'observed {identity["sha256"]}')
            limit(stamp(source) != before, 'outer_changed', 'input changed while hashing')
            self.outer_identity[path] = identity
            source.seek(0)
            try:
                yield source, identity
            finally:
                limit(stamp(source) != before, 'outer_changed', 'input changed after identity verification')

    def attempt(self, location, operation):
        before = self.boundaries.total()
        try:
            operation()
        except Boundary as exc:
            self.boundary(location, exc.kind, exc)
            if exc.stop:
                raise
        except MemoryError:
            self.boundary(location, 'allocation_limit', 'Python address-space cap reached')
        except RecursionError as exc:
            self.boundary(location, 'parser_recursion_limit', exc)
        except CODECS as exc:
            self.boundary(location, 'format_or_io_error', f'{type(exc).__name__}: {exc}')
        return self.boundaries.total() == before

    def run_region(self, name, row, operation, success='delta_complete', scan_archive=True):
        self.region = name
        path = row['path']
        entry = {'name': name, 'path': path, 'status': 'partial'}
        self.regions.append(entry)

        def run():
            with self.verified(row) as (source, identity):
                entry.update(identity)
                if scan_archive:
                    limit((identity['bytes'], identity['sha256']) in self.prior_complete,
                          'outside_delta_scope', 'exact identity is a prior complete representative')
                operation(path, source, identity)

        try:
            if self.attempt(path, run):
                entry['status'] = success
        finally:
            self.event('region', path, status=entry['status'],
                       identity=self.outer_identity.get(path))

    def member_count(self):
        self.counts['archive_members'] += 1
        limit(self.counts['archive_members'] > MAX_MEMBERS, 'member_count_limit',
              f'archive entry limit {MAX_MEMBERS} reached', True)

    def read_member(self, parent, ordinal, name, size, source, depth, expanded, *, snapshot=None):
        location = joined(parent, f'{ordinal}:{name}')
        meter = Meter(source, self, size, expanded)
        before = self.boundaries.total()
        def inspect():
            if snapshot is not None:
                identity = meter.finish()
                limit(identity['sha256'] != snapshot or size != meter.size, 'snapshot_identity',
                      f'snapshot digest {identity["sha256"]} differs from retained observation')
                self.exclude(location, identity, 'prior_snapshot_digest_only')
            else:
                self.visit(location, name_of(name), meter, depth, size, path=name)
        ok = self.attempt(location, inspect)
        identity = meter.finish()
        self.event('member_payload', location, status='checked' if ok else 'partial', **identity)
        if ok:
            self.last_completed_member[self.region] = location
        return self.boundaries.total() == before

    def tar(self, location, source, depth, selected=None, snapshot=None):
        selected_seen = Counter()
        snapshot_seen = False
        with tarfile.open(fileobj=source, mode='r|', tarinfo=BoundedTarInfo, bufsize=CHUNK) as archive:
            for ordinal, member in enumerate(archive, 1):
                self.check_time()
                self.member_count()
                loc = joined(location, f'{ordinal}:{member.name}')
                size = member.size
                limit(size < 0 or member.offset_data + size > (1 << 63) - 1,
                      'tar_member_bounds', f'invalid member extent at {loc}')
                regular = member.type in (tarfile.REGTYPE, tarfile.AREGTYPE, tarfile.CONTTYPE) and not member.sparse
                self.event('tar_header', loc, member_name=short(member.name), ordinal=ordinal,
                           bytes=size, offset=member.offset_data, type=member.type.decode('ascii', 'replace'))
                if selected is not None and member.name not in selected:
                    self.counts['prior_p29_member_excluded'] += 1
                    continue
                if selected is not None:
                    selected_seen[member.name] += 1
                    limit(selected_seen[member.name] != 1 or size != selected[member.name],
                          'p29_member_identity', f'unexpected occurrence or size at {loc}')
                if not regular:
                    if not member.isdir():
                        self.boundary(loc, 'nonregular_tar_member', 'regular-file bytes unavailable without resolving member type/link')
                    continue
                if not valid_member(member.name):
                    self.boundary(loc, 'unsafe_tar_path', 'path outside safe member-name syntax')
                    continue
                skip_sha = None
                if snapshot and ordinal == 1:
                    limit(member.name != 'ORIGINAL_EXPORT_MANIFEST.json' or size != 11_457_056,
                          'p21_first_manifest_identity', 'P2.1 first manifest name/size mismatch')
                if snapshot and member.name == snapshot['archive_member']:
                    limit(snapshot_seen, 'snapshot_identity', 'duplicate P2.1 snapshot path')
                    snapshot_seen = True
                    limit(size != snapshot['bytes'], 'snapshot_identity', 'snapshot size changed')
                    skip_sha = snapshot['sha256']
                with archive.extractfile(member) as entry:
                    self.read_member(location, ordinal, member.name, size, entry, depth + 1, False,
                                     snapshot=skip_sha)
            limit(not archive._delta_end, 'tar_end_marker', 'missing or malformed first TAR zero block')
            limit(archive.fileobj.read(512) != bytes(512), 'tar_end_marker', 'missing second TAR zero block')
            while True:
                tail = archive.fileobj.read(CHUNK)
                if not tail:
                    break
                limit(any(tail), 'tar_nonzero_tail', 'nonzero data after TAR end markers')
            if snapshot:
                limit(not snapshot_seen, 'snapshot_identity', 'retained P2.1 snapshot member missing')
            if selected is not None:
                limit(set(selected_seen) != set(selected), 'p29_member_identity',
                      f'missing expected members: {sorted(set(selected) - set(selected_seen))}')

    @contextmanager
    def zip_archive(self, source):
        end = zipfile._EndRecData(source)
        if end is None:
            raise zipfile.BadZipFile('ZIP central directory end record unavailable')
        limit(end[zipfile._ECD_SIZE] > MAX_ZIP_INDEX, 'zip_index_limit', 'ZIP central directory exceeds 12 MiB')
        limit(end[zipfile._ECD_ENTRIES_TOTAL] > MAX_MEMBERS, 'zip_index_limit', 'ZIP entry count exceeds limit')
        source.seek(0)
        with zipfile.ZipFile(source) as archive:
            limit(len(archive.infolist()) != end[zipfile._ECD_ENTRIES_TOTAL],
                  'zip_index_mismatch', 'ZIP directory entry count differs from end record')
            yield archive

    def zip_members(self, location, source, depth, block_member=None, identity_only=False):
        started = block_member is None
        found = 0
        with self.zip_archive(source) as archive:
            for ordinal, member in enumerate(archive.infolist(), 1):
                self.member_count()
                loc = joined(location, f'{ordinal}:{member.orig_filename}')
                self.event('zip_header', loc, ordinal=ordinal, member_name=short(member.orig_filename),
                           bytes=member.file_size, compressed_bytes=member.compress_size,
                           crc32=f'{member.CRC:08x}', header_offset=member.header_offset,
                           compression_method=member.compress_type)
                if identity_only:
                    continue
                selected = member.orig_filename == block_member
                if selected:
                    found += 1
                    limit(found != 1, 'block24_member_identity', 'duplicate selected ZIP name')
                    started = True
                if not started:
                    self.exclude(loc, {}, 'prior_block24_prefix_excluded')
                    continue
                if member.is_dir():
                    continue
                mode = (member.external_attr >> 16) & 0xffff if member.create_system == 3 else 0
                if not valid_member(member.orig_filename) or stat.S_IFMT(mode) not in (0, stat.S_IFREG):
                    self.boundary(loc, 'unsafe_or_nonregular_zip_member', 'ZIP member is not a safe regular file')
                    continue
                if selected:
                    def inspect_selected():
                        with archive.open(member) as entry:
                            meter = Meter(entry, self, member.file_size, expanded=True)
                            self.compressed(loc, member.orig_filename, meter, depth + 1, 'gzip', force_tar=True)
                            self.event('zip_selected_payload', loc, **meter.finish())
                    self.attempt(loc, inspect_selected)
                else:
                    def inspect():
                        with archive.open(member) as entry:
                            self.read_member(location, ordinal, member.orig_filename, member.file_size,
                                             entry, depth + 1, True)
                    self.attempt(loc, inspect)
        if block_member is not None:
            limit(found != 1, 'block24_member_identity', 'exact nested ZIP member missing')

    def compressed(self, loc, name, source, depth, kind, *, force_tar=False, selected=None, snapshot=None):
        limit(depth > MAX_DEPTH, 'nested_depth_limit', f'container nesting exceeds {MAX_DEPTH}')
        inner = inner_name(name)
        inner_loc = joined(loc, inner)
        transport = source if isinstance(source, Meter) else Meter(source, self)
        expanded = (gzip.GzipFile(fileobj=transport) if kind == 'gzip'
                    else StrictCompressed(transport, kind))
        meter = Meter(expanded, self, expanded=True)
        try:
            if force_tar:
                ok = self.attempt(inner_loc, lambda: self.tar(inner_loc, meter, depth + 1, selected, snapshot))
            else:
                ok = self.attempt(inner_loc, lambda: self.visit(inner_loc, inner, meter, depth + 1))
            identity = meter.finish()
            self.event('decompressed', inner_loc, codec=kind, integrity='verified_eof',
                       payload_status='checked' if ok else 'partial', **identity)
            return identity
        finally:
            if kind == 'gzip':
                expanded.close()

    def visit(self, loc, name, source, depth, size=None, *, path=''):
        limit(depth > MAX_DEPTH, 'nested_depth_limit', f'container nesting exceeds {MAX_DEPTH}')
        head = source.read(512)
        stream = Prefix(head, source)
        kind = codec(head, name)
        if kind is None and re.search(r'(?:^|/)objects/', path) and likely_zlib(head):
            kind = 'zlib'
        named = any(names_target(row, name) for row in self.targets)
        candidate = named or size in self.target_sizes
        # Probe recognizable encoded data in anonymous and ordinary text members.
        text = readable_head(head) or name.lower().endswith(TEXT_SUFFIX)
        if not (kind or candidate or text):
            self.counts['outside_candidate_and_wrapper_rules'] += 1
            return
        if kind in ('gzip', 'xz', 'bzip2', 'tar') and not candidate:
            if size is None or size not in self.prior_sizes | self.seen_sizes:
                return self.visit_stream_wrapper(loc, name, stream, depth, kind)
            limit(size > MAX_ZIP, 'duplicate_precheck_limit',
                  'stream wrapper has a prior/seen size and exceeds the in-memory identity precheck cap')
        if kind == 'jsonl' and not candidate and (size is None or size > MAX_JSON):
            return self.json_lines(loc, stream, depth)
        if not kind and not candidate and size is not None and size > MAX_JSON:
            return self.text_lines(loc, stream, depth)
        maximum = {'zip': MAX_ZIP, 'base64': MAX_ENCODED, 'hex': MAX_ENCODED,
                   'json': MAX_JSON, 'jsonl': MAX_JSON}.get(kind, MAX_ZIP)
        limit(size is not None and size > maximum, 'member_memory_limit',
              f'{kind or "source candidate"} has {size} bytes, cap {maximum}')
        raw = read_limit(stream, maximum, 'member_memory_limit')
        if size is not None:
            limit(len(raw) != size, 'member_size_mismatch', f'expected {size}, read {len(raw)}')
        self.visit_bytes(loc, name, raw, depth, kind=kind, path=path)

    def visit_stream_wrapper(self, loc, name, stream, depth, kind):
        inner = Meter(stream, self)
        before = self.boundaries.total()
        if kind == 'tar':
            self.tar(loc, inner, depth)
        else:
            self.compressed(loc, name, inner, depth, kind)
        identity = inner.finish()
        key = (identity['sha256'], kind)
        if self.boundaries.total() == before:
            self.seen.add(key)
            self.seen_sizes.add(identity['bytes'])
        self.event('stream_wrapper', loc, codec=kind, **identity)

    def visit_bytes(self, loc, name, raw, depth, *, kind=None, path=''):
        limit(depth > MAX_DEPTH, 'nested_depth_limit', f'container nesting exceeds {MAX_DEPTH}')
        sha = digest(raw)
        self.check_target(loc, raw, sha, name)
        kind = kind or codec(raw[:512], name)
        key = (sha, kind)
        ident = {'bytes': len(raw), 'sha256': sha}
        if sha in self.prior:
            self.exclude(loc, ident, 'prior_identity_excluded')
            return
        if key in self.seen:
            self.exclude(loc, ident, 'same_run_complete_excluded')
            return
        before = self.boundaries.total()
        stream = io.BytesIO(raw)
        if kind in ('gzip', 'xz', 'bzip2', 'tar'):
            self.visit_stream_wrapper(loc, name, stream, depth, kind)
        elif kind == 'zip':
            self.zip_members(loc, stream, depth)
        elif kind == 'zlib':
            decoder = zlib.decompressobj()
            cap = min(MAX_ZIP, self.expanded_limit - self.expanded)
            decoded = decoder.decompress(raw, max_length=cap + 1)
            limit(len(decoded) > cap, 'zlib_expansion_limit', 'nested zlib payload exceeds expansion or memory cap')
            self.charge(len(decoded))
            limit(not decoder.eof or decoder.unused_data, 'format_error', 'incomplete zlib stream or trailing bytes')
            child = inner_name(name)
            if re.match(rb'blob [0-9]+\x00', decoded[:64]):
                header, _, decoded = decoded.partition(b'\x00')
                limit(int(header[5:]) != len(decoded), 'git_loose_object_size', 'Git loose blob size mismatch')
                child = 'git-loose-blob'
            elif re.match(rb'(?:tree|commit|tag) [0-9]+\x00', decoded[:64]):
                header, _, decoded = decoded.partition(b'\x00')
                limit(int(header.rsplit(b' ', 1)[1]) != len(decoded), 'git_loose_object_size',
                      'Git loose metadata size mismatch')
                child = 'git-loose-' + header.split(b' ', 1)[0].decode('ascii')
                if child == 'git-loose-tree':
                    self.event('git_loose_tree_metadata', loc, bytes=len(decoded),
                               targets=[x['filename'] for x in self.targets if x['filename'].encode() + b'\x00' in decoded])
            self.visit_bytes(joined(loc, child), child, decoded, depth + 1)
        elif kind in ('base64', 'hex'):
            decoded = decode_encoded(raw, kind)
            self.charge(len(decoded))
            inner = inner_name(name)
            self.visit_bytes(joined(loc, inner), inner, decoded, depth + 1)
        elif kind == 'json':
            limit(len(raw) > MAX_JSON, 'json_document_limit', f'JSON exceeds {MAX_JSON} bytes')
            self.json_document(loc, raw, depth, allow_jsonl=not name.lower().endswith('.json'))
        elif kind == 'jsonl':
            self.json_lines(loc, stream, depth)
        elif kind == 'git_payload':
            raise Boundary('git_payload_needs_separate_resolver', 'nested Git pack/bundle identity recorded without object import')
        elif kind:
            raise Boundary(kind, f'unhandled wrapper for {name}')
        elif readable_head(raw[:512]) or name.lower().endswith(TEXT_SUFFIX) or path.startswith('objects/'):
            if not self.encoded_string(loc, raw, depth):
                self.text_lines(loc, stream, depth)
        if self.boundaries.total() == before:
            self.seen.add(key)
            self.seen_sizes.add(len(raw))

    def line_records(self, loc, stream, cap):
        with io.BufferedReader(BufferedAdapter(stream), buffer_size=CHUNK) as buffered:
            count = 0
            while True:
                self.check_time()
                line = buffered.readline(cap + 1)
                if not line:
                    break
                count += 1
                at = joined(loc, f'line {count}')
                if len(line) > cap:
                    self.boundary(at, 'text_or_jsonl_line_limit', f'line exceeds {cap} bytes')
                    while line and not line.endswith(b'\n'):
                        self.check_time()
                        line = buffered.readline(CHUNK)
                else:
                    yield at, line

    def text_lines(self, loc, stream, depth):
        for at, line in self.line_records(loc, stream, MAX_JSON_LINE):
            self.check_target(at, line)
            bare = line.removesuffix(b'\n').removesuffix(b'\r')
            if bare != line:
                self.check_target(at, bare)
            if bare.lstrip().startswith((b'{', b'[', b'"')):
                self.attempt(at, lambda: self.json_document(at, bare, depth, allow_jsonl=False))
            elif len(bare) >= min(self.target_sizes) or bare.startswith(b'data:'):
                self.attempt(at, lambda: self.encoded_string(at, bare, depth))

    def json_document(self, loc, raw, depth, allow_jsonl):
        try:
            parsed = json.loads(raw, object_pairs_hook=JsonObject)
        except json.JSONDecodeError as exc:
            if allow_jsonl and exc.msg == 'Extra data':
                self.json_lines(loc, io.BytesIO(raw), depth)
                return
            raise
        if (self.region == 'p21' and loc.endswith(':ORIGINAL_EXPORT_MANIFEST.json')
                and isinstance(parsed, JsonObject)):
            maps = [child for key, child in parsed if key == 'text_artifact_map' and isinstance(child, JsonObject)]
            self.event('p21_manifest_structure', loc, text_artifact_map_entries=[len(item) for item in maps])
        self.json_walk(loc, parsed, depth)

    def json_lines(self, loc, stream, depth):
        for at, line in self.line_records(loc, stream, MAX_JSON_LINE):
            if line.strip():
                self.check_target(at, line)
                self.check_target(at, line.rstrip(b'\r\n'))
                self.attempt(at, lambda: self.json_document(at, line, depth, allow_jsonl=False))

    def json_walk(self, loc, value, depth, nesting=0, key='', hints=()):
        self.check_time()
        self.counts['json_values'] += 1
        limit(self.counts['json_values'] > MAX_JSON_VALUES, 'json_value_count_limit',
              'JSON traversal node limit reached', True)
        limit(nesting > MAX_JSON_DEPTH, 'json_nesting_limit', 'JSON object/array depth exceeds cap')
        if isinstance(value, JsonObject):
            encodings = tuple(dict.fromkeys(child.lower() for field, child in value
                                            if field.lower() == 'encoding' and isinstance(child, str)))
            for field, child in value:
                self.check_target(joined(loc, '<key>'), field.encode(errors='surrogatepass'))
                child_hints = encodings if field.lower() in PAYLOAD_FIELDS else ()
                self.json_walk(joined(loc, field[:240]), child, depth, nesting + 1, field, child_hints)
        elif isinstance(value, list):
            for index, child in enumerate(value):
                self.json_walk(joined(loc, str(index)), child, depth, nesting + 1, key, hints)
        elif isinstance(value, str):
            raw = value.encode(errors='surrogatepass')
            self.check_target(loc, raw, name=key)
            for target in self.targets:
                if target['module'] in value or target['sha256'] in value:
                    self.event('metadata_mention', loc, target=target['filename'])
            field_hint = ENCODING.search(key)
            choices = hints or ((field_hint.group(2).lower(),) if field_hint else ('',))
            for hint in choices:
                self.attempt(loc, lambda: self.encoded_string(loc, raw, depth, hint))

    def encoded_string(self, loc, raw, depth, hint=''):
        if raw.startswith(b'data:') and b';base64,' in raw[:512]:
            raw = raw.split(b';base64,', 1)[1]
            hint = 'base64'
        if hint in PLAIN_HINTS:
            hint = ''
        parts = re.split(r'\s*[+,/]\s*', hint)
        if len(parts) == 2 and 'base64' in parts and set(parts) & {'gzip', 'xz', 'bzip2', 'tar', 'zip'}:
            hint = 'base64'
        if not hint:
            probe = SPACE.sub(b'', raw[:768])
            b64probe = probe[:len(probe) - len(probe) % 4]
            if probe and HEX.fullmatch(probe):
                hex_head = bytes.fromhex(probe[:len(probe) - len(probe) % 2].decode())
                if codec(hex_head, ''):
                    hint = 'hex'
                elif 2 * min(self.target_sizes) <= len(raw) <= MAX_ENCODED:
                    compact = SPACE.sub(b'', raw)
                    if len(compact) in {2 * size for size in self.target_sizes} and HEX.fullmatch(compact):
                        hint = 'hex'
            if not hint and b64probe and B64.fullmatch(b64probe):
                head = base64.b64decode(b64probe, altchars=b'-_', validate=True)
                if codec(head, ''):
                    hint = 'base64'
                elif min(self.target_sizes) <= len(raw) <= MAX_ENCODED:
                    compact = SPACE.sub(b'', raw)
                    expected = {(size + 2) // 3 * 4 - pad for size in self.target_sizes for pad in (0, 1, 2)}
                    if len(compact) in expected and B64.fullmatch(compact):
                        hint = 'base64'
        if not hint:
            return False
        limit(hint not in ('base64', 'b64', 'base64url', 'base64-url', 'hex', 'hexadecimal'),
              'unsupported_json_encoding', f'unknown payload encoding {hint[:120]}')
        limit(len(raw) > MAX_ENCODED, 'encoded_string_limit', f'encoded string exceeds {MAX_ENCODED} bytes')
        decoded = decode_encoded(raw, hint)
        self.charge(len(decoded))
        self.visit_bytes(joined(loc, 'decoded-payload'), '', decoded, depth + 1)
        return True

    def run_first(self):
        inputs = self.data['input']
        # Export first so a later decoder limit can never hide a verified handoff.
        self.run_checkpoint()
        for name in ('priority', 'receipts'):
            self.run_region(name, inputs[name],
                            lambda loc, fd, _: self.compressed(loc, name_of(loc), fd, 0, 'xz', force_tar=True))
        self.run_region('block24', inputs['block24'],
                        lambda loc, fd, _: self.zip_members(loc, fd, 0, block_member=self.data['block24_member']))

        def p29(loc, fd, _):
            identity = self.compressed(loc, name_of(loc), fd, 0, 'xz', force_tar=True,
                                       selected=self.data['p29_members'])
            limit(identity['sha256'] != self.data['p29_inner_sha256'], 'p29_inner_identity',
                  f'actual decoded TAR hash {identity["sha256"]} differs from recorded shared identity')

        self.run_region('p29_xz', inputs['p29_xz'], p29)
        self.p29_verified = self.regions[-1]['status'] == 'delta_complete'
        duplicate = inputs['p29_gzip_duplicate']
        self.regions.append({'name': 'p29_gzip_duplicate', **duplicate, 'status':
                             'delta_complete_via_prior_inner_identity' if self.p29_verified else
                             'partial_shared_region_not_closed', 'outer_read': False,
                             'shared_inner_sha256': self.data['p29_inner_sha256']})

    def run_p21(self):
        row = self.data['input']['p21']
        self.run_region('p21', row,
                        lambda loc, fd, _: self.compressed(loc, name_of(loc), fd, 0, 'xz',
                                                           force_tar=True, snapshot=self.data['p21_snapshot']))

    def run_large_identity(self):
        identities = {}
        for row in self.data['large_outer']:
            def inventory(loc, fd, identity):
                self.event('outer_identity', loc, **identity)
                if name_of(loc).lower().endswith('.zip'):
                    self.zip_members(loc, fd, 0, identity_only=True)
                fingerprint = (identity['bytes'], identity['sha256'])
                self.event('identity_classification', loc,
                           duplicate_of=identities.get(fingerprint),
                           known_complete=fingerprint in self.prior_complete or identity['sha256'] in self.prior,
                           known_partial=fingerprint in self.prior_partial,
                           payload_decoded=False)
                identities.setdefault(fingerprint, loc)
            self.run_region('large-identity', row, inventory, 'identity_only', scan_archive=False)

    def run_checkpoint(self):
        row = self.data['input']['checkpoint']
        def export(loc, fd, _):
            raw = read_limit(fd, row['bytes'], 'checkpoint_size_limit')
            limit(len(raw) != row['bytes'] or digest(raw) != row['sha256'],
                  'checkpoint_identity', 'export bytes differ from verified identity')
            self.checkpoint = {**row, 'base64': base64.b64encode(raw).decode('ascii')}
        self.run_region('checkpoint', row, export, 'verified_transport_export', scan_archive=False)
        if self.regions[-1]['status'] != 'verified_transport_export':
            self.checkpoint = None


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--phase', choices=('first', 'large-identity', 'p21', 'checkpoint'), default='first')
    parser.add_argument('--out', type=Path, default=Path(DEFAULT_OUT))
    parser.add_argument('--allowlist', type=Path, default=Path(__file__).with_name('allowlist.json'))
    parser.add_argument('--seconds', type=int, default=900)
    parser.add_argument('--expanded-limit', type=int, default=MAX_EXPANDED)
    parser.add_argument('--emit-stdout', action='store_true',
                        help='emit complete gzip/base64 transport as numbered lines for paginated task output')
    return parser.parse_args()


def main():
    args = parse_args()
    if args.seconds < 1 or not 1 <= args.expanded_limit <= MAX_EXPANDED:
        raise SystemExit('seconds must be positive and expanded-limit must be within 1..4 GiB')
    out = args.out
    if not out.is_absolute() or out.parent.resolve() != out.parent:
        raise SystemExit('--out must be absolute and its existing parent must be canonical')
    soft, hard = resource.getrlimit(resource.RLIMIT_AS)
    bound = min(x for x in (MAX_ADDRESS, soft, hard) if x != resource.RLIM_INFINITY)
    resource.setrlimit(resource.RLIMIT_AS, (bound, hard))
    with args.allowlist.open('rb') as source:
        raw = read_limit(source, 256 << 10, 'allowlist_size_limit')
    if digest(raw) != ALLOWLIST_SHA256:
        raise SystemExit('allowlist SHA-256 mismatch')
    allowlist = json.loads(raw)
    if len(allowlist['excluded_complete_117']) != 117:
        raise SystemExit('allowlist must include the 117 excluded identities')
    out.mkdir(mode=0o700, exist_ok=False)
    with gzip.open(out / 'member-inventory.jsonl.gz', 'xt', encoding='utf-8', compresslevel=4) as inventory:
        scan = Scan(allowlist, inventory, args.seconds, args.expanded_limit)
        action = {'first': scan.run_first, 'large-identity': scan.run_large_identity,
                  'p21': scan.run_p21, 'checkpoint': scan.run_checkpoint}[args.phase]
        stop = None
        try:
            action()
        except Boundary as exc:
            stop = {'kind': exc.kind, 'detail': str(exc)}
        matches = []
        for target in scan.targets:
            name = target['filename']
            payload = scan.matches.get(name)
            if payload is None:
                continue
            if (len(payload) != target['bytes'] or digest(payload) != target['sha256']
                    or not valid_member(name) or '/' in name or not name.endswith('.lean')):
                raise RuntimeError('exact match revalidation failed')
            with (out / name).open('xb') as destination:
                destination.write(payload)
            matches.append({'filename': name, 'bytes': len(payload), 'sha256': target['sha256'],
                            'locations': scan.match_locations[name][:60],
                            'occurrence_count': len(scan.match_locations[name]),
                            'base64': base64.b64encode(payload).decode('ascii')})
    inventory_path = out / 'member-inventory.jsonl.gz'
    inventory_hash = hashlib.sha256()
    with inventory_path.open('rb') as stored_inventory:
        for chunk in iter(lambda: stored_inventory.read(CHUNK), b''):
            inventory_hash.update(chunk)
    report = {
        'phase': args.phase,
        'status': 'partial' if stop or scan.boundaries else
                  ('identity_only' if args.phase == 'large-identity' else 'delta_complete'),
        'targets': scan.targets,
        'scope': ('Exact new regions only. Old-region and known-fingerprint exclusions enforce authorized scope. '
                  'Older receipts covered PhysicalE3Block only under their specific decoder semantics; '
                  'they establish no DoubleLambda or Fricke negatives.'),
        'allowlist_sha256': digest(raw),
        'regions': scan.regions,
        'capacity': {'address_space_bytes': bound, 'expansion_bytes': args.expanded_limit,
                     'json_bytes': MAX_JSON, 'nesting': MAX_DEPTH, 'deadline_seconds': args.seconds,
                     'new_temporary_bytes': 0},
        'counts': dict(scan.counts),
        'last_completed_members': scan.last_completed_member,
        'boundary_counts': dict(scan.boundaries),
        'boundary_sample': scan.limits_sample,
        'decoded_bytes_charged': scan.expanded,
        'stop': stop,
        'exact_matches': matches,
        'checkpoint': scan.checkpoint,
        'inventory': {'path': str(inventory_path), 'bytes': inventory_path.stat().st_size,
                      'sha256': inventory_hash.hexdigest()},
    }
    encoded = gzip.compress(json.dumps(report, separators=(',', ':'), ensure_ascii=True).encode(), mtime=0)
    with (out / 'result.json.gz').open('xb') as destination:
        destination.write(encoded)
    print(json.dumps({'phase': args.phase, 'status': report['status'], 'regions': scan.regions,
                      'matches': [row['filename'] for row in matches], 'boundary_counts': report['boundary_counts'],
                      'checkpoint_exported': scan.checkpoint is not None, 'stop': stop,
                      'result': str(out / 'result.json.gz'), 'result_bytes': len(encoded),
                      'result_sha256': digest(encoded)}), flush=True)
    if args.emit_stdout:
        exported = base64.b64encode(encoded).decode('ascii')
        for index, offset in enumerate(range(0, len(exported), 4096)):
            print(f'DELTA_RESULT_GZIP_BASE64 {index:05d} {exported[offset:offset + 4096]}')
        print(f'DELTA_RESULT_END {len(exported)} {digest(encoded)}', flush=True)
    return 2 if stop else 0


if __name__ == '__main__':
    sys.exit(main())
