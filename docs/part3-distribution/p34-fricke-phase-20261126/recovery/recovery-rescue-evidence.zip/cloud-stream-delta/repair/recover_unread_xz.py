#!/usr/bin/env python3
"""Resume one unread rescue TAR with its separately verified XZ decoder requirement."""
import argparse
import base64
import codecs
import gzip
import hashlib
import json
import lzma
from pathlib import Path
import resource
import sys
from types import ModuleType

ROOT = Path('/workspace/p34-recovery-delta-20261126')
RUNNER = Path('/workspace/p34-recovery-runner-20261126')
PREFLIGHT_PLAN = ROOT / 'xz-memory-preflight/xz-memory-plan.json'
BASE_SCANNER_SHA = 'e7296a56eae0df9f1cd8a1a7697c27755deb2556f8a1dac8c21af0ec0e1ebb45'
BASE_ALLOWLIST_SHA = '1ec8c01029cff0a7140e66581a29a36847538c125095271a6c334f56c57bb660'
PREFLIGHT_SCANNER_SHA = '5be123aae98a3dffd544f9e66f111be4f2ef88660248cc1ee5f86be0790b88de'
PREFLIGHT_PLAN_SHA = 'c9709f6a5e5351ca72d193f8cb64fe8b55cf98a76678ac3fbb494b47711be1ce'
REPAIR_ALLOWLIST_SHA = '462bea405363a6db9e1a1745263a09fe2d6bba5f47faa36e22a64eea032b7ef4'
REQUIRED_DICTIONARY = 67_108_864
REQUIRED_DECODER = 67_175_064


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def read_checked(path, expected, cap):
    with Path(path).open('rb') as handle:
        raw = handle.read(cap + 1)
    if len(raw) > cap or sha256(raw) != expected:
        raise ValueError(f'{path} did not match pinned length bound and SHA-256')
    return raw


def load_checked_module(path, expected, name):
    raw = read_checked(path, expected, 100_000)
    module = ModuleType(name)
    module.__file__ = str(path)
    exec(compile(raw, str(path), 'exec'), module.__dict__)
    return module


def plausible_json(head):
    """Recognize a JSON structural start and a valid UTF-8 prefix."""
    try:
        text = codecs.getincrementaldecoder('utf-8-sig')().decode(head, final=False).lstrip()
    except UnicodeDecodeError:
        return False
    if not text or text[0] not in '{["':
        return False
    if text[0] == '"':
        return True
    rest = text[1:].lstrip()
    if not rest:
        return True
    return rest[0] in ('"}' if text[0] == '{' else ']{["-0123456789tfn')


def tighten_codec(original):
    def detect(head, name):
        kind = original(head, name)
        if kind == 'json' and not name.lower().endswith('.json') and not plausible_json(head):
            return None
        if kind == 'gzip' and len(head) >= 3 and head[2] != 8:
            # An explicit filename still reaches the format boundary. Inferred
            # gzip requires both the magic and the RFC 1952 method byte.
            return 'invalid_wrapper' if name.lower().endswith(('.gz', '.tgz')) else None
        return kind
    return detect


def scanner_class(base, preflight):
    base.codec = tighten_codec(base.codec)

    class GuardedXZ(base.StrictCompressed):
        def __init__(self, source, memory, stream_count):
            super().__init__(source, 'xz')
            self.memory = memory
            self.stream_count = stream_count

        def start_member(self):
            if self.members:
                while True:
                    self.pending = self.pending or self.source.read(base.CHUNK)
                    if not self.pending:
                        break
                    trimmed = self.pending.lstrip(b'\0')
                    self.padding += len(self.pending) - len(trimmed)
                    self.pending = trimmed
                    if self.pending:
                        break
                base.limit(self.padding % 4 != 0, 'xz_stream_mismatch', 'nonaligned XZ padding')
                self.padding = 0
            else:
                self.pending = self.pending or self.source.read(base.CHUNK)
            if not self.pending:
                base.limit(self.members != self.stream_count, 'xz_stream_mismatch',
                           f'expected {self.stream_count} streams and read {self.members}')
                self.done = True
                return
            base.limit(self.members >= self.stream_count, 'xz_stream_mismatch', 'unplanned XZ stream')
            self.decoder = lzma.LZMADecompressor(format=lzma.FORMAT_XZ, memlimit=self.memory)

    class RepairScan(base.Scan):
        def __init__(self, base_allowlist, extra, inventory, seconds, expanded_limit):
            super().__init__(base_allowlist, inventory, seconds, expanded_limit)
            self.repaired_wrappers = {(sha, codec) for _, sha, codec in extra['first_finished_typed_wrappers']}
            self.seen.update(self.repaired_wrappers)
            self.seen_sizes.update(size for size, _, _ in extra['first_finished_typed_wrappers'])
            self.repairs = extra

        def exclude(self, loc, identity, reason):
            if reason == 'same_run_complete_excluded' and any(
                    sha == identity.get('sha256') for sha, _ in self.repaired_wrappers):
                reason = 'first_run_same_decoder_excluded'
            super().exclude(loc, identity, reason)

        def json_document(self, loc, raw, depth, allow_jsonl):
            try:
                super().json_document(loc, raw, depth, allow_jsonl)
            except UnicodeDecodeError:
                if not allow_jsonl:
                    raise
                # The base scanner checks whole-payload length/digest before this
                # path. A failed anonymous UTF-8 guess cannot be a JSON wrapper.
                self.counts['anonymous_non_utf8_json_probe_rejected'] += 1

        def text_lines(self, loc, stream, depth):
            for at, line in self.line_records(loc, stream, base.MAX_JSON_LINE):
                self.check_target(at, line)
                bare = line.removesuffix(b'\n').removesuffix(b'\r')
                if bare != line:
                    self.check_target(at, bare)
                if plausible_json(bare):
                    self.attempt(at, lambda: self.json_document(at, bare, depth, allow_jsonl=True))
                elif len(bare) >= min(self.target_sizes) or bare.startswith(b'data:'):
                    self.attempt(at, lambda: self.encoded_string(at, bare, depth))

        def scan_rescue(self, name, approved):
            row = self.repairs['unread_rescue'][name]
            if row != self.data['input'][name] or row != preflight.ALLOWED[name]:
                raise ValueError('rescue input did not match both original and repair allowlists')

            def read_new_tar(location, source, identity):
                checks = preflight.DecoderMemory()
                measured = {**row, **preflight.stream_header_table(source, identity['bytes'], checks, self.check_time),
                            'liblzma_version_number': checks.version, 'status': 'verified_metadata'}
                base.limit(preflight.canonical(measured) != preflight.canonical(approved),
                           'xz_preflight_plan_mismatch', 'on-file XZ metadata differs from pinned preflight')
                base.limit(not measured['within_guard'] or
                           measured['max_dictionary_bytes'] != REQUIRED_DICTIONARY or
                           measured['max_decoder_memory_bytes'] != REQUIRED_DECODER,
                           'xz_memory_guard', 'on-file XZ requirement differs from the verified ceiling')
                raw_size = measured['expected_decoded_bytes']
                base.limit(raw_size > self.expanded_limit, 'xz_expansion_preflight',
                           f'raw TAR {raw_size} bytes exceeds job expansion cap {self.expanded_limit}')
                self.event('xz_memory_bound_verified', location, **measured)
                source.seek(0)
                compressed = base.Meter(source, self, row['bytes'])
                decoded = GuardedXZ(compressed, REQUIRED_DECODER, len(measured['streams']))
                meter = base.Meter(decoded, self, raw_size, expanded=True)
                member_name = base.inner_name(base.name_of(location))
                tar_location = base.joined(location, member_name)
                checked = self.attempt(tar_location, lambda: self.tar(tar_location, meter, 1))
                payload_identity = meter.finish()
                transport_identity = compressed.finish()
                base.limit(transport_identity != identity, 'outer_replay_identity',
                           'streamed compressed bytes differed from verified transport digest')
                self.event('decompressed', tar_location, codec='xz', integrity='verified_eof',
                           payload_status='checked' if checked else 'partial', **payload_identity)

            self.run_region(name, row, read_new_tar)

    return RepairScan


def metadata_for(phase, plan):
    if phase not in ('rescue-priority', 'rescue-receipts'):
        return None
    return plan['regions'][phase.removeprefix('rescue-')]


def args_for_run():
    parse = argparse.ArgumentParser(description=__doc__)
    parse.add_argument('--phase', choices=('rescue-priority', 'rescue-receipts', 'large-identity', 'p21'),
                       required=True)
    parse.add_argument('--out', type=Path)
    parse.add_argument('--base-runner', type=Path, default=RUNNER)
    parse.add_argument('--preflight-plan', type=Path, default=PREFLIGHT_PLAN)
    parse.add_argument('--seconds', type=int, default=900)
    parse.add_argument('--expanded-limit', type=int, default=4 << 30)
    parse.add_argument('--emit-stdout', action='store_true')
    return parse.parse_args()


def main():
    args = args_for_run()
    if not 1 <= args.seconds <= 1800 or not 1 <= args.expanded_limit <= 4 << 30:
        raise ValueError('seconds or decoded expansion outside supported bounds')
    local = Path(__file__).resolve().parent
    base = load_checked_module(args.base_runner / 'recover_archive_delta.py', BASE_SCANNER_SHA, 'frozen_recover')
    preflight = load_checked_module(local / 'xz_memory_preflight.py', PREFLIGHT_SCANNER_SHA, 'frozen_xz_preflight')
    base_allowlist = json.loads(read_checked(args.base_runner / 'allowlist.json', BASE_ALLOWLIST_SHA, 256 << 10))
    repair = json.loads(read_checked(local / 'repair-allowlist-v2.json', REPAIR_ALLOWLIST_SHA, 48 << 10))
    if args.phase.startswith('rescue-'):
        plan = json.loads(read_checked(args.preflight_plan, PREFLIGHT_PLAN_SHA, 4096))
        pin = metadata_for(args.phase, plan)
        if pin['status'] != 'verified_metadata' or plan['payload_decoded'] is not False:
            raise ValueError('preflight region was not verified metadata only')
    else:
        pin = None

    out = args.out or ROOT / args.phase
    if not out.is_absolute() or out.parent.resolve() != out.parent:
        raise ValueError('output needs absolute path and existing canonical parent')
    soft, hard = resource.getrlimit(resource.RLIMIT_AS)
    cap = min(item for item in (base.MAX_ADDRESS, soft, hard) if item != resource.RLIM_INFINITY)
    resource.setrlimit(resource.RLIMIT_AS, (cap, hard))
    out.mkdir(mode=0o700, exist_ok=False)
    inventory_path = out / 'member-inventory.jsonl.gz'
    stop = None
    with gzip.open(inventory_path, 'xt', encoding='utf-8', compresslevel=4) as inventory:
        scan = scanner_class(base, preflight)(base_allowlist, repair, inventory, args.seconds, args.expanded_limit)
        try:
            if args.phase == 'large-identity':
                scan.run_large_identity()
            elif args.phase == 'p21':
                scan.run_p21()
            else:
                scan.scan_rescue(args.phase.removeprefix('rescue-'), pin)
        except base.Boundary as exc:
            stop = {'kind': exc.kind, 'detail': str(exc)}
        except preflight.PreflightError as exc:
            scan.boundary(pin['path'], exc.kind, exc)

    matches = []
    for target in scan.targets:
        name = target['filename']
        payload = scan.matches.get(name)
        if payload is None:
            continue
        if (len(payload) != target['bytes'] or sha256(payload) != target['sha256']
                or '/' in name or not name.endswith('.lean') or not base.valid_member(name)):
            raise ValueError('exact match revalidation failed')
        with (out / name).open('xb') as output:
            output.write(payload)
        matches.append({'filename': name, 'bytes': len(payload), 'sha256': target['sha256'],
                        'locations': scan.match_locations[name][:60],
                        'occurrence_count': len(scan.match_locations[name]),
                        'base64': base64.b64encode(payload).decode('ascii')})
    inventory_hash = hashlib.sha256()
    with inventory_path.open('rb') as source:
        for chunk in iter(lambda: source.read(base.CHUNK), b''):
            inventory_hash.update(chunk)
    status = 'partial' if stop or scan.boundaries else (
        'identity_only' if args.phase == 'large-identity' else 'delta_complete')
    report = {
        'phase': args.phase, 'status': status, 'regions': scan.regions,
        'first_task': repair['source_task'], 'base_allowlist_sha256': BASE_ALLOWLIST_SHA,
        'repair_allowlist_sha256': REPAIR_ALLOWLIST_SHA,
        'first_receipt_reconciliation_sha256': repair['receipt_reconciliation_sha256'],
        'xz_preflight_plan_sha256': PREFLIGHT_PLAN_SHA if pin else None,
        'targets': scan.targets, 'exact_matches': matches,
        'counts': dict(scan.counts), 'boundary_counts': dict(scan.boundaries),
        'boundary_sample': scan.limits_sample, 'stop': stop,
        'last_completed_members': scan.last_completed_member,
        'capacity': {'expansion_bytes': args.expanded_limit, 'address_space_bytes': cap,
                     'deadline_seconds': args.seconds, 'temporary_bytes': 0,
                     'outer_liblzma_memlimit': REQUIRED_DECODER if pin else None,
                     'nested_liblzma_memlimit': base.MAX_WINDOW},
        'decoded_bytes_charged': scan.expanded,
        'inventory': {'path': str(inventory_path), 'bytes': inventory_path.stat().st_size,
                      'sha256': inventory_hash.hexdigest()},
        'scope': ('One selected phase under the prior and repair allowlists. Existing first-run regions and '
                  'old representatives are excluded. Their exclusions add no new target coverage.'),
    }
    encoded = gzip.compress(preflight.canonical(report), mtime=0)
    with (out / 'result.json.gz').open('xb') as output:
        output.write(encoded)
    print(json.dumps({'phase': args.phase, 'status': status, 'regions': scan.regions,
                      'targets_found': [row['filename'] for row in matches],
                      'boundary_counts': dict(scan.boundaries), 'decoded_bytes_charged': scan.expanded,
                      'stop': stop, 'result_bytes': len(encoded), 'result_sha256': sha256(encoded)}), flush=True)
    if args.emit_stdout:
        transport = base64.b64encode(encoded).decode()
        for idx, pos in enumerate(range(0, len(transport), 4096)):
            print(f'DELTA_RESULT_GZIP_BASE64 {idx:05d} {transport[pos:pos + 4096]}')
        print(f'DELTA_RESULT_END {len(transport)} {sha256(encoded)}', flush=True)
    return 2 if stop else 0


if __name__ == '__main__':
    raise SystemExit(main())
