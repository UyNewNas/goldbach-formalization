#!/usr/bin/env python3
"""Classify first-run speculative failures using only retained receipt evidence."""
from collections import Counter, defaultdict
import gzip
import hashlib
import json
from pathlib import Path
import re

from xz_memory_preflight import ALLOWED, canonical, sha256

BASE = Path(__file__).resolve().parent.parent
FIRST = BASE.parent / 'cloud-recovery-first'
TASK = '31c27778abee4da0a61019e332dcf930'
BUNDLE_SHA256 = '93f18072c5d13ad9faab8dfd386abf223d1f0de719b69551c4b26cf35ef1d522'
BASE_SHA256 = 'e7296a56eae0df9f1cd8a1a7697c27755deb2556f8a1dac8c21af0ec0e1ebb45'
BASE_ALLOWLIST_SHA256 = '1ec8c01029cff0a7140e66581a29a36847538c125095271a6c334f56c57bb660'
BLOCK_INNER = {'bytes': 21381120, 'sha256': 'a8146276840840402c92d4cffc26ad8c42938e5cc2cc638c5c05a069daafe659'}
BLOCK_MEMBER = {'bytes': 3931453, 'sha256': '54d8bfa7329b1042e415c6455719c2bfa69a2d29ef764df000eeaa55d5e7c68c'}
P29_INNER = {'bytes': 105850880, 'sha256': 'fa2e7c052e982fbda8a962a0e238c55288f1d6c88dee93fc0566f1453753bbfd'}
P29_MEMBERS = {
    '56:verification/borrowed-actual-imports-bindings.json':
        (27062843, '6b0e29d00cf57429278bb0416c62f8642c15738a80c61bd4e0dd0b31513c2659'),
    '88:verification/consumer-actual-imports-bindings.json':
        (27063729, '5edc780b85547e069d9e3de0c2c8b5f8d78ca3f7952016223b8b64c86fc5d092'),
}


def fingerprint(row):
    return row['bytes'], row['sha256']


def expect_identity(row, expected):
    assert fingerprint(row) == fingerprint(expected), (row, expected)


def by_kind(rows, kind):
    return [row for row in rows if row['kind'] == kind]


def exact_one(rows, kind):
    row, = by_kind(rows, kind)
    return row


def source_boundary(location, members):
    assert '@sha256:' not in location, location
    (member,) = (m for m in members if location.startswith(m['location'] + '!'))
    suffix = location[len(member['location']) + 1:]
    assert not re.fullmatch(r'(?:line \d+|\d+:.*)', suffix), location
    return member, suffix


def validate_formats(region, rows, members):
    hash_rows = hashlib.sha256()
    counts = Counter()
    affected = set()
    specials = defaultdict(set)
    for row in by_kind(rows, 'boundary'):
        assert row['boundary'] == 'format_or_io_error', row
        hash_rows.update(canonical(row))
        member, suffix = source_boundary(row['location'], members)
        assert member['status'] == 'partial'
        assert member['location'].split('!')[-1].endswith(('.json', '.log')), member
        if row['detail'].startswith("UnicodeDecodeError: 'utf-8' codec can't decode byte"):
            assert 'decoded-payload' not in suffix and '!line ' not in suffix, row
            counts['speculative_decoded_bytes_fail_utf8_json'] += 1
        else:
            assert region == 'p29_xz'
            base = 'parts!254!identity!sha256'
            if suffix == base + '!decoded-payload!decoded-payload':
                assert row['detail'] == 'BadGzipFile: Unknown compression method', row
                specials[member['location']].add('unknown_gzip_method')
            else:
                assert suffix == base and row['detail'] == "BadGzipFile: Not a gzipped file (b'9Z')", row
                specials[member['location']].add('post_error_drain')
            counts['speculative_digest_gzip_mismatch_or_followon_drain'] += 1
        affected.add(member['location'])
    assert affected == {r['location'] for r in members if r['status'] == 'partial'}
    if region == 'p29_xz':
        assert len(specials) == 2
        assert all(k == {'unknown_gzip_method', 'post_error_drain'} for k in specials.values())
    return {'classifications': dict(counts), 'boundary_rows_sha256': hash_rows.hexdigest(),
            'affected_member_locations': sorted(affected)}


def write_exact(path, data):
    if path.exists():
        assert path.read_bytes() == data, path
    else:
        with path.open('xb') as output:
            output.write(data)


def main():
    assert sha256((BASE / 'recover_archive_delta.py').read_bytes()) == BASE_SHA256
    allowlist_raw = (BASE / 'allowlist.json').read_bytes()
    assert sha256(allowlist_raw) == BASE_ALLOWLIST_SHA256
    allowlist = json.loads(allowlist_raw)
    evidence = (FIRST / 'evidence.zip').read_bytes()
    assert len(evidence) == 199174 and sha256(evidence) == BUNDLE_SHA256
    result_data = (FIRST / 'result.json.gz').read_bytes()
    original = json.loads(gzip.decompress(result_data))
    assert original == json.loads((FIRST / 'result.decoded.json').read_bytes())
    assert original['phase'] == 'first' and original['status'] == 'partial' and original['stop'] is None
    assert original['targets'] == allowlist['targets'] and original['allowlist_sha256'] == BASE_ALLOWLIST_SHA256
    index_data = (FIRST / 'member-inventory.jsonl.gz').read_bytes()
    expect_identity(original['inventory'], {'bytes': len(index_data), 'sha256': sha256(index_data)})
    grouped = defaultdict(list)
    for line in gzip.decompress(index_data).splitlines():
        row = json.loads(line)
        grouped[row['region']].append(row)
    assert set(grouped) == {'checkpoint', 'priority', 'receipts', 'block24', 'p29_xz'}
    assert original['boundary_counts'] == {'xz_memory_limit': 4, 'format_or_io_error': 32959}
    assert original['exact_matches'] == []
    reported_regions = {row['name']: row for row in original['regions']}
    assert reported_regions['checkpoint']['status'] == 'verified_transport_export'
    expect_identity(reported_regions['checkpoint'], allowlist['input']['checkpoint'])

    for name, row in ALLOWED.items():
        assert row == allowlist['input'][name]
        expect_identity(reported_regions[name], row)
        logs = grouped[name]
        assert Counter(x['kind'] for x in logs) == {'boundary': 2, 'region': 1}
        assert all(x['boundary'] == 'xz_memory_limit' and x['detail'] == 'Memory usage limit exceeded'
                   for x in by_kind(logs, 'boundary'))
        assert exact_one(logs, 'region')['status'] == 'partial'

    block = grouped['block24']
    p29 = grouped['p29_xz']
    expect_identity(reported_regions['block24'], allowlist['input']['block24'])
    expect_identity(reported_regions['p29_xz'], allowlist['input']['p29_xz'])
    expect_identity(reported_regions['p29_gzip_duplicate'], allowlist['input']['p29_gzip_duplicate'])
    assert reported_regions['p29_gzip_duplicate']['shared_inner_sha256'] == P29_INNER['sha256']
    assert reported_regions['p29_gzip_duplicate']['outer_read'] is False
    for region, expected in ((block, BLOCK_INNER), (p29, P29_INNER)):
        decompressed = exact_one(region, 'decompressed')
        assert decompressed['integrity'] == 'verified_eof' and decompressed['payload_status'] == 'partial'
        expect_identity(decompressed, expected)
    expect_identity(exact_one(block, 'zip_selected_payload'), BLOCK_MEMBER)
    block_headers = by_kind(block, 'zip_header')
    assert [r['ordinal'] for r in block_headers] == [1, 2, 3, 4, 5]
    assert block_headers[1]['member_name'] == allowlist['block24_member']
    assert len(by_kind(block, 'tar_header')) == 312
    block_members = by_kind(block, 'member_payload')
    assert Counter(m['status'] for m in block_members) == {'checked': 222, 'partial': 93}
    streamed_block_names = {r['location'] for r in by_kind(block, 'tar_header') + block_headers[2:]}
    assert {x['location'] for x in block_members} == streamed_block_names
    p29_payloads = by_kind(p29, 'member_payload')
    assert len(by_kind(p29, 'tar_header')) == 128 and original['counts']['prior_p29_member_excluded'] == 126
    assert len(p29_payloads) == 2 and all(r['status'] == 'partial' for r in p29_payloads)
    assert {r['location'].split('!')[-1]: fingerprint(r) for r in p29_payloads} == P29_MEMBERS
    block_review = validate_formats('block24', block, block_members)
    p29_review = validate_formats('p29_xz', p29, p29_payloads)
    assert block_review['classifications'] == {'speculative_decoded_bytes_fail_utf8_json': 6421}
    assert p29_review['classifications'] == {'speculative_decoded_bytes_fail_utf8_json': 26534,
                                                'speculative_digest_gzip_mismatch_or_followon_drain': 4}

    report = {
        'task': TASK,
        'original_evidence_zip': {'bytes': len(evidence), 'sha256': BUNDLE_SHA256},
        'original_result_gzip': {'bytes': len(result_data), 'sha256': sha256(result_data)},
        'original_inventory_gzip': {'bytes': len(index_data), 'sha256': sha256(index_data)},
        'original_scanner_sha256': BASE_SHA256,
        'original_allowlist_sha256': BASE_ALLOWLIST_SHA256,
        'regions': {
            'priority': {'status': 'unread_tar', 'observations': 2, **ALLOWED['priority']},
            'receipts': {'status': 'unread_tar', 'observations': 2, **ALLOWED['receipts']},
            'block24': {'status': 'bounded_delta_complete_by_receipt_reconciliation',
                        'verified_inner_tar': BLOCK_INNER, 'verified_selected_zip_member': BLOCK_MEMBER,
                        'tar_headers': 312, 'payload_receipts': 315, **block_review},
            'p29_xz': {'status': 'bounded_delta_complete_by_receipt_reconciliation',
                       'verified_inner_tar': P29_INNER, 'selected_member_fingerprints': P29_MEMBERS,
                       'tar_headers': 128, 'prior_excluded': 126, **p29_review},
            'p29_gzip_duplicate': {'status': 'same_inner_tar_by_prior_verified_identity',
                                   'verified_xz_representative_inner_tar': P29_INNER, 'outer_read': False},
        },
        'reasoning': [
            'All Unicode errors are inside successfully parsed JSON string walks. No error is at a selected member, line, or declared JSON document boundary.',
            'The original scanner checks raw JSON string lengths and digests, then checks decoded length and digest before guessing the anonymous codec.',
            'The first unmatched guessed JSON character test accepts a brace/bracket byte alone. The resulting bytes had invalid UTF-8 and yielded no supported JSON wrapper.',
            'Both remaining source locations are the same structural sha256 value in the selected documents. The first gzip probe rejected the method byte. The subsequent drain fails on the already advanced stream; neither is a declared gzip payload.',
            'These are bounded read/decoder classifications. Unknown encodings and trailing or embedded JSON inside non-UTF-8 bytes are outside the original rules.',
            'Only the two rescue TAR regions remain unread in these phases. Earlier excluded representatives contribute no new DoubleLambda or Fricke coverage.',
        ],
    }
    report_data = canonical(report)
    completed_members = {fingerprint(x) for x in block_members + p29_payloads}
    verified_wrappers = {fingerprint(x) for x in (BLOCK_INNER, BLOCK_MEMBER, P29_INNER)}
    already_excluded = {(event['location'], event.get('sha256')) for event in by_kind(block, 'excluded')}
    parsed_json = {fingerprint(row) for row in block_members + p29_payloads
                   if row['location'].endswith('.json') and (row['location'], row['sha256']) not in already_excluded}
    typed_complete = sorted((size, sha, 'json') for size, sha in parsed_json)
    typed_complete += [(*fingerprint(BLOCK_MEMBER), 'gzip'), (*fingerprint(BLOCK_INNER), 'tar')]
    extra = {
        'receipt_reconciliation_sha256': sha256(report_data),
        'source_task': TASK,
        'base_scanner_sha256': BASE_SHA256,
        'base_allowlist_sha256': BASE_ALLOWLIST_SHA256,
        'first_finished_fingerprints': sorted(completed_members | verified_wrappers),
        'first_finished_typed_wrappers': typed_complete,
        'prior_p29_inner_scope_excluded': P29_INNER,
        'unread_rescue': ALLOWED,
        'checkpoint_transport_already_verified': True,
    }
    output = Path(__file__).parent
    write_exact(output / 'first-reconciliation.json', report_data)
    write_exact(output / 'repair-allowlist-v2.json', canonical(extra))
    print(json.dumps({'first_reconciliation_sha256': sha256(report_data),
                      'repair_allowlist_sha256': sha256(canonical(extra)),
                      'first_finished_fingerprints': len(extra['first_finished_fingerprints']),
                      'block24': block_review['classifications'], 'p29_xz': p29_review['classifications']}))


if __name__ == '__main__':
    main()
