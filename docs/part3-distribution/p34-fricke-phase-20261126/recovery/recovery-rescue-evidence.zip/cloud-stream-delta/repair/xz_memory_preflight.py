#!/usr/bin/env python3
"""Verify rescue transport identities and inspect XZ metadata without decoding payloads."""
import argparse
import ctypes as c
import hashlib
import json
import os
from pathlib import Path
import resource
import stat
import struct
import time
import zlib

MIB = 1 << 20
CHUNK = 256 << 10
MAX_INDEX = MIB
MAX_STREAMS = 32
MAX_BLOCKS = 4096
MAX_DICT = 128 * MIB
MAX_RAW_MEMORY = 160 * MIB
BASE_RUNNER = Path('/workspace/p34-recovery-runner-20261126')
DEFAULT_OUT = Path('/workspace/p34-recovery-delta-20261126/xz-memory-preflight')
ALLOWED = {
    'priority': {'path': '/workspace/rescue-export-20261126/priority-objects.tar.xz',
                 'bytes': 19856300,
                 'sha256': '6ea6a2f20159499b7e33b74a77e64723272175db223c6fab41a748d629363c06'},
    'receipts': {'path': '/workspace/rescue-export-20261126/evidence-receipts.tar.xz',
                 'bytes': 38735584,
                 'sha256': '1d7c1b85ab97aeb9ed471325ce67dcc40d3fe6474701b6e9b6c102645f2996b4'},
}
VLI_UNKNOWN = (1 << 64) - 1
CHECK_BYTES = {0: 0, 1: 4, 4: 8, 10: 32}


class PreflightError(Exception):
    def __init__(self, kind, message):
        super().__init__(message)
        self.kind = kind


def require(condition, message, kind='xz_metadata_format'):
    if not condition:
        raise PreflightError(kind, message)


def canonical(value):
    return (json.dumps(value, sort_keys=True, separators=(',', ':')) + '\n').encode()


def crc(data):
    return struct.pack('<I', zlib.crc32(data))


def stamp(file):
    st = os.fstat(file.fileno())
    return st.st_dev, st.st_ino, st.st_size, st.st_ctime_ns, st.st_mtime_ns


def open_regular(path):
    path = Path(path)
    require(path.is_absolute() and '..' not in path.parts, 'path must be absolute', 'input_path')
    flags = os.O_RDONLY | os.O_CLOEXEC | os.O_NOFOLLOW
    directory = os.open('/', flags | os.O_DIRECTORY)
    try:
        for part in path.parts[1:-1]:
            child = os.open(part, flags | os.O_DIRECTORY, dir_fd=directory)
            os.close(directory)
            directory = child
        fd = os.open(path.name, flags | os.O_NONBLOCK, dir_fd=directory)
    finally:
        os.close(directory)
    if not stat.S_ISREG(os.fstat(fd).st_mode):
        os.close(fd)
        raise PreflightError('input_path', 'input must be an ordinary file')
    return os.fdopen(fd, 'rb')


def exact(file, offset, size):
    require(offset >= 0 and size >= 0, 'invalid metadata extent')
    file.seek(offset)
    raw = file.read(size)
    require(len(raw) == size, 'truncated XZ metadata')
    return raw


def sha256(raw):
    return hashlib.sha256(raw).hexdigest()


def verify_archive(file, expected, check_time):
    before = stamp(file)
    require(before[2] == expected['bytes'], 'input length mismatch', 'outer_identity')
    file.seek(0)
    sha = hashlib.sha256()
    while True:
        check_time()
        chunk = file.read(CHUNK)
        if not chunk:
            break
        sha.update(chunk)
    require(sha.hexdigest() == expected['sha256'] and stamp(file) == before,
            'input digest mismatch or mutation', 'outer_identity')
    return before


def vli(source, at, end):
    value = 0
    for shift in range(0, 63, 7):
        require(at < end, 'truncated XZ variable-length field')
        octet = source[at]
        at += 1
        value |= (octet & 0x7f) << shift
        if octet < 128:
            require(shift == 0 or octet != 0, 'noncanonical XZ variable-length field')
            return value, at
    raise PreflightError('xz_metadata_format', 'XZ variable-length field exceeds 63 bits')


class Filter(c.Structure):
    _fields_ = [('id', c.c_uint64), ('options', c.c_void_p)]


class DecoderMemory:
    def __init__(self):
        try:
            self.lib = c.CDLL('liblzma.so.5')
        except OSError as exc:
            raise PreflightError('xz_memusage_unavailable', str(exc)) from exc
        lib = self.lib
        lib.lzma_version_number.argtypes = []
        lib.lzma_version_number.restype = c.c_uint32
        lib.lzma_properties_decode.argtypes = [c.POINTER(Filter), c.c_void_p, c.c_void_p, c.c_size_t]
        lib.lzma_properties_decode.restype = c.c_int
        lib.lzma_raw_decoder_memusage.argtypes = [c.POINTER(Filter)]
        lib.lzma_raw_decoder_memusage.restype = c.c_uint64
        lib.lzma_filters_free.argtypes = [c.POINTER(Filter), c.c_void_p]
        lib.lzma_filters_free.restype = None
        self.version = lib.lzma_version_number()

    def memory(self, filters):
        chain = (Filter * (len(filters) + 1))()
        for item in chain:
            item.id = VLI_UNKNOWN
        try:
            for index, (filter_id, props) in enumerate(filters):
                # Decode filter options only. This allocates no decoding dictionary.
                chain[index].id = filter_id
                buffer = c.create_string_buffer(props)
                ret = self.lib.lzma_properties_decode(c.pointer(chain[index]), None, buffer, len(props))
                require(ret == 0, f'unsupported or invalid filter {filter_id:#x}, liblzma status {ret}',
                        'xz_filter_unsupported')
            required = self.lib.lzma_raw_decoder_memusage(chain)
            require(required != VLI_UNKNOWN, 'liblzma could not inspect filter memory usage', 'xz_filter_unsupported')
            return required
        finally:
            self.lib.lzma_filters_free(chain, None)


def xz_block(header, unpadded, uncompressed, check_id):
    end = len(header) - 4
    require(crc(header[:end]) == header[end:], 'XZ block-header CRC mismatch')
    flags = header[1]
    require(not (flags & 0x3c), 'reserved XZ block-header flags')
    at = 2
    if flags & 0x40:
        compressed, at = vli(header, at, end)
        require(len(header) + compressed + CHECK_BYTES[check_id] == unpadded,
                'XZ block and Index compressed sizes differ')
    if flags & 0x80:
        size, at = vli(header, at, end)
        require(size == uncompressed, 'XZ block and Index uncompressed sizes differ')
    filters = []
    for _ in range((flags & 3) + 1):
        filter_id, at = vli(header, at, end)
        props_size, at = vli(header, at, end)
        require(props_size <= end - at, 'XZ block properties overrun')
        filters.append((filter_id, header[at:at + props_size]))
        at += props_size
    require(not any(header[at:end]), 'nonzero XZ block-header padding')
    lzma2 = [props for filter_id, props in filters if filter_id == 0x21]
    require(len(lzma2) == 1 and filters[-1][0] == 0x21 and len(lzma2[0]) == 1 and lzma2[0][0] <= 40,
            'XZ block must have one valid final LZMA2 filter', 'xz_filter_unsupported')
    prop = lzma2[0][0]
    dictionary = (1 << 32) - 1 if prop == 40 else (2 | (prop & 1)) << (prop // 2 + 11)
    return filters, dictionary


def no_stream_padding(file, end, check_time):
    while end:
        check_time()
        length = min(CHUNK, end)
        trail = exact(file, end - length, length)
        trimmed = trail.rstrip(b'\0')
        zeros = length - len(trimmed)
        end -= zeros
        if trimmed:
            return end
    return 0


def stream_header_table(file, size, decoder, check_time):
    require(size % 4 == 0, 'XZ file length is not four-byte aligned')
    end = size
    streams = []
    chain_info = {}
    total_blocks = 0
    while end:
        end = no_stream_padding(file, end, check_time)
        if not end:
            break
        require(end % 4 == 0 and end >= 24, 'invalid XZ stream end or padding')
        require(len(streams) < MAX_STREAMS, 'XZ stream count cap reached', 'xz_metadata_limit')
        footer = exact(file, end - 12, 12)
        require(footer[10:] == b'YZ' and crc(footer[4:10]) == footer[:4], 'invalid XZ footer')
        flags = footer[8:10]
        require(flags[0] == 0 and flags[1] in CHECK_BYTES, 'unsupported XZ stream-check flags', 'xz_filter_unsupported')
        index_size = (struct.unpack('<I', footer[4:8])[0] + 1) * 4
        require(8 <= index_size <= MAX_INDEX, f'XZ Index size {index_size} outside cap', 'xz_metadata_limit')
        index_start = end - 12 - index_size
        index = exact(file, index_start, index_size)
        require(index[0] == 0 and crc(index[:-4]) == index[-4:], 'invalid XZ Index')
        count, at = vli(index, 1, len(index) - 4)
        total_blocks += count
        require(total_blocks <= MAX_BLOCKS, 'XZ block count cap reached', 'xz_metadata_limit')
        extents = []
        for _ in range(count):
            unpadded, at = vli(index, at, len(index) - 4)
            uncompressed, at = vli(index, at, len(index) - 4)
            require(unpadded >= 5 + CHECK_BYTES[flags[1]], 'invalid XZ block extent')
            extents.append((unpadded, uncompressed))
        require(at + ((-at) % 4) == len(index) - 4 and not any(index[at:-4]), 'noncanonical XZ Index padding')
        start = index_start - 12 - sum((unpadded + 3) & ~3 for unpadded, _ in extents)
        header = exact(file, start, 12)
        require(header[:6] == b'\xfd7zXZ\x00' and header[6:8] == flags and crc(flags) == header[8:],
                'invalid XZ stream header or header/footer flags mismatch')
        table_hash = hashlib.sha256()
        offset = start + 12
        for unpadded, uncompressed in extents:
            check_time()
            size_octet = exact(file, offset, 1)[0]
            block_header_size = (size_octet + 1) * 4
            require(size_octet != 0 and block_header_size < unpadded - CHECK_BYTES[flags[1]],
                    'XZ block header exceeds stated extent')
            block_header = exact(file, offset, block_header_size)
            filters, dictionary = xz_block(block_header, unpadded, uncompressed, flags[1])
            key = tuple((filter_id, option.hex()) for filter_id, option in filters)
            if key not in chain_info:
                memory = decoder.memory(filters)
                chain_info[key] = {'filters': key, 'dictionary_bytes': dictionary, 'decoder_memory_bytes': memory}
            table_hash.update(struct.pack('<QQQ', offset, unpadded, uncompressed))
            table_hash.update(block_header)
            offset += (unpadded + 3) & ~3
        streams.append({'offset': start, 'end': end, 'blocks': count, 'check_id': flags[1],
                        'expected_decoded_bytes': sum(uncompressed for _, uncompressed in extents),
                        'block_headers_sha256': table_hash.hexdigest()})
        end = start
    require(bool(streams) and streams[-1]['offset'] == 0, 'XZ stream missing at file start')
    dictionaries = [row['dictionary_bytes'] for row in chain_info.values()]
    memories = [row['decoder_memory_bytes'] for row in chain_info.values()]
    result = {'streams': list(reversed(streams)), 'block_count': total_blocks,
              'filter_chains': [chain_info[k] for k in sorted(chain_info)],
              'max_dictionary_bytes': max(dictionaries, default=0),
              'max_decoder_memory_bytes': max(memories, default=0),
              'expected_decoded_bytes': sum(row['expected_decoded_bytes'] for row in streams)}
    result['within_guard'] = result['max_dictionary_bytes'] <= MAX_DICT and result['max_decoder_memory_bytes'] <= MAX_RAW_MEMORY
    return result


def observe(file, row, check_time):
    before = verify_archive(file, row, check_time)
    decoder = DecoderMemory()
    table = stream_header_table(file, row['bytes'], decoder, check_time)
    require(stamp(file) == before, 'input changed during metadata checks', 'outer_identity')
    return {**row, **table, 'liblzma_version_number': decoder.version}, before


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, default=DEFAULT_OUT)
    args = parser.parse_args()
    require(args.out.is_absolute() and args.out.parent.resolve() == args.out.parent,
            'output needs canonical existing parent', 'output_path')
    soft, hard = resource.getrlimit(resource.RLIMIT_AS)
    cap = min(item for item in (256 * MIB, soft, hard) if item != resource.RLIM_INFINITY)
    resource.setrlimit(resource.RLIMIT_AS, (cap, hard))
    args.out.mkdir(mode=0o700, exist_ok=False)
    deadline = time.monotonic() + 45
    def check_time():
        require(time.monotonic() < deadline, 'XZ metadata deadline reached', 'deadline')

    observations = {}
    for name, row in ALLOWED.items():
        try:
            with open_regular(row['path']) as file:
                result, _ = observe(file, row, check_time)
            observations[name] = {'status': 'verified_metadata', **result}
        except (OSError, PreflightError) as exc:
            observations[name] = {'status': 'partial', **row, 'boundary': getattr(exc, 'kind', 'input_io'),
                                  'detail': str(exc)[:400]}
    envelope = {'phase': 'xz-memory-preflight', 'regions': observations, 'payload_decoded': False,
                'guard': {'dictionary_bytes': MAX_DICT, 'decoder_memory_bytes': MAX_RAW_MEMORY}}
    data = canonical(envelope)
    with (args.out / 'xz-memory-plan.json').open('xb') as output:
        output.write(data)
    print(data.decode(), end='')
    print(f'XZ_MEMORY_PLAN {len(data)} {sha256(data)}')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
