#!/usr/bin/env python3
"""Inspect only remaining, hash-bound JSON fields in a previously read rescue TAR."""
import argparse
import base64
import gzip
import hashlib
import json
import lzma
from pathlib import Path
import re
import resource
import struct
import sys
import tarfile
from types import ModuleType

RUNNER = Path('/workspace/p34-recovery-runner-20261126')
ROOT = Path('/workspace/p34-recovery-delta-20261126')
V2_SHA = '1b9d8c716f3c710f12e51931ccd26de64e83926ca3f6319d30b5a5dd7c35cf19'
PLANS = {
    'priority': ('priority-field-plan.json', 'a5f9fedf190e1887d55d87acbb2c87fb6c040916024c37d34c4f8f6d474f45ae',
                 'priority-exact-fields'),
    'receipts': ('receipts-export-plan.json', '4ee5a3ef6ce95b31c8a6f68a9f56fad204bacddfe9c96f62bcb45e9442604155',
                 'receipts-git-exports'),
}
NAME = re.compile(r'[0-9a-f]{64}\Z')
REFERENCE = re.compile(rb'[/A-Za-z0-9_./-]+\.(?:b64|base64|zip|tar|gz|xz|lean|json)\Z')
SCALAR_ENCODINGS = {'uint8', 'uint16 little-endian'}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def canonical(data):
    return (json.dumps(data, sort_keys=True, separators=(',', ':')) + '\n').encode()


def read_pinned(path, expected, maximum):
    with Path(path).open('rb') as src:
        raw = src.read(maximum + 1)
    if len(raw) > maximum or sha(raw) != expected:
        raise ValueError(f'input changed: {path}')
    return raw


def load_v2(home):
    path = home / 'recover_unread_xz.py'
    raw = read_pinned(path, V2_SHA, 70_000)
    module = ModuleType('rescue_v2_for_fields')
    module.__file__ = str(path)
    exec(compile(raw, str(path), 'exec'), module.__dict__)
    return module


def encoding_value(parent):
    return [value for key, value in parent if key.lower() == 'encoding' and isinstance(value, str)]


def get_at(base, root, path):
    value = root
    parent = None
    for step in path:
        parent = value
        if isinstance(parent, base.JsonObject):
            matches = [entry for key, entry in parent if key == step]
            base.limit(len(matches) != 1, 'field_shape', f'expected exactly one {step} key')
            value = matches[0]
        elif isinstance(parent, list) and step.isdecimal() and int(step) < len(parent):
            value = parent[int(step)]
        else:
            raise base.Boundary('field_shape', f'field path component {step} is unavailable')
    return parent, value


def escaped_json(raw, expected, pairs):
    text = raw.decode('utf-8-sig')
    original = []
    while len(original) <= 32:
        try:
            value = json.loads(text, object_pairs_hook=pairs)
            if not original:
                raise ValueError('the pinned invalid-escape observation did not reproduce')
            return value, original
        except json.JSONDecodeError as exc:
            if not original and str(exc) != expected:
                raise
            if exc.msg != 'Invalid \\escape' or text[exc.pos:exc.pos + 1] != '\\' or len(original) == 32:
                raise
            original.append({'offset_from_decoded_utf8': exc.pos - len(original),
                             'line': exc.lineno, 'column_at_parse': exc.colno})
            text = text[:exc.pos] + '\\' + text[exc.pos:]
    raise ValueError('invalid-escape repair count exceeded')


def header_metadata(raw):
    if raw.startswith(b'PACK') and len(raw) >= 12:
        version, count = struct.unpack('>II', raw[4:12])
        return {'subtype': 'git_pack', 'header_base64': base64.b64encode(raw[:12]).decode('ascii'),
                'pack_version_from_header': version, 'pack_declared_object_count': count,
                'pack_offset': 0}
    if raw.startswith((b'# v2 git bundle', b'# v3 git bundle')):
        sep = raw.find(b'\n\n', 0, 64 << 10)
        header = raw[:sep + 2] if sep >= 0 else raw[: min(len(raw), 512)]
        pack_offset = sep + 2 if sep >= 0 and raw[sep + 2:sep + 6] == b'PACK' else None
        return {'subtype': 'git_bundle_v' + chr(raw[3]),
                'header_base64': base64.b64encode(header).decode('ascii'),
                'header_terminator_observed': sep >= 0, 'pack_offset': pack_offset}
    return {'subtype': 'unrecognized_git_magic', 'prefix_base64': base64.b64encode(raw[:32]).decode('ascii')}


def fields_scanner(base, v2, preflight):
    Parent = v2.scanner_class(base, preflight)
    base.MAX_JSON_VALUES = 1_000_000

    class PinnedOneStream(base.StrictCompressed):
        def __init__(self, source, required):
            super().__init__(source, 'xz')
            self.required = required

        def start_member(self):
            if self.members:
                self.done = True
                return
            self.pending = self.pending or self.source.read(base.CHUNK)
            if not self.pending:
                raise EOFError('verified XZ source supplied no bytes')
            self.decoder = lzma.LZMADecompressor(format=lzma.FORMAT_XZ, memlimit=self.required)

    class Fields(Parent):
        def __init__(self, data, extra, inventory, seconds):
            super().__init__(data, extra, inventory, seconds, 4 << 30)
            self.field_count = 0
            self.selected_members = 0
            self.exports = []

        def statement(self, loc, classification, raw, **facts):
            self.counts[classification] += 1
            self.event('field_inspection', loc, classification=classification, value_bytes=len(raw),
                       value_sha256=sha(raw), **facts)

        def try_unlabelled_b64(self, location, raw):
            compact = base.SPACE.sub(b'', raw)
            if not compact or len(compact) > base.MAX_ENCODED or not base.B64.fullmatch(compact):
                return False
            try:
                result = base.decode_encoded(compact, 'base64')
            except (ValueError, base.binascii.Error):
                return False
            if len(result) not in self.target_sizes and base.codec(result[:512], '') is None:
                return False
            self.charge(len(result))
            self.visit_bytes(base.joined(location, 'base64-alternative'), '', result, 3)
            return True

        def selected_field(self, member, parsed, entry):
            operation = entry['operation']
            path = entry['field_path']
            location = member
            for step in path:
                location = base.joined(location, step)
            if operation == 'invalid_escape_document':
                value, offsets = escaped_json(parsed, entry['old_boundary']['detail'], base.JsonObject)
                self.statement(location, 'literal_backslash_parse_recovery', parsed, invalid_escape_offsets=offsets)
                self.json_walk(location, value, 2)
                return
            parent, value = get_at(base, parsed, path)
            base.limit(not isinstance(value, str), 'field_shape', 'selected value is not a string')
            raw = value.encode('utf-8', 'surrogatepass')
            base.limit(len(raw) > base.MAX_ENCODED, 'field_size_limit', 'selected string exceeds 16 MiB')
            self.check_target(location, raw, name=path[-1])
            if operation in ('base64_file', 'declared_base64_value'):
                if operation == 'base64_file' and len(raw) < 1024 and REFERENCE.fullmatch(raw):
                    pointers = {}
                    if isinstance(parent, base.JsonObject):
                        for key, item in parent:
                            if key in ('base64_sha256', 'archive_sha256', 'decoded_sha256', 'sha256', 'tar_sha256'):
                                if isinstance(item, str) and NAME.fullmatch(item):
                                    pointers.setdefault(key, []).append(item)
                    self.statement(location, 'base64_file_reference_metadata', raw, reference=value,
                                   sibling_digest_fields=pointers)
                    return
                compact = base.SPACE.sub(b'', raw)
                if not compact:
                    self.statement(location, 'valid_empty_base64', raw, decoded_bytes=0)
                    return
                decoded = base.decode_encoded(compact, 'base64')
                self.statement(location, 'declared_base64_decoded', raw,
                               decoded_bytes=len(decoded), decoded_sha256=sha(decoded))
                self.charge(len(decoded))
                self.visit_bytes(base.joined(location, 'decoded-payload'), '', decoded, 3)
                return
            if operation in ('transcription_formula', 'wire_scalar_source'):
                base.limit(not isinstance(parent, base.JsonObject), 'field_shape', 'selected value is outside object')
                hints = encoding_value(parent)
                base.limit(len(hints) != 1, 'field_shape', 'selected object lacks a unique encoding field')
                normal = hints[0].lower()
                if operation == 'transcription_formula':
                    base.limit('unknown payload encoding ' + normal[:120] != self.plan['earlier_formula_detail'],
                               'formula_identity', 'case-normalized schema formula differs from original observation')
                    classification = 'transcription_formula_metadata'
                else:
                    base.limit(normal not in SCALAR_ENCODINGS or
                               'unknown payload encoding ' + normal != entry['old_boundary']['detail'],
                               'wire_schema_identity', 'selected scalar schema differs from original observation')
                    classification = 'wire_scalar_layout_metadata'
                wrapper = self.encoded_string(location, raw, 2)
                self.statement(location, classification, raw, recognized_wrapper=wrapper,
                               sibling_encoding_sha256=sha(hints[0].encode()))
                return
            if operation == 'inferred_odd_hex':
                compact = base.SPACE.sub(b'', raw)
                base.limit(path[-1].lower() in base.PAYLOAD_FIELDS or base.ENCODING.search(path[-1]),
                           'field_shape', 'an explicit encoding selector requires separate verification')
                base.limit(not compact or not base.HEX.fullmatch(compact) or not len(compact) % 2,
                           'odd_hex_identity', 'the inferred odd-hex condition did not reproduce')
                alternative = self.try_unlabelled_b64(location, raw)
                self.statement(location, 'unlabelled_odd_hex_probe_rejected', raw,
                               supported_base64_candidate=alternative)
                return
            raise base.Boundary('unsupported_selected_operation', operation)

        def inspect_member(self, file, row):
            head = row['member']
            name = head['member_name']
            self.selected_members += 1
            maximum = min(head['bytes'], base.MAX_JSON)
            base.limit(not NAME.fullmatch(name) or head['bytes'] > maximum,
                       'selected_member_size_or_name', 'selected JSON member outside size or CAS rules')
            raw = base.read_limit(file, maximum, 'selected_json_member_limit')
            base.limit(len(raw) != head['bytes'] or sha(raw) != name,
                       'selected_member_identity', 'selected JSON member failed exact size/digest')
            root = head['location']
            choices = row['selections']
            if len(choices) == 1 and choices[0]['operation'] == 'git_export':
                self.field_count += 1
                header = header_metadata(raw)
                self.exports.append(({'ordinal': head['ordinal'], 'offset': head['offset'],
                                      'name': name, 'sha256': name, 'bytes': len(raw),
                                      'location': root, **header}, raw))
                self.event('git_payload_identity_exported', root, ordinal=head['ordinal'], offset=head['offset'],
                           sha256=name, bytes=len(raw), subtype=header['subtype'])
                if header['subtype'] == 'unrecognized_git_magic':
                    self.boundary(root, 'git_magic_unrecognized', 'retained Git detection did not reproduce')
                return
            is_document = all(x['operation'] == 'invalid_escape_document' for x in choices)
            parsed = raw if is_document else json.loads(raw, object_pairs_hook=base.JsonObject)
            for entry in choices:
                self.field_count += 1
                at = root
                for part in entry['field_path']:
                    at = base.joined(at, part)
                self.attempt(at, lambda: self.selected_field(root, parsed, entry))
            self.event('selected_member_fields_processed', root, fields=len(choices), bytes=len(raw), sha256=name)

        def original_regions(self, plan, approved):
            self.plan = plan
            self.region = plan['phase']

            def inspect(location, source, identity):
                decoder = preflight.DecoderMemory()
                measured = {**plan['archive'],
                            **preflight.stream_header_table(source, identity['bytes'], decoder, self.check_time),
                            'liblzma_version_number': decoder.version, 'status': 'verified_metadata'}
                base.limit(preflight.canonical(measured) != preflight.canonical(approved)
                           or measured['block_count'] != 1 or len(measured['streams']) != 1
                           or not measured['within_guard'], 'xz_preflight_plan_mismatch', 'reused XZ metadata differs')
                source.seek(0)
                expanded = base.Meter(PinnedOneStream(base.Meter(source, self), measured['max_decoder_memory_bytes']),
                                      self, expanded=True)
                wanted = {row['member']['ordinal']: row for row in plan['only_members']}
                base.limit(len(wanted) != len(plan['only_members']) or len(wanted) > 128,
                           'selected_members_outside_scope', 'selected member count exceeded')
                highest = max(wanted)
                observed = set()
                with tarfile.open(fileobj=expanded, mode='r|', tarinfo=base.BoundedTarInfo, bufsize=base.CHUNK) as archive:
                    for ordinal, member in enumerate(archive, 1):
                        self.check_time()
                        if ordinal not in wanted:
                            if ordinal > highest:
                                break
                            continue
                        row = wanted[ordinal]
                        head = row['member']
                        base.limit((member.name, member.size, member.offset_data, member.type) !=
                                   (head['member_name'], head['bytes'], head['offset'], tarfile.REGTYPE)
                                   or not base.valid_member(member.name) or member.sparse,
                                   'selected_tar_header_mismatch', 'selected member header changed')
                        with archive.extractfile(member) as entry:
                            self.attempt(head['location'], lambda: self.inspect_member(entry, row))
                        observed.add(ordinal)
                        if ordinal == highest:
                            break
                base.limit(observed != set(wanted), 'selected_member_missing', 'selected member was not observed')
                self.event('prior_eof_identity_reused', location, prior_inner_tar=plan['verified_prior_inner_tar'],
                           selected_through_ordinal=highest, freshly_verified_outer_sha256=identity['sha256'])

            self.run_region(self.region, plan['archive'], inspect)
            if self.field_count != plan['selection_count']:
                self.boundary(plan['archive']['path'], 'selection_count_mismatch',
                              f'completed {self.field_count} of {plan["selection_count"]} declared field attempts')

    return Fields


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--phase', choices=tuple(PLANS), required=True)
    cli.add_argument('--runner', type=Path, default=RUNNER)
    cli.add_argument('--out', type=Path)
    cli.add_argument('--seconds', type=int, default=600)
    cli.add_argument('--emit-stdout', action='store_true')
    args = cli.parse_args()
    plan_name, plan_sha, output_name = PLANS[args.phase]
    args.out = args.out or ROOT / output_name
    if not 1 <= args.seconds <= 1200 or not args.out.is_absolute() or args.out.parent.resolve() != args.out.parent:
        raise ValueError('time or output path outside supported bounds')
    home = args.runner / 'repair-v2'
    v2 = load_v2(home)
    base = v2.load_checked_module(args.runner / 'recover_archive_delta.py', v2.BASE_SCANNER_SHA, 'field_base')
    preflight = v2.load_checked_module(home / 'xz_memory_preflight.py', v2.PREFLIGHT_SCANNER_SHA, 'field_xz')
    data = json.loads(read_pinned(args.runner / 'allowlist.json', v2.BASE_ALLOWLIST_SHA, 256 << 10))
    extra = json.loads(read_pinned(home / 'repair-allowlist-v2.json', v2.REPAIR_ALLOWLIST_SHA, 48 << 10))
    plan = json.loads(read_pinned(Path(__file__).with_name(plan_name), plan_sha, 48 << 10))
    rows = json.loads(read_pinned(v2.PREFLIGHT_PLAN, v2.PREFLIGHT_PLAN_SHA, 4096))
    approved = v2.metadata_for('rescue-' + plan['phase'], rows)
    if (plan['archive'] != data['input'][plan['phase']] or plan['archive'] != preflight.ALLOWED[plan['phase']]
            or plan['verified_prior_inner_tar']['integrity'] != 'verified_eof'):
        raise ValueError('archive or prior EOF scope did not match pinned inputs')
    soft, hard = resource.getrlimit(resource.RLIMIT_AS)
    cap = min(k for k in (base.MAX_ADDRESS, soft, hard) if k != resource.RLIM_INFINITY)
    resource.setrlimit(resource.RLIMIT_AS, (cap, hard))
    args.out.mkdir(mode=0o700, exist_ok=False)
    receipt = args.out / 'member-inventory.jsonl.gz'
    stop = None
    with gzip.open(receipt, 'xt', encoding='utf-8', compresslevel=4) as inventory:
        scanner = fields_scanner(base, v2, preflight)(data, extra, inventory, args.seconds)
        try:
            scanner.original_regions(plan, approved)
        except base.Boundary as exc:
            stop = {'kind': exc.kind, 'detail': str(exc)}
        except preflight.PreflightError as exc:
            scanner.boundary(plan['archive']['path'], exc.kind, exc)
    exact = []
    for target in scanner.targets:
        name = target['filename']
        match = scanner.matches.get(name)
        if match is None:
            continue
        if len(match) != target['bytes'] or sha(match) != target['sha256'] or '/' in name or not base.valid_member(name):
            raise ValueError('target source failed exact identity')
        with (args.out / name).open('xb') as output:
            output.write(match)
        exact.append({'filename': name, 'bytes': len(match), 'sha256': sha(match),
                      'locations': scanner.match_locations[name][:60],
                      'base64': base64.b64encode(match).decode('ascii')})
    exports = []
    for evidence, raw in scanner.exports:
        if not NAME.fullmatch(evidence['sha256']) or len(raw) != evidence['bytes'] or sha(raw) != evidence['sha256']:
            raise ValueError('Git body failed exact export verification')
        filename = f'{evidence["ordinal"]}-{evidence["sha256"]}.git-payload'
        with (args.out / filename).open('xb') as output:
            output.write(raw)
        exports.append({**evidence, 'filename': filename, 'base64': base64.b64encode(raw).decode('ascii')})
    receipt_raw = receipt.read_bytes()
    completed = 'bounded_fields_complete' if args.phase == 'priority' else 'git_transport_exports_verified'
    scope = {
        'priority': 'Exact retained unresolved fields and one malformed JSON document.',
        'receipts': 'Only the two unique Git payload bodies and header/subtype metadata. Git packs remain undecoded.',
    }[args.phase]
    result = {
        'phase': output_name, 'status': 'partial' if stop or scanner.boundaries else completed,
        'plan_sha256': plan_sha, 'prior_v3_result_gzip': plan['v3_result_gzip'],
        'scope': scope + ' Transport prefixes are inflated for selection. Prior archive EOF is reused.',
        'git_exports': exports,
        'field_attempts': scanner.field_count, 'selected_members_read': scanner.selected_members,
        'counts': dict(scanner.counts), 'boundary_counts': dict(scanner.boundaries),
        'boundary_sample': scanner.limits_sample, 'stop': stop,
        'exact_matches': exact, 'decoded_bytes_charged_including_transport': scanner.expanded,
        'inventory': {'path': str(receipt), 'bytes': len(receipt_raw), 'sha256': sha(receipt_raw)},
    }
    packed = gzip.compress(canonical(result), mtime=0)
    with (args.out / 'result.json.gz').open('xb') as output:
        output.write(packed)
    print(json.dumps({'phase': result['phase'], 'status': result['status'], 'fields': result['field_attempts'],
                      'members': result['selected_members_read'], 'boundary_counts': result['boundary_counts'],
                      'targets_found': [row['filename'] for row in exact],
                      'git_exports': [{k: row[k] for k in ('bytes', 'sha256', 'ordinal', 'subtype')} for row in exports],
                      'result_bytes': len(packed), 'result_sha256': sha(packed)}), flush=True)
    if args.emit_stdout:
        transport = base64.b64encode(packed).decode('ascii')
        for index, start in enumerate(range(0, len(transport), 4096)):
            print(f'DELTA_RESULT_GZIP_BASE64 {index:05d} {transport[start:start + 4096]}')
        print(f'DELTA_RESULT_END {len(transport)} {sha(packed)}', flush=True)
    return 2 if stop else 0


if __name__ == '__main__':
    sys.exit(main())
