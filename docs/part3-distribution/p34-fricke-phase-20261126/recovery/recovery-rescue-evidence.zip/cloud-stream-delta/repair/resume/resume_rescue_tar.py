#!/usr/bin/env python3
"""Continue two source CAS TARs after their verified partial prefix receipts."""
import argparse
import base64
from collections import Counter
from contextlib import contextmanager
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import resource
import sys
import tarfile
from types import ModuleType

RUNNER = Path('/workspace/p34-recovery-runner-20261126')
ROOT = Path('/workspace/p34-recovery-delta-20261126')
PLAN_SHA = 'dc05866918b65ba1e6e558fa9730af810b5ed751b643d7c432411abaaebae74a'
V2_SHA = '1b9d8c716f3c710f12e51931ccd26de64e83926ca3f6319d30b5a5dd7c35cf19'
MAX_NODES = 32_000_000
MAX_MEMBER_NODES = 2_000_000
MAX_RECEIPT_RAW = 32 << 20
NAME = re.compile(r'[0-9a-f]{64}\Z')
REFERENCE = re.compile(rb'[/A-Za-z0-9_./-]+\.(?:b64|base64|zip|gz|xz|lean|json)\Z')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def canonical(data):
    return (json.dumps(data, sort_keys=True, separators=(',', ':')) + '\n').encode()


def read_pinned(path, value, cap, expected_size=None):
    with Path(path).open('rb') as source:
        raw = source.read(cap + 1)
    if len(raw) > cap or sha(raw) != value or (expected_size is not None and len(raw) != expected_size):
        raise ValueError(f'pinned input changed: {path}')
    return raw


def load_v2(home):
    path = home / 'recover_unread_xz.py'
    raw = read_pinned(path, V2_SHA, 70_000)
    module = ModuleType('rescue_v2')
    module.__file__ = str(path)
    exec(compile(raw, str(path), 'exec'), module.__dict__)
    return module


def bind_cloud_prefixes(plan):
    seen = set()
    coverage = {}
    for name, observations in plan['regions'].items():
        root = ROOT / f'rescue-{name}'
        for filename, key in (('result.json.gz', 'result_gzip'), ('member-inventory.jsonl.gz', 'inventory_gzip')):
            pin = observations[key]
            raw = read_pinned(root / filename, pin['sha256'], 2 << 20, pin['bytes'])
            if key == 'result_gzip':
                report = json.loads(gzip.decompress(raw))
                if (report['phase'], report['stop']['kind'], report['counts']['json_values']) != (
                        f'rescue-{name}', 'json_value_count_limit', 8_000_001):
                    raise ValueError(f'prior result semantics changed for {name}')
            else:
                fingerprints = set()
                checked_count = 0
                decoded = 0
                with gzip.GzipFile(fileobj=io.BytesIO(raw)) as receipt:
                    for line in receipt:
                        decoded += len(line)
                        if decoded > MAX_RECEIPT_RAW:
                            raise ValueError('prior receipt expansion exceeds guard')
                        item = json.loads(line)
                        if item['kind'] == 'member_payload' and item['status'] == 'checked':
                            fingerprints.add((item['bytes'], item['sha256']))
                            checked_count += 1
                if (len(fingerprints) != observations['unique_checked_identity_count']
                        or checked_count != observations['checked_payload_count']
                        or sha(canonical(sorted(fingerprints))) != observations['unique_checked_identities_sha256']):
                    raise ValueError(f'prior checked member roster changed for {name}')
                seen.update(fingerprints)
                coverage[name] = {'checked_receipt_count': checked_count, 'distinct_fingerprints': len(fingerprints),
                                  'prior_inventory_sha256': pin['sha256']}
    return seen, coverage


def node_scope(base, v2, preflight, node_cap):
    prior_class = v2.scanner_class(base, preflight)
    base.MAX_JSON_VALUES = node_cap + MAX_MEMBER_NODES

    class ResumeScan(prior_class):
        def __init__(self, data, extra, inventory, seconds, expansion, plan, name, seen, window=None):
            super().__init__(data, extra, inventory, seconds, expansion)
            self.plan = plan
            self.region_name = name
            self.archive = plan['regions'][name]
            self.cursor = window or self.archive['cutoff']
            self.initial_region = window is None
            self.earlier = {r['member']['ordinal']: r for r in self.archive['exact_earlier_field_inspections']
                            if self.initial_region}
            self.excluded_cas = seen
            self.current_tar_member = None
            self.member_nodes = 0
            self.documents = []
            self.node_windows = []
            self.next_member = None
            self.expected_tar = self.archive['cutoff']['location'].rsplit('!', 1)[0]

        @contextmanager
        def member_context(self, header):
            self.current_tar_member = header
            self.member_nodes = 0
            try:
                yield
            finally:
                self.current_tar_member = None

        def json_document(self, loc, raw, depth, allow_jsonl):
            doc = {'location': loc, 'bytes': len(raw), 'sha256': sha(raw), 'node_position': 0}
            self.documents.append(doc)
            try:
                if not allow_jsonl:
                    super().json_document(loc, raw, depth, False)
                    return
                try:
                    parsed = json.loads(raw, object_pairs_hook=base.JsonObject)
                except UnicodeDecodeError:
                    self.counts['anonymous_non_utf8_json_probe_rejected'] += 1
                    return
                except json.JSONDecodeError as exc:
                    if exc.msg == 'Extra data':
                        # Consider each intact physical line independently. An
                        # inferred document is different from a named .jsonl.
                        self.text_lines(loc, io.BytesIO(raw), depth)
                    else:
                        self.boundary(loc, 'anonymous_json_syntax', exc)
                    return
                self.json_walk(loc, parsed, depth)
            finally:
                self.documents.pop()

        def text_lines(self, loc, stream, depth):
            for at, line in self.line_records(loc, stream, base.MAX_JSON_LINE):
                self.check_target(at, line)
                bare = line.removesuffix(b'\n').removesuffix(b'\r')
                if bare != line:
                    self.check_target(at, bare)
                if v2.plausible_json(bare[:512]):
                    try:
                        parsed = json.loads(bare, object_pairs_hook=base.JsonObject)
                    except (UnicodeDecodeError, json.JSONDecodeError):
                        self.counts['anonymous_line_json_probe_rejected'] += 1
                    else:
                        self.documents.append({'location': at, 'bytes': len(bare), 'sha256': sha(bare), 'node_position': 0})
                        try:
                            self.json_walk(at, parsed, depth)
                        finally:
                            self.documents.pop()
                        continue
                if len(bare) >= min(self.target_sizes) or bare.startswith(b'data:'):
                    self.attempt(at, lambda: self.encoded_string(at, bare, depth))

        def json_walk(self, loc, value, depth, nesting=0, key='', hints=()):
            self.member_nodes += 1
            if self.documents:
                self.documents[-1]['node_position'] += 1
            if self.member_nodes > MAX_MEMBER_NODES:
                boundary = {'member': self.current_tar_member, 'first_unvisited_location': loc,
                            'member_node_position': self.member_nodes,
                            'document_cursors': [dict(doc) for doc in self.documents],
                            'nested_depth': depth, 'json_depth': nesting}
                if self.member_nodes == MAX_MEMBER_NODES + 1:
                    self.node_windows.append(boundary)
                    self.event('json_member_resume_cursor', loc, **boundary)
                raise base.Boundary('json_member_node_cap', f'archive member reached {MAX_MEMBER_NODES} JSON nodes', True)
            super().json_walk(loc, value, depth, nesting, key, hints)

        def declared_field(self, at, source, selected):
            raw = base.read_limit(source, base.MAX_JSON, 'prior_field_json_bytes')
            base.limit(sha(raw) != selected['payload_sha256'], 'prior_field_identity',
                       'selected earlier JSON member no longer has its verified identity')
            value = json.loads(raw, object_pairs_hook=base.JsonObject)
            parent = value
            parts = selected['field_path']
            for key in parts:
                base.limit(not isinstance(value, base.JsonObject), 'prior_field_shape', 'expected JSON object')
                matches = [item for label, item in value if label == key]
                base.limit(len(matches) != 1, 'prior_field_shape', f'expected exactly one {key} field')
                parent, value = value, matches[0]
            base.limit(not isinstance(value, str), 'prior_field_shape', 'selected field is not a string')
            content = value.encode('utf-8', 'surrogatepass')
            location = at
            for part in parts:
                location = base.joined(location, part)
            result = {'member_sha256': selected['payload_sha256'], 'field_path': parts,
                      'value_bytes': len(content), 'value_sha256': sha(content)}
            if parts == ['base64_file']:
                if REFERENCE.fullmatch(content) and len(content) < 1024:
                    self.event('resolved_prior_field', location, classification='file_reference_metadata',
                               reference=value, **result)
                else:
                    try:
                        base.decode_encoded(content, 'base64')
                    except (ValueError, base.binascii.Error) as exc:
                        self.event('unresolved_prior_field', location, classification='non_reference_invalid_base64',
                                   **result)
                        self.boundary(location, 'declared_base64_invalid', exc)
                    else:
                        self.encoded_string(location, content, 2, 'base64')
                return
            encodings = [item for label, item in parent if label == 'encoding']
            base.limit(len(encodings) != 1 or not isinstance(encodings[0], str) or
                       'unknown payload encoding ' + encodings[0][:120] != selected['old_detail'],
                       'prior_field_shape', 'recorded formula did not match the selected sibling value')
            discovered = self.encoded_string(location, content, 2)
            self.event('resolved_prior_field', location, classification='transcription_formula_is_not_byte_codec',
                       supported_wrapper_discovered=discovered, formula_sha256=sha(encodings[0].encode()), **result)

        def member_header(self, parent, ordinal, member):
            location = base.joined(parent, f'{ordinal}:{member.name}')
            return {'kind': 'tar_header', 'region': self.region, 'location': location, 'ordinal': ordinal,
                    'member_name': member.name, 'bytes': member.size, 'offset': member.offset_data,
                    'type': member.type.decode('ascii', 'replace')}

        def selected_members(self, parent, stream):
            selected = set()
            with tarfile.open(fileobj=stream, mode='r|', tarinfo=base.BoundedTarInfo, bufsize=base.CHUNK) as arc:
                for ordinal, member in enumerate(arc, 1):
                    self.check_time()
                    if ordinal < self.cursor['ordinal'] and ordinal not in self.earlier:
                        self.counts['closed_prefix_headers_passed'] += 1
                        continue
                    header = self.member_header(parent, ordinal, member)
                    at = header['location']
                    self.member_count()
                    self.event('tar_header', at, **{k: header[k] for k in ('ordinal', 'member_name', 'bytes', 'offset', 'type')})
                    base.limit(member.size < 0 or member.offset_data + member.size > (1 << 63) - 1,
                               'tar_member_bounds', 'invalid TAR member extent')
                    if ordinal == self.cursor['ordinal']:
                        base.limit(header != self.cursor, 'prefix_cursor_mismatch', 'retained cursor header did not match transport')
                        self.event('resume_tar_cutoff', at, previous_json_node_cursor='unrecorded' if self.initial_region else None,
                                   operation='partial_member_provenance_replay' if self.initial_region else 'first_unopened_member')
                        selected.add(ordinal)
                    if ordinal in self.earlier:
                        early = self.earlier[ordinal]
                        base.limit(header != early['member'], 'prior_field_cursor_mismatch', 'retained earlier field header did not match')
                        selected.add(ordinal)
                        try:
                            with self.member_context(header), arc.extractfile(member) as source:
                                self.attempt(at, lambda: self.declared_field(at, source, early))
                        except base.Boundary as exc:
                            if exc.kind != 'json_member_node_cap':
                                raise
                        continue
                    if self.counts['json_values'] >= node_cap:
                        self.next_member = header
                        self.event('next_unopened_tar_member', at, header=header, scanned_json_values=self.counts['json_values'])
                        raise base.Boundary('json_job_node_window', 'job node window finished at a TAR member boundary', True)
                    if (not base.valid_member(member.name) or member.type not in
                            (tarfile.REGTYPE, tarfile.AREGTYPE, tarfile.CONTTYPE) or member.sparse):
                        if not member.isdir():
                            self.boundary(at, 'unsafe_or_nonregular_tar_member', 'TAR member was excluded by type/path guard')
                        continue
                    with self.member_context(header), arc.extractfile(member) as source:
                        meter = base.Meter(source, self, member.size)
                        expected = (member.size, member.name)
                        if ordinal == self.cursor['ordinal'] and self.initial_region:
                            # The old member's full raw read precedes its interrupted JSON traversal.
                            # Verify its CAS identity before any supplemental target processing.
                            raw = base.read_limit(meter, base.MAX_JSON, 'partial_cutoff_member_bytes')
                            identity = meter.finish()
                            base.limit(identity['sha256'] != member.name, 'partial_cutoff_identity', 'CAS digest mismatch')
                            visit = lambda: self.visit(at, member.name, io.BytesIO(raw), 2, member.size, path=member.name)
                        elif NAME.fullmatch(member.name) and expected in self.excluded_cas:
                            identity = meter.finish()
                            if identity['sha256'] == member.name:
                                self.exclude(at, identity, 'verified_prior_cas_payload_excluded')
                                continue
                            self.boundary(at, 'content_address_mismatch', 'prior CAS label disagreed with new member bytes')
                            continue
                        else:
                            visit = lambda: self.visit(at, base.name_of(member.name), meter, 2, member.size, path=member.name)
                        try:
                            ok = self.attempt(at, visit)
                        except base.Boundary as exc:
                            if exc.kind != 'json_member_node_cap':
                                raise
                            ok = False
                        identity = meter.finish()
                        if NAME.fullmatch(member.name) and identity['sha256'] != member.name:
                            self.boundary(at, 'content_address_mismatch', 'CAS label disagrees with SHA-256 of actual bytes')
                            ok = False
                        kind = 'prior_cutoff_supplement' if ordinal == self.cursor['ordinal'] and self.initial_region else 'new_payload'
                        self.event('member_payload', at, status='checked' if ok else 'partial', source_region=kind, **identity)
                        if ok:
                            self.last_completed_member[self.region] = at
                            if NAME.fullmatch(member.name):
                                self.excluded_cas.add((identity['bytes'], identity['sha256']))
                base.limit(not arc._delta_end or arc.fileobj.read(512) != bytes(512),
                           'tar_end_marker', 'missing TAR end block')
                while True:
                    tail = arc.fileobj.read(base.CHUNK)
                    if not tail:
                        break
                    base.limit(any(tail), 'tar_nonzero_tail', 'nonzero TAR trailing bytes')
                base.limit(selected != {self.cursor['ordinal'], *self.earlier}, 'missing_delta_header',
                           f'missing declared cursor or earlier field header, observed {sorted(selected)}')

        def tar(self, location, stream, depth, selected=None, snapshot=None):
            if location == self.expected_tar:
                self.selected_members(location, stream)
            else:
                super().tar(location, stream, depth, selected, snapshot)

    return ResumeScan


def completed_windows(arguments, name, plan, initial_seen):
    start = plan['regions'][name]['cutoff']
    cursor = None
    history = []
    for spec in arguments:
        pointer, separator, pinned = spec.rpartition('@')
        path = Path(pointer)
        if (not separator or not NAME.fullmatch(pinned) or not path.is_absolute()
                or ROOT not in path.parents or path != path.resolve() or path.name != 'result.json.gz'):
            raise ValueError('window must be an absolute prior result under recovery root followed by @SHA256')
        raw = read_pinned(path, pinned, 2 << 20)
        report = json.loads(gzip.decompress(raw))
        if (report['phase'], report['resume_plan_sha256'], report['start_member']) != (name, PLAN_SHA, start):
            raise ValueError('prior window is unrelated or not contiguous')
        if report['stop']['kind'] != 'json_job_node_window' or not report.get('next_unopened_member'):
            raise ValueError('prior window did not stop before an unopened member')
        cursor = report['next_unopened_member']
        if cursor['ordinal'] <= start['ordinal']:
            raise ValueError('prior window did not advance')
        pin = report['inventory']
        inv_path = path.with_name('member-inventory.jsonl.gz')
        if Path(pin['path']) != inv_path:
            raise ValueError('prior window inventory path mismatch')
        packed = read_pinned(inv_path, pin['sha256'], 8 << 20, pin['bytes'])
        with gzip.GzipFile(fileobj=io.BytesIO(packed)) as inventory:
            decoded_bytes = 0
            for line in inventory:
                decoded_bytes += len(line)
                if decoded_bytes > MAX_RECEIPT_RAW:
                    raise ValueError('previous window inventory expansion cap reached')
                row = json.loads(line)
                if row['kind'] == 'member_payload' and row['status'] == 'checked':
                    candidate = row['location'].rsplit(':', 1)[-1]
                    if candidate == row['sha256']:
                        initial_seen.add((row['bytes'], row['sha256']))
        history.append({'result_sha256': pinned, 'inventory_sha256': pin['sha256'],
                        'begin_ordinal': start['ordinal'], 'next_ordinal': cursor['ordinal'],
                        'prior_boundaries': report['boundary_counts']})
        start = cursor
    return cursor, history


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--phase', choices=('priority', 'receipts'), required=True)
    parser.add_argument('--runner', type=Path, default=RUNNER)
    parser.add_argument('--out', type=Path)
    parser.add_argument('--seconds', type=int, default=1100)
    parser.add_argument('--node-cap', type=int, default=MAX_NODES)
    parser.add_argument('--completed-window', action='append', default=[], metavar='RESULT@SHA256')
    parser.add_argument('--emit-stdout', action='store_true')
    return parser.parse_args()


def main():
    args = parse_args()
    if not (1 <= args.seconds <= 1800 and 1 <= args.node_cap <= MAX_NODES
            and len(args.completed_window) <= 8):
        raise ValueError('time, JSON node or prior-window count outside allowed range')
    home = args.runner / 'repair-v2'
    v2 = load_v2(home)
    base = v2.load_checked_module(args.runner / 'recover_archive_delta.py', v2.BASE_SCANNER_SHA, 'frozen_rescue_base')
    preflight = v2.load_checked_module(home / 'xz_memory_preflight.py', v2.PREFLIGHT_SCANNER_SHA, 'frozen_xz_reader')
    data = json.loads(read_pinned(args.runner / 'allowlist.json', v2.BASE_ALLOWLIST_SHA, 256 << 10))
    extra = json.loads(read_pinned(home / 'repair-allowlist-v2.json', v2.REPAIR_ALLOWLIST_SHA, 48 << 10))
    primary = v2.metadata_for('rescue-' + args.phase,
                              json.loads(read_pinned(v2.PREFLIGHT_PLAN, v2.PREFLIGHT_PLAN_SHA, 4096)))
    plan = json.loads(read_pinned(Path(__file__).with_name('resume-plan.json'), PLAN_SHA, 16384))
    soft, hard = resource.getrlimit(resource.RLIMIT_AS)
    cap = min(item for item in (base.MAX_ADDRESS, soft, hard) if item != resource.RLIM_INFINITY)
    resource.setrlimit(resource.RLIMIT_AS, (cap, hard))
    seen, prefix = bind_cloud_prefixes(plan)
    cursor, history = completed_windows(args.completed_window, args.phase, plan, seen)
    out = args.out or ROOT / f'resume-{args.phase}'
    if not out.is_absolute() or out.parent.resolve() != out.parent:
        raise ValueError('output requires a safe absolute path with an existing canonical parent')
    out.mkdir(mode=0o700, exist_ok=False)
    inventory_path = out / 'member-inventory.jsonl.gz'
    stop = None
    with gzip.open(inventory_path, 'xt', encoding='utf-8', compresslevel=4) as inventory:
        cls = node_scope(base, v2, preflight, args.node_cap)
        scan = cls(data, extra, inventory, args.seconds, 4 << 30, plan, args.phase, seen, cursor)
        try:
            scan.scan_rescue(args.phase, primary)
        except base.Boundary as exc:
            stop = {'kind': exc.kind, 'detail': str(exc)}
        except preflight.PreflightError as exc:
            scan.boundary(primary['path'], exc.kind, exc)
    exact = []
    for target in scan.targets:
        name = target['filename']
        value = scan.matches.get(name)
        if value is None:
            continue
        if (len(value) != target['bytes'] or sha(value) != target['sha256']
                or '/' in name or not base.valid_member(name) or not name.endswith('.lean')):
            raise ValueError('source failed final identity check')
        with (out / name).open('xb') as source:
            source.write(value)
        exact.append({'filename': name, 'bytes': len(value), 'sha256': sha(value),
                      'locations': scan.match_locations[name][:60],
                      'base64': base64.b64encode(value).decode('ascii')})
    receipt_digest = hashlib.sha256()
    with inventory_path.open('rb') as receipt:
        for block in iter(lambda: receipt.read(base.CHUNK), b''):
            receipt_digest.update(block)
    inventory_sha = receipt_digest.hexdigest()
    finding = {
        'phase': args.phase, 'resume_plan_sha256': PLAN_SHA,
        'status': 'partial' if scan.boundaries or stop else 'delta_complete',
        'regions': scan.regions,
        'start_member': scan.cursor,
        'initial_cutoff_has_unrecorded_old_json_cursor': scan.initial_region,
        'selected_earlier_fields': list(scan.earlier.values()),
        'covered_prior_windows': history, 'verified_prior_prefix_receipts': prefix,
        'next_unopened_member': scan.next_member,
        'member_specific_json_cursors': scan.node_windows,
        'counts': dict(scan.counts), 'boundary_counts': dict(scan.boundaries),
        'boundary_sample': scan.limits_sample, 'last_completed_members': scan.last_completed_member,
        'stop': stop, 'decoded_bytes_charged_including_transport_prefix': scan.expanded,
        'capacity': {'job_json_node_limit_at_member_boundary': args.node_cap,
                     'member_json_node_limit': MAX_MEMBER_NODES, 'expanded_bytes': 4 << 30,
                     'address_space': cap, 'seconds': args.seconds, 'temporary_bytes': 0},
        'exact_matches': exact,
        'inventory': {'path': str(inventory_path), 'bytes': inventory_path.stat().st_size, 'sha256': inventory_sha},
        'scope': ('Prior closed TAR payloads excluded. Original interrupted member supplemental replay reflects '
                  'an unrecorded old JSON node cursor. Only the archive suffix after that member is all-new.'),
    }
    encoded = gzip.compress(canonical(finding), mtime=0)
    with (out / 'result.json.gz').open('xb') as receipt:
        receipt.write(encoded)
    print(json.dumps({'phase': args.phase, 'status': finding['status'], 'new_exact_matches': [r['filename'] for r in exact],
                      'boundaries': finding['boundary_counts'], 'last_completed_members': scan.last_completed_member,
                      'next_unopened_member': scan.next_member, 'decoded_bytes': scan.expanded,
                      'result_bytes': len(encoded), 'result_sha256': sha(encoded), 'stop': stop}), flush=True)
    if args.emit_stdout:
        data = base64.b64encode(encoded).decode('ascii')
        for index, position in enumerate(range(0, len(data), 4096)):
            print(f'DELTA_RESULT_GZIP_BASE64 {index:05d} {data[position:position + 4096]}')
        print(f'DELTA_RESULT_END {len(data)} {sha(encoded)}', flush=True)
    return 2 if stop else 0


if __name__ == '__main__':
    raise SystemExit(main())
