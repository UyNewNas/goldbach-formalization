#!/usr/bin/env python3
"""Bind the exact two stopped TAR regions and two unresolved earlier fields."""
from collections import Counter
import gzip
import hashlib
import json
from pathlib import Path
import re

BASE = Path(__file__).resolve().parent
CONTINUATION = BASE.parents[2]
REGIONS = {
    'priority': {'task': '49951fcfaa584b55a33988cd35988865', 'evidence_size': 488509,
                 'evidence_sha256': '176b3d6613305f35baf9231b8d80e060a2f3983d8d9aed70bf5100a56b80dab1',
                 'cutoff_ordinal': 7401, 'format': 851, 'unsupported': 1},
    'receipts': {'task': 'bc5a1f4afb81417b91114ed2dc69e806', 'evidence_size': 303853,
                 'evidence_sha256': '2029ffa91ecdd671054cfba93b5c00a14c0bc26ad9cb067c66e2f4a66bed5d61',
                 'cutoff_ordinal': 5017, 'format': 4, 'unsupported': 0},
}
HEX = re.compile(r'[0-9a-f]{64}')


def canonical(obj):
    return (json.dumps(obj, sort_keys=True, separators=(',', ':')) + '\n').encode()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def bind(raw):
    return {'bytes': len(raw), 'sha256': sha(raw)}


def output(path, data):
    if path.exists():
        assert path.read_bytes() == data, path
    else:
        with path.open('xb') as file:
            file.write(data)


def inspect(name, expected):
    source = CONTINUATION / f'rescue-{name}'
    result_raw = (source / 'result.json.gz').read_bytes()
    result = json.loads(gzip.decompress(result_raw))
    assert result == json.loads((source / 'result.decoded.json').read_bytes())
    assert (result['phase'], result['status'], result['stop']['kind'], result['counts']['json_values']) == (
        f'rescue-{name}', 'partial', 'json_value_count_limit', 8_000_001)
    assert not result['exact_matches']
    assert bind((source / 'evidence.zip').read_bytes()) == {
        'bytes': expected['evidence_size'], 'sha256': expected['evidence_sha256']}
    inv_raw = (source / 'member-inventory.jsonl.gz').read_bytes()
    assert bind(inv_raw) == {k: result['inventory'][k] for k in ('bytes', 'sha256')}
    rows = [json.loads(line) for line in gzip.decompress(inv_raw).splitlines()]
    headers = [row for row in rows if row['kind'] == 'tar_header']
    payloads = [row for row in rows if row['kind'] == 'member_payload']
    cutoff = expected['cutoff_ordinal']
    assert [h['ordinal'] for h in headers] == list(range(1, cutoff + 1))
    assert [x['location'] for x in payloads] == [h['location'] for h in headers[:-1]]
    assert all(HEX.fullmatch(h['member_name']) and h['type'] == '0' for h in headers)
    assert all(h['member_name'] == p['sha256'] and h['bytes'] == p['bytes']
               for h, p in zip(headers, payloads))
    last = headers[-1]
    assert result['last_completed_members'][name] == headers[-2]['location']
    caps = [r for r in rows if r.get('boundary') == 'json_value_count_limit']
    parent = last['location'].rsplit('!', 1)[0]
    outer = parent.split('!', 1)[0]
    assert [x['location'] for x in caps] == [last['location'], parent, outer]
    assert all(x['detail'] == 'JSON traversal node limit reached' for x in caps)
    assert not any(x['kind'] == 'decompressed' for x in rows)
    boundary_rows = [r for r in rows if r['kind'] == 'boundary' and r not in caps]
    formats = Counter(r['boundary'] for r in boundary_rows)
    assert formats['format_or_io_error'] == expected['format']
    assert formats['unsupported_json_encoding'] == expected['unsupported']
    bound = {h['location']: (h, p) for h, p in zip(headers, payloads)}
    early = []
    classes = Counter()
    affected = set()
    for record in boundary_rows:
        location = record['location']
        member_location, *tail = location.split('!')[2:]
        member_path = '!'.join(location.split('!')[:2] + [member_location])
        head, payload = bound[member_path]
        affected.add(head['ordinal'])
        assert payload['status'] == 'partial'
        detail = record['detail']
        if detail.startswith('JSONDecodeError:'):
            if len(tail) in (1, 2) and all(re.fullmatch(r'line [1-9][0-9]*', part) for part in tail):
                classes['anonymous_physical_line_not_json'] += 1
            else:
                assert tail[-2:] == ['decoded-payload', 'line 1']
                classes['anonymous_decoded_text_not_json_document_or_jsonl'] += 1
        else:
            assert name == 'priority'
            if tail == ['base64_file']:
                assert detail == 'ValueError: invalid Base64 alphabet or padding'
            elif tail == ['transcription', 'source']:
                assert detail == ('unknown payload encoding term + 2*(ix + 48*(iy + 48*(iz + 48*(iw + '
                                  '48*(method + 16*floorq)))))')
            else:
                raise AssertionError(record)
            early.append({'member': head, 'field_path': tail, 'old_detail': detail, 'payload_sha256': payload['sha256']})
            classes['exact_prior_field_needs_inspection'] += 1
    assert affected == {h['ordinal'] for h, p in zip(headers, payloads) if p['status'] == 'partial'}
    if name == 'priority':
        assert classes == {'anonymous_physical_line_not_json': 848,
                           'anonymous_decoded_text_not_json_document_or_jsonl': 2, 'exact_prior_field_needs_inspection': 2}
        assert [x['member']['ordinal'] for x in early] == [441, 6734]
    else:
        assert classes == {'anonymous_decoded_text_not_json_document_or_jsonl': 4}
    mentions = [{'target': x['target'], 'location': x['location']} for x in rows if x['kind'] == 'metadata_mention']
    complete = {(x['bytes'], x['sha256']) for x in payloads if x['status'] == 'checked'}
    return {
        'task': expected['task'], 'evidence_zip': {'bytes': expected['evidence_size'], 'sha256': expected['evidence_sha256']},
        'result_gzip': bind(result_raw), 'inventory_gzip': bind(inv_raw),
        'archive': result['regions'][0], 'cutoff': last, 'preceding_header': headers[-2],
        'old_stop': result['stop'], 'old_counts': result['counts'],
        'old_decoded_bytes_charged': result['decoded_bytes_charged'],
        'closed_prefix_payload_receipts': len(payloads), 'checked_payload_count': sum(x['status']=='checked' for x in payloads),
        'unique_checked_identity_count': len(complete),
        'unique_checked_identities_sha256': sha(canonical(sorted(complete))),
        'old_format_evidence_sha256': sha(canonical(boundary_rows)), 'receipt_format_classification': dict(classes),
        'exact_earlier_field_inspections': early,
        'candidate_receipts': [x for x in rows if x['kind'] == 'candidate'],
    }, mentions


def main():
    regions, mentions = {}, {}
    for name, expected in REGIONS.items():
        regions[name], mentions[name] = inspect(name, expected)
    assert len(mentions['priority']) == 140 and not mentions['receipts']
    report = {'regions': regions,
              'scope': 'Only selected earlier fields and two interrupted members plus their unread suffixes.',
              'old_json_cursor': 'Old logs contain no per-document/row/node cursor. The interrupted JSON objects were read into memory before traversal stopped; the complete target traversal was never performed.',
              'comments': ['Prior anonymous lines were checked at exact byte lengths before parsing and failed JSON syntax. They provide no affirmative evidence of declared malformed JSON.',
                           'Prior inferred decoded text was checked at exact raw and decoded lengths before line parsing.',
                           'Metadata mentions record prior locations only. Digest-field mentions are pointer evidence, not source-byte matches.']}
    data = canonical(report)
    output(BASE / 'resume-plan.json', data)
    output(BASE / 'prior-metadata-mentions.json', canonical(mentions))
    print(json.dumps({'plan': bind(data), 'metadata_mentions': {k: len(v) for k, v in mentions.items()},
                      'cutoffs': {k: v['cutoff'] for k, v in regions.items()}}))


if __name__ == '__main__':
    main()
