# Rescue TAR coverage through the exact selected fields

The two rescue TARs reached verified decompressor and TAR EOF. Their retained scans found **zero exact matches** for the three source-byte identities in the regions covered by the declared decoders. The priority scan and its exact-field follow-up have no outstanding scanner boundary. The receipts scan has no outstanding ordinary JSON or archive traversal boundary. Two exact exported bodies retain separate content-interpretation coverage boundaries.

| Archive | Verified outer SHA-256 | Verified decoded TAR bytes | Union of member headers | Resume started at |
|---|---|---:|---:|---:|
| `priority-objects.tar.xz` | `6ea6a2f20159499b7e33b74a77e64723272175db223c6fab41a748d629363c06` | 718,028,800 | 14,287 | 7,401 |
| `evidence-receipts.tar.xz` | `1d7c1b85ab97aeb9ed471325ce67dcc40d3fe6474701b6e9b6c102645f2996b4` | 2,350,868,480 | 8,775 | 5,017 |

Each prefix stopped during JSON traversal. Its raw input had already been buffered for the interrupted member, but the first unchecked JSON node was absent from the receipt. The resume scan treated that member as a supplemental replay and continued through the unread suffix. The two complete header unions contain no content-addressed member name equal to a requested target SHA-256. The decoded TAR SHA-256 values are `3a95184624714c5ba693d7d2689ce0b5ea1050e1772f43930dfd52532f287836` for priority and `76bfe4b4d71177d454d67eecd38e5b9b2c88ae85de2bcdfd328414699ccb4aae` for receipts.

## Per-target results

| Requested source | Priority scanned regions | Receipts scanned regions |
|---|---|---|
| `Part3OriginalMediumPhysicalE3Block.lean`, 6,566 bytes, `1ed9fec9d526f866fff9a29f9d8d0fa96d63def2a8b1e4e7a42ad759a8989982` | Zero exact matches. One 6,566-byte JSON `type_expression` had a different digest. 46 metadata mentions. | Zero exact matches. No candidate or mention recorded. |
| `Part3OriginalMediumDoubleLambdaColorWindows.lean`, 7,882 bytes, `e034925f0c0fe6b3fbc1e74966848dadd66591910e7a074403151dbbb3e66f7a` | Zero exact matches. One 7,882-byte raw member had a different digest. Ordinal 13,840 records the exact digest as a 64-character string under `targets/missing`. 65 metadata mentions. | Zero exact matches. Two 7,882-byte line occurrences shared the same different digest. No metadata mention recorded. |
| `Part3ActualFrickeNonzeroFourier.lean`, 8,079 bytes, `926ee1b5e78c1a714fcb91405b6c85cc0c8d09dd32ad61c9135c2f15359a27fc` | Zero exact matches. Ordinal 13,840 records the exact digest as a 64-character string under `targets/missing`. 74 metadata mentions. | Zero exact matches. No candidate or mention recorded. |

The two 64-character values were identified by comparing the receipt hashes against the ASCII target digest strings. Metadata mentions and equal-size candidates carry no additional source-byte coverage.

## Priority exact fields

Of 34 resume boundaries, two anonymous JSON guesses occurred after the old hex byte fragments had already been decoded and checked as exact-size candidates. The other 32 positions in 19 hash-bound members were inspected. The results verify 25 empty Base64 byte-delta values, three scalar wire schema fields, one case-normalized transcription formula, one inferred odd-hex rejection, one filename reference, and one document parsed with two literal backslashes preserved at decoded-text positions 15,820 and 16,364. The sealed field receipt records zero remaining boundaries and zero exact source matches.

The pointer at ordinal 10,264 names `complete-ledger.tar.gz.b64` with encoded SHA-256 `5bc04596aee532b4497f696602c9b348fe58782635382e379d19283c145914c3`. This exact identity was previously recorded as a 1,141,635-byte Git blob, `1c60443110119d1654b99c2120bec1e96144095f`, with one Base64 decode and 106 TAR member headers in the original-target scope. The earlier ordinal 441 pointer names `local-evidence.tar.xz.b64` and has filename-only coverage in the retained field receipt. Both pointers were handled as metadata during the rescue sweep.

## Receipts exported bodies

Twelve of the 14 Git-labeled TAR boundaries are exact size and hash duplicates of the completed eleven thin-bundle checks and the checkpoint check. The other two bodies were exported intact:

- **Ordinal 7,161**, 17,237 bytes, SHA-256 `b4ad558ae94a43e8e0f64ffdd0550a77dd86632b5fbedd80f21fcd7dab0d963f`. The raw body starts `PACKEDCHARS_FLAG `. The first 12 bytes are `PACKEDCHARS_`. The transport heuristic treated bytes `EDCH` as Git pack version 1,162,101,576. That value is invalid for a Git pack, so the retained transport label `git_pack` is corrected to a PACK-prefix false positive. Content interpretation is tracked separately.
- **Ordinal 8,417**, 60,000 bytes, SHA-256 `a875a48de2881e09d1bde698c004a1bd8fb02630e50122e37ff36b1d4edeac3e`. The verified body has a Git v2 bundle header and a PACK marker at byte 265. The transport checks cover its exact bytes and header. Object-level source coverage is tracked separately.

The conclusions apply to these two archive identities and the recorded decoder selections. Previously excluded payloads keep their original target and decoder scope. The scanned ordinary regions, external references, and separate exported bodies have independently recorded coverage.

## Receipt chain

| Pass | Priority result gzip SHA-256 | Receipts result gzip SHA-256 |
|---|---|---|
| Resume | `b80c6eb1744508c490e84b3f942b527a3c99d661bc1767d48f1c18b2000a871b` | `d29c5fc506652f3e23a8320247b18249eab46000d377869fb56be8ae1ae97ed2` |
| Exact fields or exports | `b8bfc94e1466a67613784a1737b62d2bd161771a40128a3c7e81a4520827de68` | `96ab8ba7da88c2c163ab85ac99a1d68202e3c1e8f6ad42eeb5a16c3f0b13bcac` |

The companion JSON binds all six original prefix, resume and exact-field receipt ZIPs, compressed results, and inventories by size and SHA-256. It carries candidate digests, decoder exclusions, target counts, and the PACK-prefix correction. The builder verifies the retained ZIP entries against both companion files and checks the complete ordinal unions without opening the rescue TARs.
