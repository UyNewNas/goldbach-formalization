#!/usr/bin/env python3
"""Join retained bootstrap aliases, TAR fingerprints and selector results."""
from collections import Counter
import gzip
import hashlib
import json
from pathlib import Path
import zipfile

from build_bootstrap_selectors import ROOT
from scan_bootstrap_new96 import P34_OWNER, PLAN_SHA

HERE = Path(__file__).resolve().parent
SOURCE_TASKS = {
    'large-identity': ('107b7cb355b54d49a1d5e9b12be19b60', 'evidence.zip',
                       'f8d731641b4e496c0eec8ee0f887d7f149b35680f5224ff630634981e92dbd63'),
    'v3-large-members': ('fb53d3205ec34f01956a40fce57f536c', 'receipt.zip',
                         '05c1351da6a48e2056aab35ab3197e9a0629da0e6ae6c70924deb8ea572a9a5a'),
    'bootstrap': ('66e8bf57643c447da8d7155730934c40', 'receipt.zip',
                  '08c6f455b815f30b7eb74b0d1c99283c7f1f7c7d8595e9c6bd19dd802a4bc2ae'),
    'bootstrap96': ('2dd618b7ed3945b184563ce3bdb5d301', 'receipt.zip',
                    'f9ec8a59a611d579eb868dab3facb8415e9db29a481c6b5801ecdac33f1f6ab7'),
}
RECONCILIATION_SHA = '004ac914bceb1842450a6315b61acc87fdeb8434220be2419f95e37bc255efb8'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def pin(raw):
    return {'bytes': len(raw), 'sha256': sha(raw)}


def bind(label, inventory=None):
    task, zip_name, expected = SOURCE_TASKS[label]
    location = ROOT / label
    evidence = location / zip_name
    evidence_bytes = evidence.read_bytes()
    assert len(task) == 32 and sha(evidence_bytes) == expected
    result_gz = (location / 'result.json.gz').read_bytes()
    parsed = json.loads(gzip.decompress(result_gz))
    named = 'result.decoded.json' if label == 'large-identity' else 'result.json'
    assert parsed == json.loads((location / named).read_bytes())
    sealed = {'task': task, 'directory': label, 'zip': pin(evidence_bytes), 'result_gzip': pin(result_gz)}
    with zipfile.ZipFile(evidence) as archive:
        assert archive.read('result.json.gz') == result_gz
        if inventory:
            inv = (location / inventory).read_bytes()
            assert archive.read(inventory) == inv
            assert pin(inv) == {k: parsed['inventory'][k] for k in ('bytes', 'sha256')}
            sealed['inventory_gzip'] = pin(inv)
            return sealed, parsed, [json.loads(line) for line in gzip.decompress(inv).splitlines()]
    return sealed, parsed, []


def main():
    raw_plan = (HERE / 'bootstrap-new96.json').read_bytes()
    assert sha(raw_plan) == PLAN_SHA
    plan = json.loads(raw_plan)
    raw_rec = (ROOT / 'large-bootstrap-delta-plan/reconciliation.json').read_bytes()
    assert sha(raw_rec) == RECONCILIATION_SHA
    reconciliation = json.loads(raw_rec)
    identity_receipt, identity, _ = bind('large-identity', 'member-inventory.jsonl.gz')
    members_receipt, members, _ = bind('v3-large-members')
    probe_receipt, probe, probe_rows = bind('bootstrap', 'member-fingerprints.jsonl.gz')
    delta_receipt, delta, rows = bind('bootstrap96', 'member-inventory.jsonl.gz')
    assert delta_receipt['result_gzip']['sha256'] == 'ce3d011238bcc8e496b43c12075fdf631cb1f72fdac5587da86c01c6f195c46c'
    assert identity['status'] == 'identity_only' and not identity['boundary_counts']
    assert len(identity['regions']) == 5 and len({x['sha256'] for x in identity['regions']}) == 3
    outer = plan['outer']
    aliases = [r for r in identity['regions'] if r['sha256'] == outer['sha256']]
    assert len(aliases) == 3 and all(r['bytes'] == outer['bytes'] for r in aliases)
    alias_names = [row['path'] for row in aliases]
    assert outer['path'] == alias_names[0]
    assert members['status'] == 'fingerprints_verified_only' and not members['boundaries']
    raw_members = {(parent['path'], child['ordinal']): child
                   for parent in members['archives'] for child in parent['member_fingerprints']}
    assert len(raw_members) == 39 and not members['source_payload_format_decodes']
    details = reconciliation['member_rows']
    assert len(details) == 39
    for row in details:
        checked = raw_members[(row['outer_path'], row['ordinal'])]
        assert all(row[k] == checked[k] for k in ('bytes', 'sha256', 'member_name', 'header_offset'))
    dispositions = Counter(x['reconciled_status'] for x in details)
    assert dispositions == {'excluded_inherited_prior_block_scope': 36,
                            'excluded_exact_checked_rescue_member': 2,
                            'one_unread_bootstrap_identity': 1}
    bootstrap_zip_member, = [x for x in details if x['member_name'] == 'bootstrap.tar.gz']
    assert bootstrap_zip_member['sha256'] == outer['sha256']
    assert bootstrap_zip_member['bytes'] == outer['bytes']
    block_names = {x['member_name'] for x in details if x['reconciled_status'] == 'excluded_inherited_prior_block_scope'}
    assert block_names == {f'block-{i:02}.zip' for i in range(8, 44)}
    checked_json = [x for x in details if x['reconciled_status'] == 'excluded_exact_checked_rescue_member']
    assert sorted(x['member_name'] for x in checked_json) == ['index.json', 'tail.json']

    assert probe['input'] == delta['outer'] == outer
    assert probe['tar_identity'] == delta['decoded_tar_eof_identity'] == plan['decoded_tar']
    assert probe['status'] == 'fingerprint_inventory_complete' and not probe['boundaries']
    assert delta['status'] == 'selected_payloads_bounded_complete' and not delta['boundaries']
    assert delta['selector_plan_sha256'] == PLAN_SHA and delta['manifest_sha256'] == plan['manifest']['sha256']
    assert probe['tar_end_verified'] and probe['gzip_eof_verified'] and not probe['direct_source_matches']
    probe_headers = [r for r in probe_rows if r['kind'] == 'tar_header']
    fingerprints = [r for r in probe_rows if r['kind'] == 'member_fingerprint']
    assert [r['ordinal'] for r in probe_headers] == [r['ordinal'] for r in fingerprints] == list(range(1, 305))
    classes = Counter(r['classification'] for r in fingerprints)
    assert classes == {'prior_complete_identity_excluded': 205, 'same_run_identity': 3,
                       'new_unread_payload_identity': 96}
    scopes = delta['original_parent_exclusion_scope_counts']
    assert scopes == plan['excluded_parent_members_by_original_scope'] == {
        'three_targets_with_inherited_exclusions': 202, 'inherit_original_target_and_decoder_scope': 3}
    assert delta['transit_only_parent_members'] == 208 and delta['stop'] is None
    assert delta['catalog_counts'] == {'complete': 23144, 'partial': 163}
    assert not delta['prior_partial_aliases'] and not delta['unfinished_selectors'] and not delta['exact_matches']
    completed = {(row['ordinal'], row['sha256']) for row in delta['completed_selectors']}
    selectors = {row['ordinal']: row for row in plan['selectors']}
    assert len(completed) == 96 and completed == {(i, row['sha256']) for i, row in selectors.items()}
    actual_results = {r['ordinal']: r for r in rows if r['kind']=='new_selector_result'}
    assert actual_results.keys() == selectors.keys()
    assert all((r['bytes'], r['sha256']) == (actual_results[i]['bytes'], actual_results[i]['sha256'])
               for i, r in selectors.items())
    ordinary_selects = [r for r in actual_results.values() if r['status'] == 'checked_source_payload']
    assert [r['ordinal'] for r in ordinary_selects] == [106, 293, 302]
    compiled = [r for r in rows if r['kind'] == 'compiled_binary_outside_source_decoders']
    assert len(compiled) == 96 and all(r['recognized_lean_magic'] for r in compiled)
    assert len({r['sha256'] for r in compiled}) == 94
    assert sum(r['location'].count('!') == 2 for r in compiled) == 93
    assert not any(P34_OWNER.search(r['location'].rsplit('/', 1)[-1]) for r in compiled)
    assert not any(r['kind'] == 'compiled_owner_name_observed' for r in rows)
    exclude = Counter(r['reason'] for r in rows if r['kind'] == 'excluded')
    assert exclude == {'catalog_prior_complete_excluded': 19, 'same_run_complete_excluded': 4}
    assert len([r for r in rows if r['kind'] == 'zip_header']) == 32
    assert delta['counts']['archive_members'] == 336 and delta['counts']['json_values'] == 59947
    assert delta['capacity']['spooled_bytes'] == 0
    results = {
        'status': 'bounded_delta_closed_with_inherited_exclusions',
        'unique_selected_gzip': outer, 'standalone_exact_aliases': alias_names,
        'wrapper_member_alias': bootstrap_zip_member, 'aliased_zip_member_dispositions': dict(dispositions),
        'checked_rescue_json_aliases': checked_json, 'prior_block_zip_names': sorted(block_names),
        'decoded_tar': delta['decoded_tar_eof_identity'], 'root_member_fingerprint_classifications': dict(classes),
        'root_prior_exclusion_original_scope': scopes, 'new_selectors_finished': 96,
        'root_transit_only_members': 208, 'new_source_payload_selectors': ordinary_selects,
        'nested_zip_member_headers': 32, 'nested_exclusions': dict(exclude),
        'compiled_lean_occurrences': {'rows': 96, 'distinct_hashes': 94, 'root_rows': 93, 'nested_rows': 3,
                                      'owner_name_alerts': 0, 'compiled_serialization_scanned': False},
        'compiled_lean_nested_rows': [r for r in compiled if r['location'].count('!') > 2],
        'scanned_json_values': delta['counts']['json_values'],
        'targets': delta['targets'], 'exact_matches': [], 'scanner_boundaries': [],
        'receipts': {'outer_identity': identity_receipt, 'zip_alias_fingerprint': members_receipt,
                     'bootstrap_tar_fingerprint': probe_receipt, 'bootstrap_selected_decode': delta_receipt,
                     'alias_reconciliation_json': pin(raw_rec), 'exact_selector_plan': pin(raw_plan)},
        'coverage': ('One exact compressed bootstrap identity has bounded source-decoder coverage. '
                     'Aliases inherit each original scope. Compiled Lean serialization is outside source decoders, '
                     'and ordinary metadata-only probes grant no source-negative coverage by themselves.'),
    }
    encoded = (json.dumps(results, sort_keys=True, separators=(',', ':')) + '\n').encode()
    path = HERE / 'bootstrap-closeout.json'
    if path.exists():
        assert path.read_bytes() == encoded
    else:
        with path.open('xb') as output:
            output.write(encoded)
    print('bootstrap closeout', pin(encoded))


if __name__ == '__main__':
    main()
