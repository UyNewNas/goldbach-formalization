#!/usr/bin/env python3
"""Bind the 96 new bootstrap selectors to the retained fingerprint receipt."""
from collections import Counter
import gzip
import hashlib
import json
from pathlib import Path
import zipfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
BOOT = ROOT / 'bootstrap'
MANIFEST = ROOT / 'large-bootstrap-delta-plan/bootstrap-manifest.reassembled.json'
MANIFEST_SHA = 'bb38a378d1d46334fb15a3151dba1d8df80129f5ee3462025a644ff18145f67b'
PROBE_ZIP = '08c6f455b815f30b7eb74b0d1c99283c7f1f7c7d8595e9c6bd19dd802a4bc2ae'
PROBE_TASK = '66e8bf57643c447da8d7155730934c40'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def pin(data):
    return {'bytes': len(data), 'sha256': sha(data)}


def main():
    raw_manifest = MANIFEST.read_bytes()
    assert sha(raw_manifest) == MANIFEST_SHA
    manifest = json.loads(raw_manifest)
    inv = (BOOT / 'member-fingerprints.jsonl.gz').read_bytes()
    result_raw = (BOOT / 'result.json.gz').read_bytes()
    zipped = (BOOT / 'receipt.zip').read_bytes()
    assert len(zipped) == 34199 and sha(zipped) == PROBE_ZIP
    with zipfile.ZipFile(BOOT / 'receipt.zip') as archive:
        assert result_raw == archive.read('result.json.gz')
        assert inv == archive.read('member-fingerprints.jsonl.gz')
    result = json.loads(gzip.decompress(result_raw))
    assert result == json.loads((BOOT / 'result.json').read_bytes())
    assert result['status'] == 'fingerprint_inventory_complete' and not result['boundaries']
    assert result['tar_end_verified'] and result['gzip_eof_verified'] and result['input_outer_identity_verified']
    assert result['manifest_sha256'] == MANIFEST_SHA and result['input'] == manifest['input']
    assert result['nested_member_payload_decodes'] == 0 and not result['direct_source_matches']
    assert (len(manifest['completed']), len(manifest['blocked_partial'])) == (23144, 163)
    assert pin(inv) == {k: result['inventory'][k] for k in ('bytes', 'sha256')}
    roster = [json.loads(line) for line in gzip.decompress(inv).splitlines()]
    headers = {r['ordinal']: r for r in roster if r['kind'] == 'tar_header'}
    assert sorted(headers) == list(range(1, 305))
    fingerprints = [r for r in roster if r['kind'] == 'member_fingerprint']
    assert [r['ordinal'] for r in fingerprints] == list(range(1, 305))
    count = Counter(r['classification'] for r in fingerprints)
    assert count == {'prior_complete_identity_excluded': 205, 'same_run_identity': 3,
                     'new_unread_payload_identity': 96}
    assert result['counts']['regular_members_fingerprinted'] == 304
    before_complete = {(row[0], row[1]) for row in manifest['completed']}
    before_partial = {(row[0], row[1]) for row in manifest['blocked_partial']}
    complete_uses = Counter()
    for row in fingerprints:
        header = headers[row['ordinal']]
        assert all(row[k] == header[k] for k in ('member_name', 'bytes', 'data_offset', 'header_offset', 'type'))
        assert header['canonical_member_name'] is True and row['type'] == '0'
        if row['classification'] == 'prior_complete_identity_excluded':
            (old,) = [p for p in manifest['completed']
                      if p[0] == row['sha256'] and p[1] in (row['bytes'], None)]
            complete_uses[old[3]] += 1
    selected = []
    for row in fingerprints:
        if row['classification'] != 'new_unread_payload_identity':
            continue
        assert ((row['sha256'], row['bytes']) not in before_complete
                and (row['sha256'], None) not in before_complete
                and (row['sha256'], row['bytes']) not in before_partial)
        assert not row['direct_target_match'] and row['content_decoded'] is False
        selector = {k: row[k] for k in ('ordinal', 'member_name', 'bytes', 'sha256', 'type',
                                        'header_offset', 'data_offset', 'codec_hint')}
        if row['member_name'].endswith('.olean'):
            selector['selector_role'] = 'compiled_lean_filename'
        elif row['codec_hint'] == 'zip':
            selector['selector_role'] = 'zip'
        else:
            assert row['member_name'] == '.lake/p210-ci/install.log' and row['codec_hint'] is None
            selector['selector_role'] = 'text'
        selected.append(selector)
    assert len({item['sha256'] for item in selected}) == 96
    assert [r['ordinal'] for r in selected if r['selector_role'] != 'compiled_lean_filename'] == [106, 293, 302]
    assert sum(r['bytes'] for r in selected if r['selector_role'] == 'compiled_lean_filename') == 1709879240
    assert sum(r['bytes'] for r in selected) == 1711761438
    assert result['tar_identity'] == {'bytes': 1751224320,
                                     'sha256': 'a69b55b8e5b1d607b42c02d53858ee7a0ebd9a0ca91500c3442f6736c19ee61c'}
    scope = {
        'outer': result['input'], 'decoded_tar': result['tar_identity'],
        'fingerprint_probe_task': PROBE_TASK, 'fingerprint_probe_zip': pin(zipped),
        'fingerprint_probe_result_gzip': pin(result_raw), 'fingerprint_probe_inventory_gzip': pin(inv),
        'manifest': pin(raw_manifest), 'target_sha_and_size': [
            {k: row[k] for k in ('filename', 'sha256', 'bytes')} for row in manifest['targets']],
        'total_tar_headers': len(headers), 'fingerprint_classifications': dict(count),
        'excluded_parent_members_by_original_scope': dict(complete_uses),
        'selectors': selected,
    }
    data = (json.dumps(scope, sort_keys=True, separators=(',', ':')) + '\n').encode()
    destination = HERE / 'bootstrap-new96.json'
    if destination.exists():
        assert destination.read_bytes() == data
    else:
        with destination.open('xb') as output:
            output.write(data)
    print(json.dumps({'selectors': len(selected), 'manifest': pin(raw_manifest), 'exact_plan': pin(data),
                      'excluded_by_scope': dict(complete_uses),
                      'roles': dict(Counter(r['selector_role'] for r in selected))}))


if __name__ == '__main__':
    main()
