#!/usr/bin/env python3
"""Exact source recovery over 96 verified bootstrap member selectors."""
import argparse
import base64
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import resource
import struct
import sys
import tarfile
from types import ModuleType

RUNNER = Path('/workspace/p34-recovery-runner-20261126')
ROOT = Path('/workspace/p34-recovery-delta-20261126')
CATALOG = Path('/workspace/p34-large-bootstrap-runner-20261126/bootstrap-manifest.json')
PLAN_SHA = 'b92e0d0eb16213b6e974e9ca29b67c6863c96ddd930fad97c117a981e3be235d'
MANIFEST_SHA = 'bb38a378d1d46334fb15a3151dba1d8df80129f5ee3462025a644ff18145f67b'
V2_SHA = '1b9d8c716f3c710f12e51931ccd26de64e83926ca3f6319d30b5a5dd7c35cf19'
MIB = 1 << 20
MAX_PAYLOAD = 48 * MIB
MAX_ACTIVE_RAW = 96 * MIB
MAX_JSON_NODES = 8_000_000
MAX_COMPLETED_CACHE = 20_000
SHA256 = re.compile(r'[0-9a-f]{64}\Z')
P34_OWNER = re.compile(r'part3|p3(?:4|[._-])|fricke|nonzero|originaldata|physicale3block|doublelambda', re.I)
FILE_REF = re.compile(rb'[/A-Za-z0-9_.-]+\.(?:b64|base64|zip|tar|gz|xz|json|lean)\Z')


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def canonical(obj):
    return (json.dumps(obj, sort_keys=True, separators=(',', ':')) + '\n').encode()


def read_checked(path, sha, limit, size=None):
    with Path(path).open('rb') as handle:
        raw = handle.read(limit + 1)
    if len(raw) > limit or digest(raw) != sha or (size is not None and len(raw) != size):
        raise ValueError(f'input identity mismatch: {path}')
    return raw


def load_v2(home):
    path = home / 'recover_unread_xz.py'
    body = read_checked(path, V2_SHA, 72_000)
    mod = ModuleType('verified_v2_recovery')
    mod.__file__ = str(path)
    exec(compile(body, str(path), 'exec'), mod.__dict__)
    return mod


def catalog_lookup(manifest):
    completed = {item[0]: tuple(item[1:]) for item in manifest['completed']}
    blocked = {item[0]: tuple(item[1:]) for item in manifest['blocked_partial']}
    if len(completed) != len(manifest['completed']) or len(blocked) != len(manifest['blocked_partial']):
        raise ValueError('duplicate manifest identity rows')
    return completed, blocked


def validate_plan(plan, manifest, original):
    selections = plan['selectors']
    if (manifest['schema'] != 'p34.bootstrap-fingerprint-plan.v1' or plan['outer'] != manifest['input']
            or len(manifest['completed']) != 23144 or len(manifest['blocked_partial']) != 163
            or len(selections) != 96 or len({r['ordinal'] for r in selections}) != 96
            or len({r['sha256'] for r in selections}) != 96 or original['targets'] != manifest['targets']):
        raise ValueError('manifest, selected archive or target identity mismatch')
    complete, blocked = catalog_lookup(manifest)
    for row in selections:
        if (not SHA256.fullmatch(row['sha256']) or row['type'] != '0'
                or row['sha256'] in complete or row['sha256'] in blocked):
            raise ValueError('selector is malformed or was already represented in the prior manifest')
    return complete, blocked


def load_previous(specs, plan):
    closed = set()
    typed = set()
    lineage = []
    available = {r['ordinal']: r['sha256'] for r in plan['selectors']}
    for spec in specs:
        rawpath, sep, expected = spec.rpartition('@')
        path = Path(rawpath)
        if (not sep or not SHA256.fullmatch(expected) or not path.is_absolute()
                or ROOT not in path.parents or path.resolve() != path or path.name != 'result.json.gz'):
            raise ValueError('previous receipt must be an exact result path under the recovery root followed by @SHA256')
        raw = read_checked(path, expected, 4 * MIB)
        with gzip.GzipFile(fileobj=io.BytesIO(raw)) as stream:
            body = stream.read(12 * MIB + 1)
        if len(body) > 12 * MIB:
            raise ValueError('previous receipt expansion exceed cap')
        report = json.loads(body)
        if (report['selector_plan_sha256'] != PLAN_SHA or report['manifest_sha256'] != MANIFEST_SHA
                or report['outer'] != plan['outer']):
            raise ValueError('previous receipt has an unrelated source scope')
        for row in report['completed_selectors']:
            if available.get(row['ordinal']) != row['sha256']:
                raise ValueError('previous closed selector differs from exact plan')
            closed.add(row['ordinal'])
        inventory = report['inventory']
        if Path(inventory['path']) != path.with_name('member-inventory.jsonl.gz'):
            raise ValueError('previous receipt inventory path mismatch')
        read_checked(inventory['path'], inventory['sha256'], 12 * MIB, inventory['bytes'])
        for count, sha, codec in report['completed_nested_wrapper_cache']:
            if not SHA256.fullmatch(sha) or not 0 <= count <= MAX_PAYLOAD:
                raise ValueError('malformed previous nested wrapper cache')
            typed.add((count, sha, codec))
        lineage.append({'result_sha256': expected, 'closed_selectors': len(report['completed_selectors']),
                        'inventory_sha256': inventory['sha256']})
        if len(typed) > MAX_COMPLETED_CACHE:
            raise ValueError('prior nested wrapper cache exceeded limit')
    return closed, typed, lineage


def make_scanner(base, v2, preflight):
    Parent = v2.scanner_class(base, preflight)
    base.MAX_JSON_VALUES = MAX_JSON_NODES
    prior_codec = base.codec

    def checked_codec(head, name):
        kind = prior_codec(head, name)
        if kind == 'git_payload' and head.startswith(b'PACK'):
            if len(head) < 12 or struct.unpack('>I', head[4:8])[0] not in (2, 3):
                return 'invalid_wrapper' if name.lower().endswith('.bundle') else None
        return kind

    base.codec = checked_codec

    class Bootstrap(Parent):
        def __init__(self, data, extra, inventory, seconds, complete, blocked, *, previous_closed=(), typed=()):
            super().__init__(data, extra, inventory, seconds, 4 << 30)
            self.catalog_complete = complete
            self.catalog_blocked = blocked
            self.previous_closed = set(previous_closed)
            self.completed = set(previous_closed)
            self.nested_cache = set(typed)
            self.seen.update((sha, codec) for _, sha, codec in typed)
            self.seen_sizes.update(size for size, _, _ in typed)
            self.active_raw = 0
            self.active_selector = None
            self.current_location = None
            self.failure_cursor = None
            self.last_completed_selector = None
            self.documents = []
            self.top_verified = False
            self.top_compiled = False
            self.transits = 0
            self.prior_region_aliases = []
            self.tar_eof = None

        def remember_failure(self, location):
            if self.failure_cursor is None:
                self.failure_cursor = {'selector': self.active_selector, 'location': location,
                                       'active_nested_location': self.current_location,
                                       'json_documents': [dict(doc) for doc in self.documents],
                                       'global_json_values': self.counts['json_values']}

        def attempt(self, location, operation):
            try:
                return super().attempt(location, operation)
            except base.Boundary as exc:
                if exc.stop:
                    self.remember_failure(location)
                raise

        def alias(self, loc, size, sha, *, textual=False):
            for catalog, rule in ((self.catalog_complete, 'catalog_prior_complete_excluded'),
                                  (self.catalog_blocked, 'catalog_prior_partial_owned_elsewhere')):
                row = catalog.get(sha)
                if row is None or row[0] not in (None, size):
                    continue
                value = {'bytes': size, 'sha256': sha, 'prior_receipt': row[1],
                         'inherited_scope': row[2], 'inside_text': textual}
                self.exclude(loc, value, rule)
                if catalog is self.catalog_blocked and len(self.prior_region_aliases) < 1000:
                    self.prior_region_aliases.append({'location': base.short(loc), **value})
                return True
            return False

        def owner_alert(self, loc, name, kind):
            if not name.lower().endswith('.olean'):
                return
            stem = PurePosixPath(name).stem
            exact = [row['filename'] for row in self.targets if row['module'].casefold() == stem.casefold()]
            if exact or P34_OWNER.search(stem):
                self.event('compiled_owner_name_observed', loc, compiled_module=stem,
                           exact_target_module_names=exact, codec_hint=kind)
                self.counts['compiled_owner_name_observed'] += 1

        def collect(self, loc, name, source, depth, size=None, path=''):
            self.check_time()
            base.limit(depth > base.MAX_DEPTH, 'nested_depth_limit', f'payload depth {depth} exceeded cap')
            head = source.read(512)
            kind = base.codec(head, name)
            if kind is None and re.search(r'(?:^|/)objects/', path) and base.likely_zlib(head):
                kind = 'zlib'
            named = any(base.names_target(row, name) for row in self.targets)
            candidate = named or size in self.target_sizes or size is None
            binary_olean = (name.lower().endswith('.olean') and kind is None
                            and (head.startswith(b'olean') or not base.readable_head(head)))
            self.owner_alert(loc, name, kind)
            relevant = bool(kind or candidate or (not binary_olean and (
                base.readable_head(head) or name.lower().endswith(base.TEXT_SUFFIX) or path.startswith('objects/'))))
            available = min(MAX_PAYLOAD, max(0, MAX_ACTIVE_RAW - self.active_raw))
            prefix = bytearray(head) if relevant and len(head) <= available else None
            total = len(head)
            fingerprint = hashlib.sha256(head)
            while True:
                self.check_time()
                block = source.read(base.CHUNK)
                if not block:
                    break
                total += len(block)
                fingerprint.update(block)
                if prefix is not None:
                    if total <= available:
                        prefix.extend(block)
                    else:
                        prefix = None
            sha = fingerprint.hexdigest()
            base.limit(size is not None and total != size, 'member_size_mismatch', 'fingerprinted member size changed')
            # The sealed positive selector must agree before calling any decoder.
            is_top = self.active_selector is not None and loc == self.active_selector['location']
            if is_top:
                required = self.active_selector
                base.limit((total, sha) != (required['bytes'], required['sha256']),
                           'selector_body_identity_mismatch', 'selected member bytes differ from fingerprint receipt')
                base.limit(required['codec_hint'] is not None and kind != required['codec_hint'],
                           'selector_magic_mismatch', 'selected wrapper differs from fingerprinted magic')
                self.top_verified = True
            if self.alias(loc, total, sha):
                return
            if binary_olean and not named and total not in self.target_sizes:
                self.counts['compiled_binary_outside_source_decoders'] += 1
                if is_top:
                    self.top_compiled = True
                self.event('compiled_binary_outside_source_decoders', loc, bytes=total, sha256=sha,
                           reported_prefix_hex=head[:12].hex(), recognized_lean_magic=head.startswith(b'olean'))
                return
            if not relevant:
                self.counts['binary_outside_candidate_and_wrapper_rules'] += 1
                return
            if prefix is None:
                if size is None and total not in self.target_sizes and not kind and not named and not base.readable_head(head):
                    self.counts['binary_outside_candidate_and_wrapper_rules'] += 1
                    return
                self.event('fingerprint_complete_without_decode', loc, bytes=total, sha256=sha, codec=kind)
                raise base.Boundary('predecode_fingerprint_memory_guard',
                                    f'novel {total}-byte wrapper or source candidate exceeded {available}-byte scoped buffer')
            raw = bytes(prefix)
            del prefix
            self.visit_bytes(loc, name, raw, depth, kind=kind, path=path, verified_sha=sha)

        def visit(self, loc, name, source, depth, size=None, *, path=''):
            return self.collect(loc, name, source, depth, size, path)

        def visit_bytes(self, loc, name, raw, depth, *, kind=None, path='', verified_sha=None):
            value = verified_sha or digest(raw)
            if verified_sha is None:
                if value in self.catalog_complete or value in self.catalog_blocked:
                    self.check_target(loc, raw, value, name)
                    if self.alias(loc, len(raw), value):
                        return
                self.owner_alert(loc, name, kind)
            before = self.boundaries.total()
            kind = kind or base.codec(raw[:512], name)
            prior_location = self.current_location
            self.current_location = loc
            self.active_raw += len(raw)
            try:
                base.limit(self.active_raw > MAX_ACTIVE_RAW, 'nested_active_buffer_guard',
                           'simultaneously buffered known payloads exceed memory guard')
                super().visit_bytes(loc, name, raw, depth, kind=kind, path=path)
            except base.Boundary as exc:
                if exc.stop:
                    self.remember_failure(loc)
                raise
            finally:
                self.active_raw -= len(raw)
                self.current_location = prior_location
            if (kind and self.boundaries.total() == before and (value, kind) in self.seen
                    and value not in self.prior and len(self.nested_cache) < MAX_COMPLETED_CACHE):
                self.nested_cache.add((len(raw), value, kind))

        def encoded_string(self, loc, raw, depth, hint=''):
            if raw and self.alias(loc, len(raw), digest(raw), textual=True):
                return True
            if hint in ('base64', 'b64', 'base64url', 'base64-url', 'hex', 'hexadecimal'):
                if not base.SPACE.sub(b'', raw):
                    self.counts['valid_empty_declared_encoding'] += 1
                    return True
                if loc.rsplit('!', 1)[-1] == 'base64_file' and len(raw) < 1024 and FILE_REF.fullmatch(raw):
                    self.event('external_pointer_metadata', loc, bytes=len(raw), sha256=digest(raw),
                               reference=raw.decode('ascii'))
                    return True
            return super().encoded_string(loc, raw, depth, hint)

        def json_document(self, loc, raw, depth, allow_jsonl):
            node = {'location': loc, 'bytes': len(raw), 'sha256': digest(raw), 'next_node_position': 0}
            self.documents.append(node)
            try:
                if not allow_jsonl:
                    super().json_document(loc, raw, depth, False)
                    return
                try:
                    parsed = json.loads(raw, object_pairs_hook=base.JsonObject)
                except UnicodeDecodeError:
                    self.counts['anonymous_non_utf8_json_probe_rejected'] += 1
                    return
                except json.JSONDecodeError as exc:
                    if exc.msg == 'Extra data':
                        self.text_lines(loc, io.BytesIO(raw), depth)
                    else:
                        self.boundary(loc, 'anonymous_json_syntax', exc)
                    return
                self.json_walk(loc, parsed, depth)
            finally:
                self.documents.pop()

        def json_walk(self, loc, value, depth, nesting=0, key='', hints=()):
            if self.documents:
                self.documents[-1]['next_node_position'] += 1
            if self.counts['json_values'] >= MAX_JSON_NODES:
                self.remember_failure(loc)
            return super().json_walk(loc, value, depth, nesting, key, hints)

        def text_lines(self, loc, stream, depth):
            for here, line in self.line_records(loc, stream, base.MAX_JSON_LINE):
                self.check_target(here, line)
                bare = line.removesuffix(b'\n').removesuffix(b'\r')
                if line != bare:
                    self.check_target(here, bare)
                if v2.plausible_json(bare[:512]):
                    try:
                        parsed = json.loads(bare, object_pairs_hook=base.JsonObject)
                    except (UnicodeDecodeError, json.JSONDecodeError):
                        self.counts['anonymous_line_json_probe_rejected'] += 1
                    else:
                        self.documents.append({'location': here, 'bytes': len(bare), 'sha256': digest(bare),
                                               'next_node_position': 0})
                        try:
                            self.json_walk(here, parsed, depth)
                        finally:
                            self.documents.pop()
                        continue
                if len(bare) >= min(self.target_sizes) or bare.startswith(b'data:'):
                    self.attempt(here, lambda: self.encoded_string(here, bare, depth))

        def visit_selected_tar(self, parent, stream):
            by_ordinal = {row['ordinal']: row for row in self.plan['selectors']}
            seen = set()
            ordinal = 0
            with tarfile.open(fileobj=stream, mode='r|', tarinfo=base.BoundedTarInfo, bufsize=base.CHUNK) as archive:
                for ordinal, member in enumerate(archive, 1):
                    self.check_time()
                    self.member_count()
                    if ordinal not in by_ordinal:
                        self.transits += 1
                        continue
                    expected = by_ordinal[ordinal]
                    at = base.joined(parent, f'{ordinal}:{member.name}')
                    seen.add(ordinal)
                    self.active_selector = {**expected, 'location': at}
                    self.top_verified = self.top_compiled = False
                    header = (member.name, member.size, member.offset, member.offset_data, member.type)
                    required = tuple(expected[k] for k in ('member_name', 'bytes', 'header_offset', 'data_offset')) + (b'0',)
                    base.limit(header != required or not base.valid_member(member.name) or member.sparse,
                               'exact_tar_selector_header_mismatch', f'selected ordinal {ordinal} header changed')
                    if ordinal in self.previous_closed:
                        self.event('previously_completed_selector_transit', at,
                                   ordinal=ordinal, bytes=expected['bytes'], sha256=expected['sha256'])
                        continue
                    self.event('new_selector_header', at, **{k: v for k, v in expected.items() if k != 'location'})
                    with archive.extractfile(member) as file:
                        member_meter = base.Meter(file, self, member.size)
                        worked = self.attempt(at, lambda: self.visit(
                            at, base.name_of(member.name), member_meter, 1, member.size, path=member.name))
                        identity = member_meter.finish()
                    bound = identity == {'bytes': expected['bytes'], 'sha256': expected['sha256']}
                    if not bound:
                        self.boundary(at, 'exact_tar_selector_body_mismatch', 'selected body differs from sealed fingerprint')
                    ok = worked and bound and self.top_verified
                    status = ('compiled_outside_source_decoders' if self.top_compiled else 'checked_source_payload') if ok else 'partial'
                    self.event('new_selector_result', at, status=status, ordinal=ordinal, **identity)
                    if ok:
                        self.completed.add(ordinal)
                        self.last_completed_selector = self.active_selector
                    self.active_selector = None
                base.limit(ordinal != self.plan['total_tar_headers'] or seen != set(by_ordinal),
                           'top_level_inventory_mismatch', 'sealed TAR header count or selector roster changed')
                base.limit(not archive._delta_end or archive.fileobj.read(512) != bytes(512),
                           'tar_end_marker', 'missing TAR end block')
                while True:
                    tail = archive.fileobj.read(base.CHUNK)
                    if not tail:
                        break
                    base.limit(any(tail), 'tar_nonzero_tail', 'nonzero bytes after TAR zero footer')
                self.event('verified_tar_end', parent, headers=ordinal, selector_count=len(seen),
                           excluded_transit_members=self.transits)

        def scan_bootstrap(self, plan):
            self.plan = plan
            row = plan['outer']

            def read_selected(location, source, identity):
                compressed = base.Meter(source, self, expected=row['bytes'])
                parent = base.joined(location, base.inner_name(base.name_of(location)))
                with gzip.GzipFile(fileobj=compressed) as decoded:
                    expanded = base.Meter(decoded, self, expected=plan['decoded_tar']['bytes'], expanded=True)
                    ok = self.attempt(parent, lambda: self.visit_selected_tar(parent, expanded))
                    observed = expanded.finish()
                replay = compressed.finish()
                base.limit(observed != plan['decoded_tar'] or replay != identity,
                           'bootstrap_tar_transport_identity', 'decoded TAR or compressed replay differed from original receipt')
                self.tar_eof = observed
                self.event('verified_gzip_eof', parent, compressed_identity=replay, decoded_tar=observed,
                           payload_decoder_status='checked' if ok else 'partial')

            self.run_region('bootstrap-new96', row, read_selected)

    return Bootstrap


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--runner', type=Path, default=RUNNER)
    parser.add_argument('--catalog', type=Path, default=CATALOG)
    parser.add_argument('--out', type=Path, default=ROOT / 'bootstrap-new96')
    parser.add_argument('--seconds', type=int, default=900)
    parser.add_argument('--completed-receipt', action='append', default=[], metavar='RESULT@SHA256')
    parser.add_argument('--emit-stdout', action='store_true')
    args = parser.parse_args()
    if (not 1 <= args.seconds <= 1700 or len(args.completed_receipt) > 8
            or not args.out.is_absolute() or args.out.parent.resolve() != args.out.parent):
        raise ValueError('time, prior receipt count or output path outside safe bounds')
    home = args.runner / 'repair-v2'
    v2 = load_v2(home)
    base = v2.load_checked_module(args.runner / 'recover_archive_delta.py', v2.BASE_SCANNER_SHA, 'bootstrap_base')
    preflight = v2.load_checked_module(home / 'xz_memory_preflight.py', v2.PREFLIGHT_SCANNER_SHA, 'bootstrap_existing_xz')
    original_data = json.loads(read_checked(args.runner / 'allowlist.json', v2.BASE_ALLOWLIST_SHA, 256 << 10))
    extra = json.loads(read_checked(home / 'repair-allowlist-v2.json', v2.REPAIR_ALLOWLIST_SHA, 48 << 10))
    plan = json.loads(read_checked(Path(__file__).with_name('bootstrap-new96.json'), PLAN_SHA, 64 << 10))
    manifest = json.loads(read_checked(args.catalog, MANIFEST_SHA, 8 * MIB, plan['manifest']['bytes']))
    complete, blocked = validate_plan(plan, manifest, original_data)
    soft, hard = resource.getrlimit(resource.RLIMIT_AS)
    guard = min(x for x in (base.MAX_ADDRESS, soft, hard) if x != resource.RLIM_INFINITY)
    resource.setrlimit(resource.RLIMIT_AS, (guard, hard))
    closed, typed, lineage = load_previous(args.completed_receipt, plan)
    args.out.mkdir(mode=0o700, exist_ok=False)
    inventory_path = args.out / 'member-inventory.jsonl.gz'
    stop = None
    with gzip.open(inventory_path, 'xt', encoding='utf-8', compresslevel=4) as inventory:
        scan = make_scanner(base, v2, preflight)(original_data, extra, inventory, args.seconds, complete, blocked,
                                                 previous_closed=closed, typed=typed)
        try:
            scan.scan_bootstrap(plan)
        except base.Boundary as exc:
            stop = {'kind': exc.kind, 'detail': str(exc)}
    matches = []
    for target in scan.targets:
        name = target['filename']
        raw = scan.matches.get(name)
        if raw is None:
            continue
        if (len(raw) != target['bytes'] or digest(raw) != target['sha256']
                or '/' in name or not name.endswith('.lean') or not base.valid_member(name)):
            raise ValueError('selected source failed final identity check')
        with (args.out / name).open('xb') as output:
            output.write(raw)
        matches.append({'filename': name, 'bytes': len(raw), 'sha256': digest(raw),
                        'locations': scan.match_locations[name][:60],
                        'base64': base64.b64encode(raw).decode('ascii')})

    inv_hasher = hashlib.sha256()
    with inventory_path.open('rb') as receipt:
        for chunk in iter(lambda: receipt.read(base.CHUNK), b''):
            inv_hasher.update(chunk)
    pending = [row for row in plan['selectors'] if row['ordinal'] not in scan.completed]
    complete_status = 'selected_payloads_closed_with_prior_partial_aliases' if scan.prior_region_aliases else 'selected_payloads_bounded_complete'
    report = {
        'status': 'partial' if stop or scan.boundaries or pending or scan.tar_eof is None else complete_status,
        'outer': plan['outer'], 'manifest_sha256': MANIFEST_SHA, 'selector_plan_sha256': PLAN_SHA,
        'fingerprint_probe': {k: plan[k] for k in ('fingerprint_probe_task', 'fingerprint_probe_zip',
                                                  'fingerprint_probe_result_gzip', 'fingerprint_probe_inventory_gzip')},
        'decoded_tar_eof_identity': scan.tar_eof, 'decoded_bytes_charged': scan.expanded,
        'transit_only_parent_members': scan.transits,
        'original_parent_exclusion_scope_counts': plan['excluded_parent_members_by_original_scope'],
        'catalog_counts': {'complete': len(complete), 'partial': len(blocked)},
        'counts': dict(scan.counts), 'boundaries': dict(scan.boundaries),
        'boundary_sample': scan.limits_sample, 'stop': stop, 'failure_cursor': scan.failure_cursor,
        'last_completed_selector': scan.last_completed_selector, 'next_unfinished_selector': pending[0] if pending else None,
        'unfinished_selectors': pending,
        'completed_selectors': [{'ordinal': row['ordinal'], 'sha256': row['sha256']}
                                for row in plan['selectors'] if row['ordinal'] in scan.completed],
        'completed_nested_wrapper_cache': sorted(scan.nested_cache),
        'prior_partial_aliases': scan.prior_region_aliases, 'previous_target_scan_receipts': lineage,
        'targets': scan.targets, 'exact_matches': matches,
        'capacity': {'address_space': guard, 'expanded_bytes': 4 << 30, 'json_values': MAX_JSON_NODES,
                     'max_nested_input_buffer': MAX_PAYLOAD, 'max_active_raw_buffers': MAX_ACTIVE_RAW,
                     'deadline_seconds': args.seconds, 'spooled_bytes': 0},
        'inventory': {'path': str(inventory_path), 'bytes': inventory_path.stat().st_size,
                      'sha256': inv_hasher.hexdigest()},
        'scope': ('Only 96 fingerprint-selected bootstrap members. Duplicate and prior identities retain their '
                  'original target and decoder scope. Lean binaries were checked by exact raw identity and '
                  'classified outside source decoders, with target and adjacent compiled names recorded if observed.'),
    }
    packed = gzip.compress(canonical(report), mtime=0)
    with (args.out / 'result.json.gz').open('xb') as output:
        output.write(packed)
    print(json.dumps({'status': report['status'], 'transit_only_members': scan.transits,
                      'finished_selectors': len(report['completed_selectors']), 'pending': len(pending),
                      'boundaries': report['boundaries'], 'stop': stop,
                      'compiled_owner_name_alerts': scan.counts['compiled_owner_name_observed'],
                      'matches': [m['filename'] for m in matches],
                      'result_bytes': len(packed), 'result_sha256': digest(packed)}), flush=True)
    if args.emit_stdout:
        transfer = base64.b64encode(packed).decode('ascii')
        for index, offset in enumerate(range(0, len(transfer), 4096)):
            print(f'DELTA_RESULT_GZIP_BASE64 {index:05d} {transfer[offset:offset + 4096]}')
        print(f'DELTA_RESULT_END {len(transfer)} {digest(packed)}', flush=True)
    return 2 if stop else 0


if __name__ == '__main__':
    sys.exit(main())
