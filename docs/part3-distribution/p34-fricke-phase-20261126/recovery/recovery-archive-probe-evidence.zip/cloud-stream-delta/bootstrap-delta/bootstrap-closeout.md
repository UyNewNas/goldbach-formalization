# Bootstrap archive recovery closeout

One exact bootstrap gzip was selected and checked to verified TAR and gzip EOF. The selected payload scan completed all **96** allowed member identities with **zero boundaries, zero exact source matches, and zero compiled-owner name alerts**. Prior aliases keep the target and decoder scope of their respective receipts.

## Identity and alias chain

Five paths in the large identity pass reduced to three outer identities. The subsequent ZIP fingerprint pass verified all 39 stored members by exact byte count and SHA-256. Its complete disposition was:

| ZIP member group | Members | Disposition |
|---|---:|---|
| `bootstrap.zip!bootstrap.tar.gz` | 1 | Exact copy of the three 413,971,227-byte standalone gzip files. |
| `collection-tail.zip!block-08.zip` through `block-43.zip` | 36 | Exact prior representative identities. Block 24 uses the scoped first-run reconciliation. The other blocks retain their original receipts. |
| `collection-tail.zip!index.json` and `tail.json` | 2 | Exact checked rescue members at receipts ordinal 4,366 and priority ordinal 5,443, respectively. |

The standalone selected gzip is `/workspace/p210-public-receiver-20261125/.lake/p210-public-receiver/inputs/bootstrap.tar.gz`, SHA-256 `e17d879ab60ad21874b8b26ce20075a1b646af82ee18cf00749773ba5dc37370`. All other copies stayed outside the selected decode. The two JSON aliases have SHA-256 `687c35f8ef018ad85e7cc68581dcadd98cd0acd22bd22f031dfd95966abfc70e` and `3829ac29f68b12ceef9edeaca6dc6cb46378c9f35a6ecbfe3f887d12dde8359e`, respectively.

## TAR fingerprint and selected payload result

The fingerprint pass inventoried all **304** regular TAR member headers and verified the **1,751,224,320-byte** decoded TAR, SHA-256 `a69b55b8e5b1d607b42c02d53858ee7a0ebd9a0ca91500c3442f6736c19ee61c`. None of the raw members matched a requested source digest and length. The subsequent selected-payload pass independently verified the same decoded identity and EOF.

Of the 304 parent members, the selected decoder opened 96 exact members. The other 208 passed through the transport, comprising 205 previously covered content identities and three same-run duplicates. **Three** of the 205 retain the older original-target and decoder-only scope. The other **202** inherit three-target scope with their original exclusions. No historical scope was enlarged.

The source checks examined an install log at ordinal 106 and the new ZIP members at ordinals 293 and 302. The ZIPs exposed 32 additional member headers and the decoder traversed 59,947 JSON values. Nineteen nested catalog duplicates and four same-run nested duplicates were excluded. The result classified 96 Lean binary occurrences by filename, recognized binary magic and exact identity. These comprise 93 top-level occurrences and three nested occurrences, with 94 distinct hashes. The compiled Lean serialization remains outside the source decoders. None of those names matched a requested source module or triggered the P3.4-related name check.

## Retained evidence

| Phase | Task | Receipt ZIP SHA-256 |
|---|---|---|
| Large outer identity | `107b7cb355b54d49a1d5e9b12be19b60` | `f8d731641b4e496c0eec8ee0f887d7f149b35680f5224ff630634981e92dbd63` |
| Stored ZIP member fingerprints | `fb53d3205ec34f01956a40fce57f536c` | `05c1351da6a48e2056aab35ab3197e9a0629da0e6ae6c70924deb8ea572a9a5a` |
| Standalone TAR fingerprint | `66e8bf57643c447da8d7155730934c40` | `08c6f455b815f30b7eb74b0d1c99283c7f1f7c7d8595e9c6bd19dd802a4bc2ae` |
| Exact 96-selector payload scan | `2dd618b7ed3945b184563ce3bdb5d301` | `f9ec8a59a611d579eb868dab3facb8415e9db29a481c6b5801ecdac33f1f6ab7` |

The selected result gzip has SHA-256 `ce3d011238bcc8e496b43c12075fdf631cb1f72fdac5587da86c01c6f195c46c`. The accompanying JSON binds all four receipts and the exact 96-selector plan. Its binder verifies retained compressed results, member inventories, alias dispositions and the complete selector roster without opening the bootstrap source archive.
