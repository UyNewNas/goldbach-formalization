#!/usr/bin/env python3
"""Fingerprint only the 39 fixed stored ZIP members; do not decode their payloads."""
import argparse
import base64
import gzip
import hashlib
import json
import os
from pathlib import Path
import resource
import stat
import struct
import time
import zipfile
import zlib

MANIFEST = json.loads('{"archives":[{"path":"/workspace/p210-public-receiver-20261125/.lake/p210-public-receiver/inputs/bootstrap.zip","bytes":413971373,"sha256":"8a3e7275fafe9b5b0046a541d320fd4669dd413a5444384ff782c3873d16c76c","members":[{"ordinal":1,"member_name":"bootstrap.tar.gz","bytes":413971227,"compressed_bytes":413971227,"crc32":"0b69dc8c","header_offset":0,"compression_method":0,"expected_sha256":"e17d879ab60ad21874b8b26ce20075a1b646af82ee18cf00749773ba5dc37370","candidate_kind":"known_unread_gzip_identity","candidate_prior_status":null}]},{"path":"/workspace/p210-public-receiver-20261125/.lake/p210-public-collection-45611402948-receive02/collection-tail.zip","bytes":221637364,"sha256":"7831443fff334f7fa675f443ac27dc4419335ef414012c789ed4fe5cee50352c","members":[{"ordinal":1,"member_name":"block-08.zip","bytes":6171136,"compressed_bytes":6171136,"crc32":"47b058e9","header_offset":0,"compression_method":0,"expected_sha256":"2c91a1034bea81f0cd3663e64caf793100565655ad0a189509bfe3c7600d4768","candidate_kind":"previously_covered_block","candidate_prior_status":"complete"},{"ordinal":2,"member_name":"block-10.zip","bytes":6177098,"compressed_bytes":6177098,"crc32":"f5ee0021","header_offset":6171194,"compression_method":0,"expected_sha256":"02e6200d97ed1c85acb428f8c4553bcf0a0608eb823d0eb0b9cd4dd25c3b1efa","candidate_kind":"previously_covered_block","candidate_prior_status":"complete"},{"ordinal":3,"member_name":"block-09.zip","bytes":6176302,"compressed_bytes":6176302,"crc32":"42e6361d","header_offset":12348350,"compression_method":0,"expected_sha256":"0d0297b75c9c397de1bd4783f89e00ee921d5a85dc58e0d6dc64051b88c865a0","candidate_kind":"previously_covered_block","candidate_prior_status":"complete"},{"ordinal":4,"member_name":"block-11.zip","bytes":6188735,"compressed_bytes":6188735,"crc32":"2e9da0c7","header_offset":18524710,"compression_method":0,"expected_sha256":"78f403842a6ca91c4108ed0d96a79339f6f9af0f060441b26db881fa34dea042","candidate_kind":"previously_covered_block","candidate_prior_status":"complete"},{"ordinal":5,"member_name":"block-12.zip","bytes":6167957,"compressed_bytes":6167957,"crc32":"99ab655d","header_offset":24713503,"compression_method":0,"expected_sha256":"391a503ac508d8b5e1538f3f1c06da9cfa0ce8c7da103c4c701ef921adfcd173","candidate_kind":"previously_covered_block","candidate_prior_status":"complete"},{"ordinal":6,"member_name":"block-13.zip","bytes":6184581,"compressed_bytes":6184581,"crc32":"6d4e3c2f","header_offset":30881518,"compression_method":0,"expected_sha256":"31adee1282791173dc65367222c48aa2d19f417cc7c1d6b5735f6ce2414c3e33","candidate_kind":"previously_covered_block","candidate_prior_status":"complete"},{"ordinal":7,"member_name":"block-14.zip","bytes":7252644,"compressed_bytes":7252644,"crc32":"edcdab01","header_offset":37066157,"compression_method":0,"expected_sha256":"20d3cca48fbbe17b43c229647ba78bb15944275a00c7f988f154b6843637b458","candidate_kind":"previously_covered_block","candidate_prior_status":"complete"},{"ordinal":8,"member_name":"block-15.zip","bytes":6205548,"compressed_bytes":6205548,"crc32":"121c6163","header_offset":44318859,"compression_method":0,"expected_sha256":"a0fac05a0ee09c7f3a2565e528adb76e9ace26145fbf5f53fb803b5f2a9b8ebe","candidate_kind":"previously_covered_block","candidate_prior_status":"complete"},{"ordinal":9,"member_name":"block-16.zip","bytes":6225028,"compressed_bytes":6225028,"crc32":"090792f7","header_offset":50524465,"compression_method":0,"expected_sha256":"9857cdad7b3d3669463a15746e97e95326a0b20ab1947e7733a876e6ff8bdffe","candidate_kind":"previously_covered_block","candidate_prior_status":"complete"},{"ordinal":10,"member_name":"block-17.zip","bytes":6219823,"compressed_bytes":6219823,"crc32":"8ee9ffb6","header_offset":56749551,"compression_method":0,"expected_sha256":"262a531d1b6c4e5a7f344f08f3da7abe602644b690b3ded47c923b88bd98e085","candidate_kind":"previously_covered_block","candidate_prior_status":"complete"},{"ordinal":11,"member_name":"block-18.zip","bytes":6208957,"compressed_bytes":6208957,"crc32":"2cb1a607","header_offset":62969432,"compression_method":0,"expected_sha256":"7ab05f1b3b005405b472fd837c531aee3fd009805060a70497058d43b7ea5b8d","candidate_kind":"previously_covered_block","candidate_prior_status":"complete"},{"ordinal":12,"member_name":"block-19.zip","bytes":6196462,"compressed_bytes":6196462,"crc32":"c35b8caf","header_offset":69178447,"compression_method":0,"expected_sha256":"47fe3a214d9a1a216aa9f161af886e133d33504a502891665c6ec4eb5be4ccd8","candidate_kind":"previously_covered_block","candidate_prior_status":"complete"},{"ordinal":13,"member_name":"block-20.zip","bytes":6200350,"compressed_bytes":6200350,"crc32":"3a9f9ff0","header_offset":75374967,"compression_method":0,"expected_sha256":"8260db41af6b6783b3197c8ab0f7e2252dd1be2fd7da7768d062e788a205d8cb","candidate_kind":"previously_covered_block","candidate_prior_status":"complete"},{"ordinal":14,"member_name":"block-21.zip","bytes":6189446,"compressed_bytes":6189446,"crc32":"fe8fe0f4","header_offset":81575375,"compression_method":0,"expected_sha256":"18e94126b01e152571b69026ae77b373d77cfb6f32a2bc02cae1665070ea13ef","candidate_kind":"previously_covered_block","candidate_prior_status":"complete"},{"ordinal":15,"member_name":"block-22.zip","bytes":6205733,"compressed_bytes":6205733,"crc32":"d4063bd8","header_offset":87764879,"compression_method":0,"expected_sha256":"40af4ba7bfc0e2660e4754b078bff88f38080fb3134646589318f593ee2f1994","candidate_kind":"previously_covered_block","candidate_prior_status":"complete"},{"ordinal":16,"member_name":"block-23.zip","bytes":6154301,"compressed_bytes":6154301,"crc32":"e11a91e4","header_offset":93970670,"compression_method":0,"expected_sha256":"d9c49ec384c422cd4cb57f4994149b2598413f1060b4c4224ee68eec08493489","candidate_kind":"previously_covered_block","candidate_prior_status":"complete"},{"ordinal":17,"member_name":"block-24.zip","bytes":6162146,"compressed_bytes":6162146,"crc32":"2d67cebf","header_offset":100125029,"compression_method":0,"expected_sha256":"be6e9921b38fb6daaa482a0a59d5a4dd7338a0c63bd04ca4d12794719dc6b467","candidate_kind":"previously_covered_block","candidate_prior_status":"bounded_delta_complete_by_receipt_reconciliation"},{"ordinal":18,"member_name":"block-25.zip","bytes":6176855,"compressed_bytes":6176855,"crc32":"b94d520c","header_offset":106287233,"compression_method":0,"expected_sha256":"718e2fbf650f461cb6b6bfb532e029bd0f44d8a2e688af0dc0a9b8c288fe1356","candidate_kind":"previously_covered_block","candidate_prior_status":"complete"},{"ordinal":19,"member_name":"block-26.zip","bytes":6170258,"compressed_bytes":6170258,"crc32":"42ce84ab","header_offset":112464146,"compression_method":0,"expected_sha256":"a5b56964b40d16638844ec3812313d4f1c73e8356d4e119cdf08304c227aa7dc","candidate_kind":"previously_covered_block","candidate_prior_status":"complete"},{"ordinal":20,"member_name":"block-27.zip","bytes":6173286,"compressed_bytes":6173286,"crc32":"20ea25db","header_offset":118634462,"compression_method":0,"expected_sha256":"afa191070830a184a5dfe69178fa4941b000fe07158836472d0243bac17913a8","candidate_kind":"previously_covered_block","candidate_prior_status":"complete"},{"ordinal":21,"member_name":"block-28.zip","bytes":6155107,"compressed_bytes":6155107,"crc32":"51678852","header_offset":124807806,"compression_method":0,"expected_sha256":"3ed73322e7d1955dddfe84884f20891e3d52a7aee75a1f30468795ece8798473","candidate_kind":"previously_covered_block","candidate_prior_status":"complete"},{"ordinal":22,"member_name":"block-29.zip","bytes":6201888,"compressed_bytes":6201888,"crc32":"8e9e064a","header_offset":130962971,"compression_method":0,"expected_sha256":"768bf3a1a43c9937b573d1575a7a0ab262cc51b2e1668e52b0a6912e5c6b1d4f","candidate_kind":"previously_covered_block","candidate_prior_status":"complete"},{"ordinal":23,"member_name":"block-30.zip","bytes":6193219,"compressed_bytes":6193219,"crc32":"cbeb0bb0","header_offset":137164917,"compression_method":0,"expected_sha256":"0fd5591ef113a236eb50c767273e88239584995539cb47095387ce448dc73179","candidate_kind":"previously_covered_block","candidate_prior_status":"complete"},{"ordinal":24,"member_name":"block-31.zip","bytes":6208723,"compressed_bytes":6208723,"crc32":"3bc297ac","header_offset":143358194,"compression_method":0,"expected_sha256":"b4868198d0ebc18332ceb888fa3d8e4aa27e1e64b47fecad3a86502c4fcab8ed","candidate_kind":"previously_covered_block","candidate_prior_status":"complete"},{"ordinal":25,"member_name":"block-33.zip","bytes":6214931,"compressed_bytes":6214931,"crc32":"3fd1aa5f","header_offset":149566975,"compression_method":0,"expected_sha256":"f9ab296b27c41c699ef1d493256f616dd3e83378b0805e1a334e304a1b85b6d2","candidate_kind":"previously_covered_block","candidate_prior_status":"complete"},{"ordinal":26,"member_name":"block-32.zip","bytes":6211415,"compressed_bytes":6211415,"crc32":"594f9e9e","header_offset":155781964,"compression_method":0,"expected_sha256":"ce7e0aa9e32afe78336670e5fc8b101a847682e9bdba8f13a0d38cb1188fd581","candidate_kind":"previously_covered_block","candidate_prior_status":"complete"},{"ordinal":27,"member_name":"block-34.zip","bytes":6238755,"compressed_bytes":6238755,"crc32":"b3ff1475","header_offset":161993437,"compression_method":0,"expected_sha256":"e5f01e2ba56add354d620238963bbcc92fed1a68c4b0b8d34631a626b76b3148","candidate_kind":"previously_covered_block","candidate_prior_status":"complete"},{"ordinal":28,"member_name":"block-35.zip","bytes":6184176,"compressed_bytes":6184176,"crc32":"a25b86cc","header_offset":168232250,"compression_method":0,"expected_sha256":"67bfeb40fcb78840663493ab9bdcee33e3546e8093a1805639d8de94dc33ed1c","candidate_kind":"previously_covered_block","candidate_prior_status":"complete"},{"ordinal":29,"member_name":"block-36.zip","bytes":6189774,"compressed_bytes":6189774,"crc32":"579c6e50","header_offset":174416484,"compression_method":0,"expected_sha256":"b8f4dd0f3268ae587839a309bc35d47213387f6950d00195e06fd418634e4107","candidate_kind":"previously_covered_block","candidate_prior_status":"complete"},{"ordinal":30,"member_name":"block-37.zip","bytes":6212979,"compressed_bytes":6212979,"crc32":"7fb4ec4b","header_offset":180606316,"compression_method":0,"expected_sha256":"c331a0a5940aa7ca347c86081713eac883ee9e1802394fb0a262ddd742a978b8","candidate_kind":"previously_covered_block","candidate_prior_status":"complete"},{"ordinal":31,"member_name":"block-38.zip","bytes":6199281,"compressed_bytes":6199281,"crc32":"bd0dff3d","header_offset":186819353,"compression_method":0,"expected_sha256":"3d473b44b9d5332244da91eb3f80201e1a2adac8af16a49374b3da3858327bc0","candidate_kind":"previously_covered_block","candidate_prior_status":"complete"},{"ordinal":32,"member_name":"block-39.zip","bytes":6190422,"compressed_bytes":6190422,"crc32":"3dd532a6","header_offset":193018692,"compression_method":0,"expected_sha256":"462f6a79cd717c0819065d29f67d37e55f2753ef163041051f769584865505ad","candidate_kind":"previously_covered_block","candidate_prior_status":"complete"},{"ordinal":33,"member_name":"block-41.zip","bytes":6170878,"compressed_bytes":6170878,"crc32":"6421ad4e","header_offset":199209172,"compression_method":0,"expected_sha256":"1b34cd739449d2612a648579b61a3a693f6c68629e0e21c0d81ab3e380f45047","candidate_kind":"previously_covered_block","candidate_prior_status":"complete"},{"ordinal":34,"member_name":"block-40.zip","bytes":6186958,"compressed_bytes":6186958,"crc32":"4f862bf5","header_offset":205380108,"compression_method":0,"expected_sha256":"63ca4da18d38fa0b078e4735cae103f519b095db7564f658f89e1b63c46ea37e","candidate_kind":"previously_covered_block","candidate_prior_status":"complete"},{"ordinal":35,"member_name":"block-42.zip","bytes":6156807,"compressed_bytes":6156807,"crc32":"c6500000","header_offset":211567124,"compression_method":0,"expected_sha256":"399ce591c9ed79d7d069c2cfd117d4b9ef762868bcd80517bb935ec46eb3101b","candidate_kind":"previously_covered_block","candidate_prior_status":"complete"},{"ordinal":36,"member_name":"block-43.zip","bytes":1362597,"compressed_bytes":1362597,"crc32":"ec95f196","header_offset":217723989,"compression_method":0,"expected_sha256":"af382e0cb2b075fc0f86077a33a67d2a0f41efa8be734de00dd3fce4f90e7c45","candidate_kind":"previously_covered_block","candidate_prior_status":"complete"},{"ordinal":37,"member_name":"index.json","bytes":2542377,"compressed_bytes":2542377,"crc32":"784ed487","header_offset":219086644,"compression_method":0,"expected_sha256":null,"candidate_kind":"unclassified_json_member","candidate_prior_status":null},{"ordinal":38,"member_name":"tail.json","bytes":6011,"compressed_bytes":6011,"crc32":"433ef521","header_offset":221629077,"compression_method":0,"expected_sha256":null,"candidate_kind":"unclassified_json_member","candidate_prior_status":null}]}],"caps":{"outer_files":2,"stored_members":39,"outer_sequential_bytes":635608737,"member_bytes_fingerprinted":635604171,"metadata_only_member_bytes":2548388,"main_buffer_bytes":1048576,"max_raw_read_bytes":734003200,"max_central_directory_bytes":1048576,"max_deadline_seconds":240,"address_space_bytes":268435456,"temporary_payload_bytes":0,"source_payload_format_decodes":0},"scope":"Fingerprint-only fixed ZIP_STORED byte ranges; never decode gzip, tar, nested ZIP, or JSON payloads."}')
CHUNK = 1024 * 1024


class Boundary(Exception):
    pass


def stamp(s):
    return (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)


def tick(deadline):
    if time.monotonic()>deadline:
        raise Boundary('deadline')


def fingerprint_archive(row,deadline,chunk_size=CHUNK):
    """Read fixed ZIP_STORED ranges and hash outer bytes in the same sequential pass."""
    path=Path(row['path'])
    if path.resolve(strict=True)!=path:
        raise Boundary('redirected input path')
    initial=path.lstat()
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK)
    with os.fdopen(fd,'rb') as stream:
        opened=os.fstat(stream.fileno())
        if stamp(initial)!=stamp(opened) or not stat.S_ISREG(opened.st_mode) or opened.st_size!=row['bytes']:
            raise Boundary('input stat/type/size differs')
        end=zipfile._EndRecData(stream)
        if end is None:
            raise Boundary('missing ZIP end record')
        if end[zipfile._ECD_SIZE]>MANIFEST['caps']['max_central_directory_bytes']:
            raise Boundary('central directory exceeds cap')
        if end[zipfile._ECD_ENTRIES_TOTAL]!=len(row['members']):
            raise Boundary('ZIP member count differs')
        directory_start=end[zipfile._ECD_OFFSET]
        if not (0<=directory_start<=row['bytes'] and directory_start+end[zipfile._ECD_SIZE]<=row['bytes']):
            raise Boundary('invalid central directory bounds')
        stream.seek(0)
        with zipfile.ZipFile(stream) as archive:
            infos=archive.infolist()
            if len(infos)!=len(row['members']):
                raise Boundary('materialized ZIP count differs')
            ranges=[]
            for expected,info in zip(row['members'],infos):
                tick(deadline)
                actual=dict(ordinal=expected['ordinal'],member_name=info.filename,
                            bytes=info.file_size,compressed_bytes=info.compress_size,
                            crc32=f'{info.CRC:08x}',header_offset=info.header_offset,
                            compression_method=info.compress_type)
                if expected['ordinal']!=len(ranges)+1 or any(actual[k]!=expected[k] for k in actual):
                    raise Boundary('central member selector differs: '+expected['member_name'])
                if info.compress_type!=zipfile.ZIP_STORED or info.file_size!=info.compress_size or info.flag_bits&1:
                    raise Boundary('member is not unencrypted ZIP_STORED')
                stream.seek(info.header_offset)
                header=stream.read(30)
                if len(header)!=30:
                    raise Boundary('short local file header')
                sig,version,flags,method,mt,md,crc,cs,us,nlen,xlen=struct.unpack('<4sHHHHHIIIHH',header)
                if sig!=b'PK\x03\x04' or method!=0 or flags&1 or flags!=info.flag_bits:
                    raise Boundary('local file header differs')
                name=stream.read(nlen)
                if name!=expected['member_name'].encode('ascii'):
                    raise Boundary('local member filename differs')
                if not flags&8 and (crc,cs,us)!=(info.CRC,info.compress_size,info.file_size):
                    raise Boundary('local sizes/CRC differ from central metadata')
                start=info.header_offset+30+nlen+xlen
                stop=start+info.file_size
                if not 0<=start<=stop<=directory_start:
                    raise Boundary('stored payload range outside data area')
                ranges.append(dict(**actual,data_start=start,data_end=stop,
                                   expected_sha256=expected.get('expected_sha256'),
                                   candidate_kind=expected.get('candidate_kind'),
                                   candidate_prior_status=expected.get('candidate_prior_status'),
                                   hasher=hashlib.sha256(),crc=0,observed_bytes=0))
            ordered=sorted(ranges,key=lambda x:x['data_start'])
            for a,b in zip(ordered,ordered[1:]):
                if a['data_end']>b['header_offset']:
                    raise Boundary('overlapping stored member ranges')
            stream.seek(0)
            outer=hashlib.sha256()
            offset=0
            selected=0
            while offset<row['bytes']:
                tick(deadline)
                chunk=stream.read(min(chunk_size,row['bytes']-offset))
                if not chunk:
                    raise Boundary('early EOF')
                outer.update(chunk)
                endpos=offset+len(chunk)
                while selected<len(ordered):
                    item=ordered[selected]
                    if item['data_end']<=offset:
                        selected+=1
                        continue
                    if item['data_start']>=endpos:
                        break
                    lo=max(offset,item['data_start'])
                    hi=min(endpos,item['data_end'])
                    if hi>lo:
                        part=memoryview(chunk)[lo-offset:hi-offset]
                        item['hasher'].update(part)
                        item['crc']=zlib.crc32(part,item['crc'])
                        item['observed_bytes']+=len(part)
                    if item['data_end']<=endpos:
                        selected+=1
                    else:
                        break
                offset=endpos
            if stream.read(1):
                raise Boundary('unexpected bytes after expected outer length')
            actual_outer=outer.hexdigest()
            if actual_outer!=row['sha256']:
                raise Boundary('outer SHA256 differs: '+actual_outer)
            if stamp(opened)!=stamp(os.fstat(stream.fileno())) or stamp(opened)!=stamp(path.lstat()):
                raise Boundary('input changed during metadata/hash read')
            results=[]
            for item in ranges:
                if item['observed_bytes']!=item['bytes']:
                    raise Boundary('member range count differs: '+item['member_name'])
                if (item['crc']&0xffffffff)!=int(item['crc32'],16):
                    raise Boundary('member CRC differs: '+item['member_name'])
                digest=item['hasher'].hexdigest()
                result={k:v for k,v in item.items() if k not in ('hasher','crc')}
                result.update(sha256=digest,
                              matches_expected_candidate=(digest==item['expected_sha256']) if item['expected_sha256'] else None,
                              payload_format_decoded=False,source_coverage_granted=False)
                results.append(result)
    return dict(path=row['path'],bytes=row['bytes'],sha256=actual_outer,
                status='outer_and_stored_member_fingerprints_verified',
                outer_sequential_bytes=offset,member_bytes_fingerprinted=sum(x['observed_bytes'] for x in results),
                member_fingerprints=results,input_stat_unchanged=True,
                metadata_read='Central directory and fixed local headers only; no ZipFile.open/read payload decoding.')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out',type=Path,required=True)
    parser.add_argument('--seconds',type=int,default=240)
    args=parser.parse_args()
    seconds=min(args.seconds,MANIFEST['caps']['max_deadline_seconds'])
    if seconds<=0:
        raise SystemExit('seconds must be positive')
    cap=MANIFEST['caps']['address_space_bytes']
    _,hard=resource.getrlimit(resource.RLIMIT_AS)
    resource.setrlimit(resource.RLIMIT_AS,(min(cap,hard) if hard!=resource.RLIM_INFINITY else cap,hard))
    if sum(x['bytes'] for x in MANIFEST['archives'])>MANIFEST['caps']['max_raw_read_bytes']:
        raise SystemExit('manifest exceeds raw input byte cap')
    args.out.mkdir(parents=True,exist_ok=False)
    started=time.monotonic()
    result=dict(scope=MANIFEST['scope'],status='running',caps=MANIFEST['caps'],
                script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                archives=[],boundaries=[],source_payload_format_decodes=0,
                network_operations=0,temporary_payload_bytes=0,source_coverage_granted=False)
    for row in MANIFEST['archives']:
        try:
            result['archives'].append(fingerprint_archive(row,started+seconds))
        except Exception as error:
            result['boundaries'].append(dict(path=row['path'],kind=type(error).__name__,detail=str(error)))
    result['status']='fingerprints_verified_only' if not result['boundaries'] else 'partial_fingerprints_only'
    result['elapsed_seconds']=round(time.monotonic()-started,3)
    raw=(json.dumps(result,indent=2)+'\n').encode()
    with (args.out/'result.json').open('xb') as f:
        f.write(raw)
    compressed=gzip.compress(raw,mtime=0)
    with (args.out/'result.json.gz').open('xb') as f:
        f.write(compressed)
    print(json.dumps(dict(status=result['status'],result_path=str(args.out/'result.json'),
                          bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),
                          gzip_bytes=len(compressed),gzip_sha256=hashlib.sha256(compressed).hexdigest(),
                          boundaries=len(result['boundaries']),elapsed_seconds=result['elapsed_seconds'])),flush=True)
    print('P34_LARGE_MEMBER_FINGERPRINTS_GZIP_BASE64 '+base64.b64encode(compressed).decode(),flush=True)
    return 1 if result['boundaries'] else 0


if __name__=='__main__':
    raise SystemExit(main())
