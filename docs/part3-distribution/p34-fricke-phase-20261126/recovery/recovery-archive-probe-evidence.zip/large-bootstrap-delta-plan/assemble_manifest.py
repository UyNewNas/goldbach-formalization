#!/usr/bin/env python3
"""Rebuild the exact bootstrap exclusions from pinned resident metadata receipts."""
import argparse
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import resource
import stat
import time

SEED_SHA = '75332cab445e19c12d2f5bf3a61dcef36a91d55c7fbc9496354a6747a4ca7e09'
MANIFEST_SHA = 'bb38a378d1d46334fb15a3151dba1d8df80129f5ee3462025a644ff18145f67b'
INVENTORIES = ('cloud-recovery-first_inventory', 'rescue-priority_inventory',
               'rescue-receipts_inventory', 'v3-priority_inventory', 'v3-receipts_inventory')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def canonical(value):
    return (json.dumps(value, indent=2, ensure_ascii=True, sort_keys=True) + '\n').encode()


def pinned(path, expected, cap, size=None):
    flags = os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC
    fd = os.open(path, flags)
    with os.fdopen(fd, 'rb') as source:
        before = os.fstat(source.fileno())
        if not stat.S_ISREG(before.st_mode):
            raise ValueError('pinned metadata input is not a regular file')
        raw = source.read(cap + 1)
        after = os.fstat(source.fileno())
    stamp = lambda st: (st.st_dev, st.st_ino, st.st_size, st.st_ctime_ns, st.st_mtime_ns)
    if len(raw) > cap or sha(raw) != expected or stamp(before) != stamp(after) or (size is not None and len(raw) != size):
        raise ValueError('metadata input failed fixed length, digest, or stability: ' + str(path))
    return raw


def build(seed, mapping=None):
    deadline = time.monotonic() + 90
    complete = {}
    blocked = {}
    verified = []

    def tick():
        if time.monotonic() > deadline:
            raise ValueError('manifest metadata assembly deadline reached')

    def source(role):
        tick()
        expected = seed['resident_inputs'][role]
        path = Path(mapping[role] if mapping else expected['path'])
        raw = pinned(path, expected['sha256'], 1 << 20, expected['bytes'])
        verified.append({'role': role, 'path': str(path), 'bytes': len(raw), 'sha256': sha(raw)})
        return raw

    def add(identity, size, receipt, scope):
        previous = complete.get(identity)
        if previous and previous[0] is not None and size is not None and previous[0] != size:
            raise ValueError('inconsistent length for a completed identity')
        if previous is None:
            complete[identity] = [size, receipt, scope]
        elif previous[0] is None and size is not None:
            previous[0] = size

    original_scope = 'inherit_original_target_and_decoder_scope'
    base = json.loads(source('base_allowlist'))
    packed = base['prior_selected_and_complete_sha256']
    identities = {packed[i:i + 64] for i in range(0, len(packed), 64)}
    complement = set(seed['base_allowlist_minus_old1452'])
    if not complement <= identities or len(identities - complement) != 1452:
        raise ValueError('resident base and small old-known complement do not reproduce 1452 identities')
    for identity in identities - complement:
        add(identity, None, 'old_known_1452', original_scope)
    for size, identity in base['excluded_complete_117']:
        add(identity, size, 'original_delta_plan', original_scope)
    for size, identity in base['prior_partial_18']:
        blocked[identity] = [size, 'original_delta_plan', 'prior_partial_region_owned_by_separate_delta']
    for identity in identities:
        add(identity, None, 'base_allowlist', original_scope)

    for identity, size, receipt, scope in seed['local_completed_additions']:
        add(identity, size, receipt, scope)
    closed = set(seed['explicitly_closed_local_bundles'])
    repair = json.loads(source('first_reconciled_allowlist'))
    for size, identity in repair['first_finished_fingerprints']:
        add(identity, size, 'first_reconciled_allowlist', 'three_targets_bounded_payload')
    for label in ('block24', 'p29_xz', 'p29_gzip_duplicate'):
        row = base['input'][label]
        add(row['sha256'], row['bytes'], 'first_reconciliation',
            'combined_prior_scope_and_three_target_missing_delta_only')
        closed.add(row['sha256'])

    event_count = 0
    decoded_bytes = 0
    for role in INVENTORIES:
        raw = source(role)
        file_decoded = 0
        with gzip.GzipFile(fileobj=io.BytesIO(raw), mode='rb') as stream:
            while True:
                tick()
                line = stream.readline((1 << 20) + 1)
                if not line:
                    break
                file_decoded += len(line)
                decoded_bytes += len(line)
                if len(line) > 1 << 20 or file_decoded > 64 << 20:
                    raise ValueError('resident metadata receipt exceeded line or expansion cap')
                row = json.loads(line)
                event_count += 1
                checked = ((row.get('kind') == 'member_payload' and row.get('status') == 'checked')
                           or (row.get('kind') == 'decompressed' and row.get('payload_status') == 'checked'))
                if checked:
                    add(row['sha256'], row['bytes'], role, 'three_targets_with_inherited_exclusions')
                partial = ((row.get('kind') == 'member_payload' and row.get('status') == 'partial')
                           or (row.get('kind') == 'decompressed' and row.get('payload_status') == 'partial'))
                if partial:
                    blocked[row['sha256']] = [row['bytes'], role, 'prior_partial_owned_by_other_delta']
    for identity in closed:
        blocked.pop(identity, None)
    for identity in list(blocked):
        if identity in complete and complete[identity][1] in ('v3-priority_inventory', 'v3-receipts_inventory'):
            blocked.pop(identity)
    identity, size, receipt, scope = seed['reconciled_collection_tail']
    add(identity, size, receipt, scope)
    manifest = dict(seed['manifest_skeleton'])
    manifest['completed'] = [[identity, *row] for identity, row in sorted(complete.items()) if identity not in blocked]
    manifest['blocked_partial'] = [[identity, *row] for identity, row in sorted(blocked.items())]
    if (len(manifest['completed']) != seed['expected_completed_count']
            or len(manifest['blocked_partial']) != seed['expected_blocked_count']):
        raise ValueError('reconstructed identity counts differ')
    encoded = canonical(manifest)
    if len(encoded) != seed['expected_manifest_bytes'] or sha(encoded) != MANIFEST_SHA or sha(encoded) != seed['expected_manifest_sha256']:
        raise ValueError('rebuilt manifest is not byte-identical to the locally reviewed canonical plan')
    identity_document = {'completed': [row[:2] for row in manifest['completed']],
                         'blocked_partial': [row[:2] for row in manifest['blocked_partial']]}
    receipt = {'status': 'byte_exact_manifest_reconstructed_from_pinned_metadata',
               'manifest_bytes': len(encoded), 'manifest_sha256': sha(encoded),
               'sorted_identity_digest': sha(canonical(identity_document)),
               'completed_count': len(manifest['completed']), 'blocked_count': len(manifest['blocked_partial']),
               'verified_resident_inputs': verified, 'receipt_events_read': event_count,
               'decoded_receipt_bytes': decoded_bytes, 'source_payloads_read': 0,
               'new_local_identity_additions': len(seed['local_completed_additions']),
               'old_known_complement_count': len(seed['base_allowlist_minus_old1452'])}
    return encoded, receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--seed', type=Path, default=Path(__file__).with_name('assembly-seed.json'))
    parser.add_argument('--out', type=Path, default=Path(__file__).with_name('bootstrap-manifest.json'))
    parser.add_argument('--receipt-map', type=Path, help='Optional exact role/path mapping; every role remains SHA/length pinned.')
    args = parser.parse_args()
    if not args.out.is_absolute() or args.out.parent.resolve() != args.out.parent:
        raise ValueError('manifest output needs an absolute path and canonical existing parent')
    soft, hard = resource.getrlimit(resource.RLIMIT_AS)
    limit = min(value for value in (256 << 20, soft, hard) if value != resource.RLIM_INFINITY)
    resource.setrlimit(resource.RLIMIT_AS, (limit, hard))
    seed = json.loads(pinned(args.seed, SEED_SHA, 64 << 10))
    mapping = None
    if args.receipt_map:
        with args.receipt_map.open('rb') as source:
            raw = source.read((16 << 10) + 1)
        if len(raw) > 16 << 10:
            raise ValueError('receipt-map size cap')
        mapping = json.loads(raw)
        if set(mapping) != set(seed['resident_inputs']):
            raise ValueError('receipt-map must contain exactly the seven pinned roles')
    raw, receipt = build(seed, mapping)
    with args.out.open('xb') as destination:
        destination.write(raw)
    receipt['manifest_path'] = str(args.out)
    receipt['seed_sha256'] = SEED_SHA
    receipt['assembler_sha256'] = sha(Path(__file__).read_bytes())
    with args.out.with_name('manifest-assembly-receipt.json').open('xb') as destination:
        destination.write(canonical(receipt))
    print(json.dumps(receipt, sort_keys=True))


if __name__ == '__main__':
    main()
