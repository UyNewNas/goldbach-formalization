#!/usr/bin/env python3
"""Fingerprint one pinned bootstrap TAR stream, retaining only exact source matches."""
import argparse
import base64
from collections import Counter
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import resource
import tarfile
import time
from types import ModuleType
import zlib

BASE_SCANNER_SHA = 'e7296a56eae0df9f1cd8a1a7697c27755deb2556f8a1dac8c21af0ec0e1ebb45'
MANIFEST_GZIP_SHA = '9e35823ede635206e0e1f905acada420c1ee2ea9436a7f86e4559498d7fafed9'
MANIFEST_SHA = 'bb38a378d1d46334fb15a3151dba1d8df80129f5ee3462025a644ff18145f67b'
ALLOWED = {
    'path': '/workspace/p210-public-receiver-20261125/.lake/p210-public-receiver/inputs/bootstrap.tar.gz',
    'bytes': 413971227,
    'sha256': 'e17d879ab60ad21874b8b26ce20075a1b646af82ee18cf00749773ba5dc37370',
}
CHUNK = 256 << 10
MAX_MEMBERS = 50000
MAX_INVENTORY = 64 << 20
MAX_TAR = 4 << 30
MAX_ADDRESS = 256 << 20


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def canonical(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(',', ':')) + '\n').encode()


def read_pinned(path, expected, cap):
    with path.open('rb') as source:
        raw = source.read(cap + 1)
    if len(raw) > cap or sha(raw) != expected:
        raise ValueError('helper or manifest failed pinned SHA/size bound: ' + str(path))
    return raw


def load_base(path):
    raw = read_pinned(path, BASE_SCANNER_SHA, 100000)
    module = ModuleType('p34_frozen_archive_helpers')
    module.__file__ = str(path)
    # This is the previously authored, SHA-pinned scanner, never recovered archive code.
    exec(compile(raw, str(path), 'exec'), module.__dict__)
    return module


def load_manifest(path):
    if path.name.endswith('.gz'):
        raw = read_pinned(path, MANIFEST_GZIP_SHA, 2 << 20)
        decoder = zlib.decompressobj(31)
        decoded = decoder.decompress(raw, (8 << 20) + 1)
        if len(decoded) > 8 << 20 or not decoder.eof or decoder.unused_data or decoder.unconsumed_tail:
            raise ValueError('manifest gzip exceeded bound or had an incomplete/trailing stream')
    else:
        decoded = read_pinned(path, MANIFEST_SHA, 8 << 20)
    if sha(decoded) != MANIFEST_SHA:
        raise ValueError('manifest decoded identity differs')
    manifest = json.loads(decoded)
    if manifest['input'] != ALLOWED:
        raise ValueError('manifest input is outside exact allowlist')
    for target in manifest['targets']:
        if not re.fullmatch(r'Part3[A-Za-z0-9]+\.lean', target['filename']):
            raise ValueError('target export filename is not fixed safe source syntax')
    return manifest


class Probe:
    def __init__(self, base, manifest, inventory, seconds, expanded_limit=MAX_TAR):
        self.base = base
        self.manifest = manifest
        self.inventory = inventory
        self.deadline = time.monotonic() + seconds
        self.expanded_limit = expanded_limit
        self.expanded = 0
        self.inventory_bytes = 0
        self.counts = Counter()
        self.boundaries = []
        self.current_member = None
        self.last_fingerprinted_member = None
        self.next_member = None
        self.seen = {}
        self.matches = {}
        self.match_locations = {}
        self.outer_verified = False
        self.input_unchanged = False
        self.tar_eof = False
        self.gzip_eof = False
        self.tar_identity = None
        self.compressed_replay_identity = None
        self.completed = {row[0]: row for row in manifest['completed']}
        self.blocked = {row[0]: row for row in manifest['blocked_partial']}
        if len(self.completed) != len(manifest['completed']) or len(self.blocked) != len(manifest['blocked_partial']):
            raise ValueError('duplicate manifest identities')
        if set(self.completed) & set(self.blocked):
            raise ValueError('completed and blocked manifest sets overlap')
        self.target_by_size = {row['bytes']: row for row in manifest['targets']}
        if len(self.target_by_size) != 3:
            raise ValueError('expected three distinct fixed source lengths')
        if {row['sha256'] for row in manifest['targets']} & (set(self.completed) | set(self.blocked)):
            raise ValueError('authentic source target must not be excluded')

    def check_time(self):
        self.base.limit(time.monotonic() > self.deadline, 'deadline', 'monotonic probe deadline reached', True)

    def charge(self, amount):
        self.expanded += amount
        self.base.limit(self.expanded > self.expanded_limit, 'tar_expansion_cap',
                        'decoded TAR exceeded bounded streaming work allowance', True)

    def event(self, kind, **row):
        raw = canonical({'kind': kind, **row})
        self.base.limit(self.inventory_bytes + len(raw) > MAX_INVENTORY,
                        'inventory_cap', 'metadata receipt exceeded 64 MiB', True)
        self.inventory.write(raw)
        self.inventory_bytes += len(raw)

    def boundary(self, kind, detail):
        row = {'kind': kind, 'detail': str(detail)[:4000], 'member': self.current_member,
               'last_fingerprinted_member': self.last_fingerprinted_member,
               'next_member': self.next_member}
        self.boundaries.append(row)
        if self.inventory_bytes < MAX_INVENTORY - 16384:
            self.event('boundary', **{key: value for key, value in row.items() if key != 'kind'}, boundary=kind)

    def classify(self, identity, size, selector):
        if identity in self.completed:
            row = self.completed[identity]
            self.base.limit(row[1] is not None and row[1] != size, 'completed_length_conflict',
                            'member SHA matched a completed identity with a different recorded size')
            return 'prior_complete_identity_excluded', {'receipt': row[2], 'inherited_scope': row[3]}
        if identity in self.blocked:
            row = self.blocked[identity]
            self.base.limit(row[1] is not None and row[1] != size, 'partial_length_conflict',
                            'member SHA matched a blocked identity with a different recorded size')
            return 'prior_partial_identity_deferred', {'receipt': row[2], 'reason': row[3]}
        if identity in self.seen:
            return 'same_run_identity', {'first_selector': self.seen[identity]}
        self.seen[identity] = {key: selector[key] for key in
                               ('ordinal', 'bytes', 'header_offset', 'data_offset')}
        return 'new_unread_payload_identity', {}

    def fingerprint_tar(self, source, parent):
        base = self.base
        with tarfile.open(fileobj=source, mode='r|', tarinfo=base.BoundedTarInfo, bufsize=CHUNK) as archive:
            for ordinal, member in enumerate(archive, 1):
                self.check_time()
                selector = {'outer_sha256': self.manifest['input']['sha256'], 'ordinal': ordinal,
                            'member_name': member.name, 'bytes': member.size,
                            'header_offset': member.offset, 'data_offset': member.offset_data,
                            'type': member.type.decode('ascii', 'replace')}
                if len(member.name) > 4096:
                    selector['member_name'] = member.name[:1024]
                    selector['member_name_sha256'] = sha(member.name.encode('utf-8', 'surrogatepass'))
                    self.current_member = selector
                    raise base.Boundary('member_name_cap', 'TAR name exceeds 4096 characters', True)
                self.current_member = {**selector, 'payload_bytes_fingerprinted': 0}
                self.next_member = selector
                base.limit(ordinal > MAX_MEMBERS, 'member_count_cap', 'TAR member count exceeds 50000', True)
                base.limit(member.size < 0 or member.offset_data + member.size > (1 << 63) - 1,
                           'tar_member_extent', 'invalid TAR member extent', True)
                self.counts['tar_headers'] += 1
                self.event('tar_header', **selector, canonical_member_name=base.valid_member(member.name),
                           link_name=member.linkname[:4096] if member.linkname else None)
                regular = member.type in (tarfile.REGTYPE, tarfile.AREGTYPE, tarfile.CONTTYPE) and not member.sparse
                if not regular:
                    self.counts['directory_headers' if member.isdir() else 'nonregular_headers'] += 1
                    if not member.isdir():
                        self.event('nonregular_unresolved', **selector,
                                   reason='metadata only; no link resolution or special-file read')
                    archive.members.clear()
                    continue
                retained = bytearray() if member.size in self.target_by_size else None
                fingerprint = hashlib.sha256()
                first = bytearray()
                remaining = member.size
                with archive.extractfile(member) as stream:
                    while remaining:
                        self.check_time()
                        block = stream.read(min(CHUNK, remaining))
                        base.limit(not block, 'member_truncated', 'regular member ended before declared size', True)
                        fingerprint.update(block)
                        if len(first) < 512:
                            first.extend(block[:512 - len(first)])
                        if retained is not None:
                            retained.extend(block)
                        remaining -= len(block)
                        self.current_member['payload_bytes_fingerprinted'] += len(block)
                identity = fingerprint.hexdigest()
                selector = {**selector, 'sha256': identity}
                status, inherited = self.classify(identity, member.size, selector)
                self.counts[status] += 1
                self.counts['regular_member_bytes_fingerprinted'] += member.size
                self.counts['regular_members_fingerprinted'] += 1
                candidate = self.target_by_size.get(member.size)
                direct_match = bool(candidate and identity == candidate['sha256'])
                if candidate:
                    self.counts['fixed_length_direct_source_candidates'] += 1
                if direct_match:
                    name = candidate['filename']
                    self.matches[name] = bytes(retained)
                    self.match_locations.setdefault(name, []).append(selector)
                    self.counts['direct_exact_matches'] += 1
                self.event('member_fingerprint', **selector, classification=status,
                           codec_hint=base.codec(bytes(first), base.name_of(member.name)),
                           direct_target_match=candidate['filename'] if direct_match else None,
                           content_decoded=False, **inherited)
                self.last_fingerprinted_member = selector
                self.current_member = None
                self.next_member = None
                archive.members.clear()
            base.limit(not archive._delta_end, 'tar_end_marker', 'missing or malformed first TAR zero block', True)
            base.limit(archive.fileobj.read(512) != bytes(512), 'tar_end_marker', 'missing second TAR zero block', True)
            while True:
                self.check_time()
                tail = archive.fileobj.read(CHUNK)
                if not tail:
                    break
                base.limit(any(tail), 'tar_nonzero_tail', 'nonzero bytes after TAR end markers', True)
            self.tar_eof = True
            self.event('tar_end_verified', zero_tail_only=True)

    def run(self, row):
        base = self.base
        with base.regular_file(row['path']) as source:
            before = base.stamp(source)
            base.limit(before[2] != row['bytes'], 'outer_size', 'bootstrap size differs from exact identity', True)
            identity = base.Meter(source, self, row['bytes']).finish()
            base.limit(identity != {'bytes': row['bytes'], 'sha256': row['sha256']},
                       'outer_sha', 'bootstrap compressed SHA differs', True)
            base.limit(base.stamp(source) != before, 'input_changed', 'bootstrap changed during verification', True)
            self.outer_verified = True
            self.event('outer_identity_verified', **identity, path=row['path'])
            source.seek(0)
            compressed = base.Meter(source, self, row['bytes'])
            try:
                with gzip.GzipFile(fileobj=compressed, mode='rb') as expanded:
                    meter = base.Meter(expanded, self, expanded=True)
                    self.fingerprint_tar(meter, row['path'])
                    self.tar_identity = meter.finish()
                    self.gzip_eof = True
                self.compressed_replay_identity = compressed.finish()
                base.limit(self.compressed_replay_identity != identity, 'compressed_replay_identity',
                           'compressed replay SHA/length differs from preverified input', True)
                self.event('gzip_eof_verified', tar_identity=self.tar_identity,
                           compressed_identity=self.compressed_replay_identity)
            finally:
                self.input_unchanged = base.stamp(source) == before
                base.limit(not self.input_unchanged, 'input_changed', 'bootstrap changed during streaming', True)


def arguments():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', type=Path, default=Path(__file__).with_name('bootstrap-manifest.json'))
    parser.add_argument('--base-scanner', type=Path,
                        default=Path('/workspace/p34-recovery-runner-20261126/recover_archive_delta.py'))
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--seconds', type=int, default=240)
    parser.add_argument('--expanded-limit', type=int, default=MAX_TAR)
    return parser.parse_args()


def main():
    args = arguments()
    if not 1 <= args.seconds <= 240 or not 1 <= args.expanded_limit <= MAX_TAR:
        raise ValueError('seconds or expanded limit exceeds the approved bounded plan')
    if not args.out.is_absolute() or args.out.parent.resolve() != args.out.parent:
        raise ValueError('output needs an absolute path with a canonical existing parent')
    soft, hard = resource.getrlimit(resource.RLIMIT_AS)
    address = min(value for value in (MAX_ADDRESS, soft, hard) if value != resource.RLIM_INFINITY)
    resource.setrlimit(resource.RLIMIT_AS, (address, hard))
    base = load_base(args.base_scanner)
    manifest = load_manifest(args.manifest)
    args.out.mkdir(mode=0o700, exist_ok=False)
    start = time.monotonic()
    inventory_path = args.out / 'member-fingerprints.jsonl.gz'
    with gzip.open(inventory_path, 'xb', compresslevel=4) as inventory:
        probe = Probe(base, manifest, inventory, args.seconds, args.expanded_limit)
        try:
            probe.run(ALLOWED)
        except base.Boundary as exc:
            probe.boundary(exc.kind, exc)
        except (OSError, EOFError, ValueError, tarfile.TarError, zlib.error, MemoryError, RecursionError) as exc:
            probe.boundary('format_io_or_memory_error', type(exc).__name__ + ': ' + str(exc))
    exact = []
    if probe.outer_verified and probe.input_unchanged:
        for target in manifest['targets']:
            name = target['filename']
            raw = probe.matches.get(name)
            if raw is None:
                continue
            if len(raw) != target['bytes'] or sha(raw) != target['sha256']:
                raise ValueError('retained exact match failed its final source authentication')
            destination = args.out / name
            with destination.open('xb') as stream:
                stream.write(raw)
            exact.append({'filename': name, 'bytes': len(raw), 'sha256': sha(raw),
                          'path': str(destination), 'locations': probe.match_locations[name],
                          'base64': base64.b64encode(raw).decode('ascii')})
    inventory_hash = hashlib.sha256()
    inventory_size = 0
    with inventory_path.open('rb') as stream:
        for block in iter(lambda: stream.read(CHUNK), b''):
            inventory_hash.update(block)
            inventory_size += len(block)
    report = {
        'status': 'partial_fingerprint_inventory' if probe.boundaries else 'fingerprint_inventory_complete',
        'input': ALLOWED, 'script_sha256': sha(Path(__file__).read_bytes()),
        'base_scanner_sha256': BASE_SCANNER_SHA, 'manifest_sha256': MANIFEST_SHA,
        'manifest_gzip_sha256': MANIFEST_GZIP_SHA,
        'scope': 'One exact gzip transport. Regular TAR member SHA and length only. No JSON strings, text encodings, nested payloads, Git objects, or code execution.',
        'input_outer_identity_verified': probe.outer_verified, 'input_stat_unchanged': probe.input_unchanged,
        'tar_end_verified': probe.tar_eof, 'gzip_eof_verified': probe.gzip_eof,
        'tar_identity': probe.tar_identity, 'compressed_replay_identity': probe.compressed_replay_identity,
        'completed_identity_exclusions': len(probe.completed), 'blocked_partial_identities': len(probe.blocked),
        'counts': dict(probe.counts), 'boundaries': probe.boundaries,
        'last_fingerprinted_member': probe.last_fingerprinted_member, 'next_member': probe.next_member,
        'decoded_tar_bytes': probe.expanded,
        'nested_member_payload_decodes': 0, 'spooled_payload_bytes': 0,
        'direct_source_matches': exact,
        'source_coverage_limit': 'Only exact whole regular member targets are compared in this phase; new member contents remain unread and require exact future selectors. Prior exclusions inherit their original scope without extension.',
        'caps': {**manifest['caps'], 'seconds': args.seconds, 'expanded_tar_bytes': args.expanded_limit,
                 'address_space_bytes': address},
        'inventory': {'path': str(inventory_path), 'bytes': inventory_size, 'sha256': inventory_hash.hexdigest(),
                      'raw_bytes': probe.inventory_bytes},
        'elapsed_seconds': round(time.monotonic() - start, 3),
    }
    raw = canonical(report)
    with (args.out / 'result.json').open('xb') as destination:
        destination.write(raw)
    packed = gzip.compress(raw, mtime=0)
    with (args.out / 'result.json.gz').open('xb') as destination:
        destination.write(packed)
    print(json.dumps({'status': report['status'], 'counts': report['counts'],
                      'boundaries': len(report['boundaries']), 'exact_matches': [r['filename'] for r in exact],
                      'result_gzip_sha256': sha(packed), 'inventory': report['inventory']}))
    print('P34_BOOTSTRAP_FINGERPRINTS_GZIP_BASE64 ' + base64.b64encode(packed).decode('ascii'))


if __name__ == '__main__':
    main()
