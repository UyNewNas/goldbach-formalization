#!/usr/bin/env python3
"""Inspect exact P2.1 XZ structure and decoder requirements without decoding payloads."""
import argparse
import base64
import gzip
import hashlib
import json
from pathlib import Path
import resource
import time
from types import ModuleType

HELPER_SHA = '5be123aae98a3dffd544f9e66f111be4f2ef88660248cc1ee5f86be0790b88de'
ALLOWED = {
    'path': '/workspace/p21-log-audit-20261126/.lake/p21-native-restore/evidence-resume-main-20261125.slim.tar.xz',
    'bytes': 44304524,
    'sha256': '92c1067a1694ea74af4d15ee841199ab72094f2147b7651e77cf21f60e68faf4',
}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def load_helper(path):
    with path.open('rb') as source:
        raw = source.read(32769)
    if len(raw) > 32768 or sha(raw) != HELPER_SHA:
        raise ValueError('XZ metadata helper failed pinned SHA/size bound')
    module = ModuleType('p34_frozen_xz_metadata')
    module.__file__ = str(path)
    # Previously authored and SHA-pinned metadata helper, never archive content.
    exec(compile(raw, str(path), 'exec'), module.__dict__)
    return module


def observe(helper, row, seconds=90):
    deadline = time.monotonic() + seconds
    def check_time():
        helper.require(time.monotonic() <= deadline, 'P2.1 metadata deadline reached', 'deadline')
    with helper.open_regular(row['path']) as source:
        result, _ = helper.observe(source, row, check_time)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--preflight-helper', type=Path, default=Path(__file__).with_name('xz_memory_preflight.py'))
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    if not args.out.is_absolute() or args.out.parent.resolve() != args.out.parent:
        raise ValueError('output needs an absolute path and canonical existing parent')
    soft, hard = resource.getrlimit(resource.RLIMIT_AS)
    cap = min(value for value in (256 << 20, soft, hard) if value != resource.RLIM_INFINITY)
    resource.setrlimit(resource.RLIMIT_AS, (cap, hard))
    helper = load_helper(args.preflight_helper)
    args.out.mkdir(mode=0o700, exist_ok=False)
    start = time.monotonic()
    boundary = None
    measured = None
    try:
        measured = observe(helper, ALLOWED)
    except (helper.PreflightError, OSError, MemoryError) as exc:
        boundary = {'kind': getattr(exc, 'kind', type(exc).__name__), 'detail': str(exc)[:4000]}
    report = {
        'phase': 'p21_xz_metadata_only', 'status': 'partial' if boundary else 'verified_metadata',
        'input': ALLOWED, 'measurement': measured, 'boundary': boundary,
        'script_sha256': sha(Path(__file__).read_bytes()), 'helper_sha256': HELPER_SHA,
        'scope': 'One exact compressed input; SHA, XZ stream/index/block-header metadata, and liblzma decoder-memory query only.',
        'payload_decoded': False, 'tar_headers_read': 0, 'source_coverage_granted': False,
        'caps': {'address_space_bytes': cap, 'seconds': 90, 'compressed_bytes': ALLOWED['bytes'],
                 'index_bytes': helper.MAX_INDEX, 'streams': helper.MAX_STREAMS, 'blocks': helper.MAX_BLOCKS,
                 'dictionary_bytes': helper.MAX_DICT, 'raw_decoder_memory_bytes': helper.MAX_RAW_MEMORY},
        'elapsed_seconds': round(time.monotonic() - start, 3),
    }
    raw = (json.dumps(report, indent=2, sort_keys=True) + '\n').encode()
    with (args.out / 'result.json').open('xb') as destination:
        destination.write(raw)
    packed = gzip.compress(raw, mtime=0)
    with (args.out / 'result.json.gz').open('xb') as destination:
        destination.write(packed)
    print(json.dumps({'status': report['status'], 'measurement': measured, 'boundary': boundary,
                      'result_gzip_sha256': sha(packed)}))
    print('P34_P21_METADATA_GZIP_BASE64 ' + base64.b64encode(packed).decode('ascii'))


if __name__ == '__main__':
    main()
