#!/usr/bin/env python3
"""Metadata-bound P2.1 TAR fingerprints and fixed-size direct source captures only."""
import argparse
import base64
import gzip
import hashlib
import io
import json
import lzma
from pathlib import Path
import resource
import time
from types import ModuleType

PLAN_SHA = '49166455598f95fe9248f6c3853fe3deb3a0523d523b3d24e91d0a640d8bb18e'
META_SHA = 'd383482b682d4125b7f52cfa24f85c9dca3467b3d0a4e8f9d92dde8a6f1f2ba8'
BOOTSTRAP_HELPER_SHA = '0226a51705750e742467d7b504eee11ee24d2684e05bd3a21e1a4975f5b3551a'
BASE_HELPER_SHA = 'e7296a56eae0df9f1cd8a1a7697c27755deb2556f8a1dac8c21af0ec0e1ebb45'
PREFLIGHT_HELPER_SHA = '5be123aae98a3dffd544f9e66f111be4f2ef88660248cc1ee5f86be0790b88de'
MANIFEST_SHA = 'bb38a378d1d46334fb15a3151dba1d8df80129f5ee3462025a644ff18145f67b'
EXACT_TAR_BYTES = 4349603840
EXACT_DECODER_MEMORY = 67175064
CHUNK = 256 << 10


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def canonical(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(',', ':')) + '\n').encode()


def pinned(path, expected, cap):
    with path.open('rb') as source:
        raw = source.read(cap + 1)
    if len(raw) > cap or sha(raw) != expected:
        raise ValueError('P2.1 input plan/helper failed pinned digest/size: ' + str(path))
    return raw


def load_module(path, expected, name):
    raw = pinned(path, expected, 100000)
    module = ModuleType(name)
    module.__file__ = str(path)
    # Only pre-authenticated authored helpers are loaded, never recovered code.
    exec(compile(raw, str(path), 'exec'), module.__dict__)
    return module


def load_plan(plan_path, metadata_path):
    plan = json.loads(pinned(plan_path, PLAN_SHA, 16384))
    packed = pinned(metadata_path, META_SHA, 4096)
    with gzip.GzipFile(fileobj=io.BytesIO(packed)) as stream:
        raw = stream.read(16385)
    if len(raw) > 16384:
        raise ValueError('P2.1 metadata receipt expansion cap')
    receipt = json.loads(raw)
    if receipt['status'] != 'verified_metadata' or receipt['payload_decoded'] or receipt['boundary']:
        raise ValueError('P2.1 metadata receipt is not the complete metadata-only observation')
    if plan['measurement'] != receipt['measurement'] or plan['input'] != receipt['input']:
        raise ValueError('plan and metadata observation differ')
    if (plan['expanded_limit'] != EXACT_TAR_BYTES
            or plan['increase_from_prior_4GiB'] != 54636544
            or plan['outer_decoder_memory_limit'] != EXACT_DECODER_MEMORY
            or plan['measurement']['block_count'] != 1
            or len(plan['measurement']['streams']) != 1):
        raise ValueError('P2.1 exact measured limits or stream count differ')
    return plan, receipt


def normalized_measurement(value):
    # Library version is recorded, while identical on-file structure and the
    # actual measured decoder requirement remain mandatory across runtimes.
    return {key: child for key, child in value.items() if key != 'liblzma_version_number'}


class OneStreamXZ:
    """One exact preflighted XZ stream, with a per-instance decoder ceiling."""
    def __init__(self, source, base, memory):
        self.source = source
        self.base = base
        self.memory = memory
        self.decoder = lzma.LZMADecompressor(format=lzma.FORMAT_XZ, memlimit=memory)
        self.finished = False

    def read(self, size):
        if size < 0:
            raise ValueError('unbounded P2.1 decoded read')
        out = bytearray()
        while len(out) < size and not self.finished:
            if self.decoder.eof:
                extra = self.decoder.unused_data or self.source.read(CHUNK)
                self.base.limit(bool(extra), 'xz_unexpected_tail',
                                'bytes followed the one preflighted XZ stream', True)
                self.finished = True
                break
            chunk = b''
            if self.decoder.needs_input:
                chunk = self.source.read(CHUNK)
                if not chunk:
                    raise EOFError('P2.1 XZ ended before its verified stream end')
            try:
                out.extend(self.decoder.decompress(chunk, max_length=size - len(out)))
            except lzma.LZMAError as exc:
                if 'Memory usage limit' in str(exc):
                    raise self.base.Boundary('p21_exact_decoder_memory_guard', str(exc), True) from exc
                raise
        return bytes(out)


def probe_class(base, bootstrap, preflight):
    class P21Probe(bootstrap.Probe):
        def __init__(self, manifest, plan, inventory, seconds):
            p21_manifest = {**manifest, 'input': plan['input']}
            super().__init__(base, p21_manifest, inventory, seconds, plan['expanded_limit'])
            self.plan = plan
            self.snapshot_headers = 0
            self.snapshot_verified = False
            self.snapshot_selector = None
            self.xz_eof = False
            self.observed_metadata = None

        def classify(self, identity, size, selector):
            snapshot = self.plan['native_snapshot']
            if identity == snapshot['sha256']:
                base.limit(size != snapshot['bytes'], 'native_snapshot_identity',
                           'native snapshot SHA matched a different size', True)
                return 'prior_native_snapshot_digest_only_excluded', {
                    'receipt': 'original_delta_plan.native_snapshot_observation',
                    'inherited_scope': 'Prior name/digest observation only; no additional target or structured-payload coverage.'}
            return super().classify(identity, size, selector)

        def event(self, kind, **row):
            if kind == 'tar_header':
                first = self.plan['first_member']
                if row['ordinal'] == 1:
                    base.limit(row['member_name'] != first['name'] or row['bytes'] != first['bytes'],
                               'p21_first_manifest_identity', 'first native manifest name/size differs', True)
                snapshot = self.plan['native_snapshot']
                if row['member_name'] == snapshot['archive_member']:
                    self.snapshot_headers += 1
                    base.limit(self.snapshot_headers != 1 or row['bytes'] != snapshot['bytes'] or row['type'] not in ('0', '\0', '7'),
                               'native_snapshot_header', 'native snapshot path/size/type is not the expected unique regular member', True)
            elif kind == 'member_fingerprint' and row['member_name'] == self.plan['native_snapshot']['archive_member']:
                snapshot = self.plan['native_snapshot']
                base.limit(row['sha256'] != snapshot['sha256'] or row['bytes'] != snapshot['bytes'],
                           'native_snapshot_identity', 'native snapshot exact payload identity differs', True)
                self.snapshot_verified = True
                self.snapshot_selector = {key: row[key] for key in
                                          ('ordinal', 'member_name', 'bytes', 'header_offset', 'data_offset', 'sha256')}
            return super().event(kind, **row)

        def run(self, row):
            with preflight.open_regular(row['path']) as source:
                measured, before = preflight.observe(source, row, self.check_time)
                self.observed_metadata = measured
                base.limit(canonical(normalized_measurement(measured)) !=
                           canonical(normalized_measurement(self.plan['measurement'])),
                           'p21_metadata_changed', 'reobserved XZ block metadata differs from the pinned observation', True)
                base.limit(not measured['within_guard'] or measured['max_decoder_memory_bytes'] != self.plan['outer_decoder_memory_limit'],
                           'p21_decoder_requirement_changed', 'P2.1 decoder requirement differs', True)
                self.outer_verified = True
                identity = {'bytes': row['bytes'], 'sha256': row['sha256']}
                self.event('outer_and_xz_metadata_verified', **identity, path=row['path'],
                           exact_decoded_bytes=self.plan['expanded_limit'],
                           per_instance_decoder_memory_bytes=self.plan['outer_decoder_memory_limit'])
                source.seek(0)
                compressed = base.Meter(source, self, row['bytes'])
                decoder = OneStreamXZ(compressed, base, self.plan['outer_decoder_memory_limit'])
                meter = base.Meter(decoder, self, self.plan['expanded_limit'], expanded=True)
                try:
                    self.fingerprint_tar(meter, row['path'])
                    base.limit(self.snapshot_headers != 1 or not self.snapshot_verified,
                               'native_snapshot_missing', 'expected native snapshot was not authenticated', True)
                    self.tar_identity = meter.finish()
                    self.xz_eof = decoder.finished
                    base.limit(not self.xz_eof, 'xz_end_unverified', 'the exact XZ stream did not reach EOF', True)
                    self.compressed_replay_identity = compressed.finish()
                    base.limit(self.compressed_replay_identity != identity, 'compressed_replay_identity',
                               'replayed P2.1 compressed identity differs', True)
                    self.event('xz_tar_eof_verified', compressed_identity=identity,
                               tar_identity=self.tar_identity, native_snapshot=self.snapshot_selector)
                finally:
                    self.input_unchanged = preflight.stamp(source) == before
                    base.limit(not self.input_unchanged, 'input_changed', 'P2.1 source changed during streaming', True)
    return P21Probe


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--common-runner', type=Path, default=Path('/workspace/p34-large-bootstrap-runner-20261126'))
    parser.add_argument('--manifest', type=Path)
    parser.add_argument('--plan', type=Path, default=Path(__file__).with_name('plan.json'))
    parser.add_argument('--metadata', type=Path, default=Path(__file__).with_name('p21-metadata-result.json.gz'))
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--seconds', type=int, default=300)
    args = parser.parse_args()
    if not 1 <= args.seconds <= 300 or not args.out.is_absolute() or args.out.parent.resolve() != args.out.parent:
        raise ValueError('deadline or output path is outside the bounded plan')
    soft, hard = resource.getrlimit(resource.RLIMIT_AS)
    cap = min(value for value in (256 << 20, soft, hard) if value != resource.RLIM_INFINITY)
    resource.setrlimit(resource.RLIMIT_AS, (cap, hard))
    plan, metadata = load_plan(args.plan, args.metadata)
    bootstrap = load_module(args.common_runner / 'probe_bootstrap_tar.py', BOOTSTRAP_HELPER_SHA, 'p21_frozen_fingerprint_helper')
    base = load_module(args.common_runner / 'recover_archive_delta.py', BASE_HELPER_SHA, 'p21_frozen_stream_helper')
    preflight = load_module(args.common_runner / 'xz_memory_preflight.py', PREFLIGHT_HELPER_SHA, 'p21_frozen_xz_metadata')
    manifest_path = args.manifest or args.common_runner / 'bootstrap-manifest.json'
    manifest = bootstrap.load_manifest(manifest_path)
    args.out.mkdir(mode=0o700, exist_ok=False)
    start = time.monotonic()
    inventory_path = args.out / 'member-fingerprints.jsonl.gz'
    with gzip.open(inventory_path, 'xb', compresslevel=4) as inventory:
        probe = probe_class(base, bootstrap, preflight)(manifest, plan, inventory, args.seconds)
        try:
            probe.run(plan['input'])
        except base.Boundary as exc:
            probe.boundary(exc.kind, exc)
        except preflight.PreflightError as exc:
            probe.boundary(exc.kind, exc)
        except (OSError, EOFError, ValueError, lzma.LZMAError, base.tarfile.TarError, MemoryError, RecursionError) as exc:
            probe.boundary('format_io_or_memory_error', type(exc).__name__ + ': ' + str(exc))
    matches = []
    if probe.outer_verified and probe.input_unchanged:
        for target in manifest['targets']:
            name = target['filename']
            raw = probe.matches.get(name)
            if raw is None:
                continue
            if len(raw) != target['bytes'] or sha(raw) != target['sha256']:
                raise ValueError('P2.1 retained target authentication failed')
            with (args.out / name).open('xb') as destination:
                destination.write(raw)
            matches.append({'filename': name, 'bytes': len(raw), 'sha256': sha(raw),
                            'path': str(args.out / name), 'locations': probe.match_locations[name],
                            'base64': base64.b64encode(raw).decode('ascii')})
    inventory_sha = hashlib.sha256()
    inventory_size = 0
    with inventory_path.open('rb') as stream:
        for block in iter(lambda: stream.read(CHUNK), b''):
            inventory_sha.update(block)
            inventory_size += len(block)
    result = {
        'phase': 'p21_exact_tar_member_fingerprints',
        'status': 'partial_fingerprint_inventory' if probe.boundaries else 'fingerprint_inventory_complete',
        'input': plan['input'], 'script_sha256': sha(Path(__file__).read_bytes()),
        'plan_sha256': PLAN_SHA, 'metadata_receipt_sha256': META_SHA, 'manifest_sha256': MANIFEST_SHA,
        'helper_sha256': {'bootstrap_fingerprinter': BOOTSTRAP_HELPER_SHA,
                          'stream': BASE_HELPER_SHA, 'xz_metadata': PREFLIGHT_HELPER_SHA},
        'scope': plan['scope'], 'source_coverage_granted_for_nested_payloads': False,
        'global_cap_changes': False, 'metadata_reobserved': probe.observed_metadata,
        'input_outer_identity_verified': probe.outer_verified, 'input_stat_unchanged': probe.input_unchanged,
        'tar_end_verified': probe.tar_eof, 'xz_eof_verified': probe.xz_eof,
        'tar_identity': probe.tar_identity, 'compressed_replay_identity': probe.compressed_replay_identity,
        'native_snapshot_authenticated': probe.snapshot_verified, 'native_snapshot_selector': probe.snapshot_selector,
        'completed_identity_exclusions': len(probe.completed), 'blocked_partial_identities': len(probe.blocked),
        'counts': dict(probe.counts), 'boundaries': probe.boundaries,
        'last_fingerprinted_member': probe.last_fingerprinted_member, 'next_member': probe.next_member,
        'decoded_tar_bytes': probe.expanded, 'direct_source_matches': matches,
        'nested_member_payload_decodes': 0, 'json_nodes': 0, 'spooled_payload_bytes': 0,
        'limits': {**plan['caps'], 'seconds': args.seconds, 'address_space_bytes': cap,
                   'exact_tar_bytes': plan['expanded_limit'],
                   'increase_over_prior_4GiB_bytes': plan['increase_from_prior_4GiB'],
                   'outer_decoder_memory_bytes': plan['outer_decoder_memory_limit']},
        'inventory': {'path': str(inventory_path), 'bytes': inventory_size,
                      'sha256': inventory_sha.hexdigest(), 'raw_bytes': probe.inventory_bytes},
        'elapsed_seconds': round(time.monotonic() - start, 3),
    }
    raw = canonical(result)
    with (args.out / 'result.json').open('xb') as destination:
        destination.write(raw)
    packed = gzip.compress(raw, mtime=0)
    with (args.out / 'result.json.gz').open('xb') as destination:
        destination.write(packed)
    print(json.dumps({'status': result['status'], 'counts': result['counts'],
                      'boundaries': len(result['boundaries']), 'exact_matches': [row['filename'] for row in matches],
                      'result_gzip_sha256': sha(packed), 'inventory': result['inventory']}))
    print('P34_P21_FINGERPRINTS_GZIP_BASE64 ' + base64.b64encode(packed).decode('ascii'))


if __name__ == '__main__':
    main()
