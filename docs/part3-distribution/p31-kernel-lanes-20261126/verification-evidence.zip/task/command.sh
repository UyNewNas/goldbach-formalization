set -euo pipefail
cd /workspace/p31-poisson-lanes-20261126
test "$(git rev-parse HEAD)" = d28d340b0240dc5cd8658893d07b61637ee94aa2
test -z "$(git status --porcelain --untracked-files=all)"
git fetch origin 8e895502586ad41d5222ed5fd54386855b909b32
git switch --detach 8e895502586ad41d5222ed5fd54386855b909b32
export LEAN_NUM_THREADS=1
python3 -B verification/verify_part3_continuation.py --group poisson-kernel-lanes --expected-head 8e895502586ad41d5222ed5fd54386855b909b32 --output-dir .lake/p31-kernel-lanes-verification
python3 -B - <<'PY'
import base64, hashlib, io, json, zipfile
from pathlib import Path
root=Path.cwd()
directory=root/'.lake/p31-kernel-lanes-verification'
report=json.loads((directory/'report.json').read_text())
assert report['status']=='PASSED'
assert report['head_commit']=='8e895502586ad41d5222ed5fd54386855b909b32'
files=[]
for p in sorted(directory.rglob('*')):
    assert not p.is_symlink(), str(p)
    if p.is_file():
        assert p.suffix in {'.json','.log','.txt','.lean'}, str(p)
        files.append(('verification/'+p.relative_to(directory).as_posix(),p.read_bytes()))
for name in ['ImbalancedChen/Part3OriginalCommonPoissonKernelLanesCore.lean',
             'docs/part3-distribution/p31-kernel-lanes-20261126/SOURCE_INTAKE.json',
             'docs/part3-distribution/p31-kernel-lanes-20261126/CLOSURE.json']:
    p=root/name
    assert not p.is_symlink()
    files.append(('source/'+name,p.read_bytes()))
manifest={'source_commit':report['head_commit'],'status':report['status'],
          'declaration_count':report['declaration_count'],'module_counts':report['module_counts'],
          'files':[{'path':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in files]}
files.append(('MANIFEST.json',(json.dumps(manifest,indent=2)+'\n').encode()))
buf=io.BytesIO()
with zipfile.ZipFile(buf,'w') as z:
    for name,data in files:
        info=zipfile.ZipInfo(name,date_time=(1980,1,1,0,0,0))
        info.compress_type=zipfile.ZIP_DEFLATED
        info.external_attr=0o100644<<16
        z.writestr(info,data)
archive=buf.getvalue()
payload=json.dumps({'source_commit':report['head_commit'],'status':report['status'],
    'declaration_count':report['declaration_count'],'module_counts':report['module_counts'],
    'archive_bytes':len(archive),'archive_sha256':hashlib.sha256(archive).hexdigest(),
    'archive_members':len(files),'data_base64':base64.b64encode(archive).decode()},separators=(',',':'))
assert len(payload)<1500000
print('P31_KERNEL_EXPORT_JSON='+payload,flush=True)
PY
