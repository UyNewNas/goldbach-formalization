"""Combine the retained hash/commit/attachment reports; never edit or compile proof sources."""
from pathlib import Path
import re,json,subprocess,hashlib,collections,os
D=Path(__file__).resolve().parent;P=Path('/workspace/library-files/p34-proof-work')
J=json.load(open(P/'docs/part3-distribution/p34-20261125/source-resolution-recovery.json'))
B=json.load(open(D/'board-commits.json'));E=json.load(open(D/'complete-backup-report.json'));G=json.load(open(D/'historical-byte-scan.json'));gd=['git','--git-dir='+str(D/'history.git')]
child=set(J['leaves']['P3.4.child-1']['missing'])
refs={k:v for v,k in (line.split() for line in (D/'heads.tsv').read_text().splitlines())}
adds=collections.defaultdict(set);changed=collections.defaultdict(set)
for ln in (D/'raw-history.txt').read_text().splitlines():
 if ln.startswith('@'):commit=ln[1:];continue
 m=re.fullmatch(r':\d+ \d+ [0-9a-f]{40} [0-9a-f]{40} ([AMDT])\t(.+)',ln)
 if m:
  changed[m[2]].add(commit)
  if m[1]=='A':adds[m[2]].add(commit)
unresolved={}
for n,target in J['unresolved_modules'].items():
 hashes=target['registered_sha256']; refs_n={}
 for h,registry in hashes.items():
  pathset=set()
  for ref in registry:
   doc=json.load(open(P/ref))
   def visit(x):
    if isinstance(x,dict):
     if h in x.values():
      for k,v in x.items():
       if isinstance(v,str) and v.endswith(('.lean','.lean.txt')) and ('/' in v or chr(92) in v):
        # Omit unrelated second sources in compound records.
        if n.split('.')[-1].removeprefix('Part3') in v or n.split('.')[-1].startswith('Part3') and n.split('.')[-1][5:] in v:pathset.add(v.replace(chr(92),'/'))
     for v in x.values():visit(v)
    elif isinstance(x,list):
     for v in x:visit(v)
   visit(doc)
  refs_n[h]={'registry_files':registry,'recorded_paths':sorted(pathset)}
 unresolved[n]={'required_by_child_1':n in child,'registered_expected_sources':refs_n,'recovered_matches':[]}
reg=sorted({v for u in unresolved.values() for H in u['registered_expected_sources'].values() for v in H['registry_files']})
regcomm={p:{'addition_commits_in_history':sorted(adds[p]),'changed_commits_in_history':sorted(changed[p])} for p in reg}
special={'25afcbff11562df51ef7ac5113c879123fcd64c6':'Paused local 20261028 source and draft-publication records',
 'd8148323c082cbbcef12af8b933841926db65fb2':'Shiu namespace caller PINS.json, containing alternate 7bdcfdbb finite-cover reference',
 '1847d4c446be7ea2e8a83046f2561dda7a537ab5':'P3.5 source-recovery report pinning the external rebuild01 backup, bundle tip, and pack',
 'b2c20e789cd9026661bbc11eaae0e53fba9e94e5':'Historical add on one line for child-1 terminal sources',
 'e2a05f73d5f169fff847d72dcfcc66ec54ad4f87':'Historical add on a separate line for the same child-1 terminal source paths',
 '7f5330cace31383f5626da526b476dd4b0f43376':'Project board 2026-11-23 baseline containing all 24 source terminals',
 '5d022fb9a5c6149a87018cf41b688290c3f2c7e8':'Independent full native regular bounds source round',
 '53e0b471d9073d630840c41d2a4710188feffd31':'Both-sign six-scale trace source round'}
for c in list(special):
 # Ground every cited identifier as an actual Git commit, independent of shortened board labels.
 assert subprocess.check_output(gd+['cat-file','-t',c]).strip()==b'commit'
special={c:{'role':r,'subject':subprocess.check_output(gd+['show','--no-patch','--format=%s',c]).decode().strip()} for c,r in special.items()}
stats=collections.Counter();arc=collections.Counter()
for v in E['embedded_git_bundles'].values():stats.update(v['git_object_counts']);arc.update(v['decoded_member_counts'])
named=[p for p in changed if any(n.split('.')[-1].removeprefix('Part3').lower() in p.lower() for n in unresolved)]
allh={h for u in unresolved.values() for h in u['registered_expected_sources']};assert len(allh)==55
terms=sum(len(x['terminal_files']) for x in (v['7f5330cace31383f5626da526b476dd4b0f43376'] for v in B.values()))
# Omit local location of temporary pack extraction; retain source artifact and member paths.
for k,v in E['embedded_git_bundles'].items():v.pop('path',None)
commands=['git ls-remote --heads https://github.com/UyNewNas/goldbach-formalization.git > heads.tsv','git init --bare history.git; git --git-dir=history.git remote add origin https://github.com/UyNewNas/goldbach-formalization.git','git --git-dir=history.git fetch --filter=blob:none --no-tags origin +refs/heads/*:refs/remotes/historical/*','git --git-dir=history.git -c diff.renames=false log --all --name-only --no-renames --format="commit %H" --full-history > path-history-all.txt','git --git-dir=history.git -c diff.renames=false log --all --raw --no-abbrev --no-renames --format="@%H" --full-history > raw-history.txt','python history_scan.py pre; git --git-dir=history.git fetch --filter=blob:none --stdin --no-write-fetch-head --no-tags origin <want-oids.txt; python history_scan.py','python board_commits.py','tar -xOzf goldbach-rebuild01-source-backup.tar.gz rebuild01/source.bundle > rebuild01.bundle; git init --bare rebuild01.git; git --git-dir=rebuild01.git bundle verify rebuild01.bundle; git --git-dir=rebuild01.git bundle unbundle rebuild01.bundle','python archives_scan.py','zip -s 0 goldbach-rebuild10.zip --out rebuild10-complete.zip; python archives_complete.py','python summarize.py']
report={'schema':'p34-source-history-recovery-v1','repo':'UyNewNas/goldbach-formalization','checked_scope':'Read only, with a scratch-only bare Git repository. No proof edit, installation of source, compilation, or new acceptance credit. The separately tracked P3 compiler scan is not counted here.','formalization_baseline':J['baseline'],'accepted_review_checkout':'7596a3cbfba48f0764676ea2b1803caa20260b7c','counts':{'missing_module_names':len(unresolved),'modules_with_registered_sha256':sum(bool(z['registered_expected_sources']) for z in unresolved.values()),'distinct_candidate_byte_digests':len(allh),'child_1_missing_names':len(child),'matching_historical_sources':len(G['hits'])+len(E['matching_registered_sha256']),'existing_baseline_terminal_sources':terms},'exact_source_rounds':special,'board_leaf_commit_tree_checks':B,'missing_module_provenance':unresolved,'registry_file_history':regcomm,'history_search':{'remote_branch_count':len(refs),'refs_sha256':hashlib.sha256((D/'heads.tsv').read_bytes()).hexdigest(),'advertised_ref_heads':refs,'reachable_commit_count':int(subprocess.check_output(gd+['rev-list','--count','--all'])),'candidate_path_test':'All reachable historical change paths (including deleted paths); case-insensitive module basename substring, with and without Part3 prefix. This is a path search, not a claim that every reference in text is absent.','candidate_name_paths':named,'byte_scan':'Beyond the raw fa22a568 baseline already audited, collect unique added/modified historical Git blobs from these paths: .lean, .lean.txt, .patch/.diff, .raw, .zip, .tgz/.tar/.tar.gz/.tar.xz/.tar.zst, .b64 and .gz. SHA-256 over raw and supported decoded streams. Hashes or registrations alone do not constitute a match.','byte_scan_file':G},'external_archives':E,'external_summary':{'source_libraryfiles':len(E['archives']),'embedded_git_bundles':len(E['embedded_git_bundles']),'sum_of_per_bundle_objects_not_deduplicated_across_packs':dict(stats),'sum_of_per_bundle_byte_scans_not_deduplicated':dict(arc),'matched_source_sha256':E['matching_registered_sha256'],'scan_errors':E['scan_issues'],'partial_volumes':[],'split_zip':'Both same-name rebuild10 volumes were obtained; the reconstructed ZIP passed integrity, and its sole tar.gz is byte-identical to the standalone Library file.'},'limitations':['The 468 advertised branch heads and their reachable Git commit history are a defined set. Private/unadvertised refs, GitHub pull-request-only refs not reachable from those branches, unattested external backups, historic unpushed Windows working directories, and sources inside unknown opaque file formats are unverified.','For the five modules without a recorded SHA, the file and archive-member name checks cannot certify identity of arbitrarily renamed files.','git records the 24 named terminal files, and all 24 agree at the board baseline and formalization baseline. Their existence does not restore the missing imports.','The external inventory covers saved rebuild01–14 artifacts, the two parts of rebuild10, the handoff, and the already identified Nov 5 v1, v37, v38 files. Unrelated Numerics checkpoint versions were not expanded.','Source and compiled artifacts are distinguished. Metadata, imports, expected hashes, and .olean are not recovered Lean source.'],'reproduction':{'commands':commands,'script_names':['history_scan.py','board_commits.py','archives_scan.py','archives_complete.py','summarize.py'],'retained_raw_inputs':['heads.tsv','raw-history.txt','want-oids.txt','historical-byte-scan.json','board-commits.json','historical-archives.json','complete-backup-report.json']}}
# Clean references to the transient first-volume failure, now fully resolved in the separate reassembly record.
assert not E['scan_issues'] and not named and terms==24 and not G['issues']
out=D/'p34-history-source-recovery.json';out.write_text(json.dumps(report,ensure_ascii=False,indent=1)+'\n');print(out,sha if False else hashlib.sha256(out.read_bytes()).hexdigest(),out.stat().st_size,stats)
