import json,gzip,base64,hashlib,io,tarfile,zipfile,subprocess,os,pathlib,collections,re
from pathlib import Path
D=Path(__file__).resolve().parent
A=Path('/workspace/scratch/b1f8de8cd1b9/p35-library-recovery')
J=json.loads(Path('/workspace/library-files/p34-proof-work/docs/part3-distribution/p34-20261125/source-resolution-recovery.json').read_bytes())
hh={h:n for n,z in J['unresolved_modules'].items() for h in z['registered_sha256']};names={n.split('.')[-1] for n in J['unresolved_modules']}; hits=[];named=[];issues=[]; packmeta=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def visit(label,b,counts,l=0):
 counts['byte_streams']+=1;counts['byte_volume']+=len(b); h=sha(b)
 if h in hh:
  hits.append([hh[h],label,h]);(D/(hh[h]+'.lean')).write_bytes(b)
 if any(n.removeprefix('Part3').lower() in label.rsplit('!',1)[-1].split('/')[-1].lower() for n in names):named.append([label,h])
 if l>7:
  issues.append([label,'depth limit']);return
 p=label.split('!')[-1].lower()
 try:
  if b.startswith(b'# v2 git bundle') or b.startswith(b'# v3 git bundle'):
   packmeta.append([label,h,len(b),b[:200].decode(errors='replace').splitlines()[:2]])
   if Path(p).name!='source.bundle':(D/('nested-'+h+'.bundle')).write_bytes(b)
   return
  if p.endswith('.b64'):
   visit(label+'!'+Path(p).name[:-4],base64.b64decode(b),counts,l+1);return
  if zipfile.is_zipfile(io.BytesIO(b)):
   with zipfile.ZipFile(io.BytesIO(b)) as z:
    for e in z.infolist():
     if not e.is_dir():
      counts['zip_members']+=1;visit(label+'!'+e.filename,z.read(e),counts,l+1)
  elif p.endswith(('.tar','.tgz','.tar.gz','.tar.xz')) or (len(b)>=262 and b[257:262]==b'ustar'):
   with tarfile.open(fileobj=io.BytesIO(b),mode='r:*') as t:
    for e in t:
     if e.isfile():
      counts['tar_members']+=1;visit(label+'!'+e.name,t.extractfile(e).read(),counts,l+1)
  elif b.startswith(b'\x1f\x8b'):
   data=gzip.decompress(b);counts['gunzip']+=1;visit(label+'!'+Path(p).stem,data,counts,l+1)
  elif b.startswith(b'\xfd7zXZ'):
   import lzma
   visit(label+'!'+Path(p).stem,lzma.decompress(b),counts,l+1)
 except (OSError,ValueError,tarfile.TarError,zipfile.BadZipFile,EOFError) as exc:issues.append([label,str(exc)])
archives={}
for p in A.iterdir():
 if not p.is_file():continue
 c=collections.Counter();b=p.read_bytes()
 # Validation of existing source identity ahead of opening recovered attachments.
 ident=os.getxattr(p,'user.library-file-id').decode();version=os.getxattr(p,'user.library-file-version').decode()
 if p.name=='goldbach-rebuild01-source-backup.tar.gz':assert sha(b)=='418de569b101ee1f6100a3aff84d9d1d06492c024be8bf6ab596b3ff21aa03ce'
 visit(p.name,b,c);archives[p.name]=dict(file_id=ident,version=version,size=len(b),sha256=sha(b),counts=c)
gd=['git','--git-dir='+str(D/'rebuild01.git')]; obj=subprocess.check_output(gd+['cat-file','--batch-all-objects','--batch-check=%(objectname) %(objecttype)']).decode().splitlines()
gits=collections.Counter(t.split()[1] for t in obj); c=collections.Counter()
proc=subprocess.Popen(gd+['cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
paths={}
for line in subprocess.check_output(gd+['rev-list','--objects','cfdbcd9106428af5f3a61ebbc78b6bfb55c2f083']).decode().splitlines():
 if ' ' in line: oid,p=line.split(' ',1);paths[oid]=p
for line in obj:
 oid,k=line.split()
 if k!='blob':continue
 proc.stdin.write((oid+'\n').encode());proc.stdin.flush();hdr=proc.stdout.readline().split();dat=proc.stdout.read(int(hdr[2]));assert proc.stdout.read(1)==b'\n'
 visit('rebuild01 git '+oid+'!'+paths.get(oid,'unknown'),dat,c)
output=dict(archives=archives,git_bundle_objects=gits,git_bundle_source_members=c,embedded_bundles=packmeta,matching_source_hashes=hits,matching_member_paths=named,scan_issues=issues)
(D/'historical-archives.json').write_text(json.dumps(output,indent=1));print(gits,dict(c),'hits',hits[:8],'named',named[:8],'issues',issues[:4]);print('embedded bundles',[(x[0],x[1],x[2]) for x in packmeta][:10]);print('totalsarchive',sum(a['counts']['byte_streams'] for a in archives.values()))
