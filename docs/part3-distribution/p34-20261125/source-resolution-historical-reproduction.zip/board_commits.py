import pathlib,subprocess,json,collections,hashlib
D=pathlib.Path(__file__).resolve().parent;g=['git','--git-dir='+str(D/'history.git')];q=lambda args:subprocess.check_output(g+args)
base='fa22a56829ee880404516a36d498ce27dcb32f92'
j=json.load(open('/workspace/library-files/p34-proof-work/docs/part3-distribution/p34-20261125/source-resolution-recovery.json'))
ids={'child-1':[],'source-d7c20fd154':['50f7994'],'source-02f097a275':['50f7994','d9e53a4'],'source-ac61270cfe':['3a46b3f','78ae6ad1'],'source-c11432a253':['4ccc54e1'],'source-5d163eba78':['3a8d00b0'],'source-12218e6031':['62af0da','900b3d4e'],'source-be795bf299':['19c7759'],'source-b838bef941':['e6874f0f'],'source-4f9bf9d0fc':['53e0b471','5d022fb9']}
rows={};term_paths=[]
for lid,ts in ids.items():
 terms=j['leaves']['P3.4.'+lid]['terminals']
 if not ts:
  for t in terms:
   ts.extend(q(['log','--all','--diff-filter=A','--format=%H','--',t['path']]).decode().splitlines())
 rows[lid]={}
 for tag in dict.fromkeys(ts+['7f5330ca']):
  h=q(['rev-parse',tag+'^{commit}']).decode().strip()
  tree={p:m.split()[2] for entry in q(['ls-tree','-rz',h]).decode().split('\0') if entry for m,p in [entry.split('\t',1)]}
  candidates={}
  for t in terms:
   p=t['path']
   if p in tree:
    oid=tree[p];orig=q(['rev-parse',base+':'+p]).decode().strip();candidates[p]=dict(blob=oid,same_blob_as_baseline=oid==orig,registered_terminal_sha256=t['sha256'])
  rows[lid][h]=dict(title=q(['show','--no-patch','--format=%s',h]).decode().strip(),terminal_files=candidates,tracked_paths=len(tree),missing_source_named_paths=[p for p in tree if any(x.split('.')[-1].removeprefix('Part3') in p for x in j['unresolved_modules'])])
print('child 1',list(rows['child-1']));print('full-six',[(c,len(v['terminal_files']),v['tracked_paths']) for c,v in rows['source-4f9bf9d0fc'].items()]);(D/'board-commits.json').write_text(json.dumps(rows,indent=1))
