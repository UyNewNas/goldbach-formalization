import os,re,sys,json,hashlib,tarfile,io,base64,gzip,zipfile,collections,subprocess,pathlib
from pathlib import Path
d=Path(__file__).resolve().parent;gd=['git','--git-dir='+str(d/'history.git')]; base='fa22a56829ee880404516a36d498ce27dcb32f92';P=Path('/workspace/library-files/p34-proof-work');J=json.loads((P/'docs/part3-distribution/p34-20261125/source-resolution-recovery.json').read_bytes())
Z='0'*40
idx=collections.defaultdict(set)
for line in (d/'raw-history.txt').read_text().splitlines():
 if line.startswith('@'):c=line[1:];continue
 m=re.fullmatch(r':\d+ \d+ ([a-f0-9]{40}) ([a-f0-9]{40}) [AMDT]\t(.+)',line)
 if m and m[2]!=Z:idx[m[2]].add((c,m[3]))
known={row.split()[2] for row in subprocess.check_output(gd+['ls-tree','-r',base],text=True).splitlines()}
def needed(path):
 if path.endswith(('.lean','.lean.txt','.patch','.diff')):return True
 if path.endswith(('.zip','.raw','.tgz','.tar','.tar.gz','.tar.xz','.tar.zst','.b64','.gz')):return True
 return False
selected={oid:sorted(v) for oid,v in idx.items() if oid not in known and any(needed(p) for c,p in v)}
if sys.argv[-1]=='pre':
 (d/'want-oids.txt').write_text(''.join(o+'\n' for o in selected)); print(len(selected)); quit()
expected={h:n for n,z in J['unresolved_modules'].items() for h in z['registered_sha256']}
hits=[];near=[];counts=collections.Counter();issues=[]
proc=subprocess.Popen(gd+['cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,env=dict(os.environ,GIT_NO_LAZY_FETCH='1'))
def check(b, loc, oid):
 counts['bytes_checked']+=len(b)
 h=hashlib.sha256(b).hexdigest()
 if h in expected:
  hits.append(dict(module=expected[h],sha256=h,blob=oid,locations=selected[oid],member=loc));(d/(expected[h]+'.lean')).write_bytes(b)
for oid,places in selected.items():
 proc.stdin.write((oid+'\n').encode());proc.stdin.flush(); hdr=proc.stdout.readline().split()
 if len(hdr)!=3:issues.append(oid);continue
 b=proc.stdout.read(int(hdr[-1]));assert proc.stdout.read(1)==b'\n'
 path=places[0][1];counts['git_blobs']+=1;check(b,'',oid)
 if path.endswith('.b64'):
  try:b=base64.b64decode(b);path=path[:-4];check(b,'!base64decode',oid)
  except ValueError:continue
 try:
  if path.endswith(('.tar','.tar.gz','.tgz','.tar.xz')):
   with tarfile.open(fileobj=io.BytesIO(b),mode='r:*') as tar:
    for entry in tar:
     if entry.isfile():
      dat=tar.extractfile(entry).read();check(dat,entry.name,oid);counts['tar_members']+=1
  elif path.endswith('.zip'):
   with zipfile.ZipFile(io.BytesIO(b)) as z:
    for e in z.infolist():
     if not e.is_dir():check(z.read(e),e.filename,oid);counts['zip_members']+=1
  elif path.endswith('.gz'):check(gzip.decompress(b),'!gunzip',oid);counts['gzip']+=1
 except (OSError,ValueError,tarfile.TarError,zipfile.BadZipFile) as exc:issues.append([oid,path,str(exc)])
print(dict(counts),len(hits),len(issues));print(hits[:15]);(d/'historical-byte-scan.json').write_text(json.dumps({'counts':counts,'hits':hits,'issues':issues},indent=2))
