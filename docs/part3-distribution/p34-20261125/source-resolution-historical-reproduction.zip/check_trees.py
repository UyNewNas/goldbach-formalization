from pathlib import Path
import subprocess,re,json,collections
D=Path(__file__).resolve().parent;g=['git','--git-dir='+str(D/'history.git')]
J=json.load(open('/workspace/library-files/p34-proof-work/docs/part3-distribution/p34-20261125/source-resolution-recovery.json'))
names={n.split('.')[-1].removeprefix('Part3').lower() for n in J['unresolved_modules']}
ids=subprocess.check_output(g+['rev-list','--all','--objects','--filter=blob:none','--no-object-names']).splitlines()
base={e.split()[2] for e in subprocess.check_output(g+['ls-tree','-r',J['baseline']],text=True).splitlines()};want=set((D/'want-oids.txt').read_text().splitlines())
p=subprocess.Popen(g+['cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE);counts=collections.Counter();matches=[];additional=set();suffixes=collections.Counter()
for oid in ids:
 p.stdin.write(oid+b'\n');p.stdin.flush();hdr=p.stdout.readline().split();data=p.stdout.read(int(hdr[-1]));assert p.stdout.read(1)==b'\n'
 counts[hdr[1].decode()]+=1
 if hdr[1]!=b'tree':continue
 i=0
 while i<len(data):
  end=data.index(b'\0',i);mode,name=data[i:end].split(b' ',1);n=name.decode(errors='replace');b=data[end+1:end+21].hex();i=end+21
  if mode==b'40000':continue
  if any(x in n.lower() for x in names):matches.append([oid.decode(),b,n])
  if not n.endswith(('.lean','.lean.txt','.patch','.diff','.raw','.zip','.tgz','.tar','.tar.gz','.tar.xz','.tar.zst','.b64','.gz')):continue
  if b not in base and b not in want:additional.add((b,n))
p.stdin.close();p.wait()
out={'objects_by_type':dict(counts),'filename_matches':matches,'additional_historical_source_or_archive_candidates_beyond_existing_scan':sorted(additional)};print(out if not additional else [counts,len(additional),list(additional)[:9]]);(D/'reachable-tree-coverage.json').write_text(json.dumps(out,indent=1))
