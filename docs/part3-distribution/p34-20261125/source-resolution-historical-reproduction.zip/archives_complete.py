"""Verify identified external archive bytes, then enumerate their Git packs directly."""
exec((Path(__file__).parent/'archives_scan.py').read_text().split('archives={}')[0] if 'Path' in globals() else __import__('pathlib').Path(__file__).with_name('archives_scan.py').read_text().split('archives={}')[0])
previous=(D/'historical-archives.json');old=json.loads(previous.read_text())
inputs={p.name:p for folder in [A,D/'more-archives'] for p in folder.iterdir() if p.is_file()}
newDir=D/'other-bundles';newDir.mkdir(exist_ok=True)
archives={};bundles={}; split_members=[]
for name,p in sorted(inputs.items()):
 ident=os.getxattr(p,'user.library-file-id').decode();version=os.getxattr(p,'user.library-file-version').decode()
 data=p.read_bytes();h=sha(data);c=collections.Counter()
 rec={'path':str(p),'library_file_id':ident,'library_version':version,'sha256':h,'size':len(data)}
 archives[name]=rec
 if name in ['goldbach-rebuild10.z01','goldbach-rebuild10.zip']:
  rec['scope']='raw volume fingerprint; members checked from reassembled ZIP'
  continue
 if name=='goldbach-rebuild01-source-backup.tar.gz':
  assert h=='418de569b101ee1f6100a3aff84d9d1d06492c024be8bf6ab596b3ff21aa03ce'
 if name in old['archives']:
  rec['counts']=old['archives'][name]['counts']
 else:
  visit(name,data,c)
  rec['counts']=dict(c)
 if name.endswith('.tar.gz'):
  with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as tar:
   for e in tar:
    if not (e.isfile() and e.name.endswith('.bundle')):continue
    content=tar.extractfile(e).read();k=sha(content)
    if name=='goldbach-rebuild01-source-backup.tar.gz':
     file=D/'rebuild01.bundle';assert sha(file.read_bytes())==k
    else:
     file=newDir/(k+'.bundle');file.write_bytes(content)
    bundles[k]=dict(path=str(file),archive=name,member=e.name,size=len(content))
with zipfile.ZipFile(D/'rebuild10-complete.zip') as z:
 assert z.testzip() is None
 for e in z.infolist():
  b=z.read(e);assert sha(b)==archives[e.filename]['sha256'];split_members.append(dict(name=e.filename,sha256=sha(b),bytes=len(b),same_as_verified_separate_archive=True))
work=D/'other-bundles.git';subprocess.run(['git','init','--bare','--quiet',str(work)],check=True)
gd=['git','--git-dir='+str(work)]
env=dict(os.environ,GIT_ALTERNATE_OBJECT_DIRECTORIES=str(D/'rebuild01.git/objects')+':'+str(D/'history.git/objects'),GIT_NO_LAZY_FETCH='1')
for k,meta in bundles.items():
 p=Path(meta['path']);b=p.read_bytes();heads=subprocess.check_output(['git','bundle','list-heads',str(p)]).decode().splitlines()
 meta['heads']=heads;meta['sha256']=k
 if p==D/'rebuild01.bundle':
  meta['git_object_counts']=old['git_bundle_objects'];meta['decoded_member_counts']=old['git_bundle_source_members'];meta['pack_sha1']='e85da40b4859adce26c0d24101276a8b253ee10b';continue
 header,raw=b.split(b'\n\n',1);assert raw.startswith(b'PACK');meta['header']=header.decode().splitlines()
 out=subprocess.run(gd+['index-pack','--stdin','--fix-thin'],input=raw,capture_output=True,env=env)
 if out.returncode:issues.append([str(p),out.stderr.decode()]);continue
 pack=out.stdout.decode().split()[-1].strip();meta['pack_sha1']=pack
 idx=work/'objects/pack'/('pack-'+pack+'.idx');objects={}
 for s in subprocess.check_output(['git','verify-pack','-v',str(idx)],env=env).decode().splitlines():
  arr=s.split()
  if arr and re.fullmatch(r'[a-f0-9]{40}',arr[0]):objects[arr[0]]=arr[1]
 counts=collections.Counter(); blob_ids=[oid for oid,kind in objects.items() if kind=='blob']
 if blob_ids:
  proc=subprocess.Popen(gd+['cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,env=env)
  for oid in blob_ids:
   proc.stdin.write((oid+'\n').encode());proc.stdin.flush();hdr=proc.stdout.readline().split();dat=proc.stdout.read(int(hdr[2]));assert proc.stdout.read(1)==b'\n'
   visit(meta['member']+'!'+oid,dat,counts)
  proc.stdin.close();proc.wait()
 meta['git_object_counts']=dict(collections.Counter(objects.values()));meta['decoded_member_counts']=dict(counts)
report={'archives':archives,'embedded_git_bundles':bundles,'reassembled_zip':{'sha256':sha((D/'rebuild10-complete.zip').read_bytes()),'inputs':['goldbach-rebuild10.z01','goldbach-rebuild10.zip'],'members':split_members},'matching_registered_sha256':old['matching_source_hashes']+hits,'matched_target_member_paths':old['matching_member_paths']+named,'scan_issues':issues}
(D/'complete-backup-report.json').write_text(json.dumps(report,indent=1));print('archives',len(archives),'bundles',len(bundles),'issues',issues[:6],'matches',len(hits),'names',len(named));print([(x['archive'],x.get('git_object_counts')) for x in bundles.values()])
