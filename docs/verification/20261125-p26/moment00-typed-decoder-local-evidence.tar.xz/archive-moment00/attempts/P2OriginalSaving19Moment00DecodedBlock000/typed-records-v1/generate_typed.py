#!/usr/bin/env python3
"""Candidate typed values; the unchanged original decoder must certify all fields.
Only lexical decimal quotations are produced by the host, with no arithmetic
witness checks. No accepted parser, schema, or geometry owner is recompiled.
"""
from pathlib import Path
import argparse,json,re
import generate_moment as g

NS='ImbalancedChen.P2OriginalSaving19Moment00Decoding'

def head(imports,scope):
    return g.head(imports,scope).replace(g.NS,NS)+'open ImbalancedChen.P2OriginalSaving19Moment00Parsing\n\n'

def foot(names):
    return '\n'.join('#print axioms '+n for n in names)+'\n\nend '+NS+'\n'

def save(short,s,plan):
    s=s.replace('\ndef ','\nnoncomputable def ')
    p=g.PROJECT/'ImbalancedChen'/(short+'.lean')
    g.write_new(p,s)
    m={'module':'ImbalancedChen.'+short,'source':g.fp(p),
       'project_imports':re.findall(r'(?m)^import\s+(ImbalancedChen\.\S+)',s),
       'typed_schema':'ImbalancedChen.P2OriginalSaving19ArchiveSchema',
       'typed_schema_bootstrap':g.fp(g.ROOT/'TYPED_BOOTSTRAP.json'),
       'pure_parse_result':g.fp(g.ROOT/'PURE_PARSE_RESULT.json'),
       'planned_obligations':plan,'host_quotations_are_not_proof':True,
       'original_decodeMomentRecord_unchanged':True,'original_decodeMoments_unchanged':True,
       'production_modified':False,'remote_jobs_submitted':False}
    g.write_new(g.ROOT/'typed-owners'/(short+'.json'),json.dumps(m,indent=2)+'\n')
    return m

def short(i):return f'P2OriginalSaving19Moment00DecodedBlock{i:03d}'
def raw_name(i):return f'momentJsonRecord{i:03d}'
def typed_name(i):return f'momentTypedRecord{i:03d}'
def row_theorem(i):return f'decode_moment_record_{i:03d}'

def integer_literal(node):
    assert node.kind in {'str','number'}
    s=str(node.scalar)
    assert re.fullmatch(r'-?(0|[1-9][0-9]*)',s)
    # Preserve decimal digits exactly; the Lean theorem checks their meaning.
    return '('+s+' : Int)'

def row_value(node):
    fields={f.key.scalar:f.value for f in node.fields}
    id=fields['simplex_id'];assert id.kind=='number' and re.fullmatch(r'0|[1-9][0-9]*',id.scalar)
    floors=fields['log_gap_factor_floors_Q80'];assert floors.kind=='arr'
    return ('{ simplexId := '+id.scalar+',\n'
            '    factorFloorsQ80 := #['+', '.join(integer_literal(n) for n in floors.children)+'],\n'
            '    oldFloorQ96 := '+integer_literal(fields['old_floor_Q96'])+',\n'
            '    newFloorQ96 := '+integer_literal(fields['new_floor_Q96'])+' }')

def block(i):
    ids=list(range(4*i,min(4*i+4,len(g.RECORDS.children))))
    assert len(ids)==4
    imports=['P2OriginalSaving19ArchiveSchema',g.block_short(i)] if i==0 else [short(i-1),g.block_short(i)]
    s=head(imports,f'Original typed moment records {ids[0]} through {ids[-1]}; each concrete value is checked by original decodeMomentRecord.')
    names=[]
    for j in ids:
        raw=raw_name(j);typed=typed_name(j)
        s+=f'''def {raw} : SourceJson :=
  ({g.chunk_name(j)}Push []).head (List.cons_ne_nil _ _)

theorem moment_record_{j:03d}_push_eq (acc : List SourceJson) :
    {g.chunk_name(j)}Push acc = {raw} :: acc := by rfl

def {typed} : MomentRecord :=
  {row_value(g.RECORDS.children[j])}

'''
        s+=g.mark(f'typed_record_{j:03d}_before_decode')
        s+=f'''theorem {row_theorem(j)} :
    decodeMomentRecord {raw} = .ok {typed} := by rfl

'''
        s+=g.mark(f'typed_record_{j:03d}_decoded')
        names += [f'moment_record_{j:03d}_push_eq',row_theorem(j)]
    rawlist='['+', '.join(raw_name(j) for j in ids)+']'
    typedlist='['+', '.join(typed_name(j) for j in ids)+']'
    reverse_rawlist='['+', '.join(raw_name(j) for j in reversed(ids))+']'
    rb=f'momentJsonRecordsBlock{i:03d}';tb=f'momentTypedRecordsBlock{i:03d}'
    s+=f'def {rb} : List SourceJson := {rawlist}\n'
    s+=f'def {tb} : List MomentRecord := {typedlist}\n\n'
    s+=f'''theorem moment_records_block_{i:03d}_push_eq (acc : List SourceJson) :
    momentRecordsBlock{i:03d}Push acc = {reverse_rawlist} ++ acc := by rfl

theorem moment_records_block_{i:03d}_reverse (acc : List SourceJson) :
    (momentRecordsBlock{i:03d}Push acc).reverse = acc.reverse ++ {rb} := by
  rw [moment_records_block_{i:03d}_push_eq, List.reverse_append]
  rfl

theorem decode_moment_records_block_{i:03d} :
    {rb}.mapM decodeMomentRecord = .ok {tb} := by
  simp only [{rb}, {tb}, List.mapM_cons, List.mapM_nil,
    {', '.join(row_theorem(j) for j in ids)}]

'''
    alltyped=f'momentTypedRowsThroughBlock{i:03d}'
    priortyped=f'momentTypedRowsThroughBlock{i-1:03d}'
    if i==0:s+=f'def {alltyped} : List MomentRecord := {tb}\n\n'
    else:s+=f'def {alltyped} : List MomentRecord := {priortyped} ++ {tb}\n\n'
    s+=f'''theorem decode_moment_records_through_block_{i:03d} :
    {g.acc_name(ids[-1]+1)}.reverse.mapM decodeMomentRecord = .ok {alltyped} := by
  change (momentRecordsBlock{i:03d}Push {g.acc_name(ids[0])}).reverse.mapM decodeMomentRecord = _
  rw [moment_records_block_{i:03d}_reverse]
'''
    if i==0:
        s+=f'  exact decode_moment_records_block_{i:03d}\n\n'
    else:
        s+=f'  rw [List.mapM_append, decode_moment_records_through_block_{i-1:03d}, decode_moment_records_block_{i:03d}]\n  rfl\n\n'
    names += [f'moment_records_block_{i:03d}_push_eq',f'moment_records_block_{i:03d}_reverse',f'decode_moment_records_block_{i:03d}',f'decode_moment_records_through_block_{i:03d}']
    s+=g.mark(f'typed_block_{i:03d}_complete')+foot(names)
    return save(short(i),s,{'record_indices':ids,'concrete_record_values':True,
                          'source_rows_from_original_parser_chunk_Push':True,
                          'raw_record_extraction':'List.head with nonempty proof; no default or getD',
                          'full_typed_file_claimed':False})

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('block',type=int)
    a=ap.parse_args();m=block(a.block)
    print(json.dumps({'module':m['module'],'source':m['source'],'planned_obligations':m['planned_obligations']},indent=2))
