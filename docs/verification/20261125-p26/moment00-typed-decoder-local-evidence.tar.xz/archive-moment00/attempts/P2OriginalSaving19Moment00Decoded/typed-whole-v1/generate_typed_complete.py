#!/usr/bin/env python3
"""Use the exact original metadata and unchanged decoder; no getD fallback."""
import json
import generate_typed as t
import generate_moment as g

short='P2OriginalSaving19Moment00DecodeMetadata'
s=t.head(['P2OriginalSaving19ArchiveSchema','P2OriginalSaving19Moment00Parse'],
         'Original moment00 metadata decoded to exact fields, leaving the original record list abstract.')
s+='''def momentObjectWithRecords (records : List SourceJson) : SourceJson :=
  .obj (((momentRecordsFieldKey, .arr records) :: momentMetadataAcc009).reverse)

'''
field_names=['cellId','sourceWitness','dimension','verticesPerSimplex','factorCount','logDegree','expDegree','logDenominatorText','finalDenominatorText']
values=[];names=[]
for i,f in enumerate(g.PLAN.fields[:-1]):
    isstr=f.value.kind=='str';typ='String' if isstr else 'Nat'
    value='String.ofList '+g.base.quote_list(f.value.scalar) if isstr else str(f.value.scalar)
    target=f'momentMetadataDecoded_{field_names[i]}'
    s+=f'def {target} : {typ} := {value}\n\n'
    thm=f'get_moment_metadata_{i:03d}'
    s+=f'''theorem {thm} (records : List SourceJson) :
    (momentObjectWithRecords records).getObjValAs? {typ} "{f.key.scalar}" =
      .ok {target} := by
  change SourceJson.Decode.read (α := {typ}) momentMetadataField{i:03d}Value = .ok {target}
  decide +kernel

'''
    s+=g.mark(f'typed_metadata_{i:03d}_complete')
    values.append(target);names.append(thm)
for i,key in [(7,'logDenominator'),(8,'finalDenominator')]:
    s+=f'def momentMetadataDecoded_{key} : Int := {t.integer_literal(g.PLAN.fields[i].value)}\n\n'
    thm=f'parse_moment_metadata_{key}'
    s+=f'''theorem {thm} :
    parseInteger {values[i]} = .ok momentMetadataDecoded_{key} := by decide +kernel

'''
    names.append(thm)
s+='''def momentMomentsWithRows (rows : Array MomentRecord) : Moments := {
  cellId := momentMetadataDecoded_cellId
  sourceWitness := momentMetadataDecoded_sourceWitness
  dimension := momentMetadataDecoded_dimension
  verticesPerSimplex := momentMetadataDecoded_verticesPerSimplex
  factorCount := momentMetadataDecoded_factorCount
  logDegree := momentMetadataDecoded_logDegree
  expDegree := momentMetadataDecoded_expDegree
  logDenominator := momentMetadataDecoded_logDenominator
  finalDenominator := momentMetadataDecoded_finalDenominator
  rows := rows }

theorem get_moment_records_field (records : List SourceJson) :
    (momentObjectWithRecords records).getObjVal? "records" = .ok (.arr records) := by rfl

theorem decodeMoments_momentObjectWithRecords (records : List SourceJson) :
    decodeMoments (momentObjectWithRecords records) =
      (records.toArray.mapM decodeMomentRecord).bind (fun rows => .ok (momentMomentsWithRows rows)) := by
  simp only [decodeMoments,
    get_moment_metadata_000, get_moment_metadata_001, get_moment_metadata_002,
    get_moment_metadata_003, get_moment_metadata_004, get_moment_metadata_005,
    get_moment_metadata_006, get_moment_metadata_007, get_moment_metadata_008,
    parse_moment_metadata_logDenominator, parse_moment_metadata_finalDenominator,
    get_moment_records_field, SourceJson.getArr?, pure_bind]
  rfl

'''
s+=g.mark('typed_metadata_decoder_factorization_complete')
s+=t.foot(names+['get_moment_records_field','decodeMoments_momentObjectWithRecords'])
m=t.save(short,s,{'original_metadata_fields':[f.key.scalar for f in g.PLAN.fields[:-1]],
                  'all_metadata_concrete_and_checked':True,'record_list_remains_arbitrary':True,
                  'full_typed_file_claimed':False})
print(json.dumps({'module':m['module'],'source':m['source']},indent=2))

short='P2OriginalSaving19Moment00Decoded'
s=t.head(['P2OriginalSaving19Moment00DecodeMetadata',t.short(13)],
         'Complete original moment00 parse followed by the unchanged decodeMoments returns this concrete Moments value.')
s+='''def momentConcrete00 : Moments :=
  momentMomentsWithRows momentTypedRowsThroughBlock013.toArray

theorem decode_momentRootValue : decodeMoments momentRootValue = .ok momentConcrete00 := by
  change decodeMoments (momentObjectWithRecords momentRecordsAcc056.reverse) = .ok momentConcrete00
  rw [decodeMoments_momentObjectWithRecords, List.mapM_toArray, decode_moment_records_through_block_013]
  rfl

theorem momentPacked00_parse_decode :
    (SourceJson.parse (String.ofList momentPacked00.toList) >>= decodeMoments) =
      .ok momentConcrete00 := by
  rw [momentPacked00_parse]
  exact decode_momentRootValue

'''
s+=g.mark('whole_original_typed_moments_complete')
s+=t.foot(['decode_momentRootValue','momentPacked00_parse_decode'])
m=t.save(short,s,{'complete_parse_and_original_decodeMoments':True,
                  'concrete_Moments_value':'momentConcrete00','records':56,'factor_Int_values_per_record':10,
                  'success_tag_only':False,'getD_or_fallback_used':False,
                  'mathematical_moment_floor_correctness_claimed':False,'all_cells_claimed':False,
                  'old_Core_String_equality_claimed':False})
print(json.dumps({'module':m['module'],'source':m['source']},indent=2))
