#!/usr/bin/env python3
"""Original typed rows, sequential normal then independent kernel, no retries."""
from pathlib import Path
import json,subprocess,sys
import generate_typed as gen
ROOT=Path(__file__).resolve().parent
RUN=ROOT/'run_typed.py'
LOG=ROOT/'logs/typed-blocks-orchestration.log'
assert not LOG.exists()
def step(module,mode):
 tag='typed-records-v2'
 with LOG.open('ab') as f:
  p=subprocess.run([sys.executable,str(RUN),mode,module,tag],stdout=f,stderr=subprocess.STDOUT)
 receipt=ROOT/'logs'/module.split('.')[-1]/(mode+'-'+tag+'-result.json')
 if not receipt.exists():
  print(json.dumps({'module':module,'mode':mode,'exit_code':p.returncode,'status':'missing_receipt'}),flush=True)
  raise SystemExit(1)
 d=json.loads(receipt.read_text())
 print(json.dumps({k:d[k] for k in ['module','mode','attempt','status','exit_code','elapsed_seconds','peak_rss_bytes']}),flush=True)
 assert p.returncode==0 and d['status']=='succeeded','Stop on failure; no budget increase.'
step('ImbalancedChen.'+gen.short(0),'kernel')
for i in range(1,14):
 m=gen.block(i)
 step(m['module'],'normal')
 step(m['module'],'kernel')
print('P26_MOMENT00_TYPED_RECORDS_COMPLETE',flush=True)
