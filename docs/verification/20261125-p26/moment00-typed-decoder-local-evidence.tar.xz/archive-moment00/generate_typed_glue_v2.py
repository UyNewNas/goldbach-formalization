#!/usr/bin/env python3
"""Proof-only composition repair: abstract the monadic rewrites before applying
certificates to the complete actual record lists. Never decode records again.
"""
import json
from pathlib import Path
import generate_moment as g
import generate_typed as t

short='P2OriginalSaving19Moment00DecodeFromRows'
s=t.head(['P2OriginalSaving19Moment00DecodeMetadata'],
         'Abstract monadic composition of the original decoder. No concrete record list is reduced here.')
s+=g.mark('abstract_rows_before_glue')
s+='''theorem decodeMoments_of_records_decode
    (sourceRecords : List SourceJson) (typedRecords : List MomentRecord)
    (hrecords : sourceRecords.mapM decodeMomentRecord = .ok typedRecords) :
    decodeMoments (momentObjectWithRecords sourceRecords) =
      .ok (momentMomentsWithRows typedRecords.toArray) := by
  rw [decodeMoments_momentObjectWithRecords, List.mapM_toArray, hrecords]
  rfl

theorem parse_decode_of_parse_and_decode
    (text : String) (parsed : SourceJson) (decoded : Moments)
    (hparse : SourceJson.parse text = .ok parsed)
    (hdecode : decodeMoments parsed = .ok decoded) :
    (SourceJson.parse text >>= decodeMoments) = .ok decoded := by
  rw [hparse]
  exact hdecode

'''
s+=g.mark('abstract_rows_glue_complete')+t.foot(['decodeMoments_of_records_decode','parse_decode_of_parse_and_decode'])
m=t.save(short,s,{'abstract_source_and_typed_record_lists':True,'concrete_decode_recomputed':False,
                  'preserves_original_decodeMoments':True,'uses_existing_List_mapM_toArray':True})
print(json.dumps({'module':m['module'],'source':m['source']},indent=2))

short='P2OriginalSaving19Moment00Decoded'
s=t.head(['P2OriginalSaving19Moment00DecodeFromRows',t.short(13)],
         'Complete original moment00 parse followed by the unchanged decodeMoments returns this concrete Moments value.')
s+=g.mark('typed_whole_before_concrete_value')
s+='''def momentConcrete00 : Moments :=
  momentMomentsWithRows momentTypedRowsThroughBlock013.toArray

'''
s+=g.mark('typed_whole_after_concrete_value')
s+='''theorem decode_momentRootValue : decodeMoments momentRootValue = .ok momentConcrete00 :=
  decodeMoments_of_records_decode momentRecordsAcc056.reverse momentTypedRowsThroughBlock013
    decode_moment_records_through_block_013

'''
s+=g.mark('typed_whole_after_opaque_decoder_application')
s+='''theorem momentPacked00_parse_decode :
    (SourceJson.parse (String.ofList momentPacked00.toList) >>= decodeMoments) =
      .ok momentConcrete00 :=
  parse_decode_of_parse_and_decode (String.ofList momentPacked00.toList) momentRootValue
    momentConcrete00 momentPacked00_parse decode_momentRootValue

'''
s+=g.mark('whole_original_typed_moments_complete')+t.foot(['decode_momentRootValue','momentPacked00_parse_decode'])
s=s.replace('\ndef ','\nnoncomputable def ')
p=g.PROJECT/'ImbalancedChen'/(short+'.lean')
oldmanifest=g.ROOT/'typed-owners'/(short+'.json')
backup=g.ROOT/'attempts'/short/'typed-whole-v1'
assert (backup/(short+'.lean')).read_bytes()==p.read_bytes()
for name,source in [('owner-manifest.json',oldmanifest),('generate_typed_complete.py',g.ROOT/'generate_typed_complete.py')]:
 dst=backup/name
 assert not dst.exists();dst.write_bytes(source.read_bytes())
p.write_text(s)
m=json.loads(oldmanifest.read_text());m['source']=g.fp(p)
m['project_imports']=['ImbalancedChen.P2OriginalSaving19Moment00DecodeFromRows','ImbalancedChen.'+t.short(13)]
m['proof_revision']='v2: abstract List.mapM/Except bind rewrites; opaque theorem applications at the real complete data'
m['original_public_statements_and_concrete_Moments_value_unchanged']=True
oldmanifest.write_text(json.dumps(m,indent=2)+'\n')
print(json.dumps({'module':m['module'],'source':m['source']},indent=2))
