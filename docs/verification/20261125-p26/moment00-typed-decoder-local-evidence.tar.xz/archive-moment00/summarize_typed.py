#!/usr/bin/env python3
"""Freeze source/receipt evidence; no Lean commands and no witness math checks."""
from pathlib import Path
import hashlib,json,re,difflib
R=Path(__file__).resolve().parent

def fp(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def put(name,data):
 p=R/name;assert not p.exists(),name
 p.write_text(data if isinstance(data,str) else json.dumps(data,indent=2)+'\n')
 return fp(p)
pure=json.loads((R/'PURE_PARSE_RESULT.json').read_text())
purepackage=json.loads((R/'PURE_PARSE_PACKAGE_MANIFEST.json').read_text())
for row in purepackage['files']:assert fp(row['path'])==row
bootstrap=json.loads((R/'TYPED_BOOTSTRAP.json').read_text())
for kind in ['source','object']:
 for side in ['original','copy']:assert fp(bootstrap[kind][side]['path'])==bootstrap[kind][side]
# Preserve the real Schema provenance inside this typed-only checkpoint.
provenance=R/'typed-provenance/ArchiveSchema';provenance.mkdir(parents=True,exist_ok=True)
for name,source in [('SOURCE_ORIGIN.json',bootstrap['origin']['path']),
 ('normal-result.json',bootstrap['normal_receipt']['path']),('kernel-result.json',bootstrap['kernel_receipt']['path'])]:
 dest=provenance/name;assert not dest.exists();dest.write_bytes(Path(source).read_bytes())
results=[json.loads(p.read_text()) for p in sorted((R/'logs').glob('*/*-result.json'))]
typedmods=set('ImbalancedChen.'+p.stem for p in (R/'typed-owners').glob('*.json'))
assert len(typedmods)==17
accepted=[x for x in results if x['module'] in typedmods and x['status']=='succeeded']
failed=[x for x in results if x['module'] in typedmods and x['status']!='succeeded']
normal=[x for x in accepted if x['mode']=='normal'];kernel=[x for x in accepted if x['mode']=='kernel']
assert len(normal)==len(kernel)==17 and len(failed)==2
by={(x['module'],x['mode']):x for x in accepted};modules=[];axioms=[];warnings=[]
for n in normal:
 k=by[n['module'],'kernel'];assert n['source']==k['source'] and n['object']==k['object']
 assert fp(n['source']['path'])==n['source'] and fp(n['object']['path'])==n['object']
 for result in [n,k]:
  assert result['input_before']==result['input_after']
  assert result['rss_limit_bytes']==4294967296 and result['wall_limit_seconds']==180 and result['threads']==1
  for d in result['dependencies']:
   assert fp(d['source']['path'])==d['source'] and fp(d['object']['path'])==d['object']
 log=Path(n['log']['path']).read_text()
 matches=list(re.finditer(r"'([^']+)' (?:depends on axioms:\s*\[([^]]*)\]|does not depend on any axioms)",log,re.S))
 printed=re.findall(r'(?m)^#print axioms (\S+)',Path(n['source']['path']).read_text())
 assert len(matches)==len(printed),(n['module'],len(matches),len(printed))
 for m in matches:
  names=[x.strip() for x in (m.group(2) or '').split(',') if x.strip()]
  assert set(names)<={'propext','Classical.choice','Quot.sound'}
  axioms.append({'declaration':m.group(1),'axioms':names,'normal_log':n['log']})
 for line in log.splitlines():
  if ': warning:' in line:warnings.append({'module':n['module'],'message':line,'log':n['log']})
 short=n['module'].split('.')[-1]
 modules.append({'module':n['module'],'source':n['source'],'object':n['object'],
  'normal_receipt':fp(R/'logs'/short/('normal-'+n['attempt']+'-result.json')),
  'kernel_receipt':fp(R/'logs'/short/('kernel-'+k['attempt']+'-result.json')),
  'normal_seconds':n['elapsed_seconds'],'normal_peak_RSS_bytes':n['peak_rss_bytes'],
  'kernel_seconds':k['elapsed_seconds'],'kernel_peak_RSS_bytes':k['peak_rss_bytes']})
fullmodules={x['module']:x for x in pure['new_owners']}
fullmodules.update({x['module']:x for x in modules})
source_rows=[]
for p in sorted((R/'project/ImbalancedChen').glob('*.lean')):
 text=p.read_text();assert not re.search(r'\b(sorry|admit|unsafe|native_decide)\b|^\s*axiom\b',text,re.M)
 module='ImbalancedChen.'+p.stem;object=R/'objects/ImbalancedChen'/(p.stem+'.olean')
 imports=re.findall(r'(?m)^import\s+(\S+)',text)
 row={'module':module,'source':fp(p),'object':fp(object),'imports':imports}
 if module in fullmodules:
  row['local_verified_owner']=True
  row['normal_receipt']=fullmodules[module]['normal_receipt'];row['kernel_receipt']=fullmodules[module]['kernel_receipt']
 elif module==bootstrap['module']:
  row['reused_schema']=True;row['normal_receipt']=bootstrap['normal_receipt'];row['kernel_receipt']=bootstrap['kernel_receipt']
 else:
  reused=next(x for x in pure['reused_helpers'] if x['module']==module)
  assert row['source']==reused['source']['copy'] and row['object']==reused['object']['copy']
  row['reused_helper']=True
 source_rows.append(row)
assert len(source_rows)==42
lookup={x['module']:x for x in source_rows};seen=set()
def visit(module):
 if module in seen:return
 seen.add(module)
 for dep in lookup[module]['imports']:
  if dep.startswith('ImbalancedChen.'):visit(dep)
visit('ImbalancedChen.P2OriginalSaving19Moment00Decoded')
assert seen==set(lookup)
canonical=[{'module':x['module'],'source_sha256':x['source']['sha256'],'source_bytes':x['source']['bytes'],'imports':x['imports']} for x in source_rows]
closurehash=hashlib.sha256(json.dumps(canonical,sort_keys=True,separators=(',',':')).encode()).hexdigest()
closure={'schema':'saving19_moment00_full_source_closure_v1','project_modules':42,'new_local_normal_and_kernel_owners':36,
         'reused_helper_owners':5,'reused_real_schema_owners':1,'source_closure_canonical_sha256':closurehash,
         'canonical_source_rows':canonical,'sources_objects_and_receipts':source_rows,
         'external_pin':normal[0]['external_pin'],'P1_strict_claimed':False,'production_modified':False}
put('FULL_SOURCE_CLOSURE.json',closure)
# Statements and concrete decoded value stay unchanged across the failed glue's proof-only repair.
old=(R/'attempts/P2OriginalSaving19Moment00Decoded/typed-whole-v1/P2OriginalSaving19Moment00Decoded.lean').read_text()
new=(R/'project/ImbalancedChen/P2OriginalSaving19Moment00Decoded.lean').read_text()
for name in ['decode_momentRootValue','momentPacked00_parse_decode']:
 pattern=r'theorem\s+'+name+r'\s*:(.*?)\s*:='
 assert re.search(pattern,old,re.S).group(1)==re.search(pattern,new,re.S).group(1)
pattern=r'noncomputable def momentConcrete00\s*:(.*?)\n\n'
assert re.search(pattern,old,re.S).group(1)==re.search(pattern,new,re.S).group(1)
put('TYPED_GLUE_REPAIR.diff',''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='typed-whole-v1',tofile='typed-whole-v2')))
failrows=[]
for f in failed:
 short=f['module'].split('.')[-1]
 failrows.append({'module':f['module'],'attempt':f['attempt'],'status':f['status'],'exit_code':f['exit_code'],
  'source':f['source'],'source_snapshot':fp(R/'attempts'/short/f['attempt']/(short+'.lean')),
  'receipt':fp(R/'logs'/short/('normal-'+f['attempt']+'-result.json')),'log':f['log'],
  'elapsed_seconds':f['elapsed_seconds'],'peak_rss_bytes':f['peak_rss_bytes'],'object':f['object']})
result={'schema':'saving19_moment00_typed_decode_local_v1','status':'normal_and_independent_kernel_passed',
 'final_module':'ImbalancedChen.P2OriginalSaving19Moment00Decoded',
 'final_theorem':'ImbalancedChen.P2OriginalSaving19Moment00Decoding.momentPacked00_parse_decode',
 'final_statement':'(SourceJson.parse (String.ofList momentPacked00.toList) >>= decodeMoments) = .ok momentConcrete00',
 'no_hypotheses':True,'concrete_typed_output':'ImbalancedChen.P2OriginalSaving19Moment00Decoding.momentConcrete00',
 'records':56,'factor_Int_floors_per_record':10,'all_nine_metadata_fields_bound':True,
 'old_and_new_Q96_Ints_each_bound':True,'raw_record_access':'List.head with cons_ne_nil proof, no fallback',
 'actual_input':pure['actual_input'],'source_schema_bootstrap':fp(R/'TYPED_BOOTSTRAP.json'),
 'original_schema_decoder_slice_sha256':'21b86bcf4e04123dc6841cd25e50dcd073ecd9c9ac4c077b0174578a96c57a30',
 'new_owners':modules,'successful_normal_count':17,'successful_kernel_count':17,
 'sum_successful_normal_seconds':sum(x['elapsed_seconds'] for x in normal),
 'sum_successful_kernel_seconds':sum(x['elapsed_seconds'] for x in kernel),
 'max_successful_normal_peak_RSS_bytes':max(x['peak_rss_bytes'] for x in normal),
 'max_successful_kernel_peak_RSS_bytes':max(x['peak_rss_bytes'] for x in kernel),
 'exact_printed_axiom_sets':axioms,'warnings':warnings,'retained_failures':failrows,
 'failed_elaboration_placeholder_axioms_not_accepted':True,
 'final_statements_and_concrete_Moments_definition_unchanged':True,
 'pure_checkpoint_unchanged':fp(R/'PURE_PARSE_PACKAGE_MANIFEST.json'),
 'full_source_closure':fp(R/'FULL_SOURCE_CLOSURE.json'),'source_closure_canonical_sha256':closurehash,
 'limits_each_invocation':{'RSS_bytes':4294967296,'seconds':180,'threads':1,'maxRecDepth':1000000,'maxHeartbeats':0},
 'schema_recompiled':False,'pure_parser_recompiled':False,'geometry_owners_recompiled':False,'remote_jobs_submitted':False,
 'production_modified':False,'P1_strict_claimed':False,'all_cells_claimed':False,
 'old_Core_String_equality_claimed':False,'mathematical_floor_correctness_claimed':False}
put('TYPED_RESULT.json',result)
put('TYPED_SOURCE_MANIFEST.json',{'new_typed_owner_count':17,'reused_real_schema':bootstrap,
 'new_typed_sources':[x['source'] for x in modules],
 'scripts':[fp(R/p) for p in ['generate_typed.py','generate_typed_complete.py','generate_typed_glue_v2.py','run_typed.py','run_typed_blocks.py','summarize_typed.py']],
 'full_source_closure':fp(R/'FULL_SOURCE_CLOSURE.json'),
 'pure_source_manifest':fp(R/'PURE_PARSE_SOURCE_MANIFEST.json')})
rows='\n'.join('| '+m['module'].split('.')[-1]+' | '+f"{m['normal_seconds']:.3f}"+' | '+f"{m['kernel_seconds']:.3f}"+' | '+str(m['normal_peak_RSS_bytes'])+' | '+str(m['kernel_peak_RSS_bytes'])+' |' for m in modules)
report=f'''# moment00 原 parser 与真实 typed decoder：本地完整结果

## 已关闭的最终义务

以下无假设定理已通过 normal 与独立 `leanchecker`：

```lean
ImbalancedChen.P2OriginalSaving19Moment00Decoding.momentPacked00_parse_decode :
  (SourceJson.parse (String.ofList momentPacked00.toList) >>= decodeMoments) =
    .ok momentConcrete00
```

左侧使用正式 v4 候选的生产 FQN `ImbalancedChen.P2OriginalSaving19Archive.momentPacked00`，原样 `SourceJson.parse`，以及真实 `ArchiveSchema` 中原样的 `decodeMoments`。右侧是具体 `Moments` 结构值，含全部九项 metadata 和原顺序的 56 条记录。每条记录明确固定 `simplexId`、10 个 `factorFloorsQ80 : Int`、`oldFloorQ96` 与 `newFloorQ96`；本包因此绑定了全部 560 个 Q80 整数及 112 个 Q96 整数，不依赖默认值或 success tag 替代具体字段。

最终源：`project/ImbalancedChen/P2OriginalSaving19Moment00Decoded.lean`，SHA `8a269a5a9e0387deb15c7a145cf1a1bbdc94fe106babf84d20827c8c7ebb8151`。本地 object SHA `a93385473fa8f9444663524528dc4e89177fd5383a813dae0ab4f61f84bffa18`。最终 normal 1.406s / 2,137,665,536 B 峰值；独立 kernel 2.586s / 1,807,523,840 B 峰值。两个公开最终定理的精确 axioms 均仅为 `[propext, Classical.choice, Quot.sound]`。

## 明确的 metadata 值

| 原字段 | 具体解码值 |
|---|---|
| cell_id | 0 |
| source_witness | eighth-third-minorant-extension-20261009-a23-s23_low-00-cell.witness.json |
| dimension | 8 |
| vertices_per_simplex | 9 |
| factor_count | 10 |
| log_degree | 6 |
| exp_degree | 3 |
| log_floor_denominator | 1208925819614629174706176 |
| final_floor_denominator | 79228162514264337593543950336 |

具体 records 数值全部保留在 14 个 `Moment00DecodedBlock000` 至 `013` owner 的 `momentTypedRecord000` 至 `055` 定义。最终 `momentConcrete00.rows` 是这些已证值按原顺序累积后转为 Array；没有丢弃、去重或重排 records。

## 原件、schema 与 pure 层复用

原件仍为 28,999 B 的 `eighth-third-moment-refinement-20261009-a23-low-00.witness.json`，SHA `d88e9d02334dfa840f81c0e2be8e97d559978ac3848fdea13990deced9a65052`。实际本地读取路径、生产相同 relative path、原样 loader/Data00 与 CRLF 保留均见已冻结 `PURE_PARSE_REPORT.md` / `BOOTSTRAP.json`。所有 pure 源、对象及回执在本轮保持逐字不变。

真实 Schema 源 SHA `b877c0c35ace12cd76e0ed737b3a4b1ff3917fa15c4cc32b961450ee4761418b`，object SHA `8c3b41bd6b27e92b7a3c724b5d5ee9b191b4a4079fb40bd3ff5daad34129f9cc`，逐字复用 Root 已 normal/kernel 通过的对象。本轮不重编 Schema。`parseInteger` 至 `decodeMoments` 的原始 5399 B 切片 SHA 仍为 `21b86bcf4e04123dc6841cd25e50dcd073ecd9c9ac4c077b0174578a96c57a30`。Schema 的原验收与来源文件副本保存在 `typed-provenance/ArchiveSchema/`。

本轮使用相同 Lean 4.33.0-rc1 / commit `62eed1db4d67327ec8120be05f1a1b0847d74561` 与 Mathlib pin `e4c91783ca8e6a7c693ae624ade32fd22d4e43c1`。`run_typed.py` 固定 Schema 源/对象、纯层所有源/对象、原件和副本，以及 Mathlib pin 与直接 schema import 源/对象的指纹。每个命令前后均核对，无依赖重建。

## 组合方法

每条原 JSON record 从已通过原 parser 片段的 `momentRecordsChunkNNNPush []` 用 `List.head` 提取，携带 `List.cons_ne_nil` 非空证明；没有 `headD`、`getD` 或 fallback。对应 `Push acc = originalRecord :: acc` 由 `rfl` 闭合，因此数据来源仍是原解析结果。

每个具体 `decodeMomentRecord originalRecord = .ok concreteMomentRecord` 用普通 Lean kernel 的 `decide +kernel` 关闭。每四条记录使用既有 `List.mapM_cons` / `mapM_append` 等式组合；同时保留原数组累积器 reverse 的顺序语义。14 块覆盖全部 56 条记录。

metadata owner 对原 root 的九个字段逐一给出确定的读取结果，再证明一个记录列表仍任意的 `decodeMoments_momentObjectWithRecords`。`Moment00DecodeFromRows` 把 `List.mapM_toArray` 和 Except bind 的改写放在抽象记录列表上完成。最终 owner 仅应用这些不透明定理到已证明的实际 56 条记录，再与完整 pure parse 定理组合；不会在最终组装时重新运行整组 decoder。

这只是原定义的证明表达拆分。最终公开陈述与 `momentConcrete00` 定义在修复前后逐字相同，检查记录见 `TYPED_RESULT.json`，proof-only diff 见 `TYPED_GLUE_REPAIR.diff`。

## 资源回执

所有调用继续使用 4 GiB RSS 监测上限、180 秒、1 线程、`maxRecDepth=1000000`、`maxHeartbeats=0`，未提高预算。17 个新 typed owner 各做一次成功 normal 与独立 kernel；记录块与 metadata 一旦通过便没有重编或重复核验。合计成功 normal {result['sum_successful_normal_seconds']:.3f}s，成功 kernel {result['sum_successful_kernel_seconds']:.3f}s；各次详细资源数据如下。

| owner | normal 秒 | kernel 秒 | normal 峰值 bytes | kernel 峰值 bytes |
|---|---:|---:|---:|---:|
{rows}

本轮共打印并精确解析 {len(axioms)} 个定理的 axioms，见 `TYPED_RESULT.json`。成功 metadata 源保留三个 `unusedSimpArgs` 警告（两个分母解析 lemma 和 `pure_bind`）；它们不是失败，原始日志保留。没有为了清理这三个警告改写或重编已通过对象。

## 失败基线与修复

`typed-records-v1` 首块是表达失败：四个解码等式不能用 `rfl` 直接闭合，且 list mapM 化简后仍需 `rfl` 收尾。无对象生成。源、日志和生成器前像均保留；v2 只改证明表达为 `decide +kernel` 并增加收尾，不改 record 数值或公开陈述。

`typed-whole-v1` 在 11.470 秒、采样峰值 4,299,735,040 B 时被 4 GiB 监测停止，无对象生成。旧源没有前置 flush marker，因此空日志不能单独确定失败在何个内部 elaboration 步骤。本轮未加预算、未重复整组 decode；改为单独证明抽象 mapM/bind 接头后，`typed-whole-v2` 的各阶段 marker 与最终两项定理均正常完成，且独立 kernel 通过。

这两次失败及所有错误占位输出不属于通过信用。失败源、回执、日志完整保留，成功版本重新核对 axioms。

## checkpoint 与后续接线

`PURE_PARSE_*` 是已冻结、未改变的第一 checkpoint。`TYPED_DELTA_WHITELIST.json` / `TYPED_PACKAGE_MANIFEST.json` 只列出本次新增或修复保留文件，不重复 pure 的既有 whitelist，不包含任何 `.olean`，也不重复 raw input。`FULL_SOURCE_CLOSURE.json` 固定最终 42 个项目源闭包；其中 36 个 owner 在本目录 normal/kernel 通过，5 个 helper 与 1 个真实 Schema 按既有 SHA 复用。环境无关 canonical source closure SHA 为 `{closurehash}`。

本结果只为 cell00 的真实 parse 与 typed value 绑定提供本地证据。尚未声明 P1 strict、所有 13 个 moment/geometry cells、旧 Core 原 String literal 闭合等式、typed shape 总验收、Q80/Q96 数学 floor 正确性、pulling geometry 或 P2.6 最终积分端点通过。待正式新版 Core/all-input maps 接好，Root 可通过 index 0 的原定义展开把此直接生产 FQN 定理接到 `momentParse 0`；本包不加载所有其他输入或216个分析供应商来冒充该后续验收。
'''
put('TYPED_REPORT.md',report)
put('FULL_ACCEPTANCE_MANIFEST.json',{'schema':'saving19_moment00_parse_and_typed_local_checkpoint_v1',
 'pure_report':fp(R/'PURE_PARSE_REPORT.md'),'pure_result':fp(R/'PURE_PARSE_RESULT.json'),'pure_package':fp(R/'PURE_PARSE_PACKAGE_MANIFEST.json'),
 'typed_report':fp(R/'TYPED_REPORT.md'),'typed_result':fp(R/'TYPED_RESULT.json'),'typed_sources':fp(R/'TYPED_SOURCE_MANIFEST.json'),
 'full_closure':fp(R/'FULL_SOURCE_CLOSURE.json'),'full_source_closure_canonical_sha256':closurehash,
 'final_endpoint':'ImbalancedChen.P2OriginalSaving19Moment00Decoding.momentPacked00_parse_decode',
 'local_only':True,'P1_strict_claimed':False,'all_cells_claimed':False})
purepaths={Path(x['path']) for x in purepackage['files']}|{R/'PURE_PARSE_PACKAGE_MANIFEST.json'}
delta=[]
for p in sorted(R.rglob('*')):
 if not p.is_file() or p in purepaths or '__pycache__' in p.parts or 'objects' in p.parts:continue
 if p.name in {'TYPED_DELTA_WHITELIST.json','TYPED_PACKAGE_MANIFEST.json'}:continue
 assert p.suffix not in {'.olean','.ilean'}
 assert 'goldbach-research' not in p.parts
 delta.append({'relative_path':str(p.relative_to(R)),**fp(p)})
whitelist={'schema':'saving19_moment00_typed_only_delta_v1','relative_to':str(R),'base_pure_package':fp(R/'PURE_PARSE_PACKAGE_MANIFEST.json'),
 'no_objects':True,'no_raw_inputs':True,'base_pure_files_duplicated':False,'file_count':len(delta),'files':delta,
 'full_source_closure':fp(R/'FULL_SOURCE_CLOSURE.json'),'full_source_closure_canonical_sha256':closurehash}
put('TYPED_DELTA_WHITELIST.json',whitelist)
put('TYPED_PACKAGE_MANIFEST.json',{'schema':'saving19_moment00_typed_delta_package_v1','whitelist':fp(R/'TYPED_DELTA_WHITELIST.json'),
 'files':delta+[{'relative_path':'TYPED_DELTA_WHITELIST.json',**fp(R/'TYPED_DELTA_WHITELIST.json')}],
 'base_pure_package':fp(R/'PURE_PARSE_PACKAGE_MANIFEST.json'),'full_source_closure_canonical_sha256':closurehash,
 'no_objects':True,'no_raw_inputs':True,'unchanged_pure_files_duplicated':False})
for name in ['TYPED_REPORT.md','TYPED_RESULT.json','FULL_SOURCE_CLOSURE.json','TYPED_DELTA_WHITELIST.json','TYPED_PACKAGE_MANIFEST.json','FULL_ACCEPTANCE_MANIFEST.json']:
 print(json.dumps(fp(R/name)))
print(json.dumps({'typed_delta_files':len(delta),'full_sources':42,'canonical_full_closure_sha256':closurehash}))
