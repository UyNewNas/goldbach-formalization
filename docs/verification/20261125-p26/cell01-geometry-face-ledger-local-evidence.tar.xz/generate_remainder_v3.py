#!/usr/bin/env python3
"""Local grouping repair after the preserved 49-chunk composition timeout.

The source parser, raw bytes, proof templates and runtime limits are unchanged.
Only minima's special 64-chunk override is removed. Already accepted owners
remain immutable and are reused by the continuation driver.
"""
from pathlib import Path
from generate_full import FullEngine, fp
from generate_remainder import RemainderEngine


class SmallGroupRemainderEngine(RemainderEngine):
    def block_plan(self, key):
        return FullEngine.block_plan(self, key)

    def save(self, short, text, scope, plan):
        return super().save(short, text, scope,
                            {**plan, 'grouping_repair_generator': fp(Path(__file__))})
