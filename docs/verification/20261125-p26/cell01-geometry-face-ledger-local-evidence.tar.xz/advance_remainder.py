#!/usr/bin/env python3
"""Continue the real root-object fields, stopping at every actual failure."""
import argparse
import json
from generate_remainder import RemainderEngine
from advance import ensure
from external_fragments import ensure_external


ARRAY_FIELDS = ['vertices', 'vertex_values', 'all_original_constraint_minima',
                'facet_vertices', 'face_ledger', 'simplices']


def complete_array(engine, key):
    tag = engine.field_tag(key)
    ensure(engine, engine.tag+tag+'Header', lambda: engine.field_header(key))
    node, groups = engine.block_plan(key)
    for index, selected in enumerate(groups):
        if selected[-1]['end']-selected[0]['start'] > 4096:
            assert len(selected) == 1
            ensure_external(engine, node.children[selected[0]['first']], ensure)
        ensure(engine, engine.tag+tag+f'Block{index:03d}',
               lambda i=index: engine.array_block_owner(key, i))
    ensure(engine, engine.tag+tag+'Value', lambda: engine.array_value(key))
    ensure(engine, engine.tag+tag+'Field', lambda: engine.array_field(key))
    print(json.dumps({'field_complete': key, 'items': len(node.children), 'blocks': len(groups),
                      'whole_cell_parse_proved': False}), flush=True)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--through-field', choices=ARRAY_FIELDS+['whole-parse'], default='whole-parse')
    ap.add_argument('--only-field', choices=ARRAY_FIELDS)
    args = ap.parse_args()
    engine = RemainderEngine()
    keys = [args.only_field] if args.only_field else ARRAY_FIELDS
    for key in keys:
        complete_array(engine, key)
        if key == args.through_field or args.only_field:
            return
    ensure(engine, engine.tag+'PhysicalVolumeField', lambda: engine.scalar_field('physical_volume'))
    ensure(engine, engine.tag+'WholeValue', engine.whole_value)
    ensure(engine, engine.tag+'WholeParse', engine.whole_parse)
    print(json.dumps({'cell': 1, 'whole_cell_parse_proved': True,
                      'typed_geometry_proved': False, 'all13_pass_claimed': False}), flush=True)


if __name__ == '__main__':
    main()
