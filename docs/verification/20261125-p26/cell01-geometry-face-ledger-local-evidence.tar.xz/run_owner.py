#!/usr/bin/env python3
"""Compile one new owner, then independently replay its object, within fixed limits."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import re
import signal
import subprocess
import time
import psutil

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT/'project'
TOOLCHAIN = Path('/workspace/library-files/p34-runtime/lean-4.33.0-rc1-linux')
RSS_LIMIT = 4*1024**3
WALL_LIMIT = 180


def fp(p):
    p = Path(p); b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('short')
    ap.add_argument('mode', choices=['normal', 'kernel'])
    ap.add_argument('--attempt', default='initial')
    args = ap.parse_args()
    assert re.fullmatch(r'P2OriginalSaving19\w+', args.short)
    assert re.fullmatch(r'[\w-]+', args.attempt)
    manifest_path = ROOT/'owners'/(args.short+'.json')
    manifest = json.loads(manifest_path.read_text())
    source = Path(manifest['source']['path'])
    assert fp(source) == manifest['source']
    module = manifest['module']
    obj = ROOT/'objects'/(module.replace('.', '/')+'.olean')
    logs = ROOT/'logs'/args.short
    logs.mkdir(parents=True, exist_ok=True)
    stem = args.mode+'-'+args.attempt
    command = logs/(stem+'-command.json')
    result = logs/(stem+'-result.json')
    log = logs/(stem+'.log')
    assert not any(p.exists() for p in [command,result,log]), 'Immutable attempt already exists.'
    assert args.mode != 'normal' or not obj.exists(), 'Existing owner object is frozen.'
    copies = []
    for dep in manifest['dependency_closure']:
        assert fp(dep['source']['path']) == dep['source']
        original = fp(dep['object']['path'])
        if 'sha256' in dep['object']:
            assert original == dep['object']
        else:
            short = dep['module'].split('.')[-1]
            results = list((ROOT/'logs'/short).glob('kernel-*-result.json'))
            passed = [json.loads(p.read_text()) for p in results]
            assert any(x['status']=='succeeded' and x['object']==original and
                       x['source']==dep['source'] for x in passed), ('Unaccepted dependency', short)
        copied = ROOT/'objects'/(dep['module'].replace('.', '/')+'.olean')
        if copied.exists():
            assert copied.read_bytes() == Path(original['path']).read_bytes()
        else:
            copied.parent.mkdir(parents=True, exist_ok=True)
            copied.write_bytes(Path(original['path']).read_bytes())
        copies.append({'module': dep['module'], 'source': dep['source'],
                       'original': original, 'copy': fp(copied)})

    def invariants():
        records = [fp(manifest['fixture']['path']), fp(source)]
        assert records[0] == manifest['fixture'] and records[1] == manifest['source']
        for c in copies:
            for k in ['source','original','copy']:
                got = fp(c[k]['path']); assert got == c[k]; records.append(got)
        return records

    version = subprocess.run([str(TOOLCHAIN/'bin/lean'),'--version'],
                             capture_output=True,text=True,check=True).stdout.strip()
    assert '4.33.0-rc1' in version and '62eed1db4d67327ec8120be05f1a1b0847d74561' in version
    if args.mode == 'kernel':
        normal = json.loads((logs/('normal-'+args.attempt+'-result.json')).read_text())
        assert normal['status']=='succeeded' and normal['exit_code']==0
        assert normal['object']==fp(obj) and normal['source']==manifest['source']
        argv = [str(TOOLCHAIN/'bin/leanchecker'),'--verbose',module]
    else:
        argv = [str(TOOLCHAIN/'bin/lean'),'-j1','-DmaxRecDepth=1000000',
                '-DmaxHeartbeats=0','-o',str(obj),str(source)]
    env = os.environ.copy()
    env['PATH']=str(TOOLCHAIN/'bin')+os.pathsep+env.get('PATH','')
    env['LEAN_PATH']=str(ROOT/'objects')
    env['LEAN_NUM_THREADS']=env['OMP_NUM_THREADS']='1'
    before = invariants()
    record = {'module':module,'mode':args.mode,'attempt':args.attempt,
              'source':manifest['source'],'source_manifest':fp(manifest_path),
              'argv':argv,'cwd':str(PROJECT),'LEAN_PATH':env['LEAN_PATH'],
              'lean_version':version,'rss_limit_bytes':RSS_LIMIT,'wall_seconds':WALL_LIMIT,
              'source_object_invariants_before':before,'dependency_copies':copies,
              'scope':manifest['scope'],'started_unix':time.time(),
              'production_modified':False,'remote_jobs_submitted':False,
              'accepted_dependencies_recompiled':False}
    command.write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps({'module':module,'mode':args.mode,'source':manifest['source'],
                      'fixed_limits':[RSS_LIMIT,WALL_LIMIT]}),flush=True)
    start=time.monotonic();peak=0;cpu_peak=0.;reason=None
    with log.open('w') as out:
        proc=subprocess.Popen(argv,cwd=PROJECT,env=env,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
        process=psutil.Process(proc.pid)
        while True:
            rc=proc.poll();rss=0
            try:
                procs=[process]+process.children(recursive=True)
                rss=sum(p.memory_info().rss for p in procs if p.is_running())
                cpu=sum(p.cpu_times().user+p.cpu_times().system for p in procs if p.is_running())
                peak=max(peak,rss);cpu_peak=max(cpu_peak,cpu)
            except (psutil.NoSuchProcess,psutil.AccessDenied):pass
            if rc is not None:break
            if rss>RSS_LIMIT:reason='memory_limit'
            elif time.monotonic()-start>WALL_LIMIT:reason='timeout'
            if reason:
                os.killpg(proc.pid,signal.SIGKILL);break
            time.sleep(.02)
        rc=proc.wait()
    text=log.read_text()
    axioms=sorted(set(a.strip() for group in re.findall(r'depends on axioms: \[([^\]]*)\]',text)
                      for a in group.split(',') if a.strip()))
    record.update({'status':reason or ('succeeded' if rc==0 else 'failed'),'exit_code':rc,
                   'elapsed_seconds':time.monotonic()-start,'peak_rss_bytes':peak,
                   'sampled_cpu_seconds':cpu_peak,'object':fp(obj) if obj.exists() else None,
                   'log':fp(log),'source_object_invariants_after':invariants(),
                   'printed_axioms':axioms})
    result.write_text(json.dumps(record,indent=2)+'\n')
    print(text,end='',flush=True)
    print(json.dumps({k:record[k] for k in ['module','mode','status','exit_code',
          'elapsed_seconds','peak_rss_bytes','object','printed_axioms']}),flush=True)
    raise SystemExit(0 if record['status']=='succeeded' else 1)


if __name__=='__main__':main()
