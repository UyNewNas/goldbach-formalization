#!/usr/bin/env python3
"""Bounded external child certificates using the already checked reader patterns.

No host result is acceptance. Every emitted chunk/value/input equation receives
the same normal then independent-kernel checks as a top-level block.
"""
from pathlib import Path
import json
from generate_full import base, fragments, fp, WORK


def reference(node):
    result = fragments.ref(node)
    return {**result, 'split': result['stem'] + '_original_split'}


def groups_for(engine, node):
    groups, group = [], []
    for chunk in engine.chunks_for(node):
        if group and (len(group) == 8 or chunk['end'] - group[0]['start'] > 4096):
            groups.append(group)
            group = []
        group.append(chunk)
    if group:
        groups.append(group)
    return groups


def concat_split(name, parts, target, unfold):
    """Compose contiguous, already proved rest = chars ++ rest equations."""
    assert parts and all(a['end'] == b['start'] for a, b in zip(parts, parts[1:]))
    start, end = parts[0]['start'], parts[-1]['end']
    text = f'theorem {name} : sourceRest {start} = {target} ++ sourceRest {end} := by\n  calc\n'
    names = []
    for index, part in enumerate(parts):
        names.append(part['chars'])
        rhs = fragments.append_chain(names, f'sourceRest {part["end"]}')
        lhs = f'sourceRest {start}' if index == 0 else '_'
        if index == 0:
            proof = part['proof']
        else:
            context = fragments.append_chain(names[:-1], 'rest')
            proof = f'congrArg (fun rest => {context}) {part["proof"]}'
        text += f'    {lhs} = {rhs} := {proof}\n'
    simplifiers = [*unfold, 'List.cons_append', 'List.nil_append', 'List.append_assoc']
    text += f'    _ = {target} ++ sourceRest {end} := by simp only [{", ".join(simplifiers)}]\n\n'
    return text


def block_owner(engine, node, selected, short, nested, extra_plan=None):
    large = [node.children[c['first']] for c in selected if c['oversize_child']]
    imported = ['ImbalancedChen.' + engine.tag + 'Input']
    imported += [reference(child)['module'] for child in large]
    imported = list(dict.fromkeys(imported))
    text = engine.head(imported, 'Grouped external original-reader transitions; child certificates remain opaque.')
    text += f'namespace {nested}\n\n'
    names, char_names = [], []
    push = 'acc'
    for chunk in selected:
        name = f'piece{chunk["index"]:04d}'
        theorem = 'array_' + name
        body, extra = fragments.array_segment(name, theorem, chunk['start'], chunk['end'],
            node.children[chunk['first']:chunk['after']], chunk['before_offset'],
            chunk['after_offset'], chunk['final'])
        text += body
        names += extra + [theorem]
        char_names.append(name + 'Chars00')
        push = f'{name}Push00 ({push})'
    first, last = selected[0], selected[-1]
    chars = fragments.append_chain(char_names)
    payload = fragments.append_chain(char_names, 'tail')
    rhs = ('.ok (.arr ((blockPush acc).reverse), tail)' if last['final'] else
           f'SourceJson.array (fuel + {last["after_offset"]}) (SourceJson.white tail) (blockPush acc)')
    text += f'''def blockChars : List Char := {chars}
def blockPush (acc : List SourceJson) : List SourceJson := {push}

theorem array_block (fuel : Nat) (tail : List Char) (acc : List SourceJson) :
    SourceJson.array (fuel + {first['before_offset']}) (SourceJson.white (blockChars ++ tail)) acc =
      {rhs} := by
  have hinput : blockChars ++ tail = {payload} := by simp only [blockChars, List.append_assoc]
  calc
    SourceJson.array (fuel + {first['before_offset']}) (SourceJson.white (blockChars ++ tail)) acc =
        SourceJson.array (fuel + {first['before_offset']}) (SourceJson.white ({payload})) acc :=
      congrArg (fun chars => SourceJson.array (fuel + {first['before_offset']}) (SourceJson.white chars) acc) hinput
'''
    acc = 'acc'
    for i, chunk in enumerate(selected):
        rest = fragments.append_chain(char_names[i+1:], 'tail') if i+1 < len(selected) else 'tail'
        next_acc = f'piece{chunk["index"]:04d}Push00 ({acc})'
        target = rhs if i+1 == len(selected) else (
            f'SourceJson.array (fuel + {chunk["after_offset"]}) (SourceJson.white ({rest})) ({next_acc})')
        text += f'    _ = {target} := array_piece{chunk["index"]:04d} fuel ({rest}) ({acc})\n'
        acc = next_acc
    text += '\n'
    if last['end'] - first['start'] <= 4096:
        text += engine.emit_split('block_original', first['start'], last['end'], 'blockChars')
        names += ['block_original_prefix', 'block_original_split']
    else:
        assert len(selected) == 1 and len(large) == 1
        child = large[0]
        ref = reference(child)
        label = f'piece{first["index"]:04d}'
        lead, suffix = label + 'LeadChars00', label + 'SuffixChars00'
        text += engine.emit_split('block_lead', first['start'], child.start, lead)
        text += engine.emit_split('block_suffix', child.end, last['end'], suffix)
        parts = [
            {'start': first['start'], 'end': child.start, 'chars': lead, 'proof': 'block_lead_split'},
            {'start': child.start, 'end': child.end, 'chars': ref['chars'], 'proof': ref['split']},
            {'start': child.end, 'end': last['end'], 'chars': suffix, 'proof': 'block_suffix_split'},
        ]
        text += concat_split('block_original_split', parts, 'blockChars',
                             ['blockChars', label + 'Chars00'])
        names += ['block_lead_prefix', 'block_lead_split', 'block_suffix_prefix',
                  'block_suffix_split', 'block_original_split']
    actual_rhs = (f'.ok (.arr ((blockPush acc).reverse), sourceRest {last["end"]})'
                  if last['final'] else
                  f'SourceJson.array (fuel + {last["after_offset"]}) (SourceJson.white (sourceRest {last["end"]})) (blockPush acc)')
    text += f'''theorem array_block_original (fuel : Nat) (acc : List SourceJson) :
    SourceJson.array (fuel + {first['before_offset']}) (SourceJson.white (sourceRest {first['start']})) acc =
      {actual_rhs} :=
  (congrArg (fun chars => SourceJson.array (fuel + {first['before_offset']}) (SourceJson.white chars) acc)
    block_original_split).trans (array_block fuel (sourceRest {last['end']}) acc)

'''
    names += ['array_block', 'array_block_original']
    text += engine.foot(names, nested)
    plan = {'raw_span': [first['start'], last['end']], 'selected_chunks': selected,
            'external_child_spans': [[n.start, n.end] for n in large],
            'raw_binding_composed_for_span_over_4096': last['end']-first['start'] > 4096,
            'backend': fp(Path(__file__)), **(extra_plan or {})}
    return engine.save(short, text, 'Arbitrary-tail/accumulator original block with exact packed-input binding', plan)


def array_fragment_owner(engine, node, groups):
    ref = reference(node)
    blocks = [ref['stem'] + f'Block{i:03d}' for i in range(len(groups))]
    imported = [ref['module'] + f'Block{i:03d}' for i in range(len(groups))]
    text = engine.head(imported, 'Complete external array child; only previously checked small block equations are composed.')
    text += f"def {ref['stem']}OpenChars : List Char := ['[']\n"
    text += f"def {ref['stem']}Acc000 : List SourceJson := []\n"
    for i, block in enumerate(blocks):
        text += f"def {ref['stem']}Acc{i+1:03d} : List SourceJson := {block}.blockPush {ref['stem']}Acc{i:03d}\n"
    chars = [block + '.blockChars' for block in blocks]
    text += f"def {ref['chars']} : List Char := '[' :: ({fragments.append_chain(chars)})\n"
    text += f"def {ref['value']} : SourceJson := .arr ({ref['stem']}Acc{len(groups):03d}.reverse)\n\n"
    payload = fragments.append_chain(chars, 'tail')
    text += f'''theorem {ref['theorem']} (fuel : Nat) (tail : List Char) :
    SourceJson.value (fuel + {node.need}) ({ref['chars']} ++ tail) = .ok ({ref['value']}, tail) := by
  have hinput : {ref['chars']} ++ tail = '[' :: ({payload}) := by
    simp only [{ref['chars']}, List.cons_append, List.append_assoc]
  calc
    SourceJson.value (fuel + {node.need}) ({ref['chars']} ++ tail) =
        SourceJson.value (fuel + {node.need}) ('[' :: ({payload})) :=
      congrArg (SourceJson.value (fuel + {node.need})) hinput
    _ = SourceJson.array (fuel + {node.need-1}) (SourceJson.white ({payload})) {ref['stem']}Acc000 := by rfl
'''
    for i, (block, selected) in enumerate(zip(blocks, groups)):
        last = selected[-1]
        rest = fragments.append_chain(chars[i+1:], 'tail') if i+1 < len(groups) else 'tail'
        rhs = (f'.ok ({ref["value"]}, tail)' if last['final'] else
               f'SourceJson.array (fuel + {last["after_offset"]}) (SourceJson.white ({rest})) {ref["stem"]}Acc{i+1:03d}')
        text += f'    _ = {rhs} := {block}.array_block fuel ({rest}) {ref["stem"]}Acc{i:03d}\n'
    text += '\n' + engine.emit_split(ref['stem'] + '_open', node.start, node.start+1, ref['stem'] + 'OpenChars')
    parts = [{'start': node.start, 'end': node.start+1, 'chars': ref['stem']+'OpenChars',
              'proof': ref['stem']+'_open_split'}]
    parts += [{'start': group[0]['start'], 'end': group[-1]['end'],
               'chars': block+'.blockChars', 'proof': block+'.block_original_split'}
              for group, block in zip(groups, blocks)]
    text += concat_split(ref['split'], parts, ref['chars'], [ref['chars'], ref['stem']+'OpenChars'])
    text += actual_value(ref, node)
    names = [ref['theorem'], ref['stem']+'_open_prefix', ref['stem']+'_open_split',
             ref['split'], ref['theorem']+'_original']
    text += engine.foot(names)
    return engine.save(ref['short'], text, 'Self-delimiting external array child and exact input span',
        {'span': [node.start, node.end], 'node_kind': node.kind, 'blocks': len(groups),
         'value_fuel_offset': node.need, 'backend': fp(Path(__file__))})


def actual_value(ref, node):
    return f'''theorem {ref['theorem']}_original (fuel : Nat) :
    SourceJson.value (fuel + {node.need}) (sourceRest {node.start}) =
      .ok ({ref['value']}, sourceRest {node.end}) :=
  (congrArg (SourceJson.value (fuel + {node.need})) {ref['split']}).trans
    ({ref['theorem']} fuel (sourceRest {node.end}))

'''


def fragment_owner(engine, node):
    ref = reference(node)
    children = fragments.children_to_certify(node)
    imported = ['ImbalancedChen.' + engine.tag + 'Input'] + [reference(n)['module'] for n in children]
    text = engine.head(imported, 'Original self-delimiting child; structured readers use separately checked child certificates.')
    if node.kind == 'arr' and fragments.needs_ref(node):
        body, names = fragments.emit_array(node)
    elif node.kind == 'obj' and fragments.needs_ref(node):
        body, names = fragments.emit_object(node)
    else:
        body, names = fragments.emit_small(node)
    text += body
    if node.end - node.start <= 4096:
        text += engine.emit_split(ref['stem']+'_original', node.start, node.end, ref['chars'])
        names += [ref['stem']+'_original_prefix', ref['split']]
    else:
        assert node.kind == 'obj', 'Large arrays use grouped owners; oversized scalar children require separate treatment.'
        open_chars = ref['stem']+'OpenChars'
        text += f"def {open_chars} : List Char := ['{{']\n\n"
        text += engine.emit_split(ref['stem']+'_open', node.start, node.start+1, open_chars)
        names += [ref['stem']+'_open_prefix', ref['stem']+'_open_split']
        parts = [{'start': node.start, 'end': node.start+1, 'chars': open_chars,
                  'proof': ref['stem']+'_open_split'}]
        unfold = [ref['chars'], open_chars]
        for index, field in enumerate(node.fields):
            label = ref['stem']+f'Field{index:03d}'
            start = node.start+1 if index == 0 else field.prefix_start
            if fragments.needs_ref(field.value):
                child = reference(field.value)
                for tag, a, b, chars in [('header', start, field.value.start, label+'HeaderChars00'),
                                        ('suffix', field.value.end, field.prefix_end, label+'SuffixChars00')]:
                    text += engine.emit_split(label+'_'+tag, a, b, chars)
                    names += [label+'_'+tag+'_prefix', label+'_'+tag+'_split']
                parts.extend([
                    {'start': start, 'end': field.value.start, 'chars': label+'HeaderChars00', 'proof': label+'_header_split'},
                    {'start': field.value.start, 'end': field.value.end, 'chars': child['chars'], 'proof': child['split']},
                    {'start': field.value.end, 'end': field.prefix_end, 'chars': label+'SuffixChars00', 'proof': label+'_suffix_split'},
                ])
                unfold.append(label+'Chars00')
            else:
                assert field.prefix_end-start <= 4096
                text += engine.emit_split(label+'_original', start, field.prefix_end, label+'Chars00')
                names += [label+'_original_prefix', label+'_original_split']
                parts.append({'start': start, 'end': field.prefix_end, 'chars': label+'Chars00',
                              'proof': label+'_original_split'})
        text += concat_split(ref['split'], parts, ref['chars'], unfold)
        names.append(ref['split'])
    text += actual_value(ref, node)
    names.append(ref['theorem']+'_original')
    text += engine.foot(names)
    return engine.save(ref['short'], text, 'Self-delimiting original child and exact source span',
        {'span': [node.start, node.end], 'node_kind': node.kind, 'value_fuel_offset': node.need,
         'child_spans': [[n.start, n.end] for n in children], 'backend': fp(Path(__file__))})


def ensure_external(engine, node, ensure):
    ref = reference(node)
    if ref['module'] in engine.registry():
        ensure(engine, ref['short'], lambda: fragment_owner(engine, node))
        return
    for child in fragments.children_to_certify(node):
        ensure_external(engine, child, ensure)
    if node.kind == 'arr' and node.end-node.start > 4096:
        groups = groups_for(engine, node)
        for index, selected in enumerate(groups):
            short = ref['short']+f'Block{index:03d}'
            nested = ref['stem']+f'Block{index:03d}'
            ensure(engine, short, lambda s=selected, sh=short, ns=nested:
                block_owner(engine, node, s, sh, ns, {'external_array_parent_span': [node.start, node.end]}))
        ensure(engine, ref['short'], lambda: array_fragment_owner(engine, node, groups))
    else:
        ensure(engine, ref['short'], lambda: fragment_owner(engine, node))


def top_block_owner(engine, key, index):
    node, groups = engine.block_plan(key)
    selected = groups[index]
    tag = engine.field_tag(key)
    return block_owner(engine, node, selected, engine.tag+tag+f'Block{index:03d}',
                       tag+f'Block{index:03d}', {'key': key, 'block': index,
                       'planned_block_count': len(groups), 'original_array_item_count': len(node.children)})
