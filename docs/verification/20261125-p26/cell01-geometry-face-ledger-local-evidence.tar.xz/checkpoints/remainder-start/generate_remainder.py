#!/usr/bin/env python3
"""Later cell01 fields, extending the frozen active8 generator without editing it."""
from pathlib import Path
from generate_full import FullEngine, base, fp


class RemainderEngine(FullEngine):
    def save(self, short, text, scope, plan):
        return super().save(short, text, scope,
                            {**plan, 'stage_generator': fp(Path(__file__))})

    def block_plan(self, key):
        if key != 'all_original_constraint_minima':
            return super().block_plan(key)
        node = self.fields[key].value
        groups, group = [], []
        for chunk in self.chunks_for(node):
            if group and (len(group) == 64 or chunk['end']-group[0]['start'] > 4096):
                groups.append(group)
                group = []
            group.append(chunk)
        if group:
            groups.append(group)
        return node, groups

    def array_block_owner(self, key, index=0):
        node, groups = self.block_plan(key)
        selected = groups[index]
        if selected[-1]['end']-selected[0]['start'] <= 4096:
            return super().array_block_owner(key, index)
        from external_fragments import top_block_owner
        return top_block_owner(self, key, index)

    def scalar_field(self, key):
        field = self.fields[key]
        assert field.value.kind not in ['arr', 'obj'] and field.separator == ','
        index = self.field_index[key]
        prior_module, prior_acc, prior_whole = self.prior(key)
        tag = self.field_tag(key)
        nested = tag + 'Field'
        need = 1 + max(field.key.quoted_need, field.value.need)
        actual = len(self.raw)-index
        text = self.head([prior_module], 'Exact original scalar field, including its original separator.')
        text += f'''namespace {nested}

def fieldChars : List Char := {base.chars(self.raw, field.prefix_start, field.prefix_end)}
def fieldKey : String := String.ofList {base.quote_list(key)}
def fieldValue : SourceJson := {base.lean_node(field.value)}
def fieldAcc : List (String × SourceJson) := (fieldKey, fieldValue) :: {prior_acc}

theorem object_scalar (fuel : Nat) (tail : List Char) :
    SourceJson.object (fuel + {need}) (SourceJson.white (fieldChars ++ tail)) {prior_acc} =
      SourceJson.object (fuel + {need-1}) (SourceJson.white tail) fieldAcc := by rfl

'''
        text += self.emit_split('field_original', field.prefix_start, field.prefix_end, 'fieldChars')
        text += f'''theorem object_original_field :
    SourceJson.object {actual} (SourceJson.white (sourceRest {field.prefix_start})) {prior_acc} =
      SourceJson.object {actual-1} (SourceJson.white (sourceRest {field.prefix_end})) fieldAcc :=
  (congrArg (fun chars => SourceJson.object {actual} (SourceJson.white chars) {prior_acc})
    field_original_split).trans (object_scalar {actual-need} (sourceRest {field.prefix_end}))

theorem sourceChars_through_field :
    SourceJson.value {len(self.raw)+1} sourceChars =
      SourceJson.object {actual-1} (SourceJson.white (sourceRest {field.prefix_end})) fieldAcc :=
  {prior_whole}.trans object_original_field

'''
        text += self.foot(['object_scalar', 'field_original_prefix', 'field_original_split',
                          'object_original_field', 'sourceChars_through_field'], nested)
        return self.save(self.tag+tag+'Field', text, 'Complete original scalar field and next object state',
            {'key': key, 'field_span': [field.prefix_start, field.prefix_end],
             'actual_object_fuels': [actual, actual-1], 'complete_field_proved': True,
             'stage_generator': fp(Path(__file__))})

    def whole_value(self):
        field = self.node.fields[-1]
        key = field.key.scalar
        assert key == 'integral_gap' and field.separator == '}' and field.prefix_end == self.node.end
        prior_module, prior_acc, prior_whole = self.prior(key)
        index = self.field_index[key]
        need = 1 + max(field.key.quoted_need, field.value.need)
        actual = len(self.raw)-index
        text = self.head([prior_module], 'Last original field, closing object and complete original value success.')
        text = text.replace('No whole-cell parse or typed decoding claim is made by this pilot.',
                            'This owner proves the complete original value equation; typed decoding is separate.')
        text += f'''def finalFieldChars : List Char := {base.chars(self.raw, field.prefix_start, field.prefix_end)}
def finalFieldKey : String := String.ofList {base.quote_list(key)}
def finalFieldValue : SourceJson := {base.lean_node(field.value)}
def originalGeometryJson01 : SourceJson :=
  .obj (((finalFieldKey, finalFieldValue) :: {prior_acc}).reverse)

theorem object_final_field (fuel : Nat) (tail : List Char) :
    SourceJson.object (fuel + {need}) (SourceJson.white (finalFieldChars ++ tail)) {prior_acc} =
      .ok (originalGeometryJson01, tail) := by rfl

'''
        text += self.emit_split('final_field', field.prefix_start, field.prefix_end, 'finalFieldChars')
        text += f'''theorem final_field_original :
    SourceJson.object {actual} (SourceJson.white (sourceRest {field.prefix_start})) {prior_acc} =
      .ok (originalGeometryJson01, sourceRest {field.prefix_end}) :=
  (congrArg (fun chars => SourceJson.object {actual} (SourceJson.white chars) {prior_acc})
    final_field_split).trans (object_final_field {actual-need} (sourceRest {field.prefix_end}))

theorem sourceChars_whole_value :
    SourceJson.value {len(self.raw)+1} sourceChars =
      .ok (originalGeometryJson01, sourceRest {field.prefix_end}) :=
  {prior_whole}.trans final_field_original

theorem geometryPacked01_whole_value :
    SourceJson.value {len(self.raw)+1} geometryPacked01.toList =
      .ok (originalGeometryJson01, (geometryPacked01.drop {field.prefix_end}).toList) :=
  sourceChars_whole_value

'''
        text += self.foot(['object_final_field', 'final_field_prefix', 'final_field_split',
                          'final_field_original', 'sourceChars_whole_value', 'geometryPacked01_whole_value'])
        return self.save(self.tag+'WholeValue', text, 'Closed complete original value-reader success for cell01',
            {'final_field': key, 'final_field_span': [field.prefix_start, field.prefix_end],
             'whole_value_success_theorem': True, 'tail_offset': field.prefix_end,
             'all_original_field_count': len(self.node.fields), 'stage_generator': fp(Path(__file__))})

    def whole_parse(self):
        end, size = self.node.end, len(self.raw)
        text = self.head(['ImbalancedChen.'+self.tag+'WholeValue',
                          'ImbalancedChen.P2OriginalSaving19ParseFromValue00'],
                         'Original parser success for complete production-packed cell01, including its exact remaining CRLF.')
        text = text.replace('No whole-cell parse or typed decoding claim is made by this pilot.',
                            'This owner proves original parser success for cell01 only. Typed decoding is separate.')
        text += f'def finalTailChars : List Char := {base.chars(self.raw, end, size)}\n\n'
        text += self.emit_split('final_tail', end, size, 'finalTailChars')
        text += f'''theorem sourceRest_exact_tail : sourceRest {end} = finalTailChars :=
  final_tail_split.trans (by rw [sourceRest_end, List.append_nil])

theorem sourceRest_white_tail : SourceJson.white (sourceRest {end}) = [] :=
  (congrArg SourceJson.white sourceRest_exact_tail).trans (by rfl)

theorem sourceChars_parseChars : SourceJson.parseChars sourceChars = .ok originalGeometryJson01 := by
  apply SourceJson.parseChars_of_value_eq
  · simpa only [sourceChars_length] using sourceChars_whole_value
  · exact sourceRest_white_tail

theorem geometryPacked01_parseChars :
    SourceJson.parseChars geometryPacked01.toList = .ok originalGeometryJson01 :=
  sourceChars_parseChars

theorem geometryPacked01_original_parse :
    SourceJson.parse (String.ofList geometryPacked01.toList) = .ok originalGeometryJson01 :=
  (SourceJson.parse_ofList sourceChars).trans sourceChars_parseChars

'''
        text += self.foot(['final_tail_prefix', 'final_tail_split', 'sourceRest_exact_tail',
                          'sourceRest_white_tail', 'sourceChars_parseChars',
                          'geometryPacked01_parseChars', 'geometryPacked01_original_parse'])
        return self.save(self.tag+'WholeParse', text, 'Closed original SourceJson parser success for production-packed cell01',
            {'tail_span': [end, size], 'tail_hex': self.raw[end:].hex(),
             'whole_parse_success_theorem': True, 'all_original_field_count': len(self.node.fields),
             'original_reader_and_white_unchanged': True, 'typed_archive_decode_claimed': False,
             'other_cells_claimed': False, 'stage_generator': fp(Path(__file__))})
