#!/usr/bin/env python3
"""Continue only unaccepted cell01 owners with the restored small grouping."""
import argparse
import json
from advance import ensure
from advance_remainder import ARRAY_FIELDS, complete_array
from generate_remainder_v3 import SmallGroupRemainderEngine


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--through-field', choices=ARRAY_FIELDS+['whole-parse'], default='whole-parse')
    ap.add_argument('--only-field', choices=ARRAY_FIELDS)
    args = ap.parse_args()
    engine = SmallGroupRemainderEngine()
    keys = [args.only_field] if args.only_field else ARRAY_FIELDS
    for key in keys:
        complete_array(engine, key)
        if key == args.through_field or args.only_field:
            return
    ensure(engine, engine.tag+'PhysicalVolumeField', lambda: engine.scalar_field('physical_volume'))
    ensure(engine, engine.tag+'WholeValue', engine.whole_value)
    ensure(engine, engine.tag+'WholeParse', engine.whole_parse)
    print(json.dumps({'cell': 1, 'whole_cell_parse_proved': True,
                      'typed_geometry_proved': False, 'all13_pass_claimed': False}), flush=True)


if __name__ == '__main__':
    main()
