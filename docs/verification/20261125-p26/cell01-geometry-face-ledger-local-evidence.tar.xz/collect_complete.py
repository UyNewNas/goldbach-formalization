#!/usr/bin/env python3
"""Freeze complete cell01 original-parser evidence; this script never compiles."""
from pathlib import Path
import hashlib
import json
import re

WORK = Path(__file__).resolve().parent
BASELINE = WORK.parents[1]
TARGET = 'ImbalancedChen.P2OriginalSaving19Geometry01DirectWholeParse'
ALLOWED_AXIOMS = {'propext', 'Quot.sound', 'Classical.choice'}
cache = {}


def fp(path):
    path = Path(path)
    key = str(path)
    stat = path.stat()
    identity = (stat.st_size, stat.st_mtime_ns)
    if key not in cache or cache[key][0] != identity:
        data = path.read_bytes()
        cache[key] = (identity, {'path': key, 'bytes': len(data),
                               'sha256': hashlib.sha256(data).hexdigest()})
    return cache[key][1]


def save(path, data):
    data = data.encode() if isinstance(data, str) else data
    if path.exists():
        assert path.read_bytes() == data, ('Frozen complete evidence drift', str(path))
    else:
        path.write_bytes(data)


def main():
    frozen_doc = json.loads((WORK / 'FROZEN_SUPPLIERS.json').read_text())
    frozen = {row['module']: row for row in frozen_doc['inputs']}
    owners = {}
    for path in (WORK / 'owners').glob('*.json'):
        row = json.loads(path.read_text())
        owners[row['module']] = (path, row)
    assert TARGET in owners and owners[TARGET][1]['whole_cell_parse_claimed'] is True
    known = {**frozen, **{module: pair[1] for module, pair in owners.items()}}
    seen, ordered = set(), []

    def visit(module):
        if module in seen:
            return
        seen.add(module)
        row = known[module]
        assert fp(row['source']['path']) == row['source']
        for dep in row['project_imports']:
            visit(dep)
        ordered.append(module)

    visit(TARGET)
    assert not any('CharacterCore' in m or 'GeometryPackedTransport' in m or
                   m.endswith('WholeParse00') for m in ordered)
    inputs, checked, failures = [], [], []
    axioms = set()
    total_theorems = 0
    for module in ordered:
        if module in frozen:
            row = frozen[module]
            assert fp(row['object']['path']) == row['object']
            copied = fp(WORK / 'objects' / (module.replace('.', '/') + '.olean'))
            assert all(copied[k] == row['object'][k] for k in ['bytes', 'sha256'])
            inputs.append({**row, 'copied_object': copied, 'role': 'accepted_frozen_supplier',
                           'recompiled': False})
            continue
        owner_path, row = owners[module]
        assert fp(row['fixture']['path']) == row['fixture']
        short = module.split('.')[-1]
        object_fp = fp(WORK / 'objects' / (module.replace('.', '/') + '.olean'))
        accepted = {}
        for mode in ['normal', 'kernel']:
            matches = []
            for path in sorted((WORK / 'logs' / short).glob(mode + '-*-result.json')):
                receipt = json.loads(path.read_text())
                assert fp(receipt['log']['path']) == receipt['log']
                if receipt['status'] != 'succeeded':
                    failures.append(fp(path))
                    continue
                if receipt['source'] != row['source']:
                    continue
                assert receipt['exit_code'] == 0 and receipt['object'] == object_fp
                assert receipt['source_manifest'] == fp(owner_path)
                assert receipt['rss_limit_bytes'] == 4 * 1024**3 and receipt['wall_seconds'] == 180
                assert receipt['accepted_dependencies_recompiled'] is False
                assert receipt['source_object_invariants_before'] == receipt['source_object_invariants_after']
                for invariant in receipt['source_object_invariants_after']:
                    assert fp(invariant['path']) == invariant
                matches.append((path, receipt))
            assert len(matches) == 1, (module, mode, 'Expected one successful current-source receipt')
            accepted[mode] = matches[0]
        normal = accepted['normal'][1]
        kernel = accepted['kernel'][1]
        assert normal['attempt'] == kernel['attempt']
        text = Path(row['source']['path']).read_text()
        assert not re.search(r'\b(?:sorry|admit|native_decide)\b|(?m:^\s*(?:axiom|unsafe)\b)', text)
        declarations = re.findall(r'(?m)^theorem\s+(\S+)', text)
        printed = re.findall(r'(?m)^#print axioms\s+(\S+)', text)
        assert len(declarations) == len(printed) and len(printed) == len(set(printed))
        log = Path(normal['log']['path']).read_text()
        outputs = re.findall(r"(?m)^'[^']+' (?:depends on axioms:|does not depend on any axioms)", log)
        assert len(outputs) == len(declarations)
        current_axioms = set(normal['printed_axioms'])
        assert current_axioms <= ALLOWED_AXIOMS
        axioms |= current_axioms
        total_theorems += len(declarations)
        summary = {
            'module': module, 'source': row['source'], 'object': object_fp,
            'owner_manifest': fp(owner_path), 'scope': row['scope'],
            'planned_obligations': row['planned_obligations'],
            'project_imports': row['project_imports'], 'theorem_count': len(declarations),
            'normal_receipt': fp(accepted['normal'][0]),
            'kernel_receipt': fp(accepted['kernel'][0]),
            'normal_seconds': normal['elapsed_seconds'], 'kernel_seconds': kernel['elapsed_seconds'],
            'normal_peak_rss_bytes': normal['peak_rss_bytes'],
            'kernel_peak_rss_bytes': kernel['peak_rss_bytes'],
            'printed_axioms': sorted(current_axioms),
        }
        checked.append(summary)
        inputs.append({'module': module, 'source': row['source'], 'object': object_fp,
                       'project_imports': row['project_imports'], 'role': 'new_checked_owner',
                       'normal_receipt': summary['normal_receipt'],
                       'kernel_receipt': summary['kernel_receipt']})
    assert len(checked) == len(owners), 'Inspect unused or unaccepted generated owners before freezing.'
    bootstrap = json.loads((WORK / 'BOOTSTRAP.json').read_text())
    raw = fp(bootstrap['input_original']['path'])
    assert raw == bootstrap['input_original']
    assert raw['bytes'] == 470901 and raw['sha256'] == 'e19eee9d7e282cd3a618a71f12e93bcce28319485c9d0fd31bbeaf9f81a995a4'
    original_manifest = json.loads((BASELINE / 'SOURCE_ONLY_MANIFEST.json').read_text())
    for row in original_manifest['files']:
        assert all(fp(BASELINE / row['relative_path'])[k] == row[k]
                   for k in ['path', 'bytes', 'sha256'])
    terminal = Path(owners[TARGET][1]['source']['path']).read_text()
    assert 'theorem geometryPacked01_original_parse :' in terminal
    assert 'SourceJson.parse (String.ofList geometryPacked01.toList) = .ok originalGeometryJson01' in terminal
    source_inputs = {'target': TARGET, 'project_closure_count': len(inputs),
                     'new_owner_count': len(checked), 'frozen_supplier_count': len(frozen),
                     'inputs': inputs}
    save(WORK / 'SOURCE_INPUTS.json', json.dumps(source_inputs, indent=2) + '\n')
    peak = max(max(x['normal_peak_rss_bytes'], x['kernel_peak_rss_bytes']) for x in checked)
    manifest = {
        'status': 'CELL01_COMPLETE_ORIGINAL_PARSER_NORMAL_AND_INDEPENDENT_KERNEL_PASSED',
        'target': TARGET, 'cell': 1, 'raw_original': raw,
        'production_input_FQN': 'ImbalancedChen.P2OriginalSaving19Archive.geometryPacked01',
        'parsed_JSON_FQN': 'ImbalancedChen.P2OriginalSaving19Geometry01DirectParsing.originalGeometryJson01',
        'whole_parse_theorem_FQN': 'ImbalancedChen.P2OriginalSaving19Geometry01DirectParsing.geometryPacked01_original_parse',
        'original_value_fuel': 470902, 'original_JSON_value_end': 470899,
        'final_original_tail_hex': '0d0a', 'all_original_fields_retained': 14,
        'new_owner_count': len(checked), 'frozen_supplier_count': len(frozen),
        'project_closure_count': len(inputs), 'new_theorem_count': total_theorems,
        'axioms_union': sorted(axioms), 'max_observed_rss_bytes': peak,
        'fixed_limits': {'rss_bytes': 4*1024**3, 'wall_seconds': 180, 'threads': 1},
        'owners': checked, 'preserved_failed_receipts': failures,
        'source_inputs': fp(WORK / 'SOURCE_INPUTS.json'),
        'bootstrap': fp(WORK / 'BOOTSTRAP.json'), 'raw_plan': fp(WORK / 'RAW_PLAN.json'),
        'frozen_suppliers': fp(WORK / 'FROZEN_SUPPLIERS.json'),
        'frozen_v1_baseline_unchanged': True, 'frozen_v1_commit': '94148a71e2bc9b6627a98eeebd961f78076b4f08',
        'whole_cell_parse_proved': True, 'typed_geometry_decoding_proved': False,
        'archive_shape_or_row_guards_proved': False, 'numerical_floors_proved': False,
        'all13_pass_claimed': False, 'cell00_reparsed': False,
        'production_modified': False, 'remote_jobs_submitted': False,
        'accepted_dependencies_recompiled': False,
        'P1_original_path_acceptance_claimed': False,
        'full_public_ZIP_hash_verified': False, 'host_plan_is_proof': False,
    }
    save(WORK / 'SOURCE_MANIFEST.json', json.dumps(manifest, indent=2) + '\n')
    report = f'''# Complete original SourceJson parsing: cell01

The closed theorem `geometryPacked01_original_parse` proves that the unchanged
original parser returns the explicitly defined `originalGeometryJson01` from
`String.ofList Archive.geometryPacked01.toList`. The preceding whole-value
theorem uses the original fuel 470902 and returns the exact untouched remaining
CRLF at offset 470899; original `white` is separately proved to remove that tail.

The original member is 470901 bytes, SHA256
`e19eee9d7e282cd3a618a71f12e93bcce28319485c9d0fd31bbeaf9f81a995a4`.
The production-compatible Data01 object is reused from the accepted v1 private
mirror. No full public-ZIP SHA verification or P1 original-path acceptance is
claimed by this local proof package.

All 14 original fields remain in order, with the original strings, numbers,
metadata, duplicate-key checks, separators, reverse accumulators and CRLF.
Large child values are proved through bounded original array/object transitions
and opaque child certificates. Actual compact-input spans are separately bound;
large spans are assembled from smaller binding equations. No whole-file decide,
replacement reader, or assumed parser-success premise is used.

The project closure contains {len(inputs)} modules: {len(frozen)} frozen suppliers
and {len(checked)} new owners. Every new owner passed normal compilation and
independent kernel replay with 4 GiB process-tree RSS, 180 seconds and one thread.
The maximum observed RSS was {peak:,} bytes. The {total_theorems} new theorem
declarations all have printed axiom reports; their union is
{', '.join(sorted(axioms)) or 'empty'}. Preserved failed attempt receipts, if any,
are separately listed in SOURCE_MANIFEST.json.

This package proves pure parsing of cell01 only. Typed geometry decoding, shape
checks, numerical floors, the other cells and complete Saving19 remain separate.
The v1 four-owner proof and eleven generator baseline files were not changed or
recompiled; no cell00 parser was rerun and no remote compiler task was submitted.

SOURCE_MANIFEST.json records the exact statements' owners, source/object hashes,
normal/kernel receipts, resource measurements and scope. SOURCE_INPUTS.json
records the complete project import closure and accepted supplier identities.
'''
    save(WORK / 'PURE_PARSE_REPORT.md', report)
    files = sorted(str(p.relative_to(WORK)) for p in WORK.rglob('*') if p.is_file()
                   and not any(x in p.relative_to(WORK).parts for x in
                               ['objects', 'goldbach-research', '__pycache__'])
                   and p != WORK / 'EXPORT_FILELIST.txt')
    files.append('EXPORT_FILELIST.txt')
    save(WORK / 'EXPORT_FILELIST.txt', '\n'.join(sorted(files)) + '\n')
    print(json.dumps({'manifest': fp(WORK/'SOURCE_MANIFEST.json'),
                      'inputs': fp(WORK/'SOURCE_INPUTS.json'),
                      'report': fp(WORK/'PURE_PARSE_REPORT.md'),
                      'export_files': len(files),
                      'export_bytes': sum((WORK/name).stat().st_size for name in files)}, indent=2))


if __name__ == '__main__':
    main()
