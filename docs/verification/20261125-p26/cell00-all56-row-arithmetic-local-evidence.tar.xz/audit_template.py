from pathlib import Path
import hashlib,json,re

R=Path(__file__).resolve().parent
B=Path('/workspace/p26-recovery-candidates/archive-row00-arithmetic/representation-v2/project/ImbalancedChen')

def fp(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def block(text,name):
 m=re.search(r'^theorem '+name+r'\b[\s\S]*?(?=\n\n)',text,re.M)
 assert m,name
 return m[0]
def compact(s):return re.sub(r'\s+',' ',s).strip()

donors={}
for suffix in ['Determinant','Physical','Gap','Means','Maxima','Jensen']:
 p=B/('P2OriginalSaving19Cell00Row000'+suffix+'.lean')
 text=p.read_text()
 for name in re.findall(r'^theorem (\w+)\b',text,re.M):
  donors[name]={'owner':fp(p),'text':block(text,name)}
assert len(donors)==11
records=[]
for row in range(1,56):
 p=R/'project/ImbalancedChen'/f'P2OriginalSaving19Cell00Row{row:03d}Arithmetic.lean'
 text=p.read_text()
 checks=[]
 for name,d in donors.items():
  current=block(text,name)
  assert compact(current)==compact(d['text']),(row,name)
  checks.append({'theorem':name,'same_statement_and_body_modulo_whitespace':True,
    'canonical_text_sha256':hashlib.sha256(compact(current).encode()).hexdigest()})
 plan=json.loads((R/'plans'/f'row{row:03d}.json').read_text())
 assert fp(p)==plan['source']
 ids=plan['original_ordered_vertex_ids']
 quoted=[int(x) for x in re.findall(r'geometryVerticesTyped(\d+)\[j.val\]!',text)]
 assert quoted==ids,(row,quoted,ids)
 assert f'noncomputable def row : GeometryRow := geometryRowsTyped{row:03d}' in text
 assert f'boundedRow ({row} : Fin 56) = row' in text
 assert f'boundedRowVertex ({row} : Fin 56) = vertices' in text
 records.append({'row':row,'source':fp(p),'original_vertex_order_exact':True,
   'same_11_arithmetic_theorem_statements_and_bodies':checks})

out=R/'ROW_TEMPLATE_AUDIT.json';assert not out.exists()
out.write_text(json.dumps({'schema':'saving19_rows1to55_original_row000_template_source_audit_v1',
 'rows_covered':list(range(1,56)), 'row000_donor_sources':[
  {'theorem':name,'owner':d['owner'],'canonical_text_sha256':hashlib.sha256(compact(d['text']).encode()).hexdigest()}
  for name,d in donors.items()],
 'records':records,'arithmetic_proofs_reimplemented':False,
 'host_mathematical_check_performed':False,
 'scope':'Text/provenance audit only; every actual arithmetic proposition separately normal/kernel verified.'},indent=2)+'\n')
print(json.dumps(fp(out)))
