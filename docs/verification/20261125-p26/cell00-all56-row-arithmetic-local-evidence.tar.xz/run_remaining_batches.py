from pathlib import Path
import json,subprocess,sys

R=Path(__file__).resolve().parent
for start,end in [(16,23),(24,31),(32,39),(40,47),(48,55)]:
 with (R/'plans'/f'generated-{start:03d}-{end:03d}.jsonl').open('x') as output:
  p=subprocess.run([sys.executable,str(R/'generate_rows.py'),str(start),str(end)],stdout=output)
 if p.returncode:sys.exit(p.returncode)
 p=subprocess.run([sys.executable,'-u',str(R/'run_batch.py'),str(start),str(end)])
 if p.returncode:sys.exit(p.returncode)
 p=subprocess.run([sys.executable,str(R/'checkpoint_batch.py'),str(start),str(end)])
 if p.returncode:sys.exit(p.returncode)
 print(json.dumps({'checkpoint_complete':[start,end]}),flush=True)
