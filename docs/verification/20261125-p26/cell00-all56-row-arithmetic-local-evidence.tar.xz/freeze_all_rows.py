from pathlib import Path
import hashlib,json,re

R=Path(__file__).resolve().parent
P=R/'project';O=R/'objects'

def fp(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def put(p,data):
 assert not p.exists(),p
 p.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')

boot=json.loads((R/'BOOTSTRAP.json').read_text())
borrowed={x['module']:x for x in boot['reused_helpers']}
new={};failed=[]
for p in sorted((R/'logs').glob('*/normal-*-result.json')):
 n=json.loads(p.read_text())
 if n['status']!='succeeded':
  failed.append({'receipt':fp(p),'status':n['status'],'source':n['source'],'log':n['log']});continue
 stem=n['module'].split('.')[-1];tag=n['attempt']
 kp=p.with_name('kernel-'+tag+'-result.json');k=json.loads(kp.read_text())
 assert k['status']=='succeeded' and k['exit_code']==0
 source=P/'ImbalancedChen'/(stem+'.lean');obj=O/'ImbalancedChen'/(stem+'.olean')
 assert fp(source)==n['source']==k['source'] and fp(obj)==n['object']==k['object']
 assert n['dependencies']==k['dependencies']
 assert n['input_before']==n['input_after']==k['input_before']==k['input_after']
 log=Path(n['log']['path']).read_text();assert not re.search(r'warning:|error:|sorryAx|native_decide|Lean\.ofReduceBool',log)
 ax=[]
 for decl,values in re.findall(r"'([^']+)' depends on axioms:\s*\[([^]]*)\]",log,re.S):
  names=[s.strip() for s in values.split(',') if s.strip()]
  assert set(names)<={'propext','Classical.choice','Quot.sound'}
  ax.append({'declaration':decl,'axioms':names})
 for decl in re.findall(r"'([^']+)' does not depend on any axioms",log):ax.append({'declaration':decl,'axioms':[]})
 expected=4 if stem=='P2OriginalSaving19Cell00AllRowArithmetic' else 21
 assert len(ax)==expected,(stem,len(ax))
 new[n['module']]={'source':fp(source),'object':fp(obj),'normal_receipt':fp(p),'kernel_receipt':fp(kp),
  'normal_seconds':n['elapsed_seconds'],'kernel_seconds':k['elapsed_seconds'],
  'normal_peak_rss_bytes':n['peak_rss_bytes'],'kernel_peak_rss_bytes':k['peak_rss_bytes'],'printed_axioms':ax}
assert len(new)==56,len(new)

seen=set();rows=[]
def visit(mod):
 if mod in seen:return
 seen.add(mod)
 p=P/(mod.replace('.','/')+'.lean');o=O/(mod.replace('.','/')+'.olean')
 imports=re.findall(r'^import\s+(\S+)',p.read_text(),re.M)
 for dep in imports:
  if dep.startswith('ImbalancedChen.'):visit(dep)
 row={'module':mod,'source':fp(p),'object':fp(o),'imports':imports}
 if mod in new:
  row.update({'new_verified_owner':True,'normal_receipt':new[mod]['normal_receipt'],'kernel_receipt':new[mod]['kernel_receipt']})
 else:
  b=borrowed[mod];assert row['source']==b['source']['copy'] and row['object']==b['object']['copy']
  row.update({'reused_accepted_owner':True,'original_source':b['source']['original'],
   'original_object':b['object']['original'],'recompiled':False})
 rows.append(row)
visit('ImbalancedChen.P2OriginalSaving19Cell00AllRowArithmetic')
rows.sort(key=lambda x:x['module']);assert len(rows)==409,len(rows)
canonical=[{'module':x['module'],'source_sha256':x['source']['sha256'],'source_bytes':x['source']['bytes'],'imports':x['imports']} for x in rows]
closure=hashlib.sha256(json.dumps(canonical,sort_keys=True,separators=(',',':')).encode()).hexdigest()
put(R/'FULL_SOURCE_CLOSURE.json',{'schema':'saving19_cell00_all_row_arithmetic_closure_v1',
 'project_modules':len(rows),'new_verified_owners':len(new),'reused_accepted_owners':len(rows)-len(new),
 'source_closure_canonical_sha256':closure,'canonical_source_rows':canonical,
 'sources_objects_and_receipts':rows,'base_row000_package':boot['row000_base_package'],
 'P1_strict_claimed':False,'old_analytic_context_modified':False})
put(R/'SOURCE_MANIFEST.json',{'schema':'saving19_cell00_all_row_arithmetic_new_sources_v1',
 'new_sources':[{'module':m,**x} for m,x in sorted(new.items())],
 'full_closure':fp(R/'FULL_SOURCE_CLOSURE.json'),
 'base_row000_package':boot['row000_base_package'],'failed_attempts':failed})

normal=sum(x['normal_seconds'] for x in new.values());kernel=sum(x['kernel_seconds'] for x in new.values())
peakN=max(x['normal_peak_rss_bytes'] for x in new.values());peakK=max(x['kernel_peak_rss_bytes'] for x in new.values())
checkpoints=[fp(p) for p in sorted((R/'checkpoints').glob('*/CHECKPOINT.json'))]
assert len(checkpoints)==7
result={'schema':'saving19_cell00_all_row_arithmetic_local_result_v1',
 'status':'all_56_actual_cell00_rows_complete_ten_clause_guard_passed_locally',
 'new_verified_owners':56,'reused_accepted_owners':353,
 'successful_invocations':112,'failed_invocations':len(failed),'failures':failed,
 'printed_axiom_sets':sum(len(x['printed_axioms']) for x in new.values()),
 'all_printed_axioms_standard_only':True,'normal_seconds':normal,'kernel_seconds':kernel,
 'normal_peak_rss_bytes':peakN,'kernel_peak_rss_bytes':peakK,
 'budget_each_call':{'rss_bytes':4*1024**3,'wall_seconds':180,'threads':1},
 'source_closure_canonical_sha256':closure,'checkpoints':checkpoints,
 'rows':56,'physical_vertex_occurrences':56*9,'weighted_means':56*10,
 'maximum_dominations':56*9*10,'maximum_attainments':56*10,
 'exact_old_geometry_Q96_floors':56,'exact_old_moment_floor_correspondences':56,
 'final_namespace':'ImbalancedChen.P2OriginalSaving19Cell00AllRowArithmetic',
 'closed_theorems':['all_bounded_row_data_checks','all_raw_row_data_checks',
  'all_moment_old_matches_geometry','all_moment_old_eq_evaluator'],
 'row000_or_other_accepted_helpers_recompiled':False,
 'Q80_or_new_Q96_validity_claimed':False,'rationalMoment_degree6_bridge_claimed':False,
 'Archive_aliases_connected':False,'original_namespace_bridge_accepted':False,
 'other_12_cells_claimed':False,'global_28918_rows_claimed':False,
 'pulling_or_integral_endpoint_claimed':False,'P1_strict_claimed':False,
 'production_or_existing_analytic_source_modified':False,'remote_jobs_submitted':False}
put(R/'RESULT.json',result)

table='\n'.join('| '+str(json.loads(Path(p['path']).read_text())['rows'])+' | '+str(json.loads(Path(p['path']).read_text())['new_source_count'])+' | '+f"{json.loads(Path(p['path']).read_text())['normal_seconds']:.3f}"+' | '+f"{json.loads(Path(p['path']).read_text())['kernel_seconds']:.3f}"+' | '+str(json.loads(Path(p['path']).read_text())['max_rss_bytes'])+' |' for p in checkpoints)
report=f'''# Cell00 全部 56 行：精确原始 row arithmetic

## 结论与实际数据绑定

最终 owner `P2OriginalSaving19Cell00AllRowArithmetic` 已通过本地 normal 和独立
leanchecker。四个无假设定理在 namespace
`ImbalancedChen.P2OriginalSaving19Cell00AllRowArithmetic`：

- `all_bounded_row_data_checks`：对全部 `r : Fin 56`，原有界实际 vertices/row
  满足完整十项 `RowNumericsPure.RowDataChecksFor`。
- `all_raw_row_data_checks`：同一个结果接回 `concreteGeometry00` 原数组和原 row
  vertexIds 的三级索引公式；用已过的无 fallback 等式，不假设默认值正确。
- `all_moment_old_matches_geometry`：每条原 moment 的旧 Q96 字段等于对应实际
  geometry row 的 Jensen floor。
- `all_moment_old_eq_evaluator`：每条旧 moment floor 等于原公式的精确
  `oldFloorQ96 (massOf (boundedRow r)) (meansOf (boundedRow r))`。

全部十项包括 56 个非零 Matrix.det 与体积/8!等式，504 个按原行顺序选取的
PhysicalQ 点，56 个正 gap 总和及 meanGap，560 个 weighted means，5040 个
maxima domination，560 个 maxima attainment，56 个精确 Jensen 有理数和旧 Q96。
这里的点出现次数不是不同顶点数量；实际 cell00 的 28 个顶点未被增删或重排。

## 表示与来源

row0 和轻量 pure helpers 使用已冻结的上一包，无重新编译。新 row1–55 每行一个
owner，原先各个小 proof 保留为 21 个独立声明，统一放进一个模块以免反复载入相同
环境。每行引用其已 decoded 的 `geometryRowsTypedNNN` 和原 `vertexIds` 所指的
原 typed vertex 数组；生成器只机械摘录 index，不运行 host 数学预检查。
两条闭合 rfl/FinCases 等式绑定真正的 boundedRow/boundedRowVertex。全数值检查
仍用原 Rat/Int 运算和 `decide +kernel`；行列式只借既有 fastDet 原 proof 改写回
同一个 Matrix.det 规范。最后 owner 仅组合不透明已过定理，不重跑任何 row 判断。

Pure 命名空间的 13 个 Q96 定义、fastDet 原算法/proof、完整十合取来源和独立
审查都在 row0 基包固定。它们保留原公式的泛型量词与 rounding 方向。
旧 Q96/Consumer/Core 分析对象未更换；接回旧命名空间的 rfl/Iff.rfl bridge
不在本轮接受范围。原稿依据与有限代数表示界限沿用基包记录，没有新的分析估计。

## 验证和逐批冻结

新 55 个 row owner 加最终 assembly 共 56 个新 owner、112 次成功调用。
其余 353 个已通过 source/object 逐字复用，最终项目闭包 409 个 owner，canonical：
`{closure}`。

每调用固定 4 GiB RSS、180 秒、1 线程；Lean 4.33.0-rc1 / commit
62eed1db4d67327ec8120be05f1a1b0847d74561，Mathlib
e4c91783ca8e6a7c693ae624ade32fd22d4e43c1。累计成功 normal {normal:.3f}s、
独立 kernel {kernel:.3f}s；normal 峰值 {peakN} B，kernel 峰值 {peakK} B。
本轮失败 {len(failed)} 次。全部 {result['printed_axiom_sets']} 个打印的依赖集合
仅含标准 propext、Classical.choice、Quot.sound，无新 axiom 或成功占位。

| 新行范围 | owner数 | normal 秒 | kernel 秒 | 最高 RSS B |
|---|---:|---:|---:|---:|
{table}

每批 checkpoint 固定其源、normal/kernel 回执和无对象 delta whitelist；任何
已通过行、原 row0 或纯 helper 都没有重新编译。原 fixture、所有复用 source/object
以及每次目标的 source/object 前后指纹均在回执中核对。剩余边界在 RESULT 中列明。

## 未声明完成的义务

这是 cell00 全部 row arithmetic 和旧 moment floor 第 3、4 项，不是完整
FloorChecks。十个 Q80、原 degree≤6 rationalMoment 对应以及新 Q96 的
`max old new` 仍由独立任务处理。未声称其它 12 cell、28918 行全局和、
Archive/Core aliases、pulling/ownership、实际积分端点或 P1 strict 已完成。
本轮没有发现实际数据的算术反例；原余下证明义务保持原样，不用新假设覆盖。
'''
assert not (R/'REPORT.md').exists();(R/'REPORT.md').write_text(report)
put(R/'PUBLICATION_SOURCES.json',{'schema':'saving19_cell00_allrow_publication_delta_v1',
 'verified_sources':[{'module':m,'source':x['source'],'relative_path':str(Path(x['source']['path']).relative_to(R))} for m,x in sorted(new.items())],
 'base_row000_package':boot['row000_base_package'],'all_local_normal_kernel':True,'P1_claimed':False})

files=[]
for p in sorted(R.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(R)
 if rel.parts[0]=='objects' or '__pycache__' in rel.parts:continue
 if rel.parts[0]=='project' and 'ImbalancedChen.'+p.stem not in new:continue
 files.append({'relative_path':str(rel),**fp(p)})
put(R/'DELTA_WHITELIST.json',{'schema':'saving19_cell00_allrow_delta_no_objects_v1',
 'relative_to':str(R),'files':files,'contains_objects':False,
 'base_row000_package':boot['row000_base_package'],'source_closure_canonical_sha256':closure})
put(R/'PACKAGE_MANIFEST.json',{'schema':'saving19_cell00_allrow_local_package_v1',
 'files':files,'whitelist':fp(R/'DELTA_WHITELIST.json'),'report':fp(R/'REPORT.md'),
 'result':fp(R/'RESULT.json'),'sources':fp(R/'SOURCE_MANIFEST.json'),
 'full_closure':fp(R/'FULL_SOURCE_CLOSURE.json'),'publication':fp(R/'PUBLICATION_SOURCES.json')})
print(json.dumps({'new_verified':len(new),'project_closure':len(rows),'closure':closure,
 'package':fp(R/'PACKAGE_MANIFEST.json'),'whitelist':fp(R/'DELTA_WHITELIST.json'),
 'report':fp(R/'REPORT.md'),'result':fp(R/'RESULT.json')},indent=2))
