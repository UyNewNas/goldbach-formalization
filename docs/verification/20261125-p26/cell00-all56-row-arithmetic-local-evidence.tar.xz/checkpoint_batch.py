from pathlib import Path
import hashlib,json,re,sys

R=Path(__file__).resolve().parent
start=int(sys.argv[1]);end=int(sys.argv[2])
assert 1<=start<=end<56
C=R/'checkpoints'/f'rows-{start:03d}-{end:03d}'
assert not C.exists(),C
C.mkdir(parents=True)

def fp(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def put(p,data):
 assert not p.exists(),p
 p.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')

new=[];files=[]
for row in range(start,end+1):
 stem=f'P2OriginalSaving19Cell00Row{row:03d}Arithmetic'
 folder=R/'logs'/stem
 npath=folder/'normal-exact-v1-result.json';kpath=folder/'kernel-exact-v1-result.json'
 n=json.loads(npath.read_text());k=json.loads(kpath.read_text())
 assert n['status']==k['status']=='succeeded' and n['exit_code']==k['exit_code']==0
 source=R/'project/ImbalancedChen'/(stem+'.lean');obj=R/'objects/ImbalancedChen'/(stem+'.olean')
 assert fp(source)==n['source']==k['source'];assert fp(obj)==n['object']==k['object']
 assert n['dependencies']==k['dependencies']
 assert n['input_before']==n['input_after']==k['input_before']==k['input_after']
 log=Path(n['log']['path']).read_text()
 assert not re.search(r'warning:|error:|sorryAx|native_decide|Lean\.ofReduceBool',log)
 axioms=[]
 for name,a in re.findall(r"'([^']+)' depends on axioms:\s*\[([^]]*)\]",log,re.S):
  names=[v.strip() for v in a.split(',') if v.strip()]
  assert set(names)<={'propext','Classical.choice','Quot.sound'}
  axioms.append({'declaration':name,'axioms':names})
 assert len(axioms)==21,(row,len(axioms))
 record={'row':row,'module':'ImbalancedChen.'+stem,'source':fp(source),'object':fp(obj),
  'normal_receipt':fp(npath),'kernel_receipt':fp(kpath),
  'normal_seconds':n['elapsed_seconds'],'kernel_seconds':k['elapsed_seconds'],
  'normal_peak_rss_bytes':n['peak_rss_bytes'],'kernel_peak_rss_bytes':k['peak_rss_bytes'],
  'printed_axioms':axioms,'plan':fp(R/'plans'/f'row{row:03d}.json')}
 new.append(record)
 for p in [source,R/'plans'/f'row{row:03d}.json']+sorted(folder.iterdir())+sorted((R/'attempts'/stem/'exact-v1').iterdir()):
  files.append({'relative_path':str(p.relative_to(R)),**fp(p)})

put(C/'SOURCE_MANIFEST.json',{'schema':'saving19_cell00_row_batch_v1',
 'rows':[start,end],'verified_owners':new,'existing_suppliers_recompiled':False,
 'same_ten_clause_guard':True,'moment_old_floor_clauses_3_and_4_only':True,
 'Q80_or_new_Q96_claimed':False,'Archive_aliases_connected':False,'P1_claimed':False})
put(C/'DELTA_WHITELIST.json',{'schema':'saving19_cell00_row_batch_delta_v1',
 'relative_to':str(R),'files':files,'contains_objects':False,
 'base_bootstrap':fp(R/'BOOTSTRAP.json'),'generator':fp(R/'generate_rows.py'),
 'same_normal_kernel_budget':{'rss_bytes':4*1024**3,'seconds':180,'threads':1}})
put(C/'CHECKPOINT.json',{'schema':'saving19_cell00_row_batch_checkpoint_v1',
 'rows':[start,end],'all_normal_and_independent_kernel_passed':True,
 'new_source_count':len(new),'printed_axiom_sets':sum(len(x['printed_axioms']) for x in new),
 'normal_seconds':sum(x['normal_seconds'] for x in new),'kernel_seconds':sum(x['kernel_seconds'] for x in new),
 'max_rss_bytes':max(max(x['normal_peak_rss_bytes'],x['kernel_peak_rss_bytes']) for x in new),
 'sources':fp(C/'SOURCE_MANIFEST.json'),'whitelist':fp(C/'DELTA_WHITELIST.json')})
print(json.dumps({'checkpoint':fp(C/'CHECKPOINT.json'),'sources':fp(C/'SOURCE_MANIFEST.json'),
 'whitelist':fp(C/'DELTA_WHITELIST.json')},indent=2))
