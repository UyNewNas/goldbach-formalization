from pathlib import Path
import json,subprocess,sys

R=Path(__file__).resolve().parent
start=int(sys.argv[1]);end=int(sys.argv[2])
assert 1<=start<=end<56
for row in range(start,end+1):
 stem=f'P2OriginalSaving19Cell00Row{row:03d}Arithmetic'
 assert (R/'project/ImbalancedChen'/(stem+'.lean')).is_file()
 assert not (R/'objects/ImbalancedChen'/(stem+'.olean')).exists(),'Never recompile successful owner'
 for mode in ['normal','kernel']:
  p=subprocess.run([sys.executable,str(R/'run_local.py'),mode,'ImbalancedChen.'+stem,'exact-v1'],
   stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
  result=R/'logs'/stem/(mode+'-exact-v1-result.json')
  if result.exists():
   d=json.loads(result.read_text())
   print(json.dumps({k:d[k] for k in ['module','mode','status','elapsed_seconds','peak_rss_bytes']}),flush=True)
  else:print(p.stdout,flush=True)
  if p.returncode:
   print(p.stdout,flush=True);sys.exit(p.returncode)
