from pathlib import Path
import hashlib,json,re,sys

R=Path(__file__).resolve().parent
P=R/'project/ImbalancedChen'

def fp(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}

def marker(row,label):
 return f'''run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_CELL00_ROW{row:03d} {label}"
  err.flush

'''

def generate(r):
 assert 1<=r<56
 donor=P/f'P2OriginalSaving19Geometry00DecodedRow{r:03d}.lean'
 text=donor.read_text()
 match=re.search(r'noncomputable def geometryRowsTyped'+f'{r:03d}'+r' : GeometryRow :=\s*\{ simplexId := (\d+),\s*vertexIds := #\[([^]]*)\]',text)
 assert match and int(match[1])==r
 ids=[int(s.strip()) for s in match[2].split(',')]
 assert len(ids)==9
 dest=P/f'P2OriginalSaving19Cell00Row{r:03d}Arithmetic.lean'
 assert not dest.exists(),dest
 s='''import ImbalancedChen.P2OriginalSaving19Geometry00BoundedAccess
import ImbalancedChen.P2OriginalSaving19Moment00Shape
import ImbalancedChen.P2OriginalSaving19RowNumericsPure
import ImbalancedChen.P2Winner9FastDetPure
import Mathlib.Tactic.FinCases

/-! Actual cell00 row arithmetic using the unchanged ten-clause pure
representation. The original decoded row and vertex IDs are bound by closed
equalities to their bounded accesses. No Q80/new Q96 or integral conclusion. -/
'''
 s+=f'namespace ImbalancedChen.P2OriginalSaving19Cell00Row{r:03d}\n'
 s+='''set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false
open scoped BigOperators
open P2OriginalSaving19Archive
open P2OriginalSaving19Geometry00Decoding
open P2OriginalSaving19Geometry00BoundedAccess
open P2OriginalSaving19Moment00Decoding
open P2OriginalSaving19RowNumericsPure
open P2OriginalLogMomentQ96ArithmeticPure

'''
 s+=f'noncomputable def row : GeometryRow := geometryRowsTyped{r:03d}\n\n'
 s+='noncomputable def vertices : Fin 9 → QPoint :=\n  !['
 s+=',\n    '.join(f'(fun j => geometryVerticesTyped{v:03d}[j.val]!)' for v in ids)+']\n\n'
 s+=f'''noncomputable def momentRow : MomentRecord :=
  momentConcrete00.rows[({r} : Fin 56).val]'(P2OriginalSaving19Moment00Shape.row_bound {r})

'''
 proofs=[
 ('boundedRow_eq',f'boundedRow ({r} : Fin 56) = row','by rfl'),
 ('boundedRowVertex_eq',f'boundedRowVertex ({r} : Fin 56) = vertices',
  'by\n  funext i j\n  fin_cases i <;> fin_cases j <;> rfl'),
 ('raw_row_eq',f'concreteGeometry00.rows[{r}]! = row',
  f'(row_lookup_no_fallback ({r} : Fin 56)).trans boundedRow_eq'),
 ('raw_moment_row_eq',f'momentConcrete00.rows[{r}]! = momentRow',
  f'P2OriginalSaving19Moment00Shape.row_lookup_no_fallback ({r} : Fin 56)'),
 ('moment_row_eq',f'momentRow = momentTypedRecord{r:03d}','by rfl'),
 ('physical_volume_positive','0 < row.physicalVolume','by decide +kernel'),
 ('volume_eq','row.physicalVolume = |(edgeOf vertices).det| / (Nat.factorial 8 : ℚ)',
  'by\n  rw [← P2Winner9FastDetPure.fastDet_eq (edgeOf vertices)]\n  decide +kernel'),
 ('det_ne','(edgeOf vertices).det ≠ 0',
  'by\n  intro hzero\n  have h := volume_eq\n  rw [hzero, abs_zero, zero_div] at h\n  exact (ne_of_gt physical_volume_positive) h'),
 ('all_physical','∀ i : Fin 9, PhysicalQ (vertices i)','by decide +kernel'),
 ('gap_sum_positive','0 < gapSumOf vertices','by decide +kernel'),
 ('mean_gap_eq','row.meanGap = gapSumOf vertices / 9','by decide +kernel'),
 ('weighted_means_eq','∀ j : Fin 10, meansOf row j = computedMeanOf vertices j','by decide +kernel'),
 ('factor_le_maxima','∀ i : Fin 9, ∀ j : Fin 10, factorsQ (vertices i) j ≤ topsOf row j','by decide +kernel'),
 ('factor_maxima_attained','∀ j : Fin 10, ∃ i : Fin 9, factorsQ (vertices i) j = topsOf row j','by decide +kernel'),
 ('jensen_eq','row.jensenBound = oldEvaluator (massOf row) (meansOf row)','by decide +kernel'),
 ('old_floor_eq','row.jensenFloorQ96 = oldFloorQ96 (massOf row) (meansOf row)',
  'by\n  unfold oldFloorQ96\n  rw [← jensen_eq]\n  decide +kernel'),
 ('row_data_checks','RowDataChecksFor vertices row',
  'by\n  exact ⟨det_ne, all_physical, gap_sum_positive, volume_eq, mean_gap_eq,\n    weighted_means_eq, factor_le_maxima, factor_maxima_attained, jensen_eq, old_floor_eq⟩'),
 ('bounded_row_data_checks',f'RowDataChecksFor (boundedRowVertex ({r} : Fin 56)) (boundedRow ({r} : Fin 56))',
  'by\n  rw [boundedRowVertex_eq, boundedRow_eq]\n  exact row_data_checks'),
 ('moment_old_matches_geometry','momentRow.oldFloorQ96 = row.jensenFloorQ96','by decide +kernel'),
 ('moment_old_eq_evaluator','momentRow.oldFloorQ96 = oldFloorQ96 (massOf row) (meansOf row)',
  'moment_old_matches_geometry.trans old_floor_eq'),
 ('actual_moment_old_eq_bounded_evaluator',
  f'''(momentConcrete00.rows[{r}]!).oldFloorQ96 =
      oldFloorQ96 (massOf (boundedRow ({r} : Fin 56))) (meansOf (boundedRow ({r} : Fin 56)))''',
  'by\n  rw [raw_moment_row_eq, boundedRow_eq]\n  exact moment_old_eq_evaluator')]
 for name,statement,proof in proofs:
  s+=marker(r,name+'_before')
  s+=f'theorem {name} :\n    {statement} := {proof}\n\n'
 s+=marker(r,'complete')
 s+='\n'.join('#print axioms '+name for name,_,_ in proofs)+'\n\n'
 s+=f'end ImbalancedChen.P2OriginalSaving19Cell00Row{r:03d}\n'
 dest.write_text(s)
 record={'row':r,'module':'ImbalancedChen.'+dest.stem,'source':fp(dest),
   'original_typed_row_source':fp(donor),'original_ordered_vertex_ids':ids,
   'original_shape_and_bounded_access_reused':True,'new_Q80_or_new_Q96_claimed':False,
   'host_mathematical_precheck_performed':False,'normal_kernel_status_at_generation':'pending'}
 p=R/'plans'/f'row{r:03d}.json';p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_text(json.dumps(record,indent=2)+'\n')
 print(json.dumps(record),flush=True)

start=int(sys.argv[1]);end=int(sys.argv[2]) if len(sys.argv)>2 else start
for r in range(start,end+1):generate(r)
