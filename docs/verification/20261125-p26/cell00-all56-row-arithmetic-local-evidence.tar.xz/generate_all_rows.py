from pathlib import Path

R=Path(__file__).resolve().parent
P=R/'project/ImbalancedChen/P2OriginalSaving19Cell00AllRowArithmetic.lean'
assert not P.exists(),P
s='import ImbalancedChen.P2OriginalSaving19Cell00Row000OldFloor\n'
s+='\n'.join(f'import ImbalancedChen.P2OriginalSaving19Cell00Row{i:03d}Arithmetic' for i in range(1,56))
s+='''

/-! Finite assembly of the unchanged ten row-arithmetic clauses for all 56
actual cell00 rows. Each child certificate is reused opaquely. Only the old
moment Q96 floor is included; degree-six/Q80/new Q96 and integral soundness
are distinct remaining obligations. -/
namespace ImbalancedChen.P2OriginalSaving19Cell00AllRowArithmetic
set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false
open P2OriginalSaving19Geometry00Decoding
open P2OriginalSaving19Geometry00BoundedAccess
open P2OriginalSaving19Moment00Decoding
open P2OriginalSaving19RowNumericsPure
open P2OriginalLogMomentQ96ArithmeticPure

theorem all_bounded_row_data_checks : ∀ r : Fin 56,
    RowDataChecksFor (boundedRowVertex r) (boundedRow r) := by
  intro r
  fin_cases r
'''
for i in range(56):s+=f'  · exact P2OriginalSaving19Cell00Row{i:03d}.bounded_row_data_checks\n'
s+='''
theorem all_raw_row_data_checks (r : Fin 56) :
    RowDataChecksFor
      (fun i j => (concreteGeometry00.vertices[
        (concreteGeometry00.rows[r.val]!).vertexIds[i.val]!]!)[j.val]!)
      (concreteGeometry00.rows[r.val]!) := by
  have hv : (fun i : Fin 9 => fun j : Fin 8 =>
      (concreteGeometry00.vertices[
        (concreteGeometry00.rows[r.val]!).vertexIds[i.val]!]!)[j.val]!) =
      boundedRowVertex r := by
    funext i j
    exact raw_vertex_no_fallback r i j
  exact Eq.mpr (congrArg₂ RowDataChecksFor hv (row_lookup_no_fallback r))
    (all_bounded_row_data_checks r)

theorem all_moment_old_matches_geometry : ∀ r : Fin 56,
    (momentConcrete00.rows[r.val]!).oldFloorQ96 = (boundedRow r).jensenFloorQ96 := by
  intro r
  fin_cases r
'''
for i in range(56):
 ns=f'P2OriginalSaving19Cell00Row{i:03d}'
 s+=f'''  · exact (congrArg (fun g => g.oldFloorQ96) {ns}.raw_moment_row_eq).trans
      ({ns}.moment_old_matches_geometry.trans
        (congrArg (fun g => g.jensenFloorQ96) {ns}.boundedRow_eq.symm))
'''
s+='''
theorem all_moment_old_eq_evaluator : ∀ r : Fin 56,
    (momentConcrete00.rows[r.val]!).oldFloorQ96 =
      oldFloorQ96 (massOf (boundedRow r)) (meansOf (boundedRow r)) := by
  intro r
  fin_cases r
'''
for i in range(56):s+=f'  · exact P2OriginalSaving19Cell00Row{i:03d}.actual_moment_old_eq_bounded_evaluator\n'
s+='''
#print axioms all_bounded_row_data_checks
#print axioms all_raw_row_data_checks
#print axioms all_moment_old_matches_geometry
#print axioms all_moment_old_eq_evaluator

end ImbalancedChen.P2OriginalSaving19Cell00AllRowArithmetic
'''
P.write_text(s)
print(str(P))
