from pathlib import Path
import hashlib,json,os

R=Path(__file__).resolve().parent
B=Path('/workspace/p26-recovery-candidates/archive-row00-arithmetic/representation-v2')
P=R/'project';O=R/'objects'

def fp(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def put(p,b):
 assert not p.exists(),p
 p.parent.mkdir(parents=True,exist_ok=True)
 p.write_bytes(b if isinstance(b,bytes) else b.encode())
manifest=json.loads((B/'FULL_SOURCE_CLOSURE.json').read_text())
boot=json.loads((B/'BOOTSTRAP.json').read_text())
reused=[]
for row in manifest['sources_objects_and_receipts']:
 mod=row['module'];s=Path(row['source']['path']);o=Path(row['object']['path'])
 assert fp(s)==row['source'] and fp(o)==row['object']
 sc=P/(mod.replace('.','/')+'.lean');oc=O/(mod.replace('.','/')+'.olean')
 put(sc,s.read_bytes());oc.parent.mkdir(parents=True,exist_ok=True);assert not oc.exists();os.link(o,oc)
 extras=[]
 for x in o.parent.glob(o.name+'.*'):
  target=oc.parent/x.name;assert not target.exists();os.link(x,target)
  extras.append({'original':fp(x),'copy':fp(target)})
 reused.append({'module':mod,'source':{'original':fp(s),'copy':fp(sc)},
   'object':{'original':fp(o),'copy':fp(oc)},'extra_object_siblings':extras,
   'object_reuse':'immutable hardlink','recompiled':False})
boot['reused_helpers']=reused;boot['reused_count']=len(reused)
boot['schema']='saving19_cell00_rows1to55_bootstrap_v1'
boot['row000_base_manifest']=fp(B/'FULL_SOURCE_CLOSURE.json')
boot['row000_base_package']=fp(B/'PACKAGE_MANIFEST.json')
boot['row000_source_closure_canonical_sha256']=manifest['source_closure_canonical_sha256']
put(R/'BOOTSTRAP.json',json.dumps(boot,indent=2)+'\n')
put(R/'run_local.py',(B/'run_local.py').read_bytes())
print(json.dumps({'reused':len(reused),'root':str(R)}))
