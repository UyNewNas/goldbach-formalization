# Cell00 row0: exact arithmetic without the analytic import closure

This is an isolated candidate. Production, the submitted RowNumerics v1,
all accepted typed/shape packages, and the raw JSON files remain unchanged.

## Original mathematical obligations

The manuscript is `UyNewNas/chen-imbalanced-semiprimes` at
`a988cba584d803ae2856a0de50efb582f4f3dd6a`, release-20261106.
`paper/release-20261106/en/numerical-appendix.tex`,
`num:simplex-moment` (lines 177–196), gives the exact barycentric simplex
moment formula and requires original inequalities and face incidences.
`paper/release-20261106/en/argument.tex`, `eq:current-eighth-saving`
(lines 278–291), gives the saving density with its factor 4 and without
a Chen quarter or ordering factorial. The existing prefix recurrence and
Gaussian determinant are finite algebraic implementations, not extra
analytic estimates or manuscript statements newly assumed here.

The actual row arithmetic is the ten-clause
`P2OriginalSaving19RowNumerics.RowDataChecksFor`: nonzero Matrix.det,
all nine physical points, positive gap sum, determinant/volume identity,
mean-gap identity, all ten weighted means, all 90 maxima inequalities,
all ten maxima attainments, exact Jensen rational, and exact old Q96 floor.
The matrix determinant remains the specification. `fastDet_eq` may rewrite
its proof obligation but cannot replace its meaning.

The separate FloorBinding has five exact clauses. In particular its ten
Q80 floors and `max oldFloorQ96 newFloorQ96` equality are not consequences
of the ten geometry-row checks alone. A finite prefix table supplies actual
moments only after the existing Saving19 specialization and exact positive
integer encodings have been applied. No such connection is assumed.

## Source-level dependency reduction

1. `P2OriginalLogMomentQ96Arithmetic` moves the thirteen original rational
   and integer evaluator definitions, retaining their FQNs, types, implicit
   `{ι : Type*} [Fintype ι]`, and definition bodies. The original analytic
   checker receives only an import and removal of these definitions in an
   unapplied overlay. Its soundness proofs remain in the original module.
2. `P2Winner9FastDet` moves the original force helpers and the complete
   Gaussian determinant implementation/proof from
   `P2Winner9RowArithmeticChecker`. All algorithm and proof bodies remain
   unchanged. Eight `forceNat/Int/Fn/Rat` def/theorem declarations become
   public so the heavy owner's remaining original bodies can use them.
   Its other private declarations necessarily get new module-mangled names.
   This is new source requiring new normal/kernel verification, never reused
   acceptance of the old object.
3. RowNumerics v2 changes exactly its Q96 import. Its coordinate predicates,
   all ten checks, and original-form equivalence remain byte-for-byte.

Mathlib's existing Matrix.Determinant.Basic, Rat and relevant tactic objects
are available. The full Q96 analytic chain currently lacks objects downstream
of Convex.Integral. This candidate does not rebuild or download them.

## Concrete row0 certificates

Use the frozen `concreteGeometry00`, `boundedRow 0`, and
`boundedRowVertex 0`, preserving the original ordered IDs
`[27, 25, 11, 9, 7, 5, 3, 1, 0]`. Existing bounded-access theorems remove
all array fallbacks. Prove each finite component independently; combine
opaque theorems to obtain the unchanged ten-clause predicate if all pass.
Use the existing fastDet equality for determinant obligations, and the exact
original evaluator for Jensen/old Q96. Any further full FloorBinding work
must explicitly discharge the original moment representations and ten Q80
equalities; it cannot silently replace them by an encoded table result.

## Verification boundary

Each new necessary owner is normal-compiled and then independently replayed
by leanchecker, at 4 GiB RSS, 180 seconds, and one thread. Accepted suppliers
are copied with hashes and never rebuilt. Failed attempts retain exact
sources and logs. No increase in limits and no blind whole-check retries.
No original Archive aliases, full 56-row checks, all-cell results, analytic
integral conclusions, or P1 acceptance are claimed by this local work.
