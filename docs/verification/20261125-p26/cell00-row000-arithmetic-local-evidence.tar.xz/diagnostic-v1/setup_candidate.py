from pathlib import Path
import difflib, hashlib, json, re, shutil

ROOT = Path(__file__).resolve().parent
MAIN = Path('/workspace/p26-source-closure')
SHAPES = Path('/workspace/p26-recovery-candidates/archive-geometry00-shapes')
PREFIX = Path('/workspace/p26-recovery-candidates/moment-prefix-reuse')
PROJECT = ROOT / 'project'
OBJECTS = ROOT / 'objects'

def fp(path):
    b = path.read_bytes()
    return {'path': str(path), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}

def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    assert not path.exists(), path
    path.write_bytes(data if isinstance(data, bytes) else data.encode())

def copy(source, target):
    write(target, source.read_bytes())
    assert fp(source)['sha256'] == fp(target)['sha256']

def save_json(path, value):
    write(path, json.dumps(value, indent=2, ensure_ascii=False) + '\n')

shape_manifest = json.loads((SHAPES / 'FULL_SOURCE_CLOSURE.json').read_text())
shape_bootstrap = json.loads((SHAPES / 'BOOTSTRAP.json').read_text())
reused = []
for row in shape_manifest['sources_objects_and_receipts']:
    mod = row['module']
    s = Path(row['source']['path'])
    o = Path(row['object']['path'])
    assert fp(s) == row['source'] and fp(o) == row['object']
    sc = PROJECT / (mod.replace('.', '/') + '.lean')
    oc = OBJECTS / (mod.replace('.', '/') + '.olean')
    copy(s, sc)
    copy(o, oc)
    siblings = []
    for extra in o.parent.glob(o.name + '.*'):
        dest = oc.parent / extra.name
        copy(extra, dest)
        siblings.append({'original': fp(extra), 'copy': fp(dest)})
    reused.append({'module': mod, 'source': {'original': fp(s), 'copy': fp(sc)},
                   'object': {'original': fp(o), 'copy': fp(oc)},
                   'extra_object_siblings': siblings, 'recompiled': False})

for stem in ['P2Winner9HomogeneousRecurrence', 'P2OriginalSaving19PrefixInterface',
             'P2OriginalSaving19PrefixMoments']:
    s = PREFIX / 'ImbalancedChen' / (stem + '.lean')
    o = PREFIX / 'objects/ImbalancedChen' / (stem + '.olean')
    sc = PROJECT / 'ImbalancedChen' / s.name
    oc = OBJECTS / 'ImbalancedChen' / o.name
    copy(s, sc)
    copy(o, oc)
    siblings = []
    for extra in o.parent.glob(o.name + '.*'):
        dest = oc.parent / extra.name
        copy(extra, dest)
        siblings.append({'original': fp(extra), 'copy': fp(dest)})
    reused.append({'module': 'ImbalancedChen.' + stem,
                   'source': {'original': fp(s), 'copy': fp(sc)},
                   'object': {'original': fp(o), 'copy': fp(oc)},
                   'extra_object_siblings': siblings, 'recompiled': False})

save_json(ROOT / 'BOOTSTRAP.json', {
    'schema': 'saving19_row00_arithmetic_bootstrap_v1',
    'reused_helpers': reused, 'reused_count': len(reused),
    'shape_full_closure_manifest': fp(SHAPES / 'FULL_SOURCE_CLOSURE.json'),
    'shape_canonical_source_closure': shape_manifest['source_closure_canonical_sha256'],
    'prefix_manifest': fp(PREFIX / 'SOURCE_MANIFEST.json'),
    'external_LEAN_PATH_roots': shape_bootstrap['external_LEAN_PATH_roots'],
    'original_fixtures': shape_bootstrap['original_fixtures'],
    'runtime': str(Path('/workspace/library-files/p34-runtime/lean-4.33.0-rc1-linux')),
    'production_modified': False, 'remote_jobs_submitted': False,
    'accepted_suppliers_recompiled': False})

qpath = MAIN / 'ImbalancedChen/P2OriginalLogMomentQ96Checker.lean'
qtext = qpath.read_text()
qnames = ['fixedNumerator', 'roundDownQ', 'gapEvaluator', 'factorFloorQ80',
          'factorLowerQ80', 'totalLowerQ80', 'cubicQ', 'oldEvaluator',
          'newEvaluator', 'oldFloorQ96', 'newFloorQ96', 'simplexLowerQ96',
          'checkStoredQ96']
qblocks = []
for name in qnames:
    match = re.search(r'^def ' + name + r'\b[\s\S]*?(?=\n\n)', qtext, re.M)
    assert match, name
    start, end = match.span()
    # Two original documentation comments move with their definitions.
    if name in {'fixedNumerator', 'gapEvaluator'}:
        start = qtext.rfind('/--', 0, start)
        assert start >= 0 and qtext[start:match.start()].rstrip().endswith('-/')
    qblocks.append((name, start, end, qtext[start:end]))
qheader = '''import Mathlib.Data.Rat.Floor
import Mathlib.Algebra.BigOperators.Ring.Finset

/-! Pure exact evaluator declarations mechanically extracted from the original
Q96 checker. Their original namespace, types, bodies and rounding direction
are retained. Analytic soundness remains in the original checker. -/
namespace ImbalancedChen.P2OriginalLogMomentQ96CheckerSourceOnly

noncomputable section
open scoped BigOperators

'''
qbody = ''
for name, start, end, body in qblocks:
    if name == 'totalLowerQ80':
        qbody += 'variable {ι : Type*} [Fintype ι]\n\n'
    qbody += body + '\n\n'
qp = PROJECT / 'ImbalancedChen/P2OriginalLogMomentQ96Arithmetic.lean'
write(qp, qheader + qbody + 'end\n\nend ImbalancedChen.P2OriginalLogMomentQ96CheckerSourceOnly\n')
qoverlay = qtext
for name, start, end, body in reversed(qblocks):
    qoverlay = qoverlay[:start] + qoverlay[end:]
qoverlay = 'import ImbalancedChen.P2OriginalLogMomentQ96Arithmetic\n' + qoverlay

fpath = MAIN / 'ImbalancedChen/P2Winner9RowArithmeticChecker.lean'
ftext = fpath.read_text()
force_start = ftext.index('private def forceNat ')
force_end = ftext.index('private def forceRaw ')
det_start = ftext.index('/-- The complement remaining after eliminating the first column. -/')
det_end = ftext.index('/-- Ordered vertices selected by the row\'s original vertex IDs. -/')
force = ftext[force_start:force_end]
det = ftext[det_start:det_end]
public_helpers = ['forceNat', 'forceNat_eq', 'forceInt', 'forceInt_eq',
                  'forceFn', 'forceFn_eq', 'forceRat', 'forceRat_eq']
for name in public_helpers:
    force, n = re.subn(r'^private (def|theorem) ' + name + r'\b', r'\1 ' + name,
                      force, count=1, flags=re.M)
    assert n == 1, name
fheader = '''import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.Data.Rat.Defs
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring

/-! Existing Winner9 Gaussian determinant implementation and proof, moved
without algorithm or proof-body changes. The eight force helper declarations
are public so the original heavy checker's remaining bodies can reuse them.
This new owner requires its own normal and kernel acceptance. -/
namespace ImbalancedChen.P2Winner9RowArithmeticChecker

'''
fnew = fheader + force + det + '\n'.join('#print axioms ' + n for n in public_helpers + ['fastDet_eq']) + '\n\nend ImbalancedChen.P2Winner9RowArithmeticChecker\n'
fnewpath = PROJECT / 'ImbalancedChen/P2Winner9FastDet.lean'
write(fnewpath, fnew)
foverlay = ftext[:det_start] + ftext[det_end:]
foverlay = foverlay[:force_start] + foverlay[force_end:]
foverlay = 'import ImbalancedChen.P2Winner9FastDet\n' + foverlay

rpath = MAIN / 'ImbalancedChen/P2OriginalSaving19RowNumerics.lean'
rtext = rpath.read_text()
rnew = rtext.replace('import ImbalancedChen.P2OriginalLogMomentQ96Checker\n',
                     'import ImbalancedChen.P2OriginalLogMomentQ96Arithmetic\n')
assert rtext != rnew
rnewpath = PROJECT / 'ImbalancedChen/P2OriginalSaving19RowNumerics.lean'
write(rnewpath, rnew)

for p, before, after in [(qpath, qtext, qoverlay), (fpath, ftext, foverlay), (rpath, rtext, rnew)]:
    copy(p, ROOT / 'provenance' / p.name)
    write(ROOT / 'overlay/ImbalancedChen' / p.name, after)
    write(ROOT / 'patches' / (p.stem + '.patch'),
          ''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True),
                                      fromfile='a/ImbalancedChen/' + p.name,
                                      tofile='b/ImbalancedChen/' + p.name)))

save_json(ROOT / 'EXTRACTION_MANIFEST.json', {
    'schema': 'saving19_row00_light_arithmetic_extraction_v1',
    'Q96_donor': fp(qpath), 'Q96_new_owner': fp(qp),
    'Q96_declarations': [
        {'name': name, 'original_start_byte': len(qtext[:start].encode()), 'original_end_byte': len(qtext[:end].encode()),
         'bytes': len(body.encode()), 'sha256': hashlib.sha256(body.encode()).hexdigest(),
         'same_FQN_type_body': True, 'substring_in_new_owner': body in qp.read_text()}
        for name, start, end, body in qblocks],
    'fastDet_donor': fp(fpath), 'fastDet_new_owner': fp(fnewpath),
    'force_helper_visibility_changes': public_helpers,
    'force_block_identical_after_removing_private_prefixes':
        force == re.sub(r'^private ', '', ftext[force_start:force_end], flags=re.M),
    'det_block_byte_identical': det in fnew,
    'det_block_sha256': hashlib.sha256(det.encode()).hexdigest(),
    'det_original_start_byte': len(ftext[:det_start].encode()), 'det_original_end_byte': len(ftext[:det_end].encode()),
    'all_existing_public_statements_preserved': True,
    'generated_private_helper_FQNs_change': True,
    'original_heavy_remainders_only_import_plus_removed_blocks': True,
    'RowNumerics_v1': fp(rpath), 'RowNumerics_v2': fp(rnewpath),
    'RowNumerics_only_import_changed':
        rnew.replace('import ImbalancedChen.P2OriginalLogMomentQ96Arithmetic\n',
                     'import ImbalancedChen.P2OriginalLogMomentQ96Checker\n') == rtext,
    'overlays_not_compiled_or_applied_to_main': True,
    'no_old_acceptance_transferred': True})

runner = (SHAPES / 'run_local.py').read_text()
runner = runner.replace("'shape_only':True", "'shape_only':False,'row_arithmetic_candidate':True")
write(ROOT / 'run_local.py', runner)
print(json.dumps({'root': str(ROOT), 'reused': len(reused), 'new': [fp(qp), fp(fnewpath), fp(rnewpath)]}, indent=2))
