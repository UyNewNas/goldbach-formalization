from pathlib import Path
import hashlib, json, os, re

BASE = Path(__file__).resolve().parent
ROOT = BASE / 'representation-v2'
PROJECT = ROOT / 'project'
OBJECTS = ROOT / 'objects'

def fp(path):
    b = path.read_bytes()
    return {'path': str(path), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}

def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    assert not path.exists(), path
    path.write_bytes(data if isinstance(data, bytes) else data.encode())

def jwrite(path, data):
    write(path, json.dumps(data, indent=2, ensure_ascii=False) + '\n')

boot = json.loads((BASE / 'BOOTSTRAP.json').read_text())
reused = []
for row in boot['reused_helpers']:
    mod = row['module']
    s = Path(row['source']['copy']['path'])
    o = Path(row['object']['copy']['path'])
    assert fp(s) == row['source']['copy'] and fp(o) == row['object']['copy']
    sc = PROJECT / (mod.replace('.', '/') + '.lean')
    oc = OBJECTS / (mod.replace('.', '/') + '.olean')
    write(sc, s.read_bytes())
    oc.parent.mkdir(parents=True, exist_ok=True)
    assert not oc.exists()
    os.link(o, oc)
    extras = []
    for e in row['extra_object_siblings']:
        p = Path(e['copy']['path']); target = oc.parent / p.name
        assert fp(p) == e['copy']
        os.link(p, target)
        extras.append({'original': fp(p), 'copy': fp(target)})
    reused.append({'module': mod, 'source': {'original': fp(s), 'copy': fp(sc)},
                   'object': {'original': fp(o), 'copy': fp(oc)},
                   'extra_object_siblings': extras, 'object_reuse': 'immutable hardlink',
                   'recompiled': False})
boot['reused_helpers'] = reused
boot['schema'] = 'saving19_row00_arithmetic_new_namespace_bootstrap_v2'
boot['reuses_v1_extracted_objects'] = False
jwrite(ROOT / 'BOOTSTRAP.json', boot)
write(ROOT / 'run_local.py', (BASE / 'run_local.py').read_bytes())

q0 = (BASE / 'project/ImbalancedChen/P2OriginalLogMomentQ96Arithmetic.lean').read_text()
q = q0.replace('P2OriginalLogMomentQ96CheckerSourceOnly',
               'P2OriginalLogMomentQ96ArithmeticPure')
q = q.replace('Pure exact evaluator declarations mechanically extracted from the original\nQ96 checker. Their original namespace, types, bodies and rounding direction\nare retained. Analytic soundness remains in the original checker.',
'''Exact evaluator representation mechanically copied from the original Q96
checker into an independent namespace. Types, bodies, generic index types,
and rounding direction are retained. A separate definitional bridge connects
the original namespace; existing analytic owners and objects are unchanged.''')
qp = PROJECT / 'ImbalancedChen/P2OriginalLogMomentQ96ArithmeticPure.lean'
write(qp, q)

oldfast = (BASE / 'provenance/P2Winner9RowArithmeticChecker.lean').read_text()
force_start = oldfast.index('private def forceNat ')
force_end = oldfast.index('private def forceRaw ')
det_start = oldfast.index('/-- The complement remaining after eliminating the first column. -/')
det_end = oldfast.index('/-- Ordered vertices selected by the row\'s original vertex IDs. -/')
force = oldfast[force_start:force_end]
det = oldfast[det_start:det_end]
f = '''import Mathlib.LinearAlgebra.Matrix.Determinant.Basic
import Mathlib.Data.Rat.Defs
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring

/-! Original Winner9 exact Gaussian algorithm and proof, copied mechanically
into a new representation namespace. Every original helper remains private.
The specification is the existing Matrix.det; no original heavy owner or
previously accepted dependency context is modified. -/
namespace ImbalancedChen.P2Winner9FastDetPure

''' + force + det + '''#print axioms fastDet_eq

end ImbalancedChen.P2Winner9FastDetPure
'''
fpure = PROJECT / 'ImbalancedChen/P2Winner9FastDetPure.lean'
write(fpure, f)

r0 = (BASE / 'provenance/P2OriginalSaving19RowNumerics.lean').read_text()
r = r0.replace('import ImbalancedChen.P2OriginalLogMomentQ96Checker\n',
                'import ImbalancedChen.P2OriginalLogMomentQ96ArithmeticPure\n')
r = r.replace('P2OriginalSaving19Original28918', 'P2OriginalSaving19RowNumericsPure')
r = r.replace('namespace ImbalancedChen.P2OriginalSaving19RowNumerics\n',
               'namespace ImbalancedChen.P2OriginalSaving19RowNumericsPure\n')
r = r.replace('end ImbalancedChen.P2OriginalSaving19RowNumerics\n',
               'end ImbalancedChen.P2OriginalSaving19RowNumericsPure\n')
r = r.replace('open P2OriginalLogMomentQ96CheckerSourceOnly',
               'open P2OriginalLogMomentQ96ArithmeticPure')
r = r.replace('The original rational coordinate declarations below retain their namespace,\ntypes and definition bytes.',
'''The rational coordinate declarations and guard are copied into a new pure
representation namespace; their types and bodies remain unchanged. A separate
definitional bridge is required to connect the existing original namespace.''')
rp = PROJECT / 'ImbalancedChen/P2OriginalSaving19RowNumericsPure.lean'
write(rp, r)

i0 = (BASE / 'project/ImbalancedChen/P2OriginalSaving19Cell00Row000Input.lean').read_text()
i = i0.replace('import ImbalancedChen.P2OriginalSaving19RowNumerics\n',
                'import ImbalancedChen.P2OriginalSaving19RowNumericsPure\n')
i = i.replace('open P2OriginalSaving19Original28918',
               'open P2OriginalSaving19RowNumericsPure')
ip = PROJECT / 'ImbalancedChen/P2OriginalSaving19Cell00Row000Input.lean'
write(ip, i)

jwrite(ROOT / 'REPRESENTATION_MANIFEST.json', {
    'schema': 'saving19_row00_arithmetic_namespace_representation_v2',
    'base_extraction_manifest': fp(BASE / 'EXTRACTION_MANIFEST.json'),
    'Q96_donor': fp(BASE / 'provenance/P2OriginalLogMomentQ96Checker.lean'),
    'Q96_pure': fp(qp),
    'Q96_namespace_map': {'ImbalancedChen.P2OriginalLogMomentQ96CheckerSourceOnly':
                          'ImbalancedChen.P2OriginalLogMomentQ96ArithmeticPure'},
    'Q96_all_13_original_definition_blocks_unchanged': all(
        (BASE / 'provenance/P2OriginalLogMomentQ96Checker.lean').read_bytes()[x['original_start_byte']:x['original_end_byte']]
        in qp.read_bytes()
        for x in json.loads((BASE / 'EXTRACTION_MANIFEST.json').read_text())['Q96_declarations']),
    'fastDet_donor': fp(BASE / 'provenance/P2Winner9RowArithmeticChecker.lean'),
    'fastDet_pure': fp(fpure),
    'fastDet_namespace_map': {'ImbalancedChen.P2Winner9RowArithmeticChecker':
                             'ImbalancedChen.P2Winner9FastDetPure'},
    'force_block_bytes_identical': force in f,
    'force_block_sha256': hashlib.sha256(force.encode()).hexdigest(),
    'det_block_bytes_identical': det in f,
    'det_block_sha256': hashlib.sha256(det.encode()).hexdigest(),
    'all_original_private_helper_visibility_retained': True,
    'new_private_mangled_names_require_new_acceptance': True,
    'RowNumerics_original': fp(BASE / 'provenance/P2OriginalSaving19RowNumerics.lean'),
    'RowNumerics_pure': fp(rp),
    'RowNumerics_namespace_maps': {
        'ImbalancedChen.P2OriginalSaving19Original28918': 'ImbalancedChen.P2OriginalSaving19RowNumericsPure',
        'ImbalancedChen.P2OriginalSaving19RowNumerics': 'ImbalancedChen.P2OriginalSaving19RowNumericsPure'},
    'old_analytic_or_Core_source_or_objects_modified': False,
    'old_heavy_overlays_required': False,
    'v1_extracted_objects_reused': False,
    'original_Q96_and_RowNumerics_definitional_bridges_required': True,
    'row_input_unverified_at_generation': fp(ip),
    'source_only_at_generation': True})
print(json.dumps({'root': str(ROOT), 'sources': [fp(qp), fp(fpure), fp(rp), fp(ip)]}, indent=2))
