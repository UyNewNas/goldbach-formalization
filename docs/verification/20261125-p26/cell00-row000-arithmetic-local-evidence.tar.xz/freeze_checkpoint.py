from pathlib import Path
import hashlib, json, re, shutil

R = Path(__file__).resolve().parent
B = R.parent
P = R / 'project'
O = R / 'objects'
REVIEW = Path('/workspace/p26-recovery-candidates/row-light-extraction-review')

def fp(p):
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}

def write(p, value):
    assert not p.exists(), p
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(value)

def jwrite(p, value):
    write(p, json.dumps(value, indent=2, ensure_ascii=False) + '\n')

def copy(p, q):
    assert not q.exists(), q
    q.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(p, q)

boot = json.loads((R / 'BOOTSTRAP.json').read_text())
borrowed = {x['module']: x for x in boot['reused_helpers']}
new = {}
failures = []
for p in sorted((R / 'logs').glob('*/normal-*-result.json')):
    result = json.loads(p.read_text())
    if result['status'] != 'succeeded':
        failures.append({'receipt': fp(p), 'record': result})
        continue
    stem = result['module'].split('.')[-1]
    tag = result['attempt']
    kernel_path = p.with_name('kernel-' + tag + '-result.json')
    kernel = json.loads(kernel_path.read_text())
    assert kernel['status'] == 'succeeded' and kernel['exit_code'] == 0
    source = P / 'ImbalancedChen' / (stem + '.lean')
    obj = O / 'ImbalancedChen' / (stem + '.olean')
    assert result['source'] == kernel['source'] == fp(source)
    assert result['object'] == kernel['object'] == fp(obj)
    assert result['dependencies'] == kernel['dependencies']
    assert result['input_before'] == result['input_after'] == kernel['input_before'] == kernel['input_after']
    log = Path(result['log']['path']).read_text()
    assert not re.search(r'\bwarning:|\berror:|sorryAx|native_decide|Lean\.ofReduceBool', log)
    axioms = []
    for name, names in re.findall(r"'([^']+)' depends on axioms:\s*\[([^]]*)\]", log, re.S):
        names = [a.strip() for a in names.split(',') if a.strip()]
        assert set(names) <= {'propext', 'Classical.choice', 'Quot.sound'}
        axioms.append({'declaration': name, 'axioms': names})
    for name in re.findall(r"'([^']+)' does not depend on any axioms", log):
        axioms.append({'declaration': name, 'axioms': []})
    new[result['module']] = {'source': fp(source), 'object': fp(obj),
        'normal_receipt': fp(p), 'kernel_receipt': fp(kernel_path),
        'normal_seconds': result['elapsed_seconds'], 'kernel_seconds': kernel['elapsed_seconds'],
        'normal_peak_rss_bytes': result['peak_rss_bytes'],
        'kernel_peak_rss_bytes': kernel['peak_rss_bytes'], 'printed_axioms': axioms}
assert len(new) == 12
assert len(failures) == 1 and failures[0]['record']['status'] == 'failed'

visited = set()
rows = []
def visit(mod):
    if mod in visited:
        return
    visited.add(mod)
    p = P / (mod.replace('.', '/') + '.lean')
    imports = re.findall(r'^import\s+([^\s]+)', p.read_text(), re.M)
    for dep in imports:
        if dep.startswith('ImbalancedChen.'):
            visit(dep)
    obj = O / (mod.replace('.', '/') + '.olean')
    assert obj.is_file()
    row = {'module': mod, 'source': fp(p), 'object': fp(obj), 'imports': imports}
    if mod in new:
        row['new_verified_owner'] = True
        row['normal_receipt'] = new[mod]['normal_receipt']
        row['kernel_receipt'] = new[mod]['kernel_receipt']
    else:
        b = borrowed[mod]
        assert row['source'] == b['source']['copy'] and row['object'] == b['object']['copy']
        row['reused_accepted_owner'] = True
        row['original_source'] = b['source']['original']
        row['original_object'] = b['object']['original']
        row['recompiled'] = False
    rows.append(row)

visit('ImbalancedChen.P2OriginalSaving19Cell00Row000OldFloor')
assert set(new) <= visited
rows.sort(key=lambda x: x['module'])
canonical = [{'module': x['module'], 'source_sha256': x['source']['sha256'],
              'source_bytes': x['source']['bytes'], 'imports': x['imports']} for x in rows]
closure_hash = hashlib.sha256(json.dumps(canonical, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
jwrite(R / 'FULL_SOURCE_CLOSURE.json', {'schema': 'saving19_row000_pure_arithmetic_closure_v2',
    'project_modules': len(rows), 'new_verified_owners': len(new),
    'reused_accepted_owners': len(rows)-len(new),
    'source_closure_canonical_sha256': closure_hash,
    'canonical_source_rows': canonical, 'sources_objects_and_receipts': rows,
    'no_old_Q96_or_Winner9_heavy_object_in_this_closure': True,
    'old_context_objects_modified': False, 'P1_strict_claimed': False})

for name in ['REPORT_V2.md', 'SOURCE_V2_REVIEW.json', 'SOURCE_REVIEW.json']:
    copy(REVIEW / name, R / 'review' / name)
for p in [B/'EXTRACTION_MANIFEST.json', B/'setup_candidate.py', B/'setup_representation_v2.py', B/'PLAN.md']:
    copy(p, R / 'diagnostic-v1' / p.name)
for p in (B/'provenance').glob('*.lean'):
    copy(p, R / 'provenance' / p.name)
for stem in ['P2OriginalLogMomentQ96Arithmetic', 'P2Winner9FastDet', 'P2OriginalSaving19RowNumerics']:
    copy(B/'project/ImbalancedChen'/(stem+'.lean'), R/'diagnostic-v1/ImbalancedChen'/(stem+'.lean'))
    for p in (B/'logs'/stem).iterdir():
        copy(p, R/'diagnostic-v1/logs'/stem/p.name)

bridge_sources = [fp(p) for p in sorted((R/'bridge-candidate/ImbalancedChen').glob('*.lean'))]
jwrite(R/'SOURCE_MANIFEST.json', {'schema': 'saving19_row000_new_verified_sources_v2',
    'new_sources': [{'module': k, **v} for k,v in sorted(new.items())],
    'source_only_original_namespace_bridges': bridge_sources,
    'source_only_bridge_not_verified': True,
    'representation_manifest': fp(R/'REPRESENTATION_MANIFEST.json'),
    'review': [fp(R/'review'/name) for name in ['REPORT_V2.md','SOURCE_V2_REVIEW.json']],
    'full_source_closure': fp(R/'FULL_SOURCE_CLOSURE.json')})

normal_sum = sum(x['normal_seconds'] for x in new.values())
kernel_sum = sum(x['kernel_seconds'] for x in new.values())
max_normal = max(x['normal_peak_rss_bytes'] for x in new.values())
max_kernel = max(x['kernel_peak_rss_bytes'] for x in new.values())
result = {'schema': 'saving19_row000_pure_arithmetic_local_result_v2',
    'status': '12_new_owners_normal_and_independent_kernel_passed',
    'new_owners': 12, 'successful_invocations': 24,
    'failed_invocations': 1, 'failure_type': 'rewrite_matching_expression_only',
    'failure_resources_exceeded': False, 'failure_preserved': failures,
    'axiom_sets': sum(len(x['printed_axioms']) for x in new.values()),
    'allowed_axioms_only': ['propext','Classical.choice','Quot.sound'],
    'normal_seconds': normal_sum, 'kernel_seconds': kernel_sum,
    'max_normal_rss_bytes': max_normal, 'max_kernel_rss_bytes': max_kernel,
    'budget': {'rss_bytes': 4*1024**3, 'seconds': 180, 'threads': 1},
    'source_closure_canonical_sha256': closure_hash,
    'final_closed_guard': 'ImbalancedChen.P2OriginalSaving19Cell00Row000.bounded_row_data_checks',
    'old_floor_correspondence': 'ImbalancedChen.P2OriginalSaving19Cell00Row000.actual_moment_old_eq_bounded_evaluator',
    'matrix_det_specification_unchanged': True,
    'all_ten_row_clauses_proved_for_actual_row0': True,
    'all_90_dominations_and_10_attainments': True,
    'actual_original_nine_vertex_order': [27,25,11,9,7,5,3,1,0],
    'old_Q96_floor': 6708449485921,
    'full_FloorChecks_proved': False, 'ten_Q80_floors_proved': False,
    'new_Q96_floor_proved': False, 'actual_integral_bound_proved': False,
    'all_56_rows_proved': False, 'Archive_aliases_connected': False,
    'source_only_bridges_compiled': False, 'P1_strict_claimed': False,
    'old_heavy_Core_or_analytic_context_modified': False,
    'Mathlib_or_existing_supplier_rebuilt': False, 'remote_jobs_submitted': False}
jwrite(R/'RESULT.json',result)

table='\n'.join('| '+k.removeprefix('ImbalancedChen.')+' | '+f"{v['normal_seconds']:.3f}"+' | '+f"{v['kernel_seconds']:.3f}"+' | '+str(v['normal_peak_rss_bytes'])+' | '+str(v['kernel_peak_rss_bytes'])+' |' for k,v in sorted(new.items()))
report=f'''# Cell00 row0：原始十项算术条件与旧 Q96 floor

## 已闭合的实际结果

本包的 12 个新 owner 均通过本地 normal 编译和独立 leanchecker，共 24 次成功调用。
最终无假设定理是 `ImbalancedChen.P2OriginalSaving19Cell00Row000.bounded_row_data_checks`：

```lean
RowNumericsPure.RowDataChecksFor
  (Geometry00BoundedAccess.boundedRowVertex (0 : Fin 56))
  (Geometry00BoundedAccess.boundedRow (0 : Fin 56))
```

命名空间缩写仅用于此报告。源码中的陈述完整绑定已通过原 parser 与真实 typed decoder
的 `concreteGeometry00`。原九个 vertex IDs 顺序为 `[27,25,11,9,7,5,3,1,0]`。
`boundedRow_eq`、`boundedRowVertex_eq` 与原有无 fallback 定理接通真实 row/vertices，
没有用外部数值计算替代原数据等式。

完整十项是：Matrix.det 非零；全部 9 点的 PhysicalQ；正 gap 总和；原体积等于
绝对行列式除以 8!；原 meanGap；全部 10 个 weighted means；全部 90 个 maxima
domination；全部 10 个 maxima attainment；精确 Jensen 有理数；原旧 Q96 整数。
行列式规范始终为 Matrix.det，证明使用已存在 fastDet 的原算法与原正确性证明。

原 moment row0 的旧 Q96 字段也已证等于 geometry row0 的 Jensen floor，并等于
同一精确 `oldFloorQ96 (massOf row) (meansOf row)`。该整数为 6708449485921。
这提供原 FloorChecks 第 3、4 项的实际有限等式；不把它误称为完整 FloorChecks。

## 源码复用与集成选择

Pure Q96 的 13 个定义、fastDet 全部算法/证明块、RowNumerics 的坐标函数和完整十合取
均来自已有源码，只作显式命名空间迁移与必要轻 import。13 个定义的原文切片和
force/determinant 块逐字比较在 REPRESENTATION_MANIFEST 与独立 review 中固定。
索引仍保留泛型 `{{ι : Type*}} [Fintype ι]`，未强行限制成 Fin10；fastDet 的所有
原 private helpers 仍为 private。

首版同 FQN 提取本身通过了 3 owner normal/kernel，但会使已有 heavy/Core 对象发生
公共名称冲突。它只作为诊断证据放在 diagnostic-v1，不是本轮生产候选。当前 v2
使用新命名空间，原 Q96、Winner9 heavy、MomentFloorConsumer 和 Core 源/对象均未改。
`bridge-candidate` 的 13 个 rfl 与十合取 Iff.rfl 是待单独验收的原命名空间接头，
当前明确 SOURCE_ONLY；本包没有为了这些桥重建旧分析供应商。

原稿依据是 `a988cba584d803ae2856a0de50efb582f4f3dd6a` 的 2026-11-06 英文稿：
numerical-appendix `num:simplex-moment`（177–196 行）给出单纯形重心矩公式，
argument `eq:current-eighth-saving`（278–291 行）给出带因子 4、无 Chen quarter
或 ordering factorial 的 saving 密度。现有前缀递推和高斯消元是有限代数表示；
本包没有增加稿外分析估计。

## 复用与验证范围

最终闭包 {len(rows)} 个项目 owner，其中 {len(rows)-12} 个已接受 owner 原样复用、
12 个新 owner。仓内备用库存还包含既有 3 个 Prefix 对象供下一项工作，最终 row0
闭包不依赖它们。全源/对象/回执指纹在 FULL_SOURCE_CLOSURE.json，canonical 源闭包：
`{closure_hash}`。

运行时固定 Lean 4.33.0-rc1（62eed1db4d67327ec8120be05f1a1b0847d74561）与 Mathlib
e4c91783ca8e6a7c693ae624ade32fd22d4e43c1。每调用固定 4 GiB / 180 秒 / 1 线程，
原件、供应者 source/object、目标 source/object 在回执中逐字核对。
累计成功 normal {normal_sum:.3f}s，独立 kernel {kernel_sum:.3f}s；峰值 normal
{max_normal} B，kernel {max_kernel} B。所有已打印 {result['axiom_sets']} 项依赖集合
仅含 propext、Classical.choice、Quot.sound；成功回执无警告或占位。

| Owner | normal 秒 | kernel 秒 | normal 峰值 B | kernel 峰值 B |
|---|---:|---:|---:|---:|
{table}

唯一失败是 Input 第一版 `rw` 对 Fin0 coerced 索引表达式未匹配；它不是资源超限或
数学反例。失败 source/log 原样保留，改用已有等式的 trans/congrFun 后同预算通过。
其余所有新算术 owner 首遍 normal/kernel 通过，没有重复运行已通过的 owner。

## 尚未宣称的结论

本包没有证明其它 55 行、10 个 Q80 floor、新 Q96 的 `max old new`、完整 28918
行总和、原 Archive aliases、几何 pulling/ownership 或实际 reciprocal integral 下界。
原 FloorChecks 第 1、2、5 项仍须用真实 gap/deviation 与已有 Prefix/HigherMoments
桥接完成；不能把一个 Nat 编码表直接当作原 rationalMoment。当前没有发现本 row0
算术条件的实质数学缺口；先前阻塞是导入/归约表示与源码接口问题，未证义务仍明确保留。
本地 normal/kernel 结果也不冒称 P1 strict 接受。
'''
write(R/'REPORT.md', report)

publication = [{'module': k, 'relative_path': str(Path('project') / (k.replace('.','/')+'.lean')),
                'source': v['source'], 'normal_and_kernel': True} for k,v in sorted(new.items())]
jwrite(R/'PUBLICATION_SOURCES.json', {'schema':'saving19_row000_publication_sources_v2',
    'verified_Lean_sources':publication, 'source_only_bridges':bridge_sources,
    'do_not_install_diagnostic_v1':True, 'do_not_apply_v1_heavy_overlays':True})

paths=[]
for p in sorted(R.rglob('*')):
    if not p.is_file(): continue
    rel=p.relative_to(R)
    if rel.parts[0]=='objects':continue
    if rel.parts[0]=='project' and 'ImbalancedChen.'+p.stem not in new:continue
    if '__pycache__' in rel.parts:continue
    paths.append({'relative_path':str(rel), **fp(p)})
jwrite(R/'DELTA_WHITELIST.json', {'schema':'saving19_row000_delta_no_objects_v2',
    'relative_to':str(R),'files':paths,'full_source_closure':fp(R/'FULL_SOURCE_CLOSURE.json'),
    'source_closure_canonical_sha256':closure_hash,'contains_objects':False})
jwrite(R/'PACKAGE_MANIFEST.json', {'schema':'saving19_row000_local_checkpoint_package_v2',
    'whitelist':fp(R/'DELTA_WHITELIST.json'),'report':fp(R/'REPORT.md'),'result':fp(R/'RESULT.json'),
    'source_manifest':fp(R/'SOURCE_MANIFEST.json'),'full_closure':fp(R/'FULL_SOURCE_CLOSURE.json'),
    'publication_sources':fp(R/'PUBLICATION_SOURCES.json'),'files':paths})
print(json.dumps({'root':str(R),'new_owners':12,'closure':len(rows),'delta_files':len(paths),
    'closure_hash':closure_hash,'result':fp(R/'RESULT.json'),'package':fp(R/'PACKAGE_MANIFEST.json'),
    'whitelist':fp(R/'DELTA_WHITELIST.json'),'report':fp(R/'REPORT.md')},indent=2))
