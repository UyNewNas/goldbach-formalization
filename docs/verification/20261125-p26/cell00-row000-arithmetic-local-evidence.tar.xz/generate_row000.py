from pathlib import Path
import json

ROOT = Path(__file__).resolve().parent
DEST = ROOT / 'project/ImbalancedChen'
PREFIX = 'P2OriginalSaving19Cell00Row000'

def marker(label):
    return f'''run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_ROW000 {label}"
  err.flush

'''

def emit(suffix, imports, proofs):
    p = DEST / (PREFIX + suffix + '.lean')
    assert not p.exists(), p
    s = '\n'.join('import ImbalancedChen.' + x for x in imports) + '''

/-! Exact closed arithmetic for the actual decoded cell00 row0.
Original nine-vertex order, original field values, and the finite arithmetic
specifications are retained. This owner states no integral bound. -/
namespace ImbalancedChen.P2OriginalSaving19Cell00Row000
set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false
open scoped BigOperators
open P2OriginalSaving19RowNumericsPure
open P2OriginalLogMomentQ96ArithmeticPure

'''
    for name, statement, proof in proofs:
        s += marker(suffix + '_' + name + '_before')
        s += 'theorem ' + name + ' :\n    ' + statement + ' := ' + proof + '\n\n'
    s += marker(suffix + '_complete')
    s += '\n'.join('#print axioms ' + x[0] for x in proofs) + '\n\n'
    s += 'end ImbalancedChen.P2OriginalSaving19Cell00Row000\n'
    p.write_text(s)
    return p.stem

owners = []
owners.append(emit('Determinant', [PREFIX+'Input', 'P2Winner9FastDetPure'], [
    ('physical_volume_positive', '0 < row.physicalVolume', 'by decide +kernel'),
    ('volume_eq', 'row.physicalVolume = |(edgeOf vertices).det| / (Nat.factorial 8 : ℚ)', '''by
  rw [← P2Winner9FastDetPure.fastDet_eq (edgeOf vertices)]
  decide +kernel'''),
    ('det_ne', '(edgeOf vertices).det ≠ 0', '''by
  intro hzero
  have h := volume_eq
  rw [hzero, abs_zero, zero_div] at h
  exact (ne_of_gt physical_volume_positive) h''')]))

owners.append(emit('Physical', [PREFIX+'Input'], [
    ('all_physical', '∀ i : Fin 9, PhysicalQ (vertices i)', 'by decide +kernel')]))

owners.append(emit('Gap', [PREFIX+'Input'], [
    ('gap_sum_positive', '0 < gapSumOf vertices', 'by decide +kernel'),
    ('mean_gap_eq', 'row.meanGap = gapSumOf vertices / 9', 'by decide +kernel')]))

owners.append(emit('Means', [PREFIX+'Input'], [
    ('weighted_means_eq', '∀ j : Fin 10, meansOf row j = computedMeanOf vertices j', 'by decide +kernel')]))

owners.append(emit('Maxima', [PREFIX+'Input'], [
    ('factor_le_maxima', '∀ i : Fin 9, ∀ j : Fin 10, factorsQ (vertices i) j ≤ topsOf row j', 'by decide +kernel'),
    ('factor_maxima_attained', '∀ j : Fin 10, ∃ i : Fin 9, factorsQ (vertices i) j = topsOf row j', 'by decide +kernel')]))

owners.append(emit('Jensen', [PREFIX+'Input'], [
    ('jensen_eq', 'row.jensenBound = oldEvaluator (massOf row) (meansOf row)', 'by decide +kernel'),
    ('old_floor_eq', 'row.jensenFloorQ96 = oldFloorQ96 (massOf row) (meansOf row)', '''by
  unfold oldFloorQ96
  rw [← jensen_eq]
  decide +kernel''')]))

owners.append(emit('Arithmetic', owners.copy(), [
    ('row_data_checks', 'RowDataChecksFor vertices row', '''by
  exact ⟨det_ne, all_physical, gap_sum_positive, volume_eq, mean_gap_eq,
    weighted_means_eq, factor_le_maxima, factor_maxima_attained,
    jensen_eq, old_floor_eq⟩'''),
    ('bounded_row_data_checks', '''RowDataChecksFor
      (P2OriginalSaving19Geometry00BoundedAccess.boundedRowVertex (0 : Fin 56))
      (P2OriginalSaving19Geometry00BoundedAccess.boundedRow (0 : Fin 56))''', '''by
  rw [boundedRowVertex_eq, boundedRow_eq]
  exact row_data_checks''')]))
(ROOT/'ROW000_OWNERS.json').write_text(json.dumps(owners,indent=2)+'\n')
print(json.dumps({'new_sources': owners},indent=2))
