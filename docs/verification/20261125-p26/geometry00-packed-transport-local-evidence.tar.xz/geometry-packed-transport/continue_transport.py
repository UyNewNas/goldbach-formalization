#!/usr/bin/env python3
"""Check remaining compact spans and transport, reusing every accepted owner."""
from generate_transport import ROOT, span_plan, group_owner, final_owner
from check_new_owner import check_owner
import contextlib
import json


def main():
    log = ROOT / 'continue-transport.log'
    assert not log.exists(), 'Preserve immutable pipeline output.'
    with log.open('w') as output, contextlib.redirect_stdout(output):
        plan = span_plan()
        largest_span_group = max(plan['groups'], key=lambda g: max(s['count'] for s in g['spans']))
        check_owner(group_owner(largest_span_group['index']))
        for group in plan['groups']:
            check_owner(group_owner(group['index']))
        check_owner(final_owner())
        print(json.dumps({'all_transport_owners_passed': True}), flush=True)


if __name__ == '__main__':
    main()
