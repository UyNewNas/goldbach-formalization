#!/usr/bin/env python3
"""Bind compact source slices to frozen old-input prefix certificates.

No parsing is rerun. Host work selects existing theorem spans and emits Lean
candidate equalities; only their normal/kernel checks establish transport.
"""
from pathlib import Path
import argparse
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT / 'project'
NS = 'ImbalancedChen.P2OriginalSaving19GeometryPackedTransport'
OLD_NS = 'ImbalancedChen.P2OriginalSaving19CharacterCoreDiagnostic'
FIXTURE = ROOT / 'goldbach-research/eighth-third-minorant-extension-20261009-a23-s23_low-00-cell.witness.json'
RAW = FIXTURE.read_bytes()
assert len(RAW) == 195134 and hashlib.sha256(RAW).hexdigest() == '87e3c3da5a86a3ea16c1dcae3a5735ea8b0dc7db05d42b5f5cc3aae66cd54691'


def fp(path):
    path = Path(path); data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def write_new(path, data):
    path = Path(path); data = data.encode() if isinstance(data, str) else data
    if path.exists():
        assert path.read_bytes() == data, ('Frozen output differs', str(path))
    else:
        path.parent.mkdir(parents=True, exist_ok=True); path.write_bytes(data)


def registry():
    rows = {x['module']: x for x in json.loads((ROOT / 'FROZEN_SUPPLIERS.json').read_text())['inputs']}
    for path in (ROOT / 'owners').glob('*.json'):
        row = json.loads(path.read_text())
        rows[row['module']] = {'module': row['module'], 'source': row['source'],
                              'project_imports': row['project_imports'],
                              'object': {'path': str(ROOT / 'objects' / (row['module'].replace('.', '/') + '.olean'))}}
    return rows


def save(short, source, scope, plan):
    module = 'ImbalancedChen.' + short
    path = PROJECT / 'ImbalancedChen' / (short + '.lean')
    write_new(path, source)
    imports = re.findall(r'(?m)^import\s+(ImbalancedChen\.\S+)', source)
    known = registry(); closure = []; seen = set()

    def visit(name):
        if name in seen:
            return
        seen.add(name); row = known[name]
        assert fp(row['source']['path']) == row['source']
        for dep in row['project_imports']:
            visit(dep)
        closure.append(row)

    for name in imports:
        visit(name)
    record = {'module': module, 'source': fp(path), 'project_imports': imports,
              'dependency_closure': closure, 'scope': scope, 'fixture': fp(FIXTURE),
              'planned_obligations': plan, 'production_modified': False,
              'remote_jobs_submitted': False, 'accepted_dependencies_recompiled': False,
              'parser_reexecuted': False, 'host_candidate_is_proof': False}
    write_new(ROOT / 'owners' / (short + '.json'), json.dumps(record, indent=2) + '\n')
    return record


def head(imports, description):
    return ''.join('import ' + module + '\n' for module in imports) + f'''
/-! {description}
The original parser certificates remain frozen; this owner only relates input
representations through exact complete character spans. -/
namespace {NS}
set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false
open ImbalancedChen.P2OriginalSaving19Archive
open ImbalancedChen.P2OriginalSaving19PackedChars
open {OLD_NS}

'''


def foot(names):
    return '\n'.join('#print axioms ' + n for n in names) + '\n\nend ' + NS + '\n'


def mark(label):
    return ('run_cmd do\n  let err ← IO.getStderr\n'
            f'  err.putStrLn "P26_GEOMETRY_TRANSPORT {label}"\n  err.flush\n\n')


def data_owner():
    short = 'P2OriginalSaving19ArchiveGeometryData00'
    source = (PROJECT / 'ImbalancedChen' / (short + '.lean')).read_text()
    bootstrap = json.loads((ROOT / 'BOOTSTRAP.json').read_text())
    assert fp(PROJECT / 'ImbalancedChen' / (short + '.lean')) == bootstrap['data_source_copy']
    return save(short, source, 'Unchanged v4 production-FQN compact data owner in private exact-byte mirror',
                {'data_only': True, 'resolved_input_path': bootstrap['actual_resolved_input_path'],
                 'production_FQN': bootstrap['production_FQN'], 'same_v4_source_bytes': True})


def input_owner():
    short = 'P2OriginalSaving19GeometryPackedTransportInput00'
    # The generic/input owner needs no old parser or old CharList import.
    source = head(['ImbalancedChen.P2OriginalSaving19ArchiveGeometryData00'],
                  'Compact production input count, exact rest interfaces and finite list reassembly.')
    source = source.replace('open ' + OLD_NS + '\n', '')
    source += '''noncomputable def compactChars00 : List Char := geometryPacked00.toList
noncomputable def compactRest00 (n : Nat) : List Char := (geometryPacked00.drop n).toList

theorem compactRest00_eq_drop (n : Nat) :
    compactRest00 n = compactChars00.drop n :=
  Tree.toList_drop geometryPacked00 n

theorem compactRest00_drop (start count : Nat) :
    (compactRest00 start).drop count = compactRest00 (start + count) := by
  simp only [compactRest00_eq_drop, List.drop_drop]

theorem compactRest00_zero : compactRest00 0 = compactChars00 := by
  simpa only [List.drop_zero] using compactRest00_eq_drop 0

theorem geometryPacked00_count : geometryPacked00.count = 195134 := by
  decide +kernel

theorem compactChars00_length : compactChars00.length = 195134 :=
  (Tree.length_toList geometryPacked00).trans geometryPacked00_count

theorem compactRest00_end : compactRest00 195134 = [] := by
  rw [compactRest00_eq_drop]
  exact List.drop_eq_nil_of_le (by rw [compactChars00_length]; exact Nat.le_refl _)

/-- A proved finite prefix and the original remaining list reconstruct the input. -/
theorem list_drop_split_of_prefix {A : Type} (xs : List A) (start count : Nat)
    (chunk : List A) (h : (xs.drop start).take count = chunk) :
    xs.drop start = chunk ++ xs.drop (start + count) := by
  calc
    xs.drop start = (xs.drop start).take count ++ (xs.drop start).drop count :=
      (List.take_append_drop count (xs.drop start)).symm
    _ = chunk ++ (xs.drop start).drop count :=
      congrArg (fun part => part ++ (xs.drop start).drop count) h
    _ = chunk ++ xs.drop (start + count) := by rw [List.drop_drop]

'''
    source += foot(['compactRest00_eq_drop', 'compactRest00_drop', 'compactRest00_zero',
                    'geometryPacked00_count', 'compactChars00_length', 'compactRest00_end',
                    'list_drop_split_of_prefix'])
    return save(short, source, 'Exact compact input interfaces and generic finite-list reassembly',
                {'input_length': 195134, 'does_not_import_old_parser': True,
                 'only_count_uses_kernel_decide': True, 'whole_list_equality_claimed': False})


def span_plan():
    frozen = json.loads((ROOT / 'FROZEN_SUPPLIERS.json').read_text())['inputs']
    pattern = re.compile(r'theorem\s+(\w+)\s*:\s*(?:\(geometryChars00\.drop\s+(\d+)\)\.take\s+(\d+)|geometryChars00\.take\s+(\d+))\s*=\s*(\w+)\s*:=')
    candidates = []
    for row in frozen:
        assert fp(row['source']['path']) == row['source']
        for match in pattern.finditer(Path(row['source']['path']).read_text()):
            start = int(match[2] or 0); count = int(match[3] or match[4])
            candidates.append({'start': start, 'end': start + count, 'count': count,
                               'module': row['module'], 'old_theorem': match[1],
                               'chars': match[5], 'implicit_drop_zero': match[2] is None,
                               'source': row['source'], 'import_count': len(row['project_imports'])})
    selected = []; position = 0
    while position < len(RAW):
        options = [row for row in candidates if row['start'] == position]
        assert options, ('Missing original prefix certificate', position)
        best = max(options, key=lambda row: (row['end'], -row['import_count']))
        selected.append({**best, 'index': len(selected)}); position = best['end']
    assert position == len(RAW) and len(selected) == 186
    groups = []; current = []; count = 0
    for span in selected:
        if current and (len(current) == 8 or count + span['count'] > 12000):
            groups.append(current); current = []; count = 0
        current.append(span); count += span['count']
    if current:
        groups.append(current)
    plan = {'input': fp(FIXTURE), 'old_prefix_certificate_count': len(selected),
            'complete_contiguous_coverage': [0, len(RAW)], 'max_span': max(x['count'] for x in selected),
            'max_group_chars': 12000, 'max_group_spans': 8,
            'groups': [{'index': i, 'start': group[0]['start'], 'end': group[-1]['end'],
                        'chars': sum(x['count'] for x in group), 'spans': group}
                       for i, group in enumerate(groups)],
            'host_plan_is_not_proof': True}
    write_new(ROOT / 'SPAN_PLAN.json', json.dumps(plan, indent=2) + '\n')
    return plan


def group_owner(index):
    group = span_plan()['groups'][index]
    short = f'P2OriginalSaving19GeometryPackedSpanGroup{index:03d}'
    imports = ['ImbalancedChen.P2OriginalSaving19GeometryPackedTransportInput00']
    imports += list(dict.fromkeys(span['module'] for span in group['spans']))
    text = head(imports, f"Exact compact prefix group {index}, bytes [{group['start']},{group['end']}).")
    names = []
    for span in group['spans']:
        n = span['index']; start = span['start']; end = span['end']; count = span['count']
        name = f'compactSpan{n:03d}'; chars = span['chars']
        text += mark(f'span_{n:03d}_before_prefix')
        text += f'''theorem {name}_prefix :
    (compactRest00 {start}).take {count} = {chars} := by rfl

theorem {name}_split :
    compactRest00 {start} = {chars} ++ compactRest00 {end} := by
  calc
    compactRest00 {start} =
        (compactRest00 {start}).take {count} ++ (compactRest00 {start}).drop {count} :=
      (List.take_append_drop {count} (compactRest00 {start})).symm
    _ = {chars} ++ (compactRest00 {start}).drop {count} :=
      congrArg (fun part => part ++ (compactRest00 {start}).drop {count}) {name}_prefix
    _ = {chars} ++ compactRest00 {end} :=
      congrArg (fun tail => {chars} ++ tail) (compactRest00_drop {start} {count})

theorem {name}_rest_eq (htail : geometryChars00.drop {end} = compactRest00 {end}) :
    geometryChars00.drop {start} = compactRest00 {start} := by
  have hp : (geometryChars00.drop {start}).take {count} = {chars} :=
'''
        if span['implicit_drop_zero']:
            text += f'    by simpa only [List.drop_zero] using {span["old_theorem"]}\n'
        else:
            text += f'    {span["old_theorem"]}\n'
        text += f'''  exact (list_drop_split_of_prefix geometryChars00 {start} {count} {chars} hp).trans
    ((congrArg (fun tail => {chars} ++ tail) htail).trans {name}_split.symm)

'''
        text += mark(f'span_{n:03d}_complete')
        names += [name + '_prefix', name + '_split', name + '_rest_eq']
    theorem = f'group{index:03d}_rest_eq'
    text += f'''theorem {theorem}
    (htail : geometryChars00.drop {group['end']} = compactRest00 {group['end']}) :
    geometryChars00.drop {group['start']} = compactRest00 {group['start']} := by
'''
    current = 'htail'
    for span in reversed(group['spans']):
        name = f'h{span["index"]:03d}'
        text += f'  have {name} := compactSpan{span["index"]:03d}_rest_eq {current}\n'
        current = name
    text += f'  exact {current}\n\n'
    names.append(theorem); text += foot(names)
    return save(short, text, 'Compact spans and conditional finite-list reassembly; no reader evaluation', group)


def final_owner():
    groups = span_plan()['groups']
    short = 'P2OriginalSaving19GeometryPackedParseTransport00'
    imports = [f'ImbalancedChen.P2OriginalSaving19GeometryPackedSpanGroup{g["index"]:03d}' for g in groups]
    imports += ['ImbalancedChen.P2OriginalSaving19WholeParse00']
    text = head(imports, 'Closed equality of full input representations and transport of accepted original parser theorems.')
    text += '''theorem geometryChars00_eq_geometryPacked00 :
    geometryChars00 = geometryPacked00.toList := by
  have hend : geometryChars00.drop 195134 = compactRest00 195134 :=
    geometryChars00_end_drop.trans compactRest00_end.symm
'''
    current = 'hend'
    for group in reversed(groups):
        name = f'hgroup{group["index"]:03d}'
        text += f'  have {name} := group{group["index"]:03d}_rest_eq {current}\n'
        current = name
    text += f'''  exact (by rfl : geometryChars00 = geometryChars00.drop 0).trans
    ({current}.trans compactRest00_zero)

theorem geometryPacked00_whole_value :
    SourceJson.value 195135 geometryPacked00.toList =
      .ok (originalGeometryJson00, geometryPacked00.toList.drop 195132) := by
  calc
    SourceJson.value 195135 geometryPacked00.toList = SourceJson.value 195135 geometryChars00 :=
      congrArg (SourceJson.value 195135) geometryChars00_eq_geometryPacked00.symm
    _ = .ok (originalGeometryJson00, geometryChars00.drop 195132) := geometryChars00_whole_value
    _ = .ok (originalGeometryJson00, geometryPacked00.toList.drop 195132) :=
      congrArg (fun chars => Except.ok (originalGeometryJson00, chars.drop 195132))
        geometryChars00_eq_geometryPacked00

theorem geometryPacked00_parseChars :
    SourceJson.parseChars geometryPacked00.toList = .ok originalGeometryJson00 :=
  (congrArg SourceJson.parseChars geometryChars00_eq_geometryPacked00.symm).trans
    geometryChars00_parseChars

theorem geometryPacked00_original_parse :
    SourceJson.parse (String.ofList geometryPacked00.toList) = .ok originalGeometryJson00 :=
  (SourceJson.parse_ofList geometryPacked00.toList).trans geometryPacked00_parseChars

'''
    text += foot(['geometryChars00_eq_geometryPacked00', 'geometryPacked00_whole_value',
                  'geometryPacked00_parseChars', 'geometryPacked00_original_parse'])
    return save(short, text, 'Closed complete-list equality and original pure-parser transport',
                {'all_186_spans_used': True, 'complete_bytes': 195134,
                 'closed_representation_equality': True, 'parser_reexecuted': False,
                 'production_FQN': 'ImbalancedChen.P2OriginalSaving19Archive.geometryPacked00'})


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('kind', choices=['data', 'input', 'plan', 'group', 'final'])
    parser.add_argument('--index', type=int)
    args = parser.parse_args()
    if args.kind == 'data':
        record = data_owner()
    elif args.kind == 'input':
        record = input_owner()
    elif args.kind == 'plan':
        record = span_plan()
    elif args.kind == 'group':
        record = group_owner(args.index)
    else:
        record = final_owner()
    print(json.dumps({k: v for k, v in record.items() if k in ['module', 'source', 'old_prefix_certificate_count', 'max_span']}, indent=2))
