#!/usr/bin/env python3
"""Sequentially check new transport owners, preserving immutable receipts."""
from generate_transport import ROOT, fp
import json
import subprocess
import sys


def checkpoint():
    owners = []; failures = []
    for path in sorted((ROOT / 'owners').glob('*.json')):
        manifest = json.loads(path.read_text()); short = manifest['module'].split('.')[-1]
        assert fp(manifest['source']['path']) == manifest['source']
        checks = {}
        for mode in ['normal', 'kernel']:
            for receipt in sorted((ROOT / 'logs' / short).glob(mode + '-*-result.json')):
                record = json.loads(receipt.read_text())
                if record['status'] != 'succeeded':
                    failures.append({'module': manifest['module'], 'mode': mode,
                                     'source': record['source'], 'status': record['status'],
                                     'receipt': fp(receipt), 'elapsed_seconds': record['elapsed_seconds'],
                                     'peak_rss_bytes': record['peak_rss_bytes']})
                if record['source'] != manifest['source'] or record['status'] != 'succeeded':
                    continue
                assert record['exit_code'] == 0 and fp(record['object']['path']) == record['object']
                assert fp(record['log']['path']) == record['log']
                assert record['source_object_invariants_before'] == record['source_object_invariants_after']
                checks[mode] = {'receipt': fp(receipt), 'object': record['object'],
                                'elapsed_seconds': record['elapsed_seconds'],
                                'peak_rss_bytes': record['peak_rss_bytes']}
        owners.append({'module': manifest['module'], 'source': manifest['source'],
                       'manifest': fp(path), 'checks': checks,
                       'normal_kernel_passed': set(checks) == {'normal', 'kernel'}})
    done = [row for row in owners if row['normal_kernel_passed']]
    final = any(row['module'].endswith('.P2OriginalSaving19GeometryPackedParseTransport00') for row in done)
    result = {'scope': 'local original-reader input representation transport',
              'new_owner_count': len(owners), 'accepted_new_owner_count': len(done),
              'whole_transport_verified': final, 'owners': owners, 'historical_failures': failures,
              'production_modified': False, 'remote_jobs_submitted': False,
              'accepted_suppliers_recompiled': False, 'parser_reexecuted': False}
    temporary = ROOT / 'PROGRESS.tmp'
    temporary.write_text(json.dumps(result, indent=2) + '\n'); temporary.replace(ROOT / 'PROGRESS.json')
    print(json.dumps({k: result[k] for k in ['accepted_new_owner_count', 'whole_transport_verified']}), flush=True)


def check_owner(manifest):
    short = manifest['module'].split('.')[-1]
    for mode in ['normal', 'kernel']:
        receipts = list((ROOT / 'logs' / short).glob(mode + '-*-result.json'))
        matched = []
        for path in receipts:
            record = json.loads(path.read_text())
            if record['source'] == manifest['source'] and record['status'] == 'succeeded':
                assert record['exit_code'] == 0 and fp(record['object']['path']) == record['object']
                assert fp(record['log']['path']) == record['log']
                matched.append(record)
        if matched:
            print(json.dumps({'module': manifest['module'], 'mode': mode, 'action': 'reuse accepted object'}), flush=True)
            continue
        assert not receipts, ('Prior failure requires an explicit reviewed attempt', short, mode)
        driver = ROOT / 'logs' / short / (mode + '-initial-driver.log')
        driver.parent.mkdir(parents=True, exist_ok=True); assert not driver.exists()
        with driver.open('w') as output:
            result = subprocess.run([sys.executable, str(ROOT / 'run_owner.py'), short, mode],
                                    cwd=ROOT, stdout=output, stderr=subprocess.STDOUT)
        path = ROOT / 'logs' / short / (mode + '-initial-result.json')
        if path.exists():
            record = json.loads(path.read_text())
            print(json.dumps({k: record[k] for k in ['module', 'mode', 'status', 'source',
                             'elapsed_seconds', 'peak_rss_bytes', 'object']}), flush=True)
        else:
            print(driver.read_text(), flush=True)
        if result.returncode:
            checkpoint()
            raise SystemExit(result.returncode)
    checkpoint()


if __name__ == '__main__':
    checkpoint()
