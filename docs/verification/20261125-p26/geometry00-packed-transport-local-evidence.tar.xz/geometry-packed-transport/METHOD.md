# Exact production compact input transport

## Frozen inputs and scope

The previous full-cell00 package proves the original pure SourceJson reader for CharacterCoreDiagnostic.geometryChars00 and String.ofList thereof. Its 156 accepted new owners and eight accepted suppliers remain frozen. No parser owner is recompiled or reexecuted in this transport package.

The unchanged v4 ArchiveGeometryData00 source is copied byte-for-byte, SHA256 89a3c1bb21c715408eedd9b6264ae9d6d35a3f1ccf939e785a46bb92b95d9ab9. It defines the production FQN ImbalancedChen.P2OriginalSaving19Archive.geometryPacked00. Lean runs in this package's project directory, so the original relative path ../goldbach-research/eighth-third-minorant-extension-20261009-a23-s23_low-00-cell.witness.json resolves to the private exact-byte mirror recorded in BOOTSTRAP.json. The 195134-byte ASCII file preserves CRLF and SHA256 87e3c3da5a86a3ea16c1dcae3a5735ea8b0dc7db05d42b5f5cc3aae66cd54691. This is local validation, not a claim about a P1 resolved path.

The accepted PackedChars and production ArchivePackedLoader objects are reused byte-for-byte from the moment00 package; neither is recompiled. The old 164-module pure-parser closure plus these two suppliers are pinned in FROZEN_SUPPLIERS.json.

## Proof architecture

SPAN_PLAN.json enumerates 186 existing old-input prefix theorems whose intervals concatenate exactly to [0,195134). There are no unbound headers, commas, whitespace or trailing bytes. A host scan selects the theorem names and intervals; the host plan establishes no mathematical or parser claim.

The new input interface defines compactRest00 n as (geometryPacked00.drop n).toList. It reuses the accepted Tree.toList_drop and Tree.length_toList theorems. The exact tree count is checked in Lean by decide +kernel; no parser computation uses decide. A generic list wrapper derives drop = prefix ++ remaining-drop from List.take_append_drop and a proved finite take equality.

The 186 compact prefix equalities are grouped into 37 owners, each at most eight intervals and 12000 total characters. Each equality is a closed rfl check against the same named raw-character constant used by an accepted old-prefix theorem. The largest individual span is 10530 characters. A group's conditional reassembly theorem takes only equality of its final remaining lists and proves equality at its first byte. The final owner discharges every such tail premise from the two proved empty lists at byte 195134, then applies congrArg to transport the accepted original value/parse theorems. No final parse, numeric floor or geometry conclusion is a premise of the closed final result.

## Verification discipline

Each new owner receives normal compilation and then independent leanchecker only on normal success. Limits remain 4 GiB sampled process-tree RSS, 180 seconds, one thread. Source/object/import/raw-input fingerprints are checked before and after each stage. Accepted owner objects are reused; reruns require a distinct explicit reviewed attempt and preserve old logs. The progress file reports completion only after a matching normal/kernel receipt for the final transport owner.

The first input-interface attempt had only Lean-only syntax errors: Type* is unavailable without Mathlib syntax, and prefix is reserved as a binder. The preserved revision changes Type* to Type and the local binder to part; all statements needed for Char lists and all compact data remain the same. This is an expression/API repair, not a new mathematical assumption.

## Boundaries

The intended final result identifies the complete old CharacterCoreDiagnostic list with production geometryPacked00.toList and transports the original reader. It does not prove a typed geometry decoder, geometric validity, moment/floor checks, other files, or equivalence to an older production String literal. No P1 job or production mutation occurs here. Actual completion and exact source hashes are recorded by PROGRESS.json and, after the final owner passes, SOURCE_MANIFEST.json, SOURCE_INPUTS.json and VALIDATION.json.
