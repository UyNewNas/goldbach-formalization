#!/usr/bin/env python3
"""Pin the completed transport closure and all actual local evidence."""
from generate_transport import ROOT, FIXTURE, registry, fp
from check_new_owner import checkpoint
import json
import re
from pathlib import Path


def main():
    checkpoint()
    progress = json.loads((ROOT / 'PROGRESS.json').read_text())
    assert progress['whole_transport_verified']
    assert progress['new_owner_count'] == progress['accepted_new_owner_count']
    observed = {row['module']: row for row in progress['owners']}
    known = registry(); seen = set(); ordered = []
    target = 'ImbalancedChen.P2OriginalSaving19GeometryPackedParseTransport00'

    def visit(module):
        if module in seen:
            return
        seen.add(module); row = known[module]
        assert fp(row['source']['path']) == row['source']
        text = Path(row['source']['path']).read_text()
        imports = re.findall(r'(?m)^import\s+(ImbalancedChen\.\S+)', text)
        assert imports == row['project_imports']
        for name in imports:
            visit(name)
        obj = fp(row['object']['path'])
        if 'sha256' in row['object']:
            assert obj == row['object']
        result = {'module': module, 'source': row['source'], 'object': obj,
                  'project_imports': imports, 'new_owner': module in observed}
        if module in observed:
            observation = observed[module]
            assert observation['normal_kernel_passed'] and observation['source'] == row['source']
            result['checks'] = observation['checks']; result['printed_axioms'] = []
            for mode, check in observation['checks'].items():
                assert fp(check['receipt']['path']) == check['receipt']
                record = json.loads(Path(check['receipt']['path']).read_text())
                assert record['status'] == 'succeeded' and record['exit_code'] == 0
                assert record['source'] == row['source'] and record['object'] == obj
                assert fp(record['log']['path']) == record['log']
                assert record['source_object_invariants_before'] == record['source_object_invariants_after']
                assert record['rss_limit_bytes'] == 4 * 1024**3 and record['wall_seconds'] == 180
                assert record['peak_rss_bytes'] <= record['rss_limit_bytes']
                result['printed_axioms'] += record['printed_axioms']
            result['printed_axioms'] = sorted(set(result['printed_axioms']))
            assert set(result['printed_axioms']) <= {'propext', 'Classical.choice', 'Quot.sound'}
            theorems = re.findall(r'(?m)^(?:private\s+)?(?:theorem|lemma)\s+(\w+)', text)
            prints = re.findall(r'(?m)^#print axioms\s+(\w+)', text)
            assert sorted(theorems) == sorted(prints), (module, theorems, prints)
            assert not re.search(r'\b(?:sorry|admit|native_decide|unsafe)\b', text)
            assert not re.search(r'(?m)^\s*(?:axiom|constant)\s', text)
            result['theorem_count'] = len(theorems)
        ordered.append(result)

    visit(target)
    assert set(observed) <= seen
    bootstrap = json.loads((ROOT / 'BOOTSTRAP.json').read_text())
    for key in ['input_original', 'input_copy', 'data_source_original', 'data_source_copy']:
        assert fp(bootstrap[key]['path']) == bootstrap[key]
    old_manifest = Path('/workspace/p26-recovery-candidates/archive-segment-generator/full-cell00/SOURCE_MANIFEST.json')
    old_validation = old_manifest.with_name('VALIDATION.json')
    frozen = json.loads((ROOT / 'FROZEN_SUPPLIERS.json').read_text())
    assert fp(old_manifest) == frozen['pure_parser_manifest']
    assert fp(old_validation) == frozen['pure_parser_validation']
    plan = json.loads((ROOT / 'SPAN_PLAN.json').read_text())
    flat = [span for group in plan['groups'] for span in group['spans']]
    assert len(flat) == 186 and flat[0]['start'] == 0 and flat[-1]['end'] == 195134
    assert all(a['end'] == b['start'] for a, b in zip(flat, flat[1:]))
    boundary = {
        'production_input_FQN': bootstrap['production_FQN'],
        'same_v4_source_bytes': True,
        'closed_old_char_list_equals_production_packed_toList': True,
        'private_mirror_resolved_input_path': bootstrap['actual_resolved_input_path'],
        'exact_raw_input': fp(FIXTURE),
        'P1_or_production_acceptance': False,
        'old_production_string_literal_equivalence_proved': False,
        'typed_geometry_decode_proved': False,
        'geometry_validity_or_numeric_floors_proved': False,
        'other_geometry_files_proved': False,
        'original_parser_reexecuted': False,
    }
    manifest = {
        'target': target, 'status': 'LOCAL_NORMAL_AND_INDEPENDENT_KERNEL',
        'new_owner_count': len(observed), 'closure_count': len(ordered),
        'frozen_supplier_count': len(ordered) - len(observed),
        'topological_sources': [{k: row[k] for k in ['module', 'source', 'project_imports', 'new_owner']}
                                for row in ordered],
        'boundary': boundary, 'generator': fp(ROOT / 'generate_transport.py'),
        'runner': fp(ROOT / 'run_owner.py'), 'bootstrap': fp(ROOT / 'BOOTSTRAP.json'),
        'span_plan': fp(ROOT / 'SPAN_PLAN.json'), 'collector': fp(ROOT / 'collect_delivery.py'),
        'old_pure_parser_manifest': fp(old_manifest),
    }
    inputs = {'target': target, 'closure_count': len(ordered), 'inputs': ordered}
    checks = [(row['module'], mode, check)
              for row in ordered if row['new_owner'] for mode, check in row['checks'].items()]
    highest = max(checks, key=lambda x: x[2]['peak_rss_bytes'])
    longest = max(checks, key=lambda x: x[2]['elapsed_seconds'])
    result = {
        'status': manifest['status'], 'target': target,
        'new_owner_count': len(observed), 'closure_count': len(ordered),
        'verified_old_prefix_spans': len(flat), 'verified_compact_span_groups': len(plan['groups']),
        'checked_new_theorem_count': sum(row.get('theorem_count', 0) for row in ordered),
        'printed_axioms_union': sorted({a for row in ordered for a in row.get('printed_axioms', [])}),
        'all_new_theorems_have_print_axioms': True,
        'max_successful_rss': {'module': highest[0], 'mode': highest[1], **highest[2]},
        'max_successful_wall': {'module': longest[0], 'mode': longest[1], **longest[2]},
        'historical_failures': progress['historical_failures'],
        'fixed_limits': {'rss_bytes': 4 * 1024**3, 'wall_seconds': 180, 'threads': 1},
        'boundary': boundary, 'source_manifest': None,
    }
    for name, data in [('SOURCE_MANIFEST.json', manifest), ('SOURCE_INPUTS.json', inputs)]:
        (ROOT / name).write_text(json.dumps(data, indent=2) + '\n')
    result['source_manifest'] = fp(ROOT / 'SOURCE_MANIFEST.json')
    (ROOT / 'VALIDATION.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ['status', 'new_owner_count', 'closure_count',
        'verified_old_prefix_spans', 'verified_compact_span_groups', 'checked_new_theorem_count',
        'printed_axioms_union', 'max_successful_rss', 'max_successful_wall']}, indent=2))


if __name__ == '__main__':
    main()
