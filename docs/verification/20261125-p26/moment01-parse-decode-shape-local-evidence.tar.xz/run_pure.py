from pathlib import Path
import json,subprocess,sys,ast
import generate_moment as g
R=Path(__file__).resolve().parent
log=R/'logs/pure-orchestration.log'
assert not log.exists()
chunks=g.chunks_for(g.RECORDS)
assert len(chunks)==144 and all(c['after']-c['first']==1 for c in chunks)
assert (len(chunks)+3)//4==36
for p in R.glob('*.py'):ast.parse(p.read_text(),str(p))
completed=[]
def step(short):
 module='ImbalancedChen.'+short
 for mode in ['normal','kernel']:
  with log.open('ab') as out:
   proc=subprocess.run([sys.executable,'-B',str(R/'run_local.py'),mode,module,'cell01-v1'],cwd=R,stdout=out,stderr=subprocess.STDOUT)
  rp=R/'logs'/short/(mode+'-cell01-v1-result.json')
  if not rp.exists():print('MISSING_RECEIPT',module,mode,proc.returncode,flush=True);raise SystemExit(1)
  row=json.loads(rp.read_text());print(json.dumps({k:row[k] for k in ['module','mode','status','exit_code','elapsed_seconds','peak_rss_bytes']}),flush=True)
  if proc.returncode or row['status']!='succeeded':raise SystemExit(1)
 completed.append(module)
 (R/'PURE_PROGRESS.json').write_text(json.dumps({'completed_normal_and_kernel':completed,'whole_parse_completed':short=='P2OriginalSaving19Moment01Parse','P1_claimed':False},indent=2)+'\n')
step('P2OriginalSaving19ArchiveMomentData01')
step('P2OriginalSaving19Moment01Input')
g.metadata();step('P2OriginalSaving19Moment01Metadata')
for i in range(36):g.records_block(i);step(g.block_short(i))
with log.open('ab') as out:
 proc=subprocess.run([sys.executable,'-B',str(R/'generate_complete.py')],cwd=R,stdout=out,stderr=subprocess.STDOUT)
assert proc.returncode==0
step('P2OriginalSaving19Moment01Parse')
print('P26_MOMENT01_PURE_ALL_NEW_OWNERS_PASSED',len(completed),flush=True)
