from pathlib import Path
import sys,json,hashlib,re
R=Path(__file__).resolve().parent;stage=sys.argv[1]
assert stage in ['pure','typed']
P=R/'project';O=R/'objects'
def fp(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def verify(x):assert fp(Path(x['path']))==x
bootstrap=json.loads((R/'BOOTSTRAP.json').read_text());reused={x['module']:x for x in bootstrap['reused_helpers']}
if stage=='typed':
 prior=json.loads((R/'PURE_PARSE_RESULT.json').read_text())
 for x in prior['new_owners']:reused[x['module']]=x
 schema=json.loads((R/'TYPED_BOOTSTRAP.json').read_text());reused[schema['module']]=schema
end='ImbalancedChen.P2OriginalSaving19Moment01'+('Parse' if stage=='pure' else 'Decoded')
rows={}
def visit(m):
 if m in rows:return
 src=P/(m.replace('.','/')+'.lean');obj=O/(m.replace('.','/')+'.olean');assert src.exists() and obj.exists(),m
 text=src.read_text();imports=re.findall(r'^import\s+(\S+)',text,re.M)
 row={'module':m,'source':fp(src),'object':fp(obj),'imports':imports,'reused':m in reused};rows[m]=row
 for dep in imports:
  if dep.startswith('ImbalancedChen.'):visit(dep)
visit(end)
new=[];axioms=[];std={'propext','Quot.sound','Classical.choice'};ns=ks=0;nm=km=0;failed=[]
for m,row in sorted(rows.items()):
 if m in reused:continue
 folder=R/'logs'/m.split('.')[-1]
 candidates=sorted(folder.glob('normal-*-result.json'));success=[]
 for p in candidates:
  x=json.loads(p.read_text())
  if x['status']=='succeeded' and x['exit_code']==0:success.append((p,x))
  else:failed.append(fp(p))
 assert len(success)==1,(m,'Expected exactly one successful normal',len(success))
 nr,n=success[0];kr=folder/('kernel-'+n['attempt']+'-result.json');k=json.loads(kr.read_text())
 assert k['status']=='succeeded' and k['exit_code']==0
 for result in [n,k]:
  assert result['source']==row['source'] and result['object']==row['object']
  assert result['rss_limit_bytes']==4*1024**3 and result['wall_limit_seconds']==180 and result['threads']==1
  assert result['input_before']==result['input_after']
  verify(result['log'])
  for dep in result['dependencies']:verify(dep['source']);verify(dep['object'])
 assert n['dependencies']==k['dependencies']
 text=Path(n['log']['path']).read_text()
 matched=[]
 for name,items in re.findall(r"'([^']+)' depends on axioms:\s*\[([^\]]*)\]",text):
  aa=[x.strip() for x in items.split(',') if x.strip()];assert set(aa)<=std,(m,name,aa);matched.append({'declaration':name,'axioms':aa,'normal_log':n['log']})
 for name in re.findall(r"'([^']+)' does not depend on any axioms",text):matched.append({'declaration':name,'axioms':[],'normal_log':n['log']})
 assert len(matched)==len(re.findall(r'^#print axioms ',Path(row['source']['path']).read_text(),re.M)),m
 axioms+=matched
 x={**row,'normal_receipt':fp(nr),'kernel_receipt':fp(kr),'normal_seconds':n['elapsed_seconds'],'normal_peak_RSS_bytes':n['peak_rss_bytes'],'kernel_seconds':k['elapsed_seconds'],'kernel_peak_RSS_bytes':k['peak_rss_bytes']};new.append(x)
 ns+=n['elapsed_seconds'];ks+=k['elapsed_seconds'];nm=max(nm,n['peak_rss_bytes']);km=max(km,k['peak_rss_bytes'])
name='PURE_PARSE' if stage=='pure' else 'TYPED'
result={'schema':'saving19_moment01_'+stage+'_local_v1','status':'NORMAL_AND_INDEPENDENT_KERNEL_PASSED','actual_input':bootstrap['original_input_copy'],'production_input_FQN':bootstrap['production_FQN'],'source_commit_basis':bootstrap['source_commit'],'new_owners':new,'reused_module_count':len(rows)-len(new),'project_closure':len(rows),'records':144,'metadata_fields':9,'new_printed_theorems':len(axioms),'exact_printed_axiom_sets':axioms,'sum_successful_normal_seconds':ns,'sum_successful_kernel_seconds':ks,'max_successful_normal_peak_RSS_bytes':nm,'max_successful_kernel_peak_RSS_bytes':km,'retained_failures':failed,'limits_each_invocation':{'RSS_bytes':4*1024**3,'seconds':180,'threads':1},'whole_pure_parse_proved':True,'typed_decode_proved':stage=='typed','mathematical_floor_validity_proved':False,'P1_strict_acceptance_claimed':False,'all_cells_claimed':False,'host_plan_is_proof':False,'original_reader_or_schema_changed':False}
manifest={'schema':'saving19_moment01_'+stage+'_source_closure_v1','sources':list(sorted(rows.values(),key=lambda r:r['module'])),'final_module':end,'project_modules':len(rows),'new_owner_count':len(new),'source_commit_basis':bootstrap['source_commit']}
for path,data in [(R/(name+'_RESULT.json'),result),(R/(name+'_SOURCE_MANIFEST.json'),manifest)]:
 text=json.dumps(data,indent=2)+'\n';assert not path.exists();path.write_text(text)
print(json.dumps({k:result[k] for k in ['status','project_closure','reused_module_count','new_printed_theorems','sum_successful_normal_seconds','sum_successful_kernel_seconds','max_successful_normal_peak_RSS_bytes','max_successful_kernel_peak_RSS_bytes','whole_pure_parse_proved','typed_decode_proved']},indent=2))
