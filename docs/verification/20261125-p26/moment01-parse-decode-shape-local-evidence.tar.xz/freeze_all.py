from pathlib import Path
import json,hashlib,re
R=Path(__file__).resolve().parent
P=R/'project';O=R/'objects'
def fp(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def ck(x):
 p=Path(x['path']);a=fp(p);assert a['bytes']==x['bytes'] and a['sha256']==x['sha256'],p
pure=json.loads((R/'PURE_PARSE_RESULT.json').read_text());typed=json.loads((R/'TYPED_RESULT.json').read_text());pb=json.loads((R/'BOOTSTRAP.json').read_text());tb=json.loads((R/'TYPED_BOOTSTRAP.json').read_text())
assert pure['whole_pure_parse_proved'] and typed['typed_decode_proved']
accepted={x['module']:x for x in pure['new_owners']+typed['new_owners']}
shape='ImbalancedChen.P2OriginalSaving19Moment01Shape';folder=R/'logs'/shape.split('.')[-1]
npath=folder/'normal-cell01-shape-v1-result.json';kpath=folder/'kernel-cell01-shape-v1-result.json';n=json.loads(npath.read_text());k=json.loads(kpath.read_text())
for a in [n,k]:
 assert a['status']=='succeeded' and a['exit_code']==0 and a['input_before']==a['input_after'];ck(a['source']);ck(a['object']);ck(a['log'])
 for d in a['dependencies']:ck(d['source']);ck(d['object'])
assert n['dependencies']==k['dependencies']
accepted[shape]={'module':shape,'source':n['source'],'object':n['object'],'normal_receipt':fp(npath),'kernel_receipt':fp(kpath),'normal_seconds':n['elapsed_seconds'],'normal_peak_RSS_bytes':n['peak_rss_bytes'],'kernel_seconds':k['elapsed_seconds'],'kernel_peak_RSS_bytes':k['peak_rss_bytes']}
reused={x['module']:x for x in pb['reused_helpers']};reused[tb['module']]=tb
allrows={}
def visit(m):
 if m in allrows:return
 src=P/(m.replace('.','/')+'.lean');obj=O/(m.replace('.','/')+'.olean');text=src.read_text();imports=re.findall(r'^import\s+(\S+)',text,re.M)
 assert not re.search(r'\b(sorry|admit|native_decide|unsafe)\b|^\s*axiom\b',text,re.M),m
 row={'module':m,'source':fp(src),'object':fp(obj),'imports':imports,'reused_without_compilation':m in reused};allrows[m]=row
 if m in reused:
  for category in ['source','object']:
   for side in ['original','copy']:ck(reused[m][category][side])
 else:
  a=accepted[m];assert a['source']==row['source'] and a['object']==row['object'];ck(a['normal_receipt']);ck(a['kernel_receipt']);row['normal_receipt']=a['normal_receipt'];row['kernel_receipt']=a['kernel_receipt']
 for dep in imports:
  if dep.startswith('ImbalancedChen.'):visit(dep)
visit(shape);assert len(allrows)==88 and len(accepted)==81 and len(reused)==7
rows=sorted(allrows.values(),key=lambda x:x['module']);canonical=[{'module':x['module'],'source_sha256':x['source']['sha256'],'source_bytes':x['source']['bytes'],'imports':x['imports']} for x in rows];digest=hashlib.sha256(json.dumps(canonical,sort_keys=True,separators=(',',':')).encode()).hexdigest()
axioms=pure['exact_printed_axiom_sets']+typed['exact_printed_axiom_sets'];text=Path(n['log']['path']).read_text();extra=[]
for name,items in re.findall(r"'([^']+)' depends on axioms:\s*\[([^\]]*)\]",text):extra.append({'declaration':name,'axioms':[x.strip() for x in items.split(',') if x.strip()],'normal_log':n['log']})
for name in re.findall(r"'([^']+)' does not depend on any axioms",text):extra.append({'declaration':name,'axioms':[],'normal_log':n['log']})
assert len(extra)==6 and all(set(x['axioms'])<={'propext','Quot.sound','Classical.choice'} for x in extra);axioms+=extra
shape_result={'status':'NORMAL_AND_INDEPENDENT_KERNEL_PASSED','owner':accepted[shape],'axioms':extra,'rows':144,'metadata_and_row_IDs_and_floor_slot_lengths_only':True,'floor_validity_claimed':False,'P1_claimed':False};(R/'SHAPE_RESULT.json').write_text(json.dumps(shape_result,indent=2)+'\n')
closure={'schema':'saving19_moment01_whole_parse_typed_shape_closure_v1','project_modules':88,'new_local_owners':81,'reused_supplier_count':7,'canonical_source_rows':canonical,'source_closure_canonical_sha256':digest,'sources_objects_and_receipts':rows,'P1_strict_claimed':False};(R/'FULL_SOURCE_CLOSURE.json').write_text(json.dumps(closure,indent=2)+'\n')
final={'schema':'saving19_moment01_full_local_checkpoint_v1','status':'WHOLE_PARSE_TYPED_AND_SHAPE_NORMAL_KERNEL_PASSED','source_commit_basis':pb['source_commit'],'original_input':pb['original_input_copy']['original'],'local_input_copy':pb['original_input_copy']['copy'],'new_owner_count':81,'reused_supplier_count':7,'source_closure':88,'new_owners':list(sorted(accepted.values(),key=lambda x:x['module'])),'printed_theorems':len(axioms),'exact_printed_axiom_sets':axioms,'record_count':144,'Q80_integer_slots':1440,'Q96_integer_slots':288,'metadata_fields':9,'all_original_bytes_parsed':True,'concrete_typed_value_proved':True,'all_row_IDs_and_sizes_and_bounds_proved':True,'saved_floor_validity_proved':False,'Archive_aliases_connected':False,'all13_cells_claimed':False,'P1_strict_acceptance':False,'source_closure_canonical_sha256':digest,'failures_preserved':typed['retained_failures'],'final_bind_repair':fp(R/'FINAL_BIND_REPAIR.json'),'normal_seconds':sum(x['normal_seconds'] for x in accepted.values()),'kernel_seconds':sum(x['kernel_seconds'] for x in accepted.values()),'max_normal_RSS_bytes':max(x['normal_peak_RSS_bytes'] for x in accepted.values()),'max_kernel_RSS_bytes':max(x['kernel_peak_RSS_bytes'] for x in accepted.values()),'budgets_increased':False,'successful_owners_recompiled':False,'runtime_Lean_commit':'62eed1db4d67327ec8120be05f1a1b0847d74561','Mathlib_pin':'e4c91783ca8e6a7c693ae624ade32fd22d4e43c1'}
(R/'FINAL_RESULT.json').write_text(json.dumps(final,indent=2)+'\n')
progress=json.loads((R/'TYPED_PROGRESS.json').read_text());progress['completed_normal_and_kernel']=[x['module'] for x in typed['new_owners']];progress['whole_typed_completed']=True;progress['final_bind_repair']=fp(R/'FINAL_BIND_REPAIR.json');(R/'TYPED_PROGRESS.json').write_text(json.dumps(progress,indent=2)+'\n')
# Keep the historical input adaptation untouched; capture the later typed/shape derivations separately.
origin=R.parent/'archive-moment00'
adapted={'typed_metadata_origin':fp(origin/'generate_typed_complete.py'),'typed_metadata_adaptation':fp(R/'generate_typed_metadata.py'),'abstract_glue_origin':fp(origin/'generate_typed_glue_v2.py'),'abstract_glue_adaptation':fp(R/'generate_typed_glue.py'),'final_decoded_original_source':fp(origin/'project/ImbalancedChen/P2OriginalSaving19Moment00Decoded.lean'),'final_decoded_new_source':fp(P/'ImbalancedChen/P2OriginalSaving19Moment01Decoded.lean'),'shape_adaptation':fp(R/'SHAPE_ADAPTATION.json'),'generic_parse_decode_bridge_origin':fp(origin/'project/ImbalancedChen/P2OriginalSaving19Moment00DecodeFromRows.lean'),'generic_parse_decode_bridge_new_source':fp(P/'ImbalancedChen/P2OriginalSaving19MomentParseDecodeBridge.lean'),'unchanged_parser_schema_and_all_prior_objects':True}
(R/'LATER_ADAPTATION_SOURCE_ORIGIN.json').write_text(json.dumps(adapted,indent=2)+'\n')
print(json.dumps({k:final[k] for k in ['status','new_owner_count','reused_supplier_count','source_closure','printed_theorems','normal_seconds','kernel_seconds','max_normal_RSS_bytes','max_kernel_RSS_bytes','source_closure_canonical_sha256']},indent=2))
