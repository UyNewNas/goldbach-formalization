#!/usr/bin/env python3
"""Proof-only composition repair: abstract the monadic rewrites before applying
certificates to the complete actual record lists. Never decode records again.
"""
import json
from pathlib import Path
import generate_moment as g
import generate_typed as t

short='P2OriginalSaving19Moment01DecodeFromRows'
s=t.head(['P2OriginalSaving19Moment01DecodeMetadata'],
         'Abstract monadic composition of the original decoder. No concrete record list is reduced here.')
s+=g.mark('abstract_rows_before_glue')
s+='''theorem decodeMoments_of_records_decode
    (sourceRecords : List SourceJson) (typedRecords : List MomentRecord)
    (hrecords : sourceRecords.mapM decodeMomentRecord = .ok typedRecords) :
    decodeMoments (momentObjectWithRecords sourceRecords) =
      .ok (momentMomentsWithRows typedRecords.toArray) := by
  rw [decodeMoments_momentObjectWithRecords, List.mapM_toArray, hrecords]
  rfl

'''
s+=g.mark('abstract_rows_glue_complete')+t.foot(['decodeMoments_of_records_decode'])
m=t.save(short,s,{'abstract_source_and_typed_record_lists':True,'concrete_decode_recomputed':False,
                  'preserves_original_decodeMoments':True,'uses_existing_List_mapM_toArray':True})
print(json.dumps({'module':m['module'],'source':m['source']},indent=2))
