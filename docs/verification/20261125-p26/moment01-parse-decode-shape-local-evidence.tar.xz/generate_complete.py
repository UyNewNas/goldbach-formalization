#!/usr/bin/env python3
"""Compose certified packed-input spans into the unchanged whole SourceJson parser.
Host quotations remain candidates. No typed decoder or mathematical data test.
"""
import json
import generate_moment as g

f = g.PLAN.fields[-1]
node = f.value
assert f.separator == '}'
assert (f.prefix_start,node.start,node.end,f.prefix_end)==(348,363,75089,75092)
short = 'P2OriginalSaving19Moment01Parse'
s = g.head(['P2OriginalSaving19Moment01Metadata',g.block_short(35),
            'P2OriginalSaving19ParseFromValue00'],
           'Whole original moment01 pure SourceJson parse, assembled from checked compact-input spans. No typed decode claim.')
s += f'''def momentRecordsHeaderChars : List Char := {g.base.chars(g.RAW,f.prefix_start,node.start)}
def momentRecordsFieldKey : String := String.ofList {g.base.quote_list('records')}
def momentRecordsFieldAcc : List (String × SourceJson) :=
  (momentRecordsFieldKey, momentRecordsArrayValue) :: momentMetadataAcc009
def momentRootValue : SourceJson := .obj (momentRecordsFieldAcc.reverse)
def momentRecordsSeparatorChars : List Char := {g.base.chars(g.RAW,node.end,f.prefix_end)}
def momentTrailingChars : List Char := {g.base.chars(g.RAW,g.PLAN.end,len(g.RAW))}

'''
s += g.mark('whole_before_last_header_binding')
s += g.emit_split('moment_records_header',f.prefix_start,node.start,'momentRecordsHeaderChars')
s += g.emit_split('moment_records_separator',node.end,f.prefix_end,'momentRecordsSeparatorChars')
s += g.emit_split('moment_trailing',g.PLAN.end,len(g.RAW),'momentTrailingChars')
s += g.mark('whole_after_last_raw_bindings')
s += '''def momentRecordsAfterValue (fuel : Nat) (result : SourceJson × List Char) :
    Except String (SourceJson × List Char) :=
  match SourceJson.white result.2 with
  | '}' :: ending =>
      .ok (.obj (((momentRecordsFieldKey, result.1) :: momentMetadataAcc009).reverse), ending)
  | ',' :: ending =>
      SourceJson.object fuel (SourceJson.white ending)
        ((momentRecordsFieldKey, result.1) :: momentMetadataAcc009)
  | _ => .error "object separator missing"

theorem object_moment_records_header (fuel : Nat) (rest : List Char) :
    SourceJson.object (fuel + 183) (SourceJson.white (momentRecordsHeaderChars ++ rest)) momentMetadataAcc009 =
      (SourceJson.value (fuel + 182) rest).bind (momentRecordsAfterValue (fuel + 182)) := by rfl

theorem moment_records_after_value_separator (fuel : Nat) (tail : List Char) :
    (Except.ok (momentRecordsArrayValue, momentRecordsSeparatorChars ++ tail)).bind
      (momentRecordsAfterValue (fuel + 182)) = .ok (momentRootValue, tail) := by rfl

theorem object_moment_records_original (fuel : Nat) :
    SourceJson.object (fuel + 183) (SourceJson.white (momentRest01 348)) momentMetadataAcc009 =
      .ok (momentRootValue, momentRest01 75092) := by
  calc
    SourceJson.object (fuel + 183) (SourceJson.white (momentRest01 348)) momentMetadataAcc009 =
        SourceJson.object (fuel + 183)
          (SourceJson.white (momentRecordsHeaderChars ++ momentRest01 363)) momentMetadataAcc009 :=
      congrArg (fun rest => SourceJson.object (fuel + 183) (SourceJson.white rest) momentMetadataAcc009)
        moment_records_header_split
    _ = (SourceJson.value (fuel + 182) (momentRest01 363)).bind
        (momentRecordsAfterValue (fuel + 182)) :=
      object_moment_records_header fuel (momentRest01 363)
    _ = (Except.ok (momentRecordsArrayValue, momentRest01 75089)).bind
        (momentRecordsAfterValue (fuel + 182)) :=
      congrArg (fun result => result.bind (momentRecordsAfterValue (fuel + 182)))
        (value_moment_records_original fuel)
    _ = (Except.ok (momentRecordsArrayValue,
          momentRecordsSeparatorChars ++ momentRest01 75092)).bind
        (momentRecordsAfterValue (fuel + 182)) :=
      congrArg (fun rest => (Except.ok (momentRecordsArrayValue, rest)).bind
        (momentRecordsAfterValue (fuel + 182))) moment_records_separator_split
    _ = .ok (momentRootValue, momentRest01 75092) :=
      moment_records_after_value_separator fuel (momentRest01 75092)

theorem value_moment01_original (fuel : Nat) :
    SourceJson.value (fuel + 193) momentChars01 =
      .ok (momentRootValue, momentRest01 75092) := by
  exact (momentChars01_through_metadata fuel).trans (object_moment_records_original fuel)

theorem momentTrailing_white : SourceJson.white (momentRest01 75092) = [] := by
  calc
    SourceJson.white (momentRest01 75092) =
        SourceJson.white (momentTrailingChars ++ momentRest01 75094) :=
      congrArg SourceJson.white moment_trailing_split
    _ = SourceJson.white (momentTrailingChars ++ []) :=
      congrArg (fun rest => SourceJson.white (momentTrailingChars ++ rest)) momentRest01_end
    _ = [] := by rfl

theorem momentChars01_parseChars : SourceJson.parseChars momentChars01 = .ok momentRootValue := by
  apply SourceJson.parseChars_of_value_eq (tail := momentRest01 75092)
  · rw [momentChars01_length]
    exact value_moment01_original 74902
  · exact momentTrailing_white

theorem momentPacked01_parseChars :
    SourceJson.parseChars momentPacked01.toList = .ok momentRootValue :=
  momentChars01_parseChars

theorem momentPacked01_parse :
    SourceJson.parse (String.ofList momentPacked01.toList) = .ok momentRootValue :=
  (SourceJson.parse_ofList momentPacked01.toList).trans momentPacked01_parseChars

theorem momentPacked01_parse_success :
    (SourceJson.parse (String.ofList momentPacked01.toList)).toOption.isSome = true := by
  rw [momentPacked01_parse]
  rfl

'''
s += g.mark('whole_original_parser_complete')
s += g.foot(['moment_records_header_prefix','moment_records_header_split',
             'moment_records_separator_prefix','moment_records_separator_split',
             'moment_trailing_prefix','moment_trailing_split','object_moment_records_header',
             'moment_records_after_value_separator','object_moment_records_original',
             'value_moment01_original','momentTrailing_white','momentChars01_parseChars',
             'momentPacked01_parseChars','momentPacked01_parse','momentPacked01_parse_success'])
m=g.save(short,s,'whole-file original pure SourceJson parser; no typed decode claim',
         {'root_span':[0,g.PLAN.end],'complete_input_chars':len(g.RAW),
          'root_initial_fuel':len(g.RAW)+1,'generic_value_offset':g.PLAN.need,
          'generic_fuel_instantiation':len(g.RAW)+1-g.PLAN.need,
          'trailing_bytes':list(g.RAW[g.PLAN.end:]),'records_count':len(node.children),
          'all_root_fields_in_original_order':[x.key.scalar for x in g.PLAN.fields],
          'reader_success_target':'SourceJson.parse (String.ofList momentPacked01.toList) = .ok momentRootValue',
          'typed_decode_claimed':False,'old_Core_String_equality_claimed':False})
print(json.dumps({'module':m['module'],'source':m['source'],'planned_obligations':m['planned_obligations']},indent=2))
