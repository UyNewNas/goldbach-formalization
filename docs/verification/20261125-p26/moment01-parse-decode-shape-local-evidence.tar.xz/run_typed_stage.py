from pathlib import Path
import json,subprocess,sys
import generate_moment as g
import generate_typed as t
R=Path(__file__).resolve().parent;log=R/'logs/typed-orchestration.log';assert not log.exists()
assert json.loads((R/'PURE_PARSE_RESULT.json').read_text())['whole_pure_parse_proved']
completed=[]
def gen(script):
 with log.open('ab') as out:p=subprocess.run([sys.executable,'-B',str(R/script)],cwd=R,stdout=out,stderr=subprocess.STDOUT)
 assert p.returncode==0,script
def step(short):
 module='ImbalancedChen.'+short
 for mode in ['normal','kernel']:
  with log.open('ab') as out:p=subprocess.run([sys.executable,'-B',str(R/'run_typed.py'),mode,module,'cell01-typed-v1'],cwd=R,stdout=out,stderr=subprocess.STDOUT)
  path=R/'logs'/short/(mode+'-cell01-typed-v1-result.json')
  if not path.exists():print('MISSING_RECEIPT',module,mode,p.returncode,flush=True);raise SystemExit(1)
  row=json.loads(path.read_text());print(json.dumps({k:row[k] for k in ['module','mode','status','exit_code','elapsed_seconds','peak_rss_bytes']}),flush=True)
  if p.returncode or row['status']!='succeeded':raise SystemExit(1)
 completed.append(module)
 (R/'TYPED_PROGRESS.json').write_text(json.dumps({'completed_normal_and_kernel':completed,'whole_typed_completed':short=='P2OriginalSaving19Moment01Decoded','P1_claimed':False},indent=2)+'\n')
gen('generate_typed_metadata.py');step('P2OriginalSaving19Moment01DecodeMetadata')
gen('generate_typed_glue.py');step('P2OriginalSaving19Moment01DecodeFromRows')
for i in range(36):t.block(i);step(t.short(i))
step('P2OriginalSaving19Moment01Decoded')
print('P26_MOMENT01_TYPED_ALL_NEW_OWNERS_PASSED',len(completed),flush=True)
