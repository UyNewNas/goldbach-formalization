#!/usr/bin/env python3
"""Use the exact original metadata and unchanged decoder; no getD fallback."""
import json
import generate_typed as t
import generate_moment as g

short='P2OriginalSaving19Moment01DecodeMetadata'
s=t.head(['P2OriginalSaving19ArchiveSchema','P2OriginalSaving19Moment01Parse'],
         'Original moment01 metadata decoded to exact fields, leaving the original record list abstract.')
s+='''def momentObjectWithRecords (records : List SourceJson) : SourceJson :=
  .obj (((momentRecordsFieldKey, .arr records) :: momentMetadataAcc009).reverse)

'''
field_names=['cellId','sourceWitness','dimension','verticesPerSimplex','factorCount','logDegree','expDegree','logDenominatorText','finalDenominatorText']
values=[];names=[]
for i,f in enumerate(g.PLAN.fields[:-1]):
    isstr=f.value.kind=='str';typ='String' if isstr else 'Nat'
    value='String.ofList '+g.base.quote_list(f.value.scalar) if isstr else str(f.value.scalar)
    target=f'momentMetadataDecoded_{field_names[i]}'
    s+=f'def {target} : {typ} := {value}\n\n'
    thm=f'get_moment_metadata_{i:03d}'
    s+=f'''theorem {thm} (records : List SourceJson) :
    (momentObjectWithRecords records).getObjValAs? {typ} "{f.key.scalar}" =
      .ok {target} := by
  change SourceJson.Decode.read (α := {typ}) momentMetadataField{i:03d}Value = .ok {target}
  decide +kernel

'''
    s+=g.mark(f'typed_metadata_{i:03d}_complete')
    values.append(target);names.append(thm)
for i,key in [(7,'logDenominator'),(8,'finalDenominator')]:
    s+=f'def momentMetadataDecoded_{key} : Int := {t.integer_literal(g.PLAN.fields[i].value)}\n\n'
    thm=f'parse_moment_metadata_{key}'
    s+=f'''theorem {thm} :
    parseInteger {values[i]} = .ok momentMetadataDecoded_{key} := by decide +kernel

'''
    names.append(thm)
s+='''def momentMomentsWithRows (rows : Array MomentRecord) : Moments := {
  cellId := momentMetadataDecoded_cellId
  sourceWitness := momentMetadataDecoded_sourceWitness
  dimension := momentMetadataDecoded_dimension
  verticesPerSimplex := momentMetadataDecoded_verticesPerSimplex
  factorCount := momentMetadataDecoded_factorCount
  logDegree := momentMetadataDecoded_logDegree
  expDegree := momentMetadataDecoded_expDegree
  logDenominator := momentMetadataDecoded_logDenominator
  finalDenominator := momentMetadataDecoded_finalDenominator
  rows := rows }

theorem get_moment_records_field (records : List SourceJson) :
    (momentObjectWithRecords records).getObjVal? "records" = .ok (.arr records) := by rfl

theorem decodeMoments_momentObjectWithRecords (records : List SourceJson) :
    decodeMoments (momentObjectWithRecords records) =
      (records.toArray.mapM decodeMomentRecord).bind (fun rows => .ok (momentMomentsWithRows rows)) := by
  simp only [decodeMoments,
    get_moment_metadata_000, get_moment_metadata_001, get_moment_metadata_002,
    get_moment_metadata_003, get_moment_metadata_004, get_moment_metadata_005,
    get_moment_metadata_006, get_moment_metadata_007, get_moment_metadata_008,
    parse_moment_metadata_logDenominator, parse_moment_metadata_finalDenominator,
    get_moment_records_field, SourceJson.getArr?, pure_bind]
  rfl

'''
s+=g.mark('typed_metadata_decoder_factorization_complete')
s+=t.foot(names+['get_moment_records_field','decodeMoments_momentObjectWithRecords'])
m=t.save(short,s,{'original_metadata_fields':[f.key.scalar for f in g.PLAN.fields[:-1]],
                  'all_metadata_concrete_and_checked':True,'record_list_remains_arbitrary':True,
                  'full_typed_file_claimed':False})
print(json.dumps({'module':m['module'],'source':m['source']},indent=2))
