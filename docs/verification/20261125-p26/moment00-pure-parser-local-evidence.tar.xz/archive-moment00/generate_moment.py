#!/usr/bin/env python3
"""Generate only candidate quotations and original SourceJson equations.
The host plan is not evidence: every raw span and parser step is checked by Lean.
Small-array and one-binding block patterns are adapted from the frozen geometry
array_blocks.py / block_single_bind.py / fragments.py sources recorded below.
No geometry source, data owner, or object is imported or compiled.
"""
from pathlib import Path
import argparse
import hashlib
import json
import re
import raw_planner as base

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT / 'project'
NS = 'ImbalancedChen.P2OriginalSaving19Moment00Parsing'
FIXTURE = ROOT / 'goldbach-research/eighth-third-moment-refinement-20261009-a23-low-00.witness.json'
RAW = FIXTURE.read_bytes()
assert len(RAW) == 28999 and base.sha(RAW) == 'd88e9d02334dfa840f81c0e2be8e97d559978ac3848fdea13990deced9a65052'
PLAN = base.RawPlanner(RAW).value(0)
assert PLAN.kind == 'obj' and PLAN.end == 28997 and RAW[PLAN.end:] == b'\r\n'
RECORDS = PLAN.fields[-1].value
assert PLAN.fields[-1].key.scalar == 'records' and len(RECORDS.children) == 56
TEMPLATE_ROOT = ROOT.parent / 'archive-segment-generator/full-cell00'


def fp(path):
    path = Path(path); data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': base.sha(data)}


def write_new(path, data):
    path = Path(path); data = data.encode() if isinstance(data, str) else data
    if path.exists():
        assert path.read_bytes() == data, ('Frozen generated source differs', str(path))
    else:
        path.parent.mkdir(parents=True, exist_ok=True); path.write_bytes(data)


def save(short, source, scope, plan):
    source = source.replace('\ndef ', '\nnoncomputable def ')
    path = PROJECT / 'ImbalancedChen' / (short + '.lean')
    write_new(path, source)
    manifest = {
        'module': 'ImbalancedChen.' + short,
        'source': fp(path), 'scope': scope, 'planned_obligations': plan,
        'fixture': fp(FIXTURE), 'production_input_FQN': 'ImbalancedChen.P2OriginalSaving19Archive.momentPacked00',
        'project_imports': re.findall(r'(?m)^import\s+(ImbalancedChen\.\S+)', source),
        'template_sources': [fp(TEMPLATE_ROOT / p) for p in ['array_blocks.py','block_single_bind.py','fragments.py']],
        'host_candidate_only': True, 'whole_parse_claimed_by_host': False,
        'original_SourceJson_unchanged': True, 'geometry_owners_imported': False,
        'production_modified': False, 'remote_jobs_submitted': False,
    }
    write_new(ROOT / 'owners' / (short + '.json'), json.dumps(manifest, indent=2) + '\n')
    return manifest


def head(imports, description):
    return ''.join('import ImbalancedChen.' + s + '\n' for s in imports) + f'''
/-! {description}
Candidate quotations preserve exact original raw bytes. The Lean equations bind
them to the production-compatible packed input and run the unchanged reader.
This local input resolves inside this private project, not the P1 filesystem. -/
namespace {NS}
set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false
open ImbalancedChen.P2OriginalSaving19Archive

'''


def foot(names):
    return '\n'.join('#print axioms ' + n for n in names) + '\n\nend ' + NS + '\n'


def mark(label):
    return ('run_cmd do\n  let err ← IO.getStderr\n'
            f'  err.putStrLn "P26_MOMENT00 {label}"\n  err.flush\n\n')


def append_chain(names, tail=None):
    assert names
    if tail is None: return ' ++ '.join(names)
    result = tail
    for name in reversed(names): result = f'{name} ++ ({result})'
    return result


def emit_split(name, start, end, quoted):
    return f'''theorem {name}_prefix :
    (momentRest00 {start}).take {end-start} = {quoted} := by rfl

theorem {name}_split :
    momentRest00 {start} = {quoted} ++ momentRest00 {end} := by
  calc
    momentRest00 {start} =
        (momentRest00 {start}).take {end-start} ++ (momentRest00 {start}).drop {end-start} :=
      (List.take_append_drop {end-start} (momentRest00 {start})).symm
    _ = {quoted} ++ (momentRest00 {start}).drop {end-start} :=
      congrArg (fun p => p ++ (momentRest00 {start}).drop {end-start}) {name}_prefix
    _ = {quoted} ++ momentRest00 {end} :=
      congrArg (fun rest => {quoted} ++ rest) (momentRest00_drop {start} {end-start})

'''


def metadata():
    short = 'P2OriginalSaving19Moment00Metadata'
    text = head(['P2OriginalSaving19Moment00Input'],
                'The first nine original metadata fields, including root opening and original duplicate-key checks.')
    text += 'def momentMetadataAcc000 : List (String × SourceJson) := []\n\n'
    names=[]; char_names=[]
    for i, f in enumerate(PLAN.fields[:-1]):
        stem=f'momentMetadataField{i:03d}'
        start = 1 if i == 0 else f.prefix_start
        before = PLAN.need-1-i; after=before-1
        acc=f'momentMetadataAcc{i:03d}'; nextacc=f'momentMetadataAcc{i+1:03d}'
        text+=f'def {stem}Key : String := String.ofList {base.quote_list(f.key.scalar)}\n'
        text+=f'def {stem}Value : SourceJson := {base.lean_node(f.value)}\n'
        text+=f'def {stem}Chars : List Char := {base.chars(RAW,start,f.prefix_end)}\n'
        text+=f'def {nextacc} : List (String × SourceJson) := ({stem}Key, {stem}Value) :: {acc}\n\n'
        thm=f'object_moment_metadata_{i:03d}'
        text+=f'''theorem {thm} (fuel : Nat) (tail : List Char) :
    SourceJson.object (fuel + {before}) (SourceJson.white ({stem}Chars ++ tail)) {acc} =
      SourceJson.object (fuel + {after}) (SourceJson.white tail) {nextacc} := by rfl

'''
        text+=mark(f'metadata_{i:03d}_generic_complete')
        char_names.append(stem+'Chars'); names.append(thm)
    text+=f"def momentMetadataChars : List Char := '{{' :: ({append_chain(char_names)})\n\n"
    payload=append_chain(char_names,'tail')
    text+=f'''theorem value_moment_metadata (fuel : Nat) (tail : List Char) :
    SourceJson.value (fuel + {PLAN.need}) (momentMetadataChars ++ tail) =
      SourceJson.object (fuel + {PLAN.need-10}) (SourceJson.white tail) momentMetadataAcc009 := by
  have hinput : momentMetadataChars ++ tail = '{{' :: ({payload}) := by
    simp only [momentMetadataChars, List.cons_append, List.append_assoc]
  calc
    SourceJson.value (fuel + {PLAN.need}) (momentMetadataChars ++ tail) =
        SourceJson.value (fuel + {PLAN.need}) ('{{' :: ({payload})) :=
      congrArg (SourceJson.value (fuel + {PLAN.need})) hinput
    _ = SourceJson.object (fuel + {PLAN.need-1}) (SourceJson.white ({payload})) momentMetadataAcc000 := by rfl
'''
    for i,f in enumerate(PLAN.fields[:-1]):
        rest=append_chain(char_names[i+1:],'tail') if i+1<len(char_names) else 'tail'
        text+=f'    _ = SourceJson.object (fuel + {PLAN.need-2-i}) (SourceJson.white ({rest})) momentMetadataAcc{i+1:03d} :=\n'
        text+=f'      object_moment_metadata_{i:03d} fuel ({rest})\n'
    text+='\n'+mark('metadata_before_raw_binding')
    end=PLAN.fields[8].prefix_end
    text+=emit_split('moment_metadata',0,end,'momentMetadataChars')
    text+=f'''theorem momentChars00_through_metadata (fuel : Nat) :
    SourceJson.value (fuel + {PLAN.need}) momentChars00 =
      SourceJson.object (fuel + {PLAN.need-10}) (SourceJson.white (momentRest00 {end})) momentMetadataAcc009 := by
  exact (congrArg (SourceJson.value (fuel + {PLAN.need}))
    (momentRest00_zero.symm.trans moment_metadata_split)).trans
    (value_moment_metadata fuel (momentRest00 {end}))

'''
    text+=mark('metadata_complete')+foot(names+['value_moment_metadata','moment_metadata_prefix','moment_metadata_split','momentChars00_through_metadata'])
    return save(short,text,'original root opening and nine metadata fields only',
                {'span':[0,end],'root_fuel_offset':PLAN.need,'remaining_object_offset':PLAN.need-10,
                 'field_names':[f.key.scalar for f in PLAN.fields[:-1]],'whole_parse_success_claimed':False})


def chunks_for(node, max_items=2, max_bytes=768):
    # Same boundary rule as higher's verified array_blocks.chunks_for.
    assert node.kind=='arr' and node.children
    chunks=[]; first=0; start=node.start+1
    while first<len(node.children):
        after=first
        while after<len(node.children) and after-first<max_items:
            candidate=after+1; final=candidate==len(node.children)
            if final: end=node.end
            else:
                end=node.children[candidate-1].end
                while RAW[end] in base.WHITE: end+=1
                assert RAW[end]==ord(','); end+=1
            if end-start>max_bytes and after>first: break
            after=candidate
            if end-start>=max_bytes: break
        final=after==len(node.children)
        if final: end=node.end
        else:
            end=node.children[after-1].end
            while RAW[end] in base.WHITE: end+=1
            assert RAW[end]==ord(',');end+=1
        chunks.append({'index':len(chunks),'first':first,'after':after,'start':start,'end':end,
                       'final':final,'before_offset':node.need-1-first,
                       'after_offset':node.need-1-after})
        first=after;start=end
    return chunks


def chunk_name(i): return f'momentRecordsChunk{i:03d}'
def acc_name(i): return f'momentRecordsAcc{i:03d}'
def block_short(i): return f'P2OriginalSaving19Moment00RecordsBlock{i:03d}'
def cumulative_name(i): return f'moment_records_through_block_{i:03d}'


def records_block(index, block_chunks=4):
    chunks=chunks_for(RECORDS)
    selected=chunks[index*block_chunks:(index+1)*block_chunks]
    assert selected
    imported='P2OriginalSaving19Moment00Input' if index==0 else block_short(index-1)
    text=head([imported],f'Original moment records block {index}. Small arbitrary-tail/accumulator parser equations and one exact packed-input binding.')
    names=[]
    if index==0:
        text+="def momentRecordsOpenChars : List Char := ['[']\n"
        text+=f'def {acc_name(0)} : List SourceJson := []\n\n'
        text+=emit_split('moment_records_open',RECORDS.start,RECORDS.start+1,'momentRecordsOpenChars')
        text+=f'''theorem value_moment_records_open (fuel : Nat) :
    SourceJson.value (fuel + {RECORDS.need}) (momentRest00 {RECORDS.start}) =
      SourceJson.array (fuel + {RECORDS.need-1})
        (SourceJson.white (momentRest00 {RECORDS.start+1})) [] := by
  calc
    SourceJson.value (fuel + {RECORDS.need}) (momentRest00 {RECORDS.start}) =
        SourceJson.value (fuel + {RECORDS.need})
          (momentRecordsOpenChars ++ momentRest00 {RECORDS.start+1}) :=
      congrArg (SourceJson.value (fuel + {RECORDS.need})) moment_records_open_split
    _ = SourceJson.array (fuel + {RECORDS.need-1})
        (SourceJson.white (momentRest00 {RECORDS.start+1})) [] := by rfl

'''
        names+=['moment_records_open_prefix','moment_records_open_split','value_moment_records_open']
    char_names=[]
    for c in selected:
        i=c['index']; name=chunk_name(i)
        children=RECORDS.children[c['first']:c['after']]
        assert all(n.end-n.start<=768 for n in children)
        push='acc'
        for child in children: push=f'({base.lean_node(child)}) :: ({push})'
        text+=f'def {name}Chars : List Char := {base.chars(RAW,c["start"],c["end"])}\n'
        text+=f'def {name}Push (acc : List SourceJson) : List SourceJson :=\n  {push}\n\n'
        rhs=(f'.ok (.arr (({name}Push acc).reverse), tail)' if c['final'] else
             f'SourceJson.array (fuel + {c["after_offset"]}) (SourceJson.white tail) ({name}Push acc)')
        thm=f'array_moment_records_chunk_{i:03d}'
        text+=mark(f'records_chunk_{i:03d}_before_generic')
        text+=f'''theorem {thm} (fuel : Nat) (tail : List Char) (acc : List SourceJson) :
    SourceJson.array (fuel + {c['before_offset']})
      (SourceJson.white ({name}Chars ++ tail)) acc =
      {rhs} := by rfl

'''
        text+=f'def {acc_name(i+1)} : List SourceJson := {name}Push {acc_name(i)}\n\n'
        text+=mark(f'records_chunk_{i:03d}_generic_complete')
        names.append(thm);char_names.append(name+'Chars')
    first=selected[0];last=selected[-1];final=last['final']
    block=f'momentRecordsBlock{index:03d}'
    text+=f'def {block}Chars : List Char := {append_chain(char_names)}\n'
    push='acc'
    for c in selected: push=f'{chunk_name(c["index"])}Push ({push})'
    text+=f'def {block}Push (acc : List SourceJson) : List SourceJson := {push}\n\n'
    generic=f'array_moment_records_block_{index:03d}'
    payload=append_chain(char_names,'tail')
    rhs=(f'.ok (.arr (({block}Push acc).reverse), tail)' if final else
         f'SourceJson.array (fuel + {last["after_offset"]}) (SourceJson.white tail) ({block}Push acc)')
    text+=f'''theorem {generic} (fuel : Nat) (tail : List Char) (acc : List SourceJson) :
    SourceJson.array (fuel + {first['before_offset']})
      (SourceJson.white ({block}Chars ++ tail)) acc =
      {rhs} := by
  have hinput : {block}Chars ++ tail = {payload} := by
    simp only [{block}Chars, List.append_assoc]
  calc
    SourceJson.array (fuel + {first['before_offset']}) (SourceJson.white ({block}Chars ++ tail)) acc =
        SourceJson.array (fuel + {first['before_offset']}) (SourceJson.white ({payload})) acc :=
      congrArg (fun s => SourceJson.array (fuel + {first['before_offset']}) (SourceJson.white s) acc) hinput
'''
    acc='acc'
    for j,c in enumerate(selected):
        rest=append_chain(char_names[j+1:],'tail') if j+1<len(selected) else 'tail'
        nextacc=f'{chunk_name(c["index"])}Push ({acc})'
        target=rhs if j+1==len(selected) else f'SourceJson.array (fuel + {c["after_offset"]}) (SourceJson.white ({rest})) ({nextacc})'
        text+=f'    _ = {target} := array_moment_records_chunk_{c["index"]:03d} fuel ({rest}) ({acc})\n'
        acc=nextacc
    text+='\n';names.append(generic)
    text+=mark(f'records_block_{index:03d}_before_raw_binding')
    binding=f'moment_records_block_{index:03d}'
    text+=emit_split(binding,first['start'],last['end'],block+'Chars')
    text+=mark(f'records_block_{index:03d}_after_raw_binding')
    original=f'array_moment_records_original_block_{index:03d}'
    actual_rhs=(f'.ok (.arr (({block}Push acc).reverse), momentRest00 {last["end"]})' if final else
                f'SourceJson.array (fuel + {last["after_offset"]}) (SourceJson.white (momentRest00 {last["end"]})) ({block}Push acc)')
    text+=f'''theorem {original} (fuel : Nat) (acc : List SourceJson) :
    SourceJson.array (fuel + {first['before_offset']})
      (SourceJson.white (momentRest00 {first['start']})) acc =
      {actual_rhs} := by
  exact (congrArg (fun s => SourceJson.array (fuel + {first['before_offset']}) (SourceJson.white s) acc)
      {binding}_split).trans ({generic} fuel (momentRest00 {last['end']}) acc)

'''
    names += [binding+'_prefix',binding+'_split',original]
    if final:
        text+=f'def momentRecordsArrayValue : SourceJson := .arr ({acc_name(last["index"]+1)}.reverse)\n\n'
        target=f'.ok (momentRecordsArrayValue, momentRest00 {RECORDS.end})'
    else: target=f'SourceJson.array (fuel + {last["after_offset"]}) (SourceJson.white (momentRest00 {last["end"]})) {acc_name(last["index"]+1)}'
    cumulative=cumulative_name(index)
    text+=f'''theorem {cumulative} (fuel : Nat) :
    SourceJson.array (fuel + {RECORDS.need-1})
      (SourceJson.white (momentRest00 {RECORDS.start+1})) [] =
      {target} := by
'''
    if index==0: text+=f'  exact {original} fuel {acc_name(first["index"])}\n\n'
    else: text+=f'  exact ({cumulative_name(index-1)} fuel).trans ({original} fuel {acc_name(first["index"])})\n\n'
    names.append(cumulative)
    if final:
        text+=f'''theorem value_moment_records_original (fuel : Nat) :
    SourceJson.value (fuel + {RECORDS.need}) (momentRest00 {RECORDS.start}) =
      .ok (momentRecordsArrayValue, momentRest00 {RECORDS.end}) := by
  exact (value_moment_records_open fuel).trans ({cumulative} fuel)

'''
        names.append('value_moment_records_original')
    text+=mark(f'records_block_{index:03d}_complete')+foot(names)
    return save(block_short(index),text,'small original record equations with one complete block binding',
                {'index':index,'block_chunks':block_chunks,'total_blocks':(len(chunks)+block_chunks-1)//block_chunks,
                 'selected_chunks':selected,'generic_tail_and_accumulator':True,
                 'whole_parse_success_claimed':False,'last_array_value_proved':final})


if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('target',choices=['metadata','records'])
    ap.add_argument('--block',type=int,default=0)
    args=ap.parse_args()
    result=metadata() if args.target=='metadata' else records_block(args.block)
    print(json.dumps({'module':result['module'],'source':result['source'],'planned_obligations':result['planned_obligations']},indent=2))
