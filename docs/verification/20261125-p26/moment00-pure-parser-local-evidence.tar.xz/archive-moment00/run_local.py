from pathlib import Path
import hashlib,json,os,re,signal,subprocess,sys,time
import psutil
ROOT=Path(__file__).resolve().parent
PROJECT=ROOT/'project'; OBJECTS=ROOT/'objects'
TOOLCHAIN=Path('/workspace/library-files/p34-runtime/lean-4.33.0-rc1-linux')
MODE,MODULE,TAG=sys.argv[1:]
assert MODE in {'normal','kernel'}
assert re.fullmatch(r'ImbalancedChen\.[A-Za-z0-9_]+',MODULE)
assert re.fullmatch(r'[A-Za-z0-9_-]+',TAG)
SOURCE=PROJECT/(MODULE.replace('.','/')+'.lean')
OBJECT=OBJECTS/(MODULE.replace('.','/')+'.olean')
FOLDER=ROOT/'logs'/MODULE.split('.')[-1]
FOLDER.mkdir(parents=True,exist_ok=True)
LOG=FOLDER/(MODE+'-'+TAG+'.log')
COMMAND=FOLDER/(MODE+'-'+TAG+'-command.json')
RESULT=FOLDER/(MODE+'-'+TAG+'-result.json')
assert not COMMAND.exists() and not RESULT.exists(),'No attempt-tag overwrites.'
LIMIT=4*1024**3;WALL=180

def fp(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
bootstrap=json.loads((ROOT/'BOOTSTRAP.json').read_text())
reused={x['module'] for x in bootstrap['reused_helpers']}
assert MODULE not in reused,'Never recompile or re-audit already accepted helper objects.'
for row in bootstrap['reused_helpers']:
 for category in ['source','object']:
  for side in ['original','copy']:
   assert fp(Path(row[category][side]['path']))==row[category][side]
assert not re.search(r'\b(sorry|admit|native_decide|unsafe)\b|^\s*axiom\b',SOURCE.read_text(),re.M)
deps=[];visited=set()
def visit(mod):
 if mod in visited:return
 visited.add(mod)
 p=PROJECT/(mod.replace('.','/')+'.lean')
 assert p.is_file(),mod
 for dep in re.findall(r'^import\s+(ImbalancedChen\.[A-Za-z0-9_.]+)',p.read_text(),re.M):
  assert not any(x in dep for x in ['GeometryData','CharacterCore','FirstThree','DimensionPrefix','FaceLedger']),('Geometry dependency prohibited',dep)
  visit(dep)
 if mod!=MODULE:
  o=OBJECTS/(mod.replace('.','/')+'.olean');assert o.is_file(),('Dependency not ready',mod)
  deps.append({'module':mod,'source':fp(p),'object':fp(o)})
visit(MODULE)
if MODE=='normal':
 assert not OBJECT.exists(),'Never overwrite a successful object.'
 snap=ROOT/'attempts'/MODULE.split('.')[-1]/TAG/SOURCE.name
 snap.parent.mkdir(parents=True,exist_ok=True);assert not snap.exists();snap.write_bytes(SOURCE.read_bytes())
 argv=[str(TOOLCHAIN/'bin/lean'),'-j1','-DmaxRecDepth=1000000','-DmaxHeartbeats=0','-o',str(OBJECT),str(SOURCE)]
else:
 normal=json.loads((FOLDER/('normal-'+TAG+'-result.json')).read_text())
 assert normal['status']=='succeeded' and normal['exit_code']==0
 assert normal['source']==fp(SOURCE) and normal['object']==fp(OBJECT)
 assert normal['dependencies']==deps
 argv=[str(TOOLCHAIN/'bin/leanchecker'),'--verbose',MODULE]
fixture_original=Path(bootstrap['original_input_copy']['original']['path'])
fixture=Path(bootstrap['original_input_copy']['copy']['path'])
input_before=[fp(fixture_original),fp(fixture)]
assert input_before==[bootstrap['original_input_copy']['original'],bootstrap['original_input_copy']['copy']]
env=os.environ.copy();env['PATH']=str(TOOLCHAIN/'bin')+os.pathsep+env.get('PATH','')
env['LEAN_PATH']=str(OBJECTS);env['LEAN_NUM_THREADS']='1';env['OMP_NUM_THREADS']='1'
record={'module':MODULE,'mode':MODE,'attempt':TAG,'argv':argv,'cwd':str(PROJECT),'source':fp(SOURCE),'dependencies':deps,'LEAN_PATH':env['LEAN_PATH'],'rss_limit_bytes':LIMIT,'wall_limit_seconds':WALL,'rss_sample_seconds':0.02,'threads':1,'started_unix':time.time(),'input_before':input_before,'production_FQN':'ImbalancedChen.P2OriginalSaving19Archive.momentPacked00','local_fixture_path_not_P1':True,'accepted_helpers_recompiled':False,'geometry_owners_compiled':False,'production_modified':False,'remote_jobs_submitted':False}
COMMAND.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'module':MODULE,'mode':MODE,'attempt':TAG,'source':record['source'],'log':str(LOG),'rss_limit_bytes':LIMIT,'wall_limit_seconds':WALL}),flush=True)
start=time.monotonic();peak=0;cpu_peak=0;reason=None
with LOG.open('w') as output:
 p=subprocess.Popen(argv,cwd=PROJECT,env=env,stdout=output,stderr=subprocess.STDOUT,start_new_session=True)
 proc=psutil.Process(p.pid)
 while True:
  rc=p.poll();rss=0
  try:
   ps=[proc]+proc.children(recursive=True)
   rss=sum(q.memory_info().rss for q in ps if q.is_running())
   cpu=sum(q.cpu_times().user+q.cpu_times().system for q in ps if q.is_running())
   peak=max(peak,rss);cpu_peak=max(cpu_peak,cpu)
  except(psutil.NoSuchProcess,psutil.AccessDenied):pass
  if rc is not None:break
  if rss>LIMIT:reason='memory_limit'
  elif time.monotonic()-start>WALL:reason='timeout'
  if reason:os.killpg(p.pid,signal.SIGKILL);break
  time.sleep(0.02)
 rc=p.wait()
for d in deps:
 assert fp(Path(d['source']['path']))==d['source']
 assert fp(Path(d['object']['path']))==d['object']
record.update({'status':reason or ('succeeded' if rc==0 else 'failed'),'exit_code':rc,'elapsed_seconds':time.monotonic()-start,'peak_rss_bytes':peak,'sampled_cpu_seconds':cpu_peak,'object':fp(OBJECT) if OBJECT.exists() else None,'log':fp(LOG),'input_after':[fp(fixture_original),fp(fixture)]})
assert record['input_before']==record['input_after']
text=LOG.read_text()
record['printed_axioms']=[x for x in text.splitlines() if 'depends on axioms:' in x or 'does not depend on any axioms' in x]
RESULT.write_text(json.dumps(record,indent=2)+'\n')
print(text,end='',flush=True)
print(json.dumps({k:record[k] for k in ['module','mode','attempt','status','exit_code','elapsed_seconds','peak_rss_bytes','object','log','printed_axioms']}),flush=True)
sys.exit(0 if record['status']=='succeeded' else 1)
