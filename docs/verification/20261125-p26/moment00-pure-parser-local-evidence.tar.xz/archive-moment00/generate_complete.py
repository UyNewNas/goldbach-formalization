#!/usr/bin/env python3
"""Compose certified packed-input spans into the unchanged whole SourceJson parser.
Host quotations remain candidates. No typed decoder or mathematical data test.
"""
import json
import generate_moment as g

f = g.PLAN.fields[-1]
node = f.value
assert f.separator == '}'
assert (f.prefix_start,node.start,node.end,f.prefix_end)==(348,363,28994,28997)
short = 'P2OriginalSaving19Moment00Parse'
s = g.head(['P2OriginalSaving19Moment00Metadata',g.block_short(13),
            'P2OriginalSaving19ParseFromValue00'],
           'Whole original moment00 pure SourceJson parse, assembled from checked compact-input spans. No typed decode claim.')
s += f'''def momentRecordsHeaderChars : List Char := {g.base.chars(g.RAW,f.prefix_start,node.start)}
def momentRecordsFieldKey : String := String.ofList {g.base.quote_list('records')}
def momentRecordsFieldAcc : List (String × SourceJson) :=
  (momentRecordsFieldKey, momentRecordsArrayValue) :: momentMetadataAcc009
def momentRootValue : SourceJson := .obj (momentRecordsFieldAcc.reverse)
def momentRecordsSeparatorChars : List Char := {g.base.chars(g.RAW,node.end,f.prefix_end)}
def momentTrailingChars : List Char := {g.base.chars(g.RAW,g.PLAN.end,len(g.RAW))}

'''
s += g.mark('whole_before_last_header_binding')
s += g.emit_split('moment_records_header',f.prefix_start,node.start,'momentRecordsHeaderChars')
s += g.emit_split('moment_records_separator',node.end,f.prefix_end,'momentRecordsSeparatorChars')
s += g.emit_split('moment_trailing',g.PLAN.end,len(g.RAW),'momentTrailingChars')
s += g.mark('whole_after_last_raw_bindings')
s += '''def momentRecordsAfterValue (fuel : Nat) (result : SourceJson × List Char) :
    Except String (SourceJson × List Char) :=
  match SourceJson.white result.2 with
  | '}' :: ending =>
      .ok (.obj (((momentRecordsFieldKey, result.1) :: momentMetadataAcc009).reverse), ending)
  | ',' :: ending =>
      SourceJson.object fuel (SourceJson.white ending)
        ((momentRecordsFieldKey, result.1) :: momentMetadataAcc009)
  | _ => .error "object separator missing"

theorem object_moment_records_header (fuel : Nat) (rest : List Char) :
    SourceJson.object (fuel + 95) (SourceJson.white (momentRecordsHeaderChars ++ rest)) momentMetadataAcc009 =
      (SourceJson.value (fuel + 94) rest).bind (momentRecordsAfterValue (fuel + 94)) := by rfl

theorem moment_records_after_value_separator (fuel : Nat) (tail : List Char) :
    (Except.ok (momentRecordsArrayValue, momentRecordsSeparatorChars ++ tail)).bind
      (momentRecordsAfterValue (fuel + 94)) = .ok (momentRootValue, tail) := by rfl

theorem object_moment_records_original (fuel : Nat) :
    SourceJson.object (fuel + 95) (SourceJson.white (momentRest00 348)) momentMetadataAcc009 =
      .ok (momentRootValue, momentRest00 28997) := by
  calc
    SourceJson.object (fuel + 95) (SourceJson.white (momentRest00 348)) momentMetadataAcc009 =
        SourceJson.object (fuel + 95)
          (SourceJson.white (momentRecordsHeaderChars ++ momentRest00 363)) momentMetadataAcc009 :=
      congrArg (fun rest => SourceJson.object (fuel + 95) (SourceJson.white rest) momentMetadataAcc009)
        moment_records_header_split
    _ = (SourceJson.value (fuel + 94) (momentRest00 363)).bind
        (momentRecordsAfterValue (fuel + 94)) :=
      object_moment_records_header fuel (momentRest00 363)
    _ = (Except.ok (momentRecordsArrayValue, momentRest00 28994)).bind
        (momentRecordsAfterValue (fuel + 94)) :=
      congrArg (fun result => result.bind (momentRecordsAfterValue (fuel + 94)))
        (value_moment_records_original fuel)
    _ = (Except.ok (momentRecordsArrayValue,
          momentRecordsSeparatorChars ++ momentRest00 28997)).bind
        (momentRecordsAfterValue (fuel + 94)) :=
      congrArg (fun rest => (Except.ok (momentRecordsArrayValue, rest)).bind
        (momentRecordsAfterValue (fuel + 94))) moment_records_separator_split
    _ = .ok (momentRootValue, momentRest00 28997) :=
      moment_records_after_value_separator fuel (momentRest00 28997)

theorem value_moment00_original (fuel : Nat) :
    SourceJson.value (fuel + 105) momentChars00 =
      .ok (momentRootValue, momentRest00 28997) := by
  exact (momentChars00_through_metadata fuel).trans (object_moment_records_original fuel)

theorem momentTrailing_white : SourceJson.white (momentRest00 28997) = [] := by
  calc
    SourceJson.white (momentRest00 28997) =
        SourceJson.white (momentTrailingChars ++ momentRest00 28999) :=
      congrArg SourceJson.white moment_trailing_split
    _ = SourceJson.white (momentTrailingChars ++ []) :=
      congrArg (fun rest => SourceJson.white (momentTrailingChars ++ rest)) momentRest00_end
    _ = [] := by rfl

theorem momentChars00_parseChars : SourceJson.parseChars momentChars00 = .ok momentRootValue := by
  apply SourceJson.parseChars_of_value_eq (tail := momentRest00 28997)
  · rw [momentChars00_length]
    exact value_moment00_original 28895
  · exact momentTrailing_white

theorem momentPacked00_parseChars :
    SourceJson.parseChars momentPacked00.toList = .ok momentRootValue :=
  momentChars00_parseChars

theorem momentPacked00_parse :
    SourceJson.parse (String.ofList momentPacked00.toList) = .ok momentRootValue :=
  (SourceJson.parse_ofList momentPacked00.toList).trans momentPacked00_parseChars

theorem momentPacked00_parse_success :
    (SourceJson.parse (String.ofList momentPacked00.toList)).toOption.isSome = true := by
  rw [momentPacked00_parse]
  rfl

'''
s += g.mark('whole_original_parser_complete')
s += g.foot(['moment_records_header_prefix','moment_records_header_split',
             'moment_records_separator_prefix','moment_records_separator_split',
             'moment_trailing_prefix','moment_trailing_split','object_moment_records_header',
             'moment_records_after_value_separator','object_moment_records_original',
             'value_moment00_original','momentTrailing_white','momentChars00_parseChars',
             'momentPacked00_parseChars','momentPacked00_parse','momentPacked00_parse_success'])
m=g.save(short,s,'whole-file original pure SourceJson parser; no typed decode claim',
         {'root_span':[0,g.PLAN.end],'complete_input_chars':len(g.RAW),
          'root_initial_fuel':len(g.RAW)+1,'generic_value_offset':g.PLAN.need,
          'generic_fuel_instantiation':len(g.RAW)+1-g.PLAN.need,
          'trailing_bytes':list(g.RAW[g.PLAN.end:]),'records_count':len(node.children),
          'all_root_fields_in_original_order':[x.key.scalar for x in g.PLAN.fields],
          'reader_success_target':'SourceJson.parse (String.ofList momentPacked00.toList) = .ok momentRootValue',
          'typed_decode_claimed':False,'old_Core_String_equality_claimed':False})
print(json.dumps({'module':m['module'],'source':m['source'],'planned_obligations':m['planned_obligations']},indent=2))
