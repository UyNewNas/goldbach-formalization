#!/usr/bin/env python3
"""Sequential owner-only normal then independent kernel. Stop on any failure."""
from pathlib import Path
import json,subprocess,sys
import generate_moment as gen
ROOT=Path(__file__).resolve().parent
RUN=ROOT/'run_local.py'
LOG=ROOT/'logs/record-blocks-orchestration.log'
assert not LOG.exists()

def step(module,mode):
    tag='records-v1'
    with LOG.open('ab') as f:
        p=subprocess.run([sys.executable,str(RUN),mode,module,tag],stdout=f,stderr=subprocess.STDOUT)
    short=module.split('.')[-1]
    receipt=ROOT/'logs'/short/(mode+'-'+tag+'-result.json')
    if not receipt.exists():
        print(json.dumps({'module':module,'mode':mode,'status':'missing_receipt','exit_code':p.returncode}),flush=True)
        raise SystemExit(1)
    data=json.loads(receipt.read_text())
    print(json.dumps({k:data[k] for k in ['module','mode','attempt','status','exit_code','elapsed_seconds','peak_rss_bytes']}),flush=True)
    assert p.returncode==0 and data['status']=='succeeded', 'Stop: no automatic retry or budget increase.'

step('ImbalancedChen.P2OriginalSaving19Moment00RecordsBlock000','kernel')
for i in range(1,14):
    m=gen.records_block(i)
    step(m['module'],'normal')
    step(m['module'],'kernel')
print('P26_MOMENT00_RECORDS_COMPLETE',flush=True)
