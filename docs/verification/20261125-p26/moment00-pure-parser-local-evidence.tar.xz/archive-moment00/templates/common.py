from pathlib import Path
import hashlib
import importlib.util
import json
import re
import sys

ROOT = Path(__file__).resolve().parent
FROZEN = ROOT.parent
NS = 'ImbalancedChen.P2OriginalSaving19CharacterCoreDiagnostic'
spec = importlib.util.spec_from_file_location('p26_frozen_segment_generator', FROZEN/'generate.py')
base = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = base
spec.loader.exec_module(base)
RAW = base.FIXTURE.read_bytes()
assert len(RAW) == 195134 and base.sha(RAW) == base.FIXTURE_SHA and RAW.isascii()
PLANNER = base.RawPlanner(RAW)
ROOT_NODE = PLANNER.value(0)
assert ROOT_NODE.kind == 'obj' and ROOT_NODE.end == 195132 and RAW[ROOT_NODE.end:] == b'\r\n'
FIELDS = {f.key.scalar: (i, f) for i, f in enumerate(ROOT_NODE.fields)}


def fp(p):
    p = Path(p)
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}


def write_new(p, content):
    p = Path(p)
    b = content.encode() if isinstance(content, str) else content
    if p.exists():
        assert p.read_bytes() == b, ('Frozen candidate drift', str(p))
    else:
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(b)


def json_new(p, data):
    write_new(p, json.dumps(data, indent=2) + '\n')


def registry():
    old = json.loads((FROZEN/'SOURCE_INPUTS.json').read_text())
    rows = {x['module']: x for x in old['inputs']}
    bridge_root=Path('/workspace/p26-recovery-candidates/archive-char-input')
    diag=json.loads((bridge_root/'local/COMPANION_DIAGNOSTIC.json').read_text())
    generic=json.loads((bridge_root/'local/DIAGNOSTIC.json').read_text())
    for short,receipt,imports in [
        ('P2OriginalSaving19CharInputBridge',generic,[]),
        ('P2OriginalSaving19SourceJsonCharInput',diag,
         ['ImbalancedChen.P2OriginalSaving19SourceJson','ImbalancedChen.P2OriginalSaving19CharInputBridge'])]:
        module='ImbalancedChen.'+short
        normal=next(c for c in receipt['commands'] if c['module']==module and c['stage']=='normal')
        kernel=next(c for c in receipt['commands'] if c['module']==module and c['stage']=='kernel')
        assert normal['exit_code']==kernel['exit_code']==0
        assert fp(normal['source']['path'])==normal['source']==kernel['source']
        assert fp(normal['object']['path'])==normal['object']==kernel['object']
        rows[module]={'module':module,'source':normal['source'],'object':normal['object'],
                      'project_imports':imports}
    for p in (ROOT/'owners').glob('*.json'):
        m = json.loads(p.read_text())
        rows[m['module']] = {'module': m['module'], 'source': m['source'],
                             'project_imports': m['project_imports'],
                             'object': {'path': str(ROOT/'objects'/(m['module'].replace('.', '/')+'.olean'))}}
    return rows


def save_owner(short, source, scope, plan=None):
    module = 'ImbalancedChen.' + short
    path = ROOT/'ImbalancedChen'/(short+'.lean')
    write_new(path, source)
    imports = re.findall(r'(?m)^import\s+(\S+)', source)
    project = [x for x in imports if x.startswith('ImbalancedChen.')]
    known = registry()
    closure = []
    visited = set()
    def visit(mod):
        if mod in visited:
            return
        assert mod in known, ('Unknown dependency', mod)
        visited.add(mod)
        row = known[mod]
        assert fp(row['source']['path']) == row['source']
        for dep in row['project_imports']:
            visit(dep)
        closure.append({'module': mod, 'source': row['source'],
                        'object': row['object'], 'project_imports': row['project_imports']})
    for dep in project:
        visit(dep)
    m = {'module': module, 'source': fp(path), 'project_imports': project,
         'dependency_closure': closure, 'scope': scope,
         'fixture': fp(base.FIXTURE), 'planned_obligations': plan or {},
         'normal_then_kernel': True, 'remote_jobs_submitted': False,
         'accepted_dependencies_recompiled': False,
         'host_plan_is_proof': False, 'production_modified': False}
    json_new(ROOT/'owners'/(short+'.json'), m)
    return m


def head(imports, description):
    return ''.join('import '+x+'\n' for x in imports) + f'''
/-! {description}
Exact original bytes are candidate data; the original reader equations below
are the Lean checks. No whole-file decide or replacement reader is used. -/
namespace {NS}

set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false

open ImbalancedChen.P2OriginalSaving19Archive

'''


def foot(theorems):
    return '\n'.join('#print axioms '+x for x in theorems) + '\n\nend '+NS+'\n'


def mark(label):
    return ('run_cmd do\n  let err ← IO.getStderr\n'
            f'  err.putStrLn "P26_FULL_CELL00 {label}"\n  err.flush\n\n')


def emit_split(name, start, end, chars_name):
    return f'''theorem {name}_prefix :
    (geometryChars00.drop {start}).take {end-start} = {chars_name} := by rfl

theorem {name}_split :
    geometryChars00.drop {start} = {chars_name} ++ geometryChars00.drop {end} := by
  calc
    geometryChars00.drop {start} =
        (geometryChars00.drop {start}).take {end-start} ++ (geometryChars00.drop {start}).drop {end-start} :=
      (List.take_append_drop {end-start} (geometryChars00.drop {start})).symm
    _ = {chars_name} ++ (geometryChars00.drop {start}).drop {end-start} :=
      congrArg (fun p => p ++ (geometryChars00.drop {start}).drop {end-start}) {name}_prefix
    _ = {chars_name} ++ geometryChars00.drop {end} := by rw [List.drop_drop]

'''


def bootstrap():
    index, f = FIELDS['normal_rank']
    assert index == 4 and (f.prefix_start, f.prefix_end) == (359, 380)
    b = 1 + max(f.key.quoted_need, f.value.need)
    actual = len(RAW) - index
    name = 'P2OriginalSaving19NormalRankPrefix00'
    text = head(['ImbalancedChen.P2OriginalSaving19PositiveBalanceSegments00'],
                'The fifth original field, normal_rank; reuse all four accepted prior fields.')
    text += f'''def normalRankPrefixChars00 : List Char := {base.chars(RAW, f.prefix_start, f.prefix_end)}
def normalRankKey00 : String := String.ofList {base.quote_list(f.key.scalar)}
def normalRankValue00 : SourceJson := {base.lean_node(f.value)}
def normalRankAcc00 : List (String × SourceJson) :=
  (normalRankKey00, normalRankValue00) :: positiveBalanceAcc00

'''
    text += mark('normal_rank_before_binding')
    text += emit_split('geometryChars00_normal_rank', f.prefix_start, f.prefix_end, 'normalRankPrefixChars00')
    text += f'''theorem object_normal_rank_prefix (fuel : Nat) (tail : List Char) :
    SourceJson.object (fuel + {b}) (SourceJson.white (normalRankPrefixChars00 ++ tail)) positiveBalanceAcc00 =
      SourceJson.object (fuel + {b-1}) (SourceJson.white tail) normalRankAcc00 := by rfl

theorem geometryChars00_normal_rank_step :
    SourceJson.object {actual} (SourceJson.white (geometryChars00.drop {f.prefix_start})) positiveBalanceAcc00 =
      SourceJson.object {actual-1} (SourceJson.white (geometryChars00.drop {f.prefix_end})) normalRankAcc00 := by
  exact (congrArg (fun s => SourceJson.object {actual} (SourceJson.white s) positiveBalanceAcc00)
      geometryChars00_normal_rank_split).trans
    (object_normal_rank_prefix {actual-b} (geometryChars00.drop {f.prefix_end}))

theorem geometryChars00_through_normal_rank :
    SourceJson.value {len(RAW)+1} geometryChars00 =
      SourceJson.object {actual-1} (SourceJson.white (geometryChars00.drop {f.prefix_end})) normalRankAcc00 := by
  exact geometryChars00_through_positive_balance.trans geometryChars00_normal_rank_step

'''
    text += mark('normal_rank_complete')
    text += foot(['geometryChars00_normal_rank_prefix', 'geometryChars00_normal_rank_split',
                  'object_normal_rank_prefix', 'geometryChars00_normal_rank_step',
                  'geometryChars00_through_normal_rank'])
    return save_owner(name, text, 'fifth original field state transition only',
                      {'field': f.plan(), 'actual_fuels': [actual, actual-1]})


if __name__ == '__main__':
    rootplan = {'fixture': fp(base.FIXTURE), 'root_node': ROOT_NODE.plan(),
                'tail_span': [ROOT_NODE.end, len(RAW)],
                'tail_ascii_escaped': RAW[ROOT_NODE.end:].decode('ascii'),
                'host_candidate_only': True, 'whole_parse_success_claimed': False}
    json_new(ROOT/'RAW_PLAN.json', rootplan)
    print(json.dumps(bootstrap(), indent=2))
