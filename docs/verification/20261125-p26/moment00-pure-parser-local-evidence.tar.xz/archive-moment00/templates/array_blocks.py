#!/usr/bin/env python3
"""Small original-array transitions, bound to exact slices of the original input."""
import argparse
import json
from common import *

CONFIG = {
    'active8_enumeration': ('Active8', 'active8', 'P2OriginalSaving19NormalRankPrefix00',
                            'normalRankAcc00', 'geometryChars00_through_normal_rank'),
    'vertices': ('Vertices', 'vertices', 'P2OriginalSaving19Active8Field00',
                 'active8FieldAcc00', 'geometryChars00_through_active8'),
    'vertex_values': ('VertexValues', 'vertexValues', 'P2OriginalSaving19VerticesField00',
                      'verticesFieldAcc00', 'geometryChars00_through_vertices'),
    'all_original_constraint_minima': ('ConstraintMinima', 'constraintMinima', 'P2OriginalSaving19VertexValuesField00',
                                       'vertexValuesFieldAcc00', 'geometryChars00_through_vertexValues'),
    'facet_vertices': ('FacetVertices', 'facetVertices', 'P2OriginalSaving19ConstraintMinimaField00',
                       'constraintMinimaFieldAcc00', 'geometryChars00_through_constraintMinima'),
    'face_ledger': ('FaceLedger', 'faceLedger', 'P2OriginalSaving19FacetVerticesField00',
                    'facetVerticesFieldAcc00', 'geometryChars00_through_facetVertices'),
    'simplices': ('Simplices', 'simplices', 'P2OriginalSaving19FaceLedgerField00',
                  'faceLedgerFieldAcc00', 'geometryChars00_through_faceLedger'),
}


def chunks_for(node, max_items=2, max_bytes=768):
    assert node.kind == 'arr' and node.children
    chunks=[]; first=0; start=node.start+1
    while first < len(node.children):
        after=first
        while after < len(node.children) and after-first < max_items:
            candidate=after+1
            final=candidate==len(node.children)
            if final:
                end=node.end
            else:
                end=node.children[candidate-1].end
                while RAW[end] in base.WHITE:end+=1
                assert RAW[end]==ord(',');end+=1
            if end-start>max_bytes and after>first:break
            after=candidate
            if end-start>=max_bytes:break
        final=after==len(node.children)
        if final:end=node.end
        else:
            end=node.children[after-1].end
            while RAW[end] in base.WHITE:end+=1
            assert RAW[end]==ord(',');end+=1
        chunks.append({'index':len(chunks),'first':first,'after':after,'start':start,'end':end,
                       'final':final,'before_offset':node.need-1-first,
                       'after_offset':node.need-1-after,
                       'inline_bytes':end-start,
                       'oversize_child':end-start>max_bytes})
        first=after;start=end
    return chunks


def block_short(tag,index):
    return f'P2OriginalSaving19{tag}ArrayBlock{index:03d}00'


def acc_name(prefix,chunk):
    return f'{prefix}ArrayAcc{chunk:03d}00'


def chunk_name(prefix,chunk):
    return f'{prefix}Chunk{chunk:03d}'


def cumulative_name(prefix,block):
    return f'{prefix}_array_through_block_{block:03d}'


def generate_block(key, index, block_chunks=4, max_items=2, max_bytes=768):
    # Previously accepted owners retain their exact original source bytes.
    # Only not-yet-generated blocks use one original-input binding per block.
    first_single_bind={'all_original_constraint_minima':2,'facet_vertices':0,
                       'face_ledger':0,'simplices':0}
    if key in first_single_bind and index>=first_single_bind[key]:
        from block_single_bind import generate
        return generate(key,index,block_chunks,max_items,max_bytes)
    tag,prefix,prior_module,prior_acc,prior_whole=CONFIG[key]
    fieldindex,f=FIELDS[key];node=f.value
    chunks=chunks_for(node,max_items,max_bytes)
    selected=chunks[index*block_chunks:(index+1)*block_chunks]
    assert selected,('No such block',key,index)
    large_nodes=[node.children[c['first']] for c in selected if c['oversize_child']]
    if large_nodes:
        from fragments import ref, array_segment
        assert all(ref(n)['module'] in registry() for n in large_nodes), 'Generate and check child certificates first.'
    total_blocks=(len(chunks)+block_chunks-1)//block_chunks
    short=block_short(tag,index)
    imported=prior_module if index==0 else block_short(tag,index-1)
    imports=['ImbalancedChen.'+imported]
    if large_nodes:
        imports += [ref(n)['module'] for n in large_nodes]
    source=head(imports,
                f'Original {key} array block {index}/{total_blocks-1}; small chunks with arbitrary tails and accumulators.')
    names=[]
    if index==0:
        source+=f"def {prefix}OpenChars00 : List Char := ['[']\n"
        source+=f'def {acc_name(prefix,0)} : List SourceJson := []\n\n'
        openbase=f'geometryChars00_{prefix}_open'
        source+=emit_split(openbase,node.start,node.start+1,f'{prefix}OpenChars00')
        source+=f'''theorem value_{prefix}_open (fuel : Nat) :
    SourceJson.value (fuel + {node.need}) (geometryChars00.drop {node.start}) =
      SourceJson.array (fuel + {node.need-1})
        (SourceJson.white (geometryChars00.drop {node.start+1})) [] := by
  calc
    SourceJson.value (fuel + {node.need}) (geometryChars00.drop {node.start}) =
        SourceJson.value (fuel + {node.need})
          ({prefix}OpenChars00 ++ geometryChars00.drop {node.start+1}) :=
      congrArg (SourceJson.value (fuel + {node.need})) {openbase}_split
    _ = SourceJson.array (fuel + {node.need-1})
        (SourceJson.white (geometryChars00.drop {node.start+1})) [] := by rfl

'''
        names += [openbase+'_prefix',openbase+'_split',f'value_{prefix}_open']
    for c in selected:
        idx=c['index'];name=chunk_name(prefix,idx)
        children=node.children[c['first']:c['after']]
        generic=f'array_{prefix}_chunk_{idx:03d}'
        if c['oversize_child']:
            emitted,extra=array_segment(name,generic,c['start'],c['end'],children,
                                         c['before_offset'],c['after_offset'],c['final'])
            source+=emitted
            names+=extra
        else:
            push='acc'
            for child in children:
                push=f'({base.lean_node(child)}) :: ({push})'
            source+=f'def {name}Chars00 : List Char := {base.chars(RAW,c["start"],c["end"])}\n'
            source+=f'def {name}Push00 (acc : List SourceJson) : List SourceJson :=\n  {push}\n'
        source+=f'def {acc_name(prefix,idx+1)} : List SourceJson := {name}Push00 {acc_name(prefix,idx)}\n\n'
        source+=mark(f'{prefix}_chunk_{idx:03d}_before')
        basename=f'geometryChars00_{prefix}_chunk_{idx:03d}'
        source+=emit_split(basename,c['start'],c['end'],name+'Chars00')
        if c['final']:
            rhs=f'.ok (.arr (({name}Push00 acc).reverse), tail)'
            actualrhs=f'.ok (.arr (({name}Push00 acc).reverse), geometryChars00.drop {c["end"]})'
        else:
            rhs=(f'SourceJson.array (fuel + {c["after_offset"]}) (SourceJson.white tail)\n'
                 f'        ({name}Push00 acc)')
            actualrhs=(f'SourceJson.array (fuel + {c["after_offset"]})\n'
                       f'        (SourceJson.white (geometryChars00.drop {c["end"]})) ({name}Push00 acc)')
        actual=f'array_{prefix}_original_chunk_{idx:03d}'
        if not c['oversize_child']:
            source+=f'''theorem {generic} (fuel : Nat) (tail : List Char) (acc : List SourceJson) :
    SourceJson.array (fuel + {c['before_offset']})
      (SourceJson.white ({name}Chars00 ++ tail)) acc =
      {rhs} := by rfl

'''
        source+=f'''theorem {actual} (fuel : Nat) (acc : List SourceJson) :
    SourceJson.array (fuel + {c['before_offset']})
      (SourceJson.white (geometryChars00.drop {c['start']})) acc =
      {actualrhs} := by
  exact (congrArg (fun s => SourceJson.array (fuel + {c['before_offset']}) (SourceJson.white s) acc)
      {basename}_split).trans
    ({generic} fuel (geometryChars00.drop {c['end']}) acc)

'''
        source+=mark(f'{prefix}_chunk_{idx:03d}_complete')
        names += [basename+'_prefix',basename+'_split',generic,actual]
    final=selected[-1]['final'];last=selected[-1]
    if final:
        source+=f'def {prefix}ArrayValue00 : SourceJson := .arr ({acc_name(prefix,last["index"]+1)}.reverse)\n\n'
        target=f'.ok ({prefix}ArrayValue00, geometryChars00.drop {node.end})'
    else:
        target=(f'SourceJson.array (fuel + {last["after_offset"]})\n'
                f'        (SourceJson.white (geometryChars00.drop {last["end"]})) {acc_name(prefix,last["index"]+1)}')
    cum=cumulative_name(prefix,index)
    source+=f'''theorem {cum} (fuel : Nat) :
    SourceJson.array (fuel + {node.need-1})
      (SourceJson.white (geometryChars00.drop {node.start+1})) [] =
      {target} := by
  calc
'''
    if index>0:
        prev=chunks[index*block_chunks-1]
        source+=f'''    SourceJson.array (fuel + {node.need-1})
        (SourceJson.white (geometryChars00.drop {node.start+1})) [] =
      SourceJson.array (fuel + {prev['after_offset']})
        (SourceJson.white (geometryChars00.drop {prev['end']})) {acc_name(prefix,prev['index']+1)} :=
      {cumulative_name(prefix,index-1)} fuel
'''
    for j,c in enumerate(selected):
        start_expr=(f'SourceJson.array (fuel + {node.need-1})\n'
                    f'        (SourceJson.white (geometryChars00.drop {node.start+1})) []') if index==0 and j==0 else '_'
        if c['final']:
            rhs=f'.ok ({prefix}ArrayValue00, geometryChars00.drop {node.end})'
        else:
            rhs=(f'SourceJson.array (fuel + {c["after_offset"]})\n'
                 f'        (SourceJson.white (geometryChars00.drop {c["end"]})) {acc_name(prefix,c["index"]+1)}')
        source+=f'    {start_expr} =\n      {rhs} :=\n'
        source+=f'      array_{prefix}_original_chunk_{c["index"]:03d} fuel {acc_name(prefix,c["index"])}\n'
    source+='\n'
    names.append(cum)
    if final:
        source+=f'''theorem value_{prefix}_original (fuel : Nat) :
    SourceJson.value (fuel + {node.need}) (geometryChars00.drop {node.start}) =
      .ok ({prefix}ArrayValue00, geometryChars00.drop {node.end}) := by
  exact (value_{prefix}_open fuel).trans ({cum} fuel)

'''
        names.append(f'value_{prefix}_original')
    source+=mark(f'{prefix}_block_{index:03d}_complete')+foot(names)
    if key!='active8_enumeration':
        source=source.replace('\ndef ', '\nnoncomputable def ')
    return save_owner(short,source,f'{key} original array block {index}; no whole parse claim',
        {'key':key,'block':index,'total_blocks':total_blocks,'array_span':[node.start,node.end],
         'selected_chunks':selected,'array_value_offset':node.need,'final_array_value_proved':final,
         'prior_input_objects_unchanged':True,'whole_parse_success_claimed':False})


def generate_field(key,block_chunks=4,max_items=2,max_bytes=768):
    tag,prefix,prior_module,prior_acc,prior_whole=CONFIG[key]
    fieldindex,f=FIELDS[key];node=f.value
    chunks=chunks_for(node,max_items,max_bytes)
    lastblock=(len(chunks)-1)//block_chunks
    short=f'P2OriginalSaving19{tag}Field00'
    source=head(['ImbalancedChen.'+block_short(tag,lastblock)],
                f'Compose the complete original {key} array certificate into its original parent object.')
    b=1+max(f.key.quoted_need,node.need)
    actual=len(RAW)-fieldindex
    source+=f'def {prefix}HeaderChars00 : List Char := {base.chars(RAW,f.prefix_start,node.start)}\n'
    source+=f'def {prefix}FieldKey00 : String := String.ofList {base.quote_list(key)}\n'
    source+=f'''def {prefix}FieldAcc00 : List (String × SourceJson) :=
  ({prefix}FieldKey00, {prefix}ArrayValue00) :: {prior_acc}
def {prefix}SeparatorChars00 : List Char := {base.chars(RAW,node.end,f.prefix_end)}

'''
    source+=mark(prefix+'_field_after_data')
    assert f.separator==','
    source+=emit_split(f'geometryChars00_{prefix}_header',f.prefix_start,node.start,prefix+'HeaderChars00')
    source+=emit_split(f'geometryChars00_{prefix}_separator',node.end,f.prefix_end,prefix+'SeparatorChars00')
    source+=mark(prefix+'_field_after_raw_bindings')
    source+=f'''def {prefix}AfterValue00 (fuel : Nat) (result : SourceJson × List Char) :
    Except String (SourceJson × List Char) :=
  match SourceJson.white result.2 with
  | '}}' :: ending =>
      .ok (.obj ((({prefix}FieldKey00, result.1) :: {prior_acc}).reverse), ending)
  | ',' :: ending =>
      SourceJson.object fuel (SourceJson.white ending)
        (({prefix}FieldKey00, result.1) :: {prior_acc})
  | _ => .error "object separator missing"

theorem object_{prefix}_header (fuel : Nat) (rest : List Char) :
    SourceJson.object (fuel + {b}) (SourceJson.white ({prefix}HeaderChars00 ++ rest)) {prior_acc} =
      (SourceJson.value (fuel + {b-1}) rest).bind ({prefix}AfterValue00 (fuel + {b-1})) := by rfl

theorem {prefix}_after_value_separator (fuel : Nat) (tail : List Char) :
    (Except.ok ({prefix}ArrayValue00, {prefix}SeparatorChars00 ++ tail)).bind
      ({prefix}AfterValue00 (fuel + {b-1})) =
      SourceJson.object (fuel + {b-1}) (SourceJson.white tail) {prefix}FieldAcc00 := by rfl

'''
    source+=mark(prefix+'_field_after_generic_continuation')
    source+=f'''
theorem object_{prefix}_original (fuel : Nat) :
    SourceJson.object (fuel + {b}) (SourceJson.white (geometryChars00.drop {f.prefix_start})) {prior_acc} =
      SourceJson.object (fuel + {b-1}) (SourceJson.white (geometryChars00.drop {f.prefix_end})) {prefix}FieldAcc00 := by
  calc
    SourceJson.object (fuel + {b}) (SourceJson.white (geometryChars00.drop {f.prefix_start})) {prior_acc} =
        SourceJson.object (fuel + {b})
          (SourceJson.white ({prefix}HeaderChars00 ++ geometryChars00.drop {node.start})) {prior_acc} :=
      congrArg (fun s => SourceJson.object (fuel + {b}) (SourceJson.white s) {prior_acc})
        geometryChars00_{prefix}_header_split
    _ = (SourceJson.value (fuel + {b-1}) (geometryChars00.drop {node.start})).bind
        ({prefix}AfterValue00 (fuel + {b-1})) :=
      object_{prefix}_header fuel (geometryChars00.drop {node.start})
    _ = (Except.ok ({prefix}ArrayValue00, geometryChars00.drop {node.end})).bind
        ({prefix}AfterValue00 (fuel + {b-1})) :=
      congrArg (fun result => result.bind ({prefix}AfterValue00 (fuel + {b-1})))
        (value_{prefix}_original (fuel + {b-1-node.need}))
    _ = (Except.ok ({prefix}ArrayValue00,
          {prefix}SeparatorChars00 ++ geometryChars00.drop {f.prefix_end})).bind
        ({prefix}AfterValue00 (fuel + {b-1})) :=
      congrArg (fun rest => (Except.ok ({prefix}ArrayValue00, rest)).bind
        ({prefix}AfterValue00 (fuel + {b-1}))) geometryChars00_{prefix}_separator_split
    _ = SourceJson.object (fuel + {b-1})
        (SourceJson.white (geometryChars00.drop {f.prefix_end})) {prefix}FieldAcc00 :=
      {prefix}_after_value_separator fuel (geometryChars00.drop {f.prefix_end})

theorem geometryChars00_through_{prefix} :
    SourceJson.value {len(RAW)+1} geometryChars00 =
      SourceJson.object {actual-1} (SourceJson.white (geometryChars00.drop {f.prefix_end})) {prefix}FieldAcc00 := by
  exact {prior_whole}.trans (object_{prefix}_original {actual-b})

'''
    source+=mark(prefix+'_field_complete')+foot([
        f'geometryChars00_{prefix}_header_prefix',f'geometryChars00_{prefix}_header_split',
        f'geometryChars00_{prefix}_separator_prefix',f'geometryChars00_{prefix}_separator_split',
        f'object_{prefix}_header',f'{prefix}_after_value_separator',
        f'object_{prefix}_original',f'geometryChars00_through_{prefix}'])
    if key!='active8_enumeration':
        source=source.replace('\ndef ', '\nnoncomputable def ')
    return save_owner(short,source,f'complete original {key} field; next original object state',
                      {'field':f.plan(),'actual_object_fuels':[actual,actual-1],
                       'whole_parse_success_claimed':False})


if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('key',choices=list(CONFIG))
    ap.add_argument('--block',type=int)
    ap.add_argument('--field',action='store_true')
    ap.add_argument('--block-chunks',type=int,default=4)
    ap.add_argument('--max-items',type=int,default=2)
    ap.add_argument('--max-bytes',type=int,default=768)
    args=ap.parse_args()
    assert args.field != (args.block is not None), 'Select one block or the field wrapper.'
    if args.field:m=generate_field(args.key,args.block_chunks,args.max_items,args.max_bytes)
    else:m=generate_block(args.key,args.block,args.block_chunks,args.max_items,args.max_bytes)
    print(json.dumps({'module':m['module'],'source':m['source'],'plan':m['planned_obligations']},indent=2))
