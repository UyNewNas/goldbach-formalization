#!/usr/bin/env python3
"""One exact original-input binding per block, with opaque generic chunk composition."""
from common import *
from fragments import ref, array_segment, append_chain


def generate(key,index,block_chunks=4,max_items=2,max_bytes=768):
    from array_blocks import CONFIG,chunks_for,block_short,acc_name,chunk_name,cumulative_name
    tag,prefix,prior_module,prior_acc,prior_whole=CONFIG[key]
    _,f=FIELDS[key];node=f.value
    chunks=chunks_for(node,max_items,max_bytes)
    selected=chunks[index*block_chunks:(index+1)*block_chunks]
    assert selected
    count=(len(chunks)+block_chunks-1)//block_chunks
    imported=prior_module if index==0 else block_short(tag,index-1)
    large_nodes=[node.children[c['first']] for c in selected if c['oversize_child']]
    assert all(ref(n)['module'] in registry() for n in large_nodes)
    source=head(['ImbalancedChen.'+imported]+[ref(n)['module'] for n in large_nodes],
                f'Original {key} block {index}/{count-1}. Generic small chunks are composed first; '
                'exact original bytes are then bound once for the complete block, retaining the original arbitrary tail and accumulator semantics.')
    names=[]
    if index==0:
        source+=f"def {prefix}OpenChars00 : List Char := ['[']\n"
        source+=f'def {acc_name(prefix,0)} : List SourceJson := []\n\n'
        openbase=f'geometryChars00_{prefix}_open'
        source+=emit_split(openbase,node.start,node.start+1,prefix+'OpenChars00')
        source+=f'''theorem value_{prefix}_open (fuel : Nat) :
    SourceJson.value (fuel + {node.need}) (geometryChars00.drop {node.start}) =
      SourceJson.array (fuel + {node.need-1})
        (SourceJson.white (geometryChars00.drop {node.start+1})) [] := by
  calc
    SourceJson.value (fuel + {node.need}) (geometryChars00.drop {node.start}) =
        SourceJson.value (fuel + {node.need})
          ({prefix}OpenChars00 ++ geometryChars00.drop {node.start+1}) :=
      congrArg (SourceJson.value (fuel + {node.need})) {openbase}_split
    _ = SourceJson.array (fuel + {node.need-1})
        (SourceJson.white (geometryChars00.drop {node.start+1})) [] := by rfl

'''
        names += [openbase+'_prefix',openbase+'_split',f'value_{prefix}_open']
    chars_names=[]
    for c in selected:
        i=c['index'];name=chunk_name(prefix,i);generic=f'array_{prefix}_chunk_{i:03d}'
        source+=mark(f'{prefix}_chunk_{i:03d}_before_generic')
        emitted,extra=array_segment(name,generic,c['start'],c['end'],
            node.children[c['first']:c['after']],c['before_offset'],c['after_offset'],c['final'])
        source+=emitted
        source+=f'def {acc_name(prefix,i+1)} : List SourceJson := {name}Push00 {acc_name(prefix,i)}\n\n'
        source+=mark(f'{prefix}_chunk_{i:03d}_generic_complete')
        names+=extra+[generic];chars_names.append(name+'Chars00')
    first=selected[0];last=selected[-1];final=last['final']
    block=f'{prefix}Block{index:03d}'
    source+=f'def {block}Chars00 : List Char := {append_chain(chars_names)}\n'
    push='acc'
    for c in selected:push=f'{chunk_name(prefix,c["index"])}Push00 ({push})'
    source+=f'def {block}Push00 (acc : List SourceJson) : List SourceJson := {push}\n\n'
    generic=f'array_{prefix}_block_{index:03d}'
    payload=append_chain(chars_names,'tail')
    rhs=(f'.ok (.arr (({block}Push00 acc).reverse), tail)' if final else
         f'SourceJson.array (fuel + {last["after_offset"]}) (SourceJson.white tail) ({block}Push00 acc)')
    source+=f'''theorem {generic} (fuel : Nat) (tail : List Char) (acc : List SourceJson) :
    SourceJson.array (fuel + {first['before_offset']})
      (SourceJson.white ({block}Chars00 ++ tail)) acc =
      {rhs} := by
  have hinput : {block}Chars00 ++ tail = {payload} := by
    simp only [{block}Chars00, List.append_assoc]
  calc
    SourceJson.array (fuel + {first['before_offset']})
        (SourceJson.white ({block}Chars00 ++ tail)) acc =
      SourceJson.array (fuel + {first['before_offset']}) (SourceJson.white ({payload})) acc :=
      congrArg (fun s => SourceJson.array (fuel + {first['before_offset']}) (SourceJson.white s) acc) hinput
'''
    acc_expr='acc'
    for j,c in enumerate(selected):
        rest=append_chain(chars_names[j+1:],'tail') if j+1<len(selected) else 'tail'
        next_acc=f'{chunk_name(prefix,c["index"])}Push00 ({acc_expr})'
        if j+1==len(selected):target=rhs
        else:target=f'SourceJson.array (fuel + {c["after_offset"]}) (SourceJson.white ({rest})) ({next_acc})'
        source+=f'    _ = {target} := array_{prefix}_chunk_{c["index"]:03d} fuel ({rest}) ({acc_expr})\n'
        acc_expr=next_acc
    source+='\n';names.append(generic)
    source+=mark(f'{prefix}_block_{index:03d}_before_single_binding')
    binding=f'geometryChars00_{prefix}_block_{index:03d}'
    source+=emit_split(binding,first['start'],last['end'],block+'Chars00')
    source+=mark(f'{prefix}_block_{index:03d}_after_single_binding')
    original=f'array_{prefix}_original_block_{index:03d}'
    actual_rhs=(f'.ok (.arr (({block}Push00 acc).reverse), geometryChars00.drop {last["end"]})' if final else
                f'SourceJson.array (fuel + {last["after_offset"]})\n'
                f'        (SourceJson.white (geometryChars00.drop {last["end"]})) ({block}Push00 acc)')
    source+=f'''theorem {original} (fuel : Nat) (acc : List SourceJson) :
    SourceJson.array (fuel + {first['before_offset']})
      (SourceJson.white (geometryChars00.drop {first['start']})) acc =
      {actual_rhs} := by
  exact (congrArg (fun s => SourceJson.array (fuel + {first['before_offset']}) (SourceJson.white s) acc)
      {binding}_split).trans ({generic} fuel (geometryChars00.drop {last['end']}) acc)

'''
    names += [binding+'_prefix',binding+'_split',original]
    if final:
        source+=f'def {prefix}ArrayValue00 : SourceJson := .arr ({acc_name(prefix,last["index"]+1)}.reverse)\n\n'
        target=f'.ok ({prefix}ArrayValue00, geometryChars00.drop {node.end})'
    else:
        target=(f'SourceJson.array (fuel + {last["after_offset"]})\n'
                f'        (SourceJson.white (geometryChars00.drop {last["end"]})) {acc_name(prefix,last["index"]+1)}')
    cum=cumulative_name(prefix,index)
    source+=f'''theorem {cum} (fuel : Nat) :
    SourceJson.array (fuel + {node.need-1})
      (SourceJson.white (geometryChars00.drop {node.start+1})) [] =
      {target} := by
'''
    if index==0:source+=f'  exact {original} fuel {acc_name(prefix,first["index"])}\n\n'
    else:
        source+=f'  exact ({cumulative_name(prefix,index-1)} fuel).trans\n'
        source+=f'    ({original} fuel {acc_name(prefix,first["index"])})\n\n'
    names.append(cum)
    if final:
        source+=f'''theorem value_{prefix}_original (fuel : Nat) :
    SourceJson.value (fuel + {node.need}) (geometryChars00.drop {node.start}) =
      .ok ({prefix}ArrayValue00, geometryChars00.drop {node.end}) := by
  exact (value_{prefix}_open fuel).trans ({cum} fuel)

'''
        names.append(f'value_{prefix}_original')
    source+=mark(f'{prefix}_block_{index:03d}_complete')+foot(names)
    source=source.replace('\ndef ', '\nnoncomputable def ')
    return save_owner(block_short(tag,index),source,f'{key} block {index}, one original-input binding and opaque generic chunk composition',
        {'key':key,'block':index,'total_blocks':count,'array_span':[node.start,node.end],
         'selected_chunks':selected,'array_value_offset':node.need,'final_array_value_proved':final,
         'input_binding_strategy':'one take/drop proof for the entire block',
         'generic_chunks_keep_arbitrary_tail_and_accumulator':True,
         'prior_input_objects_unchanged':True,'whole_parse_success_claimed':False})
