from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parent
PROJECT=ROOT/'project'; OBJECTS=ROOT/'objects'
V4=Path('/workspace/p26-recovery-candidates/archive-v4')
PACK=Path('/workspace/p26-recovery-candidates/archive-packed-chars')
BRIDGE=Path('/workspace/p26-recovery-candidates/archive-char-input')
GEN=Path('/workspace/p26-recovery-candidates/archive-segment-generator/full-cell00')
ORIGINAL=Path('/workspace/p26-original-inputs/eighth-third-moment-refinement-20261009-a23-low-00.witness.json')
FIXTURE=ROOT/'goldbach-research'/ORIGINAL.name

def fp(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def copy_exact(a,b,expected):
 before=fp(a);assert before['sha256']==expected
 b.parent.mkdir(parents=True,exist_ok=True)
 if b.exists():assert b.read_bytes()==a.read_bytes()
 else:b.write_bytes(a.read_bytes())
 after=fp(b);assert after['bytes']==before['bytes'] and after['sha256']==before['sha256']
 assert fp(a)==before
 return {'original':before,'copy':after}
for d in ['project/ImbalancedChen','objects/ImbalancedChen','logs','attempts','owners','templates']:
 (ROOT/d).mkdir(parents=True,exist_ok=True)
rawcopy=copy_exact(ORIGINAL,FIXTURE,'d88e9d02334dfa840f81c0e2be8e97d559978ac3848fdea13990deced9a65052')
assert rawcopy['original']['bytes']==28999
assert (PROJECT/'../goldbach-research'/ORIGINAL.name).resolve()==FIXTURE.resolve()
helpers=[
 ('P2OriginalSaving19PackedChars',V4/'ImbalancedChen/P2OriginalSaving19PackedChars.lean',PACK/'objects/ImbalancedChen/P2OriginalSaving19PackedChars.olean','cf65b9e0f3b0a4735cdb962d9b317ed29e8f39c8507647bab04f7e48800ad001','b8a8059126905b41a26a67b69ef2d03242fa35c6da9681d505d176600424e006'),
 ('P2OriginalSaving19SourceJson',V4/'ImbalancedChen/P2OriginalSaving19SourceJson.lean',BRIDGE/'local/lib/lean/ImbalancedChen/P2OriginalSaving19SourceJson.olean','ae38e3ed3f11d8bc3350b9d35d1fed164a4494210ed993b2b99e8cd709f93424','ec7361a2e508c323bf2dfa5f384d31a4bd71ffd47e032bfbf428c13bc1c2e467'),
 ('P2OriginalSaving19CharInputBridge',V4/'ImbalancedChen/P2OriginalSaving19CharInputBridge.lean',BRIDGE/'local/lib/lean/ImbalancedChen/P2OriginalSaving19CharInputBridge.olean','18d5e23b30fd7333bb2b3a80c4bedae0ff4f8e190b45833c390a6cbffc1bba21','aec6d507428f15642aaf6cb0767dae7b5ec7965325e0d1c2f2166f66bfc12e70'),
 ('P2OriginalSaving19SourceJsonCharInput',V4/'ImbalancedChen/P2OriginalSaving19SourceJsonCharInput.lean',BRIDGE/'local/lib/lean/ImbalancedChen/P2OriginalSaving19SourceJsonCharInput.olean','64c20a58a005b83aec402c9b1e65e570fdcbe35fb9530be1220596679da97396','2c823b172c17ff01681210825ff1caaab371660331e90f5fd29eb17b01797150'),
 ('P2OriginalSaving19ParseFromValue00',GEN/'ImbalancedChen/P2OriginalSaving19ParseFromValue00.lean',GEN/'objects/ImbalancedChen/P2OriginalSaving19ParseFromValue00.olean','5b29d4b823dc33116e5e06b74d77ed85342b4460959ff25af0bc2708354c2f48','9c03d34129d436b5ef2ff4d9557d638e504760778b83e4001fba273803416828')]
reused=[]
for name,source,obj,s,o in helpers:
 source_copy=copy_exact(source,PROJECT/'ImbalancedChen'/(name+'.lean'),s)
 object_copy=copy_exact(obj,OBJECTS/'ImbalancedChen'/(name+'.olean'),o)
 siblings=[]
 for extra in sorted(obj.parent.glob(obj.name+'.*')):
  if extra.is_file():siblings.append(copy_exact(extra,OBJECTS/'ImbalancedChen'/extra.name,fp(extra)['sha256']))
 reused.append({'module':'ImbalancedChen.'+name,'source':source_copy,'object':object_copy,'extra_object_siblings':siblings,'recompiled':False})
new=[]
for name,expected in [
 ('P2OriginalSaving19ArchivePackedLoader','5f1ff6c68faba7bdbde44b7bb7f7aac57c1c1d71563b781ee25a5ab050717f27'),
 ('P2OriginalSaving19ArchiveMomentData00','')]:
 source=V4/'ImbalancedChen'/(name+'.lean')
 if not expected:
  m=json.loads((V4/'SOURCE_MANIFEST.json').read_text())
  expected=next(x['sha256'] for x in m['candidate_files'] if x['module']=='ImbalancedChen.'+name)
 new.append({'module':'ImbalancedChen.'+name,'source':copy_exact(source,PROJECT/'ImbalancedChen'/(name+'.lean'),expected),'v4_bytes_unchanged':True,'new_local_compilation_required':True})
report={'schema':'saving19_moment00_compact_local_binding_v1','original_input_copy':rawcopy,'raw_relative_path':'../goldbach-research/'+ORIGINAL.name,'local_working_directory':str(PROJECT),'local_resolved_input_path':str(FIXTURE.resolve()),'P1_resolved_path_not_claimed':True,'production_FQN':'ImbalancedChen.P2OriginalSaving19Archive.momentPacked00','v4_source_owners':new,'reused_helpers':reused,'old_CharList_input_or_old_htext_claimed':False,'geometry_modules_imported_or_recompiled':False,'production_modified':False,'remote_jobs_submitted':False}
p=ROOT/'BOOTSTRAP.json'
if p.exists():assert json.loads(p.read_text())==report
else:p.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'fixture':rawcopy,'new_owners':new,'reused_helpers':len(reused)},indent=2))
