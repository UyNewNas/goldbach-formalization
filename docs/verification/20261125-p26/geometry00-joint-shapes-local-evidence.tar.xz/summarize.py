#!/usr/bin/env python3
"""Freeze the three successful shape owners and exact specialization evidence."""
from pathlib import Path
import hashlib,json,re
ROOT=Path(__file__).resolve().parent
TARGETS={
    'ImbalancedChen.P2OriginalSaving19Geometry00Shape':'geometry-shape-v1',
    'ImbalancedChen.P2OriginalSaving19Geometry00BoundedAccess':'bounded-access-v1',
    'ImbalancedChen.P2OriginalSaving19Cell00Shape':'joint-shape-v1'}

def fp(p):
    p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}

def put(name,value):
    p=ROOT/name;assert not p.exists(),p
    p.write_text(value if isinstance(value,str) else json.dumps(value,indent=2)+'\n')
    return fp(p)

bootstrap=json.loads((ROOT/'BOOTSTRAP.json').read_text())
reused={x['module']:x for x in bootstrap['reused_helpers']};assert len(reused)==339
for item in reused.values():
    for kind in ['source','object']:
        for side in ['original','copy']:assert fp(item[kind][side]['path'])==item[kind][side]
    for origin in item['additional_origins']:
        for kind in ['source','object']:assert fp(origin[kind]['path'])==origin[kind]
for item in bootstrap['provenance']+[bootstrap['original_archive']]:
    for side in ['original','copy']:assert fp(item[side]['path'])==item[side]
for item in bootstrap['original_fixtures']:assert fp(item['path'])==item

all_results=[(p,json.loads(p.read_text())) for p in (ROOT/'logs').glob('*/*-result.json')]
assert len(all_results)==6 and all(x['status']=='succeeded' for _,x in all_results)
modules=[];axioms=[]
for module,tag in TARGETS.items():
    short=module.split('.')[-1];records={}
    for mode in ['normal','kernel']:
        p=ROOT/'logs'/short/(mode+'-'+tag+'-result.json');d=json.loads(p.read_text())
        assert d['status']=='succeeded' and d['exit_code']==0
        assert d['rss_limit_bytes']==4294967296 and d['wall_limit_seconds']==180 and d['threads']==1
        assert d['input_before']==d['input_after']==bootstrap['original_fixtures']
        assert d['Mathlib_pin']=='e4c91783ca8e6a7c693ae624ade32fd22d4e43c1'
        assert d['shape_only'] and not d['Archive_aliases_connected']
        assert not d['mathematical_floor_validity_claimed'] and not d['production_modified']
        assert not d['remote_jobs_submitted'] and not d['accepted_helpers_recompiled']
        assert fp(d['source']['path'])==d['source'] and fp(d['object']['path'])==d['object']
        assert fp(d['log']['path'])==d['log']
        for dep in d['dependencies']:
            assert fp(dep['source']['path'])==dep['source'] and fp(dep['object']['path'])==dep['object']
        records[mode]={'receipt':fp(p),'result':d}
    n,k=records['normal']['result'],records['kernel']['result']
    assert n['source']==k['source'] and n['object']==k['object'] and n['dependencies']==k['dependencies']
    source=Path(n['source']['path']).read_text();log=Path(n['log']['path']).read_text()
    ns=re.search(r'(?m)^namespace (\S+)',source).group(1)
    prints=re.findall(r'(?m)^#print axioms (\S+)',source)
    found=list(re.finditer(r"'([^']+)' (?:depends on axioms:\s*\[([^]]*)\]|does not depend on any axioms)",log,re.S))
    assert {x.group(1) for x in found}=={ns+'.'+p for p in prints}
    assert ': warning:' not in log and ': error:' not in log
    for x in found:
        ax=[a.strip() for a in (x.group(2) or '').split(',') if a.strip()]
        assert set(ax)<={'propext','Classical.choice','Quot.sound'}
        axioms.append({'declaration':x.group(1),'axioms':ax,'normal_log':n['log']})
    modules.append({'module':module,'source':n['source'],'object':n['object'],
        'normal_receipt':records['normal']['receipt'],'kernel_receipt':records['kernel']['receipt'],
        'normal_seconds':n['elapsed_seconds'],'normal_peak_RSS_bytes':n['peak_rss_bytes'],
        'kernel_seconds':k['elapsed_seconds'],'kernel_peak_RSS_bytes':k['peak_rss_bytes']})
assert len(axioms)==28

# Independently compare the actual predicate text with the original text using
# only the recorded binding substitutions. No clause is dropped or reordered.
specialization=json.loads((ROOT/'SHAPE_SPECIALIZATION.json').read_text())
archive=Path(specialization['original_source']['path']).read_text()
joint=(ROOT/'project/ImbalancedChen/P2OriginalSaving19Cell00Shape.lean').read_text()
for kind,original_pattern,new_pattern in [
    ('CellShape',r'def CellShape \(c : Fin 13\) : Prop :=\n(.*?)\n\ninstance \(c : Fin 13\)',
     r'def CellShape00 : Prop :=\n(.*?)\n\ndef RowShape00'),
    ('RowShape',r'def RowShape \(r : OriginalRowIndex\) : Prop :=\n(.*?)\n\ninstance \(r : OriginalRowIndex\)',
     r'def RowShape00 \(r : Fin 56\) : Prop :=\n(.*?)\n\ndef BoundedRowShape00')]:
    before=re.search(original_pattern,archive,re.S).group(1)
    assert hashlib.sha256(before.encode()).hexdigest()==specialization['original_'+kind+'_body_sha256']
    for a,b in specialization[kind+'_binding_substitutions']:before=before.replace(a,b)
    assert before==re.search(new_pattern,joint,re.S).group(1)

new_by={x['module']:x for x in modules};sources=[]
for p in sorted((ROOT/'project/ImbalancedChen').glob('*.lean')):
    text=p.read_text();assert not re.search(r'\b(sorry|admit|unsafe|native_decide)\b|^\s*axiom\b',text,re.M)
    module='ImbalancedChen.'+p.stem
    row={'module':module,'source':fp(p),'object':fp(ROOT/'objects/ImbalancedChen'/(p.stem+'.olean')),
         'imports':re.findall(r'(?m)^import\s+(\S+)',text)}
    if module in new_by:
        row.update(new_verified_owner=True,normal_receipt=new_by[module]['normal_receipt'],kernel_receipt=new_by[module]['kernel_receipt'])
    else:
        assert row['source']==reused[module]['source']['copy'] and row['object']==reused[module]['object']['copy']
        row.update(reused_accepted_owner=True,recompiled=False,
                   original_source=reused[module]['source']['original'],original_object=reused[module]['object']['original'])
    sources.append(row)
assert len(sources)==342
lookup={x['module']:x for x in sources};seen=set()
def visit(module):
    if module in seen:return
    seen.add(module)
    for dep in lookup[module]['imports']:
        if dep.startswith('ImbalancedChen.'):visit(dep)
visit('ImbalancedChen.P2OriginalSaving19Cell00Shape');assert seen==set(lookup)
canonical=[{'module':x['module'],'source_sha256':x['source']['sha256'],'source_bytes':x['source']['bytes'],'imports':x['imports']} for x in sources]
closure=hashlib.sha256(json.dumps(canonical,sort_keys=True,separators=(',',':')).encode()).hexdigest()
put('FULL_SOURCE_CLOSURE.json',{'schema':'saving19_cell00_joint_shape_full_closure_v1','project_modules':342,
    'new_local_normal_kernel_owners':3,'reused_accepted_owners':339,
    'source_closure_canonical_sha256':closure,'canonical_source_rows':canonical,
    'sources_objects_and_receipts':sources,'bootstrap':fp(ROOT/'BOOTSTRAP.json'),
    'P1_strict_claimed':False,'Archive_CellShape0_alias_connected':False})
result={'schema':'saving19_cell00_geometry_and_joint_shape_local_v1','status':'normal_and_independent_kernel_passed',
    'new_owners':modules,'exact_printed_axiom_sets':axioms,'warnings':[],'failures':[],
    'all_28_vertices_checked':True,'all_56_geometry_rows_checked':True,'all_9_ID_bounds_each_row_checked':True,
    'nine_vertex_ID_Nodup_each_row_checked':True,'both_ten_slot_geometry_arrays_each_row_checked':True,
    'all_original_CellShape_clauses_specialized':True,'all_original_RowShape_clauses_specialized':True,
    'specialization':fp(ROOT/'SHAPE_SPECIALIZATION.json'),'original_Archive_git_commit':bootstrap['original_archive_git_commit'],
    'moment_metadata_rows_IDs_floors_sizes_recomputed':False,'moment_shape_reused_source_sha256':'1c077c3ed062c0682fe11af0b530458b734b490f4415f6d7d77323e26cd11159',
    'original_rawVertex_all_lookup_levels_no_fallback':True,
    'original_vertex_order_preserved':True,'schema_parser_decoder_or_data_changed':False,
    'input_files':bootstrap['original_fixtures'],'full_source_closure':fp(ROOT/'FULL_SOURCE_CLOSURE.json'),
    'source_closure_canonical_sha256':closure,
    'limits_each_invocation':{'RSS_bytes':4294967296,'seconds':180,'threads':1,'maxRecDepth':1000000,'maxHeartbeats':0},
    'Lean_commit':'62eed1db4d67327ec8120be05f1a1b0847d74561','Mathlib_commit':'e4c91783ca8e6a7c693ae624ade32fd22d4e43c1',
    'upstream_recompiled':False,'production_modified':False,'remote_jobs_submitted':False,
    'P1_strict_claimed':False,'Archive_CellShape0_or_RowShape_aliases_connected':False,
    'all_13_cells_claimed':False,'saved_floor_or_geometric_inequality_validity_claimed':False}
put('RESULT.json',result)
put('SOURCE_MANIFEST.json',{'schema':'saving19_cell00_joint_shape_sources_v1','new_sources':[x['source'] for x in modules],
    'scripts':[fp(ROOT/p) for p in ['bootstrap.py','run_local.py','generate_joint.py','summarize.py']],
    'bootstrap':fp(ROOT/'BOOTSTRAP.json'),'specialization':fp(ROOT/'SHAPE_SPECIALIZATION.json'),
    'full_source_closure':fp(ROOT/'FULL_SOURCE_CLOSURE.json')})
table='\n'.join('| '+x['module'].split('.')[-1]+' | '+f"{x['normal_seconds']:.3f}"+' | '+f"{x['kernel_seconds']:.3f}"+
                ' | '+str(x['normal_peak_RSS_bytes'])+' | '+str(x['kernel_peak_RSS_bytes'])+' |' for x in modules)
pins='\n'.join('- `'+x['module'].split('.')[-1]+'`: source `'+x['source']['sha256']+'`; object `'+x['object']['sha256']+'`.' for x in modules)
report=f'''# 原 cell00 Geometry 与联合形状：本地完成

## 结果与具体范围

三个新 owner 已一次通过 normal 和独立 `leanchecker`，没有失败、重试或警告。它们覆盖已由原 parser/decoder 证明的 `concreteGeometry00`，并直接复用 Root 已验收的 `momentConcrete00` / `Moment00Shape`。

`P2OriginalSaving19Geometry00Shape` 的七条 theorem 关闭如下实际条件：dimension=8、physicalJacobian=1、56 条 geometry rows、28 个 vertices、vertexValues.size=vertices.size；对全部 `v : Fin concreteGeometry00.vertices.size`，坐标数组长度=8 且 factors 长度=10；对全部 `r : Fin 56`，simplexId=原索引、vertexIds 长度=9、原九个编号 Nodup、全部九个编号小于实际 vertices.size、factorMaxima 与 gapWeightedMeans 长度均=10。

只有这些 shape/Nat/array 条件执行新的闭合 `decide +kernel`。它们不计算任何 Rat 值关系，也未重新运行 parser、typed decoder 或 moment 的 metadata/56 行 ID/10 floor 槽位检查。既有数据、九个 vertexIds 的顺序和所有 Q80/Q96 数值均未改变。

## 完整原 CellShape / RowShape 子句

`P2OriginalSaving19Cell00Shape` 中三个无假设结论为：

```lean
cell_shape : CellShape00
row_shape (r : Fin 56) : RowShape00 r
row_shape_bounded (r : Fin 56) : BoundedRowShape00 r
```

三个声明的完整命名空间为 `ImbalancedChen.P2OriginalSaving19Cell00Shape`。

`CellShape00` 由原 `Archive.CellShape` 正文机械特化：只将 geometry/moments 绑定改为实际两个 concrete 值，cell index 改为 0，expected row count 改为 56，witness name 改为原完整 filename。其余字节不变，包括全部 geometry 条件、原 `Fin g.vertices.size` 顶点量词，以及原九项 moment metadata 的顺序与 2^80/2^96 分母。

`RowShape00` 同样只替换实际 g/m 行绑定和原索引记法，保持原八项合取：geometry ID、moment ID、九个 vertex IDs、Nodup、所有九个 ID 界、十个 factorMaxima、十个 gapWeightedMeans、十个 Q80 floor 槽位。`BoundedRowShape00` 只进一步把两个 row lookup 改为已经证明界限的读取，仍保留原 RowShape 的各个子句。`row_shape` 与 `row_shape_bounded` 直接组合几何结果和 Root 的已过 moment 结果，不重复有限 moment 检查。

原 source 为 SHA `f48ba6e6522a3a76bd81ef1be15875563163a4df6e7891c1422b6562ee31ed49` 的 Archive，Git commit `{bootstrap['original_archive_git_commit']}`。`SHAPE_SPECIALIZATION.json` 保存原正文 SHA、每项明确替换和新源 SHA；冻结脚本再次对实际最终 predicate 正文作精确比较，确认没有删减或重排子句。

## 完整有界访问接口

命名空间 `ImbalancedChen.P2OriginalSaving19Geometry00BoundedAccess` 提供实际 `boundedRow : Fin 56 → GeometryRow`，以及保持 producer 九点顺序的 `boundedRowVertex : Fin 56 → Fin 9 → Fin 8 → ℚ`。

`row_lookup_no_fallback`、`vertex_lookup_no_fallback`、`vertex_value_lookup_no_fallback`、`coordinate_lookup_no_fallback` 和 `vertex_id_lookup_no_fallback` 明确连接原 `!` 访问与带界访问。`vertexIndex` 来自实际原 row 的第 i 个 vertex ID，其范围由全量形状定理证明；没有新映射表、排序或默认编号。

最后的 `raw_vertex_no_fallback r i j` 关闭原 rawVertex 表达式的所有 lookup 层：

```lean
((concreteGeometry00.vertices[
    (concreteGeometry00.rows[r.val]!).vertexIds[i.val]!]!)[j.val]!) =
  boundedRowVertex r i j
```

右侧 row、vertex ID、vertex 与 coordinate 访问全部带有真实界限。另有 factorMaxima 与 gapWeightedMeans 的全部 `Fin 10` lookup 等式，便于后续 RowNumerics 直接使用原数据。以上只建立访问和原数据相同，不证明 RowDataChecks、det、体积或积分。

## 本地验证与复用

复用 Geometry 的完整 303 模块与 Moment00Shape 的完整 43 模块；共享 7 模块，故共复制并逐项钉定 339 个不同源/对象，没有重编任何供应者。新终端完整闭包为 342 个项目模块。Root 的 Moment00Shape 源 SHA `1c077c3ed062c0682fe11af0b530458b734b490f4415f6d7d77323e26cd11159`、object SHA `c8c151d48f14c9ab0b416c026443ce8ed329cf3336ddcc6808edd067db82f8b6` 原样复用。

每次调用仍固定 4 GiB / 180 秒 / 1 线程，maxRecDepth=1000000、maxHeartbeats=0。Lean commit `62eed1db4d67327ec8120be05f1a1b0847d74561`，Mathlib pin `e4c91783ca8e6a7c693ae624ade32fd22d4e43c1`。每次前后核对依赖 source/object 与原 geometry/moment 两份 input 的 SHA。所有 28 条打印 theorem 的精确 axioms 都只含 propext、Classical.choice、Quot.sound；没有额外公理。

| owner | normal 秒 | kernel 秒 | normal 峰值 bytes | kernel 峰值 bytes |
|---|---:|---:|---:|---:|
{table}

源与对象 pins：

{pins}

完整环境无关 canonical source closure SHA 为 `{closure}`。

## 发布与尚待接线

`DELTA_WHITELIST.json` 只收本次三份新 Lean 源、生成器、回执及来源指纹；不重复 339 个借用源，不含对象或原 raw input。`FULL_SOURCE_CLOSURE.json` 固定全部 342 个模块供复用核对。本轮没有 P1 调用、没有主仓改动，也没有重新核验任何成功供应者。

这次证明是 concrete values 的完整 cell00 shape 与联合 row shape。正式 `Archive.CellShape 0` / `Archive.RowShape` 的结论仍需新版 Core/input maps/geometry/moments aliases 与这些具体值接线；本包明确不声明已经完成该步骤。其余 12 cells、数学 floor 正确性、RowDataChecks、pulling、积分和 P2.6 总端点均不在本次通过范围。
'''
put('REPORT.md',report)
borrowed={Path(x['source']['copy']['path']) for x in reused.values()};files=[]
for p in sorted(ROOT.rglob('*')):
    if not p.is_file() or p in borrowed or 'objects' in p.parts or '__pycache__' in p.parts:continue
    if p.name in {'DELTA_WHITELIST.json','PACKAGE_MANIFEST.json'}:continue
    assert p.suffix not in {'.olean','.ilean'}
    files.append({'relative_path':str(p.relative_to(ROOT)),**fp(p)})
put('DELTA_WHITELIST.json',{'schema':'saving19_cell00_joint_shape_delta_v1','relative_to':str(ROOT),
    'file_count':len(files),'files':files,'no_objects':True,'no_raw_inputs':True,'borrowed_sources_duplicated':False,
    'full_source_closure':fp(ROOT/'FULL_SOURCE_CLOSURE.json'),'source_closure_canonical_sha256':closure})
put('PACKAGE_MANIFEST.json',{'schema':'saving19_cell00_joint_shape_package_v1',
    'whitelist':fp(ROOT/'DELTA_WHITELIST.json'),'files':files+[{'relative_path':'DELTA_WHITELIST.json',**fp(ROOT/'DELTA_WHITELIST.json')}],
    'no_objects':True,'no_raw_inputs':True,'borrowed_sources_duplicated':False,
    'source_closure_canonical_sha256':closure})
for name in ['REPORT.md','RESULT.json','FULL_SOURCE_CLOSURE.json','DELTA_WHITELIST.json','PACKAGE_MANIFEST.json']:
    print(json.dumps(fp(ROOT/name)))
print(json.dumps({'new_owners':3,'axiom_sets':len(axioms),'full_closure':342,'delta_files':len(files),
                  'source_closure_canonical_sha256':closure}))
