from pathlib import Path
import json, hashlib, re, shutil

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT / 'project'
OBJECTS = ROOT / 'objects'
BOOT = json.loads((ROOT / 'BOOTSTRAP.json').read_text())

def fp(p):
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}

def jwrite(p, value):
    assert not p.exists(), p
    p.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')

terminal = 'ImbalancedChen.P2OriginalSaving19Cell00Row000PrefixFloorChecks'
tags = {'ImbalancedChen.P2OriginalSaving19Cell00Row000MomentEncoding': 'encoded-v1',
        terminal: 'assemble-v2'}
for j in range(10):
    tags[f'ImbalancedChen.P2OriginalSaving19Cell00Row000MomentFactor{j:02d}'] = 'prefix-v1'
reused = {r['module']: r for r in BOOT['reused_helpers']}
assert len(tags) == 12 and len(reused) == 356
new_rows = []
allowed_axioms = {'propext', 'Classical.choice', 'Quot.sound'}
printed = []
for mod, tag in sorted(tags.items()):
    source = PROJECT / (mod.replace('.', '/') + '.lean')
    obj = OBJECTS / (mod.replace('.', '/') + '.olean')
    normal_path = ROOT / 'logs' / mod.split('.')[-1] / f'normal-{tag}-result.json'
    kernel_path = ROOT / 'logs' / mod.split('.')[-1] / f'kernel-{tag}-result.json'
    normal, kernel = [json.loads(p.read_text()) for p in [normal_path, kernel_path]]
    for result in [normal, kernel]:
        assert result['status'] == 'succeeded' and result['exit_code'] == 0
        assert result['source'] == fp(source) and result['object'] == fp(obj)
        assert result['rss_limit_bytes'] == 4 * 1024**3 and result['wall_limit_seconds'] == 180
        assert result['input_before'] == result['input_after'] == BOOT['original_fixtures']
        for dep in result['dependencies']:
            assert fp(Path(dep['source']['path'])) == dep['source']
            assert fp(Path(dep['object']['path'])) == dep['object']
        assert fp(Path(result['log']['path'])) == result['log']
    assert normal['dependencies'] == kernel['dependencies']
    log = Path(normal['log']['path']).read_text()
    assert 'sorryAx' not in log
    axioms = []
    pattern = r"^'([^']+)' (?:depends on axioms:\s*\[([^\]]*)\]|(does not depend on any axioms))"
    for match in re.finditer(pattern, log, re.M):
        declared = sorted(x.strip() for x in (match.group(2) or '').split(',') if x.strip())
        assert set(declared) <= allowed_axioms
        axioms.append({'declaration': match.group(1), 'axioms': declared})
    printed += axioms
    new_rows.append({'module': mod, 'source': fp(source), 'object': fp(obj),
                     'normal_receipt': fp(normal_path), 'kernel_receipt': fp(kernel_path),
                     'normal_log': normal['log'], 'kernel_log': kernel['log'],
                     'normal_seconds': normal['elapsed_seconds'],
                     'kernel_seconds': kernel['elapsed_seconds'],
                     'normal_peak_rss_bytes': normal['peak_rss_bytes'],
                     'kernel_peak_rss_bytes': kernel['peak_rss_bytes'],
                     'printed_theorems_and_axioms': axioms})
assert len(printed) == 122

closure = {}
def visit(mod):
    if mod in closure: return
    s = PROJECT / (mod.replace('.', '/') + '.lean')
    o = OBJECTS / (mod.replace('.', '/') + '.olean')
    assert s.is_file() and o.is_file()
    imports = re.findall(r'^import\s+([^\s]+)', s.read_text(), re.M)
    row = {'module': mod, 'source': fp(s), 'object': fp(o), 'imports': imports,
           'new_owner': mod in tags}
    if mod in tags:
        row['acceptance'] = next(r for r in new_rows if r['module'] == mod)
    else:
        assert mod in reused
        r = reused[mod]
        assert row['source'] == r['source']['copy'] and row['object'] == r['object']['copy']
        for cat in ['source', 'object']:
            for side in ['original', 'copy']:
                assert fp(Path(r[cat][side]['path'])) == r[cat][side]
        row['reused_acceptance_provenance'] = r['acceptance_provenance']
    closure[mod] = row
    for dep in imports:
        if dep.startswith('ImbalancedChen.'): visit(dep)
visit(terminal)
assert len(closure) == 368 and set(tags) <= set(closure)
canonical = [{'module': mod, 'source_bytes': r['source']['bytes'],
              'source_sha256': r['source']['sha256'], 'imports': r['imports']}
             for mod, r in sorted(closure.items())]
canonical_sha = hashlib.sha256(json.dumps(canonical, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
assert not any(mod.endswith(x) for mod in closure for x in [
    'P2OriginalLogMomentQ96Checker', 'P2DegreeSixLogGapSoundness',
    'P2PositiveAffineSimplexLogJensen', 'P2OriginalSaving19HigherMoments',
    'P2OriginalSaving19HigherMomentsPrefix', 'P2Winner9RowArithmeticChecker',
    'P2OriginalSaving19ArchiveCore', 'P2OriginalSaving19Archive'])

review = Path('/workspace/p26-recovery-candidates/cell00-row000-moment-floor-review')
(ROOT / 'review').mkdir(exist_ok=True)
for name in ['REPORT.md', 'SOURCE_REVIEW.json']:
    target = ROOT / 'review' / name
    assert not target.exists()
    shutil.copyfile(review / name, target)

failed_path = ROOT / 'logs/P2OriginalSaving19Cell00Row000PrefixFloorChecks/normal-assemble-v1-result.json'
failed = json.loads(failed_path.read_text())
assert failed['status'] == 'failed' and failed['exit_code'] == 1 and failed['object'] is None
failed_source = ROOT / 'attempts/P2OriginalSaving19Cell00Row000PrefixFloorChecks/assemble-v1/P2OriginalSaving19Cell00Row000PrefixFloorChecks.lean'
failed_b = failed_source.read_bytes()
current = PROJECT / 'ImbalancedChen/P2OriginalSaving19Cell00Row000PrefixFloorChecks.lean'
expected = failed_b.replace(b'import Mathlib.Tactic.FinCases\n',
                            b'import Mathlib.Tactic.FinCases\nimport Mathlib.Algebra.BigOperators.Field\n', 1)
expected = expected.replace(b'  rw [total_Q80_eq_saved, h]\n',
                            b'  rw [total_Q80_eq_saved, h]\n  norm_num\n', 1)
assert current.read_bytes() == expected

bridge = ROOT / 'bridge-candidate/ImbalancedChen/P2OriginalSaving19Cell00Row000OriginalFloorBridge.lean'
paper = Path('/workspace/scratch/32a3e5d7265b/audit/sources/new/paper/release-20261106/en/numerical-appendix.tex')
spec = Path('/workspace/p26-source-closure/ImbalancedChen/P2OriginalSaving19Original28918FloorBinding.lean')
prefix = Path('/workspace/p26-source-closure/ImbalancedChen/P2OriginalSaving19HigherMomentsPrefix.lean')
field_base = Path('/workspace/library-files/p34-proof-work/.lake/packages/mathlib')
field_src = field_base / 'Mathlib/Algebra/BigOperators/Field.lean'
field_obj = field_base / '.lake/build/lib/lean/Mathlib/Algebra/BigOperators/Field.olean'
jwrite(ROOT / 'FULL_SOURCE_CLOSURE.json', {
    'schema': 'saving19_row000_prefix_floor_complete_local_closure_v1',
    'project_modules': len(closure), 'new_verified_owners': len(tags),
    'reused_accepted_owners': len(reused), 'source_closure_canonical_sha256': canonical_sha,
    'canonical_source_rows': canonical, 'sources_objects_and_receipts': list(closure.values()),
    'old_analytic_or_Archive_Core_not_in_closure': True,
    'reused_owners_recompiled': False, 'P1_strict_claimed': False,
})
jwrite(ROOT / 'VALIDATION.json', {
    'schema': 'saving19_row000_prefix_floor_local_normal_kernel_v1',
    'owners': new_rows, 'new_owner_count': len(new_rows),
    'printed_theorem_count': len(printed), 'axiom_union': sorted({a for p in printed for a in p['axioms']}),
    'normal_seconds_total': sum(r['normal_seconds'] for r in new_rows),
    'kernel_seconds_total': sum(r['kernel_seconds'] for r in new_rows),
    'peak_rss_bytes': max(max(r['normal_peak_rss_bytes'], r['kernel_peak_rss_bytes']) for r in new_rows),
    'normal_and_kernel_passed': True, 'P1_strict_all_owned_audit_claimed': False,
    'unchanged_local_driver': fp(ROOT / 'run_local.py'),
    'budgets': {'rss_bytes': 4 * 1024**3, 'wall_seconds': 180, 'increased': False},
    'original_fixtures': BOOT['original_fixtures'],
    'source_closure_canonical_sha256': canonical_sha,
    'failed_attempt': {'receipt': fp(failed_path), 'source': fp(failed_source), 'log': failed['log'],
                       'reason': 'missing imported Finset.sum_div and closed Int-to-Rat numeral normalization',
                       'object_produced': False, 'failed_error_recovery_terms_not_accepted': True,
                       'only_repair': 'one existing cached Mathlib import plus one norm_num line',
                       'no_successful_owner_recompiled': True},
    'added_Mathlib_import_reused': {'source': fp(field_src), 'object': fp(field_obj),
                                   'downloaded': False, 'recompiled': False},
})
jwrite(ROOT / 'SOURCE_MANIFEST.json', {
    'schema': 'saving19_row000_prefix_floor_verified_source_manifest_v1',
    'new_sources': [{'module': r['module'], 'source': r['source'], 'object': r['object'],
                     'normal_receipt': r['normal_receipt'], 'kernel_receipt': r['kernel_receipt']}
                    for r in new_rows],
    'uncompiled_original_semantics_bridge': fp(bridge),
    'bridge_not_in_verified_closure': True,
    'missing_local_bridge_dependencies': [
        'ImbalancedChen.P2OriginalSaving19HigherMomentsPrefix',
        'ImbalancedChen.P2OriginalLogMomentQ96ArithmeticBridge'],
    'existing_prefix_semantic_interface': fp(prefix),
    'full_source_closure': fp(ROOT / 'FULL_SOURCE_CLOSURE.json'),
    'validation': fp(ROOT / 'VALIDATION.json'),
    'independent_source_review': fp(ROOT / 'review/SOURCE_REVIEW.json'),
})
jwrite(ROOT / 'FINAL_RESULT.json', {
    'schema': 'saving19_cell00_row000_prefix_numeric_checkpoint_v1',
    'status': 'PASS_LOCAL_NORMAL_AND_INDEPENDENT_KERNEL_FOR_PREFIX_NUMERIC_CERTIFICATES',
    'cell': 0, 'row': 0, 'new_owners': 12, 'reused_owners': 356, 'project_closure': 368,
    'actual_vertex_order': [27, 25, 11, 9, 7, 5, 3, 1, 0],
    'exact_integer_encodings_of_original_data_proved': True,
    'moment_degree_range': [1, 6], 'moment_value_equalities': 60,
    'first_moment_encodings': 10, 'saved_Q80_bindings': 10,
    'explicit_Q80_lower_and_strict_upper_bounds': 10,
    'all_original_five_floor_clauses_in_prefix_representation': True,
    'old_Q96': '6708449485921', 'new_Q96': '6729532351297',
    'sum_original_saved_Q80': '3793373373731202336663',
    'original_max_old_new_retained': True,
    'original_Q96_old_items_reused_not_reproved': True,
    'original_rationalMoment_bridge_compiled': False,
    'original_rationalMoment_or_integral_semantics_claimed_complete': False,
    'remaining_55_cell00_row_moment_floors_proved_here': False,
    'all13_Archive_guards_proved': False, 'P2_6_complete': False,
    'P1_strict_claimed': False, 'production_modified': False, 'P1_jobs_submitted': False,
    'manuscript': {'repository': 'chen-imbalanced-semiprimes',
                   'commit': 'a988cba584d803ae2856a0de50efb582f4f3dd6a',
                   'source': fp(paper), 'label': 'num:simplex-moment', 'lines': [177, 196]},
    'original_five_clause_specification': fp(spec),
    'terminal_source': fp(current), 'terminal_object': fp(OBJECTS / (terminal.replace('.', '/') + '.olean')),
    'validation': fp(ROOT / 'VALIDATION.json'), 'source_manifest': fp(ROOT / 'SOURCE_MANIFEST.json'),
})
jwrite(ROOT / 'PUBLICATION_FILES.json', {
    'schema': 'saving19_row000_prefix_floor_publication_scope_v1',
    'verified_new_sources': [{'repository_path': r['module'].replace('.', '/') + '.lean',
                              'source': r['source']} for r in new_rows],
    'uncompiled_bridge_stays_separate': {'repository_candidate_path':
        'docs/verification/20261125-p26/cell00-row000-moment-floor/bridge-candidate/ImbalancedChen/' + bridge.name,
        'source': fp(bridge)},
    'existing_supplier_sources_must_match_full_closure_before_reuse': True,
    'new_commit_not_guessed': True, 'new_P1_acceptance_not_claimed': True,
})
for name in ['SOURCE_MANIFEST.json', 'VALIDATION.json', 'FULL_SOURCE_CLOSURE.json', 'FINAL_RESULT.json']:
    print(name, json.dumps(fp(ROOT / name)))
