from pathlib import Path
from fractions import Fraction
import hashlib, json, math, os, re

ROOT = Path(__file__).resolve().parent
BASE = Path('/workspace/p26-recovery-candidates/archive-row00-arithmetic/representation-v2')
PROJECT = ROOT / 'project'
OBJECTS = ROOT / 'objects'

def fp(p):
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}

def write(p, text):
    p.parent.mkdir(parents=True, exist_ok=True)
    assert not p.exists(), p
    p.write_bytes(text if isinstance(text, bytes) else text.encode())

def jwrite(p, value):
    write(p, json.dumps(value, indent=2, ensure_ascii=False) + '\n')

old_boot = json.loads((BASE / 'BOOTSTRAP.json').read_text())
old_closure = json.loads((BASE / 'FULL_SOURCE_CLOSURE.json').read_text())
assert old_closure['source_closure_canonical_sha256'] == '596d600cdcc2091bd8fa9acd7422178c2b256b6a876decb834f8f426b68b0dda'
rows = {x['module']: x for x in old_closure['sources_objects_and_receipts']}
prefix_names = {
    'ImbalancedChen.P2Winner9HomogeneousRecurrence',
    'ImbalancedChen.P2OriginalSaving19PrefixInterface',
    'ImbalancedChen.P2OriginalSaving19PrefixMoments',
}
for item in old_boot['reused_helpers']:
    if item['module'] in prefix_names:
        assert item['module'] not in rows
        rows[item['module']] = {
            'module': item['module'], 'source': item['source']['copy'],
            'object': item['object']['copy'], 'provenance': item,
        }
assert len(rows) == 356
reused = []
for mod, row in sorted(rows.items()):
    s, o = Path(row['source']['path']), Path(row['object']['path'])
    assert fp(s) == row['source'] and fp(o) == row['object']
    sc = PROJECT / (mod.replace('.', '/') + '.lean')
    oc = OBJECTS / (mod.replace('.', '/') + '.olean')
    write(sc, s.read_bytes())
    oc.parent.mkdir(parents=True, exist_ok=True)
    assert not oc.exists()
    os.link(o, oc)
    extras = []
    for suffix in ['.olean.private', '.olean.server', '.ir']:
        e = o.with_name(o.stem + suffix)
        if e.exists():
            target = oc.with_name(oc.stem + suffix)
            assert not target.exists()
            os.link(e, target)
            extras.append({'original': fp(e), 'copy': fp(target)})
    reused.append({
        'module': mod, 'source': {'original': fp(s), 'copy': fp(sc)},
        'object': {'original': fp(o), 'copy': fp(oc)},
        'extra_object_siblings': extras, 'object_reuse': 'immutable hardlink',
        'recompiled': False, 'acceptance_provenance': row,
    })
boot = {
    'schema': 'saving19_cell00_row000_prefix_floor_bootstrap_v1',
    'reused_helpers': reused, 'reused_count': len(reused),
    'row000_full_source_closure_manifest': fp(BASE / 'FULL_SOURCE_CLOSURE.json'),
    'row000_canonical_source_closure': old_closure['source_closure_canonical_sha256'],
    'prefix_manifest': fp(Path('/workspace/p26-recovery-candidates/moment-prefix-reuse/SOURCE_MANIFEST.json')),
    'external_LEAN_PATH_roots': old_boot['external_LEAN_PATH_roots'],
    'original_fixtures': old_boot['original_fixtures'],
    'runtime': old_boot['runtime'],
    'production_modified': False, 'remote_jobs_submitted': False,
    'accepted_suppliers_recompiled': False,
    'old_analytic_checker_imported': False,
    'HigherMomentsPrefix_object_present': False,
    'new_floor_claim_before_Lean_verification': False,
}
jwrite(ROOT / 'BOOTSTRAP.json', boot)
write(ROOT / 'run_local.py', (BASE / 'run_local.py').read_bytes())
jwrite(ROOT / 'RUNNER_PROVENANCE.json', {
    'source_driver': fp(BASE / 'run_local.py'),
    'copied_driver': fp(ROOT / 'run_local.py'), 'byte_identical': True,
    'rss_limit_bytes': 4 * 1024**3, 'wall_limit_seconds': 180,
    'new_owner_only': True, 'accepted_suppliers_recompiled': False,
})

raw = {}
for f in boot['original_fixtures']:
    p = Path(f['path']); assert fp(p) == f
    raw['geometry' if 'minorant-extension' in p.name else 'moments'] = json.loads(p.read_bytes())
geometry, moments = raw['geometry'], raw['moments']
row, moment_row = geometry['simplices'][0], moments['records'][0]
assert row['simplex_id'] == moment_row['simplex_id'] == 0
vertices = [[Fraction(q) for q in geometry['vertices'][i]] for i in row['vertex_ids']]
assert row['vertex_ids'] == [27, 25, 11, 9, 7, 5, 3, 1, 0]

def comparison(t): return (1 + t[0] + t[3]) / 2
def new(t): return (1 + t[1] + t[3] + t[7]) / 2 - Fraction(1, 1000000)
def factors(t): return [comparison(t) - sum(t), new(t) - sum(t)] + t
gaps = [new(t) - comparison(t) for t in vertices]
maxima = [Fraction(x) for x in row['factor_maxima']]
deviations = [[1 - factors(v)[j] / maxima[j] for v in vertices] for j in range(10)]
gap_scale = math.lcm(*(q.denominator for q in gaps))
gap_nats = [int(q * gap_scale) for q in gaps]
denominators = [math.lcm(*(q.denominator for q in ds)) for ds in deviations]
deviation_nats = [[int(q * d) for q in ds] for ds, d in zip(deviations, denominators)]
assert all(x >= 0 for x in gap_nats) and all(x >= 0 for ds in deviation_nats for x in ds)

def host_prefix(z):
    table = [1] + [0] * 6
    for a in reversed(z):
        carry = 0; next_table = []
        for x in table:
            carry = x + a * carry
            next_table.append(carry)
        table = next_table
    return table

def host_moment(z, d, k):
    table = host_prefix(z)
    n = sum(table[k-j] * sum(g * y**j for g, y in zip(gap_nats, z)) for j in range(k+1))
    return Fraction(n, sum(gap_nats) * math.comb(9+k, k) * d**k)

moment_values = [[host_moment(z, d, k) for k in range(1, 7)]
                 for z, d in zip(deviation_nats, denominators)]
gap_values = [sum((ms[k-1] - ms[0]**k) / k for k in range(2, 7)) for ms in moment_values]

def qr(q): return {'numerator': str(q.numerator), 'denominator': str(q.denominator)}
def rat(q): return f'({q.numerator} : ℚ) / {q.denominator}'
def vec(xs): return '![' + ', '.join(str(x) for x in xs) + ']'

jwrite(ROOT / 'CANDIDATE_WITNESSES.json', {
    'schema': 'saving19_row000_prefix_moment_witness_candidates_v1',
    'host_role': 'candidate generation only; every mathematical equality and bound requires Lean proof',
    'original_fixtures': boot['original_fixtures'], 'original_vertex_ids': row['vertex_ids'],
    'gap_scale': str(gap_scale), 'gap_nats': [str(x) for x in gap_nats],
    'deviation_denominators': [str(x) for x in denominators],
    'deviation_nats': [[str(x) for x in xs] for xs in deviation_nats],
    'moment_degree1_through6_candidates': [[qr(q) for q in ms] for ms in moment_values],
    'log_gap_candidates': [qr(q) for q in gap_values],
    'original_saved_Q80': moment_row['log_gap_factor_floors_Q80'],
    'original_old_Q96': moment_row['old_floor_Q96'],
    'original_new_Q96': moment_row['new_floor_Q96'],
    'mathematical_PASS_from_host': False,
})

namespace = 'ImbalancedChen.P2OriginalSaving19Cell00Row000MomentFloor'
def progress(s):
    return f'''run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_ROW000_MOMENT {s}"
  err.flush

'''
header = f'''namespace {namespace}

set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false

open scoped BigOperators
open P2OriginalSaving19Cell00Row000
open P2OriginalSaving19RowNumericsPure
open P2OriginalLogMomentQ96ArithmeticPure
open P2OriginalSaving19PrefixMoments

'''
encoding = '''import ImbalancedChen.P2OriginalSaving19Cell00Row000Input
import ImbalancedChen.P2OriginalSaving19PrefixMoments

/-! Exact nonnegative integer encodings of the actual nine ordered vertices.
The existing prefix evaluator is used unchanged. Host-generated literals
are connected to the decoded row by closed Lean equalities below. No
saved field, moment value or final floor is an assumption. -/
''' + header
encoding += f'def gapScale : Nat := {gap_scale}\n\n'
encoding += f'def gapNats : Fin 9 → Nat := {vec(gap_nats)}\n\n'
encoding += 'def deviationDenominators : Fin 10 → Nat := ' + vec(denominators) + '\n\n'
encoding += 'def deviationNats : Fin 10 → Fin 9 → Nat :=\n  ![' + ',\n    '.join(vec(xs) for xs in deviation_nats) + ']\n\n'
encoding += '''def prefixMoment (j : Fin 10) (k : Nat) : ℚ :=
  normalizedMoment gapNats (deviationNats j) (deviationDenominators j) k

'''
encoding += progress('gap_encoding_before')
encoding += '''theorem gapScale_ne : gapScale ≠ 0 := by decide +kernel

theorem gap_encoding : ∀ i : Fin 9,
    gapQ (vertices i) = (gapNats i : ℚ) / (gapScale : ℚ) := by
  decide +kernel

'''
encoding += progress('deviation_encoding_before')
encoding += '''theorem deviationDenominators_ne : ∀ j : Fin 10, deviationDenominators j ≠ 0 := by
  decide +kernel

theorem deviation_encoding : ∀ (j : Fin 10) (i : Fin 9),
    1 - factorsQ (vertices i) j / topsOf row j =
      (deviationNats j i : ℚ) / (deviationDenominators j : ℚ) := by
  decide +kernel

'''
encoding += progress('encoding_complete')
for name in ['gapScale_ne', 'gap_encoding', 'deviationDenominators_ne', 'deviation_encoding']:
    encoding += '#print axioms ' + name + '\n'
encoding += '\nend ' + namespace + '\n'
write(PROJECT / 'ImbalancedChen/P2OriginalSaving19Cell00Row000MomentEncoding.lean', encoding)

generated = []
for j in range(10):
    suffix = f'{j:02d}'
    module = f'P2OriginalSaving19Cell00Row000MomentFactor{suffix}'
    text = '''import ImbalancedChen.P2OriginalSaving19Cell00Row000MomentEncoding
import ImbalancedChen.P2OriginalSaving19Cell00Row000OldFloor

/-! Exact degree-one through degree-six moments for one actual factor,
followed by its original Q80 integer and both floor inequalities. -/
''' + header
    names = []
    for k, q in enumerate(moment_values[j], 1):
        name = f'factor{suffix}_moment{k}'
        names.append(name)
        text += progress(f'factor{suffix}_moment{k}_before')
        text += f'theorem {name} : prefixMoment ({j} : Fin 10) {k} = {rat(q)} := by\n  decide +kernel\n\n'
    first = f'factor{suffix}_first_moment'
    text += progress(f'factor{suffix}_first_moment_before')
    text += f'''theorem {first} :
    prefixMoment ({j} : Fin 10) 1 = 1 - meansOf row ({j} : Fin 10) / topsOf row ({j} : Fin 10) := by
  rw [factor{suffix}_moment1]
  decide +kernel

'''
    names.append(first)
    gap = f'factor{suffix}_gap_value'
    text += progress(f'factor{suffix}_gap_before')
    text += f'''theorem {gap} :
    gapEvaluator (prefixMoment ({j} : Fin 10)) = {rat(gap_values[j])} := by
  unfold gapEvaluator
  simp only [Finset.sum_range_succ, Finset.sum_range_zero]
  simp only [{', '.join(f'factor{suffix}_moment{k}' for k in range(1,7))}]
  decide +kernel

'''
    names.append(gap)
    text += progress(f'factor{suffix}_saved_Q80_before')
    saved = f'factor{suffix}_saved_Q80'
    text += f'''theorem {saved} :
    momentRow.factorFloorsQ80[{j}]! = factorFloorQ80 (prefixMoment ({j} : Fin 10)) := by
  unfold factorFloorQ80
  rw [{gap}]
  decide +kernel

'''
    names.append(saved)
    lower, upper = f'factor{suffix}_Q80_lower', f'factor{suffix}_Q80_upper'
    text += f'''theorem {lower} :
    ((momentRow.factorFloorsQ80[{j}]! : ℤ) : ℚ) ≤
      gapEvaluator (prefixMoment ({j} : Fin 10)) * (2 : ℚ)^80 := by
  rw [{gap}]
  decide +kernel

theorem {upper} :
    gapEvaluator (prefixMoment ({j} : Fin 10)) * (2 : ℚ)^80 <
      ((momentRow.factorFloorsQ80[{j}]! : ℤ) : ℚ) + 1 := by
  rw [{gap}]
  decide +kernel

'''
    names += [lower, upper]
    text += progress(f'factor{suffix}_complete')
    text += ''.join('#print axioms ' + n + '\n' for n in names)
    text += '\nend ' + namespace + '\n'
    target = PROJECT / 'ImbalancedChen' / (module + '.lean')
    write(target, text)
    generated.append({'module': 'ImbalancedChen.' + module, 'source': fp(target), 'factor': j,
                      'stage': 'source_candidate_not_yet_compiled'})
jwrite(ROOT / 'GENERATED_FACTORS.json', {'schema': 'saving19_row000_factor_source_candidates_v1', 'factors': generated})
print(json.dumps({'reused_helpers': len(reused), 'gap_scale': gap_scale,
                  'gap_nats': gap_nats, 'deviation_denominator_digits': [len(str(d)) for d in denominators],
                  'encoding': fp(PROJECT / 'ImbalancedChen/P2OriginalSaving19Cell00Row000MomentEncoding.lean'),
                  'factor00': generated[0], 'host_did_not_certify_mathematics': True}, indent=2))
