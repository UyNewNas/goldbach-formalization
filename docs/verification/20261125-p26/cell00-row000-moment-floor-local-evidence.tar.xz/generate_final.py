from pathlib import Path
import json, hashlib

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT / 'project'
w = json.loads((ROOT / 'CANDIDATE_WITNESSES.json').read_text())
total = sum(map(int, w['original_saved_Q80']))
saved_new = int(w['original_new_Q96'])
ns = 'ImbalancedChen.P2OriginalSaving19Cell00Row000MomentFloor'

def write(path, text):
    path.parent.mkdir(parents=True, exist_ok=True)
    assert not path.exists(), path
    path.write_text(text)

def progress(s):
    return f'''run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_ROW000_FLOOR {s}"
  err.flush

'''

s = ''.join(f'import ImbalancedChen.P2OriginalSaving19Cell00Row000MomentFactor{j:02d}\n'
            for j in range(10))
s += '''import Mathlib.Tactic.FinCases
import Mathlib.Algebra.BigOperators.Field

/-! All five original floor obligations for the actual cell00 row0, expressed
through the existing finite prefix evaluator. The old two equalities are
reused. Both Q80 bounds remain explicit, and the saved new field is the
maximum of the exact old and new Q96 evaluations. The separate bridge to
the original rationalMoment still requires its own acceptance. -/
'''
s += f'''namespace {ns}

set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false

open scoped BigOperators
open P2OriginalSaving19Cell00Row000
open P2OriginalSaving19RowNumericsPure
open P2OriginalLogMomentQ96ArithmeticPure

'''
s += progress('first_moments_before')
s += '''theorem all_first_moments (j : Fin 10) :
    prefixMoment j 1 = 1 - meansOf row j / topsOf row j := by
  fin_cases j
'''
s += ''.join(f'  · exact factor{j:02d}_first_moment\n' for j in range(10)) + '\n'
s += '''theorem all_saved_Q80 (j : Fin 10) :
    momentRow.factorFloorsQ80[j.val]! = factorFloorQ80 (prefixMoment j) := by
  fin_cases j
'''
s += ''.join(f'  · exact factor{j:02d}_saved_Q80\n' for j in range(10)) + '\n'
s += '''theorem all_Q80_bounds (j : Fin 10) :
    ((momentRow.factorFloorsQ80[j.val]! : ℤ) : ℚ) ≤
        gapEvaluator (prefixMoment j) * (2 : ℚ)^80 ∧
      gapEvaluator (prefixMoment j) * (2 : ℚ)^80 <
        ((momentRow.factorFloorsQ80[j.val]! : ℤ) : ℚ) + 1 := by
  fin_cases j
'''
s += ''.join(f'  · exact ⟨factor{j:02d}_Q80_lower, factor{j:02d}_Q80_upper⟩\n' for j in range(10)) + '\n'
s += progress('total_Q80_before')
s += '''theorem total_Q80_eq_saved :
    totalLowerQ80 prefixMoment =
      ((∑ j : Fin 10, momentRow.factorFloorsQ80[j.val]! : ℤ) : ℚ) / (2 : ℚ)^80 := by
  calc
    totalLowerQ80 prefixMoment =
        ((∑ j : Fin 10, factorFloorQ80 (prefixMoment j) : ℤ) : ℚ) / (2 : ℚ)^80 := by
      simp only [totalLowerQ80, factorLowerQ80, roundDownQ, factorFloorQ80,
        Int.cast_sum, Finset.sum_div]
    _ = _ := by simp_rw [← all_saved_Q80]

'''
s += f'''theorem total_Q80_value :
    totalLowerQ80 prefixMoment = ({total} : ℚ) / (2 : ℚ)^80 := by
  have h : (∑ j : Fin 10, momentRow.factorFloorsQ80[j.val]! : ℤ) = {total} := by
    decide +kernel
  rw [total_Q80_eq_saved, h]
  norm_num

'''
s += progress('new_Q96_before')
s += f'''theorem new_Q96_value :
    newFloorQ96 (massOf row) (meansOf row) prefixMoment = {saved_new} := by
  unfold newFloorQ96 newEvaluator
  rw [← jensen_eq, total_Q80_value]
  decide +kernel

'''
s += '''theorem saved_new_Q96_max :
    momentRow.newFloorQ96 =
      max (oldFloorQ96 (massOf row) (meansOf row))
        (newFloorQ96 (massOf row) (meansOf row) prefixMoment) := by
  rw [← moment_old_eq_evaluator, new_Q96_value]
  decide +kernel

def PrefixFloorChecks : Prop :=
  (∀ j : Fin 10, prefixMoment j 1 = 1 - meansOf row j / topsOf row j) ∧
  (∀ j : Fin 10, momentRow.factorFloorsQ80[j.val]! = factorFloorQ80 (prefixMoment j)) ∧
  momentRow.oldFloorQ96 = row.jensenFloorQ96 ∧
  momentRow.oldFloorQ96 = oldFloorQ96 (massOf row) (meansOf row) ∧
  momentRow.newFloorQ96 =
    max (oldFloorQ96 (massOf row) (meansOf row))
      (newFloorQ96 (massOf row) (meansOf row) prefixMoment)

theorem prefix_floor_checks : PrefixFloorChecks :=
  ⟨all_first_moments, all_saved_Q80, moment_old_matches_geometry,
    moment_old_eq_evaluator, saved_new_Q96_max⟩

'''
s += progress('complete')
for name in ['all_first_moments', 'all_saved_Q80', 'all_Q80_bounds', 'total_Q80_eq_saved',
             'total_Q80_value', 'new_Q96_value', 'saved_new_Q96_max', 'prefix_floor_checks']:
    s += '#print axioms ' + name + '\n'
s += '\nend ' + ns + '\n'
write(PROJECT / 'ImbalancedChen/P2OriginalSaving19Cell00Row000PrefixFloorChecks.lean', s)

bridge = '''import ImbalancedChen.P2OriginalSaving19Cell00Row000PrefixFloorChecks
import ImbalancedChen.P2OriginalSaving19HigherMomentsPrefix
import ImbalancedChen.P2OriginalLogMomentQ96ArithmeticBridge

/-! SOURCE-ONLY integration candidate. The original HigherMomentsPrefix
object is absent from this local finite environment. This owner has not
been compiled here and receives no credit from the numerical certificates.
It uses the already existing moment representation theorem and the separate
Q96 namespace bridge; it does not alter analytic suppliers or Core. -/
namespace ImbalancedChen.P2OriginalSaving19Cell00Row000OriginalFloorBridge

open scoped BigOperators
open P2OriginalSaving19Cell00Row000
open P2OriginalSaving19Cell00Row000MomentFloor
open P2OriginalSaving19RowNumericsPure
open P2OriginalLogMomentQ96ArithmeticPure
open P2OriginalSaving19HigherMomentsPrefix

noncomputable def originalMoments (j : Fin 10) (k : Nat) : ℚ :=
  P2OriginalSaving19HigherMoments.rationalMoment
    (fun i => gapQ (vertices i))
    (fun i => 1 - factorsQ (vertices i) j / topsOf row j) k

theorem prefixMoment_eq_original (j : Fin 10) (k : Nat) (hk : k ≤ 6) :
    prefixMoment j k = originalMoments j k := by
  exact normalizedMoment_eq_encoded gapNats (deviationNats j)
    (deviationDenominators j) gapScale k (deviationDenominators_ne j) gapScale_ne hk
    (fun i => gapQ (vertices i))
    (fun i => 1 - factorsQ (vertices i) j / topsOf row j)
    gap_encoding (deviation_encoding j)

theorem original_gap_eq (j : Fin 10) :
    gapEvaluator (originalMoments j) = gapEvaluator (prefixMoment j) := by
  unfold gapEvaluator
  apply Finset.sum_congr rfl
  intro k hk
  rw [← prefixMoment_eq_original j (k + 2)
    (by have h := Finset.mem_range.mp hk; omega),
    ← prefixMoment_eq_original j 1 (by decide)]

theorem original_first_moment (j : Fin 10) :
    originalMoments j 1 = 1 - meansOf row j / topsOf row j := by
  rw [← prefixMoment_eq_original j 1 (by decide)]
  exact all_first_moments j

theorem original_saved_Q80 (j : Fin 10) :
    momentRow.factorFloorsQ80[j.val]! =
      P2OriginalLogMomentQ96CheckerSourceOnly.factorFloorQ80 (originalMoments j) := by
  rw [← P2OriginalLogMomentQ96ArithmeticBridge.factorFloorQ80_eq]
  unfold factorFloorQ80
  rw [original_gap_eq]
  exact all_saved_Q80 j

theorem original_Q80_bounds (j : Fin 10) :
    ((momentRow.factorFloorsQ80[j.val]! : ℤ) : ℚ) ≤
        P2OriginalLogMomentQ96CheckerSourceOnly.gapEvaluator (originalMoments j) * (2 : ℚ)^80 ∧
      P2OriginalLogMomentQ96CheckerSourceOnly.gapEvaluator (originalMoments j) * (2 : ℚ)^80 <
        ((momentRow.factorFloorsQ80[j.val]! : ℤ) : ℚ) + 1 := by
  rw [← P2OriginalLogMomentQ96ArithmeticBridge.gapEvaluator_eq, original_gap_eq]
  exact all_Q80_bounds j

theorem original_total_eq :
    totalLowerQ80 originalMoments = totalLowerQ80 prefixMoment := by
  unfold totalLowerQ80 factorLowerQ80 roundDownQ
  apply Finset.sum_congr rfl
  intro j hj
  rw [original_gap_eq]

theorem original_saved_new_Q96 :
    momentRow.newFloorQ96 =
      max (P2OriginalLogMomentQ96CheckerSourceOnly.oldFloorQ96 (massOf row) (meansOf row))
        (P2OriginalLogMomentQ96CheckerSourceOnly.newFloorQ96
          (massOf row) (meansOf row) originalMoments) := by
  rw [← P2OriginalLogMomentQ96ArithmeticBridge.oldFloorQ96_eq,
    ← P2OriginalLogMomentQ96ArithmeticBridge.newFloorQ96_eq]
  change momentRow.newFloorQ96 = max (oldFloorQ96 (massOf row) (meansOf row))
    (fixedNumerator 96 (oldEvaluator (massOf row) (meansOf row) *
      cubicQ (totalLowerQ80 originalMoments)))
  rw [original_total_eq]
  exact saved_new_Q96_max

/-- The exact five original clauses, specialized to the already decoded
row0 values. This does not connect the remaining twelve archive cells. -/
theorem original_floor_formula :
    (∀ j : Fin 10, originalMoments j 1 = 1 - meansOf row j / topsOf row j) ∧
    (∀ j : Fin 10, momentRow.factorFloorsQ80[j.val]! =
      P2OriginalLogMomentQ96CheckerSourceOnly.factorFloorQ80 (originalMoments j)) ∧
    momentRow.oldFloorQ96 = row.jensenFloorQ96 ∧
    momentRow.oldFloorQ96 =
      P2OriginalLogMomentQ96CheckerSourceOnly.oldFloorQ96 (massOf row) (meansOf row) ∧
    momentRow.newFloorQ96 =
      max (P2OriginalLogMomentQ96CheckerSourceOnly.oldFloorQ96 (massOf row) (meansOf row))
        (P2OriginalLogMomentQ96CheckerSourceOnly.newFloorQ96
          (massOf row) (meansOf row) originalMoments) := by
  refine ⟨original_first_moment, original_saved_Q80, moment_old_matches_geometry, ?_,
    original_saved_new_Q96⟩
  rw [← P2OriginalLogMomentQ96ArithmeticBridge.oldFloorQ96_eq]
  exact moment_old_eq_evaluator

#print axioms prefixMoment_eq_original
#print axioms original_gap_eq
#print axioms original_first_moment
#print axioms original_saved_Q80
#print axioms original_Q80_bounds
#print axioms original_total_eq
#print axioms original_saved_new_Q96
#print axioms original_floor_formula

end ImbalancedChen.P2OriginalSaving19Cell00Row000OriginalFloorBridge
'''
write(ROOT / 'bridge-candidate/ImbalancedChen/P2OriginalSaving19Cell00Row000OriginalFloorBridge.lean', bridge)
print(json.dumps({'total_saved_Q80_candidate': str(total), 'saved_new_Q96_candidate': str(saved_new),
                  'host_mathematical_PASS': False, 'bridge_compiled': False}))
