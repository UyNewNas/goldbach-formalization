#!/usr/bin/env python3
"""Copy and pin already accepted reader/transport/Schema sources and objects.
No compiler, input producer, parser, typed decoder, or mathematical checker runs.
"""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parent
PROJECT=ROOT/'project';OBJECTS=ROOT/'objects'
for p in [PROJECT/'ImbalancedChen',OBJECTS/'ImbalancedChen',ROOT/'logs',ROOT/'attempts',ROOT/'owners',ROOT/'provenance']:
 p.mkdir(parents=True,exist_ok=True)
def fp(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def copy(source,dest):
 source=Path(source);dest=Path(dest);b=source.read_bytes();assert not dest.exists(),str(dest)
 dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b);assert dest.read_bytes()==b
 return {'original':fp(source),'copy':fp(dest)}
transport=ROOT.parent/'geometry-packed-transport'
source_inputs=transport/'SOURCE_INPUTS.json'
assert fp(source_inputs)['sha256']=='9e50e37b9365e5d3955431b6fa03ff44780a87f9b27abc346dd62f4b25ab14f8'
rows=json.loads(source_inputs.read_text())['inputs'];assert len(rows)==206
reused=[]
for row in rows:
 assert fp(row['source']['path'])==row['source']
 assert fp(row['object']['path'])==row['object']
 mod=row['module'];modulepath=Path(mod.replace('.','/'))
 s=copy(row['source']['path'],PROJECT/modulepath.with_suffix('.lean'))
 o=copy(row['object']['path'],OBJECTS/modulepath.with_suffix('.olean'))
 original_object=Path(row['object']['path']);extra=[]
 for p in original_object.parent.glob(original_object.name+'.*'):
  extra.append(copy(p,OBJECTS/modulepath.parent/p.name))
 reused.append({'module':mod,'source':s,'object':o,'extra_object_siblings':extra,'project_imports':row['project_imports'],'recompiled':False})
schema=ROOT.parent/'archive-schema'
ns=json.loads((schema/'logs/normal-schema-v1-result.json').read_text());ks=json.loads((schema/'logs/kernel-schema-v1-result.json').read_text())
assert ns['status']==ks['status']=='succeeded' and ns['source']==ks['source'] and ns['object']==ks['object']
assert fp(ns['source']['path'])==ns['source'];assert fp(ns['object']['path'])==ns['object']
reused.append({'module':ns['module'],
 'source':copy(ns['source']['path'],PROJECT/'ImbalancedChen/P2OriginalSaving19ArchiveSchema.lean'),
 'object':copy(ns['object']['path'],OBJECTS/'ImbalancedChen/P2OriginalSaving19ArchiveSchema.olean'),
 'extra_object_siblings':[],'project_imports':['ImbalancedChen.P2OriginalSaving19SourceJson'],'recompiled':False})
provenance=[]
for label,p in [
 ('GeometryTransport_SOURCE_INPUTS.json',source_inputs),
 ('GeometryParser_SOURCE_INPUTS.json',ROOT.parent/'archive-segment-generator/full-cell00/SOURCE_INPUTS.json'),
 ('GeometryParser_SOURCE_MANIFEST.json',ROOT.parent/'archive-segment-generator/full-cell00/SOURCE_MANIFEST.json'),
 ('GeometryParser_VALIDATION.json',ROOT.parent/'archive-segment-generator/full-cell00/VALIDATION.json'),
 ('ArchiveSchema_SOURCE_ORIGIN.json',schema/'SOURCE_ORIGIN.json'),
 ('ArchiveSchema_normal_result.json',schema/'logs/normal-schema-v1-result.json'),
 ('ArchiveSchema_kernel_result.json',schema/'logs/kernel-schema-v1-result.json')]:
 provenance.append(copy(p,ROOT/'provenance'/label))
planner=copy(ROOT.parent/'archive-moment00/raw_planner.py',ROOT/'raw_planner.py')
fixture=Path('/workspace/p26-original-inputs/eighth-third-minorant-extension-20261009-a23-s23_low-00-cell.witness.json')
assert fp(fixture)['sha256']=='87e3c3da5a86a3ea16c1dcae3a5735ea8b0dc7db05d42b5f5cc3aae66cd54691'
result={'schema':'saving19_geometry00_original_typed_bootstrap_v1','reused_module_count':207,
 'reused_helpers':reused,'provenance':provenance,'raw_planner_source':planner,
 'original_geometry_fixture':fp(fixture),
 'original_parsed_JSON_FQN':'ImbalancedChen.P2OriginalSaving19CharacterCoreDiagnostic.originalGeometryJson00',
 'production_packed_parse_theorem':'ImbalancedChen.P2OriginalSaving19GeometryPackedTransport.geometryPacked00_original_parse',
 'external_LEAN_PATH_roots':ns['LEAN_PATH'].split(':')[1:],
 'reader_and_parser_recompiled':False,'Schema_recompiled':False,'production_modified':False,'remote_jobs_submitted':False}
p=ROOT/'BOOTSTRAP.json';assert not p.exists();p.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'bootstrap':fp(p),'reused_modules':len(reused),'copied_olean_bytes':sum(x['object']['copy']['bytes'] for x in reused)},indent=2))
