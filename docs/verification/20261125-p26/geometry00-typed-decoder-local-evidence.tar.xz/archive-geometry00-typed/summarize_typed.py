#!/usr/bin/env python3
"""Freeze exact source/receipt evidence after all terminal checks pass.

This script invokes no Lean compilation and checks no witness mathematics.
It validates the recorded source, object, provenance, budget and axiom boundary.
"""
from pathlib import Path
import difflib
import hashlib
import json
import re
import subprocess

ROOT = Path(__file__).resolve().parent
FINAL = 'ImbalancedChen.P2OriginalSaving19Geometry00PackedDecoded'
NS = 'ImbalancedChen.P2OriginalSaving19Geometry00Decoding'


def fp(path):
    path = Path(path)
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def put(name, value):
    path = ROOT/name
    assert not path.exists(), ('Frozen output already exists', path)
    path.write_text(value if isinstance(value, str) else json.dumps(value, indent=2)+'\n')
    return fp(path)


bootstrap = json.loads((ROOT/'BOOTSTRAP.json').read_text())
reused = {x['module']: x for x in bootstrap['reused_helpers']}
assert len(reused) == 207
for item in reused.values():
    for kind in ['source', 'object']:
        for side in ['original', 'copy']:
            assert fp(item[kind][side]['path']) == item[kind][side]
for item in bootstrap['provenance']:
    for side in ['original', 'copy']:
        assert fp(item[side]['path']) == item[side]
assert fp(bootstrap['original_geometry_fixture']['path']) == bootstrap['original_geometry_fixture']
owners = {json.loads(p.read_text())['module']: json.loads(p.read_text())
          for p in (ROOT/'owners').glob('*.json')}
assert len(owners) == 96, len(owners)
assert not (set(owners) & set(reused))

results = [(p, json.loads(p.read_text())) for p in sorted((ROOT/'logs').glob('*/*-result.json'))]
accepted = [(p, x) for p, x in results if x['status'] == 'succeeded']
failed = [(p, x) for p, x in results if x['status'] != 'succeeded']
normal = {x['module']: (p, x) for p, x in accepted if x['mode'] == 'normal'}
kernel = {x['module']: (p, x) for p, x in accepted if x['mode'] == 'kernel'}
assert set(normal) == set(kernel) == set(owners)
assert len(accepted) == 2*len(owners)

axioms, warnings, modules = [], [], []
for module in sorted(owners):
    np, n = normal[module]
    kp, k = kernel[module]
    assert n['source'] == k['source'] == owners[module]['source']
    assert n['object'] == k['object']
    assert fp(n['source']['path']) == n['source']
    assert fp(n['object']['path']) == n['object']
    assert n['dependencies'] == k['dependencies']
    for result in [n, k]:
        assert result['input_before'] == result['input_after'] == [bootstrap['original_geometry_fixture']]
        assert result['rss_limit_bytes'] == 4294967296
        assert result['wall_limit_seconds'] == 180 and result['threads'] == 1
        assert result['Mathlib_pin'] == 'e4c91783ca8e6a7c693ae624ade32fd22d4e43c1'
        assert not result['remote_jobs_submitted'] and not result['production_modified']
        assert not result['accepted_helpers_recompiled'] and not result['Schema_recompiled']
        assert not result['accepted_geometry_parser_or_transport_owners_recompiled']
        assert fp(result['log']['path']) == result['log']
        for dep in result['dependencies']:
            assert fp(dep['source']['path']) == dep['source']
            assert fp(dep['object']['path']) == dep['object']
    source = Path(n['source']['path']).read_text()
    assert not re.search(r'\b(sorry|admit|unsafe|native_decide)\b|^\s*axiom\b', source, re.M)
    log = Path(n['log']['path']).read_text()
    matches = list(re.finditer(r"'([^']+)' (?:depends on axioms:\s*\[([^]]*)\]|does not depend on any axioms)", log, re.S))
    printed = re.findall(r'(?m)^#print axioms (\S+)', source)
    assert len(matches) == len(printed), (module, len(matches), len(printed))
    assert {m.group(1) for m in matches} == {NS+'.'+name for name in printed}
    for match in matches:
        ax = [x.strip() for x in (match.group(2) or '').split(',') if x.strip()]
        assert set(ax) <= {'propext', 'Classical.choice', 'Quot.sound'}
        axioms.append({'declaration': match.group(1), 'axioms': ax, 'normal_log': n['log']})
    for line in log.splitlines():
        if ': warning:' in line:
            warnings.append({'module': module, 'message': line, 'log': n['log']})
    modules.append({'module': module, 'source': n['source'], 'object': n['object'],
                    'normal_receipt': fp(np), 'kernel_receipt': fp(kp),
                    'normal_seconds': n['elapsed_seconds'], 'normal_peak_RSS_bytes': n['peak_rss_bytes'],
                    'kernel_seconds': k['elapsed_seconds'], 'kernel_peak_RSS_bytes': k['peak_rss_bytes']})

source_rows = []
for path in sorted((ROOT/'project/ImbalancedChen').glob('*.lean')):
    module = 'ImbalancedChen.'+path.stem
    text = path.read_text()
    assert not re.search(r'\b(sorry|admit|unsafe|native_decide)\b|^\s*axiom\b', text, re.M)
    obj = ROOT/'objects/ImbalancedChen'/(path.stem+'.olean')
    row = {'module': module, 'source': fp(path), 'object': fp(obj),
           'imports': re.findall(r'(?m)^import\s+(\S+)', text)}
    if module in owners:
        row.update(local_verified_owner=True, normal_receipt=fp(normal[module][0]),
                   kernel_receipt=fp(kernel[module][0]))
    else:
        assert module in reused
        assert row['source'] == reused[module]['source']['copy']
        assert row['object'] == reused[module]['object']['copy']
        row.update(reused_accepted_owner=True, recompiled=False,
                   original_source=reused[module]['source']['original'],
                   original_object=reused[module]['object']['original'])
    source_rows.append(row)
assert len(source_rows) == 303
lookup = {x['module']: x for x in source_rows}
seen = set()


def visit(module):
    if module in seen:
        return
    seen.add(module)
    for dep in lookup[module]['imports']:
        if dep.startswith('ImbalancedChen.'):
            visit(dep)


visit(FINAL)
assert seen == set(lookup), (len(seen), sorted(set(lookup)-seen))
canonical = [{'module': x['module'], 'source_sha256': x['source']['sha256'],
              'source_bytes': x['source']['bytes'], 'imports': x['imports']} for x in source_rows]
closure_hash = hashlib.sha256(json.dumps(canonical, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
runtime = Path('/workspace/library-files/p34-runtime/lean-4.33.0-rc1-linux')
version = subprocess.check_output([str(runtime/'bin/lean'), '--version'], text=True).strip()
assert '4.33.0-rc1' in version and '62eed1db4d67327ec8120be05f1a1b0847d74561' in version
runtime_pin = {'version': version, 'lean': fp(runtime/'bin/lean'), 'leanchecker': fp(runtime/'bin/leanchecker'),
               'Mathlib_commit': 'e4c91783ca8e6a7c693ae624ade32fd22d4e43c1',
               'external_LEAN_PATH_roots': bootstrap['external_LEAN_PATH_roots']}
put('FULL_SOURCE_CLOSURE.json', {
    'schema': 'saving19_geometry00_typed_full_source_closure_v1',
    'project_modules': 303, 'new_local_normal_and_kernel_owners': 96,
    'reused_accepted_owner_count': 207, 'bootstrap': fp(ROOT/'BOOTSTRAP.json'),
    'source_closure_canonical_sha256': closure_hash,
    'canonical_source_rows': canonical, 'sources_objects_and_receipts': source_rows,
    'runtime_pin': runtime_pin, 'P1_strict_claimed': False, 'production_modified': False})

# The failed whole-row prototype's four concrete values, original accessors and
# public decode statements are moved, not edited or weakened.
old_path = ROOT/'attempts/P2OriginalSaving19Geometry00DecodedRows000/geometry-typed-v1/P2OriginalSaving19Geometry00DecodedRows000.lean'
old = old_path.read_text()
preserved = []
for i in range(4):
    new_path = ROOT/'project/ImbalancedChen'/f'P2OriginalSaving19Geometry00DecodedRow{i:03d}.lean'
    new = new_path.read_text()
    for name in [f'geometryRowsJson{i:03d}', f'geometryRowsTyped{i:03d}']:
        pattern = r'noncomputable def '+name+r'\s*:(.*?)\n\n'
        a, b = re.search(pattern, old, re.S), re.search(pattern, new, re.S)
        assert a and b and a.group(1) == b.group(1), name
        preserved.append({'declaration': NS+'.'+name, 'definition_byte_preserved': True})
    name = f'decode_geometry_Rows_{i:03d}'
    pattern = r'theorem '+name+r'\s*:(.*?)\s*:='
    assert re.search(pattern, old, re.S).group(1) == re.search(pattern, new, re.S).group(1)
    preserved.append({'declaration': NS+'.'+name, 'statement_byte_preserved': True})
new_block = ROOT/'project/ImbalancedChen/P2OriginalSaving19Geometry00DecodedRows000.lean'
put('ROWS_REPRESENTATION_REPAIR.diff', ''.join(difflib.unified_diff(
    old.splitlines(True), new_block.read_text().splitlines(True),
    fromfile='whole-row-decision-v1/Rows000', tofile='rows-compose-v1/Rows000')))

failure_rows = []
for receipt, failure in failed:
    short = failure['module'].split('.')[-1]
    assert failure['object'] is None
    snapshot = ROOT/'attempts'/short/failure['attempt']/(short+'.lean')
    assert fp(snapshot)['sha256'] == failure['source']['sha256']
    failure_rows.append({k: failure[k] for k in ['module', 'mode', 'attempt', 'status', 'exit_code',
                         'elapsed_seconds', 'peak_rss_bytes', 'object', 'source', 'log']} |
                        {'receipt': fp(receipt), 'source_snapshot': fp(snapshot)})

terminal = next(x for x in modules if x['module'] == FINAL)
parsed_terminal = next(x for x in modules if x['module'] == 'ImbalancedChen.P2OriginalSaving19Geometry00Decoded')
result = {
    'schema': 'saving19_geometry00_original_typed_decode_local_v1',
    'status': 'normal_and_independent_kernel_passed',
    'final_module': FINAL, 'final_theorem': NS+'.geometryPacked00_parse_decode',
    'final_statement': '(SourceJson.parse (String.ofList geometryPacked00.toList) >>= decodeGeometry) = .ok concreteGeometry00',
    'parsed_AST_theorem': NS+'.decode_originalGeometryJson00',
    'parsed_AST_statement': 'decodeGeometry originalGeometryJson00 = .ok concreteGeometry00',
    'no_hypotheses': True, 'concrete_typed_output': NS+'.concreteGeometry00',
    'literal_contents': {'dimension': 8, 'physicalJacobian': 1, 'vertices': 28, 'vertexValues': 28,
                         'rows': 56, 'facetOriginalIndices': 11, 'facetVertices': 11, 'faces': 39},
    'all_eight_Geometry_fields_bound': True, 'all_eight_GeometryRow_fields_bound': True,
    'all_source_JSON_fields_retained_by_reused_full_parser': True,
    'separate_shape_theorems_claimed': False,
    'raw_record_access': 'List.get with a kernel-checked index bound, no fallback',
    'actual_input': bootstrap['original_geometry_fixture'],
    'original_schema_decoder_slice_sha256': '21b86bcf4e04123dc6841cd25e50dcd073ecd9c9ac4c077b0174578a96c57a30',
    'new_owners': modules, 'successful_normal_count': 96, 'successful_kernel_count': 96,
    'sum_successful_normal_seconds': sum(x['normal_seconds'] for x in modules),
    'sum_successful_kernel_seconds': sum(x['kernel_seconds'] for x in modules),
    'max_successful_normal_peak_RSS_bytes': max(x['normal_peak_RSS_bytes'] for x in modules),
    'max_successful_kernel_peak_RSS_bytes': max(x['kernel_peak_RSS_bytes'] for x in modules),
    'exact_printed_axiom_sets': axioms, 'warnings': warnings, 'retained_failures': failure_rows,
    'first_four_row_definitions_and_statements_preserved': preserved,
    'failed_elaboration_placeholder_axioms_not_accepted': True,
    'final_owner': terminal, 'parsed_AST_owner': parsed_terminal,
    'full_source_closure': fp(ROOT/'FULL_SOURCE_CLOSURE.json'),
    'source_closure_canonical_sha256': closure_hash, 'runtime_pin': runtime_pin,
    'limits_each_invocation': {'RSS_bytes': 4294967296, 'seconds': 180, 'threads': 1,
                               'maxRecDepth': 1000000, 'maxHeartbeats': 0},
    'reused_parser_transport_and_schema_objects': 207,
    'schema_recompiled': False, 'pure_parser_recompiled': False, 'geometry_transport_recompiled': False,
    'remote_jobs_submitted': False, 'production_modified': False, 'P1_strict_claimed': False,
    'all_cells_claimed': False, 'old_Core_String_equality_claimed': False,
    'mathematical_floor_correctness_claimed': False, 'pulling_or_integral_correctness_claimed': False}
put('TYPED_RESULT.json', result)
put('TYPED_SOURCE_MANIFEST.json', {
    'new_typed_owner_count': 96, 'reused_owner_count': 207,
    'new_typed_sources': [x['source'] for x in modules], 'bootstrap': fp(ROOT/'BOOTSTRAP.json'),
    'scripts': [fp(ROOT/p) for p in ['bootstrap.py', 'raw_planner.py', 'generate.py', 'generate_complete.py',
                                    'generate_rows.py', 'run_local.py', 'run_families.py', 'run_rows.py', 'run_complete.py', 'summarize_typed.py']],
    'full_source_closure': fp(ROOT/'FULL_SOURCE_CLOSURE.json')})

resource_table = '\n'.join('| '+x['module'].split('.')[-1]+' | '+f"{x['normal_seconds']:.3f}"+
                          ' | '+f"{x['kernel_seconds']:.3f}"+' | '+str(x['normal_peak_RSS_bytes'])+
                          ' | '+str(x['kernel_peak_RSS_bytes'])+' |' for x in modules)
failure_table = '\n'.join('| '+x['module'].split('.')[-1]+' | '+x['attempt']+' | '+x['status']+
                         ' | '+f"{x['elapsed_seconds']:.3f}"+' | '+str(x['peak_rss_bytes'])+' |'
                         for x in failure_rows)
report = f'''# geometry00 原 parser 与真实 typed decoder：本地完整结果

## 已关闭的两个最终义务

以下两个无假设定理均通过 normal 与独立 `leanchecker`：

```lean
ImbalancedChen.P2OriginalSaving19Geometry00Decoding.decode_originalGeometryJson00 :
  decodeGeometry originalGeometryJson00 = .ok concreteGeometry00

ImbalancedChen.P2OriginalSaving19Geometry00Decoding.geometryPacked00_parse_decode :
  (SourceJson.parse (String.ofList geometryPacked00.toList) >>= decodeGeometry) =
    .ok concreteGeometry00
```

第一个左侧是已验收完整原 JSON AST；第二个左侧直接使用正式 v4 候选生产 FQN `ImbalancedChen.P2OriginalSaving19Archive.geometryPacked00`。二者都使用真实 `ArchiveSchema` 中原样的 `decodeGeometry`。原 `SourceJson.parse`、原字节输入、typed schemas、各 decoder 的定义与错误分支均未修改。

右侧是具体 `Geometry` 值，不是 success tag 或默认值。公开名称为 `{NS}.concreteGeometry00`。它包含 dimension=8、physicalJacobian=1、28 个原顶点、28 个原 VertexValues、56 个原 GeometryRow、11 个 facetOriginalIndices、11 个 facetVertices 数组以及 39 条 FaceRecord。这里说明具体字面量内容；单独的数组 shape/范围/Nodup 数学检查没有在本包声明通过。

最终 packed owner 源 SHA `{terminal['source']['sha256']}`，object SHA `{terminal['object']['sha256']}`。normal {terminal['normal_seconds']:.3f}s / {terminal['normal_peak_RSS_bytes']:,} B；独立 kernel {terminal['kernel_seconds']:.3f}s / {terminal['kernel_peak_RSS_bytes']:,} B。AST decoded owner 源 SHA `{parsed_terminal['source']['sha256']}`，object SHA `{parsed_terminal['object']['sha256']}`。

## 字段与顺序

`Geometry` 的全部八个 schema 字段均由原 decoder 绑定。每个 `GeometryRow` 仍包含 simplexId、原顺序九个 vertexIds、physicalVolume、meanGap、十个 factorMaxima、十个 gapWeightedMeans、jensenBound 和 jensenFloorQ96。FaceRecord 的 vertices、dimension、pivot、facetSets 与 simplices 均保留。所有 Rat 目标保持原文本的 numerator/denominator 表达式，未用 host 浮点、Fraction 或 gcd 规范化替换数据。

原 root JSON 的 14 个字段仍保留在复用的完整 AST 中。原 `decodeGeometry` 只读取其中对应八个 schema 字段；其他原始字段依然由完整 parser 绑定，不把它们误称为 decoder 新增读取的字段。`facet_original_indices` 保持原 Nat 编号，未擅自转换成 Fin97 gate 编号。

具体 row、顶点等值从已过原 parser 的 `*ChunkNNNPush []` 使用 `List.get` 提取，携带闭合 index bound；没有 `getD`、fallback 或外部解析结果作为假设。每个 Push/list.reverse 等式按原顺序组合，56 条 row 分 14 块累积。首四条 row 的原 accessor/typed definition 与原 decode 陈述在失败整行版本和新独立 row owner 中逐字一致，记录见 `TYPED_RESULT.json`。

## 资源修复只改变证明表达

首个完整 `decodeGeometryRow` 直接 `decide +kernel` 曾触及 4 GiB 限制。阶段 marker 明确停止在 row000 的整行 decoder 证明；数据定义已经完成。没有提高预算或重跑这个整行目标。

替代形式先证明通用 `original_rational_fraction_of_chars`：原 numerator 不含 slash、原 `SourceJson.intChars` 对 numerator/denominator 的成功结果，以及 denominator 非零，推得原 `parseRational (String.ofList (ns ++ '/' :: ds))` 的精确 Rat 结果。证明使用 `String.toList_ofList` 与 List.takeWhile/drop 的既有定理消除字符往返，原 split 和所有错误条件没有放宽。另有原整数型 rational 分支的通用等式。

实际每行用原 getter 确认 scalar 文本，闭合证明 `intChars` 与非零 guards，再应用该通用桥。两个实际十元 Rat 数组及两个 Nat 字段各自做原 decoder 的闭合 kernel guard；Q96 字符串继续经过原 `parseInteger`。最终通过原 `decodeGeometryRow` 的八字段通用展开等式组合，避免重新判定整行。原始失败、两次通用桥表达修复和一次全 Geometry 组合的 Except bind 表达修复均保留。

完整 Geometry 的抽象组合定理将五个 JSON 列表与五个 typed Array 留作参数，先证明原字段 getter 和原 `Array.mapM` 绑定。最终 owner 只应用已经通过的实际列表等式，不在完整 56 行上下文中重新化简整份 decoder。最后与 higher agent 已通过的生产 packed parse 定理通过原 Except bind 组合。

## 复用、原件与可追溯性

本轮逐字复用 207 个源/对象：higher agent 冻结的 geometry parser 与 packed transport 完整 206 闭包，加一个真实 ArchiveSchema。bootstrap 逐项记录 original/copy SHA；每次 normal/kernel 前后核对所有复用源与对象，未重编 parser、transport、Schema 或分析供应商。

原 geometry00 文件为 `eighth-third-minorant-extension-20261009-a23-s23_low-00-cell.witness.json`，195,134 bytes，SHA `87e3c3da5a86a3ea16c1dcae3a5735ea8b0dc7db05d42b5f5cc3aae66cd54691`。本地候选读取已冻结 `/workspace/p26-original-inputs/` 副本用于机械候选 quotation，保留 CRLF 与所有字符；该 staging 路径不冒充 P1 实际路径。真实生产 FQN 的 packed 数据与该原文的闭合绑定来自已过 geometry transport 证明，不靠 SHA 代替 Lean 内容等式。

Schema 源 SHA `b877c0c35ace12cd76e0ed737b3a4b1ff3917fa15c4cc32b961450ee4761418b`，object SHA `8c3b41bd6b27e92b7a3c724b5d5ee9b191b4a4079fb40bd3ff5daad34129f9cc`。原 `parseInteger` 至 `decodeMoments` 的 5399 B schema/decoder 切片 SHA `21b86bcf4e04123dc6841cd25e50dcd073ecd9c9ac4c077b0174578a96c57a30` 未改。

Lean 为 `{version}`；Mathlib pin `e4c91783ca8e6a7c693ae624ade32fd22d4e43c1`。每次调用固定 4 GiB RSS 监测上限、180 秒、1 线程、maxRecDepth=1000000、maxHeartbeats=0。normal 成功后才运行独立 leanchecker；通过后不重复核验或重编。

96 个新 owner 各有一份成功 normal 与一份成功 kernel 回执；完整终端闭包 303 个项目模块。成功 normal 合计 {result['sum_successful_normal_seconds']:.3f}s，kernel 合计 {result['sum_successful_kernel_seconds']:.3f}s；最高成功峰值分别为 {result['max_successful_normal_peak_RSS_bytes']:,} B 与 {result['max_successful_kernel_peak_RSS_bytes']:,} B。完整打印并解析 {len(axioms)} 个声明的精确 axiom set，全部仅含 propext/Classical.choice/Quot.sound 或空集。失败 elaboration 的错误占位输出不计入通过信用。

## 保留的失败

| owner | attempt | 结果 | 秒 | 峰值 bytes |
|---|---|---|---:|---:|
{failure_table}

所有失败均无 object 生成，源快照和完整日志保留。证明表达的普通错误已在相同预算内局部修复，没有改变陈述或用假设绕过数据。

## 成功回执

| owner | normal 秒 | kernel 秒 | normal 峰值 bytes | kernel 峰值 bytes |
|---|---:|---:|---:|---:|
{resource_table}

## checkpoint 与边界

`TYPED_DELTA_WHITELIST.json` / `TYPED_PACKAGE_MANIFEST.json` 只打包本轮新增 typed 源和证据，以及来源指纹和失败快照；不重复 207 个借用源、不含 object 或 raw input。完整 303 模块的环境无关 canonical source closure SHA 为 `{closure_hash}`，详见 `FULL_SOURCE_CLOSURE.json`。原件可复用 parent 已提交的 cell00 input archive；不另造原件。

这次结果是 geometry00 的真实完整 parse→typed-value 绑定。本包没有运行 P1 strict，也未证明其余 12 个 geometry cells、26 文件的整体验收、旧 Core 原 String literal 与新输入的闭合等式、全部 shape/Nodup/range guards、Q80/Q96 floor 数学正确性、pulling overlap/coverage、积分下界或 P2.6 最终端点。正式新版 Core/all-input maps 完成后，parent 可把生产 index0 定义与本包已闭合 theorem 接到 `geometryParse 0`；本包不导入旧 Core 或216个数学供应商伪称这一步已完成。
'''
put('TYPED_REPORT.md', report)
put('FULL_ACCEPTANCE_MANIFEST.json', {
    'schema': 'saving19_geometry00_typed_local_checkpoint_v1',
    'report': fp(ROOT/'TYPED_REPORT.md'), 'result': fp(ROOT/'TYPED_RESULT.json'),
    'sources': fp(ROOT/'TYPED_SOURCE_MANIFEST.json'), 'closure': fp(ROOT/'FULL_SOURCE_CLOSURE.json'),
    'source_closure_canonical_sha256': closure_hash,
    'final_endpoint': NS+'.geometryPacked00_parse_decode', 'local_only': True,
    'P1_strict_claimed': False, 'all_cells_claimed': False})

borrowed_sources = {Path(x['source']['copy']['path']) for x in reused.values()}
delta = []
for path in sorted(ROOT.rglob('*')):
    if not path.is_file() or path in borrowed_sources or '__pycache__' in path.parts or 'objects' in path.parts:
        continue
    if path.name in {'TYPED_DELTA_WHITELIST.json', 'TYPED_PACKAGE_MANIFEST.json'}:
        continue
    assert path.suffix not in {'.olean', '.ilean'}
    assert 'goldbach-research' not in path.parts
    delta.append({'relative_path': str(path.relative_to(ROOT)), **fp(path)})
put('TYPED_DELTA_WHITELIST.json', {
    'schema': 'saving19_geometry00_typed_only_delta_v1', 'relative_to': str(ROOT),
    'base_geometry_transport_source_inputs': bootstrap['provenance'][0]['original'],
    'no_objects': True, 'no_raw_inputs': True, 'borrowed_sources_duplicated': False,
    'file_count': len(delta), 'files': delta,
    'full_source_closure': fp(ROOT/'FULL_SOURCE_CLOSURE.json'),
    'source_closure_canonical_sha256': closure_hash})
put('TYPED_PACKAGE_MANIFEST.json', {
    'schema': 'saving19_geometry00_typed_delta_package_v1',
    'whitelist': fp(ROOT/'TYPED_DELTA_WHITELIST.json'),
    'files': delta+[{'relative_path': 'TYPED_DELTA_WHITELIST.json', **fp(ROOT/'TYPED_DELTA_WHITELIST.json')}],
    'source_closure_canonical_sha256': closure_hash,
    'no_objects': True, 'no_raw_inputs': True, 'borrowed_sources_duplicated': False})
for name in ['TYPED_REPORT.md', 'TYPED_RESULT.json', 'FULL_SOURCE_CLOSURE.json',
             'TYPED_DELTA_WHITELIST.json', 'TYPED_PACKAGE_MANIFEST.json', 'FULL_ACCEPTANCE_MANIFEST.json']:
    print(json.dumps(fp(ROOT/name)))
print(json.dumps({'new_owners': len(owners), 'full_closure': len(source_rows),
                  'axiom_sets': len(axioms), 'retained_failures': len(failed),
                  'delta_files': len(delta), 'source_closure_canonical_sha256': closure_hash}))
