import ImbalancedChen.P2OriginalSaving19ArchiveSchema
import ImbalancedChen.P2OriginalSaving19SimplicesArrayBlock00000

/-! Actual original simplices typed block 0; exact original record order and fields.
All actual reader/transport objects and the genuine original ArchiveSchema are
reused. Candidate typed values below require original-decoder Lean equalities.
No source JSON or mathematical certificate field is deleted or normalized. -/
namespace ImbalancedChen.P2OriginalSaving19Geometry00Decoding
set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false
open ImbalancedChen.P2OriginalSaving19Archive
open ImbalancedChen.P2OriginalSaving19CharacterCoreDiagnostic

noncomputable def geometryRowsJson000 : SourceJson :=
  (simplicesChunk000Push00 []).get ⟨0, by decide +kernel⟩

noncomputable def geometryRowsTyped000 : GeometryRow :=
  { simplexId := 0,
    vertexIds := #[27, 25, 11, 9, 7, 5, 3, 1, 0],
    physicalVolume := ((19739397832697952137558059616479938870079 : ℚ) / (455559274759680000000000000000000000000000000000000000000000000000 : ℚ)),
    meanGap := ((546743 : ℚ) / (1368000000 : ℚ)),
    factorMaxima := #[((828113 : ℚ) / (8000000 : ℚ)), ((828113 : ℚ) / (8000000 : ℚ)), ((2859299 : ℚ) / (21000000 : ℚ)), ((8952977 : ℚ) / (84000000 : ℚ)), ((16827881 : ℚ) / (180000000 : ℚ)), ((2315557 : ℚ) / (28800000 : ℚ)), ((140619 : ℚ) / (3250000 : ℚ)), ((1171847 : ℚ) / (30000000 : ℚ)), ((1171847 : ℚ) / (30000000 : ℚ)), ((390609 : ℚ) / (10000000 : ℚ))],
    gapWeightedMeans := #[((2729208052373 : ℚ) / (28701400000000 : ℚ)), ((343731975221 : ℚ) / (3587675000000 : ℚ)), ((62006907809983 : ℚ) / (516625200000000 : ℚ)), ((15260448353743 : ℚ) / (172208400000000 : ℚ)), ((14065087471927 : ℚ) / (172208400000000 : ℚ)), ((37981941979937 : ℚ) / (516625200000000 : ℚ)), ((9444658442381 : ℚ) / (258312600000000 : ℚ)), ((111973056431 : ℚ) / (3228907500000 : ℚ)), ((872045089711 : ℚ) / (25831260000000 : ℚ)), ((8484957488687 : ℚ) / (258312600000000 : ℚ))],
    jensenBound := ((10834690813210051893402338510123798599562269817407486088488213780293011258042147800259092050000000000000000000 : ℚ) / (127959917763745368475196527417819510952049770006681331846640501075257306822069892456899675389103890739359516969634488889416849 : ℚ)),
    jensenFloorQ96 := (6708449485921 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_GEOMETRY00_TYPED Rows_record_000_before_decode"
  err.flush

theorem decode_geometry_Rows_000 :
    decodeGeometryRow geometryRowsJson000 = .ok geometryRowsTyped000 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_GEOMETRY00_TYPED Rows_record_000_decoded"
  err.flush

theorem geometry_Rows_chunk_000_push_eq (acc : List SourceJson) :
    simplicesChunk000Push00 acc = [geometryRowsJson000] ++ acc := by rfl

noncomputable def geometryRowsJson001 : SourceJson :=
  (simplicesChunk001Push00 []).get ⟨0, by decide +kernel⟩

noncomputable def geometryRowsTyped001 : GeometryRow :=
  { simplexId := 1,
    vertexIds := #[27, 25, 11, 9, 7, 5, 3, 2, 0],
    physicalVolume := ((6477384745712663246322391033126942478007520303 : ℚ) / (37902531660005376000000000000000000000000000000000000000000000000000 : ℚ)),
    meanGap := ((19865249 : ℚ) / (23712000000 : ℚ)),
    factorMaxima := #[((2484331 : ℚ) / (24000000 : ℚ)), ((2484331 : ℚ) / (24000000 : ℚ)), ((2859299 : ℚ) / (21000000 : ℚ)), ((8952977 : ℚ) / (84000000 : ℚ)), ((16827881 : ℚ) / (180000000 : ℚ)), ((2315557 : ℚ) / (28800000 : ℚ)), ((140619 : ℚ) / (3250000 : ℚ)), ((1171847 : ℚ) / (30000000 : ℚ)), ((1171847 : ℚ) / (30000000 : ℚ)), ((390609 : ℚ) / (10000000 : ℚ))],
    gapWeightedMeans := #[((643583878014991819289 : ℚ) / (6841925491783200000000 : ℚ)), ((108554578758088009009 : ℚ) / (1140320915297200000000 : ℚ)), ((822370895460748037393 : ℚ) / (6841925491783200000000 : ℚ)), ((1843583502113747936447 : ℚ) / (20525776475349600000000 : ℚ)), ((559511491347564641101 : ℚ) / (6841925491783200000000 : ℚ)), ((496188325398262404317 : ℚ) / (6841925491783200000000 : ℚ)), ((20887045592775035771 : ℚ) / (570160457648600000000 : ℚ)), ((1371636388004260843 : ℚ) / (39472647067980000000 : ℚ)), ((2680628577154176193 : ℚ) / (78945294135960000000 : ℚ)), ((335015901511332141761 : ℚ) / (10262888237674800000000 : ℚ))],
    jensenBound := ((5303043124036511258712160275644797675959327014222986280829308067763068735867068651151643465476904560147861631101248003305509083670421787493419324487362872026634171712000000000000000000000 : ℚ) / (7490936286502424745039414837101463170577171286972732576063115636681613392642870421318752421601770121348431256425518097703422558069460892656802515496574922304263476673074619758631857409818150108445883 : ℚ)),
    jensenFloorQ96 := (56087830196655987 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_GEOMETRY00_TYPED Rows_record_001_before_decode"
  err.flush

theorem decode_geometry_Rows_001 :
    decodeGeometryRow geometryRowsJson001 = .ok geometryRowsTyped001 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_GEOMETRY00_TYPED Rows_record_001_decoded"
  err.flush

theorem geometry_Rows_chunk_001_push_eq (acc : List SourceJson) :
    simplicesChunk001Push00 acc = [geometryRowsJson001] ++ acc := by rfl

noncomputable def geometryRowsJson002 : SourceJson :=
  (simplicesChunk002Push00 []).get ⟨0, by decide +kernel⟩

noncomputable def geometryRowsTyped002 : GeometryRow :=
  { simplexId := 2,
    vertexIds := #[27, 25, 11, 9, 7, 5, 4, 2, 0],
    physicalVolume := ((6939348704700313419566100996434862557187457829 : ℚ) / (18612850368752640000000000000000000000000000000000000000000000000000 : ℚ)),
    meanGap := ((1640269 : ℚ) / (3744000000 : ℚ)),
    factorMaxima := #[((2484331 : ℚ) / (24000000 : ℚ)), ((2484331 : ℚ) / (24000000 : ℚ)), ((2859299 : ℚ) / (21000000 : ℚ)), ((8952977 : ℚ) / (84000000 : ℚ)), ((16827881 : ℚ) / (180000000 : ℚ)), ((2315557 : ℚ) / (28800000 : ℚ)), ((140619 : ℚ) / (3250000 : ℚ)), ((1171847 : ℚ) / (30000000 : ℚ)), ((1171847 : ℚ) / (30000000 : ℚ)), ((390609 : ℚ) / (10000000 : ℚ))],
    gapWeightedMeans := #[((118628487712297 : ℚ) / (1262861600000000 : ℚ)), ((59812184417151 : ℚ) / (631430800000000 : ℚ)), ((1366339008573241 : ℚ) / (11365754400000000 : ℚ)), ((112784147789597 : ℚ) / (1262861600000000 : ℚ)), ((309373230498719 : ℚ) / (3788584800000000 : ℚ)), ((827382821497229 : ℚ) / (11365754400000000 : ℚ)), ((104482022467351 : ℚ) / (2841438600000000 : ℚ)), ((190628979347 : ℚ) / (5464305000000 : ℚ)), ((188228960033 : ℚ) / (5464305000000 : ℚ)), ((184615135085879 : ℚ) / (5682877200000000 : ℚ))],
    jensenBound := ((155250243714682791822465894328974525803799189888080353063872641627780797090987733076590030659895804674668800000000000000000000 : ℚ) / (193712951315668674133828366806141361807320508001423280035514659184527785248639627386239434682310181745394739157950139800371353278718279851 : ℚ)),
    jensenFloorQ96 := (63497001392343764 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_GEOMETRY00_TYPED Rows_record_002_before_decode"
  err.flush

theorem decode_geometry_Rows_002 :
    decodeGeometryRow geometryRowsJson002 = .ok geometryRowsTyped002 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_GEOMETRY00_TYPED Rows_record_002_decoded"
  err.flush

theorem geometry_Rows_chunk_002_push_eq (acc : List SourceJson) :
    simplicesChunk002Push00 acc = [geometryRowsJson002] ++ acc := by rfl

noncomputable def geometryRowsJson003 : SourceJson :=
  (simplicesChunk003Push00 []).get ⟨0, by decide +kernel⟩

noncomputable def geometryRowsTyped003 : GeometryRow :=
  { simplexId := 3,
    vertexIds := #[27, 25, 11, 9, 7, 6, 5, 3, 1],
    physicalVolume := ((6579638820975569522770293280488195056813 : ℚ) / (151853091586560000000000000000000000000000000000000000000000000000 : ℚ)),
    meanGap := ((546743 : ℚ) / (1368000000 : ℚ)),
    factorMaxima := #[((828113 : ℚ) / (8000000 : ℚ)), ((828113 : ℚ) / (8000000 : ℚ)), ((2859299 : ℚ) / (21000000 : ℚ)), ((8952977 : ℚ) / (84000000 : ℚ)), ((16827881 : ℚ) / (180000000 : ℚ)), ((3859259 : ℚ) / (48000000 : ℚ)), ((140619 : ℚ) / (3250000 : ℚ)), ((1171847 : ℚ) / (30000000 : ℚ)), ((1171847 : ℚ) / (30000000 : ℚ)), ((390609 : ℚ) / (10000000 : ℚ))],
    gapWeightedMeans := #[((3227973942283 : ℚ) / (34441680000000 : ℚ)), ((3252751241557 : ℚ) / (34441680000000 : ℚ)), ((124249205703349 : ℚ) / (1033250400000000 : ℚ)), ((3653092001563 : ℚ) / (41330016000000 : ℚ)), ((84155134748179 : ℚ) / (1033250400000000 : ℚ)), ((75728493876491 : ℚ) / (1033250400000000 : ℚ)), ((424993488181 : ℚ) / (11480560000000 : ℚ)), ((18151079112343 : ℚ) / (516625200000000 : ℚ)), ((17676257435923 : ℚ) / (516625200000000 : ℚ)), ((5735101686919 : ℚ) / (172208400000000 : ℚ))],
    jensenBound := ((674894239729546126284625671023664040912962960381893199987626484065102755116345142604049206476800000000000000000 : ℚ) / (8109084687671433360281486861040773664898427656496769856410756683911118145053894188737483701775893813923739383769557504503165167 : ℚ)),
    jensenFloorQ96 := (6593916892559 : Int) }

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_GEOMETRY00_TYPED Rows_record_003_before_decode"
  err.flush

theorem decode_geometry_Rows_003 :
    decodeGeometryRow geometryRowsJson003 = .ok geometryRowsTyped003 := by decide +kernel

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_GEOMETRY00_TYPED Rows_record_003_decoded"
  err.flush

theorem geometry_Rows_chunk_003_push_eq (acc : List SourceJson) :
    simplicesChunk003Push00 acc = [geometryRowsJson003] ++ acc := by rfl

noncomputable def geometryRowsJsonBlock000 : List SourceJson := [geometryRowsJson000, geometryRowsJson001, geometryRowsJson002, geometryRowsJson003]
noncomputable def geometryRowsTypedBlock000 : List (GeometryRow) := [geometryRowsTyped000, geometryRowsTyped001, geometryRowsTyped002, geometryRowsTyped003]
noncomputable def geometryRowsBlock000Push (acc : List SourceJson) : List SourceJson := simplicesChunk003Push00 (simplicesChunk002Push00 (simplicesChunk001Push00 (simplicesChunk000Push00 (acc))))

theorem geometry_Rows_block_000_push_eq (acc : List SourceJson) :
    geometryRowsBlock000Push acc = [geometryRowsJson003, geometryRowsJson002, geometryRowsJson001, geometryRowsJson000] ++ acc := by rfl

theorem geometry_Rows_block_000_reverse (acc : List SourceJson) :
    (geometryRowsBlock000Push acc).reverse = acc.reverse ++ geometryRowsJsonBlock000 := by
  rw [geometry_Rows_block_000_push_eq, List.reverse_append]
  rfl

theorem decode_geometry_Rows_block_000 :
    geometryRowsJsonBlock000.mapM decodeGeometryRow = .ok geometryRowsTypedBlock000 := by
  simp only [geometryRowsJsonBlock000, geometryRowsTypedBlock000, List.mapM_cons, List.mapM_nil,
    decode_geometry_Rows_000, decode_geometry_Rows_001, decode_geometry_Rows_002, decode_geometry_Rows_003]
  rfl

noncomputable def geometryRowsTypedThroughBlock000 : List (GeometryRow) := geometryRowsTypedBlock000

theorem decode_geometry_Rows_through_block_000 :
    simplicesArrayAcc00400.reverse.mapM decodeGeometryRow = .ok geometryRowsTypedThroughBlock000 := by
  change (geometryRowsBlock000Push simplicesArrayAcc00000).reverse.mapM decodeGeometryRow = _
  rw [geometry_Rows_block_000_reverse]
  exact decode_geometry_Rows_block_000

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_GEOMETRY00_TYPED Rows_block_000_complete"
  err.flush

#print axioms decode_geometry_Rows_000
#print axioms geometry_Rows_chunk_000_push_eq
#print axioms decode_geometry_Rows_001
#print axioms geometry_Rows_chunk_001_push_eq
#print axioms decode_geometry_Rows_002
#print axioms geometry_Rows_chunk_002_push_eq
#print axioms decode_geometry_Rows_003
#print axioms geometry_Rows_chunk_003_push_eq
#print axioms geometry_Rows_block_000_push_eq
#print axioms geometry_Rows_block_000_reverse
#print axioms decode_geometry_Rows_block_000
#print axioms decode_geometry_Rows_through_block_000

end ImbalancedChen.P2OriginalSaving19Geometry00Decoding
