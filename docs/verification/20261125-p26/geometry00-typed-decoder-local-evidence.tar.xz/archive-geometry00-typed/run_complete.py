#!/usr/bin/env python3
"""Final two new terminal owners only; no successful dependency is rebuilt."""
from pathlib import Path
import json, subprocess, sys

ROOT = Path(__file__).resolve().parent
LOG = ROOT/'logs/complete-orchestration.log'
assert not LOG.exists()
for short, tag in [
        ('P2OriginalSaving19Geometry00Decoded', 'geometry-whole-v1'),
        ('P2OriginalSaving19Geometry00PackedDecoded', 'geometry-packed-v1')]:
    for mode in ['normal', 'kernel']:
        with LOG.open('ab') as out:
            p = subprocess.run([sys.executable, str(ROOT/'run_local.py'), mode, 'ImbalancedChen.'+short, tag],
                               stdout=out, stderr=subprocess.STDOUT)
        receipt = ROOT/'logs'/short/(mode+'-'+tag+'-result.json')
        assert receipt.exists(), ('missing receipt', short, mode, p.returncode)
        d = json.loads(receipt.read_text())
        print(json.dumps({k:d[k] for k in ['module','mode','attempt','status','exit_code',
                                         'elapsed_seconds','peak_rss_bytes']}),flush=True)
        assert p.returncode == 0 and d['status'] == 'succeeded', 'Stop on failure; original budget retained.'
print('P26_GEOMETRY00_ORIGINAL_PARSE_AND_CONCRETE_DECODE_COMPLETE',flush=True)
