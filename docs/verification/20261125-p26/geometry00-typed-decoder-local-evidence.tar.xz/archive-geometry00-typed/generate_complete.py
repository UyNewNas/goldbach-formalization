#!/usr/bin/env python3
"""Abstract original-field decoder glue and final opaque applications.
No concrete whole-file decoder reduction is attempted in the final owner.
"""
import json
import generate as g
PARAMS='(vertexJson valueJson rowJson facetJson faceJson : List SourceJson)'
ARGS='vertexJson valueJson rowJson facetJson faceJson'
SOURCE_ARGS='verticesArrayAcc01400.reverse vertexValuesArrayAcc02800.reverse simplicesArrayAcc05600.reverse facetVerticesArrayAcc00600.reverse faceLedgerArrayAcc03300.reverse'
short='P2OriginalSaving19Geometry00DecodeFields'
s=g.head(['P2OriginalSaving19ArchiveSchema','P2OriginalSaving19WholeValue00'],
         'Original geometry metadata and abstract field-list decoder composition. All original schema fields are retained.')
s+=g.mark('fields_before_original_object')
s+=f'''def geometryObjectWithArrays {PARAMS} : SourceJson := .obj [
  (dimensionKey00, dimensionValue00),
  (physicalKey00, physicalValue00),
  (facetIndicesKey00, facetIndicesValue00),
  (positiveBalanceKey00, positiveBalanceValue00),
  (normalRankKey00, normalRankValue00),
  (active8FieldKey00, active8ArrayValue00),
  (verticesFieldKey00, .arr vertexJson),
  (vertexValuesFieldKey00, .arr valueJson),
  (constraintMinimaFieldKey00, constraintMinimaArrayValue00),
  (facetVerticesFieldKey00, .arr facetJson),
  (faceLedgerFieldKey00, .arr faceJson),
  (simplicesFieldKey00, .arr rowJson),
  (physicalVolumeKey00, physicalVolumeValue00),
  (integralGapKey00, integralGapValue00)]

theorem originalGeometryJson00_eq_object :
    originalGeometryJson00 = geometryObjectWithArrays {SOURCE_ARGS} := by rfl

'''
s+=g.mark('fields_original_object_bound')
s+=f'def geometryDecodedDimension : Nat := {g.nat(g.FIELDS["dimension"])}\n'
s+=f'def geometryDecodedPhysicalJacobian : Nat := {g.nat(g.FIELDS["physical_jacobian"])}\n'
s+=f'def geometryDecodedFacetOriginalIndices : Array Nat := {g.arr(g.FIELDS["facet_original_indices"],g.nat)}\n\n'
names=['originalGeometryJson00_eq_object']
for key,typ,value,raw in [
 ('dimension','Nat','geometryDecodedDimension','dimensionValue00'),
 ('physical_jacobian','Nat','geometryDecodedPhysicalJacobian','physicalValue00'),
 ('facet_original_indices','Array Nat','geometryDecodedFacetOriginalIndices','facetIndicesValue00')]:
 name='geometry_get_'+key
 s+=f'''theorem {name} {PARAMS} :
    (geometryObjectWithArrays {ARGS}).getObjValAs? ({typ}) "{key}" = .ok {value} := by
  change SourceJson.Decode.read (α := {typ}) {raw} = .ok {value}
  decide +kernel

'''
 names.append(name)
for key,param in [('vertices','vertexJson'),('vertex_values','valueJson'),('simplices','rowJson'),('face_ledger','faceJson')]:
 name='geometry_get_'+key
 s+=f'''theorem {name} {PARAMS} :
    (geometryObjectWithArrays {ARGS}).getObjVal? "{key}" = .ok (.arr {param}) := by rfl

'''
 names.append(name)
s+=f'''theorem geometry_get_facet_vertices {PARAMS} :
    (geometryObjectWithArrays {ARGS}).getObjValAs? (Array (Array Nat)) "facet_vertices" =
      facetJson.toArray.mapM (SourceJson.Decode.read (α := Array Nat)) := by rfl

'''
names.append('geometry_get_facet_vertices')
s+=g.mark('fields_all_original_getters_complete')
s+='''def geometryWithDecodedArrays
    (vertices : Array (Array ℚ)) (vertexValues : Array VertexValues)
    (rows : Array GeometryRow) (facetVertices : Array (Array Nat))
    (faces : Array FaceRecord) : Geometry := {
  dimension := geometryDecodedDimension
  physicalJacobian := geometryDecodedPhysicalJacobian
  vertices := vertices
  vertexValues := vertexValues
  rows := rows
  facetOriginalIndices := geometryDecodedFacetOriginalIndices
  facetVertices := facetVertices
  faces := faces }

theorem mapM_array_of_list_ok {α β : Type}
    (read : α → Except String β) (source : List α) (target : List β)
    (h : source.mapM read = .ok target) :
    source.toArray.mapM read = .ok target.toArray := by
  rw [List.mapM_toArray, h]
  rfl

'''
s+=f'''theorem decodeGeometry_of_array_decodes
    {PARAMS}
    (vertices : Array (Array ℚ)) (vertexValues : Array VertexValues)
    (rows : Array GeometryRow) (facetVertices : Array (Array Nat)) (faces : Array FaceRecord)
    (hvertices : vertexJson.toArray.mapM rationalArray = .ok vertices)
    (hvalues : valueJson.toArray.mapM decodeVertexValues = .ok vertexValues)
    (hrows : rowJson.toArray.mapM decodeGeometryRow = .ok rows)
    (hfacets : facetJson.toArray.mapM (SourceJson.Decode.read (α := Array Nat)) = .ok facetVertices)
    (hfaces : faceJson.toArray.mapM decodeFace = .ok faces) :
    decodeGeometry (geometryObjectWithArrays {ARGS}) =
      .ok (geometryWithDecodedArrays vertices vertexValues rows facetVertices faces) := by
  simp only [decodeGeometry, geometry_get_dimension, geometry_get_physical_jacobian,
    geometry_get_vertices, geometry_get_vertex_values, geometry_get_simplices,
    geometry_get_facet_original_indices, geometry_get_facet_vertices, geometry_get_face_ledger,
    SourceJson.getArr?, hvertices, hvalues, hrows, hfacets, hfaces, bind, Except.bind]
  rfl

'''
s+='''theorem geometry_parse_decode_of_equalities
    (text : String) (parsed : SourceJson) (decoded : Geometry)
    (hparse : SourceJson.parse text = .ok parsed)
    (hdecode : decodeGeometry parsed = .ok decoded) :
    (SourceJson.parse text >>= decodeGeometry) = .ok decoded := by
  rw [hparse]
  exact hdecode

'''
names += ['mapM_array_of_list_ok','decodeGeometry_of_array_decodes','geometry_parse_decode_of_equalities']
s+=g.mark('fields_abstract_decoder_glue_complete')+g.foot(names)
m=g.save(short,s,{'original_root_fields':14,'all_original_Geometry_schema_fields':8,
 'five_JSON_array_lists_remain_abstract':True,'facet_original_indices_preserved_as_Nat':True,
 'original_parsed_JSON_identity_closed':True,'full_concrete_decodeGeometry_claimed':False})
print(json.dumps({'module':m['module'],'source':m['source']},indent=2))

short='P2OriginalSaving19Geometry00Decoded'
finals={key:(len(g.chunks_for(g.FIELDS[key]))-1)//4 for key in g.CONFIG}
imports=['P2OriginalSaving19Geometry00DecodeFields']+[g.short(key,finals[key]) for key in g.CONFIG]
s=g.head(imports,'Original complete parsed geometry00 AST decoded into its concrete original Geometry structure.')
s+=g.mark('whole_before_concrete_geometry')
TARGET_ARGS='geometryVerticesTypedThroughBlock003.toArray geometryVertexValuesTypedThroughBlock006.toArray geometryRowsTypedThroughBlock013.toArray geometryFacetVerticesTypedThroughBlock001.toArray geometryFacesTypedThroughBlock008.toArray'
s+=f'''def concreteGeometry00 : Geometry :=
  geometryWithDecodedArrays {TARGET_ARGS}

'''
s+=g.mark('whole_before_opaque_decoder_application')
s+=f'''theorem decode_originalGeometryJson00 :
    decodeGeometry originalGeometryJson00 = .ok concreteGeometry00 :=
  (congrArg decodeGeometry originalGeometryJson00_eq_object).trans
    (decodeGeometry_of_array_decodes {SOURCE_ARGS}
      {TARGET_ARGS}
      (mapM_array_of_list_ok rationalArray verticesArrayAcc01400.reverse
        geometryVerticesTypedThroughBlock003 decode_geometry_Vertices_through_block_003)
      (mapM_array_of_list_ok decodeVertexValues vertexValuesArrayAcc02800.reverse
        geometryVertexValuesTypedThroughBlock006 decode_geometry_VertexValues_through_block_006)
      (mapM_array_of_list_ok decodeGeometryRow simplicesArrayAcc05600.reverse
        geometryRowsTypedThroughBlock013 decode_geometry_Rows_through_block_013)
      (mapM_array_of_list_ok (SourceJson.Decode.read (α := Array Nat)) facetVerticesArrayAcc00600.reverse
        geometryFacetVerticesTypedThroughBlock001 decode_geometry_FacetVertices_through_block_001)
      (mapM_array_of_list_ok decodeFace faceLedgerArrayAcc03300.reverse
        geometryFacesTypedThroughBlock008 decode_geometry_Faces_through_block_008))

'''
s+=g.mark('whole_original_Geometry_decode_complete')+g.foot(['decode_originalGeometryJson00'])
m=g.save(short,s,{'complete_original_decodeGeometry_to_concrete_value':True,
 'concrete_Geometry':'concreteGeometry00','all_eight_schema_fields':True,'success_tag_only':False,
 'getD_or_fallback_used':False,'all_cells_claimed':False,'geometric_certificate_correctness_claimed':False})
print(json.dumps({'module':m['module'],'source':m['source']},indent=2))

short='P2OriginalSaving19Geometry00PackedDecoded'
s=g.head(['P2OriginalSaving19Geometry00Decoded','P2OriginalSaving19GeometryPackedParseTransport00'],
         'Production v4 geometryPacked00 parsed and decoded by the original reader and actual original decoder.')
s+='open ImbalancedChen.P2OriginalSaving19GeometryPackedTransport\n\n'
s+=g.mark('packed_before_opaque_bind_glue')
s+='''theorem geometryPacked00_parse_decode :
    (SourceJson.parse (String.ofList geometryPacked00.toList) >>= decodeGeometry) =
      .ok concreteGeometry00 :=
  geometry_parse_decode_of_equalities (String.ofList geometryPacked00.toList)
    originalGeometryJson00 concreteGeometry00 geometryPacked00_original_parse decode_originalGeometryJson00

'''
s+=g.mark('packed_original_geometry_parse_decode_complete')+g.foot(['geometryPacked00_parse_decode'])
m=g.save(short,s,{'production_FQN':'ImbalancedChen.P2OriginalSaving19Archive.geometryPacked00',
 'complete_original_parser_and_decodeGeometry_to_concrete_value':True,
 'uses_existing_206_module_packed_transport':True,'parser_or_transport_recompiled':False,
 'getD_or_fallback_used':False,'old_Archive_String_literal_equality_claimed':False,'all_cells_claimed':False})
print(json.dumps({'module':m['module'],'source':m['source']},indent=2))
