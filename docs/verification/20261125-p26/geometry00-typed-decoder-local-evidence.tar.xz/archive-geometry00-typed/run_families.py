#!/usr/bin/env python3
"""Each necessary typed owner normal then independent kernel, sequentially.
Stop on any failure. Never recompile accepted reader/transport/Schema objects.
"""
from pathlib import Path
import json,subprocess,sys
import generate as gen
R=Path(__file__).resolve().parent;LOG=R/'logs/families-orchestration.log'
assert not LOG.exists()
plan={key:{'records':len(gen.FIELDS[key].children),'chunks':len(gen.chunks_for(gen.FIELDS[key])),
           'blocks':(len(gen.chunks_for(gen.FIELDS[key]))+3)//4} for key in gen.CONFIG}
(R/'GENERATION_PLAN.json').write_text(json.dumps({'original_fixture':gen.fp(gen.RAW_PATH),'host_candidate_only':True,'families':plan},indent=2)+'\n')
def step(module,mode,tag='geometry-typed-v1'):
 with LOG.open('ab') as f:
  p=subprocess.run([sys.executable,str(R/'run_local.py'),mode,module,tag],stdout=f,stderr=subprocess.STDOUT)
 receipt=R/'logs'/module.split('.')[-1]/(mode+'-'+tag+'-result.json')
 if not receipt.exists():
  print(json.dumps({'module':module,'mode':mode,'status':'missing_receipt','exit_code':p.returncode}),flush=True)
  raise SystemExit(1)
 d=json.loads(receipt.read_text())
 print(json.dumps({k:d[k] for k in ['module','mode','attempt','status','exit_code','elapsed_seconds','peak_rss_bytes']}),flush=True)
 assert p.returncode==0 and d['status']=='succeeded','Stop on failure; no budget increase or repeated owner.'
step('ImbalancedChen.'+gen.short('vertices',0),'kernel','vertices-v1')
for key in gen.CONFIG:
 for i in range(plan[key]['blocks']):
  if key=='vertices' and i==0:continue
  m=gen.block(key,i)
  step(m['module'],'normal')
  step(m['module'],'kernel')
print('P26_GEOMETRY00_ALL_TYPED_FAMILIES_COMPLETE',flush=True)
