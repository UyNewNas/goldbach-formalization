#!/usr/bin/env python3
"""Field-wise certificates for the original GeometryRow decoder.

The raw span planner supplies candidate character/numeric quotations only.
Every getter, integer parse, rational parse and decoder composition is certified
by Lean against the reused original JSON AST and the unchanged ArchiveSchema.
"""
import argparse
import json
import re
from pathlib import Path
import generate as g

ROOT = Path(__file__).resolve().parent


def row_short(index):
    return f'P2OriginalSaving19Geometry00DecodedRow{index:03d}'


def generate_row(index):
    chunks = g.chunks_for(g.FIELDS['simplices'])
    chunk = next(c for c in chunks if c['first'] <= index < c['after'])
    block = chunk['index'] // 4
    imports = ['P2OriginalSaving19ArchiveRationalChars',
               f'P2OriginalSaving19SimplicesArrayBlock{block:03d}00']
    s = g.head(imports, f'Original GeometryRow {index}: field-wise decoder certificates.')
    raw = g.item_name('Rows', index)
    typed = g.typed_name('Rows', index)
    node = g.FIELDS['simplices'].children[index]
    fields = {f.key.scalar: f.value for f in node.fields}
    prefix = f'geometryRow{index:03d}'
    names = []
    s += f'''def {raw} : SourceJson :=
  ({g.orig_push('simplices', chunk['index'])} []).get ⟨{chunk['after']-1-index}, by decide +kernel⟩

def {typed} : GeometryRow :=
  {g.record_value('simplices', node)}

'''
    for key, field, typ in [('simplex_id', 'simplexId', 'Nat'),
                            ('vertex_ids', 'vertexIds', '(Array Nat)')]:
        name = f'{prefix}_{field}_read'
        s += g.mark(f'Row_{index:03d}_{field}_before')
        s += f'''theorem {name} :
    {raw}.getObjValAs? {typ} "{key}" = .ok {typed}.{field} := by decide +kernel

'''
        names.append(name)
    for key, field in [('physical_volume', 'physicalVolume'),
                       ('mean_gap', 'meanGap'),
                       ('jensen_bound', 'jensenBound')]:
        token = fields[key].scalar
        parts = token.split('/')
        assert len(parts) == 2 and all(re.fullmatch(r'-?[0-9]+', x) for x in parts)
        numerator, denominator = parts
        stem = f'{prefix}_{field}'
        ns, ds = stem + 'NumeratorChars', stem + 'DenominatorChars'
        text = stem + 'Text'
        s += f'''def {ns} : List Char := {g.base.quote_list(numerator)}
def {ds} : List Char := {g.base.quote_list(denominator)}
def {text} : String := String.ofList ({ns} ++ '/' :: {ds})

'''
        s += g.mark(f'Row_{index:03d}_{field}_before_field')
        s += f'''theorem {stem}_field :
    {raw}.getObjVal? "{key}" = .ok (.str {text}) := by rfl

theorem {stem}_numerator_no_slash :
    {ns}.all (fun c => c != '/') = true := by decide +kernel

theorem {stem}_numerator_parse :
    SourceJson.intChars {ns} = some ({numerator} : Int) := by decide +kernel

theorem {stem}_denominator_parse :
    SourceJson.intChars {ds} = some ({denominator} : Int) := by decide +kernel

theorem {stem}_denominator_nonzero : ({denominator} : Int) ≠ 0 := by decide +kernel

theorem {stem}_parse :
    parseRational {text} = .ok {typed}.{field} :=
  original_rational_fraction_of_chars {ns} {ds}
    ({numerator} : Int) ({denominator} : Int)
    {stem}_numerator_no_slash {stem}_numerator_parse
    {stem}_denominator_parse {stem}_denominator_nonzero

theorem {stem}_read :
    rationalField {raw} "{key}" = .ok {typed}.{field} :=
  original_rationalField_of_string {raw} "{key}" {text}
    {typed}.{field} {stem}_field {stem}_parse

'''
        names += [stem + suffix for suffix in ['_field', '_numerator_no_slash',
                  '_numerator_parse', '_denominator_parse', '_denominator_nonzero', '_parse', '_read']]
        s += g.mark(f'Row_{index:03d}_{field}_complete')
    for key, field in [('factor_maxima', 'factorMaxima'), ('gap_weighted_means', 'gapWeightedMeans')]:
        name = f'{prefix}_{field}_read'
        s += g.mark(f'Row_{index:03d}_{field}_before')
        s += f'''theorem {name} :
    rationalArrayField {raw} "{key}" = .ok {typed}.{field} := by decide +kernel

'''
        names.append(name)
        s += g.mark(f'Row_{index:03d}_{field}_complete')
    floor = fields['jensen_floor_Q96'].scalar
    floor_text = f'{prefix}_floorText'
    floor_chars = f'{prefix}_floorChars'
    s += f'''def {floor_chars} : List Char := {g.base.quote_list(floor)}
def {floor_text} : String := String.ofList {floor_chars}

theorem {prefix}_floor_text_read :
    {raw}.getObjValAs? String "jensen_floor_Q96" = .ok {floor_text} := by rfl

theorem {prefix}_floor_chars_parse :
    SourceJson.intChars {floor_chars} = some ({floor} : Int) := by decide +kernel

theorem {prefix}_floor_parse :
    parseInteger {floor_text} = .ok {typed}.jensenFloorQ96 := by
  simp only [{floor_text}, parseInteger, String.toList_ofList, {prefix}_floor_chars_parse]
  rfl

theorem {g.decode_name('Rows', index)} :
    decodeGeometryRow {raw} = .ok {typed} :=
  original_geometryRow_of_fields {raw} {typed} {floor_text}
    {prefix}_simplexId_read {prefix}_vertexIds_read
    {prefix}_physicalVolume_read {prefix}_meanGap_read
    {prefix}_factorMaxima_read {prefix}_gapWeightedMeans_read
    {prefix}_jensenBound_read {prefix}_floor_text_read {prefix}_floor_parse

'''
    names += [prefix + '_floor_text_read', prefix + '_floor_chars_parse',
              prefix + '_floor_parse', g.decode_name('Rows', index)]
    s += g.mark(f'Row_{index:03d}_original_decoder_complete') + g.foot(names)
    return g.save(row_short(index), s, {
        'original_key': 'simplices', 'row_index': index,
        'original_raw_span': [node.start, node.end], 'source_chunk': chunk,
        'all_original_GeometryRow_schema_fields': 8,
        'vertex_ids_original_order_preserved': True,
        'original_JSON_getter_and_original_intChars_guards': True,
        'original_rational_slash_and_denominator_nonzero_checks': True,
        'whole_row_decide_replaced_with_opaque_field_composition': True,
        'original_decoder_unchanged': True,
        'candidate_rationals': 'exact source numerator/denominator expressions, no host normalization',
        'original_JSON_access': 'List.get with kernel-checked bound, no fallback'})


def generate_block(index):
    chunks = g.chunks_for(g.FIELDS['simplices'])
    selected = chunks[index*4:(index+1)*4]
    assert selected
    ids = [j for c in selected for j in range(c['first'], c['after'])]
    original_module = f'P2OriginalSaving19SimplicesArrayBlock{index:03d}00'
    imports = ([g.short('simplices', index-1)] if index else [])
    imports += [original_module] + [row_short(j) for j in ids]
    s = g.head(imports, f'Original GeometryRow block {index}: opaque individual row certificates in original order.')
    names = []
    for c in selected:
        records = '['+', '.join(g.item_name('Rows',j) for j in reversed(range(c['first'],c['after'])))+']'
        thm = f'geometry_Rows_chunk_{c["index"]:03d}_push_eq'
        s += f'''theorem {thm} (acc : List SourceJson) :
    {g.orig_push('simplices',c['index'])} acc = {records} ++ acc := by rfl

'''
        names.append(thm)
    rb, tb, push = [f'geometryRows{x}{index:03d}' for x in ['JsonBlock','TypedBlock','Block']]
    push += 'Push'
    s += f'def {rb} : List SourceJson := ['+', '.join(g.item_name('Rows',j) for j in ids)+']\n'
    s += f'def {tb} : List GeometryRow := ['+', '.join(g.typed_name('Rows',j) for j in ids)+']\n'
    expr = 'acc'
    for c in selected:
        expr = f'{g.orig_push("simplices",c["index"])} ({expr})'
    s += f'def {push} (acc : List SourceJson) : List SourceJson := {expr}\n\n'
    reverse_raw = '['+', '.join(g.item_name('Rows',j) for j in reversed(ids))+']'
    s += f'''theorem geometry_Rows_block_{index:03d}_push_eq (acc : List SourceJson) :
    {push} acc = {reverse_raw} ++ acc := by rfl

theorem geometry_Rows_block_{index:03d}_reverse (acc : List SourceJson) :
    ({push} acc).reverse = acc.reverse ++ {rb} := by
  rw [geometry_Rows_block_{index:03d}_push_eq, List.reverse_append]
  rfl

theorem decode_geometry_Rows_block_{index:03d} :
    {rb}.mapM decodeGeometryRow = .ok {tb} := by
  simp only [{rb}, {tb}, List.mapM_cons, List.mapM_nil,
    {', '.join(g.decode_name('Rows',j) for j in ids)}]
  rfl

'''
    total = f'geometryRowsTypedThroughBlock{index:03d}'
    rhs = tb if index == 0 else f'geometryRowsTypedThroughBlock{index-1:03d} ++ {tb}'
    s += f'def {total} : List GeometryRow := {rhs}\n\n'
    s += f'''theorem decode_geometry_Rows_through_block_{index:03d} :
    {g.raw_acc('simplices',selected[-1]['index']+1)}.reverse.mapM decodeGeometryRow = .ok {total} := by
  change ({push} {g.raw_acc('simplices',selected[0]['index'])}).reverse.mapM decodeGeometryRow = _
  rw [geometry_Rows_block_{index:03d}_reverse]
'''
    if index == 0:
        s += f'  exact decode_geometry_Rows_block_{index:03d}\n\n'
    else:
        s += f'  rw [List.mapM_append, decode_geometry_Rows_through_block_{index-1:03d}, decode_geometry_Rows_block_{index:03d}]\n  rfl\n\n'
    names += [f'geometry_Rows_block_{index:03d}_push_eq',f'geometry_Rows_block_{index:03d}_reverse',
              f'decode_geometry_Rows_block_{index:03d}', f'decode_geometry_Rows_through_block_{index:03d}']
    s += g.mark(f'Rows_block_{index:03d}_composed') + g.foot(names)
    short = g.short('simplices', index)
    plan = {'original_key':'simplices','block':index,'selected_chunks':selected,'record_indices':ids,
            'all_original_schema_fields_preserved':True,'original_order_preserved':True,
            'whole_row_guard_replaced_by_imported_field_certificates':True,
            'row_decoder_statements_and_concrete_values_unchanged':True,
            'full_decodeGeometry_claimed':False}
    p = g.PROJECT/'ImbalancedChen'/(short+'.lean')
    if p.exists() and p.read_text() != s.replace('\ndef ', '\nnoncomputable def '):
        assert index == 0, 'Only the recorded failed initial block may change.'
        assert not (ROOT/'objects/ImbalancedChen'/(short+'.olean')).exists()
        failed = ROOT/'attempts'/short/'geometry-typed-v1'/(short+'.lean')
        assert p.read_bytes() == failed.read_bytes()
        meta = ROOT/'owners'/(short+'.json')
        frozen = ROOT/'provenance/whole-row-decision-v1'
        frozen.mkdir(parents=True, exist_ok=True)
        g.write_new(frozen/p.name, p.read_bytes())
        g.write_new(frozen/meta.name, meta.read_bytes())
        s = s.replace('\ndef ', '\nnoncomputable def ')
        p.write_text(s)
        m = json.loads(meta.read_text())
        m.update(source=g.fp(p), project_imports=re.findall(r'(?m)^import\s+(ImbalancedChen\.\S+)', s),
                 planned_obligations=plan, failed_preimage=g.fp(failed))
        meta.write_text(json.dumps(m,indent=2)+'\n')
        return m
    return g.save(short,s,plan)


if __name__ == '__main__':
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('index', type=int)
    ap.add_argument('--block', action='store_true')
    args = ap.parse_args()
    result = generate_block(args.index) if args.block else generate_row(args.index)
    print(json.dumps({'module': result['module'], 'source': result['source']}, indent=2))
