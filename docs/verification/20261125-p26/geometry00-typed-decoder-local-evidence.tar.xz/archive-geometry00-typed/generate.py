#!/usr/bin/env python3
"""Mechanical typed quotations from raw spans; original decoders certify them.
No host mathematical property of a witness is tested. Numeric source strings
are retained as Lean integer/rational expressions without host normalization.
"""
from pathlib import Path
import argparse,json,re,hashlib
import raw_planner as base
ROOT=Path(__file__).resolve().parent;PROJECT=ROOT/'project'
NS='ImbalancedChen.P2OriginalSaving19Geometry00Decoding'
RAW_PATH=Path('/workspace/p26-original-inputs/eighth-third-minorant-extension-20261009-a23-s23_low-00-cell.witness.json')
RAW=RAW_PATH.read_bytes()
assert len(RAW)==195134 and base.sha(RAW)=='87e3c3da5a86a3ea16c1dcae3a5735ea8b0dc7db05d42b5f5cc3aae66cd54691'
PLAN=base.RawPlanner(RAW).value(0)
FIELDS={f.key.scalar:f.value for f in PLAN.fields}
CONFIG={
 'vertices':('Vertices','vertices','Array ℚ','rationalArray'),
 'vertex_values':('VertexValues','vertexValues','VertexValues','decodeVertexValues'),
 'facet_vertices':('FacetVertices','facetVertices','Array Nat','(SourceJson.Decode.read (α := Array Nat))'),
 'face_ledger':('Faces','faceLedger','FaceRecord','decodeFace'),
 'simplices':('Rows','simplices','GeometryRow','decodeGeometryRow')}
ORIGINAL_TAG={'vertices':'Vertices','vertex_values':'VertexValues','facet_vertices':'FacetVertices','face_ledger':'FaceLedger','simplices':'Simplices'}

def fp(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':base.sha(b)}
def write_new(p,data):
 p=Path(p);b=data.encode() if isinstance(data,str) else data
 if p.exists():assert p.read_bytes()==b,('Frozen candidate drift',str(p))
 else:p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
def head(imports,description):
 return ''.join('import ImbalancedChen.'+x+'\n' for x in imports)+f'''
/-! {description}
All actual reader/transport objects and the genuine original ArchiveSchema are
reused. Candidate typed values below require original-decoder Lean equalities.
No source JSON or mathematical certificate field is deleted or normalized. -/
namespace {NS}
set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false
open ImbalancedChen.P2OriginalSaving19Archive
open ImbalancedChen.P2OriginalSaving19CharacterCoreDiagnostic

'''
def foot(names):return '\n'.join('#print axioms '+n for n in names)+'\n\nend '+NS+'\n'
def mark(s):return 'run_cmd do\n  let err ← IO.getStderr\n  err.putStrLn "P26_GEOMETRY00_TYPED '+s+'"\n  err.flush\n\n'
def save(short,s,plan):
 s=s.replace('\ndef ','\nnoncomputable def ')
 p=PROJECT/'ImbalancedChen'/(short+'.lean');write_new(p,s)
 m={'module':'ImbalancedChen.'+short,'source':fp(p),'project_imports':re.findall(r'(?m)^import\s+(ImbalancedChen\.\S+)',s),
    'planned_obligations':plan,'original_fixture':fp(RAW_PATH),'bootstrap':fp(ROOT/'BOOTSTRAP.json'),
    'host_typed_quotations_are_proof':False,'accepted_parser_or_Schema_recompiled':False,
    'original_decodeGeometry_unchanged':True,'production_modified':False,'remote_jobs_submitted':False}
 write_new(ROOT/'owners'/(short+'.json'),json.dumps(m,indent=2)+'\n');return m

def nat(n):
 assert n.kind=='number' and re.fullmatch(r'0|[1-9][0-9]*',n.scalar)
 return n.scalar

def int_(n):
 assert n.kind in {'str','number'} and re.fullmatch(r'-?(0|[1-9][0-9]*)',n.scalar)
 return '('+n.scalar+' : Int)'

def rat(n):
 assert n.kind=='str'
 q=n.scalar.split('/')
 assert len(q) in [1,2] and all(re.fullmatch(r'-?(0|[1-9][0-9]*)',x) for x in q)
 return '('+' / '.join('('+x+' : ℚ)' for x in q)+')'

def arr(n,f):
 assert n.kind=='arr'
 return '#['+', '.join(f(x) for x in n.children)+']'

def record_value(key,n):
 if key=='vertices':return arr(n,rat)
 if key=='facet_vertices':return arr(n,nat)
 d={f.key.scalar:f.value for f in n.fields}
 if key=='vertex_values':
  return '{ gap := '+rat(d['gap'])+',\n    factors := '+arr(d['factors'],rat)+' }'
 if key=='face_ledger':
  return ('{ vertices := '+arr(d['vertices'],nat)+',\n'
          '    dimension := '+nat(d['dimension'])+', pivot := '+nat(d['pivot'])+',\n'
          '    facetSets := '+arr(d['facet_sets'],lambda x:arr(x,nat))+',\n'
          '    simplices := '+nat(d['simplices'])+' }')
 assert key=='simplices'
 return ('{ simplexId := '+nat(d['simplex_id'])+',\n'
         '    vertexIds := '+arr(d['vertex_ids'],nat)+',\n'
         '    physicalVolume := '+rat(d['physical_volume'])+',\n'
         '    meanGap := '+rat(d['mean_gap'])+',\n'
         '    factorMaxima := '+arr(d['factor_maxima'],rat)+',\n'
         '    gapWeightedMeans := '+arr(d['gap_weighted_means'],rat)+',\n'
         '    jensenBound := '+rat(d['jensen_bound'])+',\n'
         '    jensenFloorQ96 := '+int_(d['jensen_floor_Q96'])+' }')

def chunks_for(node):
 chunks=[];first=0;start=node.start+1
 while first<len(node.children):
  after=first
  while after<len(node.children) and after-first<2:
   candidate=after+1;final=candidate==len(node.children)
   if final:end=node.end
   else:
    end=node.children[candidate-1].end
    while RAW[end] in base.WHITE:end+=1
    assert RAW[end]==ord(',');end+=1
   if end-start>768 and after>first:break
   after=candidate
   if end-start>=768:break
  final=after==len(node.children)
  if final:end=node.end
  else:
   end=node.children[after-1].end
   while RAW[end] in base.WHITE:end+=1
   assert RAW[end]==ord(',');end+=1
  chunks.append({'index':len(chunks),'first':first,'after':after,'start':start,'end':end,'final':final})
  first=after;start=end
 return chunks

def short(key,i):return f'P2OriginalSaving19Geometry00Decoded{CONFIG[key][0]}{i:03d}'
def item_name(tag,i):return f'geometry{tag}Json{i:03d}'
def typed_name(tag,i):return f'geometry{tag}Typed{i:03d}'
def decode_name(tag,i):return f'decode_geometry_{tag}_{i:03d}'
def raw_acc(prefix,i):return f'{prefix}ArrayAcc{i:03d}00'
def orig_push(prefix,i):return f'{prefix}Chunk{i:03d}Push00'

def block(key,index):
 tag,prefix,typ,decoder=CONFIG[key];node=FIELDS[key];chunks=chunks_for(node)
 selected=chunks[index*4:(index+1)*4];assert selected
 original_module=f'P2OriginalSaving19{ORIGINAL_TAG[key]}ArrayBlock{index:03d}00'
 assert (PROJECT/'ImbalancedChen'/(original_module+'.lean')).exists()
 imports=['P2OriginalSaving19ArchiveSchema',original_module] if index==0 else [short(key,index-1),original_module]
 s=head(imports,f'Actual original {key} typed block {index}; exact original record order and fields.')
 names=[];ids=[]
 for c in selected:
  for j in range(c['first'],c['after']):
   raw=item_name(tag,j);typed=typed_name(tag,j);reverse_index=c['after']-1-j
   s+=f'''def {raw} : SourceJson :=
  ({orig_push(prefix,c['index'])} []).get ⟨{reverse_index}, by decide +kernel⟩

def {typed} : {typ} :=
  {record_value(key,node.children[j])}

'''
   s+=mark(f'{tag}_record_{j:03d}_before_decode')
   s+=f'''theorem {decode_name(tag,j)} :
    {decoder} {raw} = .ok {typed} := by decide +kernel

'''
   s+=mark(f'{tag}_record_{j:03d}_decoded');names.append(decode_name(tag,j));ids.append(j)
  reversed_records='['+', '.join(item_name(tag,j) for j in reversed(range(c['first'],c['after'])))+']'
  thm=f'geometry_{tag}_chunk_{c["index"]:03d}_push_eq'
  s+=f'''theorem {thm} (acc : List SourceJson) :
    {orig_push(prefix,c['index'])} acc = {reversed_records} ++ acc := by rfl

'''
  names.append(thm)
 rb=f'geometry{tag}JsonBlock{index:03d}';tb=f'geometry{tag}TypedBlock{index:03d}';push=f'geometry{tag}Block{index:03d}Push'
 s+=f'def {rb} : List SourceJson := ['+', '.join(item_name(tag,j) for j in ids)+']\n'
 s+=f'def {tb} : List ({typ}) := ['+', '.join(typed_name(tag,j) for j in ids)+']\n'
 expr='acc'
 for c in selected:expr=f'{orig_push(prefix,c["index"])} ({expr})'
 s+=f'def {push} (acc : List SourceJson) : List SourceJson := {expr}\n\n'
 reverse_raw='['+', '.join(item_name(tag,j) for j in reversed(ids))+']'
 s+=f'''theorem geometry_{tag}_block_{index:03d}_push_eq (acc : List SourceJson) :
    {push} acc = {reverse_raw} ++ acc := by rfl

theorem geometry_{tag}_block_{index:03d}_reverse (acc : List SourceJson) :
    ({push} acc).reverse = acc.reverse ++ {rb} := by
  rw [geometry_{tag}_block_{index:03d}_push_eq, List.reverse_append]
  rfl

theorem decode_geometry_{tag}_block_{index:03d} :
    {rb}.mapM {decoder} = .ok {tb} := by
  simp only [{rb}, {tb}, List.mapM_cons, List.mapM_nil,
    {', '.join(decode_name(tag,j) for j in ids)}]
  rfl

'''
 total=f'geometry{tag}TypedThroughBlock{index:03d}'
 rhs=tb if index==0 else f'geometry{tag}TypedThroughBlock{index-1:03d} ++ {tb}'
 s+=f'def {total} : List ({typ}) := {rhs}\n\n'
 s+=f'''theorem decode_geometry_{tag}_through_block_{index:03d} :
    {raw_acc(prefix,selected[-1]['index']+1)}.reverse.mapM {decoder} = .ok {total} := by
  change ({push} {raw_acc(prefix,selected[0]['index'])}).reverse.mapM {decoder} = _
  rw [geometry_{tag}_block_{index:03d}_reverse]
'''
 if index==0:s+=f'  exact decode_geometry_{tag}_block_{index:03d}\n\n'
 else:s+=f'  rw [List.mapM_append, decode_geometry_{tag}_through_block_{index-1:03d}, decode_geometry_{tag}_block_{index:03d}]\n  rfl\n\n'
 names += [f'geometry_{tag}_block_{index:03d}_push_eq',f'geometry_{tag}_block_{index:03d}_reverse',f'decode_geometry_{tag}_block_{index:03d}',f'decode_geometry_{tag}_through_block_{index:03d}']
 s+=mark(f'{tag}_block_{index:03d}_complete')+foot(names)
 return save(short(key,index),s,{'original_key':key,'block':index,'selected_chunks':selected,'record_indices':ids,
  'all_original_schema_fields_preserved':True,'candidate_rationals':'exact source numerator/denominator expressions, no host normalization',
  'original_JSON_access':'List.get with kernel-checked bound, no fallback','decoder':decoder,
  'full_decodeGeometry_claimed':False,'schema_type':typ})

if __name__=='__main__':
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('key',choices=list(CONFIG));ap.add_argument('--block',type=int,default=0)
 a=ap.parse_args();m=block(a.key,a.block)
 print(json.dumps({'module':m['module'],'source':m['source'],'plan':m['planned_obligations']},indent=2))
