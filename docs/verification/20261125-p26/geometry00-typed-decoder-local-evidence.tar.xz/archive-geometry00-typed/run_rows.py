#!/usr/bin/env python3
"""Sequential new row owners only; reuse the accepted row000 pilot unchanged."""
from pathlib import Path
import json, subprocess, sys
import generate as g
import generate_rows as gen

ROOT = Path(__file__).resolve().parent
LOG = ROOT/'logs/rows-fields-orchestration.log'
assert not LOG.exists()


def step(module, mode, tag):
    with LOG.open('ab') as f:
        p = subprocess.run([sys.executable,str(ROOT/'run_local.py'),mode,module,tag],
                           stdout=f,stderr=subprocess.STDOUT)
    receipt = ROOT/'logs'/module.split('.')[-1]/(mode+'-'+tag+'-result.json')
    assert receipt.exists(), ('missing receipt', module, mode, p.returncode)
    d = json.loads(receipt.read_text())
    print(json.dumps({k:d[k] for k in ['module','mode','attempt','status','exit_code','elapsed_seconds','peak_rss_bytes']}),flush=True)
    assert p.returncode == 0 and d['status'] == 'succeeded', 'Stop on actual failure, no resource increase.'


def reuse_pilot():
    short = gen.row_short(0)
    source = ROOT/'project/ImbalancedChen'/(short+'.lean')
    obj = ROOT/'objects/ImbalancedChen'/(short+'.olean')
    for mode in ['normal','kernel']:
        d = json.loads((ROOT/'logs'/short/(mode+'-row-fields-v1-result.json')).read_text())
        assert d['status'] == 'succeeded' and d['source'] == g.fp(source) and d['object'] == g.fp(obj)
    print('Reused frozen GeometryRow000 pilot normal/kernel without recompilation.',flush=True)


reuse_pilot()
for block in range(14):
    for index in range(block*4,block*4+4):
        if index == 0:
            continue
        m = gen.generate_row(index)
        step(m['module'],'normal','row-fields-v1')
        step(m['module'],'kernel','row-fields-v1')
    m = gen.generate_block(block)
    step(m['module'],'normal','rows-compose-v1')
    step(m['module'],'kernel','rows-compose-v1')
print('P26_GEOMETRY00_ALL56_ORIGINAL_ROW_DECODERS_COMPLETE',flush=True)
