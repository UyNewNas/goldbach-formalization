# Cell 00: unchanged pure SourceJson parser by finite segments

The active task is to prove complete success of the existing pure parser on
the exact 195134-byte geometry witness for cell 00. `PROGRESS.json` is the
authoritative incremental record: an owner is counted as accepted only when
its current exact source and object have both a successful normal receipt and
a successful independent kernel receipt. The checkpoint is replaced atomically.

No P1 job or production source edit is performed by this package. The accepted
four-field package, all older supplier source/object bytes, and every passed
new owner remain frozen. Each new owner is checked with one Lean thread,
4 GiB externally monitored RSS and 180 seconds wall time. The archive
diagnostic's existing maxRecDepth and maxHeartbeats settings are retained.

## Fixed original input

The input is read with `Path.read_bytes()`, never newline-normalizing text I/O:

```text
/workspace/p26-original-inputs/eighth-third-minorant-extension-20261009-a23-s23_low-00-cell.witness.json
195134 bytes
SHA256 87e3c3da5a86a3ea16c1dcae3a5735ea8b0dc7db05d42b5f5cc3aae66cd54691
```

The original `SourceJson` source SHA is
`ae38e3ed3f11d8bc3350b9d35d1fed164a4494210ed993b2b99e8cd709f93424`.
Its grammar, integer rules, quoted-string escapes, duplicate-key rejection,
white-space function, structural fuel and all error branches are unchanged.
No Lean.Json parser or replacement reader is used.

The exact ASCII input makes byte offsets equal Char offsets. The host scanner
produces untrusted node spans, candidate AST data and sufficient fuel offsets.
Every generated result is checked through an equality for the original Lean
reader. A host hash or a host tokenization result is never a substitute for
that equality.

| Original field | Field span including its separator | Value span | Array items |
|---|---:|---:|---:|
| dimension | `[0,20)` including root opener | `[18,19)` | — |
| physical_jacobian | `[20,47)` | `[45,46)` | — |
| facet_original_indices | `[47,179)` | `[77,178)` | 11 |
| positive_normal_balance | `[179,359)` | `[210,358)` | 11 |
| normal_rank | `[359,380)` | `[378,379)` | — |
| active8_enumeration | `[380,40598)` | `[407,40597)` | 165 |
| vertices | `[40598,46975)` | `[40614,46974)` | 28 |
| vertex_values | `[46975,60449)` | `[46996,60448)` | 28 |
| all_original_constraint_minima | `[60449,62655)` | `[60487,62654)` | 97 |
| facet_vertices | `[62655,65221)` | `[62677,65220)` | 11 |
| face_ledger | `[65221,100416)` | `[65240,100415)` | 39 |
| simplices | `[100416,194777)` | `[100433,194776)` | 56 |
| physical_volume | `[194777,194942)` | `[194800,194941)` | — |
| integral_gap | `[194942,195132)` including root closer | `[194962,195129)` | — |

The final untouched tail is `[195132,195134)`, exactly CRLF. Rational-looking
quoted values remain original string tokens; the parser task does not convert
them to rationals or assert a numerical estimate.

## Three layers of original-reader proof

### Generic finite chunks

A nonfinal array chunk proves the following for arbitrary spare fuel, tail
and reverse accumulator:

```lean
SourceJson.array (fuel + beforeOffset)
    (SourceJson.white (chunkChars ++ tail)) acc =
  SourceJson.array (fuel + afterOffset)
    (SourceJson.white tail) (Push acc)
```

The final chunk returns `.ok (.arr ((Push acc).reverse), tail)`. It does not
replace an arbitrary accumulator with a fixed complete AST. Candidate chunks
contain their original commas or closing brackets. Numeric tokens therefore
retain a real non-digit delimiter, while the parent still checks the JSON
separator. None of these nonempty chunks begins with the empty-array special
case.

The first accepted large-array implementation binds each small chunk to the
original input. Later, not-yet-generated owners first compose their small
generic chunk theorems, then bind the complete block once. This reduces repeated
traversal of the original prefix without changing parser semantics. Earlier
accepted owners were not rewritten or recompiled.

### Reusable nested value certificates

`fragments.py` generates SourceJson-only child owners with this interface:

```lean
∀ fuel tail,
  SourceJson.value (fuel + need) (fragmentChars ++ tail) =
    .ok (fragmentValue, tail)
```

These owners have no `geometryChars00` dependency. Large object values are
split at original fields. Their object accumulators are fixed, real preceding
fields, so each original duplicate-key test is evaluated rather than assumed
away. Large child arrays are proved by the array chunk interface and supplied
to the unchanged object `Except.bind` continuation.

The first object field explicitly starts at `node.start + 1`, retaining the
original CRLF and indentation after `{`; the host tokenizer's first key
position alone would be insufficient. Final fields retain `}`. Arrays retain
`[` and `]`. No suffix is copied in full.

Data declarations use `noncomputable def` to retain their exact kernel terms
without generating unnecessary runtime code. This does not add axioms,
change reader results or alter the quoted characters.

### Exact original-input bindings and parent composition

Each actual block has a kernel-checked prefix equality and a `take_append_drop`
split, for example:

```lean
(geometryChars00.drop start).take count = blockChars
geometryChars00.drop start = blockChars ++ geometryChars00.drop end
```

Congruence transports the original reader through that split, and the generic
chunk theorem is instantiated with the exact original `drop end`. Its payload
and remaining tail are therefore tied to the complete accepted character input.

An object header exposes the original child `value` call and original
post-value continuation. The child certificate is applied opaquely. The comma
continuation is first proved with an arbitrary tail, then transported to the
actual remaining suffix. This detail prevents definitional reduction from
executing the entire remaining JSON while proving a small join.

## Observed failure and local corrections

The first Active8 parent join used `rw` followed by `rfl` on a concrete
remaining suffix. It reached the unchanged 4 GiB memory cap. The 21 array
owners had already passed and were retained. The revised join adds a generic
separator-continuation equality, then composes it by congruence and theorem
application. It passed normal and kernel under the same limit, without
changing any data or public reader conclusion. The failed source, manifest
and receipts remain under `revisions/` and the owner log directory.

The small generic `ParseFromValue00` helper initially needed the `Except.ok`
bind/pair match exposed before rewriting the tail. Two failed elaborations
are retained. The final helper uses `change` to expose that pure continuation
and closes the concrete empty-list branch by `rfl`. Its statement is unchanged
and its normal/kernel receipts passed. It does not contain a concrete parse
success assumption.

`CONTROLLED_PAUSE_01.json` records a driver pause after a complete owner had
passed, used to switch only future blocks to one actual-input binding each.
No compiler process was interrupted. A driver pause is not a Lean failure.

## Full-parser endpoint and representation boundary

The final source stages are designed to close:

```lean
SourceJson.value 195135 geometryChars00 =
  .ok (originalGeometryJson00, geometryChars00.drop 195132)

SourceJson.white (geometryChars00.drop 195132) = []

SourceJson.parseChars geometryChars00 = .ok originalGeometryJson00

SourceJson.parse geometryText00 = .ok originalGeometryJson00
```

The existing `SourceJsonCharInput.parse_ofList` theorem is reused to transport
the result to `geometryText00`, which is explicitly defined from the accepted
character input. `ParseFromValue00` is a separate generic elimination theorem:
it requires both the actual value-result equality and the empty-white-tail
equality, and the final owner supplies both. It does not run the parser again
and it does not need a decidable equality on the complete AST.

The actual success status is recorded in `PROGRESS.json` and, after completion,
the final delivery manifest. These statements do not by themselves establish
equality with an older String-literal archive declaration or a newer compact
tree input. The generic arbitrary-tail certificates can be reused with another
representation, but its exact span bindings must be proved separately. No
equality is transported merely from matching hashes.

This package addresses only the cell 00 geometry JSON pure parser. Other files,
typed archive decoding and the downstream numerical certificate remain
separate tasks.

## Scripts and immutable receipts

- `common.py`: fixed input, node planner, frozen supplier registry and owner manifests.
- `array_blocks.py`: accepted per-chunk binding template and original parent-field joins.
- `block_single_bind.py`: generic block composition followed by one actual slice binding.
- `fragments.py`: SourceJson-only nested child value certificates.
- `final_tail.py`: last scalar fields, complete value result, tail and parser composition.
- `run_owner.py`: exactly one new-owner normal or independent kernel attempt.
- `continue_all.py`: sequential remaining owners; stops at the first actual failed check.
- `checkpoint.py`: verified source/object fingerprints and atomic progress record.

An existing successful object is never overwritten. Normal failure prevents
kernel submission. Later attempts require a separately named receipt and a
preserved old-source revision. Every receipt records the unchanged input and
dependency hashes before and after, the exact command, resource limits,
elapsed time and peak sampled RSS. This is local diagnostic evidence, not P1
production acceptance.

## Observed late raw-slice binding limit and isolated repair

The initial `SimplicesArrayBlock01300` source `345db5d10c8626637f70c971005a0ec79f96556b6974f8f7b9cb92da37908dfc` completed its four generic chunk proof stages, then hit the unchanged 4 GiB RSS limit while elaborating `(geometryChars00.drop 188334).take 6442 = simplicesBlock013Chars00` by `rfl`: 19.118 s, sampled peak 4,298,854,400 B, no object. The exact source and manifest are retained in the SHA-named revisions directory with logs.

`raw_slice.py` isolates only that concrete list equality in `GeometrySlice18833400`, importing CharacterCore alone. The exact raw 6,442-character slice is quoted mechanically; the host quotation is candidate data, and `rfl` checks its relation to the original input definition. This new owner passed normal (20.877 s, 3,796,213,760 B) and independent kernel (11.007 s, 3,219,275,776 B). No parser or AST conclusion is a premise.

The revised block source `e226f5dc20fc0f67bb952ca2383d6575c77b370cf1281303444991c5dc740127` differs by one import and the prefix proof `geometryChars00_slice_188334_prefix.trans (by rfl)`. Its statements, generic parsing proofs, original tail and accumulator are unchanged. It passed normal (5.054 s, 2,125,971,456 B) and independent kernel (2.784 s, 1,761,210,368 B). The first 150 accepted new owners were not recompiled or edited. This is an expression/execution repair, with no mathematical estimate or parser change and no budget increase.
