#!/usr/bin/env python3
"""Sequential new-owner normal/kernel checks; stop at the first actual failure."""
import argparse
import json
from pathlib import Path
import subprocess
import sys
from array_blocks import *


def verify_existing(short, mode):
    paths=list((ROOT/'logs'/short).glob(mode+'-*-result.json'))
    if not paths:return False
    current=json.loads((ROOT/'owners'/(short+'.json')).read_text())['source']
    rows=[(p,json.loads(p.read_text())) for p in paths]
    matching=[(p,x) for p,x in rows if x['source']==current and x['status']=='succeeded' and x['exit_code']==0]
    if not matching:
        raise AssertionError(('Previous failure or source revision requires an explicit reviewed attempt',short,mode))
    for path,row in matching:
        assert fp(row['source']['path'])==row['source']
        assert fp(row['object']['path'])==row['object']
        assert fp(row['log']['path'])==row['log']
        assert row['source_object_invariants_before']==row['source_object_invariants_after']
    return True


def check_owner(m):
    short=m['module'].split('.')[-1]
    for mode in ['normal','kernel']:
        if verify_existing(short,mode):
            print(json.dumps({'module':m['module'],'mode':mode,'action':'reuse recorded success'}),flush=True)
            continue
        driver_log=ROOT/'logs'/short/(mode+'-initial-driver.log')
        driver_log.parent.mkdir(parents=True,exist_ok=True)
        assert not driver_log.exists()
        with driver_log.open('w') as out:
            done=subprocess.run([sys.executable,str(ROOT/'run_owner.py'),short,mode],
                                cwd=ROOT,stdout=out,stderr=subprocess.STDOUT)
        receipt=ROOT/'logs'/short/(mode+'-initial-result.json')
        if receipt.exists():
            row=json.loads(receipt.read_text())
            print(json.dumps({k:row[k] for k in ['module','mode','status','elapsed_seconds',
                              'peak_rss_bytes','source','object']}),flush=True)
        else:
            print(driver_log.read_text(),flush=True)
        assert done.returncode==0, ('Stop at first failed owner',short,mode,str(driver_log))
        verify_existing(short,mode)


if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('key',choices=list(CONFIG))
    ap.add_argument('--through-block',type=int)
    ap.add_argument('--include-field',action='store_true')
    ap.add_argument('--block-chunks',type=int,default=4)
    ap.add_argument('--max-items',type=int,default=2)
    ap.add_argument('--max-bytes',type=int,default=768)
    args=ap.parse_args()
    chunks=chunks_for(FIELDS[args.key][1].value,args.max_items,args.max_bytes)
    nblocks=(len(chunks)+args.block_chunks-1)//args.block_chunks
    last=nblocks-1 if args.through_block is None else args.through_block
    assert 0<=last<nblocks
    for i in range(last+1):
        selected=chunks[i*args.block_chunks:(i+1)*args.block_chunks]
        for c in selected:
            if c['oversize_child']:
                from fragments import ensure_fragment
                ensure_fragment(FIELDS[args.key][1].value.children[c['first']],check_owner)
        check_owner(generate_block(args.key,i,args.block_chunks,args.max_items,args.max_bytes))
    if args.include_field:
        assert last==nblocks-1
        check_owner(generate_field(args.key,args.block_chunks,args.max_items,args.max_bytes))
    print(json.dumps({'key':args.key,'through_block':last,'total_blocks':nblocks,
                      'field_completed':args.include_field,'status':'requested_new_owners_succeeded'}),flush=True)
