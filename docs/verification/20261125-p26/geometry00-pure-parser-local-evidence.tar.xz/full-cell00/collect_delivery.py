#!/usr/bin/env python3
"""Collect exact source/receipt closure after the whole parser theorem passes.

This performs no Lean invocation and never upgrades a partial checkpoint.
"""
from common import ROOT, RAW, FIELDS, base, fp, registry
import json
import re


def main():
    progress_path = ROOT / 'PROGRESS.json'
    progress = json.loads(progress_path.read_text())
    assert progress['whole_parse_success_verified']
    assert progress['new_owner_count'] == progress['accepted_new_owner_count']
    observed = {row['module']: row for row in progress['owners']}
    known = registry()
    target = 'ImbalancedChen.P2OriginalSaving19WholeParse00'
    ordered = []
    visited = set()

    def visit(module):
        if module in visited:
            return
        visited.add(module)
        row = known[module]
        assert fp(row['source']['path']) == row['source']
        text = open(row['source']['path']).read()
        imports = re.findall(r'(?m)^import\s+(ImbalancedChen\.\S+)', text)
        assert imports == row['project_imports'], (module, imports, row['project_imports'])
        for dep in imports:
            visit(dep)
        obj = fp(row['object']['path'])
        if 'sha256' in row['object']:
            assert obj == row['object']
        result = {'module': module, 'source': row['source'], 'object': obj,
                  'project_imports': imports, 'new_owner': module in observed}
        if module in observed:
            observation = observed[module]
            assert observation['source'] == row['source']
            assert observation['normal_kernel_passed']
            result['observed_checks'] = observation['observed_checks']
            result['source_manifest'] = observation['manifest']
            result['printed_axioms'] = []
            for mode, check in observation['observed_checks'].items():
                assert fp(check['receipt']['path']) == check['receipt']
                receipt = json.loads(open(check['receipt']['path']).read())
                assert receipt['mode'] == mode and receipt['status'] == 'succeeded'
                assert receipt['exit_code'] == 0 and receipt['source'] == row['source']
                assert receipt['object'] == obj
                assert fp(receipt['log']['path']) == receipt['log']
                assert receipt['source_object_invariants_before'] == receipt['source_object_invariants_after']
                assert receipt['rss_limit_bytes'] == 4 * 1024**3
                assert receipt['wall_seconds'] == 180
                assert receipt['peak_rss_bytes'] <= receipt['rss_limit_bytes']
                result['printed_axioms'] += receipt['printed_axioms']
            result['printed_axioms'] = sorted(set(result['printed_axioms']))
            assert set(result['printed_axioms']) <= {'propext', 'Quot.sound', 'Classical.choice'}
            declarations = re.findall(r'(?m)^(?:private\s+)?(?:theorem|lemma)\s+(\w+)', text)
            prints = re.findall(r'(?m)^#print axioms\s+(\w+)', text)
            assert sorted(declarations) == sorted(prints), (module, declarations, prints)
            assert not re.search(r'\b(?:sorry|admit|native_decide|unsafe)\b', text)
            assert not re.search(r'(?m)^\s*(?:axiom|constant)\s', text)
            result['theorem_count'] = len(declarations)
        ordered.append(result)

    visit(target)
    assert set(observed) <= visited, 'Unconnected new owner must be explained explicitly.'
    sources = [{'module': r['module'], 'source': r['source'],
                'project_imports': r['project_imports'], 'new_owner': r['new_owner']}
               for r in ordered]
    boundary = {
        'verified_input': 'CharacterCoreDiagnostic.geometryChars00 / String.ofList thereof',
        'raw_bytes': fp(base.FIXTURE),
        'raw_ascii_and_crlf_preserved': True,
        'production_compact_tree_binding_proved': False,
        'old_production_string_literal_equivalence_proved': False,
        'typed_geometry_decoder_or_validity_proved': False,
        'other_cell_files_proved': False,
        'remote_or_production_acceptance': False,
        'host_plan_is_proof': False,
    }
    manifest = {
        'target': target, 'status': 'LOCAL_NORMAL_AND_INDEPENDENT_KERNEL',
        'closure_count': len(ordered), 'new_owner_count': len(observed),
        'frozen_supplier_count': len(ordered) - len(observed),
        'topological_sources': sources, 'boundary': boundary,
        'generator': fp(ROOT / 'collect_delivery.py'),
    }
    inputs = {'target': target, 'closure_count': len(ordered), 'inputs': ordered}
    fields = [{'key': key, 'value_span': [field.value.start, field.value.end],
               'item_count': len(field.value.children) if field.value.kind == 'arr' else None}
              for key, (_, field) in FIELDS.items()]
    checks = [(row['module'], mode, check)
              for row in ordered if row['new_owner']
              for mode, check in row['observed_checks'].items()]
    maximum = max(checks, key=lambda x: x[2]['peak_rss_bytes'])
    validation = {
        'status': manifest['status'], 'target': target,
        'new_owner_count': len(observed), 'closure_count': len(ordered),
        'whole_parse_success_verified': True,
        'checked_theorem_count': sum(r.get('theorem_count', 0) for r in ordered),
        'printed_axioms_union': sorted({a for r in ordered for a in r.get('printed_axioms', [])}),
        'all_new_theorems_have_print_axioms': True,
        'fixed_limits': {'rss_bytes': 4 * 1024**3, 'wall_seconds': 180, 'threads': 1},
        'peak_successful_observation': {'module': maximum[0], 'mode': maximum[1], **maximum[2]},
        'historical_failed_attempts': progress['historical_failures'],
        'all_original_top_level_fields': fields,
        'final_tail_span': [195132, 195134], 'final_tail_bytes_hex': RAW[195132:].hex(),
        'input_length': len(RAW), 'original_value_fuel': len(RAW) + 1,
        'boundary': boundary, 'progress_snapshot': fp(progress_path),
        'source_manifest': None,
    }
    for name, data in [('SOURCE_MANIFEST.json', manifest), ('SOURCE_INPUTS.json', inputs)]:
        (ROOT / name).write_text(json.dumps(data, indent=2) + '\n')
    validation['source_manifest'] = fp(ROOT / 'SOURCE_MANIFEST.json')
    (ROOT / 'VALIDATION.json').write_text(json.dumps(validation, indent=2) + '\n')
    print(json.dumps({k: validation[k] for k in [
        'status', 'new_owner_count', 'closure_count', 'whole_parse_success_verified',
        'checked_theorem_count', 'printed_axioms_union', 'peak_successful_observation']}, indent=2))


if __name__ == '__main__':
    main()
