#!/usr/bin/env python3
"""Isolate an exact raw slice binding from the accumulated parser environment."""
from common import *


def generate_slice(start, end):
    assert 0 <= start < end <= len(RAW)
    short = f'P2OriginalSaving19GeometrySlice{start:06d}00'
    chars = f'geometrySlice{start:06d}Chars00'
    theorem = f'geometryChars00_slice_{start:06d}_prefix'
    source = f'''import ImbalancedChen.P2OriginalSaving19CharacterCore00

/-! Exact original-input slice only. Separating this definitional equality
from the parser-owner import environment avoids retaining accumulated parser
expressions during raw-list reduction. No parser theorem is assumed here. -/
namespace {NS}

set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false

noncomputable def {chars} : List Char := {base.chars(RAW,start,end)}

'''
    source += mark(f'raw_slice_{start:06d}_before_binding')
    source += f'''theorem {theorem} :
    (geometryChars00.drop {start}).take {end-start} = {chars} := by rfl

'''
    source += mark(f'raw_slice_{start:06d}_complete')
    source += foot([theorem])
    return save_owner(short, source,
        'Exact original raw slice, isolated from accumulated parser imports',
        {'raw_span': [start, end], 'no_parser_or_ast_conclusion': True,
         'whole_parse_success_claimed': False})


if __name__ == '__main__':
    print(json.dumps(generate_slice(188334,194776),indent=2))
