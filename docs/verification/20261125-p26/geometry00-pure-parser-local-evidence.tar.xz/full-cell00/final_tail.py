#!/usr/bin/env python3
"""Last scalar fields and the original parser's complete success composition."""
import argparse
import json
from common import *


def generate_consumer():
    short='P2OriginalSaving19ParseFromValue00'
    source='''import ImbalancedChen.P2OriginalSaving19SourceJsonCharInput

/-! Algebraic elimination of the unchanged original parser front end.
All arguments are arbitrary. Concrete value success and empty remaining white
input must both be supplied by separately checked theorems. -/
namespace ImbalancedChen.P2OriginalSaving19Archive.SourceJson

theorem parseChars_of_value_eq {cs : List Char} {parsed : SourceJson} {tail : List Char}
    (hvalue : value (cs.length + 1) cs = .ok (parsed, tail))
    (htail : white tail = []) :
    parseChars cs = .ok parsed := by
  unfold parseChars ImbalancedChen.P2OriginalSaving19CharInputBridge.parseChars
  rw [hvalue]
  change (if (white tail).isEmpty then Except.ok parsed
    else Except.error "unconsumed original JSON input") = Except.ok parsed
  rw [htail]
  rfl

#print axioms parseChars_of_value_eq

end ImbalancedChen.P2OriginalSaving19Archive.SourceJson
'''
    return save_owner(short,source,'generic original parser consumer; no concrete parse assumption discharged here',
                      {'generic_only':True,'whole_parse_success_claimed':False,
                       'existing_parse_ofList_reused':True})


def generate_physical_volume():
    index,f=FIELDS['physical_volume'];b=1+max(f.key.quoted_need,f.value.need)
    actual=len(RAW)-index
    short='P2OriginalSaving19PhysicalVolumePrefix00'
    source=head(['ImbalancedChen.P2OriginalSaving19SimplicesField00'],
                'Exact penultimate field physical_volume, including its original decimal-rational string and comma.')
    source+=f'''noncomputable def physicalVolumePrefixChars00 : List Char := {base.chars(RAW,f.prefix_start,f.prefix_end)}
noncomputable def physicalVolumeKey00 : String := String.ofList {base.quote_list(f.key.scalar)}
noncomputable def physicalVolumeValue00 : SourceJson := {base.lean_node(f.value)}
noncomputable def physicalVolumeAcc00 : List (String × SourceJson) :=
  (physicalVolumeKey00, physicalVolumeValue00) :: simplicesFieldAcc00

'''
    source+=mark('physical_volume_before_binding')
    source+=emit_split('geometryChars00_physical_volume',f.prefix_start,f.prefix_end,'physicalVolumePrefixChars00')
    source+=mark('physical_volume_after_binding')
    source+=f'''theorem object_physical_volume_prefix (fuel : Nat) (tail : List Char) :
    SourceJson.object (fuel + {b}) (SourceJson.white (physicalVolumePrefixChars00 ++ tail)) simplicesFieldAcc00 =
      SourceJson.object (fuel + {b-1}) (SourceJson.white tail) physicalVolumeAcc00 := by rfl

theorem geometryChars00_physical_volume_step :
    SourceJson.object {actual} (SourceJson.white (geometryChars00.drop {f.prefix_start})) simplicesFieldAcc00 =
      SourceJson.object {actual-1} (SourceJson.white (geometryChars00.drop {f.prefix_end})) physicalVolumeAcc00 := by
  exact (congrArg (fun s => SourceJson.object {actual} (SourceJson.white s) simplicesFieldAcc00)
      geometryChars00_physical_volume_split).trans
    (object_physical_volume_prefix {actual-b} (geometryChars00.drop {f.prefix_end}))

theorem geometryChars00_through_physical_volume :
    SourceJson.value {len(RAW)+1} geometryChars00 =
      SourceJson.object {actual-1} (SourceJson.white (geometryChars00.drop {f.prefix_end})) physicalVolumeAcc00 := by
  exact geometryChars00_through_simplices.trans geometryChars00_physical_volume_step

'''
    source+=mark('physical_volume_complete')+foot([
        'geometryChars00_physical_volume_prefix','geometryChars00_physical_volume_split',
        'object_physical_volume_prefix','geometryChars00_physical_volume_step',
        'geometryChars00_through_physical_volume'])
    return save_owner(short,source,'penultimate scalar field original-reader transition',
                      {'field':f.plan(),'actual_object_fuels':[actual,actual-1],
                       'whole_parse_success_claimed':False})


def generate_whole_value():
    index,f=FIELDS['integral_gap'];b=1+max(f.key.quoted_need,f.value.need)
    actual=len(RAW)-index
    assert f.prefix_end==ROOT_NODE.end and f.separator=='}'
    short='P2OriginalSaving19WholeValue00'
    source=head(['ImbalancedChen.P2OriginalSaving19PhysicalVolumePrefix00'],
                'Exact final integral_gap field and the closing original root object. '
                'The full original value reader returns the certified AST and the untouched original CRLF tail.')
    source+=f'''noncomputable def integralGapPrefixChars00 : List Char := {base.chars(RAW,f.prefix_start,f.prefix_end)}
noncomputable def integralGapKey00 : String := String.ofList {base.quote_list(f.key.scalar)}
noncomputable def integralGapValue00 : SourceJson := {base.lean_node(f.value)}
noncomputable def originalGeometryJson00 : SourceJson :=
  .obj (((integralGapKey00, integralGapValue00) :: physicalVolumeAcc00).reverse)

'''
    source+=mark('integral_gap_before_binding')
    source+=emit_split('geometryChars00_integral_gap',f.prefix_start,f.prefix_end,'integralGapPrefixChars00')
    source+=mark('integral_gap_after_binding')
    source+=f'''theorem object_integral_gap_prefix (fuel : Nat) (tail : List Char) :
    SourceJson.object (fuel + {b}) (SourceJson.white (integralGapPrefixChars00 ++ tail)) physicalVolumeAcc00 =
      .ok (originalGeometryJson00, tail) := by rfl

theorem geometryChars00_integral_gap_step :
    SourceJson.object {actual} (SourceJson.white (geometryChars00.drop {f.prefix_start})) physicalVolumeAcc00 =
      .ok (originalGeometryJson00, geometryChars00.drop {f.prefix_end}) := by
  exact (congrArg (fun s => SourceJson.object {actual} (SourceJson.white s) physicalVolumeAcc00)
      geometryChars00_integral_gap_split).trans
    (object_integral_gap_prefix {actual-b} (geometryChars00.drop {f.prefix_end}))

theorem geometryChars00_whole_value :
    SourceJson.value {len(RAW)+1} geometryChars00 =
      .ok (originalGeometryJson00, geometryChars00.drop {f.prefix_end}) := by
  exact geometryChars00_through_physical_volume.trans geometryChars00_integral_gap_step

'''
    source+=mark('whole_value_complete')+foot([
        'geometryChars00_integral_gap_prefix','geometryChars00_integral_gap_split',
        'object_integral_gap_prefix','geometryChars00_integral_gap_step','geometryChars00_whole_value'])
    return save_owner(short,source,'complete original value reader success, with exact original remaining tail',
                      {'field':f.plan(),'whole_value_success_theorem':True,
                       'whole_parse_success_claimed':False,'tail_offset':f.prefix_end})


def generate_whole_parse():
    end=ROOT_NODE.end;n=len(RAW);remaining=n-end
    short='P2OriginalSaving19WholeParse00'
    source=head(['ImbalancedChen.P2OriginalSaving19WholeValue00',
                 'ImbalancedChen.P2OriginalSaving19ParseFromValue00'],
                'Complete unchanged SourceJson parser success for the exact accepted geometryChars00 input '
                'and its explicitly defined geometryText00. The original remaining CRLF is checked and removed by original white.')
    source+=f'noncomputable def geometryTailChars00 : List Char := {base.chars(RAW,end,n)}\n\n'
    source+=mark('whole_parse_before_tail_binding')
    source+=emit_split('geometryChars00_final_tail',end,n,'geometryTailChars00')
    source+=f'''theorem geometryChars00_end_drop : geometryChars00.drop {n} = [] := by
  simpa only [geometryChars00_length] using List.drop_length (l := geometryChars00)

theorem geometryChars00_exact_tail : geometryChars00.drop {end} = geometryTailChars00 := by
  exact geometryChars00_final_tail_split.trans (by rw [geometryChars00_end_drop, List.append_nil])

theorem geometryChars00_white_tail : SourceJson.white (geometryChars00.drop {end}) = [] := by
  exact (congrArg SourceJson.white geometryChars00_exact_tail).trans (by rfl)

theorem geometryChars00_parseChars :
    SourceJson.parseChars geometryChars00 = .ok originalGeometryJson00 := by
  apply SourceJson.parseChars_of_value_eq
  · simpa only [geometryChars00_length] using geometryChars00_whole_value
  · exact geometryChars00_white_tail

theorem geometryText00_parse :
    SourceJson.parse geometryText00 = .ok originalGeometryJson00 := by
  exact (SourceJson.parse_ofList geometryChars00).trans geometryChars00_parseChars

'''
    source+=mark('whole_parse_complete')+foot([
        'geometryChars00_final_tail_prefix','geometryChars00_final_tail_split',
        'geometryChars00_end_drop','geometryChars00_exact_tail','geometryChars00_white_tail',
        'geometryChars00_parseChars','geometryText00_parse'])
    return save_owner(short,source,'complete original pure SourceJson parser success for cell00 only',
                      {'tail_span':[end,n],'tail_ascii':RAW[end:].decode('ascii'),
                       'whole_parse_success_theorem':True,
                       'original_reader_and_white_unchanged':True,
                       'old_String_literal_equivalence_claimed':False,
                       'other_25_files_proved':False,'typed_archive_decode_claimed':False})


if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('stage',choices=['consumer','physical-volume','whole-value','whole-parse'])
    args=ap.parse_args()
    m={'consumer':generate_consumer,'physical-volume':generate_physical_volume,
       'whole-value':generate_whole_value,'whole-parse':generate_whole_parse}[args.stage]()
    print(json.dumps({'module':m['module'],'source':m['source'],'plan':m['planned_obligations']},indent=2))
