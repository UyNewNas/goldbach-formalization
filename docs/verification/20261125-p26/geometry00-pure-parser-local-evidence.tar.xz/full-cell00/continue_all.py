#!/usr/bin/env python3
"""Continue the authorized single-cell proof chain, with a checkpoint per owner."""
import json
import subprocess
import sys
from advance_array import check_owner
from array_blocks import *
from fragments import ensure_fragment
from final_tail import *


def checkpoint():
    done=subprocess.run([sys.executable,str(ROOT/'checkpoint.py')],cwd=ROOT,
                        stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    assert done.returncode==0,done.stdout
    d=json.loads(done.stdout)
    print(json.dumps({'checkpoint_accepted_owners':d['accepted_new_owner_count'],
                      'whole_parse_success_verified':d['whole_parse_success_verified']}),flush=True)


def checked(m):
    check_owner(m)
    checkpoint()


checked(generate_consumer())
for key,max_items in [('vertex_values',2),('all_original_constraint_minima',16),
                      ('facet_vertices',2),('face_ledger',2),('simplices',2)]:
    node=FIELDS[key][1].value
    chunks=chunks_for(node,max_items,768)
    count=(len(chunks)+3)//4
    for i in range(count):
        for c in chunks[i*4:(i+1)*4]:
            if c['oversize_child']:
                ensure_fragment(node.children[c['first']],checked)
        checked(generate_block(key,i,4,max_items,768))
    checked(generate_field(key,4,max_items,768))
    print(json.dumps({'field_completed':key,'array_items':len(node.children),
                      'original_input_end':FIELDS[key][1].prefix_end}),flush=True)
checked(generate_physical_volume())
checked(generate_whole_value())
checked(generate_whole_parse())
print(json.dumps({'status':'CELL00_ORIGINAL_PURE_PARSER_COMPLETE_LOCAL_NORMAL_KERNEL',
                  'production_acceptance_claimed':False,'other_25_files_proved':False}),flush=True)
