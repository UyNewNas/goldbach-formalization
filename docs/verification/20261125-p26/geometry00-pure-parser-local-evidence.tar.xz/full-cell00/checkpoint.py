#!/usr/bin/env python3
"""Record observed per-owner progress; never infer a whole-parse success."""
from pathlib import Path
import json
import os
import sys
from common import ROOT, fp

rows=[];failures=[]
for manifest_path in sorted((ROOT/'owners').glob('*.json')):
    m=json.loads(manifest_path.read_text());short=m['module'].split('.')[-1]
    assert fp(m['source']['path'])==m['source']
    modes={}
    for mode in ['normal','kernel']:
        for result_path in sorted((ROOT/'logs'/short).glob(mode+'-*-result.json')):
            rec=json.loads(result_path.read_text())
            if rec['status']!='succeeded':
                failures.append({'module':m['module'],'mode':mode,'status':rec['status'],
                                 'source':rec['source'],'receipt':fp(result_path),
                                 'elapsed_seconds':rec['elapsed_seconds'],
                                 'peak_rss_bytes':rec['peak_rss_bytes']})
            if rec['source']!=m['source'] or rec['status']!='succeeded':continue
            assert rec['exit_code']==0 and rec['object']==fp(rec['object']['path'])
            assert rec['log']==fp(rec['log']['path'])
            assert rec['source_object_invariants_before']==rec['source_object_invariants_after']
            modes[mode]={'receipt':fp(result_path),'object':rec['object'],
                         'elapsed_seconds':rec['elapsed_seconds'],'peak_rss_bytes':rec['peak_rss_bytes']}
    rows.append({'module':m['module'],'source':m['source'],'scope':m['scope'],
                 'normal_kernel_passed':set(modes)=={'normal','kernel'},'observed_checks':modes,
                 'manifest':fp(manifest_path),'planned_obligations':m['planned_obligations']})
passed=[r for r in rows if r['normal_kernel_passed']]
whole=[r for r in passed if r['planned_obligations'].get('whole_parse_success_theorem',False)]
summary={'scope':'cell00 original pure SourceJson reader; local diagnostic only',
         'new_owner_count':len(rows),'accepted_new_owner_count':len(passed),
         'whole_parse_success_verified':bool(whole),'owners':rows,'historical_failures':failures,
         'production_modified':False,'remote_jobs_submitted':False,
         'frozen_prior_suppliers':fp(ROOT.parent/'SOURCE_INPUTS.json')}
temporary=ROOT/('PROGRESS-'+str(os.getpid())+'.tmp')
temporary.write_text(json.dumps(summary,indent=2)+'\n')
temporary.replace(ROOT/'PROGRESS.json')
print(json.dumps({'new_owner_count':len(rows),'accepted_new_owner_count':len(passed),
                  'whole_parse_success_verified':bool(whole),'historical_failed_attempts':len(failures),
                  'progress':fp(ROOT/'PROGRESS.json')},indent=2))
if (ROOT/'PAUSE_AFTER_OWNER').exists():
    print('CONTROLLED_DRIVER_PAUSE_AFTER_COMPLETED_OWNER; all completed Lean receipts remain unchanged.',flush=True)
    raise SystemExit(75)
