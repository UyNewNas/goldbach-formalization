import Lean

/-! Synthetic two-chunk diagnostic only. No Saving19 source fixture is read.
The original String is independently literal, and every chunk binding is proved
by closed rfl; the full toList equality uses only these bindings and library
String.toList_ofList / String.toList_append. Host code produces data only. -/
namespace ImbalancedChen.P2OriginalSaving19StringChunks2KiBProbe

set_option maxRecDepth 1000000
set_option Elab.async false

open Lean Elab Term

elab "syntheticRawChars% " s:str : term => do
  return toExpr s.getString.toList

def originalText : String := "chunk 00\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0chunk 01\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0"

#check originalText

def chunk0 : String := "chunk 00\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0"

noncomputable def chars0 : List Char := syntheticRawChars% "chunk 00\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0"

#check chars0

theorem chunk0_eq_ofList : chunk0 = String.ofList chars0 := by
  rfl

#check chunk0_eq_ofList

theorem chunk0_toList_eq : chunk0.toList = chars0 := by
  rw [chunk0_eq_ofList, String.toList_ofList]


def chunk1 : String := "chunk 01\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0"

noncomputable def chars1 : List Char := syntheticRawChars% "chunk 01\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0"

#check chars1

theorem chunk1_eq_ofList : chunk1 = String.ofList chars1 := by
  rfl

#check chunk1_eq_ofList

theorem chunk1_toList_eq : chunk1.toList = chars1 := by
  rw [chunk1_eq_ofList, String.toList_ofList]

theorem original_eq_append : originalText = chunk0 ++ chunk1 := by
  rfl

#check original_eq_append

theorem original_toList_eq : originalText.toList = chars0 ++ chars1 := by
  rw [original_eq_append, String.toList_append, chunk0_toList_eq, chunk1_toList_eq]

#check original_toList_eq

#print axioms chunk0_eq_ofList
#print axioms chunk1_eq_ofList
#print axioms original_eq_append
#print axioms original_toList_eq

end ImbalancedChen.P2OriginalSaving19StringChunks2KiBProbe
