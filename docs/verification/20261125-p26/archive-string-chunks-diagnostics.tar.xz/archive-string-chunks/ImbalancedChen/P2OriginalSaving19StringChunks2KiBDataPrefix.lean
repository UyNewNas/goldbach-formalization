import Lean

/-! Synthetic data-only prefix of the two-chunk candidate.
All five data definitions and the emitting elaborator are copied verbatim.
No theorem, String conversion equality, parser, or actual fixture is present.
Direct stderr markers are flushed and stderr message capture is disabled. -/
namespace ImbalancedChen.P2OriginalSaving19StringChunks2KiBDataPrefix

set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false

open Lean Elab Term

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_DATA_PREFIX before_emitter"
  err.flush

elab "syntheticRawChars% " s:str : term => do
  return toExpr s.getString.toList

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_DATA_PREFIX after_emitter"
  err.flush

def originalText : String := "chunk 00\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0chunk 01\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0"

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_DATA_PREFIX after_originalText"
  err.flush

def chunk0 : String := "chunk 00\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0"

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_DATA_PREFIX after_chunk0"
  err.flush

noncomputable def chars0 : List Char := syntheticRawChars% "chunk 00\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0"

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_DATA_PREFIX after_chars0"
  err.flush

def chunk1 : String := "chunk 01\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0"

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_DATA_PREFIX after_chunk1"
  err.flush

noncomputable def chars1 : List Char := syntheticRawChars% "chunk 01\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0,1,2,3,4,5,6,7,8,9]}\n{\"synthetic_cell\":00,\"raw\":\"A23/s23_low\",\"numbers\":[0"

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_DATA_PREFIX after_chars1"
  err.flush

run_cmd do
  let err ← IO.getStderr
  err.putStrLn "P26_DATA_PREFIX all_data_complete"
  err.flush

end ImbalancedChen.P2OriginalSaving19StringChunks2KiBDataPrefix
