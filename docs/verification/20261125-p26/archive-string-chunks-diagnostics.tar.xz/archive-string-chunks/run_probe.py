from pathlib import Path
import hashlib,json,os,signal,subprocess,sys,time
import psutil
ROOT=Path(__file__).resolve().parent
TOOLCHAIN=Path('/workspace/library-files/p34-runtime/lean-4.33.0-rc1-linux')
MODE=sys.argv[1];MODULE=sys.argv[2]
assert MODE in {'normal','kernel'}
assert all(x.isalnum() or x in '._' for x in MODULE)
source=ROOT/(MODULE.replace('.','/')+'.lean')
obj=ROOT/'objects'/(MODULE.replace('.','/')+'.olean')
obj.parent.mkdir(parents=True,exist_ok=True)
phase=MODE+'-'+MODULE.split('.')[-1]
log=ROOT/'logs'/(phase+'.log')
limit=2*1024*1024*1024;wall_limit=60
if MODE=='normal':argv=[str(TOOLCHAIN/'bin/lean'),'-j1','-DmaxRecDepth=1000000','-DmaxHeartbeats=0','-o',str(obj),str(source)]
else:argv=[str(TOOLCHAIN/'bin/leanchecker'),'-v',MODULE]
env=os.environ.copy();env['LEAN_PATH']=str(ROOT/'objects');env['LEAN_NUM_THREADS']='1';env['OMP_NUM_THREADS']='1'
record={'mode':MODE,'module':MODULE,'argv':argv,'cwd':str(ROOT),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'rss_limit_bytes':limit,'timeout_seconds':wall_limit,'rss_sample_seconds':0.02,'started_unix':time.time(),'normal_or_kernel_only':True}
(ROOT/'logs'/(phase+'-command.json')).write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record),flush=True)
start=time.monotonic();peak=0;cpu_peak=0.;reason=None
with log.open('w') as output:
 p=subprocess.Popen(argv,cwd=ROOT,env=env,stdout=output,stderr=subprocess.STDOUT,start_new_session=True)
 process=psutil.Process(p.pid)
 while True:
  rc=p.poll()
  rss=0
  try:
   processes=[process]+process.children(recursive=True)
   rss=sum(q.memory_info().rss for q in processes if q.is_running())
   cpu=sum(q.cpu_times().user+q.cpu_times().system for q in processes if q.is_running())
   peak=max(peak,rss);cpu_peak=max(cpu_peak,cpu)
  except (psutil.NoSuchProcess,psutil.AccessDenied):pass
  elapsed=time.monotonic()-start
  if rc is not None:break
  if rss>limit:reason='memory_limit'
  elif elapsed>wall_limit:reason='timeout'
  if reason:
   os.killpg(p.pid,signal.SIGKILL)
   break
  time.sleep(0.02)
 rc=p.wait()
record.update({'exit_code':rc,'status':reason or ('succeeded' if rc==0 else 'failed'),'elapsed_seconds':time.monotonic()-start,'peak_rss_bytes':peak,'sampled_cpu_seconds':cpu_peak,'log_bytes':log.stat().st_size,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'object_exists':obj.exists()})
if obj.exists():record['object_sha256']=hashlib.sha256(obj.read_bytes()).hexdigest();record['object_bytes']=obj.stat().st_size
(ROOT/'logs'/(phase+'-result.json')).write_text(json.dumps(record,indent=2)+'\n')
print(log.read_text(),end='',flush=True);print(json.dumps(record),flush=True)
sys.exit(0 if record['status']=='succeeded' else 1)
