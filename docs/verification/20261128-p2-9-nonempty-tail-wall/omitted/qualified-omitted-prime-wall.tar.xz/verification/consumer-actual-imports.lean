import Lean
open Lean
def p29ResolvedImports : IO Unit := do
  initSearchPath (← findSysroot)
  let names : Array Name := #[`ImbalancedChen.P2FiniteMarkedGamma5OmittedPrimeWall]
  let env ← importModules (names.map fun n => { module := n }) {}
  for idx in [:env.header.modules.size] do
    let mod := env.header.modules[idx]!
    let data := env.header.moduleData[idx]!
    let p ← findOLean mod.module
    let mut parts : Array System.FilePath := #[p]
    if data.isModule then
      parts := parts.push (OLeanLevel.server.adjustFileName p)
      parts := parts.push (OLeanLevel.private.adjustFileName p)
    let irSig := p.withExtension "ir.sig"
    if ← irSig.pathExists then
      parts := parts.push irSig
      parts := parts.push (p.withExtension "ir")
    let partRows ← parts.mapM fun q => do
      let resolved ← IO.FS.realPath q
      return Json.mkObj [
        ("path", toJson q.toString),
        ("resolved_path", toJson resolved.toString)]
    IO.println ("P29_ACTUAL_IMPORT " ++ (Json.mkObj [
      ("module", toJson mod.module.toString),
      ("is_module", toJson data.isModule),
      ("direct_imports", toJson (data.imports.map fun i => i.module.toString)),
      ("parts", toJson partRows)]).compress)
#eval p29ResolvedImports
