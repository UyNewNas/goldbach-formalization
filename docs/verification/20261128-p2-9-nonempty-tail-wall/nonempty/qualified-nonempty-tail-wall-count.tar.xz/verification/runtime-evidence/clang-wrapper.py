#!/usr/bin/env python3
import fcntl, json, os, pathlib, re, sys
C = {'environment': {'LEAN_SYSROOT': '/workspace/p29-nonempty-20261128-v2/runtime/p0-ci-shadow-toolchain', 'LAKE_OVERRIDE_LEAN': 'true', 'LEAN_NUM_THREADS': '2', 'ELAN_TOOLCHAIN': 'leanprover/lean4:v4.33.0-rc1', 'P0_CI_GUARD_STATE': '/workspace/p29-nonempty-20261128-v2/verification/runtime-evidence/state.json'}, 'shadow': '/workspace/p29-nonempty-20261128-v2/runtime/p0-ci-shadow-toolchain', 'realbin': '/workspace/toolchains/lean-4.33.0-rc1-linux/bin', 'slot': '/workspace/p29-nonempty-20261128-v2/verification/runtime-evidence/compiler.lock', 'log': '/workspace/p29-nonempty-20261128-v2/verification/runtime-evidence/compiler-commands.jsonl', 'tools': ['lean', 'leanir', 'clang', 'leanc', 'llvm-ar']}
def require(ok, message):
    if not ok: raise RuntimeError('CI runtime guard: ' + message)
def normalize_lean_args(args):
    # Exact fixed-pin src/util/shell.cpp getopt spellings. -t is TRUST;
    # -T/--timeout is a different option and must remain unchanged.
    controlled = {'--trust', '--threads', '--memory'}
    long_required = {'--root', '--plugin', '--load-dynlib', '--setup', '--error',
                     '--incr-save', '--incr-load', '--incr-header-save', '--tstack', '--debug'}
    short_required = set('DoibcCtjRMTpEYZHs')
    short_noarg = set('PdqgvVh012rae')
    clean = []
    i = 0
    while i < len(args):
        a = args[i]
        require(a != '--run' and a != '-r', 'program execution is outside this build-only wrapper')
        if a == '--':
            clean.extend(args[i:]); break
        if a.startswith('--'):
            key, sep, value = a.partition('=')
            require(not (len(key) > 2 and '--run'.startswith(key)),
                    'program execution is outside this build-only wrapper')
            if key in controlled:
                if not sep:
                    i += 1
                    require(i < len(args), 'missing resource argument')
                    value = args[i]
                require(re.fullmatch(r'[0-9]+', value), 'bad resource argument')
            else:
                require(not (len(key) > 2 and any(n.startswith(key) for n in controlled)),
                        'abbreviated resource argument: ' + a)
                clean.append(a)
                if key in long_required and not sep:
                    i += 1
                    require(i < len(args), 'missing option argument')
                    clean.append(args[i])
        elif a.startswith('-') and a != '-':
            # Parse clusters too: getopt accepts -qj8 as -q -j8.
            j = 1
            while j < len(a):
                flag = a[j]
                require(flag != 'r', 'program execution is outside this build-only wrapper')
                require(flag in short_required or flag in short_noarg, 'unknown short option: ' + a)
                if flag in short_required:
                    value = a[j+1:]
                    if not value:
                        i += 1
                        require(i < len(args), 'missing option argument')
                        value = args[i]
                    if flag in 'tjM':
                        require(re.fullmatch(r'[0-9]+', value), 'bad resource argument')
                    else:
                        clean.extend(['-' + flag, value])
                    break
                clean.append('-' + flag)
                j += 1
        else:
            clean.append(a)
        i += 1
    return ['-t0', '-j2', '-M12288', *clean]

for key, value in C['environment'].items():
    require(os.environ.get(key) == value, 'changed environment: ' + key)
for key, name in [('LEAN', 'lean'), ('LEAN_AR', 'llvm-ar')]:
    if key in os.environ:
        require(os.environ[key] == C['shadow'] + '/bin/' + name, 'bypassed ' + key)
require(not os.environ.get('LEAN_CC'), 'custom LEAN_CC bypasses bundled compiler')
name = pathlib.Path(sys.argv[0]).name
require(name in C['tools'], 'unknown compiler')
args = sys.argv[1:]
if name == 'lean':
    args = normalize_lean_args(args)
# One inherited flock across Lean and native compiler descendants. Never trust
# a naked HELD flag: require a live ancestor holding the exact lock descriptor.
held = os.environ.get('P0_COMPILER_SLOT_HELD')
if held:
    require(held.isdigit(), 'invalid slot owner')
    owner = int(held)
    # Permit only this direct, read-only metadata child from a Lean owner.
    cache_prefix_probe = (os.environ.get('P0_COMPILER_SLOT_TOOL') == 'lean'
                          and name == 'lean' and sys.argv[1:] == ['--print-prefix']
                          and os.getppid() == owner)
    # Keep the existing fixed Leanc.lean -> clang child and its inherited lock.
    # LeanIR emits C internally; no other nested compiler command is admitted.
    leanc_clang_child = (os.environ.get('P0_COMPILER_SLOT_TOOL') == 'leanc'
                         and name == 'clang' and os.getppid() == owner)
    require(cache_prefix_probe or leanc_clang_child,
            'unreviewed nested compiler chain')
    ancestor = os.getppid()
    while ancestor > 1 and ancestor != owner:
        ancestor = int(pathlib.Path('/proc', str(ancestor), 'stat').read_text().rsplit(')', 1)[1].split()[1])
    require(ancestor == owner, 'slot owner is not an ancestor')
    fdnum = os.environ.get('P0_COMPILER_SLOT_FD', '')
    require(fdnum.isdigit(), 'invalid slot descriptor')
    lockstat = os.stat(C['slot'])
    ownerstat = os.stat('/proc/' + held + '/fd/' + fdnum)
    require((lockstat.st_dev, lockstat.st_ino) == (ownerstat.st_dev, ownerstat.st_ino), 'slot descriptor mismatch')
else:
    fd = os.open(C['slot'], os.O_CREAT | os.O_WRONLY, 0o600)
    fcntl.flock(fd, fcntl.LOCK_EX)
    os.set_inheritable(fd, True)
    os.environ['P0_COMPILER_SLOT_HELD'] = str(os.getpid())
    os.environ['P0_COMPILER_SLOT_FD'] = str(fd)
    os.environ['P0_COMPILER_SLOT_TOOL'] = name
compiler = (C['shadow'] + '/bin/lean-runtime' if name == 'lean'
            else C['realbin'] + '/' + name)
cmd = [compiler, *args]
record = {'pid': os.getpid(), 'tool': name, 'command': cmd,
          'input_args': sys.argv[1:], 'slot_owner': os.environ['P0_COMPILER_SLOT_HELD'],
          'cwd': os.getcwd(), 'sysroot': os.environ['LEAN_SYSROOT']}
# One append under a separate short log lock, including nested children.
with open(C['log'], 'a') as log:
    fcntl.flock(log, fcntl.LOCK_EX)
    log.write(json.dumps(record) + '\n')
os.execv(cmd[0], cmd)
