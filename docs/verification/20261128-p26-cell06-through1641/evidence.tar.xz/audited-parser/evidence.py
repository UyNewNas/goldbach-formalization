"""Immutable host receipts and canonical/shared audit validation (not executed proofs)."""
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import shutil
import subprocess
import time
import uuid
from contextlib import contextmanager

ALLOWED = {'propext', 'Classical.choice', 'Quot.sound'}
_TRANSACTION = None


@contextmanager
def verification_transaction():
    """Deduplicate only a single preflight/recovery transaction."""
    global _TRANSACTION
    previous=_TRANSACTION;state={'seen':set(),'json':{},'baselines':{},'validated_baselines':set(),'actual_checks':0};_TRANSACTION=state
    try:yield state
    finally:_TRANSACTION=previous


@contextmanager
def uncached_verification():
    global _TRANSACTION
    previous=_TRANSACTION;_TRANSACTION=None
    try:yield
    finally:_TRANSACTION=previous


def environment_sha256(env):
    return hashlib.sha256(json.dumps(env,sort_keys=True,separators=(',',':')).encode()).hexdigest()


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def pin(path):
    path = Path(path)
    digest = hashlib.sha256()
    size = 0
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block); size += len(block)
    return {'path': str(path.absolute()), 'bytes': size, 'sha256': digest.hexdigest()}


def check(item):
    key=(item['path'],item['bytes'],item['sha256'])
    if _TRANSACTION is not None and key in _TRANSACTION['seen']:return
    require(pin(item['path']) == item, 'Pinned file changed: ' + item['path'])
    if _TRANSACTION is not None:
        _TRANSACTION['seen'].add(key);_TRANSACTION['actual_checks']+=1


def read_pinned(item):
    check(item);key=(item['path'],item['bytes'],item['sha256'])
    if _TRANSACTION is not None and key in _TRANSACTION['json']:return _TRANSACTION['json'][key]
    result=read(item['path'])
    if _TRANSACTION is not None:_TRANSACTION['json'][key]=result
    return result


def read(path):
    return json.loads(Path(path).read_text())


def dump_new(path, value):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as out:
        json.dump(value, out, ensure_ascii=False, indent=2); out.write('\n')
        out.flush(); os.fsync(out.fileno())
    return pin(path)


def unique_pins(items):
    result = {}
    for item in items:
        previous = result.setdefault(item['path'], item)
        require(previous == item, 'Conflicting pins: ' + item['path'])
    return [result[k] for k in sorted(result)]


def check_all(items):
    for item in items:
        check(item)


def expand_inputs(spec):
    """Resolve one immutable shared baseline plus an explicit per-step delta."""
    if isinstance(spec,list):return unique_pins(spec) # Synthetic fixtures only.
    require(set(spec)=={'baseline','delta'},'Unknown input-reference schema')
    base=read_pinned(spec['baseline'])
    require(isinstance(base,list),'Baseline must be a complete pin array')
    return unique_pins(base+[spec['baseline']]+spec['delta'])


def baseline_map(spec):
    item=spec['baseline'];key=(item['path'],item['bytes'],item['sha256'])
    if _TRANSACTION is not None and key in _TRANSACTION['baselines']:
        check(item);return key,_TRANSACTION['baselines'][key]
    base=read_pinned(item);mapped={i['path']:i for i in base}
    require(len(mapped)==len(base),'Duplicate paths in shared baseline')
    if _TRANSACTION is not None:_TRANSACTION['baselines'][key]=mapped
    return key,mapped


def input_count(spec):
    if isinstance(spec,list):return len(unique_pins(spec))
    _,mapped=baseline_map(spec);extra={spec['baseline']['path']}
    for item in spec['delta']:
        if item['path'] in mapped:require(mapped[item['path']]==item,'Delta conflicts with baseline')
        else:extra.add(item['path'])
    return len(mapped)+len(extra-set(mapped))


def check_inputs(spec):
    if isinstance(spec,list):check_all(unique_pins(spec));return
    key,mapped=baseline_map(spec)
    if _TRANSACTION is None or key not in _TRANSACTION['validated_baselines']:
        check_all(mapped.values())
        if _TRANSACTION is not None:_TRANSACTION['validated_baselines'].add(key)
    check(spec['baseline'])
    for item in unique_pins(spec['delta']):
        if item['path'] in mapped:require(mapped[item['path']]==item,'Delta conflicts with baseline')
        check(item)


def check_receipt_chain(seal_pin,expected_contract=None,expected_key=None,expected_mode=None,expected_environment_sha=None,expected_argv=None):
    check(seal_pin); seal=read(seal_pin['path'])
    require(seal.get('formal_acceptance') is True,'Unaccepted checkpoint seal')
    identity=seal['identity']
    for actual,expected,label in [(identity['contract'],expected_contract,'stage contract'),(identity['key'],expected_key,'owner key'),
                                  (identity['mode'],expected_mode,'mode'),(identity['environment_sha256'],expected_environment_sha,'final environment'),
                                  (identity['argv'],expected_argv,'argv')]:
        if expected is not None:require(actual==expected,'Receipt does not match expected '+label)
    check(seal['result']); result=read(seal['result']['path'])
    require(result['exit_code']==0 and not result.get('stop_reason'),'Accepted checkpoint has failed result')
    check(result['command']); command=read(result['command']['path'])
    require(command['identity']==seal['identity'],'Checkpoint identity chain differs')
    attempt=Path(result['command']['path']).parent
    expected_actual=[str(attempt/'normal.olean') if a=='__NORMAL_OUTPUT__' else a for a in identity['argv']]
    require(command['actual_argv']==expected_actual,'Actual checkpoint argv differs')
    if identity['mode']=='normal':
        require(result.get('object') is not None and result['object']['path']==str(attempt/'normal.olean'),'Wrong permanent normal artifact path')
    check(command['identity']['contract']);check(command['inputs']);spec=read(command['inputs']['path']);check_inputs(spec)
    require(result['postcheck']=={'inputs':command['inputs'],'all_files_matched':True,'file_count':input_count(spec)},'Incomplete postcheck reference')
    check(result['log'])
    if result.get('object'):check(result['object'])
    require('sorryAx' not in Path(result['log']['path']).read_text(),'Forbidden stored proof output')


def json_lines(text, prefix):
    result = {}
    for line in text.splitlines():
        if line.startswith(prefix + '_'):
            tag, raw = line.split(' ', 1)
            result.setdefault(tag[len(prefix)+1:], []).append(json.loads(raw))
    return result


def validate_audit(text, targets, project_modules, external_modules):
    rows = json_lines(text, 'P26_CELL06_AUDIT')
    require(len(rows.get('IMPORTS', [])) == 1, 'Missing/duplicate complete import inventory')
    imports = rows['IMPORTS'][0]
    require(len(imports) == len(set(imports)), 'Duplicate imported module')
    require({m for m in imports if m.startswith('ImbalancedChen.')} == set(project_modules), 'Audit actual project import set differs')
    require({m for m in imports if not m.startswith('ImbalancedChen.')} == set(external_modules), 'Audit introduced/lost external modules')
    inventories, completes = {}, {}
    for kind, destination in [('INVENTORY', inventories), ('COMPLETE', completes)]:
        for row in rows.get(kind, []):
            require(row['module'] not in destination, 'Duplicate audit ' + kind)
            destination[row['module']] = row
        require(set(destination) == set(targets), 'Incomplete module ' + kind)
    canonical, shared, seen_canonical, seen_shared = {}, {}, set(), set()
    for kind, destination in [('DECL', canonical), ('SHARED', shared)]:
        for row in rows.get(kind, []):
            require(row['module'] in targets, 'Unexpected audited owner')
            require(not any(row[k] for k in ('unsafe', 'partial', 'axiom')), 'Unsafe/partial/axiom mathematical owner')
            require(row['type'] and '⋯' not in row['type'] and set(row['axioms']) <= ALLOWED, 'Type/axiom audit rejected')
            if kind == 'SHARED':
                key = (row['module'], row['name'])
                require(key not in seen_shared, 'Duplicate shared occurrence'); seen_shared.add(key)
                require(row['identical_metadata'] is True and row['proof_body_kernel_checked'] is True, 'Unreplayed shared serialized body')
                require(row['canonical_module'] in project_modules and row['canonical_module'] != row['module'], 'Invalid canonical shared owner')
            else:
                require(row['name'] not in seen_canonical, 'Duplicate canonical declaration'); seen_canonical.add(row['name'])
            destination.setdefault(row['module'], []).append(row)
    for module in targets:
        inv, done = inventories[module], completes[module]
        names = sorted(r['name'] for r in canonical.get(module, []))
        aliases = sorted(r['name'] for r in shared.get(module, []))
        require(names == sorted(inv['environment']) and aliases == sorted(inv['shared']), 'Canonical/shared inventories differ')
        require(len(inv['serialized']) == len(set(inv['serialized'])) and sorted(inv['serialized']) == sorted(names + aliases), 'Serialized inventory incomplete')
        require(not set(names) & set(aliases), 'Canonical/shared overlap')
        require(done == {'module': module, 'count': len(names), 'shared_count': len(aliases), 'serialized_count': len(names)+len(aliases)}, 'Audit count mismatch')
    return {'canonical_count': len(seen_canonical), 'shared_occurrences': len(seen_shared),
            'modules': len(targets), 'inventories': inventories, 'canonical': canonical, 'shared': shared,
            'external_modules': sorted(external_modules)}


def validate_replay(text, parent_modules, incoming, geometry_bytes, moment_bytes):
    rows = json_lines(text, 'P26_CELL06')
    require(len(rows.get('CONTEXT_IMPORTS', [])) == len(rows.get('JOIN_COMPLETE', [])) == len(rows.get('ORIGINAL_BYTES', [])) == 1, 'Incomplete replay markers')
    context, complete, originals = rows['CONTEXT_IMPORTS'][0], rows['JOIN_COMPLETE'][0], rows['ORIGINAL_BYTES'][0]
    require(set(context['base_project']) == set(parent_modules), 'Base actual project import set differs from explicit parent')
    require(set(context['full_project']) == set(parent_modules) | set(incoming), 'Full actual project set is not parent+incoming')
    require(set(context['base_external']) == set(context['full_external']), 'Qualification introduced new external imports')
    require(complete['project_modules'] == len(incoming) and complete['new_external_modules'] == [] and complete['kernel_replay_succeeded'] is True, 'Official replay failed/incomplete')
    progress = rows.get('JOIN_PROGRESS', [])
    require(len(progress) == len(incoming) and {r['module'] for r in progress} == set(incoming), 'Replay module progress incomplete')
    require([r['completed_modules'] for r in progress] == list(range(1, len(incoming)+1)), 'Nonmonotonic replay checkpoint')
    require(progress[-1]['checked_declarations'] == complete['checked_declarations'], 'Replay declaration count mismatch')
    require(originals == {'geometry_bytes': geometry_bytes, 'moment_bytes': moment_bytes, 'embedded_original_bytes_match': True}, 'Quoted packed bytes differ')
    return {'checked_declarations': complete['checked_declarations'], 'external_modules': sorted(context['base_external']),
            'actual_imports': context, 'original_bytes': originals}


def real_process(argv, cwd, env, log, timeout, rss_bytes):
    """Only called by explicit execution CLI; host tests never call this."""
    started = time.monotonic(); peak = 0; reason = None
    with Path(log).open('xb') as out:
        process = subprocess.Popen(argv, cwd=cwd, env=env, stdout=out, stderr=subprocess.STDOUT, start_new_session=True)
        while process.poll() is None:
            total, todo, seen = 0, [process.pid], set()
            while todo:
                pid = todo.pop()
                if pid in seen: continue
                seen.add(pid)
                try:
                    status = Path(f'/proc/{pid}/status').read_text()
                    match = re.search(r'(?m)^VmRSS:\s+(\d+)\s+kB', status)
                    if match: total += int(match[1])*1024
                    todo += [int(p) for p in Path(f'/proc/{pid}/task/{pid}/children').read_text().split()]
                except (FileNotFoundError, ProcessLookupError, PermissionError): pass
            peak = max(peak, total)
            if total > rss_bytes: reason = 'aggregate_tree_rss_limit'
            if shutil.disk_usage(cwd).free < 512*1024**2:reason='disk_reserve_512_MiB'
            if time.monotonic()-started > timeout: reason = 'wall_timeout'
            if reason:
                try: os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError: pass
                break
            time.sleep(0.1)
        code = process.wait()
    return {'exit_code': code, 'stop_reason': reason, 'seconds': time.monotonic()-started, 'sampled_peak_tree_rss_bytes': peak}


def step(stage, key, mode, argv, env, inputs, contract_pin, validator, timeout, rss_bytes,
         output_object=None, executor=real_process):
    """Append-only attempts. A successful or ambiguous normal is never re-run."""
    stage = Path(stage); base = stage/'steps'/key/mode
    environment_hash=environment_sha256(env)
    identity = {'key': key, 'mode': mode, 'argv': list(map(str, argv)), 'cwd': str(stage/'project'),
                'environment_sha256':environment_hash,'environment_keys':sorted(env),
                'contract': contract_pin, 'timeout': timeout, 'rss_limit_bytes': rss_bytes}
    for attempt in sorted(base.glob('*')) if base.exists() else []:
        command_path, result_path, seal_path = (attempt/n for n in ('COMMAND.json','RESULT.json','ACCEPTED.json'))
        require(command_path.is_file(), 'Unknown checkpoint directory: '+str(attempt))
        command = read(command_path)
        require(command['identity'] == identity, 'Existing attempt has a different command/context; use a reviewed new stage')
        actual_argv = [str(attempt/'normal.olean') if a == '__NORMAL_OUTPUT__' else a for a in identity['argv']]
        require(command['actual_argv'] == actual_argv, 'Stored actual argv differs from frozen command')
        check(command['inputs']); prior_inputs = read(command['inputs']['path']); check_inputs(prior_inputs)
        if not result_path.exists():
            raise RuntimeError('Ambiguous unfinished attempt; recover evidence before retry: '+str(attempt))
        result = read(result_path)
        require(result['command'] == pin(command_path), 'Result/command chain mismatch')
        require(result['postcheck']=={'inputs':command['inputs'],'all_files_matched':True,'file_count':input_count(prior_inputs)},'Stored postcheck reference differs')
        check(result['log'])
        if result.get('object'): check(result['object'])
        if result['exit_code'] != 0 or result.get('stop_reason'):
            require(not seal_path.exists(), 'Failure has an acceptance seal')
            continue
        text = Path(result['log']['path']).read_text()
        require('sorryAx' not in text, 'Forbidden sorryAx in stored proof output')
        parsed = validator(text, result)
        if seal_path.exists():
            seal = read(seal_path)
            require(seal['result'] == pin(result_path) and seal['validated'] == parsed and seal['identity'] == identity, 'Acceptance seal mismatch')
        else:
            dump_new(seal_path, {'identity': identity, 'result': pin(result_path), 'validated': parsed,
                                'formal_acceptance': True, 'P2_6_complete': False, 'recovered_success_without_reexecution': True})
        return {'receipt': pin(seal_path), 'validated': parsed, 'object': result.get('object'), 'reused': True}
    with uncached_verification():
        expanded=expand_inputs(inputs);check_all(expanded);check(contract_pin)
    require(shutil.disk_usage(stage).free>1024**3,'Leave1GiB disk reserve before starting a proof step')
    attempt = base/(str(time.time_ns())+'-'+uuid.uuid4().hex[:8]); attempt.mkdir(parents=True)
    fingerprints = dump_new(attempt/'INPUTS.json', inputs)
    actual_argv = [str(attempt/'normal.olean') if a == '__NORMAL_OUTPUT__' else a for a in identity['argv']]
    command = {'identity': identity, 'actual_argv': actual_argv, 'inputs': fingerprints, 'started_unix_ns': time.time_ns()}
    command_path = attempt/'COMMAND.json'; dump_new(command_path, command)
    if output_object is not None:
        output_object = attempt/'normal.olean'
        require('__NORMAL_OUTPUT__' in identity['argv'] and not output_object.exists(), 'Normal output must be an exclusive per-attempt object')
    log = attempt/'output.log'
    process = executor(actual_argv, identity['cwd'], env, log, timeout, rss_bytes)
    with uncached_verification():
        after = unique_pins([pin(i['path']) for i in expanded])
        require(after == expanded, 'Input changed during proof command; preserve attempt and recover evidence')
    result = {**process, 'command': pin(command_path), 'log': pin(log),
              'postcheck':{'inputs':fingerprints,'all_files_matched':True,'file_count':len(expanded)},
              'object': pin(output_object) if output_object is not None and Path(output_object).is_file() else None}
    dump_new(attempt/'RESULT.json', result)
    require(process['exit_code'] == 0 and not process.get('stop_reason'), 'Proof step failed; immutable attempt retained: '+str(attempt))
    require('sorryAx' not in log.read_text(), 'Forbidden sorryAx in proof output')
    parsed = validator(log.read_text(), result)
    seal_path = attempt/'ACCEPTED.json'
    dump_new(seal_path, {'identity': identity, 'result': pin(attempt/'RESULT.json'), 'validated': parsed,
                        'formal_acceptance': True, 'P2_6_complete': False, 'recovered_success_without_reexecution': False})
    return {'receipt': pin(seal_path), 'validated': parsed, 'object': result.get('object'), 'reused': False}
