#!/usr/bin/env python3
"""Cell06 verification-controller candidate. Explicit execution commands only."""
import argparse
import fcntl
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

sys.dont_write_bytecode = True
from evidence import (require, pin, check, check_all, check_inputs, check_receipt_chain, unique_pins, read, dump_new, step,
                      verification_transaction,environment_sha256,
                      validate_audit, validate_replay)
import templates

ROOT = Path(__file__).resolve().parent
GRAPH = ROOT.parent/'CANDIDATE_GRAPH_v2.json'
MATHLIB_COMMIT = 'e4c91783ca8e6a7c693ae624ade32fd22d4e43c1'
TOOL_SHA = {'lean':'e8baaa71855a616dc351028f3ad2200051b0671f423a1696a100e809302d5550',
            'leanchecker':'ed46f21c763051c26f89481096cbaaf5db9665d674d602e3daf3391613ba0e6a'}
OLD = ['ImbalancedChen.P2OriginalSaving19ArchiveGeometryData06','ImbalancedChen.P2OriginalSaving19ArchiveMomentData06']
RAWS = [
 {'path':'/workspace/goldbach-research/eighth-third-minorant-extension-20261009-a23-s23_low-06-cell.witness.json','bytes':335849,'sha256':'377bbf9f0c96cfd537e34072b7e283760b3f44f3b4a7d55f47fa4c7a95517e9b'},
 {'path':'/workspace/goldbach-research/eighth-third-moment-refinement-20261009-a23-low-06.witness.json','bytes':58376,'sha256':'7654ebb59737bd765340a9edbd3984a4a72fe0f5b4cd9bf8f42266d7a7e724e9'}]
ROLES = {'actual-imported-artifact','actual-imported-source','batteries-donor-artifact','batteries-donor-source',
         'qualified-native-artifact','selected-native-source','pinned-runtime','pinned-toolchain-shared-library-ABI'}


def after_trivia(text):
    i=0
    while i<len(text):
        if text[i].isspace():i+=1
        elif text.startswith('--',i):
            end=text.find('\n',i);i=len(text) if end<0 else end+1
        elif text.startswith('/-',i) and not text.startswith(('/-!','/--'),i):
            depth=1;i+=2
            while depth:
                require(i<len(text),'Unterminated header comment')
                if text.startswith('/-',i):depth+=1;i+=2
                elif text.startswith('-/',i):depth-=1;i+=2
                else:i+=1
        else:break
    return text[i:]


def writable(path):
    path = Path(path).absolute()
    require(path.resolve().is_relative_to(ROOT), 'Writes must remain under runner root')
    for ancestor in [path,*path.parents]:
        if ancestor == ROOT.parent: break
        require(not ancestor.is_symlink(), 'Symlink in writable path')
    return path


def copy_new(source, target, expected):
    check(expected); target = writable(target); target.parent.mkdir(parents=True,exist_ok=True)
    if target.exists():
        require(pin(target)['sha256'] == expected['sha256'] and target.stat().st_size == expected['bytes'], 'Existing staged file differs')
        return pin(target)
    with Path(source).open('rb') as incoming, target.open('xb') as outgoing:
        shutil.copyfileobj(incoming,outgoing)
    result=pin(target)
    require(all(result[k]==expected[k] for k in ('bytes','sha256')), 'Copy readback failed')
    return result


def validate_parent(path, sha256, expected_count, verify_files=True):
    path=Path(path).absolute(); actual=pin(path)
    require(actual['sha256']==sha256,'Explicit accepted-parent SHA256 mismatch')
    parent=read(path)
    require(parent.get('formal_acceptance') is True and parent.get('P2_6_complete') is False,'Parent must be an actual accepted context, not a candidate')
    require(len(parent['project_closure'])==expected_count,'Explicit expected parent closure count differs')
    require(len(parent['native_artifacts'])==555,'Expected the complete555 native-artifact inventory')
    require(not set(OLD)&set(parent['project_closure']),'Data06 must be qualified as exactly two incoming modules')
    require(set(parent['runtime'])==set(TOOL_SHA),'Runtime pin inventory differs')
    for name,expected in parent['runtime'].items():
        require(expected['sha256']==TOOL_SHA[name] and Path(expected['path']).name==name,'Wrong fixed Lean4.33rc1 runtime bytes')
    require('phase_parent' in parent,'Explicit completed phase receipt required')
    check(parent['phase_parent']); phase=read(parent['phase_parent']['path'])
    require(phase.get('formal_acceptance') is True and phase.get('status')=='succeeded','Parent phase has not actually succeeded')
    require('final_external_readback' in phase,'Parent lacks completed external readback')
    check(phase['final_external_readback']); external=read(phase['final_external_readback']['path'])
    require(external['status']=='matched' and external['problems']==[],'Parent external readback failed')
    check(external['plan'])
    if verify_files:
        check_all(list(parent['runtime'].values())+parent['native_artifacts'])
        for info in parent['project_closure'].values():
            check(info['source']); check(info['selected_object'])
    return parent,actual,phase,external


def validate_graph(graph, parent_modules, verify_files=True):
    require(graph.get('candidate_revision')==2 and graph.get('formal_acceptance') is False,'Only frozen candidate graphv2 is allowed')
    require(graph['candidate_project_modules']==len(graph['entries'])==334 and graph['new_normal_targets']==332,'Wrong334/332 target inventory')
    require(graph['restored_old_normal_excluded_modules']==OLD,'Old normal exclusion list differs')
    order=graph['topological_order']; entries=graph['entries']
    require(len(order)==len(set(order))==334 and set(order)==set(entries),'Incomplete topological whitelist')
    require(not set(entries)&set(parent_modules),'Candidate/parent module overlap')
    available=set(parent_modules)
    for module in order:
        row=entries[module]
        project_imports={n for n in row['imports'] if n.startswith('ImbalancedChen.')}
        require(project_imports<=available,'Missing or non-topological project import: '+module)
        require(row['kind']==('restored_old_object_not_yet_qualified' if module in OLD else 'new_source_candidate'),'Unexpected target kind')
        if verify_files:
            check(row['source'])
            imports=re.findall(r'(?m)^import\s+([A-Za-z0-9_.]+)',Path(row['source']['path']).read_text())
            require(imports==row['imports'],'Source/graph imports drift: '+module)
            if module in OLD: check(row['object'])
            else:
                text=Path(row['source']['path']).read_text()
                require(not re.search(r'\b(?:sorry|admit|native_decide|unsafe|partial|newaxiom)\b|(?m:^\s*axiom\b)',text),'Forbidden mathematical source declaration/token')
                require(after_trivia(text).startswith('import '),'Candidate imports must precede moduleDoc/commands')
        available.add(module)
    if verify_files:
        check_all(graph['candidate_manifests']+[graph['restoration_report'],graph['accepted_supplier_anchor']])
    return [m for m in order if m not in OLD]


def external_inputs(external_report):
    """Independent reproduction of the accepted execution-role byte check."""
    plan=read(external_report['plan']['path']); aliases={r['original']:r['current'] for r in external_report['remapped_aliases']}
    files=[]; physical=set()
    for name,row in plan['required_files'].items():
        if row['role'] not in ROLES: continue
        path=Path(name)
        if not path.is_file() and name in aliases: path=Path(aliases[name])
        actual=pin(path)
        require(all(actual[k]==row[k] for k in ('bytes','sha256')),'Accepted external execution input differs: '+name)
        files.append(actual); physical.add(str(path.resolve()))
    require(len(physical)==external_report['unique_physical_files_hashed'],'Accepted external physical-file coverage differs')
    return unique_pins(files)


def environment_roots(parent,mathlib,sysroot):
    mathlib,sysroot=Path(mathlib).resolve(),Path(sysroot).resolve()
    require(parent['runtime']['lean']['path']==str(sysroot/'bin/lean'),'Sysroot does not match accepted runtime')
    commit=subprocess.check_output(['git','-C',str(mathlib),'rev-parse','HEAD'],text=True).strip()
    require(commit==MATHLIB_COMMIT,'Mathlib checkout is not locked')
    tail=parent['lean_path'].split(':')[1:]
    require(str(mathlib/'.lake/build/lib/lean') in tail,'Mathlib object root is not in accepted LEAN_PATH')
    roots=[Path(p) for p in tail]+[sysroot/'lib']
    files=set()
    for root in roots:
        require(root.is_dir(),'Missing environment root: '+str(root))
        for path in root.rglob('*'):
            if path.is_file(): files.add(path.absolute())
    return {'mathlib_root':str(mathlib),'mathlib_commit':commit,'sysroot':str(sysroot),'lean_path_tail':tail},sorted(files)


def make_lock(args):
    parent,parent_pin,phase,external=validate_parent(args.parent_context,args.parent_sha256,args.expected_parent_modules)
    inherited=external_inputs(external)
    config,paths=environment_roots(parent,args.mathlib,args.sysroot)
    files=unique_pins(inherited+[pin(p) for p in paths]+list(parent['runtime'].values()))
    check_all(files)
    lock={'schema':'p26_cell06_environment_lock_v1','accepted_parent':parent_pin,'phase_parent':parent['phase_parent'],
          'accepted_external_readback':phase['final_external_readback'],'accepted_external_plan':external['plan'],
          **config,'active_search_files':list(map(str,paths)),'files':files,'formal_acceptance':False,'scope':'Exact inherited external execution roles plus complete current search/runtime byte lock; no new mathematical acceptance.'}
    dump_new(writable(args.output),lock)
    print(json.dumps({'environment_lock':pin(args.output),'files':len(files),'Lean_commands':0,'formal_acceptance':False}))


def prepare(args):
    stage=writable(args.stage);require(not stage.exists(),'Fresh stage must not already exist')
    require(args.rss_gib>0 and args.wall_seconds>0,'Positive memory/time limits are required')
    parent,parent_pin,phase,external=validate_parent(args.parent_context,args.parent_sha256,args.expected_parent_modules)
    graph_pin=pin(args.graph);require(graph_pin['sha256']==args.graph_sha256,'Explicit graph SHA mismatch');graph=read(args.graph)
    targets=validate_graph(graph,parent['project_closure'])
    lock_pin=pin(args.environment_lock);require(lock_pin['sha256']==args.environment_lock_sha256,'Explicit environment lock SHA mismatch');lock=read(args.environment_lock)
    require(lock['schema']=='p26_cell06_environment_lock_v1' and lock['accepted_parent']==parent_pin,'Environment lock does not bind this parent')
    config,paths=environment_roots(parent,lock['mathlib_root'],lock['sysroot'])
    require(all(lock[k]==v for k,v in config.items()),'Environment configuration changed')
    require(lock['active_search_files']==list(map(str,paths)),'Environment search/runtime file inventory changed')
    inherited=external_inputs(external);check_all(lock['files'])
    locked={r['path']:r for r in lock['files']}
    require(all(str(p) in locked for p in paths) and all(locked.get(i['path'])==i for i in inherited),'Environment lock coverage incomplete')
    check_all(RAWS)
    controls=[pin(ROOT/n) for n in ('controller.py','evidence.py','templates.py','IMPLEMENTATION_PLAN.md')]
    references=[pin(templates.REFERENCES/n) for n in ('ReplayJoin.lean','OwnedSuppliersAudit.lean','prepare_finite_join.py','build_finite_p1.py','build_finite_p2.py','verify_after_finite.py')]
    watched=[parent_pin,graph_pin,lock_pin,parent['phase_parent'],phase['final_external_readback'],external['plan'],*controls,*references,*lock['files'],*RAWS,
             *graph['candidate_manifests'],graph['restoration_report'],graph['accepted_supplier_anchor']]
    copy_pins=[*parent['native_artifacts'],*RAWS]
    for item in parent['project_closure'].values():copy_pins += [item['source'],item['selected_object']]
    for item in graph['entries'].values():
        copy_pins.append(item['source'])
        if 'object' in item:copy_pins.append(item['object'])
    required_copy_bytes=sum(i['bytes'] for i in unique_pins(copy_pins))
    require(shutil.disk_usage(ROOT).free>required_copy_bytes+2*1024**3,'Insufficient disk for exact stage copies plus2GiB reserve')
    stage.mkdir(parents=True)
    for name in ('project','objects','helpers','accepted-contexts','home','tmp'):(stage/name).mkdir()
    catalog={};native=[];staged=[]
    for module,info in parent['project_closure'].items():
        relative=Path(module.replace('.','/'))
        source=copy_new(info['source']['path'],stage/'project'/relative.with_suffix('.lean'),info['source'])
        obj=copy_new(info['selected_object']['path'],stage/'objects'/relative.with_suffix('.olean'),info['selected_object'])
        catalog[module]={'source':source,'selected_object':obj,'origin':'exact-explicit-accepted-parent'}
        watched += [info['source'],info['selected_object']];staged += [source,obj]
    parent_object_root=Path(parent['lean_path'].split(':')[0])
    for row in parent['native_artifacts']:
        relative=Path(row['path']).relative_to(parent_object_root)
        target=copy_new(row['path'],stage/'objects'/relative,row);native.append(target);staged.append(target);watched.append(row)
    for module in graph['topological_order']:
        row=graph['entries'][module];relative=Path(module.replace('.','/'))
        source=copy_new(row['source']['path'],stage/'project'/relative.with_suffix('.lean'),row['source']);staged.append(source);watched.append(row['source'])
        if module in OLD:
            obj=copy_new(row['object']['path'],stage/'objects'/relative.with_suffix('.olean'),row['object']);staged.append(obj);watched.append(row['object'])
    raws=[]
    for row in RAWS:
        raws.append(copy_new(row['path'],stage/'goldbach-research'/Path(row['path']).name,row));staged.append(raws[-1])
    parent_modules=sorted(catalog)
    replay_source=templates.replay(parent_modules,OLD,raws[0]['path'],raws[1]['path'])
    audit_source=templates.audit(parent_modules+OLD,OLD)
    for name,text in [('Data2Replay.lean',replay_source),('Data2Owned.lean',audit_source)]:
        path=stage/'helpers'/name
        with path.open('x') as out:out.write(text)
        staged.append(pin(path))
    staged += [dump_new(stage/'DATA2_MODULES.json',OLD),dump_new(stage/'PARENT_MODULES.json',parent_modules)]
    frozen=unique_pins(watched+staged);check_all(frozen)
    baseline=dump_new(stage/'BASELINE_INPUTS.json',frozen)
    context={'schema':'p26_cell06_verification_stage_v2','status':'prepared_not_executed','formal_acceptance':False,'P2_6_complete':False,
             'accepted_parent':parent_pin,'parent_module_count':args.expected_parent_modules,'parent_catalog':catalog,
             'native_artifacts':native,'graph':graph_pin,'targets':targets,'old_normal_excluded':OLD,
             'environment_lock':lock_pin,'environment':config,'runtime':parent['runtime'],
             'lean_path':str(stage/'objects')+':'+':'.join(lock['lean_path_tail']),
             'baseline_inputs':baseline,'raw_copies':raws,'rss_gib':args.rss_gib,'wall_seconds':args.wall_seconds,
             'planned_initial_copy_bytes':required_copy_bytes,'minimum_disk_headroom_before_copy':2*1024**3,
             'controller_sources':controls,'reference_sources':references,'Lean_commands':0}
    dump_new(stage/'STAGE.json',context)
    print(json.dumps({'stage_contract':pin(stage/'STAGE.json'),'status':'prepared_not_executed','formal_acceptance':False,'Lean_commands':0}))


def validate_stage_parent(stage,context):
    parent,parent_pin,_,_=validate_parent(context['accepted_parent']['path'],context['accepted_parent']['sha256'],context['parent_module_count'])
    require(context['accepted_parent']==parent_pin and context['runtime']==parent['runtime'],'Stage runtime/parent differ from accepted authority')
    require(set(context['parent_catalog'])==set(parent['project_closure']),'Stage parent module set differs')
    for module,original in parent['project_closure'].items():
        relative=Path(module.replace('.','/'));copied=context['parent_catalog'][module]
        for key,folder,suffix in [('source','project','.lean'),('selected_object','objects','.olean')]:
            require(copied[key]['path']==str(stage/folder/relative.with_suffix(suffix)),'Noncanonical staged parent path')
            require(all(copied[key][k]==original[key][k] for k in ('bytes','sha256')),'Staged parent source/object differs from original authority')
            check(copied[key])
    parent_root=Path(parent['lean_path'].split(':')[0])
    expected_native=[{**i,'path':str(stage/'objects'/Path(i['path']).relative_to(parent_root))} for i in parent['native_artifacts']]
    require(context['native_artifacts']==expected_native,'Stage native inventory differs from all555 parent files')
    check_all(expected_native)
    require(context['lean_path']==str(stage/'objects')+':'+parent['lean_path'].split(':',1)[1],'Stage LEAN_PATH differs from explicit parent tail')


def load_stage(stage,expected_sha256):
    stage=writable(stage)
    require(pin(stage/'STAGE.json')['sha256']==expected_sha256,'Externally supplied prepare→execution stage SHA mismatch')
    context=read(stage/'STAGE.json');require(context['schema']=='p26_cell06_verification_stage_v2','Wrong stage contract')
    validate_stage_parent(stage,context)
    check(context['baseline_inputs']);check_all(read(context['baseline_inputs']['path']));check_all(context['controller_sources']);check(context['graph']);check(context['environment_lock'])
    graph=read(context['graph']['path']);validate_graph(graph,context['parent_catalog'])
    environment_inventory(context)
    env=lean_environment(stage,context)
    flags=lean_flags(context)
    return context,graph,env,flags


def lean_flags(context):
    return ['--trust=0','-DwarningAsError=true','-j1',f'-M{context["rss_gib"]*1024}','-DmaxRecDepth=1000000','-DmaxHeartbeats=0']


def expected_argv(stage,context,key,mode):
    stage=Path(stage);lean=context['runtime']['lean']['path'];flags=lean_flags(context)
    if key=='DATA2':
        require(mode in ('official-replay','full-owned'),'Unexpected Data2 mode')
        argv=([lean,*flags,'--run',stage/'helpers/Data2Replay.lean',stage/'DATA2_MODULES.json'] if mode=='official-replay'
              else [lean,*flags,stage/'helpers/Data2Owned.lean'])
    elif mode=='normal':argv=[lean,*flags,'-o','__NORMAL_OUTPUT__',stage/'project'/Path(key.replace('.','/')).with_suffix('.lean')]
    elif mode=='stock-leanchecker':argv=[context['runtime']['leanchecker']['path'],'--verbose',key]
    elif mode=='full-owned':argv=[lean,*flags,stage/'helpers'/(key+'.Owned.lean')]
    else:raise RuntimeError('Unexpected owner mode')
    return list(map(str,argv))


def lean_environment(stage,context):
    # Explicit allowlist: no inherited LD_*, proxy/tunnel/API keys, Python paths,
    # user HOME, credentials or arbitrary process environment enter Lean.
    stage=Path(stage)
    return {'HOME':str(stage/'home'),'TMPDIR':str(stage/'tmp'),'LANG':'C.UTF-8','LC_ALL':'C.UTF-8','TZ':'UTC',
            'LEAN_PATH':context['lean_path'],'LEAN_NUM_THREADS':'1','OMP_NUM_THREADS':'1',
            'LEAN_SYSROOT':context['environment']['sysroot'],
            'PATH':context['environment']['sysroot']+'/bin:/usr/bin:/bin'}


def restore_normal_output(stage,module,receipt,expected_canonical,expected_environment_sha=None,expected_command=None):
    # The permanent normal artifact is authoritative; restoration cannot invoke
    # a compiler and precedes checking pins that reference the lost namespace copy.
    check_receipt_chain(receipt,pin(Path(stage)/'STAGE.json'),module,'normal',expected_environment_sha,expected_command);seal=read(receipt['path'])
    require(seal['identity']['key']==module and seal['identity']['mode']=='normal','Wrong restoration normal receipt')
    result=read(seal['result']['path']);require(result.get('object') is not None,'Missing permanent normal output')
    require(all(result['object'][k]==expected_canonical[k] for k in ('bytes','sha256')),'Normal artifact and canonical object disagree')
    target=Path(stage)/'objects'/Path(module.replace('.','/')).with_suffix('.olean')
    require(expected_canonical['path']==str(target),'Wrong restoration destination')
    return copy_new(result['object']['path'],target,result['object'])


def environment_inventory(context):
    lock=read(context['environment_lock']['path'])
    parent=read(context['accepted_parent']['path'])
    config,paths=environment_roots(parent,lock['mathlib_root'],lock['sysroot'])
    require(all(lock[k]==v for k,v in config.items()) and lock['active_search_files']==list(map(str,paths)),
            'External search/runtime namespace changed')


def guarded(context,validator):
    def validate(text,result):
        environment_inventory(context)
        return validator(text,result)
    return validate


def inputs_for(stage,context,extra=()):
    baseline=context['baseline_inputs'];check(baseline);base={i['path']:i for i in read(baseline['path'])}
    delta=[]
    for item in unique_pins([pin(Path(stage)/'STAGE.json')]+list(extra)):
        if item['path'] in base:require(base[item['path']]==item,'Delta conflicts with shared frozen baseline')
        else:delta.append(item)
    return {'baseline':baseline,'delta':delta}


def qualified(stage):
    path=Path(stage)/'accepted-contexts/DATA2.json'
    require(path.exists(),'Data2 must qualify before any new normal compilation')
    value=read(path);require(value['formal_acceptance'] is True,'Data2 did not formally qualify')
    context=read(Path(stage)/'STAGE.json');graph=read(context['graph']['path'])
    require(len(value['receipts'])==2,'Wrong Data2 receipt count')
    env_hash=environment_sha256(lean_environment(stage,context));contract=pin(Path(stage)/'STAGE.json')
    for receipt,mode in zip(value['receipts'],['official-replay','full-owned']):check_receipt_chain(receipt,contract,'DATA2',mode,env_hash,expected_argv(stage,context,'DATA2',mode))
    check_inputs(value['pins'])
    require(value['stage_contract']==pin(Path(stage)/'STAGE.json') and value['accepted_parent']==context['accepted_parent'],'Data2 parent/contract changed')
    require(value['accepted_new_modules']==[] and len(value['receipts'])==2,'Wrong Data2 qualification receipt scope')
    replay_seal=read(value['receipts'][0]['path']);replay_result=read(replay_seal['result']['path'])
    replayed=validate_replay(Path(replay_result['log']['path']).read_text(),set(context['parent_catalog']),OLD,RAWS[0]['bytes'],RAWS[1]['bytes'])
    require(replay_seal['validated']==replayed and value['external_modules']==replayed['external_modules'],'Data2 replay/import evidence changed')
    audit_seal=read(value['receipts'][1]['path']);audit_result=read(audit_seal['result']['path'])
    audited=validate_audit(Path(audit_result['log']['path']).read_text(),OLD,set(context['parent_catalog'])|set(OLD),replayed['external_modules'])
    require(audit_seal['validated']==audited and audited['canonical_count']==replayed['checked_declarations'],'Data2 owned/replay coverage changed')
    validate_catalog(Path(stage),context,graph,value['project_closure'],[])
    return value,path


def validate_catalog(stage,context,graph,catalog,accepted):
    require(set(catalog)==set(context['parent_catalog'])|set(OLD)|set(accepted),'Accepted prefix module set differs')
    for module,info in context['parent_catalog'].items():
        require(catalog[module]==info,'Selected parent source/object changed')
    for module in OLD+list(accepted):
        row=catalog[module];relative=Path(module.replace('.','/'))
        require(row['source']['path']==str(stage/'project'/relative.with_suffix('.lean')),'Wrong canonical source path')
        require(row['selected_object']['path']==str(stage/'objects'/relative.with_suffix('.olean')),'Wrong canonical object path')
        check(row['source']);check(row['selected_object'])
        require(all(row['source'][k]==graph['entries'][module]['source'][k] for k in ('bytes','sha256')),'Accepted candidate source differs from frozen graph')
        if module in OLD:
            require(all(row['selected_object'][k]==graph['entries'][module]['object'][k] for k in ('bytes','sha256')),'Restored old object pin changed')


def namespace_check(stage,catalog,native,normal_objects=()):
    expected={i['selected_object']['path'] for i in catalog.values()}|{i['path'] for i in native}|{i['path'] for i in normal_objects}
    actual={str(p.absolute()) for p in (Path(stage)/'objects').rglob('*') if p.is_file()}
    require(actual==expected,'Unknown/missing file in unified first object root')
    check_all([i['selected_object'] for i in catalog.values()]+list(native)+list(normal_objects))


def qualify_data(args):
    stage=writable(args.stage);context,graph,env,flags=load_stage(stage,args.stage_sha256)
    if (stage/'accepted-contexts/DATA2.json').exists():
        value,path=qualified(stage);print(json.dumps({'reused_accepted_context':pin(path),'formal_acceptance':True}));return
    catalog=dict(context['parent_catalog'])
    for module in OLD:
        relative=Path(module.replace('.','/'));catalog[module]={'source':pin(stage/'project'/relative.with_suffix('.lean')),'selected_object':pin(stage/'objects'/relative.with_suffix('.olean')),'origin':'restored_exact_old_object_pending_qualification'}
    namespace_check(stage,catalog,context['native_artifacts'])
    parent_modules=set(context['parent_catalog']);contract=pin(stage/'STAGE.json');inputs=inputs_for(stage,context)
    validate=guarded(context,lambda text,result:validate_replay(text,parent_modules,OLD,RAWS[0]['bytes'],RAWS[1]['bytes']))
    replay=step(stage,'DATA2','official-replay',[context['runtime']['lean']['path'],*flags,'--run',stage/'helpers/Data2Replay.lean',stage/'DATA2_MODULES.json'],
                env,inputs,contract,validate,context['wall_seconds'],context['rss_gib']*1024**3)
    external=replay['validated']['external_modules']
    audit=step(stage,'DATA2','full-owned',[context['runtime']['lean']['path'],*flags,stage/'helpers/Data2Owned.lean'],
               env,inputs_for(stage,context,[replay['receipt']]),contract,
               guarded(context,lambda text,result:validate_audit(text,OLD,set(catalog),external)),context['wall_seconds'],context['rss_gib']*1024**3)
    require(audit['validated']['canonical_count']==replay['validated']['checked_declarations'],'Official replay/full-owned canonical declaration coverage differs')
    namespace_check(stage,catalog,context['native_artifacts']);check_inputs(inputs)
    for module in OLD:catalog[module]['origin']='qualified_restored_Data06_no_normal_rebuild'
    result={'schema':'p26_cell06_accepted_prefix_context_v1','formal_acceptance':True,'P2_6_complete':False,'scope':'Exactly two restored Data06 modules qualified in complete explicit accepted parent context.',
            'accepted_parent':context['accepted_parent'],'stage_contract':contract,'project_closure':catalog,'native_artifacts':context['native_artifacts'],
            'runtime':context['runtime'],'lean_path':context['lean_path'],'external_modules':external,'accepted_new_modules':[],
            'receipts':[replay['receipt'],audit['receipt']],'pins':inputs,'old_normal_recompilations':0}
    path=stage/'accepted-contexts/DATA2.json';dump_new(path,result);print(json.dumps({'accepted_data2_context':pin(path),'formal_acceptance':True,'P2_6_complete':False}))


def normal_validator(text,result):
    require(result['object'] is not None,'Successful normal has no exact output object')
    reported={a.strip() for group in re.findall(r'depends on axioms: \[([^\]]*)\]',text) for a in group.split(',') if a.strip()}
    require(reported<={'propext','Classical.choice','Quot.sound'},'Forbidden printed axiom')
    return {'normal_object':result['object'],'printed_axioms':sorted(reported)}


def run_owners(args):
    stage=writable(args.stage);context,graph,env,flags=load_stage(stage,args.stage_sha256);base,base_path=qualified(stage)
    whitelist=read(args.modules);require(isinstance(whitelist,list) and whitelist and len(whitelist)==len(set(whitelist)),'Explicit unique whitelist JSON required')
    order=[m for m in context['targets'] if m in whitelist]
    require(order==whitelist and not set(whitelist)&set(OLD),'Whitelist must be in frozen graph order and must exclude old data')
    check_inputs(base['pins']);catalog=dict(base['project_closure']);accepted=[];context_path=base_path
    # Reconstruct every completed prefix; gaps are rejected, never guessed.
    for module in context['targets']:
        path=stage/'accepted-contexts'/(module+'.json')
        if path.exists():
            require(module==context['targets'][len(accepted)],'Gap in accepted graph prefix')
            previous=read(path);require(previous['accepted_parent']==pin(context_path),'Accepted prefix parent differs')
            require(previous['accepted_new_modules']==accepted+[module],'Non-topological accepted prefix')
            require(len(previous['receipts'])==3,'New owner requires normal, stockchecker and full-owned receipts')
            restore_normal_output(stage,module,previous['receipts'][0],previous['project_closure'][module]['selected_object'],environment_sha256(env),expected_argv(stage,context,module,'normal'))
            check_inputs(previous['pins'])
            for receipt,mode in zip(previous['receipts'],['normal','stock-leanchecker','full-owned']):
                check_receipt_chain(receipt,pin(stage/'STAGE.json'),module,mode,environment_sha256(env),expected_argv(stage,context,module,mode))
            require(previous['stage_contract']==pin(stage/'STAGE.json') and previous['external_modules']==base['external_modules'],'Accepted prefix contract/external set differs')
            normal_seal=read(previous['receipts'][0]['path']);normal_result=read(normal_seal['result']['path'])
            require(normal_seal['identity']['key']==module and normal_seal['identity']['mode']=='normal','Wrong normal receipt owner/mode')
            require(all(previous['project_closure'][module]['selected_object'][k]==normal_result['object'][k] for k in ('bytes','sha256')),'Accepted object does not match successful normal output')
            kernel_seal=read(previous['receipts'][1]['path'])
            require(kernel_seal['identity']['key']==module and kernel_seal['identity']['mode']=='stock-leanchecker','Wrong stockchecker receipt')
            audit_seal=read(previous['receipts'][2]['path']);audit_result=read(audit_seal['result']['path'])
            audited=validate_audit(Path(audit_result['log']['path']).read_text(),[module],set(catalog)|{module},base['external_modules'])
            require(audit_seal['identity']['key']==module and audit_seal['identity']['mode']=='full-owned' and audit_seal['validated']==audited,'Wrong full-owned receipt')
            validate_catalog(stage,context,graph,previous['project_closure'],accepted+[module])
            catalog=previous['project_closure'];accepted.append(module);context_path=path
    for module in whitelist:
        if module in accepted:continue
        # This first implementation deliberately accepts a contiguous graph prefix.
        require(module==context['targets'][len(accepted)],'Only the next graph owner can extend the accepted prefix')
        require({n for n in graph['entries'][module]['imports'] if n.startswith('ImbalancedChen.')}<=set(catalog),'Owner imports a source-only dependency')
        obj_path=stage/'objects'/Path(module.replace('.','/')).with_suffix('.olean')
        pending=[]
        if obj_path.exists():
            prior_success=[]
            for result_path in (stage/'steps'/module/'normal').glob('*/RESULT.json'):
                result=read(result_path)
                if result['exit_code']==0 and not result.get('stop_reason') and result.get('object'):
                    prior_success.append(result['object'])
            require(any(all(pin(obj_path)[k]==p[k] for k in ('bytes','sha256')) for p in prior_success),
                    'Unreceipted existing normal object; do not recompile')
            pending=[pin(obj_path)]
        namespace_check(stage,catalog,context['native_artifacts'],pending)
        source=stage/'project'/Path(module.replace('.','/')).with_suffix('.lean')
        audit_source=stage/'helpers'/(module+'.Owned.lean')
        audit_text=templates.audit(sorted(catalog)+[module],[module])
        if audit_source.exists():require(audit_source.read_text()==audit_text,'Frozen per-owner auditor changed')
        else:
            with audit_source.open('x') as out:out.write(audit_text)
        extra=[pin(source),pin(audit_source),pin(context_path),pin(args.modules)]
        for item in catalog.values():extra += [item['source'],item['selected_object']]
        inputs=inputs_for(stage,context,extra);contract=pin(stage/'STAGE.json')
        normal=step(stage,module,'normal',[context['runtime']['lean']['path'],*flags,'-o','__NORMAL_OUTPUT__',source],env,inputs,contract,
                    guarded(context,normal_validator),context['wall_seconds'],context['rss_gib']*1024**3,output_object=True)
        obj=copy_new(normal['object']['path'],obj_path,normal['object'])
        # Successful normal is now a permanent no-recompile barrier; missing
        # canonical copies are restored from exactly the receipt-bound output.
        kernel=step(stage,module,'stock-leanchecker',[context['runtime']['leanchecker']['path'],'--verbose',module],env,
                    inputs_for(stage,context,extra+[normal['receipt'],obj]),contract,
                    guarded(context,lambda text,result:{'stock_leanchecker_exit_zero':True}),context['wall_seconds'],context['rss_gib']*1024**3)
        audit=step(stage,module,'full-owned',[context['runtime']['lean']['path'],*flags,audit_source],env,
                   inputs_for(stage,context,extra+[normal['receipt'],kernel['receipt'],obj]),contract,
                   guarded(context,lambda text,result:validate_audit(text,[module],set(catalog)|{module},base['external_modules'])),
                   context['wall_seconds'],context['rss_gib']*1024**3)
        catalog[module]={'source':pin(source),'selected_object':obj,'origin':'qualified_new_normal_stockchecker_fullowned'};accepted.append(module)
        namespace_check(stage,catalog,context['native_artifacts'])
        result={'schema':'p26_cell06_accepted_prefix_context_v1','formal_acceptance':True,'P2_6_complete':False,
                'scope':'A checked contiguous Cell06 candidate prefix, not complete P2.6.','accepted_parent':pin(context_path),
                'stage_contract':contract,'project_closure':catalog,'native_artifacts':context['native_artifacts'],
                'runtime':context['runtime'],'lean_path':context['lean_path'],'external_modules':base['external_modules'],
                'accepted_new_modules':list(accepted),'receipts':[normal['receipt'],kernel['receipt'],audit['receipt']],
                'pins':inputs_for(stage,context,extra+[obj]),'old_normal_recompilations':0}
        context_path=stage/'accepted-contexts'/(module+'.json');dump_new(context_path,result)
        print(json.dumps({'module':module,'accepted_context':pin(context_path),'formal_acceptance':True,'P2_6_complete':False}),flush=True)


def main():
    p=argparse.ArgumentParser(description=__doc__);commands=p.add_subparsers(dest='command',required=True)
    def parent_flags(q):
        q.add_argument('--parent-context',type=Path,required=True);q.add_argument('--parent-sha256',required=True);q.add_argument('--expected-parent-modules',type=int,required=True)
    q=commands.add_parser('make-environment-lock');parent_flags(q);q.add_argument('--mathlib',type=Path,required=True);q.add_argument('--sysroot',type=Path,required=True);q.add_argument('--output',type=Path,required=True);q.set_defaults(action=make_lock)
    q=commands.add_parser('prepare');parent_flags(q);q.add_argument('--graph',type=Path,default=GRAPH);q.add_argument('--graph-sha256',required=True)
    q.add_argument('--environment-lock',type=Path,required=True);q.add_argument('--environment-lock-sha256',required=True);q.add_argument('--stage',type=Path,required=True)
    q.add_argument('--rss-gib',type=int,default=12);q.add_argument('--wall-seconds',type=int,default=2400);q.set_defaults(action=prepare)
    q=commands.add_parser('qualify-data');q.add_argument('--stage',type=Path,required=True);q.add_argument('--stage-sha256',required=True);q.set_defaults(action=qualify_data)
    q=commands.add_parser('run-owners');q.add_argument('--stage',type=Path,required=True);q.add_argument('--stage-sha256',required=True);q.add_argument('--modules',type=Path,required=True);q.set_defaults(action=run_owners)
    args=p.parse_args()
    if hasattr(args,'stage'):
        lock_path=writable(ROOT/'CONTROLLER_LOCK')
        with lock_path.open('a+') as lock:
            fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
            with verification_transaction():args.action(args)
    else:args.action(args)


if __name__=='__main__':main()
