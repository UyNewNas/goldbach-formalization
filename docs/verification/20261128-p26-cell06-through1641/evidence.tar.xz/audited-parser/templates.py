"""Render new verification helpers from pinned, read-only reference source."""
from pathlib import Path
import json
from evidence import require

REFERENCES = Path('/workspace/p26-proof-continuation-20261127/tools/p26/cell01-integral')


def names_array(names):
    require(names and len(names)==len(set(names)), 'Expected unique module list')
    require(all(n.startswith('ImbalancedChen.') and all(c.isalnum() or c in '._' for c in n) for n in names), 'Invalid module name')
    return '#[\n'+',\n'.join('    { module := `'+n+' }' for n in names)+']'


def replay(parent_modules, incoming, geometry_path, moment_path):
    require(len(incoming)==2, 'Only exact Data06 qualification is supported by this helper')
    source=(REFERENCES/'ReplayJoin.lean').read_text()
    source=source.replace('P26_CELL01','P26_CELL06').replace('geometryPacked01','geometryPacked06').replace('momentPacked01','momentPacked06')
    source=source.replace('"/workspace/goldbach-research/eighth-third-minorant-extension-20261009-a23-s23_low-01-cell.witness.json"',json.dumps(str(geometry_path)))
    source=source.replace('"/workspace/goldbach-research/eighth-third-moment-refinement-20261009-a23-low-01.witness.json"',json.dumps(str(moment_path)))
    require('wanted.size == 407' in source,'Replay template drift')
    source=source.replace('wanted.size == 407','wanted.size == 2')
    start=source.index('  let baseImports : Array Import := #[')
    end=source.index('  let (_, baseState)',start)
    source=source[:start]+'  let baseImports : Array Import := '+names_array(parent_modules)+'\n'+source[end:]
    start=source.index('  let allImports := baseImports ++ #[')
    end=source.index('  let (_, fullState)',start)
    source=source[:start]+'  let allImports := baseImports ++ '+names_array(incoming)+'\n'+source[end:]
    marker='  checkOriginalData full\n'
    require(source.count(marker)==1,'Replay marker drift')
    checks='''  let baseProject := base.header.moduleNames.filter (fun n => (`ImbalancedChen).isPrefixOf n)
  let fullProject := full.header.moduleNames.filter (fun n => (`ImbalancedChen).isPrefixOf n)
  let baseExternal := base.header.moduleNames.filter (fun n => !(`ImbalancedChen).isPrefixOf n)
  let fullExternal := full.header.moduleNames.filter (fun n => !(`ImbalancedChen).isPrefixOf n)
  unless baseProject.qsort Name.lt == (baseImports.map (·.module)).qsort Name.lt do
    throw <| IO.userError "Base actual imports differ from complete accepted parent"
  unless fullProject.qsort Name.lt == (allImports.map (·.module)).qsort Name.lt do
    throw <| IO.userError "Full actual imports differ from parent+Data06"
  unless baseExternal.qsort Name.lt == fullExternal.qsort Name.lt do
    throw <| IO.userError "New external modules are forbidden"
  IO.println s!"P26_CELL06_CONTEXT_IMPORTS {(Json.mkObj [
    ("base_project", toJson (baseProject.map Name.toString)),
    ("full_project", toJson (fullProject.map Name.toString)),
    ("base_external", toJson (baseExternal.map Name.toString)),
    ("full_external", toJson (fullExternal.map Name.toString))]).compress}"
  (← IO.getStdout).flush
'''
    source=source.replace(marker,checks+marker)
    return source


def audit(import_modules, targets):
    source=(REFERENCES/'OwnedSuppliersAudit.lean').read_text()
    source=''.join('import '+n+'\n' for n in import_modules)+source[source.index('import Lean.Util.CollectAxioms'):]
    start=source.index('  for moduleName in #[')
    end=source.index('] do\n    let some idx',start)
    source=source[:start]+'  for moduleName in #[\n'+',\n'.join('      `'+n for n in targets)+source[end:]
    source=source.replace('P26_CELL01_SUPPLIER_AUDIT','P26_CELL06_AUDIT').replace('p26Cell01SharedProofBodyCheck','p26Cell06SharedProofBodyCheck')
    require('addDeclCore 0 0 declaration' in source and 'original with name := aliasName' in source,'Missing trust0 serialized-body replay')
    require('serializedData.constants' in source and 'canonical_module' in source,'Missing complete shared audit')
    return source
