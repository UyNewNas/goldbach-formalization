#!/usr/bin/env python3
"""Synthetic bytes/evidence only. The fake executor never launches a subprocess."""
import json
from pathlib import Path
import sys
import tempfile
import time
import unittest
from unittest.mock import patch
sys.dont_write_bytecode=True
import family_common as common
import family_engine as e
import family_controller as c
from family_common import *
ROOT=Path(__file__).resolve().parent
RUN=ROOT/'host-tests'/str(time.time_ns())
RUN.mkdir(parents=True)


def rewrite(path,value):Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')


class Fixture:
    def __init__(self,n=9):
        self.temp=tempfile.TemporaryDirectory(prefix='SYNTHETIC-',dir=RUN);self.family=Path(self.temp.name)
        for name in ('project','objects','evidence','runtime','state','batches','old-search'):(self.family/name).mkdir()
        self.parent='ImbalancedChen.SyntheticParent';self.targets=['ImbalancedChen.SyntheticNext'+str(i).zfill(3) for i in range(n)]
        self.calls={};self.bad_shared=False
        ps=source_path(self.family,self.parent);ps.parent.mkdir();ps.write_text('-- synthetic parent\n')
        po=object_path(self.family,self.parent);po.parent.mkdir();po.write_bytes(b'fake accepted parent')
        self.lib=self.family/'shared-global.bin';self.lib.write_bytes(b'global-only-original')
        lean=self.family/'runtime/lean';lean.write_bytes(b'not executable')
        checker=self.family/'runtime/leanchecker';checker.write_bytes(b'not executable either')
        code=[pin(ROOT/name) for name in ('family_common.py','family_controller.py','family_engine.py')]
        sources={self.parent:pin(ps)};entries={}
        for owner in self.targets:
            path=source_path(self.family,owner);path.write_text('import '+self.parent+'\n')
            sources[owner]=pin(path);entries[owner]={'source':pin(path),'imports':[self.parent]}
        graph=dump(self.family/'GRAPH.json',{'topological_order':self.targets,'entries':entries})
        cert=dump(self.family/'CERT.json',{'synthetic_only':True})
        transport=dump(self.family/'TRANSPORT.json',{'rows':[]})
        barriers=dump(self.family/'NORMAL_BARRIERS.json',[])
        catalog={self.parent:{'source':pin(ps),'selected_object':pin(po)}}
        base=dump(self.family/'BASE_CONTEXT.json',{'protocol':PROTOCOL,'project_closure':catalog,
              'formal_acceptance':False,'verified_parent_formal_acceptance':True,'accepted_since_family_base':[],'certificate':cert})
        baseline=dump(self.family/'BASE_GLOBAL_INPUTS.json',unique([*sources.values(),pin(po),pin(self.lib),pin(lean),pin(checker),graph,cert,transport,barriers,base,*code]))
        self.ext={'protocol':PROTOCOL,'family_root':str(self.family),'base_catalog':catalog,'parent_catalog':catalog,'base_context':base,
                  'native_artifacts':[],'runtime':{'lean':pin(lean),'leanchecker':pin(checker)},'environment':{'sysroot':str(self.family/'runtime')},
                  'lean_path':str(self.family/'objects'),'external_modules':['Init'],'graph':graph,'certificate':cert,'transport':transport,
                  'normal_barriers':[],'normal_barriers_manifest':barriers,'normal_search_roots':[str(self.family/'old-search')],
                  'project_files':sorted(row['path'] for row in sources.values()),'project_sources':sources,'base_global_inputs':baseline,
                  'code_pins':code,'rss_gib':1,'wall_seconds':10,'synthetic_fixture':True,'formal_acceptance':False}
        self.fp=dump(self.family/'FAMILY.json',self.ext);self.ext['_anchor']=self.fp;self.parent_pin=base

    def close(self):self.temp.cleanup()
    def freeze(self,name='epoch1',count=2,parent=None):
        bp=c.freeze_epoch(self.family,self.ext,parent or self.parent_pin,name,count)
        self.epoch=Path(bp['path']).parent;self.batch=read(bp['path']);self.batch['_anchor']=bp
        current=read((parent or self.parent_pin)['path']);self.ext['parent_catalog']=current['project_closure']
        self.ext['foundation']=parent or self.parent_pin;self.ext['global_inputs']=self.batch['global_inputs']
        return bp
    def fake(self,mode,owner,argv,cwd,env,log,timeout,rss):
        self.calls[(owner,mode)]=self.calls.get((owner,mode),0)+1
        if mode=='normal':
            Path(argv[argv.index('-o')+1]).write_bytes(('SYNTHETIC_OBJECT_'+owner).encode());text='synthetic normal\n'
        elif mode=='stock-leanchecker':text='synthetic checker\n'
        else:
            prefix=self.batch['owners'][:self.batch['owners'].index(owner)+1]
            imports=sorted(set(self.ext['parent_catalog'])|set(prefix))+['Init'];name=owner+'.fact'
            decl={'module':owner,'name':name,'type':'Nat','unsafe':False,'partial':False,'axiom':False,'axioms':[]}
            rows=[('IMPORTS',imports),('DECL',decl)];shared=[];serialized=[name]
            if self.bad_shared:
                shared=['synthetic.shared'];serialized+=shared
                rows.append(('SHARED',{**decl,'name':shared[0],'canonical_module':self.parent,'identical_metadata':True,'identical_body':False,'proof_body_kernel_checked':False}))
            rows += [('INVENTORY',{'module':owner,'serialized':serialized,'environment':[name],'shared':shared}),
                     ('COMPLETE',{'module':owner,'count':1,'shared_count':len(shared),'serialized_count':len(serialized)})]
            text=''.join('P26_CELL06_AUDIT_'+tag+' '+json.dumps(value)+'\n' for tag,value in rows)
        Path(log).write_text(text)
        return {'exit_code':0,'stop_reason':None,'seconds':0.0,'sampled_peak_tree_rss_bytes':0}
    def pre(self):return e.pre_anchor(self.epoch,self.ext,self.batch)
    def pending(self):
        pre=self.pre();history,pending=e.execute_pending(self.epoch,self.ext,self.batch,pre,self.fake)
        return pre,history,pending
    def normal(self):
        pre=self.pre();record=e.run_mode(self.epoch,self.ext,self.batch,self.batch['owners'][0],'normal',pre,[],{},self.fake)
        return pre,record
    def load(self,**kwargs):
        args={'family_sha':self.fp['sha256'],'batch_sha':self.batch['_anchor']['sha256'],
              'controller_sha':pin(ROOT/'family_controller.py')['sha256'],'parent_sha':self.batch['parent_context']['sha256']}
        args.update(kwargs);return e.load_contract(self.epoch,**args)


class FamilyTests(unittest.TestCase):
    def setUp(self):self.f=Fixture()
    def tearDown(self):self.f.close()

    def test_exact_next8_and_singleton_tail(self):
        f=self.f;f.freeze(count=8);seal=e.run_batch(f.epoch,f.ext,f.batch,f.fake)
        self.assertEqual(len(read(seal['path'])['owners']),8);self.assertEqual(sum(f.calls.values()),24)
        parent=pin(f.epoch/'accepted-contexts'/(f.targets[7]+'.json'))
        f.freeze(name='tail',count=1,parent=parent);self.assertEqual(f.batch['owners'],[f.targets[8]])
        e.run_batch(f.epoch,f.ext,f.batch,f.fake);self.assertEqual(sum(f.calls.values()),27)
        self.assertEqual(read(f.epoch/'accepted-contexts'/(f.targets[8]+'.json'))['accepted_since_family_base'],f.targets)

    def test_next_epoch_inherits_sealed_audit_without_reparsing_all_ancestor_logs(self):
        f=self.f;f.freeze();e.run_batch(f.epoch,f.ext,f.batch,f.fake)
        parent=pin(f.epoch/'accepted-contexts'/(f.targets[1]+'.json'))
        with patch.object(e,'parse_mode',side_effect=AssertionError('Repeated ancestor audit semantic parse')):
            f.freeze(name='successor',count=1,parent=parent)
        self.assertEqual(f.batch['owners'],[f.targets[2]])

    def test_first8_next8_single_tail_and_zero_duplicate_normals(self):
        self.f.close();self.f=Fixture(n=17);f=self.f
        for index,count in enumerate((8,8,1),1):
            f.freeze(name='epoch'+str(index),count=count,parent=f.parent_pin)
            e.run_batch(f.epoch,f.ext,f.batch,f.fake)
            f.parent_pin=pin(f.epoch/'accepted-contexts'/(f.batch['owners'][-1]+'.json'))
        self.assertEqual(len(read(f.parent_pin['path'])['project_closure']),18)
        self.assertEqual(read(f.parent_pin['path'])['accepted_since_family_base'],f.targets)
        self.assertEqual(sum(f.calls.values()),51)
        for owner in f.targets:self.assertEqual(f.calls[(owner,'normal')],1)

    def test_other_root_complete_failed_attempt_still_needs_explicit_transport(self):
        f=self.f;f.freeze();owner=f.targets[0];attempt=f.family/'old-search/failed/steps'/owner/'normal/one';attempt.mkdir(parents=True)
        command=dump(attempt/'COMMAND.json',{'identity':{'key':owner,'mode':'normal'}})
        log=attempt/'output.log';log.write_text('failed fake process')
        dump(attempt/'RESULT.json',{'command':command,'exit_code':1,'stop_reason':None,'seconds':0.1,'sampled_peak_tree_rss_bytes':1,'log':pin(log),'object':None})
        with self.assertRaisesRegex(RuntimeError,'failed-attempt transport'):e.refuse_other_stage_normal(f.epoch,f.ext,owner)

    def test_exact_attempt_local_inputs_cannot_be_transplanted(self):
        f=self.f;f.freeze();pre,record=f.normal();command=read(record['command']['path'])
        wrong=f.epoch/'wrong-inputs.json';wrong.write_bytes(Path(command['local_inputs']['path']).read_bytes());command['local_inputs']=pin(wrong)
        rewrite(record['command']['path'],command)
        with self.assertRaises(RuntimeError):e.find_record(f.epoch,f.ext,f.batch,f.targets[0],'normal',pre)

    def test_snapshot_from_another_batch_is_rejected(self):
        f=self.f;f.freeze();pre=f.pre();report=read(pre['path']);report['batch']={**report['batch'],'sha256':'0'*64};rewrite(pre['path'],report)
        with self.assertRaises(RuntimeError):e.validate_snapshot(pin(pre['path']),f.epoch,f.ext,f.batch,'PRE')

    def test_unknown_mode_sidefile_cannot_be_sealed(self):
        f=self.f;f.freeze();pre,history,pending=f.pending()
        attempt=Path(history[0]['command']['path']).parent;(attempt/'unrecorded.dat').write_text('not an allowed mode artifact')
        with self.assertRaises(RuntimeError):e.finish(f.epoch,f.ext,f.batch,pre,history,pending)

    def test_later_epoch_restores_historical_canonical_without_normal(self):
        f=self.f;f.freeze();e.run_batch(f.epoch,f.ext,f.batch,f.fake)
        parent=pin(f.epoch/'accepted-contexts'/(f.targets[1]+'.json'));object_path(f.family,f.targets[0]).unlink()
        f.freeze(name='next',count=1,parent=parent);e.run_batch(f.epoch,f.ext,f.batch,f.fake)
        self.assertEqual(f.calls[(f.targets[0],'normal')],1);self.assertTrue(object_path(f.family,f.targets[0]).exists())

    def test_non_normal_object_sidefile_rejected(self):
        f=self.f;f.freeze();pre,history,pending=f.pending()
        stock=next(row for row in history if row['mode']=='stock-leanchecker')
        (Path(stock['command']['path']).parent/'normal.olean').write_bytes(b'unclaimed side object')
        with self.assertRaises(RuntimeError):e.finish(f.epoch,f.ext,f.batch,pre,history,pending)

    def test_unknown_non_json_state_sidefile_rejected(self):
        f=self.f;f.freeze();pre,history,pending=f.pending();(f.epoch/'state/unclaimed.bin').write_bytes(b'extra')
        with self.assertRaises(RuntimeError):e.finish(f.epoch,f.ext,f.batch,pre,history,pending)

    def test_count_zero_nine_padding_rejected(self):
        for count in (0,9,-1):
            with self.assertRaises(RuntimeError):next_owners(self.f.targets,set(),count)
        with self.assertRaises(RuntimeError):next_owners(self.f.targets,set(self.f.targets[:8]),2)

    def test_normal_never_reexecuted_missing_marker_and_canonical(self):
        f=self.f;f.freeze();pre,record=f.normal();Path(record['marker']['path']).unlink()
        e.catalog_objects(f.epoch,f.ext,{f.targets[0]:record});object_path(f.family,f.targets[0]).unlink()
        e.run_batch(f.epoch,f.ext,f.batch,f.fake);self.assertEqual(f.calls[(f.targets[0],'normal')],1)

    def test_missing_post_only_runs_post(self):
        f=self.f;f.freeze();f.pending();calls=dict(f.calls)
        def forbidden(*args):self.fail('Executor called after all modes complete')
        seal=e.run_batch(f.epoch,f.ext,f.batch,forbidden)
        self.assertTrue(read(seal['path'])['formal_acceptance']);self.assertEqual(f.calls,calls)
        self.assertEqual(len(list((f.epoch/'state').glob('POST-*'))),1)
        self.assertEqual(len(list((f.epoch/'state').glob('RESUME-*'))),0)

    def test_global_post_actually_reads_after_pre(self):
        f=self.f;f.freeze();pre,history,pending=f.pending();original=f.lib.read_bytes();f.lib.write_bytes(b'changed')
        with self.assertRaises(RuntimeError):e.finish(f.epoch,f.ext,f.batch,pre,history,pending)
        f.lib.write_bytes(original)
        with self.assertRaisesRegex(RuntimeError,'Sticky'):e.run_batch(f.epoch,f.ext,f.batch,f.fake)
        self.assertFalse((f.epoch/'state/BATCH_ACCEPTED.json').exists())

    def test_wrong_external_sha_rejects_without_poison(self):
        f=self.f;f.freeze()
        for key in ('family_sha','batch_sha','controller_sha','parent_sha'):
            with self.assertRaises(RuntimeError):f.load(**{key:'0'*64})
        self.assertFalse((f.family/'state/INTEGRITY_FAILED.json').exists());f.load()

    def test_pending_artifact_tamper_is_sticky_even_after_restore(self):
        f=self.f;f.freeze();pre,normal=f.normal();artifact=Path(normal['object']['path']);original=artifact.read_bytes()
        artifact.write_bytes(b'bad')
        with self.assertRaises(RuntimeError):e.run_mode(f.epoch,f.ext,f.batch,f.targets[0],'stock-leanchecker',pre,[normal],{f.targets[0]:normal},f.fake)
        artifact.write_bytes(original)
        with self.assertRaisesRegex(RuntimeError,'Sticky'):e.run_batch(f.epoch,f.ext,f.batch,f.fake)

    def test_shared_body_false_cannot_seal(self):
        f=self.f;f.freeze();f.bad_shared=True
        with self.assertRaises(RuntimeError):e.run_batch(f.epoch,f.ext,f.batch,f.fake)
        self.assertFalse((f.epoch/'state/BATCH_ACCEPTED.json').exists())

    def test_unknown_command_refuses_guess_normal(self):
        f=self.f;f.freeze();pre,normal=f.normal();attempt=Path(normal['command']['path']).parent
        for name in ('RESULT.json','PENDING.json'):(attempt/name).unlink()
        with self.assertRaisesRegex(RuntimeError,'Unknown COMMAND'):e.run_batch(f.epoch,f.ext,f.batch,f.fake)
        self.assertEqual(f.calls[(f.targets[0],'normal')],1)

    def test_inherited_successful_normal_blocked_across_root(self):
        f=self.f;f.freeze();owner=f.targets[0];attempt=f.family/'old-search/foreign/steps'/owner/'normal/one';attempt.mkdir(parents=True)
        command=dump(attempt/'COMMAND.json',{'identity':{'key':owner}})
        dump(attempt/'RESULT.json',{'command':command,'exit_code':0,'stop_reason':None})
        with self.assertRaises(RuntimeError):e.refuse_other_stage_normal(f.epoch,f.ext,owner)

    def test_unsealed_epoch_blocks_new_epoch(self):
        f=self.f;f.freeze();f.normal()
        with self.assertRaises(RuntimeError):c.freeze_epoch(f.family,f.ext,f.parent_pin,'bypass',1)
        self.assertFalse((f.family/'batches/bypass').exists())

    def test_transport_original_identity_and_independent_inode(self):
        f=self.f;source=f.family/'history.json';source.write_text('{"identity":{"contract":"ORIGINAL"}}\n')
        rows=transport_evidence(f.family,[pin(source)]);validate_transport(rows)
        self.assertEqual(Path(rows[0]['physical']['path']).read_bytes(),source.read_bytes())
        self.assertNotEqual(Path(rows[0]['physical']['path']).stat().st_ino,source.stat().st_ino)
        self.assertEqual(resolve_historical(pin(source),rows),rows[0]['physical'])
        wrong={**pin(source),'sha256':'0'*64}
        with self.assertRaises(RuntimeError):resolve_historical(wrong,rows)

    def test_source_changed_before_next_mode_sticky(self):
        f=self.f;f.freeze();pre,normal=f.normal();source=source_path(f.family,f.targets[1]);original=source.read_bytes();source.write_text('-- changed\n')
        with self.assertRaises(RuntimeError):e.run_mode(f.epoch,f.ext,f.batch,f.targets[1],'normal',pre,[normal],{f.targets[0]:normal},f.fake)
        source.write_bytes(original)
        with self.assertRaisesRegex(RuntimeError,'Sticky'):e.run_batch(f.epoch,f.ext,f.batch,f.fake)

    def test_wrong_log_transplant_rejected_sticky(self):
        f=self.f;f.freeze();pre,record=f.normal();result=read(record['result']['path']);original=Path(record['result']['path']).read_bytes()
        wrong=f.epoch/'other.log';wrong.write_text(Path(result['log']['path']).read_text());result['log']=pin(wrong);rewrite(record['result']['path'],result)
        with self.assertRaises(RuntimeError):e.find_record(f.epoch,f.ext,f.batch,f.targets[0],'normal',pre)
        Path(record['result']['path']).write_bytes(original)
        with self.assertRaisesRegex(RuntimeError,'Sticky'):e.run_batch(f.epoch,f.ext,f.batch,f.fake)

    def test_process_return_fields_must_match_result(self):
        f=self.f;f.freeze();pre,record=f.normal();result=read(record['result']['path']);result['seconds']=12;rewrite(record['result']['path'],result)
        with self.assertRaises(RuntimeError):e.find_record(f.epoch,f.ext,f.batch,f.targets[0],'normal',pre)

    def test_mode_cannot_claim_per_step_global_success(self):
        f=self.f;f.freeze();pre,record=f.normal();result=read(record['result']['path']);result['postcheck']={'allmatched':True};rewrite(record['result']['path'],result)
        with self.assertRaises(RuntimeError):e.find_record(f.epoch,f.ext,f.batch,f.targets[0],'normal',pre)

    def test_invalid_freeze_count_does_not_poison_family(self):
        f=self.f
        for count in (0,9,'2'):
            with self.assertRaises(RuntimeError):c.freeze_epoch(f.family,f.ext,f.parent_pin,'bad-count',count)
        self.assertFalse((f.family/'state/INTEGRITY_FAILED.json').exists());f.freeze(count=1)

    def test_tail_padding_count_rejects_without_poison(self):
        self.f.close();self.f=Fixture(n=1);f=self.f
        with self.assertRaises(RuntimeError):c.freeze_epoch(f.family,f.ext,f.parent_pin,'padded',2)
        self.assertFalse((f.family/'state/INTEGRITY_FAILED.json').exists())

    def test_wrong_declared_env_hash_sticky_after_matched_identity(self):
        f=self.f;f.freeze();path=f.epoch/'BATCH.json';value=read(path);value['environment_sha256']='0'*64;rewrite(path,value)
        f.batch=read(path);f.batch['_anchor']=pin(path)
        with self.assertRaises(RuntimeError):f.load()
        self.assertTrue((f.family/'state/INTEGRITY_FAILED.json').exists())

    def test_wrong_global_selector_sticky(self):
        f=self.f;f.freeze();selector=Path(f.batch['global_inputs']['path']);original=selector.read_bytes();selector.write_text('{}')
        with self.assertRaises(RuntimeError):f.load()
        selector.write_bytes(original)
        with self.assertRaisesRegex(RuntimeError,'Sticky'):f.load()

    def test_cross_root_ambiguous_normal_observation_cannot_be_erased(self):
        f=self.f;f.freeze();owner=f.targets[0];attempt=f.family/'old-search/foreign/steps'/owner/'normal/one';attempt.mkdir(parents=True)
        command=dump(attempt/'COMMAND.json',{'identity':{'key':owner}})
        with self.assertRaises(RuntimeError):e.run_batch(f.epoch,f.ext,f.batch,f.fake)
        Path(command['path']).unlink()
        with self.assertRaisesRegex(RuntimeError,'Sticky'):e.run_batch(f.epoch,f.ext,f.batch,f.fake)

    def test_other_root_malformed_result_is_never_treated_as_failure(self):
        f=self.f;f.freeze();owner=f.targets[0]
        attempt=f.family/'old-search/foreign/steps'/owner/'normal/one';attempt.mkdir(parents=True)
        command=dump(attempt/'COMMAND.json',{'identity':{'key':owner}})
        result_path=attempt/'RESULT.json'
        for value in ({'command':command},{'command':command,'exit_code':None},{'command':command,'exit_code':'1'},
                      {'command':command,'exit_code':False},{'command':command,'exit_code':1,'stop_reason':None}):
            rewrite(result_path,value)
            with self.assertRaises(RuntimeError):e.refuse_other_stage_normal(f.epoch,f.ext,owner)

    def test_process_return_is_in_every_later_mode_D(self):
        f=self.f;f.freeze();pre,record=f.normal()
        result=read(record['result']['path']);ret=result['process_return']
        local=e.delta_items(f.epoch,f.ext,f.batch,f.targets[0],'stock-leanchecker',[record],{f.targets[0]:record})
        self.assertIn(ret,local)

    def test_historical_accepted_evidence_tamper_cannot_be_re_pinned_green(self):
        f=self.f;f.freeze();seal=e.run_batch(f.epoch,f.ext,f.batch,f.fake)
        parent=pin(f.epoch/'accepted-contexts'/(f.targets[1]+'.json'));old_epoch=f.epoch
        old_log=next((old_epoch/'steps').rglob('output.log'));original=old_log.read_bytes();old_log.write_bytes(b'changed old accepted log')
        f.freeze(name='next',count=1,parent=parent)
        with self.assertRaises(RuntimeError):e.run_batch(f.epoch,f.ext,f.batch,f.fake)
        old_log.write_bytes(original)
        with self.assertRaisesRegex(RuntimeError,'Sticky'):e.run_batch(f.epoch,f.ext,f.batch,f.fake)

    def test_inherited_evidence_namespace_added_after_pre_is_rejected(self):
        f=self.f;f.freeze();e.run_batch(f.epoch,f.ext,f.batch,f.fake)
        parent=pin(f.epoch/'accepted-contexts'/(f.targets[1]+'.json'));old_epoch=f.epoch
        f.freeze(name='next',count=1,parent=parent);pre,history,pending=f.pending()
        (old_epoch/'unexpected-side-file').write_text('extra')
        with self.assertRaises(RuntimeError):e.finish(f.epoch,f.ext,f.batch,pre,history,pending)

    def test_success_normal_in_other_family_root_is_not_bypassed(self):
        f=self.f;f.freeze();owner=f.targets[0]
        with tempfile.TemporaryDirectory(prefix='OTHER-FAMILY-',dir=RUN) as temp:
            attempt=Path(temp)/'batches/old/steps'/owner/'normal/one';attempt.mkdir(parents=True)
            command=dump(attempt/'COMMAND.json',{'identity':{'key':owner}})
            dump(attempt/'RESULT.json',{'command':command,'exit_code':0,'stop_reason':None})
            with self.assertRaises(RuntimeError):e.refuse_other_stage_normal(f.epoch,f.ext,owner)

    def test_env_allowlist_has_no_inherited_secrets(self):
        f=self.f;f.freeze()
        with patch.dict('os.environ',{'LD_PRELOAD':'bad','PYTHONPATH':'bad','TUNNEL_API_TOKEN':'secret'}):
            env=env_for(f.epoch,f.ext)
        self.assertNotIn('LD_PRELOAD',env);self.assertNotIn('PYTHONPATH',env);self.assertNotIn('TUNNEL_API_TOKEN',env)
        self.assertIn('-DwarningAsError=true',flags(f.ext));self.assertIn('--trust=0',flags(f.ext))


if __name__=='__main__':
    started=time.monotonic();result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(sys.modules[__name__]))
    dump(RUN/'HOST_TEST_RESULTS.json',{'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
        'seconds':time.monotonic()-started,'Lean_commands':0,'MCP_jobs':0,'real_prepare':False,'formal_acceptance':False,'P2_6_complete':False,
        'code_pins':[pin(ROOT/name) for name in ('family_common.py','family_controller.py','family_engine.py','test_family_host.py')]})
    sys.exit(not result.wasSuccessful())
