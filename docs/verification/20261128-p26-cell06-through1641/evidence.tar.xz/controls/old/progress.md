# Execution ledger — plan: IMPLEMENTATION_PLAN.md

Ruling: use this explicitly authorized fresh non-git root as isolation; do not create a worktree, commit, or write skill scratch outside it — root forbids all provider/repository mutations.
Pre-flight: parent_certificate output and family cold seed share fixed ABI; parent owns certificate/test files. Epoch engine consumes parent catalog derived from current accepted prefix rather than static1504. G physical byte inventory remains complete; metadata references do not replace reads.
Task1: pending (tests first). No real prepare/Lean/MCP has run.

Task1: complete — exact1..8 scheduling RED(absent implementation)→GREEN; invalid range and tail padding reject without sticky poison.
Task2: implementation complete / production unexecuted — cold seed original-byte evidence transport, full selected first root, no shared-runtime copy; parent certificate root code frozen a7a8/27fb and separately qualified/reviewed by root. No claim that seed has run.
Task3: complete in synthetic host scope — persistent family metadata inheritance; first8→next8→singleton tail:51 modes,17 normals each once. Ancestor audit reparse RED→GREEN test ensures epoch reuse does not repeat old proof semantic computation.
Task4: complete in synthetic host scope — reviewed batch-window state machine port; exact PROCESS_RETURN/D binding, pending success barriers, full-owned parser and no-repeat normal recovery.
Task5: complete —36 host tests GREEN. Recorded RED→GREEN fixes include frozen-source D, cross-root ambiguous normal sticky persistence, inherited evidence namespace, malformed foreign RESULT schema, PROCESS_RETURN included in each later D, non-normal .olean and non-JSON state sidefiles. Initial red logs retained; no old passed proof/tests rerun.
Ruling: cross-root failed attempts are not a migration permission — after strict process schema/log/object binding, even complete foreign failure blocks pending explicit transport. Same-epoch actual failed process retries retain the reviewed behavior; cost is manual review for cross-root failed-attempt migration.
Ruling: later epochs inherit externally pinned sealed raw evidence, then real G checks all its bytes — no full ancestor audit log reparse or prior global scan per prefix. The sealed code/identity links remain original; cost is a new explicit protocol boundary rather than pretending old per-command checks ran again.
Self-review: found/closed two sidefile omissions by RED→GREEN; independent reviewer coordinated by root is the final review authority. No real prepare, Lean, lake, MCP, git, source regeneration, provider write or new agent was performed.
