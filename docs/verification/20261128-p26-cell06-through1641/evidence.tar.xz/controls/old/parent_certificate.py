"""Read-only qualification of the fixed, already accepted Cell06 1504 prefix.

No provider recovery, sticky writes, compiler or proof execution is permitted.
The inherited environment inventory may run read-only Git metadata queries.
Byte checks are deduplicated only within one explicit collection transaction.
"""
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re
import sys

sys.dont_write_bytecode = True
PARENT_SHA = 'c19494c887e8768213dfb8c15b43fc36f2f52c72d527a86f8095f4a66f25dcb8'
GRAPH_SHA = '0c0930dc27e9ee532ac4a8c78afb2dfb5c9cf40a364076e50cddae7f4cf8dd02'
EXT_SHA = '94ef902b323ff2b041045c08d315b4b89e86ee769c5797ea8b7f2a01aeb4b376'
BATCH_SHA = '32536b97ddaa017be6872d73efbdc8fb837a33763f55f98e50be7c27b1c67209'
SEAL_SHA = 'b3859d41dbfd10ea78ab4452d8e779989d4a00bd40748a1100c2c0e241e0c7e1'
DELIVERY_SHA = '484a28bb2a39836d86120e04b699bda12b8e9c5af33fef0c84699ab6bd7e9a24'
HELPER_SHA = '4e35f4d11c38e76ece4bdc429476e4fa4746c3c082f8db8eaea42b91d7a156bc'
OLD_STAGE_SHA = '83affec77d951a27ec2b7a172fea4e8c43c1d64579f173e275521b45689ccb41'
FOUNDATION_SHA = 'd528a2f388f10c22b89c218e675b534a76de129de50054fd1dc4a68e66398ad1'
BATCH_ROOT = Path('/workspace/p26-cell06-batch-boundary-20261128')
STAGE = BATCH_ROOT / 'stages/batch01'
OLD_STAGE = Path('/workspace/p26-cell06-source-candidate-20261128/runner/stages/cell06-parent1499-v1')
OLD_INPUT = 'ImbalancedChen.P2OriginalSaving19Geometry06ScalableInput'
OLD_DATA = ['ImbalancedChen.P2OriginalSaving19ArchiveGeometryData06', 'ImbalancedChen.P2OriginalSaving19ArchiveMomentData06']
OWNERS = ['ImbalancedChen.P2OriginalSaving19Moment06Input', 'ImbalancedChen.P2OriginalSaving19Geometry06ScalableActive8EnumerationBlock000']
MODES = ['normal', 'stock-leanchecker', 'full-owned']
PROTOCOL = 'batch_global_boundary_v1'
PROCESS_FIELDS = {'exit_code', 'stop_reason', 'seconds', 'sampled_peak_tree_rss_bytes'}


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def validate_pin(item):
    require(isinstance(item, dict) and set(item) == {'path', 'bytes', 'sha256'}, 'Malformed pin fields')
    require(isinstance(item['path'], str) and Path(item['path']).is_absolute(), 'Pin needs absolute path')
    require(type(item['bytes']) is int and item['bytes'] >= 0, 'Malformed pin byte count')
    require(isinstance(item['sha256'], str) and re.fullmatch('[0-9a-f]{64}', item['sha256']) is not None, 'Malformed pin digest')
    return item


def unique_pins(items):
    result = {}
    for item in items:
        validate_pin(item)
        require(result.setdefault(item['path'], item) == item, 'Conflicting pin: ' + item['path'])
    return [result[key] for key in sorted(result)]


def validate_attempt_fields(identity, command, result, returned):
    require(command['identity'] == returned['identity'] == identity, 'Attempt identity differs')
    require(returned['command'] == result['command'] and returned['log'] == result['log']
            and returned['object'] == result.get('object'), 'Transplanted command/log/object')
    fields = returned['process_result']
    require(set(fields) == PROCESS_FIELDS, 'Unexpected process fields')
    require(type(fields['exit_code']) is int and type(fields['seconds']) in (int, float)
            and math.isfinite(fields['seconds']) and fields['seconds'] >= 0 and type(fields['sampled_peak_tree_rss_bytes']) is int
            and fields['sampled_peak_tree_rss_bytes'] >= 0, 'Invalid process status/timing')
    require(all(result[key] == fields[key] for key in PROCESS_FIELDS), 'Durable process return differs')
    require(result['exit_code'] == 0 and result['stop_reason'] is None, 'Parent process did not succeed')


def validate_certificate_metadata(cert, *, expected_count=1504):
    """Structural validator; only collect_1504_parent establishes real provenance."""
    require(cert['verified_parent_formal_acceptance'] is True and cert['formal_acceptance'] is False,
            'Transport certificate cannot accept a new mathematical module')
    require(len(cert['project_closure']) == expected_count, 'Wrong parent catalog size')
    require(len(cert['native_artifacts']) == 555, 'Incomplete native inventory')
    validate_pin(cert['accepted_context']);validate_pin(cert['graph'])
    require(cert['accepted_context']['sha256'] == PARENT_SHA and cert['graph']['sha256'] == GRAPH_SHA,
            'Wrong fixed parent/graph roots')
    require(len(cert['normal_barriers']) == 5 and {row['module'] for row in cert['normal_barriers']} == set(OLD_DATA + [OLD_INPUT] + OWNERS),
            'Incomplete original normal barrier set')
    for row in cert['normal_barriers']:
        require(row['status'] == ('old_normal_forbidden' if row['module'] in OLD_DATA else 'accepted_normal'), 'Wrong normal barrier role')
        validate_pin(row['source']);validate_pin(row['permanent_object'])
        if row['module'] in OLD_DATA:
            require(row['normal_receipt'] is None, 'Do not invent a Data06 normal receipt')
        else:
            validate_pin(row['normal_receipt'])
    require(len(cert['remaining_order']) == len(set(cert['remaining_order'])) == 329, 'Remaining graph order incomplete')
    require(not set(cert['remaining_order']) & set(cert['project_closure']), 'Already accepted normal is scheduled again')
    require(set(cert['accepted_graph_modules']) == set(OLD_DATA + [OLD_INPUT] + OWNERS), 'Accepted graph intersection differs')
    return cert


def _load_helpers():
    path = BATCH_ROOT / 'approved_helpers.py'
    require(hashlib.sha256(path.read_bytes()).hexdigest() == HELPER_SHA, 'Frozen helper loader changed')
    spec = importlib.util.spec_from_file_location('_p26_readonly_approved_helpers', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.OLD


def collect_1504_parent(parent_context: Path, expected_parent_sha256: str,
                        graph_path: Path, expected_graph_sha256: str) -> dict:
    require(expected_parent_sha256 == PARENT_SHA and expected_graph_sha256 == GRAPH_SHA, 'Unsupported externally anchored parent/graph')
    parent_context, graph_path = Path(parent_context).absolute(), Path(graph_path).absolute()
    require(parent_context == STAGE / 'accepted-contexts' / (OWNERS[-1] + '.json'), 'Wrong accepted context location')
    OLD = _load_helpers()
    ev, ctl = OLD.evidence, OLD.controller
    seen, preserve = {}, {}

    def remember(item, copy=False):
        validate_pin(item);require(seen.setdefault(item['path'], item) == item, 'Conflicting historical input pin')
        ev.check(item)
        if copy:preserve[item['path']] = item
        return item

    def read_pin(item, copy=True):
        remember(item, copy);return ev.read_pinned(item)

    def rooted(path, sha):
        item = ev.pin(path);require(item['sha256'] == sha, 'External root digest differs: ' + str(path))
        return read_pin(item), item

    with ev.verification_transaction():
        parent, parent_pin = rooted(parent_context, PARENT_SHA)
        graph, graph_pin = rooted(graph_path, GRAPH_SHA)
        delivery, delivery_pin = rooted(BATCH_ROOT / 'DELIVERY_MANIFEST.json', DELIVERY_SHA)
        for row in delivery['members']:remember(row, True)
        extension, extension_pin = rooted(STAGE / 'BATCH_EXTENSION.json', EXT_SHA)
        batch, batch_pin = rooted(STAGE / 'BATCH.json', BATCH_SHA)
        seal, seal_pin = rooted(STAGE / 'state/BATCH_ACCEPTED.json', SEAL_SHA)
        require(extension['protocol'] == batch['protocol'] == seal['protocol'] == PROTOCOL, 'Wrong historical protocol')
        require(batch['owners'] == OWNERS and batch['concurrency'] == 1 and batch['failure_policy'] == 'atomic_two_owners', 'Wrong parent batch scope')
        require(batch['extension'] == seal['extension'] == extension_pin and seal['batch'] == batch_pin, 'Historical root identity differs')
        require(seal['formal_acceptance'] is True and seal['P2_6_complete'] is False and seal['status'] == 'BATCH_ACCEPTED', 'Unaccepted parent batch')
        require(parent['formal_acceptance'] is True and parent['P2_6_complete'] is False and parent['batch_seal'] == seal_pin, 'Wrong parent acceptance')
        require(parent['extension'] == extension_pin and parent['batch'] == batch_pin and parent['accepted_new_modules'] == OWNERS, 'Parent context scope differs')
        require(not (STAGE / 'state/INTEGRITY_FAILED.json').exists(), 'Provider integrity failure cannot be discarded')
        require(extension['graph'] == graph_pin and extension['same_source_graph_required'] is True
                and extension['source_repair_transport_implemented'] is False, 'Changed source graph is unsupported')
        global_pin = extension['global_inputs'];require(batch['global_inputs'] == global_pin, 'Global selector mismatch')
        global_rows = read_pin(global_pin)
        complete_global = unique_pins(global_rows + [global_pin, extension_pin, batch_pin])
        for row in complete_global:remember(row)
        map_sha = hashlib.sha256(b''.join(json.dumps(row, sort_keys=True, separators=(',', ':')).encode() + b'\n' for row in complete_global)).hexdigest()
        for purpose in ['PRE', 'POST']:
            report = read_pin(seal['global_' + purpose.lower()])
            require(report['protocol'] == PROTOCOL and report['purpose'] == purpose and report['global_validation_scope'] == 'batch_boundary', 'Wrong global window report')
            require(report['extension'] == extension_pin and report['batch'] == batch_pin and report['global_inputs'] == global_pin, 'Global report transplant')
            require(report['matched'] is True and report['mismatches'] == [] and report['files_checked'] == len(complete_global)
                    and report['bytes_read'] == sum(row['bytes'] for row in complete_global) and report['actual_map_sha256'] == map_sha, 'Global coverage/digest differs')
        pre = seal['global_pre']
        anchor_pin = ev.pin(STAGE / 'state/GLOBAL_PRE.json')
        require(read_pin(anchor_pin) == {'snapshot': pre, 'formal_acceptance': False}, 'PRE anchor differs')

        old_context, old_stage_pin = rooted(OLD_STAGE / 'STAGE.json', OLD_STAGE_SHA)
        require(extension['old_stage'] == old_stage_pin, 'Old stage ancestry differs')
        # These specifically audited helpers only read/check. No load_stage,
        # recovery, step, verify_accepted, dump or writable helper is called.
        ctl.validate_stage_parent(OLD_STAGE, old_context)
        ctl.validate_graph(graph, old_context['parent_catalog'])
        ctl.environment_inventory(old_context)
        data, data_path = ctl.qualified(OLD_STAGE)
        remember(ev.pin(data_path), True)
        foundation, foundation_pin = rooted(extension['foundation']['path'], FOUNDATION_SHA)
        require(foundation['accepted_parent'] == ev.pin(data_path) and foundation['stage_contract'] == old_stage_pin,
                '1502 ancestry differs')
        require(foundation['formal_acceptance'] is True and foundation['P2_6_complete'] is False
                and foundation['old_normal_recompilations'] == data['old_normal_recompilations'] == 0, 'Invalid inherited qualification')
        require(len(foundation['project_closure']) == 1502 and foundation['accepted_new_modules'] == [OLD_INPUT], 'Wrong 1502 foundation')
        require(foundation['runtime'] == data['runtime'] and foundation['native_artifacts'] == data['native_artifacts']
                and foundation['lean_path'] == data['lean_path'], '1502 fixed environment differs')
        old_env_hash = ev.environment_sha256(ctl.lean_environment(OLD_STAGE, old_context))
        require(len(foundation['receipts']) == 3, 'Missing original Input modes')
        for receipt, mode in zip(foundation['receipts'], MODES):
            ev.check_receipt_chain(receipt, old_stage_pin, OLD_INPUT, mode, old_env_hash, ctl.expected_argv(OLD_STAGE, old_context, OLD_INPUT, mode))
        ctl.validate_catalog(OLD_STAGE, old_context, graph, foundation['project_closure'], [OLD_INPUT])
        require(all(foundation['project_closure'][name] == value for name, value in data['project_closure'].items()), '1501 to1502 catalog differs')
        for owner_context in [data, foundation]:
            for receipt in owner_context['receipts']:
                stored = read_pin(receipt);result = read_pin(stored['result']);command = read_pin(result['command'])
                spec = read_pin(command['inputs'])
                for row in ev.expand_inputs(spec):remember(row)
                remember(result['log'], True)
                if result.get('object'):remember(result['object'], True)
        old_audit = read_pin(foundation['receipts'][-1]);old_audit_result = read_pin(old_audit['result'])
        require(old_audit['validated'] == ev.validate_audit(Path(old_audit_result['log']['path']).read_text(), [OLD_INPUT], set(foundation['project_closure']), data['external_modules']), 'Original Input audit differs')

        transport = read_pin(extension['transport'])
        require(transport['foundation'] == foundation_pin and transport['old_stage'] == old_stage_pin and transport['graph'] == graph_pin
                and transport['same_source_only'] is True and transport['old_normal_recompilations'] == 0
                and transport['independent_inode_copies'] is True, '1502 transport scope differs')
        require(len(transport['modules']) == 1502 and {row['module'] for row in transport['modules']} == set(foundation['project_closure']), 'Incomplete1502 transport')
        for row in transport['modules']:
            name = row['module'];original = foundation['project_closure'][name];copied = extension['parent_catalog'][name]
            for key, old_key, new_key in [('source', 'old_source', 'new_source'), ('selected_object', 'old_object', 'new_object')]:
                require(row[old_key] == original[key] and row[new_key] == copied[key], 'Wrong transport mapping')
                require(all(original[key][part] == copied[key][part] for part in ['bytes', 'sha256']), 'Transport byte mismatch')
                remember(original[key]);remember(copied[key])
                require(Path(original[key]['path']).stat().st_ino != Path(copied[key]['path']).stat().st_ino
                        or Path(original[key]['path']).stat().st_dev != Path(copied[key]['path']).stat().st_dev, 'Transport aliases provider inode')
        require(extension['runtime'] == parent['runtime'] == foundation['runtime'] and extension['external_modules'] == data['external_modules'], 'Runtime/external inventory differs')
        require(extension['native_artifacts'] == parent['native_artifacts'] and len(parent['native_artifacts']) == 555, 'Incomplete native transport')
        old_object_root = Path(foundation['lean_path'].split(':')[0])
        expected_native = [{**row, 'path': str(STAGE / 'objects' / Path(row['path']).relative_to(old_object_root))} for row in foundation['native_artifacts']]
        require(parent['native_artifacts'] == expected_native and transport['native_files'] == expected_native, 'Native paths/bytes differ')
        for old, new in zip(foundation['native_artifacts'], expected_native):
            remember(old);remember(new)
            require((Path(old['path']).stat().st_dev, Path(old['path']).stat().st_ino) != (Path(new['path']).stat().st_dev, Path(new['path']).stat().st_ino), 'Native provider inode reused')
        require(parent['lean_path'] == extension['lean_path'] == str(STAGE / 'objects') + ':' + foundation['lean_path'].split(':', 1)[1], 'Selected search path differs')

        old_normal = read_pin(foundation['receipts'][0]);old_normal_result = read_pin(old_normal['result'])
        require(all(old_normal_result['object'][part] == foundation['project_closure'][OLD_INPUT]['selected_object'][part] for part in ['bytes', 'sha256']), 'Old normal artifact differs')
        barriers = [{'module': name, 'source': parent['project_closure'][name]['source'],
                     'permanent_object': data['project_closure'][name]['selected_object'], 'normal_receipt': None,
                     'old_identity': [ev.read(receipt['path'])['identity'] for receipt in data['receipts']],
                     'status': 'old_normal_forbidden'} for name in OLD_DATA]
        barriers.append({'module': OLD_INPUT, 'source': parent['project_closure'][OLD_INPUT]['source'],
                         'permanent_object': old_normal_result['object'], 'normal_receipt': foundation['receipts'][0],
                         'old_identity': old_normal['identity'], 'status': 'accepted_normal'})
        expected_catalog = dict(extension['parent_catalog']);previous_parent = foundation_pin
        history = [];pending_objects = {};env_hash = ev.environment_sha256(ctl.lean_environment(STAGE, extension))
        require(env_hash == batch['environment_sha256'], 'Batch allowlist environment differs')
        require(len(seal['pending_mode_receipts']) == 6, 'Missing/excess parent modes')
        for index, owner in enumerate(OWNERS):
            for mode_index, mode in enumerate(MODES):
                marker_pin = seal['pending_mode_receipts'][3 * index + mode_index];marker = read_pin(marker_pin)
                attempt = Path(marker_pin['path']).parent
                require(attempt.parent == STAGE / 'steps' / owner / mode and marker_pin['path'] == str(attempt / 'PENDING.json'), 'Wrong historical attempt location')
                require(list(attempt.parent.iterdir()) == [attempt], 'Unknown/failed additional attempt requires explicit protocol')
                expected_identity = {'protocol': PROTOCOL, 'extension': extension_pin, 'batch': batch_pin, 'key': owner, 'mode': mode,
                                     'global_validation_scope': 'batch_boundary', 'batch_pre': pre, 'environment_sha256': env_hash,
                                     'argv': ctl.expected_argv(STAGE, extension, owner, mode), 'cwd': str(STAGE / 'project'),
                                     'timeout': extension['wall_seconds'], 'rss_bytes': extension['rss_gib'] * 1024**3}
                require(marker['identity'] == expected_identity and marker['formal_acceptance'] is False and marker['batch_post'] is None
                        and marker['P2_6_complete'] is False, 'Historical pending mode claims wrong identity or scope')
                require(marker['status'] == ('NORMAL_SUCCEEDED_PENDING_GLOBAL' if mode == 'normal' else 'PROCESS_VALIDATED_PENDING_GLOBAL'), 'Wrong marker role')
                require(marker['result']['path'] == str(attempt / 'RESULT.json'), 'Transplanted RESULT')
                result = read_pin(marker['result']);require(result['command']['path'] == str(attempt / 'COMMAND.json'), 'Transplanted COMMAND')
                command = read_pin(result['command']);require(command['local_inputs']['path'] == str(attempt / 'LOCAL_INPUTS.json'), 'Transplanted D')
                local = read_pin(command['local_inputs']);require(unique_pins(local) == local, 'Noncanonical local pin selector')
                for row in local:remember(row)
                require(result['log']['path'] == str(attempt / 'output.log') and result['process_return']['path'] == str(attempt / 'PROCESS_RETURN.json'), 'Transplanted log/return')
                remember(result['log'], True);returned = read_pin(result['process_return'])
                validate_attempt_fields(expected_identity, command, result, returned)
                require(returned['protocol'] == PROTOCOL and returned['formal_acceptance'] is False
                        and returned['status'] == 'PROCESS_RETURNED_PENDING_LOCAL_AND_GLOBAL_CHECKS'
                        and marker['process_return'] == result['process_return'], 'Durable-return role differs')
                require(result['command'] == ev.pin(attempt / 'COMMAND.json') and command['actual_argv'] == [str(attempt / 'normal.olean') if arg == '__NORMAL_OUTPUT__' else arg for arg in expected_identity['argv']], 'Actual command differs')
                require(result['protocol'] == PROTOCOL and result['global_validation_scope'] == 'batch_boundary' and result['formal_acceptance'] is False
                        and 'postcheck' not in result and result['local_post'] == {'inputs': command['local_inputs'], 'all_local_files_matched': True, 'file_count': len(local)}, 'Wrong per-mode validation scope')
                text = Path(result['log']['path']).read_text();require('sorryAx' not in text, 'Forbidden stored proof output')
                if mode == 'normal':
                    require(result['object']['path'] == str(attempt / 'normal.olean'), 'Wrong permanent normal artifact')
                    remember(result['object'], True);parsed = ctl.normal_validator(text, result);pending_objects[owner] = result['object']
                    barriers.append({'module': owner, 'source': parent['project_closure'][owner]['source'], 'permanent_object': result['object'],
                                     'normal_receipt': marker_pin, 'old_identity': expected_identity, 'status': 'accepted_normal'})
                else:
                    require(result.get('object') is None, 'Non-normal output object')
                    parsed = ({'stock_leanchecker_exit_zero': True} if mode == 'stock-leanchecker' else
                              ev.validate_audit(text, [owner], set(extension['parent_catalog']) | set(OWNERS[:index+1]), extension['external_modules']))
                require(marker['validated'] == parsed, 'Stored mode semantic validation differs')
                required = {'COMMAND.json', 'LOCAL_INPUTS.json', 'PROCESS_RETURN.json', 'RESULT.json', 'PENDING.json', 'output.log'} | ({'normal.olean'} if mode == 'normal' else set())
                require({path.name for path in attempt.iterdir()} == required, 'Unknown/missing attempt sidefile')
                history += [marker_pin, marker['result'], result['command'], command['local_inputs'], result['log'], *local]
                if result.get('object'):history.append(result['object'])
                history += [remember(ev.pin(path), True) for path in sorted(attempt.iterdir())]
            info = parent['project_closure'][owner];normal = pending_objects[owner]
            require(all(info['selected_object'][part] == normal[part] for part in ['bytes', 'sha256']) and info['normal_success_artifact'] == normal, 'Accepted object/permanent artifact mismatch')
            expected_catalog[owner] = info
            context_pin = ev.pin(STAGE / 'accepted-contexts' / (owner + '.json'));context = read_pin(context_pin)
            require(context['accepted_parent'] == previous_parent and context['project_closure'] == expected_catalog
                    and context['batch_seal'] == seal_pin and context['extension'] == extension_pin and context['batch'] == batch_pin
                    and context['formal_acceptance'] is True and context['P2_6_complete'] is False
                    and context['accepted_new_modules'] == OWNERS[:index+1] and context['global_validation_scope'] == 'batch_boundary', 'Accepted prefix chain differs')
            require(context['native_artifacts'] == parent['native_artifacts'] and context['runtime'] == parent['runtime'] and context['lean_path'] == parent['lean_path'], 'Prefix runtime/native/search changed')
            previous_parent = context_pin
        require(expected_catalog == parent['project_closure'] and previous_parent == parent_pin, '1504 union differs')
        state_files = {path for path in (STAGE / 'state').iterdir()}
        require(state_files == {Path(pre['path']), Path(seal['global_post']['path']), STAGE / 'state/GLOBAL_PRE.json', STAGE / 'state/BATCH_ACCEPTED.json'}, 'Unknown historical state/unfinished recovery')
        for path in state_files - {STAGE / 'state/BATCH_ACCEPTED.json'}:history.append(remember(ev.pin(path), True))
        require(unique_pins(history) == seal['delta_inputs'], 'Historical final D selector incomplete')
        for row in seal['delta_inputs']:remember(row)
        require({path.name for path in (STAGE / 'steps').iterdir()} == set(OWNERS), 'Unknown provider owner namespace')
        require({str(path.absolute()) for path in (STAGE / 'project').rglob('*') if path.is_file()} == set(extension['project_files']), 'Provider source namespace changed')
        expected_objects = {row['selected_object']['path'] for row in parent['project_closure'].values()} | {row['path'] for row in parent['native_artifacts']}
        require({str(path.absolute()) for path in (STAGE / 'objects').rglob('*') if path.is_file()} == expected_objects, 'Provider object namespace changed')
        for name, info in parent['project_closure'].items():
            for key in ['source', 'selected_object']:remember(info[key])
            if name in graph['entries']:
                require(all(info['source'][part] == graph['entries'][name]['source'][part] for part in ['bytes', 'sha256']), 'Graph source bytes changed')
        # Only proof/control evidence is copied. Fixed runtime/mathlib and the
        # historical provider object paths remain explicitly pinned references.
        external_roots = [Path(extension['environment']['mathlib_root']), Path(extension['environment']['sysroot'])]
        def shared(path):
            return any(Path(path).is_relative_to(root) for root in external_roots) or not Path(path).is_relative_to('/workspace')
        for item in list(seen.values()):
            path = Path(item['path'])
            if not shared(path) and (path.suffix in {'.json', '.jsonl', '.log', '.lean', '.py', '.md'} or '/steps/' in str(path) or '/helpers/' in str(path)):
                preserve[item['path']] = item
        historical_manifests = unique_pins([global_pin, old_context['baseline_inputs']])
        provenance = {'accepted1504': parent_pin, 'original1502': foundation_pin, 'old_stage': old_stage_pin,
                      'batch_extension': extension_pin, 'batch': batch_pin, 'batch_seal': seal_pin,
                      'batch_delivery': delivery_pin, 'old_delivery': OLD.delivery}
        cert = {'schema': 'p26_cell06_readonly1504_parent_certificate_v1', 'verified_parent_formal_acceptance': True, 'formal_acceptance': False,
                'accepted_context': parent_pin, 'graph': graph_pin, 'project_closure': parent['project_closure'],
                'native_artifacts': parent['native_artifacts'], 'runtime': parent['runtime'], 'environment': extension['environment'],
                'lean_path_tail': parent['lean_path'].split(':')[1:], 'external_modules': extension['external_modules'],
                'accepted_graph_modules': [name for name in graph['topological_order'] if name in parent['project_closure']],
                'remaining_order': [name for name in graph['topological_order'] if name not in parent['project_closure']],
                'normal_barriers': barriers, 'evidence_pins': unique_pins(preserve.values()),
                'shared_external_pins': unique_pins([item for item in seen.values() if shared(item['path'])]),
                'historical_global_manifests': historical_manifests, 'provenance_roots': provenance,
                'normal_search_roots': [str(OLD_STAGE.parent), str(STAGE.parent)],
                'verified_historical_input_count': len(seen), 'provider_recovery_permitted': False,
                'source_repair_transport_implemented': False}
        return validate_certificate_metadata(cert)
