"""Small negative tests for read-only certificate/attempt validators; no proofs."""
import copy
import unittest
import tempfile
import sys
from pathlib import Path

sys.path.insert(0,str(Path(__file__).resolve().parent))
import parent_certificate as p


class ParentValidators(unittest.TestCase):
    def test_reject_malformed_pin(self):
        for row in [{}, {'path': 'relative', 'bytes': 1, 'sha256': 'a'*64},
                    {'path': '/a', 'bytes': -1, 'sha256': 'a'*64},
                    {'path': '/a', 'bytes': True, 'sha256': 'a'*64},
                    {'path': '/a', 'bytes': 1, 'sha256': 'a'*63}]:
            with self.assertRaises(RuntimeError): p.validate_pin(row)

    def test_pin_conflict_rejected(self):
        a={'path':'/a','bytes':1,'sha256':'a'*64}
        self.assertEqual(p.unique_pins([a,a]),[a])
        b={**a,'bytes':2}
        with self.assertRaises(RuntimeError):p.unique_pins([a,b])

    def attempt(self):
        ident={'mode':'normal'}
        fields={'exit_code':0,'stop_reason':None,'seconds':1.0,'sampled_peak_tree_rss_bytes':10}
        command={'identity':ident}
        r={'command':{'path':'/x/COMMAND.json'},'log':{'path':'/x/output.log'},'object':{'path':'/x/normal.olean'},**fields}
        returned={'identity':ident,'command':r['command'],'log':r['log'],'object':r['object'],'process_result':fields}
        return ident,command,r,returned

    def test_process_fields_match(self):
        ident,command,r,returned=self.attempt()
        p.validate_attempt_fields(ident,command,r,returned)

    def test_process_fields_mismatch_rejected(self):
        ident,command,r,returned=self.attempt()
        for key,value in [('exit_code',1),('seconds',2),('stop_reason','timeout'),('sampled_peak_tree_rss_bytes',20)]:
            bad=copy.deepcopy(returned);bad['process_result'][key]=value
            with self.assertRaises(RuntimeError):p.validate_attempt_fields(ident,command,r,bad)

    def test_transplanted_log_identity_object_rejected(self):
        ident,command,r,returned=self.attempt()
        for key,value in [('identity',{'mode':'full-owned'}),('log',{'path':'/y/output.log'}),('object',{'path':'/y/normal.olean'}),('command',{'path':'/y/COMMAND.json'})]:
            bad=copy.deepcopy(returned);bad[key]=value
            with self.assertRaises(RuntimeError):p.validate_attempt_fields(ident,command,r,bad)

    def test_invalid_process_metrics_rejected(self):
        ident,command,r,returned=self.attempt()
        for key,value in [('seconds',True),('seconds',float('inf')),('seconds',float('nan')),
                          ('seconds',-1),('sampled_peak_tree_rss_bytes',True),('sampled_peak_tree_rss_bytes',-1)]:
            bad=copy.deepcopy(returned);bad['process_result'][key]=value
            wrong=copy.deepcopy(r);wrong[key]=value
            with self.assertRaises(RuntimeError):p.validate_attempt_fields(ident,command,wrong,bad)

    def test_unknown_roots_rejected_without_provider_write(self):
        with tempfile.TemporaryDirectory() as name:
            root=Path(name);before=list(root.iterdir())
            with self.assertRaises(RuntimeError):p.collect_1504_parent(root/'absent','0'*64,root/'absent-graph',p.GRAPH_SHA)
            self.assertEqual(list(root.iterdir()),before)


if __name__=='__main__':unittest.main(verbosity=2)
