# Cell06 persistent B8 family implementation

Binding design: /workspace/p26-cell06-next-batch-plan-20261128/DESIGN.md (SHA ea23a67370379ccf9adabd1939d11d099fa67cbeb2b3c418886809698b1b0fc2).

Only this new root is writable. Parent independently owns parent_certificate.py and test_parent_certificate.py; this implementer owns family_common.py, family_controller.py, family_engine.py, test_family_host.py and delivery documentation. No real prepare, Lean, lake, MCP, git, installation, source regeneration or provider write is permitted during implementation. All host tests use independent synthetic files; production CLI rejects fixtures.

1. Define failing host contracts for exact next1..8 scheduling, original-byte evidence transport, append-only namespace and no repeated normal; then implement the shared file/identity helpers.
2. Implement cold seed with the agreed collect_1504_parent API: readonly qualification once; independent1504 objects+555 native and all334 candidate sources; explicit original-pin -> physical-copy evidence map; runtime/mathlib stay shared; normal ledger includes2 forbiddenData+3 accepted normals. Freeze a family manifest and immutable base G. Seed accepts no new proof.
3. Implement epoch freeze under external controller/family/current-parent SHA: exact next1..8 only, helpers/whitelist immutable before PRE, complete current-parent catalog and all prior accepted evidence added to G through references. No source changes, graph extension, parallelism, bulk dispatcher or cross-source migration.
4. Port the reviewed batch-boundary state machine into a new explicit protocol; do not call/monkeypatch old step. Real G PRE/POST each batch; D exact before/after each mode and around POST; exact PROCESS_RETURN/COMMAND/log/object/PENDING chain; full-owned parser retains actual imports/canonical/shared/type/axiom evidence. Pending successful normals are permanent and cannot be re-executed. Unknown COMMAND refuses recovery.
5. Cover sticky integrity after restoring original bytes; missingPOST resumes POST only; canonical restoration from permanent artifacts without normal; cross-root barriers; incorrect contract/env/transport/provisional/shared/mode scope/source rejection; globalPOST always byte reads; support B1 tail and B8.
6. Freeze candidate code/document pins, host reports and exact CLI. No claim of real code execution or proof acceptance. Root arranges independent review and subsequent explicit execution.

Resource reporting separates cold seed, epoch metadata, G PRE/POST, D pre/post, proof process and final seal. Actual B8 time/memory/disk is unknown until first8 real execution.
