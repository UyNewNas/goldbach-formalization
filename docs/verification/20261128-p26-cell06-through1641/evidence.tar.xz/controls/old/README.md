# Cell06 persistent family / serial B8 candidate

This is a new `family_batch_global_boundary_v1` controller. It has not been used to seed a real family or run Lean. The inherited1504 prefix is already formally accepted under its original contracts; this delivery adds no formal credit and keeps `P2_6_complete:false`.

The code uses the executing-plans and test-driven-development skills. Its explicitly authorized fresh root replaces a git worktree; no existing repository/provider/stage has been modified. Root independently owns the frozen parent validator/test pair. All execution remains subject to root's subsequent review and explicit MCP submission.

## Files and trust boundary

- `parent_certificate.py`: pure-readonly fixed1504 qualification/collector, root's frozen module SHA `a7a8ecdb0c7126258846629b5097e1589afd1d919e9373cdaf8e9a1bb909e6b2`.
- `family_common.py`: exact streaming byte pins, exclusive creation, independent inode copies, original-byte transport, allowlist Lean environment, source/normal paths and family+epoch sticky failure.
- `family_controller.py`: one cold seed, metadata-only sealed-prefix inheritance and one explicit next1..8 epoch freeze; no automatic bulk loop.
- `family_engine.py`: independent batch identity/state machine. Only audited readonly hashing/process/audit templates/parsers are imported from the old reviewed controller; no old step, main, prepare, recovery, monkeypatch, or provider write is used.
- `test_family_host.py`: synthetic file/state tests and fake executor. CLI rejects all fixtures. No real proof subprocess, real family seed, or MCP job occurs in these tests.
- `build_engine_source.py`: archived one-time initial source derivation, not a controller entrypoint; exclusive output refuses to overwrite the current engine. The final engine contains subsequent reviewed adaptations, so this archival script is not a regeneration recipe for final code.

The fixed graph is334 modules,332 new normal targets plus2 oldData. The inherited1504 catalog contains5 graph modules;329 remain. First exact8 are Geometry06ScalableActive8EnumerationBlock001 through008. Later batches accept1..8 exact remaining owners, and329 mod8=1 requires a singleton tail. No padding, skipping, repetition, parallel mode, source change, graph expansion or postfinite17 extension is implemented.

## Production CLI (root executes only after review)

Use the final `DELIVERY_MANIFEST.json` controller SHA literally as `CONTROLLER_SHA`. Do not rerun the independent74s parent pretest. Formal cold seed necessarily performs one new production qualification to bind its own actual inputs.

```bash
python -B /workspace/p26-cell06-family-20261128/family_controller.py seed \
  --controller-sha256 CONTROLLER_SHA \
  --family /workspace/p26-cell06-family-20261128/families/main \
  --parent-context /workspace/p26-cell06-batch-boundary-20261128/stages/batch01/accepted-contexts/ImbalancedChen.P2OriginalSaving19Geometry06ScalableActive8EnumerationBlock000.json \
  --parent-sha256 c19494c887e8768213dfb8c15b43fc36f2f52c72d527a86f8095f4a66f25dcb8 \
  --graph /workspace/p26-cell06-source-candidate-20261128/CANDIDATE_GRAPH_v2.json \
  --graph-sha256 0c0930dc27e9ee532ac4a8c78afb2dfb5c9cf40a364076e50cddae7f4cf8dd02 \
  --rss-gib 12 --wall-seconds 2400
```

Seed prints the exact `FAMILY.json` pin, qualification time and total cold-seed time. Use that actual SHA as `FAMILY_SHA`. Read/pin its `BASE_CONTEXT.json`; use that exact SHA as `BASE_CONTEXT_SHA`. The base context explicitly marks original accepted1504 transport, not a newly proved module.

```bash
python -B /workspace/p26-cell06-family-20261128/family_controller.py freeze \
  --controller-sha256 CONTROLLER_SHA \
  --family /workspace/p26-cell06-family-20261128/families/main \
  --family-sha256 FAMILY_SHA \
  --parent-context /workspace/p26-cell06-family-20261128/families/main/BASE_CONTEXT.json \
  --parent-sha256 BASE_CONTEXT_SHA --epoch first8 --count 8

python -B /workspace/p26-cell06-family-20261128/family_controller.py run \
  --controller-sha256 CONTROLLER_SHA \
  --epoch-directory /workspace/p26-cell06-family-20261128/families/main/batches/first8 \
  --family-sha256 FAMILY_SHA --batch-sha256 FIRST8_BATCH_SHA \
  --parent-sha256 BASE_CONTEXT_SHA
```

`FIRST8_BATCH_SHA` must be the actual freeze output, never a predicted placeholder. For every later explicit epoch, use the preceding sealed batch's **last** accepted context and its exact SHA; use a fresh epoch name and the desired exact next count1..8. First8 success would yield1512; no current file claims1512 exists. Root will review actual first8 performance before considering any further batch.

The global controller lock serializes all CLI invocations under this root. Legacy controllers are readonly providers and must remain retired. Additional roots/versions need explicit reviewed transport and barrier registration; this version cannot silently fork another cold family under the same root.

## Cold seed and retained evidence

Seed copies the complete1504 project object namespace and555 native files into one complete first LEAN_PATH root, each a separate inode; all parent/candidate sources are frozen once. Runtime/mathlib external files stay at their original anchored paths and are not copied as an extra9–10GB. It copies original proof/control JSON, logs, helpers and permanent normal artifacts as bytes into an evidence archive and writes an explicit logical-old-pin to physical-new-copy map. No historical contract/path/env hash is edited. The original provider pins remain in baseline G, so a later missing provider stops validation; provider-independent evacuation is not implemented.

The initial normal ledger preserves2 Data06 `old_normal_forbidden` entries and3 accepted normal identities/artifacts: Geometry06ScalableInput, Moment06Input and Active8EnumerationBlock000. New accepted normal artifacts are append-only permanent per-attempt outputs and enter all later prefix manifests. Canonical copies can be restored from these exact artifacts; normal cannot be rerun to restore them.

## Actual validation window

Each epoch freezes helpers, whitelist, environment/strict flags, parent SHA and G selector before PRE. G expands the full shared baseline plus sealed-prefix expected pins and current static helpers/contracts. PRE and POST each stream every selected byte, including runtime/native/source/object/originalJSON and all inherited roles. No cached stat/hash result substitutes for a boundary byte read. Reference manifests avoid repeated large arrays, not physical validation.

Each mode performs exact D pre/post reads of frozen current source/helper/code/runtime, prior mode receipts including PROCESS_RETURN/log/objects, and provisional canonical/permanent artifacts. It stores COMMAND, exact attempt-local LOCAL_INPUTS, log, durable PROCESS_RETURN, RESULT and a nonformal PENDING marker. Full-owned parsing checks complete actual imports, serialized/environment ownership, canonical/shared distinction, identical shared bodies and freshalias trust0, types and only propext/Classical.choice/Quot.sound. It never hardcodes a canonical declaration count.

A successful normal immediately leaves a permanent artifact and the `NORMAL_SUCCEEDED_PENDING_GLOBAL` barrier. Unknown COMMAND interruption refuses to guess or rerun. Missing RESULT/PENDING can only follow the implemented durable-result recovery rules; a COMMAND without RESULT requires explicit evidence recovery. With all3B modes done and POST absent, resume executes POST only. Partial resume performs a fresh complete G RESUME before missing modes. All3B results remain pending until complete D and successful real global POST; only then are BATCH_ACCEPTED and prefix contexts written.

Accepted previous family epochs inherit their externally anchored contexts/seals and original expected-pin D selectors. Subsequent freeze/run does not replay their normal/stock/audit semantic computation or re-copy namespaces. Metadata references and namespaces are checked; the next actual G PRE/POST checks all their sealed bytes. Old logs are never freshly pinned to make modifications trusted. New-root canonical restoration occurs before later receipt D checks; old providers are never restored or modified.

An observed anchored contract/input/ref/namespace mismatch writes sticky markers at epoch and family scope; restoring original bytes does not turn it green. A wrong outer CLI controller/family/batch/parent SHA, invalid count/type/range, or padded tail count is a rejection without poisoning valid state. Declared cross-root normal attempts are scanned, including all family roots under this controller. Missing/malformed process results are blocked, not treated as failed. This version also refuses migration of a complete failed attempt from another root; only current-epoch exact-byte retries of a genuinely failed process are supported. No cross-root result is a permission to re-normal.

## Measurements and limits

The already accepted exact2 batch measured PRE24.354444769s + POST49.060910445s =73.415355214s for G110275 files/13,130,890,292bytes; six processes57.040602371s, Dpre13.668168708s, Dpost0.025698577s. Its cold prepare89.5184s included65.8659s qualification. The separate new-parent readonly pretest74.167052s is historical pretest evidence, not a family seed measurement. Production seed reports qualification, namespace/evidence materialization, full cold readback and total time separately; per epoch reports G timings, mode D and process times.

No production cold seed or first8 has run with this code. Large332/329-owner resource use, actual first8 time/peakRSS and complete closure are unmeasured. B8 only amortizes two G boundaries over more serial owners; it does not guarantee a wall-time or memory bound. The actual15GB-ish next G size must be measured after seed rather than inferred as fixed73s.

Failed-source repair across contracts/families, transporting unsealed successful or unknown normal attempts, global cache/prefix migration, provider-independent removal, source-fix migration and larger graph expansion remain unimplemented. A source/controller/runtime change needs a new explicitly reviewed protocol/transport; do not rerun successful normal as a workaround. A partial seed/freeze is retained as evidence and is not automatically cleaned up or resumed. This delivery is a SOURCE_CANDIDATE/CONTROLLER_CANDIDATE only.
