"""Explicit persistent-family primitives; no provider mutations or old step calls."""
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import shutil
import sys
import time
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
PROTOCOL='family_batch_global_boundary_v1'
MODES=('normal','stock-leanchecker','full-owned')
GRAPH_SHA='0c0930dc27e9ee532ac4a8c78afb2dfb5c9cf40a364076e50cddae7f4cf8dd02'
PARENT_SHA='c19494c887e8768213dfb8c15b43fc36f2f52c72d527a86f8095f4a66f25dcb8'
HELPER=Path('/workspace/p26-cell06-batch-boundary-20261128/approved_helpers.py')
HELPER_SHA='4e35f4d11c38e76ece4bdc429476e4fa4746c3c082f8db8eaea42b91d7a156bc'


def require(ok,message):
    if not ok:raise RuntimeError(message)


def pin(path):
    path=Path(path);digest=hashlib.sha256();size=0
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):digest.update(block);size+=len(block)
    return {'path':str(path.absolute()),'bytes':size,'sha256':digest.hexdigest()}


def check(item):
    require(isinstance(item,dict) and set(item)=={'path','bytes','sha256'},'Malformed exact pin')
    require(pin(item['path'])==item,'Exact byte pin differs: '+item['path'])


def read(path):return json.loads(Path(path).read_text())


def unique(items):
    result={}
    for item in items:require(result.setdefault(item['path'],item)==item,'Conflicting exact pin: '+item['path'])
    return [result[key] for key in sorted(result)]


def writable(path):
    path=Path(path).absolute();require(path.resolve().is_relative_to(ROOT),'Write outside new family implementation root')
    for part in (path,*path.parents):
        if part==ROOT.parent:break
        require(not part.is_symlink(),'Symlink in writable path')
    return path


def dump(path,value):
    path=writable(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x') as f:
        json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
    return pin(path)


def copy_exact(source,target,expected):
    check(expected);require(str(Path(source).absolute())==expected['path'],'Copy source differs from pin')
    target=writable(target);target.parent.mkdir(parents=True,exist_ok=True)
    if not target.exists():
        with Path(source).open('rb') as incoming,target.open('xb') as out:
            shutil.copyfileobj(incoming,out);out.flush();os.fsync(out.fileno())
    result=pin(target);require(all(result[k]==expected[k] for k in ('bytes','sha256')),'Independent copy differs')
    left,right=Path(source).stat(),target.stat()
    require((left.st_dev,left.st_ino)!=(right.st_dev,right.st_ino),'Copy aliases provider inode')
    return result


def next_owners(order,accepted,count):
    require(type(count) is int and 1<=count<=8,'Batch length must be1..8')
    require(len(order)==len(set(order)),'Repeated source graph owner')
    remaining=[owner for owner in order if owner not in accepted]
    require(len(remaining)>=count,'No padding or repeated tail owners')
    return remaining[:count]


def source_path(family,owner):return Path(family)/'project'/Path(owner.replace('.','/')).with_suffix('.lean')

def object_path(family,owner):return Path(family)/'objects'/Path(owner.replace('.','/')).with_suffix('.olean')


def same_bytes(a,b):return all(a[k]==b[k] for k in ('bytes','sha256'))


def env_for(epoch,extension):
    epoch=Path(epoch);sysroot=extension['environment']['sysroot']
    return {'HOME':str(epoch/'home'),'TMPDIR':str(epoch/'tmp'),'LANG':'C.UTF-8','LC_ALL':'C.UTF-8','TZ':'UTC',
            'LEAN_PATH':extension['lean_path'],'LEAN_NUM_THREADS':'1','OMP_NUM_THREADS':'1','LEAN_SYSROOT':sysroot,
            'PATH':sysroot+'/bin:/usr/bin:/bin'}


def env_hash(env):return hashlib.sha256(json.dumps(env,sort_keys=True,separators=(',',':')).encode()).hexdigest()


def flags(extension):return ['--trust=0','-DwarningAsError=true','-j1',f'-M{extension["rss_gib"]*1024}','-DmaxRecDepth=1000000','-DmaxHeartbeats=0']


def load_old():
    require(pin(HELPER)['sha256']==HELPER_SHA,'Reviewed readonly helper loader differs')
    spec=importlib.util.spec_from_file_location('_p26_family_readonly_helpers',HELPER)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module.OLD


OLD=load_old()


def family_path(extension):return Path(extension['family_root'])


def ensure_clean(epoch,extension=None):
    epoch=Path(epoch)
    require(not (epoch/'state/INTEGRITY_FAILED.json').exists(),'Sticky epoch integrity failure')
    family=family_path(extension) if extension else epoch.parent.parent
    require(not (family/'state/INTEGRITY_FAILED.json').exists(),'Sticky family integrity failure')


def sticky(epoch,reason,details=None,extension=None):
    epoch=Path(epoch);family=family_path(extension) if extension else epoch.parent.parent
    value={'protocol':PROTOCOL,'reason':reason,'details':details,'epoch':str(epoch),'formal_acceptance':False,'P2_6_complete':False}
    for path in (epoch/'state/INTEGRITY_FAILED.json',family/'state/INTEGRITY_FAILED.json'):
        if not path.exists():dump(path,value)
    raise RuntimeError('Sticky INTEGRITY_FAILED: '+reason+': '+str(details)[:400])


def transport_evidence(family,items):
    rows=[]
    for index,item in enumerate(unique(items)):
        destination=Path(family)/'evidence'/f'{index:06d}-{item["sha256"]}-{Path(item["path"]).name}'
        copied=copy_exact(item['path'],destination,item)
        rows.append({'logical':item,'physical':copied,'identity_preserved':True})
    return rows


def validate_transport(rows):
    logical={};physical=set()
    for row in rows:
        require(row.get('identity_preserved') is True and same_bytes(row['logical'],row['physical']),'Historical identity/bytes changed')
        require(logical.setdefault(row['logical']['path'],row['logical'])==row['logical'],'Conflicting transport logical pin')
        require(row['physical']['path'] not in physical,'Reused transport destination');physical.add(row['physical']['path'])
        check(row['logical']);check(row['physical'])
        a,b=(Path(row[key]['path']).stat() for key in ('logical','physical'))
        require((a.st_dev,a.st_ino)!=(b.st_dev,b.st_ino),'Transport inode aliases provider')
    return rows


def resolve_historical(item,rows):
    by_logical={row['logical']['path']:row for row in rows};require(item['path'] in by_logical,'Historical pin missing explicit transport')
    row=by_logical[item['path']];require(row['logical']==item and same_bytes(item,row['physical']),'Historical ref transplant')
    check(row['physical']);return row['physical']


def validate_process_schema(value):
    fields={'exit_code','stop_reason','seconds','sampled_peak_tree_rss_bytes'}
    require(fields<=set(value),'Incomplete process status schema')
    require(type(value['exit_code']) is int,'Process exit_code must be an integer')
    require(value['stop_reason'] is None or value['stop_reason'] in ('aggregate_tree_rss_limit','disk_reserve_512_MiB','wall_timeout'),'Unknown process stop reason')
    require(type(value['seconds']) in (int,float) and math.isfinite(value['seconds']) and value['seconds']>=0,'Invalid process elapsed time')
    require(type(value['sampled_peak_tree_rss_bytes']) is int and value['sampled_peak_tree_rss_bytes']>=0,'Invalid process RSS')
    return {key:value[key] for key in fields}
