"""Recorded one-time source derivation; never calls the frozen module."""
from pathlib import Path
root=Path(__file__).resolve().parent
s=Path('/workspace/p26-cell06-batch-boundary-20261128/batch_engine.py').read_text()
start=s.index('def read(path)');end=s.index('def argv_for(')
s=s[:start]+s[end:]
s=s.replace('from approved_helpers import OLD,pin,require', 'from family_common import *\nimport math')
s=s.replace("ROOT=Path(__file__).resolve().parent\nrequire(ROOT==Path('/workspace/p26-cell06-batch-boundary-20261128'),'Controller must run from its approved writable root')\nPROTOCOL='batch_global_boundary_v1'\nMODES=('normal','stock-leanchecker','full-owned')\n",'')
s=s.replace("stage/'project'/Path(owner.replace('.','/')).with_suffix('.lean')", "source_path(family_path(extension),owner)")
s=s.replace("Path(stage)/'objects'/Path(owner.replace('.','/')).with_suffix('.olean')", "object_path(family_path(extension),owner)")
s=s.replace("stage/'objects'/Path(name.replace('.','/')).with_suffix('.olean')", "object_path(family_path(extension),name)")
s=s.replace("Path(stage)/'project'/Path(owner.replace('.','/')).with_suffix('.lean')", "source_path(family_path(extension),owner)")
s=s.replace("(stage/'objects').rglob", "(family_path(extension)/'objects').rglob")
s=s.replace("(stage/'project').rglob", "(family_path(extension)/'project').rglob")
s=s.replace("str(Path(stage)/'project')", "str(family_path(extension)/'project')")
s=s.replace("'BATCH_EXTENSION.json'", "'FAMILY.json'")
# Family anchors live at family root, not epoch.
s=s.replace("pin(Path(stage)/'FAMILY.json')", "pin(family_path(extension)/'FAMILY.json')")
s=s.replace("'extension':", "'family':")
s=s.replace("['extension']", "['family']")
s=s.replace("'origin':'accepted_batch_global_boundary_v1'", "'origin':'accepted_family_batch_global_boundary_v1'")
s=s.replace("ensure_clean(stage)", "ensure_clean(stage,extension)")
s=s.replace("len(history)==6", "len(history)==3*len(batch['owners'])")
s=s.replace("len(history)<6", "len(history)<3*len(batch['owners'])")
s=s.replace("Both owners require all three modes", "All declared owners require all three modes")
s=s.replace("'scope':'Exact completed two-owner batch; no global P2.6 claim.'", "'scope':'Exact atomic1..8-owner family batch; no global P2.6 claim.'")
s=s.replace("'accepted_new_modules':batch['owners'][:batch['owners'].index(owner)+1]", "'accepted_in_this_batch':batch['owners'][:batch['owners'].index(owner)+1],\n               'accepted_since_family_base':batch['accepted_before']+batch['owners'][:batch['owners'].index(owner)+1]")
s=s.replace("'extension':extension['_anchor']", "'family':extension['_anchor']")
s=s.replace("'cwd':str(Path(stage)/'project')", "'cwd':str(family_path(extension)/'project')")
# Keep every byte/attempt check in original reviewed engine, but replace contract APIs.
a=s.index('def load_contract(');b=s.index('def anchors(',a)
s=s[:a]+'''def load_contract(stage,family_sha,batch_sha,controller_sha,parent_sha):
    stage=writable(stage);family=stage.parent.parent
    require(pin(ROOT/'family_controller.py')['sha256']==controller_sha,'Externally supplied controller SHA differs')
    require(pin(family/'FAMILY.json')['sha256']==family_sha,'Externally supplied family SHA differs')
    require(pin(stage/'BATCH.json')['sha256']==batch_sha,'Externally supplied batch SHA differs')
    extension,batch=read(family/'FAMILY.json'),read(stage/'BATCH.json')
    require(batch['parent_context']['sha256']==parent_sha,'Externally supplied parent SHA differs')
    require(extension['protocol']==batch['protocol']==PROTOCOL and batch['family']==pin(family/'FAMILY.json'),'Wrong family protocol/root')
    require(extension['family_root']==str(family),'Family root transplant')
    ensure_clean(stage,extension)
    extension['_anchor']=pin(family/'FAMILY.json');batch['_anchor']=pin(stage/'BATCH.json')
    try:
        for row in extension['code_pins']:check(row)
        check(extension['base_global_inputs']);check(extension['graph']);check(extension['transport']);check(extension['certificate'])
        check(batch['global_inputs']);check(batch['parent_context']);check(batch['whitelist'])
        require(read(batch['whitelist']['path'])==batch['owners'],'Whitelist differs')
        require(1<=len(batch['owners'])<=8 and len(set(batch['owners']))==len(batch['owners']),'Expected1..8 distinct owners')
        require(batch['failure_policy']=='atomic_all_declared_owners' and batch['concurrency']==1,'Wrong batch policy')
        require(batch['global_validation_scope']=='batch_boundary' and batch['normal_success_recompile_allowed'] is False,'Wrong validation scope/barrier policy')
        from family_controller import validate_epoch_parent
        parent=validate_epoch_parent(family,extension,batch['parent_context'],current_epoch=stage)
        graph=read(extension['graph']['path'])
        require(next_owners(graph['topological_order'],set(parent['project_closure']),len(batch['owners']))==batch['owners'],'Not exact next graph owners')
        require(batch['accepted_before']==parent.get('accepted_since_family_base',[]),'Wrong accepted prefix counter')
        extension['parent_catalog']=parent['project_closure'];extension['foundation']=batch['parent_context'];extension['global_inputs']=batch['global_inputs']
        require(env_hash(env_for(stage,extension))==batch['environment_sha256'],'Final allowlist environment differs')
        for helper in batch['helpers']:check(helper)
        require(set(row['path'] for row in batch['helpers'])=={str(stage/'helpers'/(owner+'.Owned.lean')) for owner in batch['owners']},'Auditor helper selector differs')
    except Exception as exc:sticky(stage,'Anchored family/batch contract mismatch',str(exc),extension)
    return extension,batch


''' +s[b:]
# Drop local definitions now imported from family_common (sticky/family failure is shared).
a=s.index('def sticky(');b=s.index('def global_items(',a);s=s[:a]+s[b:]
a=s.index('def global_items(');b=s.index('def catalog_objects(',a)
s=s[:a]+'''def global_items(stage,extension,batch):
    try:
        selector=batch['global_inputs'];check(selector);spec=read(selector['path'])
        require(spec['protocol']==PROTOCOL and spec['family']==extension['_anchor'] and spec['parent_context']==batch['parent_context'],'Global selector transplant')
        require(spec['baseline']==extension['base_global_inputs'],'Global baseline selector differs')
        check(spec['baseline']);items=read(spec['baseline']['path'])
        require(isinstance(items,list),'Malformed global baseline')
        items+=spec['prefix_inputs']+spec['batch_static']+[selector,spec['baseline']]
    except Exception as exc:sticky(stage,'Anchored global input selector mismatch',str(exc),extension)
    family_pin,batch_pin=anchors(stage,extension,batch)
    return unique(items+[family_pin,batch_pin])


''' +s[b:]
s=s.replace("extension.setdefault('_anchor',pin(Path(stage)/'FAMILY.json'))", "extension.setdefault('_anchor',pin(family_path(extension)/'FAMILY.json'))")
s=s.replace("OLD.controller.environment_inventory(read(extension['old_stage']['path']))", "OLD.controller.environment_inventory(read(extension['provenance_roots']['old_stage']['path']))")
# Cold baseline normal artifacts and every accepted family artifact can restore missing canonical copies.
s=s.replace("selected=[i['selected_object'] for i in extension['parent_catalog'].values()]+extension['native_artifacts']", """selected=[]
    for info in extension['parent_catalog'].values():
        target=Path(info['selected_object']['path'])
        if info.get('normal_success_artifact'):
            require(same_bytes(info['normal_success_artifact'],info['selected_object']),'Accepted canonical/permanent artifact differs')
            copy_exact(info['normal_success_artifact']['path'],target,info['normal_success_artifact'])
        selected.append(info['selected_object'])
    selected+=extension['native_artifacts']""")
s=s.replace("and returned['process_result']['seconds']>=0", "and math.isfinite(returned['process_result']['seconds']) and returned['process_result']['seconds']>=0")
# Refuse cross-root attempts, including old runner protocol's different identity shape.
a=s.index('def refuse_other_stage_normal(');b=s.index('def run_mode(',a)
s=s[:a]+'''def refuse_other_stage_normal(stage,extension,owner):
    stage=Path(stage)
    forbidden={row['module'] for row in extension['normal_barriers']}
    require(owner not in forbidden,'Inherited successful/oldData normal is permanently forbidden')
    roots=extension['normal_search_roots']+[str(family_path(extension)/'batches')]
    commands=set()
    for root in roots:
        base=Path(root);require(base.is_dir(),'Declared normal-search provider root missing')
        for command_path in base.glob('**/steps/'+owner+'/normal/*/COMMAND.json'):
            if command_path.is_relative_to(stage):continue
            commands.add(command_path)
    for command_path in sorted(commands):
        command=read(command_path);ident=command.get('identity',{})
        require(ident.get('key')==owner,'Unexpected normal command identity under owner namespace')
        result_path=command_path.parent/'RESULT.json'
        require(result_path.exists(),'Other-root ambiguous normal blocks recompilation; explicit transport required')
        result=read(result_path)
        require(result.get('command')==pin(command_path),'Other-root normal result/command differs')
        require(result.get('exit_code')!=0 or result.get('stop_reason'),'Other-root successful normal blocks recompilation; explicit transport required')


''' +s[b:]
s=s.replace("refuse_other_stage_normal(stage,owner)", "refuse_other_stage_normal(stage,extension,owner)")
s=s.replace("'accepted_parent':parent,", "'accepted_parent':parent,'epoch_parent':batch['parent_context'],")
s=s.replace("'global_validation_scope':'batch_boundary','global_pre':pre", "'global_validation_scope':'batch_boundary','parent_context':batch['parent_context'],'global_pre':pre")
s=s.replace("'extension':pin(Path(stage)/'FAMILY.json')", "'family':pin(family_path(extension)/'FAMILY.json')")
# Source helper is called in one context with no extension available only via explicit parameter.
with (root/'family_engine.py').open('x') as out:out.write(s)
