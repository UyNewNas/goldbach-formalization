"""New batch-global-boundary protocol; never calls or monkeypatches old step."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import time
import uuid

from family_common import *
import math



def argv_for(stage,extension,owner,mode):
    stage=Path(stage);lean=extension['runtime']['lean']['path']
    if mode=='normal':value=[lean,*flags(extension),'-o','__NORMAL_OUTPUT__',source_path(family_path(extension),owner)]
    elif mode=='stock-leanchecker':value=[extension['runtime']['leanchecker']['path'],'--verbose',owner]
    elif mode=='full-owned':value=[lean,*flags(extension),stage/'helpers'/(owner+'.Owned.lean')]
    else:raise RuntimeError('Unknown mode')
    return list(map(str,value))


def load_contract(stage,family_sha,batch_sha,controller_sha,parent_sha):
    stage=writable(stage);family=stage.parent.parent
    require(pin(ROOT/'family_controller.py')['sha256']==controller_sha,'Externally supplied controller SHA differs')
    require(pin(family/'FAMILY.json')['sha256']==family_sha,'Externally supplied family SHA differs')
    require(pin(stage/'BATCH.json')['sha256']==batch_sha,'Externally supplied batch SHA differs')
    extension,batch=read(family/'FAMILY.json'),read(stage/'BATCH.json')
    require(batch['parent_context']['sha256']==parent_sha,'Externally supplied parent SHA differs')
    require(extension['protocol']==batch['protocol']==PROTOCOL and batch['family']==pin(family/'FAMILY.json'),'Wrong family protocol/root')
    require(extension['family_root']==str(family),'Family root transplant')
    ensure_clean(stage,extension)
    extension['_anchor']=pin(family/'FAMILY.json');batch['_anchor']=pin(stage/'BATCH.json')
    try:
        for row in extension['code_pins']:check(row)
        check(extension['base_global_inputs']);check(extension['graph']);check(extension['transport']);check(extension['certificate'])
        check(batch['global_inputs']);check(batch['parent_context']);check(batch['whitelist'])
        require(read(batch['whitelist']['path'])==batch['owners'],'Whitelist differs')
        require(1<=len(batch['owners'])<=8 and len(set(batch['owners']))==len(batch['owners']),'Expected1..8 distinct owners')
        require(batch['failure_policy']=='atomic_all_declared_owners' and batch['concurrency']==1,'Wrong batch policy')
        require(batch['global_validation_scope']=='batch_boundary' and batch['normal_success_recompile_allowed'] is False,'Wrong validation scope/barrier policy')
        from family_controller import validate_epoch_parent
        parent=validate_epoch_parent(family,extension,batch['parent_context'],current_epoch=stage)
        graph=read(extension['graph']['path'])
        require(next_owners(graph['topological_order'],set(parent['project_closure']),len(batch['owners']))==batch['owners'],'Not exact next graph owners')
        require(batch['accepted_before']==parent.get('accepted_since_family_base',[]),'Wrong accepted prefix counter')
        extension['parent_catalog']=parent['project_closure'];extension['foundation']=batch['parent_context'];extension['global_inputs']=batch['global_inputs']
        extension['_closed_namespaces']=parent['_closed_namespaces']
        require(env_hash(env_for(stage,extension))==batch['environment_sha256'],'Final allowlist environment differs')
        for helper in batch['helpers']:check(helper)
        require(set(row['path'] for row in batch['helpers'])=={str(stage/'helpers'/(owner+'.Owned.lean')) for owner in batch['owners']},'Auditor helper selector differs')
    except Exception as exc:sticky(stage,'Anchored family/batch contract mismatch',str(exc),extension)
    return extension,batch


def anchors(stage,extension,batch):
    extension.setdefault('_anchor',pin(family_path(extension)/'FAMILY.json'))
    batch.setdefault('_anchor',pin(Path(stage)/'BATCH.json'))
    try:check(extension['_anchor']);check(batch['_anchor'])
    except Exception as exc:sticky(stage,'Anchored extension/batch content changed',str(exc))
    return extension['_anchor'],batch['_anchor']


def global_items(stage,extension,batch):
    try:
        selector=batch['global_inputs'];check(selector);spec=read(selector['path'])
        require(spec['protocol']==PROTOCOL and spec['family']==extension['_anchor'] and spec['parent_context']==batch['parent_context'],'Global selector transplant')
        require(spec['baseline']==extension['base_global_inputs'],'Global baseline selector differs')
        check(spec['baseline']);items=read(spec['baseline']['path'])
        require(isinstance(items,list),'Malformed global baseline')
        items+=spec['prefix_inputs']+spec['batch_static']+[selector,spec['baseline']]
    except Exception as exc:sticky(stage,'Anchored global input selector mismatch',str(exc),extension)
    family_pin,batch_pin=anchors(stage,extension,batch)
    return unique(items+[family_pin,batch_pin])


def catalog_objects(stage,extension,pending):
    selected=[]
    for info in extension['parent_catalog'].values():
        target=Path(info['selected_object']['path'])
        if info.get('normal_success_artifact'):
            require(same_bytes(info['normal_success_artifact'],info['selected_object']),'Accepted canonical/permanent artifact differs')
            if not target.exists():copy_exact(info['normal_success_artifact']['path'],target,info['normal_success_artifact'])
        selected.append(info['selected_object'])
    selected+=extension['native_artifacts']
    for owner,normal in pending.items():
        target=object_path(family_path(extension),owner)
        expected={**normal['object'],'path':str(target)}
        # Restoring an exact namespace copy never invokes normal again.
        copy_exact(normal['object']['path'],target,normal['object']);selected.append(expected)
    return unique(selected)


def namespace_check(stage,extension,pending):
    stage=Path(stage);objects=catalog_objects(stage,extension,pending)
    expected={i['path'] for i in objects}
    actual={str(p.absolute()) for p in (family_path(extension)/'objects').rglob('*') if p.is_file()}
    require(actual==expected,'Unknown/missing object/native namespace file')
    project={str(p.absolute()) for p in (family_path(extension)/'project').rglob('*') if p.is_file()}
    require(project==set(extension['project_files']),'Unknown/missing mathematical source file')
    for previous_epoch,expected_paths in extension.get('_closed_namespaces',{}).items():
        require({str(p) for p in Path(previous_epoch).rglob('*') if p.is_file()}==set(expected_paths),'Inherited evidence namespace changed')
    if not extension.get('synthetic_fixture',False):
        OLD.controller.environment_inventory(read(extension['provenance_roots']['old_stage']['path']))


def snapshot(stage,extension,batch,purpose,pending):
    ensure_clean(stage,extension);started=time.monotonic()
    try:items=global_items(stage,extension,batch)
    except Exception as exc:sticky(stage,'Global contract/input-selector mismatch before '+purpose,str(exc))
    selector_seconds=time.monotonic()-started;namespace_started=time.monotonic()
    mismatches=[];total=0;digest=hashlib.sha256()
    try:namespace_check(stage,extension,pending)
    except Exception as exc:sticky(stage,'namespace mismatch before '+purpose,str(exc))
    namespace_pre_seconds=time.monotonic()-namespace_started;hash_started=time.monotonic()
    for expected in items:
        try:actual=pin(expected['path'])
        except (FileNotFoundError,OSError) as exc:
            mismatches.append({'expected':expected,'error':str(exc)});continue
        total+=actual['bytes'];digest.update(json.dumps(actual,sort_keys=True,separators=(',',':')).encode()+b'\n')
        if actual!=expected:mismatches.append({'expected':expected,'actual':actual})
    hash_seconds=time.monotonic()-hash_started;namespace_started=time.monotonic()
    try:namespace_check(stage,extension,pending)
    except Exception as exc:mismatches.append({'namespace':str(exc)})
    namespace_post_seconds=time.monotonic()-namespace_started
    report={'protocol':PROTOCOL,'purpose':purpose,'global_validation_scope':'batch_boundary',
            'family':pin(family_path(extension)/'FAMILY.json'),'batch':pin(Path(stage)/'BATCH.json'),
            'global_inputs':extension['global_inputs'],'files_checked':len(items),'bytes_read':total,
            'actual_map_sha256':digest.hexdigest(),'seconds':time.monotonic()-started,'matched':not mismatches,
            'timings':{'selector_seconds':selector_seconds,'global_byte_hash_seconds':hash_seconds,
                       'namespace_pre_seconds':namespace_pre_seconds,'namespace_post_seconds':namespace_post_seconds},
            'mismatches':mismatches,'checked_unix_ns':time.time_ns(),'formal_acceptance':False}
    path=Path(stage)/'state'/f'{purpose}-{time.time_ns()}.json';report_pin=dump(path,report)
    if mismatches:sticky(stage,'Observed global '+purpose+' mismatch',report_pin)
    return report_pin


def _validate_snapshot(snapshot_pin,stage,extension,batch,purpose=None):
    check(snapshot_pin);value=read(snapshot_pin['path'])
    require(value['protocol']==PROTOCOL and value['global_validation_scope']=='batch_boundary' and value['matched'] is True,'Invalid global snapshot')
    require(value['family']==pin(family_path(extension)/'FAMILY.json') and value['batch']==pin(Path(stage)/'BATCH.json'),'Snapshot contract transplant')
    require(value['global_inputs']==extension['global_inputs'] and value['files_checked']==len(global_items(stage,extension,batch)),'Snapshot input selector differs')
    if purpose is not None:require(value['purpose']==purpose,'Wrong snapshot purpose')
    return value


def validate_snapshot(snapshot_pin,stage,extension,batch,purpose=None):
    try:return _validate_snapshot(snapshot_pin,stage,extension,batch,purpose)
    except Exception as exc:sticky(stage,'Anchored global snapshot/reference mismatch',str(exc))


def pre_anchor(stage,extension,batch):
    path=Path(stage)/'state/GLOBAL_PRE.json'
    if path.exists():
        anchor=read(path);validate_snapshot(anchor['snapshot'],stage,extension,batch,'PRE');return anchor['snapshot']
    value=snapshot(stage,extension,batch,'PRE',{})
    dump(path,{'snapshot':value,'formal_acceptance':False});return value


def identity(stage,extension,batch,owner,mode,pre):
    extension_pin,batch_pin=anchors(stage,extension,batch)
    return {'protocol':PROTOCOL,'family':extension_pin,'batch':batch_pin,
            'key':owner,'mode':mode,'global_validation_scope':'batch_boundary','batch_pre':pre,
            'environment_sha256':env_hash(env_for(stage,extension)),'argv':argv_for(stage,extension,owner,mode),
            'cwd':str(family_path(extension)/'project'),'timeout':extension['wall_seconds'],'rss_bytes':extension['rss_gib']*1024**3}


def parse_mode(stage,extension,batch,owner,mode,text,result):
    require('sorryAx' not in text,'Forbidden sorryAx')
    if mode=='normal':return OLD.controller.normal_validator(text,result)
    if mode=='stock-leanchecker':return {'stock_leanchecker_exit_zero':True}
    prefix=batch['owners'][:batch['owners'].index(owner)+1]
    return OLD.evidence.validate_audit(text,[owner],set(extension['parent_catalog'])|set(prefix),extension['external_modules'])


def delta_items(stage,extension,batch,owner,mode,history,pending):
    stage=Path(stage);helper_path=str(stage/'helpers'/(owner+'.Owned.lean'))
    helper=[item for item in batch['helpers'] if item['path']==helper_path]
    require(len(helper)==1,'Exact mode helper selector differs')
    items=[extension['project_sources'][owner],helper[0],*extension['code_pins'],*extension['runtime'].values()]
    for record in history:
        items += [record['marker'],record['result'],record['command'],record['log'],record['local_inputs'],record['process_return']]
        if record['object']:items.append(record['object'])
    for name,record in pending.items():
        target=object_path(family_path(extension),name)
        copy_exact(record['object']['path'],target,record['object']);items += [record['object'],pin(target)]
    return unique(items)


def _verify_record(stage,extension,batch,owner,mode,pre,attempt):
    command_path,result_path,marker_path=(attempt/n for n in ('COMMAND.json','RESULT.json','PENDING.json'))
    require(command_path.is_file(),'Unknown attempt directory')
    command=read(command_path);expected=identity(stage,extension,batch,owner,mode,pre)
    require(command['identity']==expected,'Wrong extension/batch/key/mode/environment/argv receipt')
    require(command['local_inputs']['path']==str(attempt/'LOCAL_INPUTS.json'),'LOCAL_INPUTS must belong to this exact attempt')
    check(command['local_inputs']);local=read(command['local_inputs']['path'])
    try:
        for item in local:check(item)
    except Exception as exc:sticky(stage,'Stored local D byte mismatch',{'attempt':str(attempt),'error':str(exc)})
    actual=[str(attempt/'normal.olean') if a=='__NORMAL_OUTPUT__' else a for a in expected['argv']]
    require(command['actual_argv']==actual,'Actual argv transplant')
    require(result_path.exists(),'Unknown COMMAND interruption: recover evidence, never guess/re-normal')
    result=read(result_path)
    require(result['command']==pin(command_path),'Result/command chain differs')
    require(result['log']['path']==str(attempt/'output.log'),'Log must belong to this exact attempt')
    require(result['process_return']['path']==str(attempt/'PROCESS_RETURN.json'),'PROCESS_RETURN must belong to this exact attempt')
    check(result['process_return']);returned=read(result['process_return']['path'])
    require(returned['protocol']==PROTOCOL and returned['identity']==expected and returned['formal_acceptance'] is False
            and returned['status']=='PROCESS_RETURNED_PENDING_LOCAL_AND_GLOBAL_CHECKS','Wrong durable process return identity/status')
    require(returned['command']==pin(command_path) and returned['log']==result['log'] and returned['object']==result.get('object'),
            'Durable process return command/log/object differs')
    validate_process_schema(returned['process_result']);validate_process_schema(result)
    process_fields={'exit_code','stop_reason','seconds','sampled_peak_tree_rss_bytes'}
    require(set(returned['process_result'])==process_fields,'Unexpected process-return field set')
    require(type(returned['process_result']['exit_code']) is int and isinstance(returned['process_result']['seconds'],(int,float))
            and math.isfinite(returned['process_result']['seconds']) and returned['process_result']['seconds']>=0 and type(returned['process_result']['sampled_peak_tree_rss_bytes']) is int
            and returned['process_result']['sampled_peak_tree_rss_bytes']>=0,'Invalid process timing/status values')
    require(all(result[k]==returned['process_result'][k] for k in process_fields),'Durable process return fields differ from RESULT')
    require(result['protocol']==PROTOCOL and result['global_validation_scope']=='batch_boundary' and 'postcheck' not in result
            and result['formal_acceptance'] is False,'Mode falsely reports per-step global/formal validation')
    require(result['local_post']=={'inputs':command['local_inputs'],'all_local_files_matched':True,'file_count':len(local)},'Wrong local D postcheck')
    check(result['log'])
    if result.get('object'):check(result['object'])
    if mode=='normal':
        if result.get('object'):require(result['object']['path']==str(attempt/'normal.olean'),'Wrong exact normal artifact path')
    else:require(result.get('object') is None,'Non-normal mode cannot claim a new object')
    if result['exit_code']!=0 or result.get('stop_reason'):
        require(not marker_path.exists(),'Failed process has pending-success marker');return None
    if mode=='normal':require(result['object']['path']==str(attempt/'normal.olean'),'Wrong permanent normal artifact')
    parsed=parse_mode(stage,extension,batch,owner,mode,Path(result['log']['path']).read_text(),result)
    marker={'protocol':PROTOCOL,'status':'NORMAL_SUCCEEDED_PENDING_GLOBAL' if mode=='normal' else 'PROCESS_VALIDATED_PENDING_GLOBAL',
            'identity':expected,'result':pin(result_path),'process_return':result['process_return'],
            'validated':parsed,'formal_acceptance':False,'batch_post':None,'P2_6_complete':False}
    if marker_path.exists():require(read(marker_path)==marker,'Pending marker differs or makes a false formal/global claim')
    else:dump(marker_path,marker) # Recover a durable successful result without execution.
    return {'owner':owner,'mode':mode,'marker':pin(marker_path),'result':pin(result_path),'command':pin(command_path),
            'log':result['log'],'local_inputs':command['local_inputs'],'process_return':result['process_return'],'object':result.get('object'),'validated':parsed}


def verify_record(stage,extension,batch,owner,mode,pre,attempt):
    try:return _verify_record(stage,extension,batch,owner,mode,pre,attempt)
    except RuntimeError as exc:
        if 'Unknown COMMAND interruption' in str(exc):raise
        sticky(stage,'Anchored mode D receipt/content mismatch',str(exc))
    except Exception as exc:sticky(stage,'Anchored mode D receipt/content mismatch',str(exc))


def find_record(stage,extension,batch,owner,mode,pre):
    base=Path(stage)/'steps'/owner/mode
    successes=[]
    for attempt in sorted(base.iterdir()) if base.exists() else []:
        record=verify_record(stage,extension,batch,owner,mode,pre,attempt)
        if record:successes.append(record)
    require(len(successes)<=1,'Multiple successful executions for one frozen owner/mode')
    return successes[0] if successes else None


def real_executor(mode,owner,argv,cwd,env,log,timeout,rss):
    return OLD.evidence.real_process(argv,cwd,env,log,timeout,rss)


def refuse_other_stage_normal(stage,extension,owner):
    stage=Path(stage)
    forbidden={row['module'] for row in extension['normal_barriers']}
    require(owner not in forbidden,'Inherited successful/oldData normal is permanently forbidden')
    roots=extension['normal_search_roots']+[str(family_path(extension)/'batches'),str(ROOT)]
    commands=set()
    for root in roots:
        base=Path(root);require(base.is_dir(),'Declared normal-search provider root missing')
        for command_path in base.glob('**/steps/'+owner+'/normal/*/COMMAND.json'):
            if command_path.is_relative_to(stage):continue
            commands.add(command_path)
    for command_path in sorted(commands):
        command=read(command_path);ident=command.get('identity',{})
        require(ident.get('key')==owner,'Unexpected normal command identity under owner namespace')
        result_path=command_path.parent/'RESULT.json'
        require(result_path.exists(),'Other-root ambiguous normal blocks recompilation; explicit transport required')
        result=read(result_path)
        require(result.get('command')==pin(command_path),'Other-root normal result/command differs')
        validate_process_schema(result)
        require(result['log']['path']==str(command_path.parent/'output.log'),'Other-root log belongs to a different attempt')
        check(result['log'])
        if result.get('object'):
            require(result['object']['path']==str(command_path.parent/'normal.olean'),'Other-root normal artifact belongs to a different attempt')
            check(result['object'])
        if result.get('process_return'):
            require(result['process_return']['path']==str(command_path.parent/'PROCESS_RETURN.json'),'Other-root process return belongs to a different attempt')
            check(result['process_return']);returned=read(result['process_return']['path'])
            require(returned['identity']==ident and returned['command']==pin(command_path) and returned['log']==result['log']
                    and returned['object']==result.get('object') and returned['process_result']==validate_process_schema(result),'Other-root durable return transplant')
        require(result['exit_code']!=0 or result['stop_reason'] is not None,'Other-root successful normal blocks recompilation; explicit transport required')
        # This version transports only the sealed1504 parent. A cross-root failed
        # attempt is not a retry permission or an implemented migration protocol.
        raise RuntimeError('Other-root failed normal blocks recompilation; explicit failed-attempt transport is not implemented')



def run_mode(stage,extension,batch,owner,mode,pre,history,pending,executor=real_executor):
    ensure_clean(stage,extension);validate_snapshot(pre,stage,extension,batch,'PRE')
    previous=find_record(stage,extension,batch,owner,mode,pre)
    if previous:return previous
    if mode=='normal':
        try:refuse_other_stage_normal(stage,extension,owner)
        except Exception as exc:sticky(stage,'Observed cross-root normal barrier mismatch',str(exc),extension)
    require(shutil.disk_usage(stage).free>1024**3,'Leave1GiB reserve before a new mode')
    local_started=time.monotonic()
    try:
        local=delta_items(stage,extension,batch,owner,mode,history,pending)
        namespace_check(stage,extension,pending)
        for item in local:check(item)
    except Exception as exc:sticky(stage,'Observed local D mismatch before mode',str(exc))
    local_pre_seconds=time.monotonic()-local_started
    attempt=Path(stage)/'steps'/owner/mode/(str(time.time_ns())+'-'+uuid.uuid4().hex[:8]);attempt.mkdir(parents=True)
    local_pin=dump(attempt/'LOCAL_INPUTS.json',local);ident=identity(stage,extension,batch,owner,mode,pre)
    actual=[str(attempt/'normal.olean') if a=='__NORMAL_OUTPUT__' else a for a in ident['argv']]
    dump(attempt/'COMMAND.json',{'identity':ident,'actual_argv':actual,'local_inputs':local_pin,'started_unix_ns':time.time_ns()})
    log=attempt/'output.log';result=executor(mode,owner,actual,ident['cwd'],env_for(stage,extension),log,ident['timeout'],ident['rss_bytes'])
    returned={'protocol':PROTOCOL,'identity':ident,'process_result':result,'command':pin(attempt/'COMMAND.json'),
              'log':pin(log),'object':pin(attempt/'normal.olean') if mode=='normal' and (attempt/'normal.olean').is_file() else None,
              'status':'PROCESS_RETURNED_PENDING_LOCAL_AND_GLOBAL_CHECKS','formal_acceptance':False}
    return_pin=dump(attempt/'PROCESS_RETURN.json',returned)
    local_started=time.monotonic()
    try:
        for item in local:check(item)
    except Exception as exc:sticky(stage,'Observed local D mismatch after mode',{'attempt':str(attempt),'error':str(exc)})
    local_post_seconds=time.monotonic()-local_started
    obj=attempt/'normal.olean'
    result={**result,'protocol':PROTOCOL,'global_validation_scope':'batch_boundary','command':pin(attempt/'COMMAND.json'),
            'process_return':return_pin,
            'log':pin(log),'local_post':{'inputs':local_pin,'all_local_files_matched':True,'file_count':len(local)},
            'object':pin(obj) if mode=='normal' and obj.is_file() else None,'formal_acceptance':False,
            'timings':{'local_D_pre_seconds':local_pre_seconds,'local_D_post_seconds':local_post_seconds,
                       'local_D_expected_bytes':sum(i['bytes'] for i in local),'process_seconds':result.get('seconds')}}
    validation_error=None;validation_started=time.monotonic()
    if result['exit_code']==0 and not result.get('stop_reason'):
        try:parse_mode(stage,extension,batch,owner,mode,log.read_text(),result)
        except Exception as exc:validation_error=str(exc)
    result['timings']['mode_validation_seconds']=time.monotonic()-validation_started
    result['mode_validation_error']=validation_error
    dump(attempt/'RESULT.json',result)
    require(result['exit_code']==0 and not result.get('stop_reason'),'Mode failed; evidence/output retained')
    require(validation_error is None,'Mode validation failed; successful process artifact retained: '+str(validation_error))
    return verify_record(stage,extension,batch,owner,mode,pre,attempt)


def recover_history(stage,extension,batch,pre):
    history=[];pending={};gap=False
    for owner in batch['owners']:
        for mode in MODES:
            record=find_record(stage,extension,batch,owner,mode,pre)
            if record is None:gap=True;continue
            require(not gap,'Non-prefix provisional mode history')
            history.append(record)
            if mode=='normal':
                pending[owner]=record
                try:catalog_objects(stage,extension,pending)
                except Exception as exc:sticky(stage,'Provisional canonical object mismatch',str(exc))
    try:namespace_check(stage,extension,pending)
    except Exception as exc:sticky(stage,'Recovered provisional namespace mismatch',str(exc))
    return history,pending


def validate_all_delta(history):
    items=[]
    for record in history:
        for key in ('marker','result','command','log','local_inputs','process_return'):items.append(record[key])
        items += read(record['local_inputs']['path'])
        if record['object']:items.append(record['object'])
    items=unique(items)
    for item in items:check(item)
    return items


def complete_delta_inventory(stage,history):
    expected=validate_all_delta(history)
    allowed={'COMMAND.json','RESULT.json','PENDING.json','LOCAL_INPUTS.json','PROCESS_RETURN.json','output.log','normal.olean'}
    owners={r['owner'] for r in history}
    for path in (Path(stage)/'steps').rglob('*') if (Path(stage)/'steps').exists() else []:
        if path.is_file():
            parts=path.relative_to(Path(stage)/'steps').parts
            require(len(parts)==4 and parts[0] in owners and parts[1] in MODES and path.name in allowed and (path.name!='normal.olean' or parts[1]=='normal'),'Unknown file in mode D namespace')
            expected.append(pin(path))
    # All prior global boundary/resume reports are retained and bound, too.
    for path in (Path(stage)/'state').rglob('*'):
        if not path.is_file():continue
        require(path.parent==Path(stage)/'state' and path.suffix=='.json','Unknown non-JSON/nested state artifact')
        if path.name=='GLOBAL_PRE.json' or path.name.startswith(('PRE-','RESUME-','POST-')):expected.append(pin(path))
        else:require(path.name in ('BATCH_ACCEPTED.json','INTEGRITY_FAILED.json'),'Unknown batch state file')
    return unique(expected)


def materialize_contexts(stage,extension,batch,seal,history,pending):
    catalog=dict(extension['parent_catalog']);parent=extension['foundation']
    for owner in batch['owners']:
        normal=pending[owner];target=object_path(family_path(extension),owner)
        catalog[owner]={'source':pin(source_path(family_path(extension),owner)),'selected_object':pin(target),
                        'origin':'accepted_family_batch_global_boundary_v1','normal_success_artifact':normal['object']}
        value={'protocol':PROTOCOL,'formal_acceptance':True,'P2_6_complete':False,
               'family':extension['_anchor'],'batch':batch['_anchor'],'batch_seal':seal,'accepted_parent':parent,'epoch_parent':batch['parent_context'],
               'project_closure':dict(catalog),'native_artifacts':extension['native_artifacts'],'runtime':extension['runtime'],
               'lean_path':extension['lean_path'],'accepted_in_this_batch':batch['owners'][:batch['owners'].index(owner)+1],
               'accepted_since_family_base':batch['accepted_before']+batch['owners'][:batch['owners'].index(owner)+1],
               'global_validation_scope':'batch_boundary','scope':'Exact atomic1..8-owner family batch; no global P2.6 claim.'}
        path=Path(stage)/'accepted-contexts'/(owner+'.json')
        if path.exists():require(read(path)==value,'Existing accepted prefix context differs')
        else:dump(path,value)
        parent=pin(path)


def execute_pending(stage,extension,batch,pre,executor=real_executor):
    history,pending=recover_history(stage,extension,batch,pre)
    completed={(r['owner'],r['mode']) for r in history}
    for owner in batch['owners']:
        for mode in MODES:
            if (owner,mode) in completed:continue
            record=run_mode(stage,extension,batch,owner,mode,pre,history,pending,executor)
            history.append(record);completed.add((owner,mode))
            if mode=='normal':pending[owner]=record
    return history,pending


def finish(stage,extension,batch,pre,history,pending):
    ensure_clean(stage,extension);require(len(history)==3*len(batch['owners']) and set(pending)==set(batch['owners']),'All declared owners require all three modes')
    try:delta=complete_delta_inventory(stage,history);namespace_check(stage,extension,pending)
    except Exception as exc:sticky(stage,'Final D mismatch',str(exc))
    post=snapshot(stage,extension,batch,'POST',pending)
    if validate_snapshot(post,stage,extension,batch,'POST')['actual_map_sha256']!=validate_snapshot(pre,stage,extension,batch,'PRE')['actual_map_sha256']:
        sticky(stage,'PRE/POST actual maps differ',{'pre':pre,'post':post})
    try:
        for item in delta:check(item)
        validate_all_delta(history);namespace_check(stage,extension,pending)
        delta=complete_delta_inventory(stage,history)
        for item in delta:check(item)
    except Exception as exc:sticky(stage,'Final D changed around global POST',str(exc))
    accepted={'protocol':PROTOCOL,'status':'BATCH_ACCEPTED','family':pin(family_path(extension)/'FAMILY.json'),'batch':pin(Path(stage)/'BATCH.json'),
              'global_validation_scope':'batch_boundary','parent_context':batch['parent_context'],'global_pre':pre,'global_post':post,'owners':batch['owners'],
              'pending_mode_receipts':[r['marker'] for r in history],'delta_inputs':delta,'formal_acceptance':True,'P2_6_complete':False}
    seal=dump(Path(stage)/'state/BATCH_ACCEPTED.json',accepted)
    materialize_contexts(stage,extension,batch,seal,history,pending)
    return seal


def _verify_accepted(stage,extension,batch):
    ensure_clean(stage,extension);path=Path(stage)/'state/BATCH_ACCEPTED.json';value=read(path)
    require(value['protocol']==PROTOCOL and value['status']=='BATCH_ACCEPTED' and value['formal_acceptance'] is True,'Wrong accepted batch seal')
    require(value['family']==pin(family_path(extension)/'FAMILY.json') and value['batch']==pin(Path(stage)/'BATCH.json'),'Accepted seal transplant')
    validate_snapshot(value['global_pre'],stage,extension,batch,'PRE');validate_snapshot(value['global_post'],stage,extension,batch,'POST')
    history,pending=recover_history(stage,extension,batch,value['global_pre'])
    require([r['marker'] for r in history]==value['pending_mode_receipts'] and len(history)==3*len(batch['owners']),'Accepted mode set differs')
    for item in value['delta_inputs']:check(item)
    require(value['delta_inputs']==complete_delta_inventory(stage,history),'Accepted final D inventory differs')
    for item in global_items(stage,extension,batch):check(item)
    namespace_check(stage,extension,pending)
    materialize_contexts(stage,extension,batch,pin(path),history,pending)
    return pin(path)


def verify_accepted(stage,extension,batch):
    try:return _verify_accepted(stage,extension,batch)
    except Exception as exc:sticky(stage,'Accepted batch referenced content mismatch',str(exc))


def run_batch(stage,extension,batch,executor=real_executor):
    ensure_clean(stage,extension)
    if (Path(stage)/'state/BATCH_ACCEPTED.json').exists():return verify_accepted(stage,extension,batch)
    pre=pre_anchor(stage,extension,batch)
    history,pending=recover_history(stage,extension,batch,pre)
    if history and len(history)<3*len(batch['owners']):
        # A resumed unfinished batch gets a fresh complete real-byte recheck.
        snapshot(stage,extension,batch,'RESUME',pending)
    history,pending=execute_pending(stage,extension,batch,pre,executor)
    return finish(stage,extension,batch,pre,history,pending)
