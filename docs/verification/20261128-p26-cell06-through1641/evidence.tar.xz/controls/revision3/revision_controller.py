#!/usr/bin/env python3
"""Cold seed once; explicitly freeze/run one serial atomic1..8-owner epoch."""
import argparse
import fcntl
import hashlib
import json
from types import ModuleType
from pathlib import Path
import re
import shutil
import sys
import time
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent

CODE_NAMES=('revision_common.py','revision_engine.py','revision_controller.py','parent_revision3.py','revision_source_loader.py','SOURCE_LOCK.json','IMPLEMENTATION_PLAN.md','README.md')



def _bootstrap_runtime(source_lock_sha,controller_sha,source_lock_path=None):
    """External lock -> loader/common/engine source bytes, with no .pyc reads."""
    lock_path=Path(source_lock_path) if source_lock_path is not None else ROOT/'SOURCE_LOCK.json'
    raw=lock_path.read_bytes()
    if hashlib.sha256(raw).hexdigest()!=source_lock_sha:raise RuntimeError('External source-lock SHA differs')
    lock=json.loads(raw)
    if lock['schema']!='p26_revision3_python_source_lock_v1':raise RuntimeError('Wrong source lock schema')
    def exact(item,path):
        value=Path(path).read_bytes()
        if item['path']!=str(Path(path).absolute()) or len(value)!=item['bytes'] or hashlib.sha256(value).hexdigest()!=item['sha256']:
            raise RuntimeError('Pinned source path/bytes differ: '+str(path))
        return value
    exact(lock['controller'],ROOT/'revision_controller.py')
    if lock['controller']['sha256']!=controller_sha:raise RuntimeError('External controller SHA differs')
    needed={'revision_source_loader','revision_common','revision_engine','parent_revision3'}
    if set(lock['modules'])!=needed:raise RuntimeError('Incomplete source-only module lock')
    for name,item in lock['modules'].items():exact(item,ROOT/(name+'.py'))
    loader_raw=exact(lock['modules']['revision_source_loader'],ROOT/'revision_source_loader.py')
    loader=ModuleType('_revision3_source_loader');loader.__file__=str(ROOT/'revision_source_loader.py');loader.__cached__=None
    exec(compile(loader_raw,loader.__file__,'exec',dont_inherit=True),loader.__dict__)
    common=loader.load_pinned_module('revision_common',lock['modules']['revision_common'])
    # engine's import resolves this freshly compiled common module. The current
    # source controller is registered so its reverse import cannot read a cache.
    sys.modules['revision_controller']=sys.modules[__name__]
    loaded_engine=loader.load_pinned_module('revision_engine',lock['modules']['revision_engine'])
    globals().update({name:value for name,value in common.__dict__.items() if not name.startswith('_')})
    globals()['engine']=loaded_engine;globals()['_SOURCE_LOADER']=loader;globals()['_SOURCE_LOCK']=lock
    globals()['_SOURCE_LOCK_PIN']={'path':str(lock_path.absolute()),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
    return lock


def validate_frozen_sources(graph,parent_catalog):
    available=set(parent_catalog)
    for owner in graph['topological_order']:
        row=graph['entries'][owner];check(row['source'])
        actual=re.findall(r'(?m)^import\s+([A-Za-z0-9_.]+)',Path(row['source']['path']).read_text())
        require(actual==row['imports'],'Exact full source import list differs')
        require({name for name in actual if name.startswith('ImbalancedChen.')}<=available,'Non-topological project import')
        available.add(owner)


def seed_family(family,certificate,graph,rss_gib,wall_seconds,qualification_seconds=0.0):
    """Called only after pure real parent collection. Accepts no new owner."""
    family=writable(family);require(not family.exists(),'Exclusive cold seed directory required')
    require(not list(ROOT.glob('**/FAMILY.json')),'A family already exists under this controller; explicit family transport required')
    require(certificate['verified_parent_formal_acceptance'] is True and certificate['formal_acceptance'] is False and certificate['source_revision_qualified'] is True,'Invalid revision3 transport qualification')
    require(len(certificate['normal_barriers'])==21 and sum(row['status']=='old_normal_forbidden' for row in certificate['normal_barriers'])==2
            and sum(row['status']=='accepted_normal' for row in certificate['normal_barriers'])==19,'Incomplete1520 normal barrier ledger')
    validate_failed_releases(certificate)
    require(certificate['accepted_context']['sha256']==PARENT_SHA and certificate['graph']['sha256']==GRAPH_SHA,'Wrong fixed1520/graph roots')
    require(len(certificate['project_closure'])==1520 and len(certificate['native_artifacts'])==555 and len(certificate['remaining_order'])==313,'Incomplete real parent')
    require(rss_gib>0 and wall_seconds>0,'Positive resource limits required')
    started=time.monotonic();revision_report=validate_revision_sources(graph,certificate['project_closure'],certificate['source_revision_manifest'])
    validate_frozen_sources(graph,certificate['project_closure'])
    source_inputs=[info['source'] for info in certificate['project_closure'].values()]+[info['source'] for info in graph['entries'].values()]
    object_inputs=[info['selected_object'] for info in certificate['project_closure'].values()]+certificate['native_artifacts']
    need=sum(row['bytes'] for row in unique(source_inputs+object_inputs+certificate['evidence_pins']+OLD.controller.RAWS))
    require(shutil.disk_usage(ROOT).free>need+2*1024**3,'Insufficient independent-copy space plus2GiB reserve')
    materialize_started=time.monotonic();family.mkdir(parents=True)
    for name in ('project','objects','evidence','raw','batches','state'):(family/name).mkdir()
    cert_pin=dump(family/'PARENT_CERTIFICATE.json',certificate)
    transported=transport_evidence(family,certificate['evidence_pins']);validate_transport(transported)
    transport_pin=dump(family/'EVIDENCE_TRANSPORT_MAP.json',{'protocol':PROTOCOL,'parent_context':certificate['accepted_context'],
        'same_source_graph':certificate['graph'],'original_identity_retained':True,'rows':transported,'formal_acceptance':False})
    source_map={};catalog={};copied=[]
    for owner,info in certificate['project_closure'].items():
        source=copy_exact(info['source']['path'],source_path(family,owner),info['source'])
        obj=copy_exact(info['selected_object']['path'],object_path(family,owner),info['selected_object'])
        source_map[owner]=source;copied += [source,obj]
        catalog[owner]={'source':source,'selected_object':obj,'origin':'readonly1520_original_bytes_revision3_transport'}
    for owner,row in graph['entries'].items():
        source=copy_exact(row['source']['path'],source_path(family,owner),row['source'])
        require(owner not in source_map or source_map[owner]==source,'Source graph/parent copy mismatch')
        source_map[owner]=source;copied.append(source)
    native=[]
    old_object_root=Path(certificate['project_closure'][next(iter(certificate['project_closure']))]['selected_object']['path'])
    # Selected namespace roots are fixed by accepted1520's LEAN_PATH, not suffix guessing.
    original_parent=read(certificate['accepted_context']['path']);old_object_root=Path(original_parent['lean_path'].split(':')[0])
    for row in certificate['native_artifacts']:
        native.append(copy_exact(row['path'],family/'objects'/Path(row['path']).relative_to(old_object_root),row))
    copied+=native
    barriers=[]
    for barrier in certificate['normal_barriers']:
        physical=resolve_historical(barrier['permanent_object'],transported) if barrier['status']=='accepted_normal' else catalog[barrier['module']]['selected_object']
        barriers.append({**barrier,'transported_permanent_object':physical})
        if barrier['status']=='accepted_normal':catalog[barrier['module']]['normal_success_artifact']=physical
    barriers_pin=dump(family/'NORMAL_BARRIERS.json',barriers)
    releases_pin=dump(family/'FAILED_RELEASES.json',certificate['failed_releases'])
    raw=[]
    for row in OLD.controller.RAWS:raw.append(copy_exact(row['path'],family/'raw'/Path(row['path']).name,row))
    base_context={'protocol':PROTOCOL,'verified_parent_formal_acceptance':True,'formal_acceptance':False,'P2_6_complete':False,
                  'original_accepted_context':certificate['accepted_context'],'certificate':cert_pin,'project_closure':catalog,
                  'native_artifacts':native,'runtime':certificate['runtime'],'accepted_since_family_base':[],
                  'scope':'Exact original-byte1520 transport; no new mathematical owner accepted.'}
    base_context_pin=dump(family/'BASE_CONTEXT.json',base_context)
    code=[pin(ROOT/name) for name in CODE_NAMES]
    historical=expand_historical_manifests(certificate['historical_global_manifests'])
    provenance=list(certificate['provenance_roots'].values())
    release_inputs=[]
    for release in certificate['failed_releases']:
        release_inputs += [value for value in release.values() if isinstance(value,dict) and set(value)=={'path','bytes','sha256'}]
        failed_anchor=read(release['failed_anchor']['path'])
        release_inputs += [failed_anchor[key] for key in ('global_pre_anchor','global_pre_report','mcp_record')]
        release_inputs.append(read(release['old_batch']['path'])['global_inputs'])
    release_inputs += [revision_report['prior_graph'],revision_report['new_geometry_manifest'],revision_report['generator']]
    original_catalog=[pin for info in certificate['project_closure'].values() for pin in (info['source'],info['selected_object'])]
    baseline=unique(historical+release_inputs+certificate['shared_external_pins']+certificate['evidence_pins']+original_catalog+certificate['native_artifacts']+
                    copied+raw+[row['physical'] for row in transported]+code+provenance+
                    [cert_pin,transport_pin,barriers_pin,releases_pin,base_context_pin,certificate['graph'],certificate['source_revision_manifest'],*certificate['runtime'].values()])
    materialize_seconds=time.monotonic()-materialize_started;readback_started=time.monotonic()
    # This cold readback is real; no stat shortcut. Later epochs do not rerun cold collector/copy.
    for item in baseline:check(item)
    readback_seconds=time.monotonic()-readback_started
    baseline_pin=dump(family/'BASE_GLOBAL_INPUTS.json',baseline)
    value={'schema':'p26_cell06_source_revision3_family_v1','protocol':PROTOCOL,'family_root':str(family),'formal_acceptance':False,'P2_6_complete':False,
           'certificate':cert_pin,'source_revision_manifest':certificate['source_revision_manifest'],'failed_releases':certificate['failed_releases'],'failed_releases_manifest':releases_pin,
           'source_revision_qualified':True,
           'transport':transport_pin,'base_context':base_context_pin,'base_catalog':catalog,'native_artifacts':native,
           'runtime':certificate['runtime'],'environment':certificate['environment'],
           'lean_path':':'.join([str(family/'objects'),*certificate['lean_path_tail']]),'external_modules':certificate['external_modules'],
           'graph':certificate['graph'],'project_files':sorted(row['path'] for row in source_map.values()),'project_sources':source_map,
           'base_global_inputs':baseline_pin,'code_pins':code,'normal_barriers':barriers,'normal_barriers_manifest':barriers_pin,
           'normal_search_roots':sorted(set(certificate['normal_search_roots']+[str(ROOT)]+[str(Path(row['old_family']['path']).parent) for row in certificate['failed_releases']])),'provenance_roots':certificate['provenance_roots'],
           'rss_gib':rss_gib,'wall_seconds':wall_seconds,'maximum_batch_size':8,'concurrency':1,'same_source_graph_required':True,
           'source_repair_transport_implemented':'exact_revision3_four_lint_fixes_and_one_known_failed_release_only','raw_copies':raw,'independent_inode_copies':True,
           'cold_seed_seconds_excluding_qualification':time.monotonic()-started,'qualification_seconds':qualification_seconds,
           'namespace_and_evidence_materialization_seconds':materialize_seconds,'cold_global_readback_seconds':readback_seconds,'copy_bytes_upper_bound':need,
           'scope':'Immutable same-graph family; explicit atomic1..8-owner epochs with actual global boundary byte validation.'}
    return dump(family/'FAMILY.json',value)


def load_family(family,expected_sha,controller_sha):
    family=writable(family)
    require(pin(ROOT/'revision_controller.py')['sha256']==controller_sha,'Externally supplied controller SHA differs')
    require(pin(family/'FAMILY.json')['sha256']==expected_sha,'Externally supplied family SHA differs')
    extension=read(family/'FAMILY.json');extension['_anchor']=pin(family/'FAMILY.json')
    ensure_clean(family/'batches/PREFLIGHT',extension)
    try:
        require(extension['protocol']==PROTOCOL and extension['family_root']==str(family),'Family path/protocol transplant')
        require(extension['graph']['sha256']==GRAPH_SHA and extension['same_source_graph_required'] is True and extension['source_repair_transport_implemented']=='exact_revision3_four_lint_fixes_and_one_known_failed_release_only','Unsupported source graph policy')
        for item in extension['code_pins']+[extension['graph'],extension['certificate'],extension['transport'],extension['base_context'],extension['normal_barriers_manifest'],extension['base_global_inputs'],extension['source_revision_manifest'],extension['failed_releases_manifest']]:check(item)
        require(read(extension['normal_barriers_manifest']['path'])==extension['normal_barriers'],'Normal barriers differ')
        require(read(extension['failed_releases_manifest']['path'])==extension['failed_releases'] and extension['source_revision_qualified'] is True,'Failed-release/source revision qualification differs')
        validate_failed_releases(extension)
        require(extension['certificate']['sha256']==read(extension['base_context']['path'])['certificate']['sha256'],'Certificate/context mismatch')
    except Exception as exc:sticky(family/'batches/PREFLIGHT','Anchored family input mismatch',str(exc),extension)
    return extension


def validate_epoch_parent(family,extension,parent_pin,current_epoch=None):
    """Validate sealed metadata inheritance, not replay old proof/audit semantics.

    Prior raw logs/objects/D arrays are selected by their original sealed pins into
    the next real G PRE/POST. They are never re-pinned as newly trusted bytes.
    One transaction deduplicates immutable metadata pin checks. No previous G is
    expanded/hash-checked here, and no previous mode parser/executor is called.
    """
    family=Path(family);seen={};prefix=[]
    def checked(item):
        previous=seen.setdefault(item['path'],item);require(previous==item,'Conflicting ancestor metadata pin')
        if previous is item:check(item)
        prefix.append(item);return read(item['path'])
    base=checked(extension['base_context'])
    require(base['project_closure']==extension['base_catalog'] and base['formal_acceptance'] is False and base['verified_parent_formal_acceptance'] is True,'Transport base changed')
    tip=checked(parent_pin);chain=[];cursor=parent_pin
    while cursor!=extension['base_context']:
        value=checked(cursor)
        require(value['protocol']==PROTOCOL and value['family']==extension['_anchor'] and value['formal_acceptance'] is True
                and value['P2_6_complete'] is False and value['global_validation_scope']=='batch_boundary','Invalid inherited accepted context')
        require(cursor['path']==str(family/'batches'/Path(value['batch']['path']).parent.name/'accepted-contexts'/(value['accepted_in_this_batch'][-1]+'.json')),'Wrong accepted context location')
        chain.append((cursor,value));cursor=value['accepted_parent']
        require(len(chain)<=len(read(extension['graph']['path'])['topological_order']),'Cyclic/excess accepted ancestry')
    chain.reverse();catalog=dict(extension['base_catalog']);accepted=[];previous=extension['base_context'];epochs={};epoch_namespaces={}
    for context_pin,context in chain:
        batch=checked(context['batch']);epoch=Path(context['batch']['path']).parent
        require(context['batch']['path']==str(epoch/'BATCH.json') and epoch.parent==family/'batches','Inherited batch root transplant')
        require(batch['family']==extension['_anchor'] and batch['concurrency']==1 and batch['failure_policy']=='atomic_all_declared_owners','Inherited batch policy differs')
        if str(epoch) not in epochs:
            require(context['accepted_in_this_batch']==[batch['owners'][0]] and batch['parent_context']==previous,'Epoch starts from wrong prefix')
            require(batch['owners']==next_owners(read(extension['graph']['path'])['topological_order'],set(catalog),len(batch['owners'])),'Historical owner skip/repeat')
            require(batch['accepted_before']==accepted and batch['epoch_index']==len(epochs)+1,'Inherited batch order differs')
            ensure_clean(epoch,extension)
            seal=checked(context['batch_seal']);require(context['batch_seal']['path']==str(epoch/'state/BATCH_ACCEPTED.json'),'Wrong seal location')
            require(seal['protocol']==PROTOCOL and seal['status']=='BATCH_ACCEPTED' and seal['formal_acceptance'] is True and seal['P2_6_complete'] is False,'Invalid inherited seal')
            require(seal['family']==extension['_anchor'] and seal['batch']==context['batch'] and seal['parent_context']==previous and seal['owners']==batch['owners'],'Inherited seal transplant')
            require(len(seal['pending_mode_receipts'])==3*len(batch['owners']),'Incomplete inherited mode set')
            require(env_hash(env_for(epoch,extension))==batch['environment_sha256'],'Inherited final allowlist environment changed')
            spec=checked(batch['global_inputs']);checked(batch['whitelist'])
            require(spec['family']==extension['_anchor'] and spec['parent_context']==previous and spec['baseline']==extension['base_global_inputs'],'Inherited G selector differs')
            require(read(batch['whitelist']['path'])==batch['owners'] and set(row['path'] for row in batch['helpers'])=={str(epoch/'helpers'/(owner+'.Owned.lean')) for owner in batch['owners']},'Inherited whitelist/helper selector differs')
            prefix+=spec['prefix_inputs']+spec['batch_static']+[spec['baseline']]+seal['delta_inputs']+batch['helpers']
            reports=[]
            for purpose in ('PRE','POST'):
                report=checked(seal['global_'+purpose.lower()]);reports.append(report)
                require(report['protocol']==PROTOCOL and report['purpose']==purpose and report['family']==extension['_anchor'] and report['batch']==context['batch']
                        and report['global_inputs']==batch['global_inputs'] and report['matched'] is True and report['mismatches']==[]
                        and report['global_validation_scope']=='batch_boundary','Inherited real boundary report differs')
            require(reports[0]['actual_map_sha256']==reports[1]['actual_map_sha256'],'Inherited PRE/POST differs')
            markers={}
            for index,owner in enumerate(batch['owners']):
                for mode_index,mode in enumerate(MODES):
                    marker_pin=seal['pending_mode_receipts'][index*3+mode_index];marker=checked(marker_pin);ident=marker['identity']
                    require(marker_pin['path'].startswith(str(epoch/'steps'/owner/mode)+'/') and Path(marker_pin['path']).name=='PENDING.json','Inherited marker path differs')
                    require(ident['protocol']==PROTOCOL and ident['family']==extension['_anchor'] and ident['batch']==context['batch'] and ident['key']==owner and ident['mode']==mode
                            and ident['batch_pre']==seal['global_pre'] and ident['environment_sha256']==batch['environment_sha256']
                            and ident['global_validation_scope']=='batch_boundary' and marker['formal_acceptance'] is False and marker['batch_post'] is None,'Inherited mode identity/scope transplant')
                    require(marker['status']==('NORMAL_SUCCEEDED_PENDING_GLOBAL' if mode=='normal' else 'PROCESS_VALIDATED_PENDING_GLOBAL'),'Wrong inherited normal barrier status')
                    result=checked(marker['result']);require(result['protocol']==PROTOCOL and result['formal_acceptance'] is False and 'postcheck' not in result and result['global_validation_scope']=='batch_boundary','Inherited result scope differs')
                    require(result['exit_code']==0 and result['stop_reason'] is None,'Inherited mode did not succeed')
                    # Result/command/return/log/artifact exact original pins are in
                    # sealed D, checked by the upcoming complete real G boundary.
                    require(result['process_return']==marker['process_return'],'Inherited process return chain differs')
                    markers[(owner,mode)]=(marker,result)
            epochs[str(epoch)]={'batch':batch,'seal_pin':context['batch_seal'],'markers':markers}
            expected_paths={row['path'] for row in seal['delta_inputs'] if Path(row['path']).is_relative_to(epoch)}
            expected_paths|={row['path'] for row in batch['helpers']}|{batch['whitelist']['path'],batch['global_inputs']['path'],context['batch']['path'],context['batch_seal']['path']}
            epoch_namespaces[str(epoch)]=expected_paths
        inherited=epochs[str(epoch)];require(context['batch_seal']==inherited['seal_pin'],'Changed inherited seal within epoch')
        index=len(context['accepted_in_this_batch'])-1;owner=batch['owners'][index]
        require(context['accepted_in_this_batch']==batch['owners'][:index+1],'Wrong per-batch prefix counter')
        normal=inherited['markers'][(owner,'normal')][1]['object'];require(normal is not None,'Missing inherited permanent normal')
        require(normal['path'].startswith(str(epoch/'steps'/owner/'normal')+'/') and Path(normal['path']).name=='normal.olean','Permanent normal ref transplant')
        catalog[owner]={'source':extension['project_sources'][owner],'selected_object':{**normal,'path':str(object_path(family,owner))},
                        'origin':'accepted_source_revision3_family_batch_global_boundary_v1','normal_success_artifact':normal}
        accepted.append(owner)
        require(context['accepted_parent']==previous and context['epoch_parent']==batch['parent_context'] and context['project_closure']==catalog
                and context['accepted_since_family_base']==accepted and context['native_artifacts']==extension['native_artifacts']
                and context['runtime']==extension['runtime'] and context['lean_path']==extension['lean_path'],'Inherited catalog/runtime/ancestry differs')
        epoch_namespaces[str(epoch)].add(context_pin['path']);previous=context_pin
    require(parent_pin==previous,'Only latest complete accepted prefix is eligible')
    if chain:
        last=chain[-1][1];last_batch=epochs[str(Path(last['batch']['path']).parent)]['batch']
        require(last['accepted_in_this_batch']==last_batch['owners'],'Intermediate atomic-batch prefix cannot start an epoch')
    actual_epochs={str(path) for path in (family/'batches').iterdir() if path!=current_epoch}
    require(actual_epochs==set(epochs),'Unsealed/unknown epoch blocks successor or prefix rollback')
    for epoch,expected in epoch_namespaces.items():
        actual={str(path) for path in Path(epoch).rglob('*') if path.is_file()}
        require(actual==expected,'Inherited evidence namespace differs')
    # Only new family canonical copies may be restored, never a provider root.
    engine.catalog_objects(current_epoch or family/'batches/PREFLIGHT',{**extension,'parent_catalog':catalog},{})
    result=dict(tip);result['_prefix_inputs']=unique(prefix+[info['selected_object'] for info in catalog.values()])
    result['_closed_namespaces']=epoch_namespaces
    return result


def freeze_epoch(family,extension,parent_pin,name,count):
    started=time.monotonic();family=Path(family)
    require(type(count) is int and 1<=count<=8,'Batch length must be1..8')
    require(re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]{0,63}',name) is not None,'Unsafe epoch name')
    epoch=writable(family/'batches'/name);require(not epoch.exists(),'Exclusive epoch directory required')
    require(parent_pin['sha256'] and len(parent_pin['sha256'])==64,'Explicit current parent SHA required')
    try:
        parent=validate_epoch_parent(family,extension,parent_pin)
        check(extension['graph']);graph=read(extension['graph']['path'])
    except Exception as exc:sticky(family/'batches/PREFLIGHT','Accepted prefix mismatch',str(exc),extension)
    owners=next_owners(graph['topological_order'],set(parent['project_closure']),count)
    require_pilot(parent['project_closure'],owners)
    try:
        available=set(parent['project_closure'])
        for owner in owners:
            require({m for m in graph['entries'][owner]['imports'] if m.startswith('ImbalancedChen.')}<=available,'Unaccepted project dependency')
            engine.refuse_other_stage_normal(epoch,extension,owner);available.add(owner)
        engine.catalog_objects(epoch,{**extension,'parent_catalog':parent['project_closure']},{})
    except Exception as exc:sticky(family/'batches/PREFLIGHT','Accepted prefix/normal barrier mismatch',str(exc),extension)
    epochs=list((family/'batches').iterdir())
    epoch.mkdir()
    for part in ('helpers','state','steps','accepted-contexts','home','tmp'):(epoch/part).mkdir()
    helpers=[]
    for i,owner in enumerate(owners):
        path=epoch/'helpers'/(owner+'.Owned.lean')
        with path.open('x') as f:f.write(OLD.templates.audit(sorted(parent['project_closure'])+owners[:i+1],[owner]))
        helpers.append(pin(path))
    whitelist=dump(epoch/'WHITELIST.json',owners)
    prefix=parent['_prefix_inputs']+[parent_pin]
    extension['_closed_namespaces']=parent['_closed_namespaces']
    selector=dump(epoch/'GLOBAL_INPUTS.json',{'protocol':PROTOCOL,'family':extension['_anchor'],'parent_context':parent_pin,
        'baseline':extension['base_global_inputs'],'prefix_inputs':unique(prefix),'batch_static':helpers+[whitelist]})
    batch={'schema':'p26_cell06_source_revision3_family_epoch_v1','protocol':PROTOCOL,'family':extension['_anchor'],'epoch_index':len(epochs)+1,
           'parent_context':parent_pin,'owners':owners,'accepted_before':parent.get('accepted_since_family_base',[]),'global_inputs':selector,
           'helpers':helpers,'whitelist':whitelist,'environment_sha256':env_hash(env_for(epoch,extension)),
           'concurrency':1,'failure_policy':'atomic_all_declared_owners','global_validation_scope':'batch_boundary',
           'normal_success_recompile_allowed':False,'formal_acceptance':False,'P2_6_complete':False,
           'epoch_freeze_seconds':time.monotonic()-started}
    return dump(epoch/'BATCH.json',batch)


def main():
    parser=argparse.ArgumentParser(description=__doc__);sub=parser.add_subparsers(dest='action',required=True)
    bootstrap=sub.add_parser('check-bootstrap');bootstrap.add_argument('--source-lock-file',type=Path)
    seed=sub.add_parser('seed');seed.add_argument('--family',type=Path,required=True);seed.add_argument('--parent-context',type=Path,required=True);seed.add_argument('--parent-sha256',required=True)
    seed.add_argument('--graph',type=Path,required=True);seed.add_argument('--graph-sha256',required=True);seed.add_argument('--rss-gib',type=int,default=12);seed.add_argument('--wall-seconds',type=int,default=2400)
    freeze=sub.add_parser('freeze');freeze.add_argument('--family',type=Path,required=True);freeze.add_argument('--family-sha256',required=True);freeze.add_argument('--parent-context',type=Path,required=True);freeze.add_argument('--parent-sha256',required=True);freeze.add_argument('--epoch',required=True);freeze.add_argument('--count',type=int,required=True)
    run=sub.add_parser('run');run.add_argument('--epoch-directory',type=Path,required=True);run.add_argument('--family-sha256',required=True);run.add_argument('--batch-sha256',required=True);run.add_argument('--parent-sha256',required=True)
    for command in (seed,freeze,run,bootstrap):
        command.add_argument('--controller-sha256',required=True);command.add_argument('--source-lock-sha256',required=True)
    args=parser.parse_args()
    _bootstrap_runtime(args.source_lock_sha256,args.controller_sha256,getattr(args,'source_lock_file',None))
    require(pin(ROOT/'revision_controller.py')['sha256']==args.controller_sha256,'Externally supplied controller SHA differs')
    if args.action=='check-bootstrap':
        print(json.dumps({'controller':pin(ROOT/'revision_controller.py'),'source_lock':_SOURCE_LOCK_PIN,'runtime_source_only':True,
                          'parent_qualification_called':False,'real_seed':False,'Lean_commands':0,'MCP_jobs':0,'formal_acceptance':False,'P2_6_complete':False}));return
    with (ROOT/'EXECUTION.lock').open('a+') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        if args.action=='seed':
            parent_module=_SOURCE_LOADER.load_pinned_module('parent_revision3',_SOURCE_LOCK['modules']['parent_revision3'])
            collect_revision3_parent=parent_module.collect_revision3_parent
            seed_started=time.monotonic()
            certificate=collect_revision3_parent(args.parent_context,args.parent_sha256,args.graph,args.graph_sha256)
            qualification_seconds=time.monotonic()-seed_started
            result=seed_family(args.family,certificate,read(args.graph),args.rss_gib,args.wall_seconds,qualification_seconds)
            print(json.dumps({'family':result,'prepared_not_executed':True,'formal_acceptance':False,'Lean_commands':0,
                              'qualification_seconds':qualification_seconds,'total_cold_seed_seconds':time.monotonic()-seed_started}))
        elif args.action=='freeze':
            extension=load_family(args.family,args.family_sha256,args.controller_sha256)
            require(not extension.get('synthetic_fixture',False),'CLI forbids fixtures')
            parent=pin(args.parent_context);require(parent['sha256']==args.parent_sha256,'Externally supplied current parent SHA differs')
            result=freeze_epoch(args.family,extension,parent,args.epoch,args.count)
            print(json.dumps({'batch':result,'prepared_not_executed':True,'formal_acceptance':False,'Lean_commands':0}))
        else:
            extension,batch=engine.load_contract(args.epoch_directory,args.family_sha256,args.batch_sha256,args.controller_sha256,args.parent_sha256)
            require(not extension.get('synthetic_fixture',False),'CLI forbids fixtures')
            result=engine.run_batch(args.epoch_directory,extension,batch)
            print(json.dumps({'batch_accepted':result,'formal_acceptance':True,'P2_6_complete':False,'scope':'Only exact declared same-graph batch plus inherited accepted prefix.'}))


if __name__=='__main__':main()
