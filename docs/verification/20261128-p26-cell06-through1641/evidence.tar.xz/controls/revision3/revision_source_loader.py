"""Compile exact pinned Python source bytes; never consult Python bytecode caches."""
import hashlib
from pathlib import Path
import sys
from types import ModuleType
sys.dont_write_bytecode=True


def load_pinned_module(name,expected):
    path=Path(expected['path']);raw=path.read_bytes()
    if len(raw)!=expected['bytes'] or hashlib.sha256(raw).hexdigest()!=expected['sha256']:
        raise RuntimeError('Pinned Python source bytes differ: '+str(path))
    module=ModuleType(name);module.__file__=str(path);module.__package__=name.rpartition('.')[0];module.__cached__=None
    previous=sys.modules.get(name);sys.modules[name]=module
    try:exec(compile(raw,str(path),'exec',dont_inherit=True),module.__dict__)
    except BaseException:
        if previous is None:sys.modules.pop(name,None)
        else:sys.modules[name]=previous
        raise
    return module
