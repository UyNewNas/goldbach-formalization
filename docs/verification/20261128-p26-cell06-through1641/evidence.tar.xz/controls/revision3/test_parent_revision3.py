"""Negative guards for accepted-parent and exact failed-tail transport."""
from pathlib import Path
import sys
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parent))
import parent_revision3 as p


class RevisionGuards(unittest.TestCase):
    def test_exact_proof_edit(self):
        old='noncomputable def blockChars : List Char := chunk0048Chars00\n'+p.BEFORE
        p.validate_patch_bytes(old.encode(),old.replace(p.BEFORE,p.AFTER).encode())

    def test_statement_or_data_change_rejected(self):
        old='noncomputable def blockChars : List Char := chunk0048Chars00\n theorem T : 1=1 := '+p.BEFORE
        for new in [old.replace(p.BEFORE,p.AFTER).replace('1=1','0=1'),old,old.replace(p.BEFORE,p.AFTER)+'\naxiom bad : False']:
            with self.assertRaises(RuntimeError):p.validate_patch_bytes(old.encode(),new.encode())

    def test_non_singleton_rejected(self):
        old='noncomputable def blockChars : List Char := chunk0048Chars00 ++ chunk0049Chars00\n'+p.BEFORE
        with self.assertRaises(RuntimeError):p.validate_patch_bytes(old.encode(),old.replace(p.BEFORE,p.AFTER).encode())

    def test_only_explicit_failed_status(self):
        result={'exit_code':1,'stop_reason':None,'object':None,'formal_acceptance':False,'seconds':2.,'sampled_peak_tree_rss_bytes':10}
        p.validate_failed_result(result)
        for key,value in [('exit_code',0),('exit_code',None),('exit_code','1'),('exit_code',True),('stop_reason','wall_timeout'),('object',{}),('formal_acceptance',True)]:
            wrong={**result,key:value}
            with self.assertRaises(RuntimeError):p.validate_failed_result(wrong)

    def test_outer_unknown_roots_rejected_early(self):
        with self.assertRaises(RuntimeError):p.collect_revision3_parent(Path('/absent'),'0'*64,Path('/absent'),p.NEW_GRAPH_SHA)

    def test_original_outside_managed_references_preserved(self):
        def pin(n):return {'path':'/'+n,'bytes':1,'sha256':'a'*64}
        def unique(rows):return sorted({x['path']:x for x in rows}.values(),key=lambda x:x['path'])
        base,parent,managed,reference,obj=[pin(n) for n in ['base','parent','managed','runtime','object']]
        self.assertEqual(p.inherited_prefix(unique,base,parent,[managed],[reference,base],[obj]),unique([base,parent,managed,reference,obj]))


if __name__=='__main__':unittest.main(verbosity=2)
