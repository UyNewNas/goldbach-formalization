# Explicit sourceRevision3 family candidate

This is a new protocol, `source_revision3_family_batch_global_boundary_v1`. It inherits the already accepted1520 prefix and permits exactly4 reviewed unaccepted singleton lint fixes plus one exact known failed normal release. It does not edit or reinterpret the old family, its graph0c, any accepted source/object, original JSON, receipt or identity. No real seed, Lean/lake/MCP or proof has been executed by this implementer.

Root owns `parent_revision3.py`/`test_parent_revision3.py`. The direct source controller requires an externally pinned SOURCE_LOCK.json; its bootstrap checks exact controller/loader/common/engine/parent bytes and compiles common/engine/parent from source without consulting .pyc. A synthetic valid-but-untrusted .pyc negative test covers all3 modules. The -B flag still disables bytecode writes; source-only loading also prevents cached-bytecode reads. The agreed collector is `collect_revision3_parent(parentContext,expectedParentSha,graphPath,expectedGraphSha)->dict`, with the prior certificate core, `source_revision_qualified:true`, `source_revision_manifest` Pin and exactly one `failed_releases` tuple. This new controller never calls old main/step/prepare/recovery helpers. It imports only the old pinned readonly hashing/process/templates/audit parser support used by the reviewed family protocol.

The accepted parent is1520, SHA `e3ad37ec35b564bd32a4c6ec55d7a2bc9d16f7df86e7b96445f9f6634fea69f5`. The source graph is334 modules, SHA `b072272b21689ae65097f2c14b553412c5650813a8a5fe3b7116b29363f10927`, with313 remaining owners and no accepted source change. Revision report SHA is `99182593d8a0021f5d7bc0d9a4d31a036f7187a510ecabcb6a1f053ee9284043`. It changes only Minima006, Vertices002, VertexValues004 and Simplices014: each removes exactly19 bytes `, List.append_assoc` from one singleton hinput simp argument list. The other330 source selections, all imports/order/declarations/types/data and original readers remain fixed. All4 are still SOURCE_CANDIDATE until their own actual proof checks succeed.

Cold seed copies a complete1520+555 object/native first root using independent inodes and freezes the full revised source selection. Original identities/evidence bytes remain original, with explicit physical transport maps. Runtime/mathlib remains shared and pinned, without another9–10GB copy. Initial no-normal ledger has2 oldData forbidden records and19 accepted-normal records. No accepted1520 normal, stock checker or owned audit is rerun by transport. Historical G manifests may be lists or reference selectors; the new recursive expansion preserves selector/baseline/family/parent/prefix/static pins and all original roles.

The sole failed exception has status `typed_failed_no_object_source_revision`. It binds old c172 family, exact third8 batch, graph0c, compiled old source, new source/graph/report, failed anchor `4dfadfbd036075f8e46a1e7bbdb50856d1ecf20b1a741b405d11c0a126b6b2f1`, COMMAND, LOCAL_INPUTS, PROCESS_RETURN, RESULT, log and original identity. Validation requires actual integer exit1, stopNone, no object/canonical/PENDING/ACCEPTED/POST/seal, no extra step files/directories, correct original PRE, exact first-mode D and strict flags/env/argv. Missing/null/string/bool/non1 exits, success/unknown attempts, changed source/tuple or additional foreign attempt all block. The foreign scan skips only that exact revalidated COMMAND with the approved revised staged source. Other cross-root failures still block. No owner-wide/root-wide exemption is implemented.

Initial production freeze is hard-gated to B1 Minima006. Only after its real normal/stock/full-owned/globalPOST creates an accepted context can root explicitly freeze later1..8 exact next owners, including a singleton tail. There is no bulk or parallel path. Each batch retains full real global PRE/POST, mode-local exact D, permanent successful-normal barriers, same-attempt process/result/log/object chains, missingPOST-only recovery, sticky integrity and complete dynamic canonical/shared/freshalias/import/type/axiom audits. The allowed axioms remain propext/Classical.choice/Quot.sound. Strict `--trust=0`, `-DwarningAsError=true`, j1 and locked4.33rc1/mathlib inputs are retained.

Root executes only after final review; replace every SHA placeholder with the exact returned value:

```bash
python -B /workspace/p26-cell06-family-revision3-20261128/revision_controller.py seed \
  --controller-sha256 CONTROLLER_SHA --source-lock-sha256 SOURCE_LOCK_SHA \
  --family /workspace/p26-cell06-family-revision3-20261128/families/main \
  --parent-context /workspace/p26-cell06-family-20261128/families/main/batches/second8/accepted-contexts/ImbalancedChen.P2OriginalSaving19Geometry06ScalableAllOriginalConstraintMinimaBlock005.json \
  --parent-sha256 e3ad37ec35b564bd32a4c6ec55d7a2bc9d16f7df86e7b96445f9f6634fea69f5 \
  --graph /workspace/p26-cell06-source-revision-20261128/v3/CANDIDATE_GRAPH_v3.json \
  --graph-sha256 b072272b21689ae65097f2c14b553412c5650813a8a5fe3b7116b29363f10927 \
  --rss-gib 12 --wall-seconds 2400

python -B /workspace/p26-cell06-family-revision3-20261128/revision_controller.py freeze \
  --controller-sha256 CONTROLLER_SHA --source-lock-sha256 SOURCE_LOCK_SHA \
  --family /workspace/p26-cell06-family-revision3-20261128/families/main \
  --family-sha256 ACTUAL_FAMILY_SHA \
  --parent-context /workspace/p26-cell06-family-revision3-20261128/families/main/BASE_CONTEXT.json \
  --parent-sha256 ACTUAL_BASE_CONTEXT_SHA --epoch pilot1 --count 1

python -B /workspace/p26-cell06-family-revision3-20261128/revision_controller.py run \
  --controller-sha256 CONTROLLER_SHA --source-lock-sha256 SOURCE_LOCK_SHA \
  --epoch-directory /workspace/p26-cell06-family-revision3-20261128/families/main/batches/pilot1 \
  --family-sha256 ACTUAL_FAMILY_SHA --batch-sha256 ACTUAL_PILOT_BATCH_SHA \
  --parent-sha256 ACTUAL_BASE_CONTEXT_SHA
```

Root must keep old controllers retired and use one new-root writer. The locked roots and exception are external SHA inputs, not a promise that a future context exists. Wrong outer CLI SHA/count is rejected without poisoning valid state; observed anchored input/ref/namespace mismatches remain sticky. Existing success normal is never rerun to repair a missing canonical object; only exact permanent-artifact restoration in the new root is used.

Host tests use synthetic new-root files, fake executor outputs and synthetic release certificates. Regression fixtures include an already accepted synthetic pilot to test later1..8 behavior; the production pre-pilot gate is tested independently. Fixtures are rejected by CLI. Actual seed/new pilot time, memory, disk, new context and source acceptance are unmeasured here. No original proof success is relabeled as a new-contract proof. Future source/runtime/controller repair, other failed classes/attempts, pending successful migration and larger graph expansion still require another explicit reviewed protocol. Cell06 integral and globalP2.6 remain incomplete.

A no-proof CLI preflight is available as `check-bootstrap --controller-sha256 ... --source-lock-sha256 ...`. It compiles/loads the locked runtime sources, reports `runtime_source_only:true`, and returns before any execution lock, parent collection, stage copy or proof action. Only that preflight accepts `--source-lock-file` for the synthetic/candidate lock tests; production seed/freeze/run always use the final ROOT/SOURCE_LOCK.json. Real CLI positive/wrong-lock/wrong-module-pin cases are covered alongside3 valid synthetic cache payloads. The current host suite has53 tests, no actual source acceptance.
