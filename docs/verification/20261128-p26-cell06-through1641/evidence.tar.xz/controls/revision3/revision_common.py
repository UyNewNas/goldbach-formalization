"""Explicit persistent-family primitives; no provider mutations or old step calls."""
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import shutil
import sys
import time
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
PROTOCOL='source_revision3_family_batch_global_boundary_v1'
MODES=('normal','stock-leanchecker','full-owned')
GRAPH_SHA='b072272b21689ae65097f2c14b553412c5650813a8a5fe3b7116b29363f10927'
PARENT_SHA='e3ad37ec35b564bd32a4c6ec55d7a2bc9d16f7df86e7b96445f9f6634fea69f5'
HELPER=Path('/workspace/p26-cell06-batch-boundary-20261128/approved_helpers.py')
HELPER_SHA='4e35f4d11c38e76ece4bdc429476e4fa4746c3c082f8db8eaea42b91d7a156bc'


def require(ok,message):
    if not ok:raise RuntimeError(message)


def pin(path):
    path=Path(path);digest=hashlib.sha256();size=0
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):digest.update(block);size+=len(block)
    return {'path':str(path.absolute()),'bytes':size,'sha256':digest.hexdigest()}


def check(item):
    require(isinstance(item,dict) and set(item)=={'path','bytes','sha256'},'Malformed exact pin')
    require(pin(item['path'])==item,'Exact byte pin differs: '+item['path'])


def read(path):return json.loads(Path(path).read_text())


def unique(items):
    result={}
    for item in items:require(result.setdefault(item['path'],item)==item,'Conflicting exact pin: '+item['path'])
    return [result[key] for key in sorted(result)]


def writable(path):
    path=Path(path).absolute();require(path.resolve().is_relative_to(ROOT),'Write outside new family implementation root')
    for part in (path,*path.parents):
        if part==ROOT.parent:break
        require(not part.is_symlink(),'Symlink in writable path')
    return path


def dump(path,value):
    path=writable(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x') as f:
        json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
    return pin(path)


def copy_exact(source,target,expected):
    check(expected);require(str(Path(source).absolute())==expected['path'],'Copy source differs from pin')
    target=writable(target);target.parent.mkdir(parents=True,exist_ok=True)
    if not target.exists():
        with Path(source).open('rb') as incoming,target.open('xb') as out:
            shutil.copyfileobj(incoming,out);out.flush();os.fsync(out.fileno())
    result=pin(target);require(all(result[k]==expected[k] for k in ('bytes','sha256')),'Independent copy differs')
    left,right=Path(source).stat(),target.stat()
    require((left.st_dev,left.st_ino)!=(right.st_dev,right.st_ino),'Copy aliases provider inode')
    return result


def next_owners(order,accepted,count):
    require(type(count) is int and 1<=count<=8,'Batch length must be1..8')
    require(len(order)==len(set(order)),'Repeated source graph owner')
    remaining=[owner for owner in order if owner not in accepted]
    require(len(remaining)>=count,'No padding or repeated tail owners')
    return remaining[:count]


def source_path(family,owner):return Path(family)/'project'/Path(owner.replace('.','/')).with_suffix('.lean')

def object_path(family,owner):return Path(family)/'objects'/Path(owner.replace('.','/')).with_suffix('.olean')


def same_bytes(a,b):return all(a[k]==b[k] for k in ('bytes','sha256'))


def env_for(epoch,extension):
    epoch=Path(epoch);sysroot=extension['environment']['sysroot']
    return {'HOME':str(epoch/'home'),'TMPDIR':str(epoch/'tmp'),'LANG':'C.UTF-8','LC_ALL':'C.UTF-8','TZ':'UTC',
            'LEAN_PATH':extension['lean_path'],'LEAN_NUM_THREADS':'1','OMP_NUM_THREADS':'1','LEAN_SYSROOT':sysroot,
            'PATH':sysroot+'/bin:/usr/bin:/bin'}


def env_hash(env):return hashlib.sha256(json.dumps(env,sort_keys=True,separators=(',',':')).encode()).hexdigest()


def flags(extension):return ['--trust=0','-DwarningAsError=true','-j1',f'-M{extension["rss_gib"]*1024}','-DmaxRecDepth=1000000','-DmaxHeartbeats=0']


def load_old():
    require(pin(HELPER)['sha256']==HELPER_SHA,'Reviewed readonly helper loader differs')
    spec=importlib.util.spec_from_file_location('_p26_family_readonly_helpers',HELPER)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module.OLD


OLD=load_old()


def family_path(extension):return Path(extension['family_root'])


def ensure_clean(epoch,extension=None):
    epoch=Path(epoch)
    require(not (epoch/'state/INTEGRITY_FAILED.json').exists(),'Sticky epoch integrity failure')
    family=family_path(extension) if extension else epoch.parent.parent
    require(not (family/'state/INTEGRITY_FAILED.json').exists(),'Sticky family integrity failure')


def sticky(epoch,reason,details=None,extension=None):
    epoch=Path(epoch);family=family_path(extension) if extension else epoch.parent.parent
    value={'protocol':PROTOCOL,'reason':reason,'details':details,'epoch':str(epoch),'formal_acceptance':False,'P2_6_complete':False}
    for path in (epoch/'state/INTEGRITY_FAILED.json',family/'state/INTEGRITY_FAILED.json'):
        if not path.exists():dump(path,value)
    raise RuntimeError('Sticky INTEGRITY_FAILED: '+reason+': '+str(details)[:400])


def transport_evidence(family,items):
    rows=[]
    for index,item in enumerate(unique(items)):
        destination=Path(family)/'evidence'/f'{index:06d}-{item["sha256"]}-{Path(item["path"]).name}'
        copied=copy_exact(item['path'],destination,item)
        rows.append({'logical':item,'physical':copied,'identity_preserved':True})
    return rows


def validate_transport(rows):
    logical={};physical=set()
    for row in rows:
        require(row.get('identity_preserved') is True and same_bytes(row['logical'],row['physical']),'Historical identity/bytes changed')
        require(logical.setdefault(row['logical']['path'],row['logical'])==row['logical'],'Conflicting transport logical pin')
        require(row['physical']['path'] not in physical,'Reused transport destination');physical.add(row['physical']['path'])
        check(row['logical']);check(row['physical'])
        a,b=(Path(row[key]['path']).stat() for key in ('logical','physical'))
        require((a.st_dev,a.st_ino)!=(b.st_dev,b.st_ino),'Transport inode aliases provider')
    return rows


def resolve_historical(item,rows):
    by_logical={row['logical']['path']:row for row in rows};require(item['path'] in by_logical,'Historical pin missing explicit transport')
    row=by_logical[item['path']];require(row['logical']==item and same_bytes(item,row['physical']),'Historical ref transplant')
    check(row['physical']);return row['physical']


def validate_process_schema(value):
    fields={'exit_code','stop_reason','seconds','sampled_peak_tree_rss_bytes'}
    require(fields<=set(value),'Incomplete process status schema')
    require(type(value['exit_code']) is int,'Process exit_code must be an integer')
    require(value['stop_reason'] is None or value['stop_reason'] in ('aggregate_tree_rss_limit','disk_reserve_512_MiB','wall_timeout'),'Unknown process stop reason')
    require(type(value['seconds']) in (int,float) and math.isfinite(value['seconds']) and value['seconds']>=0,'Invalid process elapsed time')
    require(type(value['sampled_peak_tree_rss_bytes']) is int and value['sampled_peak_tree_rss_bytes']>=0,'Invalid process RSS')
    return {key:value[key] for key in fields}

OLD_GRAPH_SHA='0c0930dc27e9ee532ac4a8c78afb2dfb5c9cf40a364076e50cddae7f4cf8dd02'
OLD_FAMILY_SHA='c172b52da388a8f068bafa925cfd9da8d8b1b47b270d93b3e9a157a17d1a522d'
REVISION_REPORT_SHA='99182593d8a0021f5d7bc0d9a4d31a036f7187a510ecabcb6a1f053ee9284043'
PILOT_OWNER='ImbalancedChen.P2OriginalSaving19Geometry06ScalableAllOriginalConstraintMinimaBlock006'
CHANGED_OWNERS={PILOT_OWNER,
 'ImbalancedChen.P2OriginalSaving19Geometry06ScalableVerticesBlock002',
 'ImbalancedChen.P2OriginalSaving19Geometry06ScalableVertexValuesBlock004',
 'ImbalancedChen.P2OriginalSaving19Geometry06ScalableSimplicesBlock014'}


def require_pilot(parent_catalog,owners):
    if PILOT_OWNER not in parent_catalog:
        require(owners==[PILOT_OWNER],'Initial revision3 production epoch must be B1 Minima006 pilot')


def approved_hinput_deletion(original,replacement,singleton):
    before=f'  have hinput : blockChars ++ tail = {singleton} ++ (tail) := by simp only [blockChars, List.append_assoc]'.encode()
    after=before.replace(b', List.append_assoc',b'')
    require(original.count(before)==1 and len(original)-len(replacement)==19 and original.replace(before,after,1)==replacement,
            'Source change is not exactly the singleton hinput19-byte deletion')


def validate_revision_sources(graph,parent_catalog,manifest):
    check(manifest);report=read(manifest['path'])
    require(manifest['sha256']==REVISION_REPORT_SHA and graph['candidate_revision']==3,'Wrong explicit source revision3 manifest/graph')
    require(report['new_graph']['sha256']==GRAPH_SHA and report['prior_graph']['sha256']==OLD_GRAPH_SHA and report['parent']['sha256']==PARENT_SHA,'Revision origin roots differ')
    require(report['changes']==graph['source_revision_changes'] and report['changed_modules']==4 and report['unchanged_graph_sources']==330
            and report['accepted1520_sources_changed']==0 and report['same_order_imports_declarations_types_and_original_data'] is True,'Revision scope differs')
    require(report['formal_acceptance'] is False and report['P2_6_complete'] is False and report['Lean_commands']==report['normal_compilations']==0,'Source candidate cannot claim new proof acceptance')
    changes={row['module']:row for row in report['changes']};require(set(changes)==CHANGED_OWNERS and not set(changes)&set(parent_catalog),'Changed owner already accepted or outside4-owner lint whitelist')
    check(report['prior_graph']);old=read(report['prior_graph']['path'])
    require(old['topological_order']==graph['topological_order'] and set(old['entries'])==set(graph['entries']),'Source revision changed owner order/inventory')
    for owner,row in graph['entries'].items():
        before=old['entries'][owner]
        require(row['imports']==before['imports'] and row['kind']==before['kind'],'Source revision changed imports/owner kind')
        if owner not in changes:require(row==before,'Source revision changed a non-whitelisted source/object')
        else:
            change=changes[owner];require(change['old_source']==before['source'] and change['new_source']==row['source'] and change['replacement_count']==1
                    and change['definitions_imports_declaration_types_and_data_unchanged'] is True,'Revision source mapping differs')
            check(change['old_source']);check(change['new_source'])
            original=Path(change['old_source']['path']).read_bytes();replacement=Path(change['new_source']['path']).read_bytes()
            approved_hinput_deletion(original,replacement,change['singleton'])
    check(report['new_geometry_manifest']);check(report['generator'])
    return report

FAILED_ANCHOR_SHA='4dfadfbd036075f8e46a1e7bbdb50856d1ecf20b1a741b405d11c0a126b6b2f1'
OLD_PROTOCOL='family_batch_global_boundary_v1'


def validate_failed_release(release,new_graph,revision_manifest,active_source=None):
    """Exact readonly exit1/no-object exception; never releases an entire owner/root."""
    require(release['module']==PILOT_OWNER and release['status']=='typed_failed_no_object_source_revision','Unsupported failed release class/owner')
    require(type(release['exit_code']) is int and release['exit_code']==1 and release['stop_reason'] is None and release['object'] is None,'Release is not typed exit1/no-object')
    require(release['new_graph']==new_graph and release['revision_manifest']==revision_manifest,'New graph/revision release transplant')
    require(new_graph['sha256']==GRAPH_SHA and release['old_graph']['sha256']==OLD_GRAPH_SHA
            and release['old_family']['sha256']==OLD_FAMILY_SHA and revision_manifest['sha256']==REVISION_REPORT_SHA
            and release['failed_anchor']['sha256']==FAILED_ANCHOR_SHA,'Wrong exact failed-release root pins')
    keys=('old_family','old_batch','old_graph','old_source','new_graph','new_source','revision_manifest','failed_anchor','command','local_inputs','process_return','result','log')
    for key in keys:check(release[key])
    old_family=read(release['old_family']['path']);batch=read(release['old_batch']['path']);old_graph=read(release['old_graph']['path']);graph=read(new_graph['path']);anchor=read(release['failed_anchor']['path'])
    require(anchor['schema']=='p26_exact_failed_singleton_tail_anchor_v1' and anchor['old_family']==release['old_family'] and anchor['old_batch']==release['old_batch']
            and anchor['old_graph']==release['old_graph'] and type(anchor['expected_exit_code']) is int and anchor['expected_exit_code']==1 and anchor['expected_stop_reason'] is None
            and anchor['expected_object'] is None and anchor['PENDING_permitted'] is False and anchor['successful_modes']==0 and anchor['formal_acceptance'] is False and anchor['P2_6_complete'] is False,'Failed-tail anchor scope differs')
    old_root=Path(release['old_family']['path']).parent;epoch=Path(release['old_batch']['path']).parent;attempt=Path(release['command']['path']).parent
    require(old_family['family_root']==str(old_root) and epoch.parent==old_root/'batches' and attempt.parent==epoch/'steps'/PILOT_OWNER/'normal'
            and str(attempt)==anchor['attempt'],'Failed attempt namespace differs')
    require(old_family['protocol']==batch['protocol']==OLD_PROTOCOL and batch['family']==release['old_family'] and old_family['graph']==release['old_graph']
            and batch['owners'][0]==PILOT_OWNER and batch['parent_context']['sha256']==PARENT_SHA,'Old failed family/batch/parent differs')
    files={'command':'COMMAND.json','local_inputs':'LOCAL_INPUTS.json','process_return':'PROCESS_RETURN.json','result':'RESULT.json','log':'output.log'}
    require(set(anchor['files'])==set(files.values()),'Anchor file selector differs')
    for key,name in files.items():require(release[key]==anchor['files'][name] and release[key]['path']==str(attempt/name),'Failed tuple sidefile transplant')
    require({str(path) for path in (epoch/'steps').rglob('*') if path.is_file()}=={str(attempt/name) for name in files.values()},'Extra/unsealed/unknown old failed modes/artifacts')
    expected_dirs={epoch/'steps',epoch/'steps'/PILOT_OWNER,epoch/'steps'/PILOT_OWNER/'normal',attempt}
    require({path for path in (epoch/'steps').rglob('*')}==(expected_dirs-{epoch/'steps'})|{attempt/name for name in files.values()}
            and all(not path.is_symlink() for path in (epoch/'steps').rglob('*')),'Unknown failed mode/attempt directory or symlink')
    canonical=old_root/'objects'/Path(PILOT_OWNER.replace('.','/')).with_suffix('.olean')
    require(not canonical.exists() and not canonical.is_symlink(),'Failed owner already has a canonical object/symlink')
    require(not (epoch/'state/BATCH_ACCEPTED.json').exists() and not list((epoch/'state').glob('POST-*'))
            and not (epoch/'state/INTEGRITY_FAILED.json').exists() and not (old_root/'state/INTEGRITY_FAILED.json').exists(),'Old failed batch has acceptance/POST/sticky state')
    check(anchor['global_pre_anchor']);check(anchor['global_pre_report']);check(anchor['mcp_record'])
    require(read(anchor['global_pre_anchor']['path'])=={'snapshot':anchor['global_pre_report'],'formal_acceptance':False},'Failed PRE anchor differs')
    pre=read(anchor['global_pre_report']['path'])
    require(pre['protocol']==OLD_PROTOCOL and pre['purpose']=='PRE' and pre['family']==release['old_family'] and pre['batch']==release['old_batch']
            and pre['global_inputs']==batch['global_inputs'] and pre['matched'] is True and pre['mismatches']==[] and pre['global_validation_scope']=='batch_boundary','Original failed PRE scope differs')
    command=read(release['command']['path']);returned=read(release['process_return']['path']);result=read(release['result']['path']);local=read(release['local_inputs']['path'])
    require(release['old_source']==old_family['project_sources'][PILOT_OWNER] and same_bytes(release['old_source'],old_graph['entries'][PILOT_OWNER]['source'])
            and release['new_source']==graph['entries'][PILOT_OWNER]['source'],'Old compiled/new revised source selection differs')
    if active_source is not None:check(active_source);require(same_bytes(active_source,release['new_source']),'Retry staged source differs from exact released revision')
    helper=[item for item in batch['helpers'] if item['path']==str(epoch/'helpers'/(PILOT_OWNER+'.Owned.lean'))]
    require(len(helper)==1,'Old failed helper selector differs')
    expected_local=unique([release['old_source'],helper[0],*old_family['code_pins'],*old_family['runtime'].values()])
    require(local==expected_local,'Old failed localD is not the exact first-mode source/helper/code/runtime selector')
    for item in local:check(item)
    ident={'protocol':OLD_PROTOCOL,'family':release['old_family'],'batch':release['old_batch'],'key':PILOT_OWNER,'mode':'normal','global_validation_scope':'batch_boundary',
           'batch_pre':anchor['global_pre_report'],'environment_sha256':env_hash(env_for(epoch,old_family)),
           'argv':[old_family['runtime']['lean']['path'],*flags(old_family),'-o','__NORMAL_OUTPUT__',release['old_source']['path']],
           'cwd':str(old_root/'project'),'timeout':old_family['wall_seconds'],'rss_bytes':old_family['rss_gib']*1024**3}
    require(ident['environment_sha256']==batch['environment_sha256'] and release['old_identity']==command['identity']==returned['identity']==ident,'Old failed identity/env/argv differs')
    require(command['actual_argv']==[str(attempt/'normal.olean') if value=='__NORMAL_OUTPUT__' else value for value in ident['argv']]
            and command['local_inputs']==release['local_inputs'],'Failed actual command/D differs')
    require(returned['protocol']==OLD_PROTOCOL and returned['command']==result['command']==release['command'] and returned['log']==result['log']==release['log']
            and returned['object'] is None and result.get('object') is None and returned['formal_acceptance'] is False
            and returned['status']=='PROCESS_RETURNED_PENDING_LOCAL_AND_GLOBAL_CHECKS' and result['process_return']==release['process_return'],'Failed return/result/log/object differs')
    require(set(returned['process_result'])=={'exit_code','stop_reason','seconds','sampled_peak_tree_rss_bytes'},'Failed process schema differs')
    process=validate_process_schema(result);require(process==validate_process_schema(returned['process_result']) and process['exit_code']==1 and process['stop_reason'] is None,'Failed process is not exact typed exit1')
    require(result['protocol']==OLD_PROTOCOL and result['global_validation_scope']=='batch_boundary' and result['formal_acceptance'] is False and 'postcheck' not in result
            and result['local_post']=={'inputs':release['local_inputs'],'all_local_files_matched':True,'file_count':len(local)},'Failed mode scope/local postcheck differs')
    text=Path(release['log']['path']).read_text();require('List.append_assoc' in text and 'unusedSimpArgs' in text,'Failed log is not the exact lint class')
    return {'module':PILOT_OWNER,'command':release['command'],'typed_failed_no_object':True,'normal_success':False,'formal_acceptance':False}


def validate_failed_releases(extension):
    releases=extension['failed_releases'];require(len(releases)==1,'Exactly one failed-attempt release required')
    require(releases[0]['new_graph']==extension['graph'] and releases[0]['revision_manifest']==extension['source_revision_manifest'],'Release contract selectors differ')
    return [validate_failed_release(row,extension['graph'],extension['source_revision_manifest']) for row in releases]


def expand_historical_manifests(manifests):
    """Original list baselines and explicit selector refs; metadata only, no old main."""
    output=[];seen={};active=set()
    def visit(item):
        require(seen.setdefault(item['path'],item)==item,'Conflicting historical selector pin')
        require(item['path'] not in active,'Historical selector cycle')
        if item['path'] in done:return
        check(item);active.add(item['path']);value=read(item['path']);output.append(item)
        if isinstance(value,list):output.extend(value)
        else:
            require(isinstance(value,dict) and {'baseline','prefix_inputs','batch_static','family','parent_context','protocol'}<=set(value),'Unsupported historical G selector schema')
            require(value['protocol'] in (OLD_PROTOCOL,PROTOCOL),'Unknown historical G protocol')
            visit(value['baseline']);output.extend(value['prefix_inputs']+value['batch_static']+[value['family'],value['parent_context']])
        active.remove(item['path']);done.add(item['path'])
    done=set()
    for manifest in manifests:visit(manifest)
    return unique(output)
