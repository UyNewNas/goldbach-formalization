# Revision3 ledger — IMPLEMENTATION_PLAN.md

Binding scope: root explicitly authorizes4 unaccepted singleton hinput lint fixes, not only the observed failed owner; preserve all1520 accepted sources/objects and raw/import/type/data bytes. New graph/new protocol, no old code edits.
ABI: agreed certificate core plus failed_releases/source_revision_manifest; exact schema confirmation pending root.
No real seed/Lean/MCP/package executed.

Core task: explicit sourceRevision3 protocol copied from reviewed persistent-family algorithms into new names/root; old mutable helpers never called. Parent ABI confirmed exactly; old list/dict selectors recursively expanded including baseline/family/parent refs.
Release task: exact1 known typed exit1/noobject release; other foreign attempts block; tamper+restore remains sticky; dangling symlink cannot masquerade as no-object/no-extra. Synthetic release records only, no actual failed mode run/replay.
Source guard RED→GREEN: actual source-only preflight exposed overly broad first append_assoc replacement for Simplices014 (3 uses). Guard now anchors exact singleton hinput line; test preserves other occurrences. Actual4×19byte/330unchanged/1520changed0/313remaining source-only preview passed; no collect/seed/Lean.
Bootstrap task RED→GREEN: after removing ordinary imports, standalone ROOT initially undefined; fixed before bootstrap. New source-only loader compiles exact locked .py bytes, bypassing common/engine/parent .pyc. Valid malicious synthetic caches demonstrate ordinary loading would use cache and pinned-source loading ignores it. Real CLI check-bootstrap positive/wronglock/wrongmodulepin pass with no proof/parent qualifier/stage action.
Host scope:53 tests passed. Root independently owns/froze parent30977(bbca...) and6guards; root reports actual readonly attempt002 success67.00683s and review0/0/0, preserving attempt001. This implementer did not rerun that collection or parent tests.
No real seed/freeze/package/Lean/lake/MCP/git/newagent/provider write performed. Final SOURCE_LOCK and code review remain the handoff gate; actual Minima006 normal/stock/owned/globalPOST and1521 credit are not claimed.
