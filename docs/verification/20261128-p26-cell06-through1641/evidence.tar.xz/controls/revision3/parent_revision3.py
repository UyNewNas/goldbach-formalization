"""Read-only inheritance of accepted1520 and one exact failed source-revision tail.

No provider recovery, proof execution, sticky marker or provider write occurs.
Existing1504 qualification is inherited by its previously checked fixed family
root; both subsequent sealed epochs are independently checked as old evidence.
"""
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys
sys.dont_write_bytecode=True

OLD_ROOT=Path('/workspace/p26-cell06-family-20261128')
FAMILY=OLD_ROOT/'families/main'
REV=Path('/workspace/p26-cell06-source-revision-20261128/v3')
PARENT=FAMILY/'batches/second8/accepted-contexts/ImbalancedChen.P2OriginalSaving19Geometry06ScalableAllOriginalConstraintMinimaBlock005.json'
PARENT_SHA='e3ad37ec35b564bd32a4c6ec55d7a2bc9d16f7df86e7b96445f9f6634fea69f5'
NEW_GRAPH_SHA='b072272b21689ae65097f2c14b553412c5650813a8a5fe3b7116b29363f10927'
OLD_GRAPH_SHA='0c0930dc27e9ee532ac4a8c78afb2dfb5c9cf40a364076e50cddae7f4cf8dd02'
FAMILY_SHA='c172b52da388a8f068bafa925cfd9da8d8b1b47b270d93b3e9a157a17d1a522d'
BASE_SHA='397fa4294fc51aa8a5008b1be86e774aee53049a7b264a2d01ba666860466d94'
FINAL_SHA='f26363a19799e72deb1842e9befa3d204e8b603b262ecc08a132516bee86ec25'
LAST_SEAL_SHA='3ada5a3f504af39ed98b3014a4443bbad849d92932c6834a23719e97fa4b3cdd'
FAILED_ANCHOR_SHA='4dfadfbd036075f8e46a1e7bbdb50856d1ecf20b1a741b405d11c0a126b6b2f1'
SUPPORT=Path('/workspace/p26-cell06-family-first8-evidence-20261128/package_first8.py')
SUPPORT_SHA='662c9ab293b80b392061bc8ae07bdab3cfb8111b62d72bc8e1b8196cfed326c8'
PROTOCOL='family_batch_global_boundary_v1'
MODES=('normal','stock-leanchecker','full-owned')
FAILED='ImbalancedChen.P2OriginalSaving19Geometry06ScalableAllOriginalConstraintMinimaBlock006'
CHANGED={FAILED,*('ImbalancedChen.P2OriginalSaving19Geometry06Scalable'+name for name in ['VerticesBlock002','VertexValuesBlock004','SimplicesBlock014'])}
BEFORE='by simp only [blockChars, List.append_assoc]'
AFTER='by simp only [blockChars]'


def require(ok,message):
    if not ok:raise RuntimeError(message)


def validate_patch_bytes(before,after):
    a,b=before.decode(),after.decode()
    require(a.count(BEFORE)==1 and b==a.replace(BEFORE,AFTER),'Only exact singleton proof-list edit is allowed')
    require(re.search(r'noncomputable def blockChars : List Char := chunk\d+Chars\d+\s*\n',a) is not None,'Not a singleton block')
    require(len(before)-len(after)==19,'Unexpected proof edit size')


def validate_failed_result(value):
    require(type(value.get('exit_code')) is int and value['exit_code']==1 and value.get('stop_reason','missing') is None,
            'Only the exact typed exit1/stopNone is released')
    require('object' in value and value['object'] is None and value.get('formal_acceptance') is False,'A success/object/unknown is not a failed release')


def inherited_prefix(unique,base,parent,managed,referenced,objects):
    """Exact old freeze selector: managed payloads plus every sealed old ref."""
    return unique([base,parent]+list(managed)+list(referenced)+list(objects))


def _support():
    raw=SUPPORT.read_bytes();require(hashlib.sha256(raw).hexdigest()==SUPPORT_SHA,'Readonly support source changed')
    spec=importlib.util.spec_from_file_location('_p26_revision3_readonly_support',SUPPORT)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module


def collect_revision3_parent(parent_context:Path,expected_parent_sha256:str,graph_path:Path,expected_graph_sha256:str)->dict:
    require(expected_parent_sha256==PARENT_SHA and expected_graph_sha256==NEW_GRAPH_SHA,'Unknown revision parent/graph roots')
    require(Path(parent_context).absolute()==PARENT and Path(graph_path).absolute()==REV/'CANDIDATE_GRAPH_v3.json','Wrong fixed revision locations')
    support=_support();r=support.Readonly();pin=support.pin;unique=support.unique
    parent,parent_pin=r.rooted(PARENT,PARENT_SHA)
    family,fp=r.rooted(FAMILY/'FAMILY.json',FAMILY_SHA);base,base_pin=r.rooted(FAMILY/'BASE_CONTEXT.json',BASE_SHA)
    final,final_pin=r.rooted(OLD_ROOT/'DELIVERY_MANIFEST.json',FINAL_SHA)
    for item in final['members']:r.check(item)
    for key in ('candidate','host_report','binding_design','parent_delivery'):r.check(final[key])
    require(family['protocol']==PROTOCOL and family['base_context']==base_pin and family['family_root']==str(FAMILY),'Wrong inherited family')
    require(base['formal_acceptance'] is False and base['verified_parent_formal_acceptance'] is True
            and len(base['project_closure'])==1504 and base['project_closure']==family['base_catalog'],'Wrong inherited1504 transport')
    certificate=r.read(family['certificate']);require(base['certificate']==family['certificate'] and certificate['accepted_context']==base['original_accepted_context']
            and certificate['verified_parent_formal_acceptance'] is True and certificate['formal_acceptance'] is False,'Known1504 qualification root differs')
    require(certificate['accepted_context']['sha256']=='c19494c887e8768213dfb8c15b43fc36f2f52c72d527a86f8095f4a66f25dcb8','Wrong original1504 root')
    old_graph,old_graph_pin=r.rooted(family['graph']['path'],OLD_GRAPH_SHA)
    graph,graph_pin=r.rooted(graph_path,NEW_GRAPH_SHA);revision_pin=pin(REV/'REVISION_REPORT.json');revision=r.read(revision_pin)
    require(graph['candidate_revision']==3 and graph['prior_candidate_graph']==old_graph_pin and graph['revision_parent_accepted_context']==parent_pin,'Revision lineage differs')
    require(graph['topological_order']==old_graph['topological_order'] and len(graph['entries'])==334 and set(graph['entries'])==set(old_graph['entries']),'Graph inventory/order differs')
    require(revision['new_graph']==graph_pin and revision['prior_graph']==old_graph_pin and revision['parent']==parent_pin
            and revision['changed_modules']==4 and revision['accepted1520_sources_changed']==0 and revision['formal_acceptance'] is False,'Wrong proof-only revision report')
    changes={row['module']:row for row in revision['changes']};require(set(changes)==CHANGED,'Unexpected source edit domain')
    for owner,row in graph['entries'].items():
        old=old_graph['entries'][owner]
        if owner in CHANGED:
            change=changes[owner];require(owner not in parent['project_closure'],'Accepted source cannot be repaired/re-normalized')
            require(row=={**old,'source':change['new_source']} and old['source']==change['old_source'],'Source revision changes imports/roles')
            r.check(old['source']);r.check(row['source']);validate_patch_bytes(Path(old['source']['path']).read_bytes(),Path(row['source']['path']).read_bytes())
        else:require(row==old,'Unaffected graph source/import changed')
    require(graph['source_revision_changes']==revision['changes'],'Graph/patch table differs')
    for owner,info in parent['project_closure'].items():
        if owner in graph['entries']:
            require(all(info['source'][key]==graph['entries'][owner]['source'][key] for key in ('bytes','sha256')),'Accepted source bytes changed')
    require(set(graph['entries'])&set(parent['project_closure'])==set(old_graph['entries'])&set(parent['project_closure'])
            and len(set(graph['entries'])&set(parent['project_closure']))==21,'Wrong inherited graph intersection')
    require(parent['formal_acceptance'] is True and parent['P2_6_complete'] is False and len(parent['project_closure'])==1520,'Parent is not accepted1520')
    require(not (FAMILY/'state/INTEGRITY_FAILED.json').exists(),'Old family has sticky failure')
    require({p.name for p in (FAMILY/'batches').iterdir()}=={'first8','second8','third8'},'Unknown/unregistered old epoch')
    old,helper_pin=support.load_parser(r)
    stage=r.read(family['provenance_roots']['old_stage']);r.check(stage['environment_lock'])
    old.controller.environment_inventory(stage)
    baseline=r.read(family['base_global_inputs']);transport=r.read(family['transport']);normal_rows=r.read(family['normal_barriers_manifest'])
    require(normal_rows==family['normal_barriers'] and len(normal_rows)==5,'Original five barriers differ')
    require(transport['original_identity_retained'] is True and transport['parent_context']==base['original_accepted_context'],'Old evidence transport differs')
    for row in transport['rows']:
        require(row['identity_preserved'] is True and all(row['logical'][key]==row['physical'][key] for key in ('bytes','sha256')),'Old evidence transport changed bytes')
        r.check(row['logical']);r.check(row['physical'])

    def argv(epoch,owner,mode):
        flags=['--trust=0','-DwarningAsError=true','-j1',f'-M{family["rss_gib"]*1024}','-DmaxRecDepth=1000000','-DmaxHeartbeats=0']
        if mode=='normal':return [family['runtime']['lean']['path'],*flags,'-o','__NORMAL_OUTPUT__',str(FAMILY/'project'/Path(owner.replace('.','/')).with_suffix('.lean'))]
        if mode=='stock-leanchecker':return [family['runtime']['leanchecker']['path'],'--verbose',owner]
        return [family['runtime']['lean']['path'],*flags,str(epoch/'helpers'/(owner+'.Owned.lean'))]

    global_manifests=[family['base_global_inputs']];all_history=[];contexts=[base_pin];catalog=dict(family['base_catalog']);accepted=[];previous=base_pin;prior_managed=[];prior_referenced=[]
    barriers=[]
    for row in normal_rows:
        barriers.append({'module':row['module'],'source':parent['project_closure'][row['module']]['source'],
                         'permanent_object':row['transported_permanent_object'],'normal_receipt':row['normal_receipt'],
                         'old_identity':row['old_identity'],'status':row['status']})

    def global_reports(epoch,batch,bp,seal=None):
        spec=r.read(batch['global_inputs']);require(spec['protocol']==PROTOCOL and spec['family']==fp
                and spec['parent_context']==batch['parent_context'] and spec['baseline']==family['base_global_inputs'],'Historical G selector identity differs')
        require(spec['prefix_inputs']==inherited_prefix(unique,base_pin,batch['parent_context'],[r.expected[str(p)] for p in prior_managed],prior_referenced,[x['selected_object'] for x in catalog.values()]),'Inherited prefix input selector omits or re-pins a role')
        require(spec['batch_static']==batch['helpers']+[batch['whitelist']] and r.read(batch['whitelist'])==batch['owners'],'Static helper/whitelist selector differs')
        require(len(batch['helpers'])==len(batch['owners']) and {x['path'] for x in batch['helpers']}=={str(epoch/'helpers'/(owner+'.Owned.lean')) for owner in batch['owners']},'Helper ownership inventory differs')
        rows=unique(list(baseline)+spec['prefix_inputs']+spec['batch_static']+[batch['global_inputs'],family['base_global_inputs'],fp,bp])
        digest=hashlib.sha256(b''.join(json.dumps(x,sort_keys=True,separators=(',',':')).encode()+b'\n' for x in rows)).hexdigest()
        anchor_pin=pin(epoch/'state/GLOBAL_PRE.json');anchor=r.read(anchor_pin)
        require(anchor['formal_acceptance'] is False,'PRE anchor claims acceptance')
        for purpose in (('PRE','POST') if seal is not None else ('PRE',)):
            item=seal['global_'+purpose.lower()] if seal else anchor['snapshot'];report=r.read(item)
            require(report['protocol']==PROTOCOL and report['purpose']==purpose and report['family']==fp and report['batch']==bp
                    and report['global_inputs']==batch['global_inputs'] and report['global_validation_scope']=='batch_boundary'
                    and report['matched'] is True and report['mismatches']==[] and report['files_checked']==len(rows)
                    and report['bytes_read']==sum(x['bytes'] for x in rows) and report['actual_map_sha256']==digest,'Historical global boundary differs')
            if purpose=='PRE':require(anchor=={'snapshot':item,'formal_acceptance':False},'Historical PRE anchor transplant')
        for item in rows:r.check(item)
        global_manifests.append(batch['global_inputs'])
        return anchor['snapshot']

    def mode(epoch,batch,bp,pre,owner,kind,marker_pin,history,pending,parent_names):
        marker=r.read(marker_pin);attempt=Path(marker_pin['path']).parent
        require(marker_pin['path']==str(attempt/'PENDING.json') and attempt.parent==epoch/'steps'/owner/kind,'Wrong mode marker path')
        require(list(attempt.parent.iterdir())==[attempt],'Unknown extra accepted-epoch attempt')
        expected_names={'COMMAND.json','LOCAL_INPUTS.json','PROCESS_RETURN.json','RESULT.json','PENDING.json','output.log'}|({'normal.olean'} if kind=='normal' else set())
        require({p.name for p in attempt.iterdir()}==expected_names,'Unknown/missing accepted attempt sidefile')
        ident={'protocol':PROTOCOL,'family':fp,'batch':bp,'key':owner,'mode':kind,'global_validation_scope':'batch_boundary','batch_pre':pre,
               'environment_sha256':support.environment_sha(support.environment(epoch,family)),'argv':argv(epoch,owner,kind),
               'cwd':str(FAMILY/'project'),'timeout':family['wall_seconds'],'rss_bytes':family['rss_gib']*1024**3}
        require(ident['environment_sha256']==batch['environment_sha256'] and marker['identity']==ident,'Historical mode identity differs')
        require(marker['result']['path']==str(attempt/'RESULT.json'),'Transplanted result')
        result=r.read(marker['result']);require(result['command']['path']==str(attempt/'COMMAND.json'),'Transplanted command')
        command=r.read(result['command']);require(command['identity']==ident and command['actual_argv']==[str(attempt/'normal.olean') if x=='__NORMAL_OUTPUT__' else x for x in ident['argv']],'Historical actual argv differs')
        require(command['local_inputs']['path']==str(attempt/'LOCAL_INPUTS.json'),'Transplanted local inputs')
        local=r.read(command['local_inputs']);expected=[family['project_sources'][owner],next(x for x in batch['helpers'] if x['path']==str(epoch/'helpers'/(owner+'.Owned.lean'))),*family['code_pins'],*family['runtime'].values()]
        for record in history:
            expected += [record[k] for k in ('marker','result','command','log','local_inputs','process_return')]
            if record['object']:expected.append(record['object'])
        for name,record in pending.items():expected += [record['object'],{**record['object'],'path':str(FAMILY/'objects'/Path(name.replace('.','/')).with_suffix('.olean'))}]
        require(local==unique(expected),'Original per-mode D selector differs')
        for item in local:r.check(item)
        require(result['log']['path']==str(attempt/'output.log') and result['process_return']['path']==str(attempt/'PROCESS_RETURN.json'),'Transplanted log/return')
        r.check(result['log']);returned=r.read(result['process_return'])
        require(returned['identity']==ident and returned['protocol']==PROTOCOL and returned['command']==result['command'] and returned['log']==result['log']
                and returned['object']==result.get('object') and returned['formal_acceptance'] is False and returned['status']=='PROCESS_RETURNED_PENDING_LOCAL_AND_GLOBAL_CHECKS','Process return chain differs')
        require(set(returned['process_result'])==support.PROCESS_FIELDS and support.process_schema(returned['process_result'])==support.process_schema(result)
                and result['exit_code']==0 and result['stop_reason'] is None,'Historical process did not succeed')
        require(result['protocol']==PROTOCOL and result['global_validation_scope']=='batch_boundary' and result['formal_acceptance'] is False
                and 'postcheck' not in result and result['local_post']=={'inputs':command['local_inputs'],'all_local_files_matched':True,'file_count':len(local)},'Wrong D/mode scope')
        if kind=='normal':require(result['object']['path']==str(attempt/'normal.olean'),'Wrong permanent normal output');r.check(result['object'])
        else:require(result.get('object') is None,'Non-normal object')
        raw=Path(result['log']['path']).read_bytes();require(support.bytes_pin(result['log']['path'],raw)==result['log'],'Log changed while reading');text=raw.decode();require('sorryAx' not in text,'Forbidden stored proof')
        parsed=(old.controller.normal_validator(text,result) if kind=='normal' else {'stock_leanchecker_exit_zero':True} if kind=='stock-leanchecker' else old.evidence.validate_audit(text,[owner],set(parent_names)|set(batch['owners'][:batch['owners'].index(owner)+1]),family['external_modules']))
        require(marker=={'protocol':PROTOCOL,'status':'NORMAL_SUCCEEDED_PENDING_GLOBAL' if kind=='normal' else 'PROCESS_VALIDATED_PENDING_GLOBAL',
                'identity':ident,'result':marker['result'],'process_return':result['process_return'],'validated':parsed,'formal_acceptance':False,'batch_post':None,'P2_6_complete':False},'Pending success evidence differs')
        return {'owner':owner,'mode':kind,'marker':marker_pin,'result':marker['result'],'command':result['command'],'log':result['log'],
                'local_inputs':command['local_inputs'],'process_return':result['process_return'],'object':result.get('object'),'old_identity':ident}

    for index,name in enumerate(('first8','second8'),1):
        epoch=FAMILY/'batches'/name;bp=pin(epoch/'BATCH.json');batch=r.read(bp);sp=pin(epoch/'state/BATCH_ACCEPTED.json');seal=r.read(sp)
        if index==2:require(sp['sha256']==LAST_SEAL_SHA,'Wrong1520 seal root')
        require(batch['family']==fp and batch['parent_context']==previous and batch['epoch_index']==index
                and batch['accepted_before']==accepted and 1<=len(batch['owners'])<=8,'Historical epoch ancestry differs')
        remaining=[n for n in old_graph['topological_order'] if n not in catalog]
        require(batch['owners']==remaining[:len(batch['owners'])] and len(batch['owners'])==8,'Owner skip/repeat')
        require(seal['protocol']==PROTOCOL and seal['status']=='BATCH_ACCEPTED' and seal['formal_acceptance'] is True and seal['P2_6_complete'] is False
                and seal['family']==fp and seal['batch']==bp and seal['parent_context']==previous and seal['owners']==batch['owners'],'Unaccepted historical epoch')
        pre=global_reports(epoch,batch,bp,seal);history=[];pending={};parent_names=set(catalog)
        require(len(seal['pending_mode_receipts'])==24,'Missing/excess historical modes')
        for i,owner in enumerate(batch['owners']):
            for j,kind in enumerate(MODES):
                record=mode(epoch,batch,bp,pre,owner,kind,seal['pending_mode_receipts'][3*i+j],history,pending,parent_names);history.append(record)
                if kind=='normal':pending[owner]=record
            normal=pending[owner];obj={**normal['object'],'path':str(FAMILY/'objects'/Path(owner.replace('.','/')).with_suffix('.olean'))}
            catalog[owner]={'source':family['project_sources'][owner],'selected_object':obj,'origin':'accepted_family_batch_global_boundary_v1','normal_success_artifact':normal['object']};accepted.append(owner)
            cp=pin(epoch/'accepted-contexts'/(owner+'.json'));context=r.read(cp)
            require(context=={'protocol':PROTOCOL,'formal_acceptance':True,'P2_6_complete':False,'family':fp,'batch':bp,'batch_seal':sp,
                    'accepted_parent':previous,'epoch_parent':batch['parent_context'],'project_closure':dict(catalog),'native_artifacts':family['native_artifacts'],
                    'runtime':family['runtime'],'lean_path':family['lean_path'],'accepted_in_this_batch':batch['owners'][:i+1],
                    'accepted_since_family_base':list(accepted),'global_validation_scope':'batch_boundary','scope':'Exact atomic1..8-owner family batch; no global P2.6 claim.'},'Accepted context chain differs')
            previous=cp;contexts.append(cp);r.check(obj)
            barriers.append({'module':owner,'source':catalog[owner]['source'],'permanent_object':normal['object'],'normal_receipt':normal['marker'],
                             'old_identity':normal['old_identity'],'status':'accepted_normal'})
        delta=[]
        for record in history:
            delta += [record[k] for k in ('marker','result','command','log','local_inputs','process_return')]+r.read(record['local_inputs'])
            if record['object']:delta.append(record['object'])
        managed={epoch/'BATCH.json',epoch/'GLOBAL_INPUTS.json',epoch/'WHITELIST.json',*(Path(x['path']) for x in batch['helpers']),*(Path(x['path']) for x in contexts if Path(x['path']).parent==epoch/'accepted-contexts')}
        for record in history:
            for path in Path(record['command']['path']).parent.iterdir():delta.append(pin(path));managed.add(path)
        for path in (epoch/'state').iterdir():
            require(path.is_file() and path.suffix=='.json' and (path.name in ('BATCH_ACCEPTED.json','GLOBAL_PRE.json') or path.name.startswith(('PRE-','POST-','RESUME-'))),'Unknown old state sidefile')
            managed.add(path)
            if path.name!='BATCH_ACCEPTED.json':delta.append(pin(path))
        require(unique(delta)==seal['delta_inputs'],'Historical final D selector differs')
        for item in delta:r.check(item)
        require({p for p in epoch.rglob('*') if p.is_file()}==managed,'Unknown historical managed artifact')
        prior_managed.extend(managed)
        old_spec=r.read(batch['global_inputs'])
        prior_referenced.extend(old_spec['prefix_inputs']+old_spec['batch_static']+[old_spec['baseline']]+seal['delta_inputs']+batch['helpers'])
        all_history+=history
    require(previous==parent_pin and catalog==parent['project_closure'],'1520 catalog is not exact last sealed prefix')
    require(parent['native_artifacts']==family['native_artifacts'] and parent['runtime']==family['runtime'] and parent['lean_path']==family['lean_path'],'Parent runtime/native/search differs')

    anchor,anchor_pin=r.rooted(REV/'FAILED_TAIL_ANCHOR.json',FAILED_ANCHOR_SHA);epoch=FAMILY/'batches/third8';bp=pin(epoch/'BATCH.json');batch=r.read(bp)
    require(anchor['old_family']==fp and anchor['old_batch']==bp and anchor['old_graph']==old_graph_pin,'Failed-tail lineage differs')
    require(batch['parent_context']==parent_pin and batch['epoch_index']==3 and batch['accepted_before']==accepted,'Failed epoch parent differs')
    require(batch['owners']==[n for n in old_graph['topological_order'] if n not in catalog][:8] and batch['owners'][0]==FAILED,'Failed epoch order differs')
    pre=global_reports(epoch,batch,bp);require(anchor['global_pre_report']==pre and r.read(anchor['global_pre_anchor'])=={'snapshot':pre,'formal_acceptance':False},'Failed PRE differs')
    attempt=Path(anchor['attempt']);require(attempt.parent==epoch/'steps'/FAILED/'normal','Wrong failed attempt')
    require({p.name for p in attempt.iterdir()}=={'COMMAND.json','LOCAL_INPUTS.json','PROCESS_RETURN.json','RESULT.json','output.log'},'Failed/unknown extra artifact cannot be released')
    files=anchor['files'];require(set(files)=={p.name for p in attempt.iterdir()},'Failed anchor inventory differs')
    for name,item in files.items():require(item['path']==str(attempt/name),'Failed file transplant');r.check(item)
    result=r.read(files['RESULT.json']);command=r.read(files['COMMAND.json']);returned=r.read(files['PROCESS_RETURN.json']);local=r.read(files['LOCAL_INPUTS.json'])
    validate_failed_result(result);require(result['command']==files['COMMAND.json'] and result['process_return']==files['PROCESS_RETURN.json'] and result['log']==files['output.log'],'Failed result references differ')
    ident={'protocol':PROTOCOL,'family':fp,'batch':bp,'key':FAILED,'mode':'normal','global_validation_scope':'batch_boundary','batch_pre':pre,
           'environment_sha256':support.environment_sha(support.environment(epoch,family)),'argv':argv(epoch,FAILED,'normal'),'cwd':str(FAMILY/'project'),
           'timeout':family['wall_seconds'],'rss_bytes':family['rss_gib']*1024**3}
    require(command['identity']==returned['identity']==ident and ident['environment_sha256']==batch['environment_sha256'],'Failed exact identity differs')
    require(command['actual_argv']==[str(attempt/'normal.olean') if x=='__NORMAL_OUTPUT__' else x for x in ident['argv']]
            and command['local_inputs']==files['LOCAL_INPUTS.json'],'Failed actual argv/local selector differs')
    expected=unique([family['project_sources'][FAILED],next(x for x in batch['helpers'] if x['path']==str(epoch/'helpers'/(FAILED+'.Owned.lean'))),*family['code_pins'],*family['runtime'].values()])
    require(local==expected,'Failed local inputs include unknown changes')
    for item in local:r.check(item)
    require(set(returned['process_result'])==support.PROCESS_FIELDS and support.process_schema(returned['process_result'])==support.process_schema(result)
            and returned['command']==files['COMMAND.json'] and returned['log']==files['output.log'] and returned['object'] is None
            and returned['protocol']==PROTOCOL and returned['formal_acceptance'] is False and returned['status']=='PROCESS_RETURNED_PENDING_LOCAL_AND_GLOBAL_CHECKS','Failed durable return differs')
    require(result['local_post']=={'inputs':files['LOCAL_INPUTS.json'],'all_local_files_matched':True,'file_count':len(local)} and result['formal_acceptance'] is False
            and result['protocol']==PROTOCOL and result['global_validation_scope']=='batch_boundary' and 'postcheck' not in result,'Failed local status differs')
    log=Path(files['output.log']['path']).read_text();require('This simp argument is unused' in log and 'List.append_assoc' in log and 'sorryAx' not in log,'Not the known linter failure')
    managed={epoch/'BATCH.json',epoch/'GLOBAL_INPUTS.json',epoch/'WHITELIST.json',*(Path(x['path']) for x in batch['helpers']),Path(anchor['global_pre_anchor']['path']),Path(pre['path']),*(Path(x['path']) for x in files.values())}
    require({p for p in epoch.rglob('*') if p.is_file()}==managed and not list((epoch/'accepted-contexts').iterdir()),'Unsealed success/unknown data cannot be ignored')
    require(not (epoch/'state/INTEGRITY_FAILED.json').exists() and not (epoch/'state/BATCH_ACCEPTED.json').exists(),'Failed tail acquired acceptance/sticky')
    mcp=r.read(anchor['mcp_record']);require(mcp['status']['status']=='failed' and mcp['status']['exit_code']==1 and mcp['status']['ended_at'] is not None,'Failed task is not ended')
    require(len(barriers)==21 and sum(x['status']=='old_normal_forbidden' for x in barriers)==2,'Incomplete1520 normal barrier ledger')
    release={'module':FAILED,'status':'typed_failed_no_object_source_revision','old_family':fp,'old_batch':bp,'old_graph':old_graph_pin,
             'old_source':family['project_sources'][FAILED],'new_graph':graph_pin,'new_source':graph['entries'][FAILED]['source'],
             'revision_manifest':revision_pin,'failed_anchor':anchor_pin,'command':files['COMMAND.json'],'local_inputs':files['LOCAL_INPUTS.json'],
             'process_return':files['PROCESS_RETURN.json'],'result':files['RESULT.json'],'log':files['output.log'],'old_identity':ident,
             'exit_code':1,'stop_reason':None,'object':None}
    require(all(release['old_source'][k]==old_graph['entries'][FAILED]['source'][k] for k in ('bytes','sha256')),'Failed old source differs from original graph')
    roots=sorted(set(family['normal_search_roots']+[str(OLD_ROOT)]))
    unaccepted=set(graph['entries'])-set(catalog);found=set()
    for root in roots:
        require(Path(root).is_dir(),'Missing declared prior normal root')
        for path in Path(root).glob('**/steps/*/normal/*/COMMAND.json'):
            owner=path.parents[2].name
            if owner in unaccepted:found.add(str(path))
    require(found=={files['COMMAND.json']['path']},'Another unaccepted successful/failed/unknown normal blocks migration')
    require({str(p) for p in (FAMILY/'project').rglob('*') if p.is_file()}==set(family['project_files']),'Old source namespace changed')
    require({str(p) for p in (FAMILY/'objects').rglob('*') if p.is_file()}=={x['selected_object']['path'] for x in catalog.values()}|{x['path'] for x in family['native_artifacts']},'Old object/native namespace changed')
    for info in catalog.values():r.check(info['source']);r.check(info['selected_object'])
    for item in family['native_artifacts']:r.check(item)
    for row in graph['entries'].values():r.check(row['source'])
    r.check(helper_pin);r.check(pin(SUPPORT))
    preserve=[]
    external_roots=[Path(family['environment']['mathlib_root']),Path(family['environment']['sysroot'])]
    def shared(path):return any(Path(path).is_relative_to(root) for root in external_roots) or not Path(path).is_relative_to('/workspace')
    for item in r.expected.values():
        path=Path(item['path'])
        if not shared(path) and (path.suffix in ('.json','.jsonl','.log','.lean','.py','.md') or '/steps/' in str(path) or '/helpers/' in str(path)):
            preserve.append(item)
    for barrier in barriers:
        r.check(barrier['permanent_object']);preserve.append(barrier['permanent_object'])
        if barrier['normal_receipt']:r.check(barrier['normal_receipt']);preserve.append(barrier['normal_receipt'])
    remaining=[n for n in graph['topological_order'] if n not in catalog];require(len(remaining)==313 and remaining[0]==FAILED,'Wrong revision remaining order')
    old.controller.environment_inventory(stage)
    return {'schema':'p26_revision3_readonly1520_parent_v1','accepted_context':parent_pin,'graph':graph_pin,'project_closure':catalog,
            'native_artifacts':family['native_artifacts'],'runtime':family['runtime'],'environment':family['environment'],
            'lean_path_tail':family['lean_path'].split(':')[1:],'external_modules':family['external_modules'],
            'accepted_graph_modules':[n for n in graph['topological_order'] if n in catalog],'remaining_order':remaining,
            'normal_barriers':barriers,'evidence_pins':unique(preserve),'shared_external_pins':unique([x for x in r.expected.values() if shared(x['path'])]),
            'historical_global_manifests':unique([family['base_global_inputs']]+[r.read(pin(FAMILY/'batches'/n/'BATCH.json'))['global_inputs'] for n in ('first8','second8','third8')]),
            'historical_manifest_format':'first plainlist; epoch selectors with baseline/prefix_inputs/batch_static must be expanded, never treated as pin arrays',
            'provenance_roots':{'old_family':fp,'old_delivery':final_pin,'old_stage':family['provenance_roots']['old_stage'],'parent1520':parent_pin,'last_seal':pin(FAMILY/'batches/second8/state/BATCH_ACCEPTED.json'),'prior_graph':old_graph_pin,'revision_manifest':revision_pin,'failed_anchor':anchor_pin,'readonly_support':pin(SUPPORT)},
            'normal_search_roots':roots,'failed_releases':[release],'source_revision_manifest':revision_pin,'source_revision_qualified':True,
            'verified_parent_formal_acceptance':True,'formal_acceptance':False,'P2_6_complete':False,'provider_recovery_permitted':False,
            'original_full_snapshot_verified':False,'verified_historical_input_count':len(r.expected)}
