#!/usr/bin/env python3
"""Readonly incremental evidence: published1512 -> old1520 -> revision3 epochs.

Never executes Lean, a mode, seed, coldcollect, G or provider repair. Full-G
reports/selectors retain their original validation scope. Bulk inherited bytes
are references, explicitly not re-checksummed by this packager.
"""
import argparse
import hashlib
import io
import json
import math
from pathlib import Path
import re
import sys
import tarfile
import time
from types import ModuleType,SimpleNamespace
sys.dont_write_bytecode=True
TOOLS=Path(__file__).resolve().parent
OLD_ROOT=Path('/workspace/p26-cell06-family-20261128')
NEW_ROOT=Path('/workspace/p26-cell06-family-revision3-20261128')
OLD_FAMILY=OLD_ROOT/'families/main';NEW_FAMILY=NEW_ROOT/'families/main'
PUBLISHED=Path('/workspace/p26-cell06-family-first8-evidence-20261128')
OLD_PROTOCOL='family_batch_global_boundary_v1'
NEW_PROTOCOL='source_revision3_family_batch_global_boundary_v1'
SCHEMA='p26_cross_family_revision3_checkpoint_v1'
MODES=('normal','stock-leanchecker','full-owned')
PILOT='ImbalancedChen.P2OriginalSaving19Geometry06ScalableAllOriginalConstraintMinimaBlock006'
FIRST8=['ImbalancedChen.P2OriginalSaving19Geometry06ScalableActive8EnumerationBlock'+str(i).zfill(3) for i in range(1,9)]
SECOND_LAST='ImbalancedChen.P2OriginalSaving19Geometry06ScalableAllOriginalConstraintMinimaBlock005'
OLD_FAMILY_SHA='c172b52da388a8f068bafa925cfd9da8d8b1b47b270d93b3e9a157a17d1a522d'
OLD_BASE_SHA='397fa4294fc51aa8a5008b1be86e774aee53049a7b264a2d01ba666860466d94'
OLD_GRAPH_SHA='0c0930dc27e9ee532ac4a8c78afb2dfb5c9cf40a364076e50cddae7f4cf8dd02'
OLD_FINAL_SHA='f26363a19799e72deb1842e9befa3d204e8b603b262ecc08a132516bee86ec25'
SECOND_CONTEXT_SHA='e3ad37ec35b564bd32a4c6ec55d7a2bc9d16f7df86e7b96445f9f6634fea69f5'
SECOND_SEAL_SHA='3ada5a3f504af39ed98b3014a4443bbad849d92932c6834a23719e97fa4b3cdd'
NEW_FAMILY_SHA='edfbfb70ab75e23643eeb10a3d96ace499304bbe317d6918fc612fe8958337ea'
NEW_BASE_SHA='84ca1ad46ba5fb3afa80365698fa52308d22eca5fec8f0767eb2ec0fea13302f'
NEW_FINAL_SHA='3bd74a27045e61db4057b2cb3758bf6330ae505a69f3931928f57b445766da47'
SOURCE_LOCK_SHA='cd56193740f7759df91bea8f35a47426e490069853ac36cdad301f65a98b0842'
NEW_GRAPH_SHA='b072272b21689ae65097f2c14b553412c5650813a8a5fe3b7116b29363f10927'
REVISION_SHA='99182593d8a0021f5d7bc0d9a4d31a036f7187a510ecabcb6a1f053ee9284043'
FAILED_ANCHOR_SHA='4dfadfbd036075f8e46a1e7bbdb50856d1ecf20b1a741b405d11c0a126b6b2f1'
PUBLISHED_COMMIT='47fd1249c4653b6f8a16c218c852cc5eccd2eef7'
PUB_CAPSULE_SHA='651284f06d6a2eedc6037e8285bffe3046d14dfd85c2b851ffa6e161f9953ddd'
PUB_ARCHIVE_SHA='dcb26ba2e81fbe67f33c341ebb2f5ed6f35b06052a11bccc7da2cdc1d09d65b2'
PUB_CONTEXT_SHA='eb8421a493c63c9cd1ff30313d200bebff6eae7c1991c1339b6b0add1e5027a6'
PUB_SEAL_SHA='4cf65c59175aad25e6e266e56ea9df44cf60a7ae3139880638d0d01c44224592'
PROCESS_FIELDS={'exit_code','stop_reason','seconds','sampled_peak_tree_rss_bytes'}
MAX_ARCHIVE=90*1024**2


def require(ok,message):
    if not ok:raise RuntimeError(message)


def raw_pin(path,raw):return {'path':str(Path(path).absolute()),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}


def pin(path):
    digest=hashlib.sha256();size=0
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):digest.update(block);size+=len(block)
    return {'path':str(Path(path).absolute()),'bytes':size,'sha256':digest.hexdigest()}


def valid_pin(item):
    require(isinstance(item,dict) and set(item)=={'path','bytes','sha256'} and isinstance(item['path'],str) and Path(item['path']).is_absolute()
            and type(item['bytes']) is int and item['bytes']>=0 and isinstance(item['sha256'],str) and re.fullmatch('[0-9a-f]{64}',item['sha256']) is not None,'Malformed exact pin')
    return item


def unique(items):
    result={}
    for item in items:valid_pin(item);require(result.setdefault(item['path'],item)==item,'Conflicting original pin: '+item['path'])
    return [result[path] for path in sorted(result)]


def same_bytes(left,right):return all(left[key]==right[key] for key in ('bytes','sha256'))


class Readonly:
    """Actual checks for metadata/localD/payload; separate un-rehashed G refs."""
    def __init__(self):self.expected={};self.verified=set();self.cache={};self.texts={};self.byte_count=0;self.roles={}
    def expect(self,item,role='inherited-reference'):
        valid_pin(item);require(self.expected.setdefault(item['path'],item)==item,'Original pin/reference conflict')
        self.roles.setdefault(item['path'],set()).add(role);return item
    def _raw(self,item,role):
        self.expect(item,role);raw=Path(item['path']).read_bytes();require(raw_pin(item['path'],raw)==item,'Pinned bytes changed: '+item['path'])
        if item['path'] not in self.verified:self.verified.add(item['path']);self.byte_count+=item['bytes']
        return raw
    def check(self,item,role='localD-or-payload'):
        self.expect(item,role)
        if item['path'] not in self.verified:
            require(pin(item['path'])==item,'Actual checksum mismatch: '+item['path']);self.verified.add(item['path']);self.byte_count+=item['bytes']
        return item
    def read(self,item):
        self.expect(item,'metadata')
        if item['path'] not in self.cache:self.cache[item['path']]=json.loads(self._raw(item,'metadata'))
        return self.cache[item['path']]
    def text(self,item):
        self.expect(item,'mode-log')
        if item['path'] not in self.texts:self.texts[item['path']]=self._raw(item,'mode-log').decode()
        return self.texts[item['path']]
    def rooted(self,path,sha):
        raw=Path(path).read_bytes();item=raw_pin(path,raw);require(item['sha256']==sha,'External root SHA mismatch: '+str(path))
        self.expect(item,'external-root');self.cache[item['path']]=json.loads(raw)
        if item['path'] not in self.verified:self.verified.add(item['path']);self.byte_count+=item['bytes']
        return self.cache[item['path']],item
    def post_members(self,items):
        rows=unique(items)
        for item in rows:require(pin(item['path'])==item,'Archive input changed: '+item['path'])
        return {'files':len(rows),'bytes':sum(item['bytes'] for item in rows),'matched':True,'scope':'Archive members only; no full-G/bulk checksum repeated.'}


def process_schema(value):
    require(PROCESS_FIELDS<=set(value) and type(value['exit_code']) is int,'Malformed process status')
    require(value['stop_reason'] is None or value['stop_reason'] in ('aggregate_tree_rss_limit','disk_reserve_512_MiB','wall_timeout'),'Unknown stop reason')
    require(type(value['seconds']) in (int,float) and math.isfinite(value['seconds']) and value['seconds']>=0
            and type(value['sampled_peak_tree_rss_bytes']) is int and value['sampled_peak_tree_rss_bytes']>=0,'Invalid process timing/RSS')
    return {key:value[key] for key in PROCESS_FIELDS}


def owner_name(value):
    require(isinstance(value,str) and re.fullmatch(r'ImbalancedChen(?:\.[A-Za-z0-9_]+)+',value) is not None,'Unsafe owner name')
    return value


def next_owners(order,accepted,count):
    require(type(count) is int and 1<=count<=8 and len(order)==len(set(order)),'Invalid1..8 owner batch')
    remaining=[owner for owner in order if owner not in accepted];require(len(remaining)>=count,'No padded/repeated tail')
    return remaining[:count]


def env_for(epoch,family):
    sysroot=family['environment']['sysroot']
    return {'HOME':str(epoch/'home'),'TMPDIR':str(epoch/'tmp'),'LANG':'C.UTF-8','LC_ALL':'C.UTF-8','TZ':'UTC','LEAN_PATH':family['lean_path'],
            'LEAN_NUM_THREADS':'1','OMP_NUM_THREADS':'1','LEAN_SYSROOT':sysroot,'PATH':sysroot+'/bin:/usr/bin:/bin'}


def env_sha(env):return hashlib.sha256(json.dumps(env,sort_keys=True,separators=(',',':')).encode()).hexdigest()


def argv_for(epoch,family,owner,mode):
    root=Path(family['family_root']);flags=['--trust=0','-DwarningAsError=true','-j1',f'-M{family["rss_gib"]*1024}','-DmaxRecDepth=1000000','-DmaxHeartbeats=0']
    if mode=='normal':return [family['runtime']['lean']['path'],*flags,'-o','__NORMAL_OUTPUT__',str(root/'project'/Path(owner.replace('.','/')).with_suffix('.lean'))]
    if mode=='stock-leanchecker':return [family['runtime']['leanchecker']['path'],'--verbose',owner]
    require(mode=='full-owned','Unknown mode');return [family['runtime']['lean']['path'],*flags,str(epoch/'helpers'/(owner+'.Owned.lean'))]


def old_parsers(r):
    root=Path('/workspace/p26-cell06-source-candidate-20261128/runner')
    delivery,dp=r.rooted(root/'DELIVERY_MANIFEST.json','d14f188c6e011a5576db429e79378bb3bf9b1d8d080ff37584cbbb699008b462')
    known={item['path']:item for item in delivery['members']};saved={name:sys.modules.get(name) for name in ('evidence','templates','controller')};loaded={}
    try:
        for name in ('evidence','templates','controller'):
            item=known[str(root/(name+'.py'))];raw=r._raw(item,'audited-parser-source');module=ModuleType(name);module.__file__=item['path'];module.__cached__=None
            sys.modules[name]=module;exec(compile(raw,item['path'],'exec',dont_inherit=True),module.__dict__);loaded[name]=module
    finally:
        for name,previous in saved.items():
            if previous is None:sys.modules.pop(name,None)
            else:sys.modules[name]=previous
    return SimpleNamespace(**loaded,delivery=dp,code=[known[str(root/(name+'.py'))] for name in ('evidence','templates','controller')])


def exact_local(family,batch,epoch,owner,history,pending):
    helper=[item for item in batch['helpers'] if item['path']==str(epoch/'helpers'/(owner+'.Owned.lean'))];require(len(helper)==1,'Helper selector differs')
    rows=[family['project_sources'][owner],helper[0],*family['code_pins'],*family['runtime'].values()]
    for record in history:
        rows += [record[key] for key in ('marker','result','command','log','local_inputs','process_return')]
        if record['object']:rows.append(record['object'])
    for owner,record in pending.items():rows += [record['object'],{**record['object'],'path':str(Path(family['family_root'])/'objects'/Path(owner.replace('.','/')).with_suffix('.olean'))}]
    return unique(rows)


def attempt(r,old,family,fp,batch,bp,epoch,owner,mode,directory,selected,history,pending,parent,delta):
    protocol=family['protocol'];require(protocol in (OLD_PROTOCOL,NEW_PROTOCOL),'Unsupported actual family protocol')
    require(directory.parent==epoch/'steps'/owner/mode and directory.is_dir() and not directory.is_symlink(),'Mode directory transplant')
    result_pin=r.read(selected)['result'] if selected else delta[str(directory/'RESULT.json')]
    require(result_pin['path']==str(directory/'RESULT.json') and (directory/'COMMAND.json').is_file() and (directory/'RESULT.json').is_file(),'Unknown COMMAND/RESULT; no recovery')
    result=r.read(result_pin);command=r.read(result['command']);returned=r.read(result['process_return'])
    require(result['command']['path']==str(directory/'COMMAND.json') and result['process_return']['path']==str(directory/'PROCESS_RETURN.json')
            and result['log']['path']==str(directory/'output.log') and command['local_inputs']['path']==str(directory/'LOCAL_INPUTS.json'),'Exact attempt file transplant')
    ident={'protocol':protocol,'family':fp,'batch':bp,'key':owner,'mode':mode,'global_validation_scope':'batch_boundary','batch_pre':batch['_pre']}
    ident.update({'environment_sha256':batch['environment_sha256'],'argv':argv_for(epoch,family,owner,mode),
        'cwd':str(Path(family['family_root'])/'project'),'timeout':family['wall_seconds'],'rss_bytes':family['rss_gib']*1024**3})
    require(command['identity']==returned['identity']==ident,'Wrong protocol/family/key/mode/argv/env')
    require(command['actual_argv']==[str(directory/'normal.olean') if value=='__NORMAL_OUTPUT__' else value for value in ident['argv']],'Actual argv differs')
    local=r.read(command['local_inputs']);require(local==exact_local(family,batch,epoch,owner,history,pending),'Original exactD/prefix selector differs')
    for item in local:r.check(item)
    require(returned['protocol']==protocol and returned['command']==result['command'] and returned['log']==result['log'] and returned['object']==result.get('object')
            and returned['formal_acceptance'] is False and returned['status']=='PROCESS_RETURNED_PENDING_LOCAL_AND_GLOBAL_CHECKS','Durable return chain differs')
    require(set(returned['process_result'])==PROCESS_FIELDS and process_schema(returned['process_result'])==process_schema(result),'Typed return/process fields differ')
    require(result['protocol']==protocol and result['formal_acceptance'] is False and result['global_validation_scope']=='batch_boundary' and 'postcheck' not in result
            and result['local_post']=={'inputs':command['local_inputs'],'all_local_files_matched':True,'file_count':len(local)},'Mode claims false global/formal/local scope')
    if result.get('object'):require(mode=='normal' and result['object']['path']==str(directory/'normal.olean'),'Normal object transplant');r.check(result['object'])
    text=r.text(result['log']);successful=result['exit_code']==0 and result['stop_reason'] is None
    names={'COMMAND.json','LOCAL_INPUTS.json','PROCESS_RETURN.json','RESULT.json','output.log'}|({'normal.olean'} if result.get('object') else set())
    if successful:
        require(selected is not None and selected['path']==str(directory/'PENDING.json'),'Unsealed/repeated successful mode')
        require('sorryAx' not in text,'Forbidden sorryAx')
        if mode=='normal':require(result.get('object') is not None,'No permanent normal artifact');validated=old.controller.normal_validator(text,result)
        elif mode=='stock-leanchecker':validated={'stock_leanchecker_exit_zero':True}
        else:validated=old.evidence.validate_audit(text,[owner],set(parent)|set(batch['owners'][:batch['owners'].index(owner)+1]),family['external_modules'])
        marker={'protocol':protocol,'status':'NORMAL_SUCCEEDED_PENDING_GLOBAL' if mode=='normal' else 'PROCESS_VALIDATED_PENDING_GLOBAL','identity':ident,
            'result':result_pin,'process_return':result['process_return'],'validated':validated,'formal_acceptance':False,'batch_post':None,'P2_6_complete':False}
        require(r.read(selected)==marker,'Raw canonical/shared/type/body/import validation changed');names.add('PENDING.json')
    else:require(selected is None and not (directory/'PENDING.json').exists(),'Failure has success marker');validated=None
    require({path.name for path in directory.iterdir()}==names and all(path.is_file() and not path.is_symlink() for path in directory.iterdir()),'Unknown/missing mode artifact')
    return {'owner':owner,'mode':mode,'marker':selected,'result':result_pin,'command':result['command'],'process_return':result['process_return'],
        'log':result['log'],'local_inputs':command['local_inputs'],'object':result.get('object'),'validated':validated,'process':result,'successful':successful,'epoch':epoch.name,'protocol':protocol}


def digest_map(rows):return hashlib.sha256(b''.join(json.dumps(item,sort_keys=True,separators=(',',':')).encode()+b'\n' for item in rows)).hexdigest()


def family_profile(r,path,family_sha,base_sha,graph_sha):
    family,fp=r.rooted(path/'FAMILY.json',family_sha);base,base_pin=r.rooted(path/'BASE_CONTEXT.json',base_sha)
    require(family['family_root']==str(path) and family['base_context']==base_pin and base['project_closure']==family['base_catalog']
            and base['verified_parent_formal_acceptance'] is True and base['formal_acceptance'] is False,'Family/base transport differs')
    graph=r.read(family['graph']);require(family['graph']['sha256']==graph_sha and len(graph['entries'])==334,'Wrong fixed source graph')
    return {'family':family,'pin':fp,'base':base,'base_pin':base_pin,'graph':graph,'baseline':r.read(family['base_global_inputs']),'path':path}


def context_chain(r,profile,current_pin):
    rows=[];cursor=current_pin;base=profile['base_pin'];family=profile['pin'];root=profile['path']
    while cursor!=base:
        value=r.read(cursor);require(value['family']==family and value['protocol']==profile['family']['protocol'] and value['formal_acceptance'] is True
            and value['P2_6_complete'] is False and value['global_validation_scope']=='batch_boundary','Unaccepted/cross-family context')
        epoch=Path(value['batch']['path']).parent
        require(epoch.parent==root/'batches' and value['batch']['path']==str(epoch/'BATCH.json')
            and cursor['path']==str(epoch/'accepted-contexts'/(owner_name(value['accepted_in_this_batch'][-1])+'.json')),'Context namespace transplant')
        rows.append((cursor,value));cursor=value['accepted_parent'];require(len(rows)<=329,'Context cycle/excess')
    groups=[]
    for cp,value in reversed(rows):
        epoch=Path(value['batch']['path']).parent
        if not groups or groups[-1]['path']!=epoch:groups.append({'path':epoch,'batch':value['batch'],'seal':value['batch_seal'],'contexts':[]})
        require(groups[-1]['batch']==value['batch'] and groups[-1]['seal']==value['batch_seal'],'Contract changes inside atomic epoch')
        groups[-1]['contexts'].append((cp,value))
    return groups


def verify_family(r,old,profile,current_pin,allowed_unsealed=()):
    family=profile['family'];fp=profile['pin'];root=profile['path'];groups=context_chain(r,profile,current_pin)
    require(groups,'No successful endpoint');expected_dirs={group['path'] for group in groups}|set(allowed_unsealed)
    require({path for path in (root/'batches').iterdir()}==expected_dirs,'Active/unsealed/unknown epoch exists')
    catalog=dict(family['base_catalog']);previous=profile['base_pin'];accepted=[];prefix=[profile['base_pin']];records=[];all_attempts=[];managed={};metrics=[]
    for index,group in enumerate(groups,1):
        ep=group['path'];batch=dict(r.read(group['batch']));seal=r.read(group['seal']);protocol=family['protocol'];delta={item['path']:item for item in unique(seal['delta_inputs'])}
        require(not (ep/'state/INTEGRITY_FAILED.json').exists() and not (root/'state/INTEGRITY_FAILED.json').exists(),'Sticky provider failure')
        require(batch['protocol']==protocol and batch['family']==fp and batch['parent_context']==previous and batch['epoch_index']==index
            and batch['concurrency']==1 and batch['failure_policy']=='atomic_all_declared_owners' and batch['normal_success_recompile_allowed'] is False,'Epoch parent/policy differs')
        owners=batch['owners'];require(owners==next_owners(profile['graph']['topological_order'],set(catalog),len(owners)) and batch['accepted_before']==accepted,'Epoch owner skip/repeat')
        if protocol==NEW_PROTOCOL and index==1:require(owners==[PILOT],'Revision3 initial B1 gate violated')
        require(seal['protocol']==protocol and seal['status']=='BATCH_ACCEPTED' and seal['formal_acceptance'] is True and seal['P2_6_complete'] is False
            and seal['global_validation_scope']=='batch_boundary' and seal['family']==fp and seal['batch']==group['batch'] and seal['parent_context']==previous
            and seal['owners']==owners and len(seal['pending_mode_receipts'])==3*len(owners),'Accepted seal identity/scope differs')
        require(len(group['contexts'])==len(owners) and env_sha(env_for(ep,family))==batch['environment_sha256'],'Incomplete contexts or changed final environment')
        spec=r.read(batch['global_inputs']);require(spec['protocol']==protocol and spec['family']==fp and spec['parent_context']==previous and spec['baseline']==family['base_global_inputs'],'G selector transplant')
        require(r.read(batch['whitelist'])==owners and spec['batch_static']==batch['helpers']+[batch['whitelist']] and
            {item['path'] for item in batch['helpers']}=={str(ep/'helpers'/(owner+'.Owned.lean')) for owner in owners},'Static import/helper/whitelist selector differs')
        require(spec['prefix_inputs']==unique(prefix+[info['selected_object'] for info in catalog.values()]),'Original inherited prefix differs')
        g_rows=unique(list(profile['baseline'])+spec['prefix_inputs']+spec['batch_static']+[batch['global_inputs'],family['base_global_inputs'],fp,group['batch']])
        g_digest=digest_map(g_rows)
        for item in g_rows:r.expect(item,'recorded-G-reference-not-rehashed')
        reports={}
        for purpose in ('PRE','POST'):
            report=r.read(seal['global_'+purpose.lower()]);reports[purpose]=report
            require(report['protocol']==protocol and report['purpose']==purpose and report['family']==fp and report['batch']==group['batch'] and report['global_inputs']==batch['global_inputs']
                and report['matched'] is True and report['mismatches']==[] and report['global_validation_scope']=='batch_boundary' and report['files_checked']==len(g_rows)
                and report['bytes_read']==sum(item['bytes'] for item in g_rows) and report['actual_map_sha256']==g_digest,'Original complete G report differs')
        anchor=delta[str(ep/'state/GLOBAL_PRE.json')];require(r.read(anchor)=={'snapshot':seal['global_pre'],'formal_acceptance':False},'Original PRE anchor differs')
        batch['_pre']=seal['global_pre'];parent=dict(catalog);history=[];pending={};attempts=[]
        for owner_index,owner in enumerate(owners):
            for mode_index,mode in enumerate(MODES):
                selected=seal['pending_mode_receipts'][3*owner_index+mode_index];selected_dir=Path(selected['path']).parent
                require(selected['path']==str(selected_dir/'PENDING.json') and selected_dir.parent==ep/'steps'/owner/mode,'Selected marker transplant')
                directories=sorted((ep/'steps'/owner/mode).iterdir());require(selected_dir in directories,'Selected successful attempt absent')
                successes=[]
                for directory in directories:
                    record=attempt(r,old,family,fp,batch,group['batch'],ep,owner,mode,directory,selected if directory==selected_dir else None,history,pending,parent,delta)
                    attempts.append(record)
                    if record['successful']:successes.append(record)
                require(len(successes)==1,'Missing/repeated successful mode');history.append(successes[0])
                if mode=='normal':pending[owner]=successes[0]
        require([item['marker'] for item in history]==seal['pending_mode_receipts'],'Original successful receipt order differs')
        epoch_parent=previous
        for owner_index,(cp,value) in enumerate(group['contexts']):
            owner=owners[owner_index];normal=pending[owner]['object'];canonical={**normal,'path':str(root/'objects'/Path(owner.replace('.','/')).with_suffix('.olean'))}
            origin='accepted_family_batch_global_boundary_v1' if protocol==OLD_PROTOCOL else 'accepted_source_revision3_family_batch_global_boundary_v1'
            catalog[owner]={'source':family['project_sources'][owner],'selected_object':canonical,'origin':origin,'normal_success_artifact':normal};accepted.append(owner)
            expected={'protocol':protocol,'formal_acceptance':True,'P2_6_complete':False,'family':fp,'batch':group['batch'],'batch_seal':group['seal'],'accepted_parent':previous,
                'epoch_parent':epoch_parent,'project_closure':dict(catalog),'native_artifacts':family['native_artifacts'],'runtime':family['runtime'],'lean_path':family['lean_path'],
                'accepted_in_this_batch':owners[:owner_index+1],'accepted_since_family_base':list(accepted),'global_validation_scope':'batch_boundary','scope':'Exact atomic1..8-owner family batch; no global P2.6 claim.'}
            require(value==expected,'Exact context/catalog/source/object differs');previous=cp
        expected_delta=[];files={ep/'BATCH.json',ep/'GLOBAL_INPUTS.json',ep/'WHITELIST.json',*(Path(cp['path']) for cp,_ in group['contexts']),*(Path(item['path']) for item in batch['helpers'])}
        for record in history:
            expected_delta += [record[key] for key in ('marker','result','command','log','local_inputs','process_return')]+r.read(record['local_inputs'])
            if record['object']:expected_delta.append(record['object'])
        for record in attempts:
            for path in Path(record['result']['path']).parent.iterdir():files.add(path);expected_delta.append(delta[str(path)])
        for path in (ep/'state').iterdir():
            require(path.is_file() and not path.is_symlink() and path.suffix=='.json' and (path.name in ('GLOBAL_PRE.json','BATCH_ACCEPTED.json') or path.name.startswith(('PRE-','POST-','RESUME-'))),'Unknown state file')
            files.add(path)
            if path.name!='BATCH_ACCEPTED.json':expected_delta.append(delta[str(path)])
        require(unique(expected_delta)==seal['delta_inputs'] and {path for path in ep.rglob('*') if path.is_file()}==files,'Complete original D/managed namespace differs')
        for item in seal['delta_inputs']:r.check(item,'sealed-D')
        managed[ep]=files;records+=history;all_attempts+=attempts
        prefix += [cp for cp,_ in group['contexts']]+[group['batch'],group['seal'],batch['global_inputs'],batch['whitelist'],anchor]+seal['delta_inputs']+spec['prefix_inputs']+spec['batch_static']+[spec['baseline']]+batch['helpers']
        prefix += [seal['global_pre'],seal['global_post']]+[record[key] for record in history for key in ('marker','result')]
        metrics.append({'family_protocol':protocol,'epoch':ep.name,'index':index,'owners':owners,'last_context':previous,'seal':group['seal'],
            'global_pre':reports['PRE'],'global_post':reports['POST'],'canonical':sum(item['validated']['canonical_count'] for item in history if item['mode']=='full-owned'),
            'shared':sum(item['validated']['shared_occurrences'] for item in history if item['mode']=='full-owned'),'successful_modes':len(history),'failed_attempts':len(attempts)-len(history)})
    require(previous==current_pin,'Endpoint is not a whole last epoch')
    return {'profile':profile,'groups':groups,'catalog':catalog,'accepted':accepted,'records':records,'attempts':all_attempts,'managed':managed,'metrics':metrics,'current':current_pin,'expected_dirs':expected_dirs}

def module_transport(logical,physical,old_root,new_root):
    require(set(logical)==set(physical),'Transport lost/added an accepted module')
    rows=[]
    for owner in sorted(logical):
        before,after=logical[owner],physical[owner]
        require(before['source']['path']==str(old_root/'project'/Path(owner.replace('.','/')).with_suffix('.lean'))
            and before['selected_object']['path']==str(old_root/'objects'/Path(owner.replace('.','/')).with_suffix('.olean')),'Logical accepted namespace changed')
        require(same_bytes(before['source'],after['source']) and same_bytes(before['selected_object'],after['selected_object']),'Accepted source/object bytes changed during migration')
        require(after['source']['path']==str(new_root/'project'/Path(owner.replace('.','/')).with_suffix('.lean'))
            and after['selected_object']['path']==str(new_root/'objects'/Path(owner.replace('.','/')).with_suffix('.olean')),'Incomplete/new transport namespace selection')
        rows.append({'module':owner,'logical_source':before['source'],'physical_source':after['source'],'logical_object':before['selected_object'],
            'physical_object':after['selected_object'],'bytes_identical':True,'current_bulk_checksum_repeated':False})
    return rows


def evidence_transport(expected,rows,new_root):
    by_source={};destinations=set()
    for row in rows:
        require(row['identity_preserved'] is True and same_bytes(row['logical'],row['physical']),'Historical evidence body/identity edited')
        valid_pin(row['logical']);valid_pin(row['physical'])
        require(row['logical']['path'] not in by_source and row['physical']['path'] not in destinations
            and Path(row['physical']['path']).parent==new_root/'evidence','Duplicate/foreign evidence transport mapping')
        by_source[row['logical']['path']]=row['logical'];destinations.add(row['physical']['path'])
    require(unique(by_source.values())==unique(expected),'Evidence logical↔physical map is incomplete')
    return rows


def validate_revision_patch(r,old_graph,new_graph,report):
    require(report['changed_modules']==4 and report['unchanged_graph_sources']==330 and report['accepted1520_sources_changed']==0
        and report['same_order_imports_declarations_types_and_original_data'] is True and report['formal_acceptance'] is False and report['P2_6_complete'] is False,'Source revision scope changed')
    require(old_graph['topological_order']==new_graph['topological_order'] and set(old_graph['entries'])==set(new_graph['entries']),'Revision changed owner topology')
    changes={row['module']:row for row in report['changes']}
    expected={PILOT,'ImbalancedChen.P2OriginalSaving19Geometry06ScalableVerticesBlock002','ImbalancedChen.P2OriginalSaving19Geometry06ScalableVertexValuesBlock004','ImbalancedChen.P2OriginalSaving19Geometry06ScalableSimplicesBlock014'}
    require(set(changes)==expected and report['changes']==new_graph['source_revision_changes'],'Revision changed owner whitelist')
    for owner,row in new_graph['entries'].items():
        before=old_graph['entries'][owner]
        if owner not in changes:require(row==before,'Revision changed a non-whitelisted source/object')
        else:
            change=changes[owner];require(change['old_source']==before['source'] and change['new_source']==row['source'] and row['imports']==before['imports'] and row['kind']==before['kind'],'Revision source/import selection differs')
            original=r._raw(change['old_source'],'source-revision-payload');replacement=r._raw(change['new_source'],'source-revision-payload')
            needle=f'  have hinput : blockChars ++ tail = {change["singleton"]} ++ (tail) := by simp only [blockChars, List.append_assoc]'.encode()
            require(original.count(needle)==1 and len(original)-len(replacement)==19 and original.replace(needle,needle.replace(b', List.append_assoc',b''),1)==replacement,'Revision is not exact singleton hinput deletion')
    return list(changes.values())


def failed_tail(r,old,old_profile,old_result,new_profile,cert):
    family=old_profile['family'];new_family=new_profile['family'];releases=cert['failed_releases']
    require(len(releases)==1 and releases==new_family['failed_releases']==r.read(new_family['failed_releases_manifest']),'Failed release class/inventory differs')
    release=releases[0];require(release['module']==PILOT and release['status']=='typed_failed_no_object_source_revision'
        and type(release['exit_code']) is int and release['exit_code']==1 and release['stop_reason'] is None and release['object'] is None,'Not the exact typed failed exit1/no-object release')
    require(release['old_family']==old_profile['pin'] and release['old_graph']==family['graph'] and release['new_graph']==new_family['graph']
        and release['revision_manifest']==new_family['source_revision_manifest'] and release['failed_anchor']['sha256']==FAILED_ANCHOR_SHA,'Failed release roots differ')
    anchor=r.read(release['failed_anchor']);batch=r.read(release['old_batch']);epoch=Path(release['old_batch']['path']).parent;directory=Path(release['command']['path']).parent
    require(epoch==old_profile['path']/'batches/third8' and directory.parent==epoch/'steps'/PILOT/'normal' and str(directory)==anchor['attempt'],'Failed release attempt namespace differs')
    require(anchor['old_family']==release['old_family'] and anchor['old_batch']==release['old_batch'] and anchor['old_graph']==release['old_graph']
        and anchor['expected_exit_code']==1 and type(anchor['expected_exit_code']) is int and anchor['expected_stop_reason'] is None and anchor['expected_object'] is None
        and anchor['PENDING_permitted'] is False and anchor['successful_modes']==0 and anchor['formal_acceptance'] is False and anchor['P2_6_complete'] is False,'Failed anchor qualification differs')
    names={'command':'COMMAND.json','local_inputs':'LOCAL_INPUTS.json','process_return':'PROCESS_RETURN.json','result':'RESULT.json','log':'output.log'}
    require(set(anchor['files'])==set(names.values()),'Failed files selector differs')
    for key,name in names.items():require(release[key]==anchor['files'][name] and release[key]['path']==str(directory/name),'Failed tuple sidefile transplant')
    require(batch['protocol']==OLD_PROTOCOL and batch['family']==old_profile['pin'] and batch['parent_context']==old_result['current'] and batch['owners'][0]==PILOT,'Failed parent/owner identity differs')
    require(release['old_source']==family['project_sources'][PILOT] and same_bytes(release['old_source'],old_profile['graph']['entries'][PILOT]['source'])
        and release['new_source']==new_profile['graph']['entries'][PILOT]['source'],'Failed old/new source mapping differs')
    require(r.read(anchor['global_pre_anchor'])=={'snapshot':anchor['global_pre_report'],'formal_acceptance':False},'Failed PRE anchor differs')
    pre=r.read(anchor['global_pre_report']);spec=r.read(batch['global_inputs'])
    require(spec['family']==old_profile['pin'] and spec['parent_context']==old_result['current'] and spec['baseline']==family['base_global_inputs'],'Failed selector roots differ')
    g_rows=unique(list(old_profile['baseline'])+spec['prefix_inputs']+spec['batch_static']+[batch['global_inputs'],family['base_global_inputs'],old_profile['pin'],release['old_batch']])
    require(pre['protocol']==OLD_PROTOCOL and pre['purpose']=='PRE' and pre['family']==old_profile['pin'] and pre['batch']==release['old_batch'] and pre['global_inputs']==batch['global_inputs']
        and pre['matched'] is True and pre['mismatches']==[] and pre['files_checked']==len(g_rows) and pre['bytes_read']==sum(item['bytes'] for item in g_rows)
        and pre['actual_map_sha256']==digest_map(g_rows),'Recorded failed PRE does not cover original selector')
    for item in g_rows:r.expect(item,'old-failed-PRE-reference-not-rehashed')
    batch=dict(batch);batch['_pre']=anchor['global_pre_report'];delta={item['path']:item for item in anchor['files'].values()}
    record=attempt(r,old,family,old_profile['pin'],batch,release['old_batch'],epoch,PILOT,'normal',directory,None,[],{},old_result['catalog'],delta)
    require(not record['successful'] and record['process']['exit_code']==1 and record['process']['stop_reason'] is None and record['object'] is None
        and r.read(release['command'])['identity']==release['old_identity'],'Known failure was silently reclassified')
    log=r.text(release['log']);require('List.append_assoc' in log and 'unusedSimpArgs' in log,'Failure is not pinned lint class')
    require({path for path in (epoch/'steps').rglob('*')}=={epoch/'steps'/PILOT,epoch/'steps'/PILOT/'normal',directory,*[directory/name for name in names.values()]}
        and all(not path.is_symlink() for path in (epoch/'steps').rglob('*')),'Unknown failed mode/directory/object')
    canonical=old_profile['path']/'objects'/Path(PILOT.replace('.','/')).with_suffix('.olean')
    require(not canonical.exists() and not canonical.is_symlink() and not (epoch/'state/BATCH_ACCEPTED.json').exists() and not list((epoch/'state').glob('POST-*'))
        and not (epoch/'state/INTEGRITY_FAILED.json').exists(),'Failed owner has object/success/POST/sticky')
    files={Path(item['path']) for item in anchor['files'].values()}|{Path(anchor['global_pre_anchor']['path']),Path(anchor['global_pre_report']['path']),epoch/'BATCH.json',epoch/'GLOBAL_INPUTS.json',epoch/'WHITELIST.json',*(Path(item['path']) for item in batch['helpers'])}
    require({path for path in epoch.rglob('*') if path.is_file()}==files,'Unknown failed managed evidence')
    r.read(batch['whitelist']);r.read(anchor['mcp_record'])
    for item in batch['helpers']:r.check(item,'failed-prepared-helper')
    return {'release':release,'anchor':anchor,'record':record,'files':files,'epoch':epoch}


def bridge(r,old_profile,old_result,new_profile):
    family=new_profile['family'];base=new_profile['base'];cert=r.read(family['certificate']);transport=r.read(family['transport'])
    require(len(old_result['catalog'])==1520 and base['original_accepted_context']==old_result['current'] and cert['accepted_context']==old_result['current']
        and base['certificate']==family['certificate'] and cert['verified_parent_formal_acceptance'] is True and cert['formal_acceptance'] is False
        and cert['source_revision_qualified'] is True and family['source_revision_qualified'] is True,'New family lacks qualified same-byte1520 provenance')
    require(cert['project_closure']==old_result['catalog'] and family['runtime']==old_profile['family']['runtime']
        and family['lean_path'].split(':')[1:]==old_profile['family']['lean_path'].split(':')[1:],'Parent logical catalog/runtime/search changed')
    modules=module_transport(cert['project_closure'],base['project_closure'],old_profile['path'],new_profile['path'])
    old_native=old_profile['family']['native_artifacts'];new_native=family['native_artifacts'];require(len(old_native)==len(new_native)==555,'Incomplete native selection')
    expected_native=[{**item,'path':str(new_profile['path']/'objects'/Path(item['path']).relative_to(old_profile['path']/'objects'))} for item in old_native]
    require(new_native==expected_native and base['native_artifacts']==new_native,'Native logical↔physical map changed')
    require(transport['protocol']==NEW_PROTOCOL and transport['parent_context']==old_result['current'] and transport['same_source_graph']==family['graph']
        and transport['original_identity_retained'] is True,'Evidence transport contract changed')
    rows=evidence_transport(cert['evidence_pins'],transport['rows'],new_profile['path'])
    for row in rows:r.expect(row['logical'],'inherited-logical-evidence');r.expect(row['physical'],'inherited-physical-copy-not-rehashed')
    barriers=r.read(family['normal_barriers_manifest']);require(barriers==family['normal_barriers'] and len(barriers)==21
        and sum(item['status']=='old_normal_forbidden' for item in barriers)==2 and sum(item['status']=='accepted_normal' for item in barriers)==19,'No-normal barrier ledger changed')
    cert_barriers={item['module']:item for item in cert['normal_barriers']};by_logical={row['logical']['path']:row for row in rows}
    for item in barriers:
        original=cert_barriers[item['module']];require({key:value for key,value in item.items() if key!='transported_permanent_object'}==original,'Old normal identity/receipt changed')
        physical=item['transported_permanent_object']
        if item['status']=='accepted_normal':require(by_logical[original['permanent_object']['path']]['physical']==physical,'Permanent normal transport alias changed')
        else:require(physical==base['project_closure'][item['module']]['selected_object'] and item['normal_receipt'] is None,'Data forbidden record fakes a normal')
    report=r.read(family['source_revision_manifest']);require(family['source_revision_manifest']['sha256']==REVISION_SHA and cert['source_revision_manifest']==family['source_revision_manifest'],'Wrong exact4-source revision')
    require(report['parent']==old_result['current'] and report['prior_graph']==old_profile['family']['graph'] and report['new_graph']==family['graph'],'Source revision parent/graph roots differ')
    changes=validate_revision_patch(r,old_profile['graph'],new_profile['graph'],report)
    require(not {row['module'] for row in changes}&set(old_result['catalog']),'Revision modified an accepted owner')
    return {'certificate':cert,'transport':transport,'module_map':modules,'native_map':[{'logical':old,'physical':new,'bytes_identical':True,'current_bulk_checksum_repeated':False} for old,new in zip(old_native,new_native)],
        'evidence_map':rows,'revision':report,'changes':changes}


def controls(r):
    old_final,old_pin=r.rooted(OLD_ROOT/'DELIVERY_MANIFEST.json',OLD_FINAL_SHA);new_final,new_pin=r.rooted(NEW_ROOT/'DELIVERY_MANIFEST.json',NEW_FINAL_SHA)
    for final in (old_final,new_final):
        require(final['formal_acceptance'] is False and final['P2_6_complete'] is False,'Candidate control file claims proof credit')
        for item in final['members']:r.check(item,'frozen-control')
        host=r.read(final['host_report']);require(host['failures']==host['errors']==0,'Control fixture report failed')
        r.read(final['parent_delivery']);r.read(final.get('tested_source_lock',final['host_report']))
    lock,lp=r.rooted(NEW_ROOT/'SOURCE_LOCK.json',SOURCE_LOCK_SHA)
    require(lock['controller']==new_final['controller'] and new_final['source_lock']==lp,'Source-only control lock changed')
    for item in [lock['controller'],*lock['modules'].values()]:r.check(item,'source-only-runtime')
    return {'old':old_final,'old_pin':old_pin,'new':new_final,'new_pin':new_pin,'source_lock':lock,'source_lock_pin':lp}



def inspect_future_metadata(r,profile,path,sha,current_pin,current,index):
    require(path is not None and sha is not None,'Future exclusion requires exact path/SHA')
    path=Path(path).absolute();epoch=path.parent;root=profile['path']
    require(path==epoch/'BATCH.json' and epoch.parent==root/'batches' and epoch.is_dir() and not epoch.is_symlink(),'Excluded future batch namespace differs')
    value,item=r.rooted(path,sha);owners=value['owners'];family=profile['family']
    require(value['protocol']==family['protocol']==NEW_PROTOCOL and value['family']==profile['pin'] and value['parent_context']==current_pin
        and value['epoch_index']==index+1 and value['accepted_before']==current['accepted_since_family_base'],'Excluded future family/parent/index differs')
    require(owners==next_owners(profile['graph']['topological_order'],set(current['project_closure']),len(owners)),'Excluded future owner order differs')
    require(value['concurrency']==1 and value['failure_policy']=='atomic_all_declared_owners' and value['normal_success_recompile_allowed'] is False
        and value['global_validation_scope']=='batch_boundary' and value['formal_acceptance'] is False and value['P2_6_complete'] is False
        and env_sha(env_for(epoch,family))==value['environment_sha256'],'Excluded future policy/environment differs')
    require(r.read(value['whitelist'])==owners and value['whitelist']['path']==str(epoch/'WHITELIST.json'),'Excluded future whitelist differs')
    require({item['path'] for item in value['helpers']}=={str(epoch/'helpers'/(owner+'.Owned.lean')) for owner in owners}
        and value['global_inputs']['path']==str(epoch/'GLOBAL_INPUTS.json'),'Excluded future static selector differs')
    # Never open future helper/selector/attempt/log/object bytes. Immutable batch
    # and whitelist are the only actual future-byte reads.
    for pin_value in value['helpers']+[value['global_inputs']]:r.expect(pin_value,'excluded-future-metadata-reference-only')
    allowed_objects={str(root/'objects'/Path(owner.replace('.','/')).with_suffix('.olean')) for owner in owners}
    return {'batch':item,'whitelist':value['whitelist'],'epoch':str(epoch),'owners':owners,'allowed_canonical_paths':sorted(allowed_objects),
        'parent_context':current_pin,'helper_paths':[item['path'] for item in value['helpers']],'scope':'Explicit one directly subsequent frozen batch excluded; no future attempt/object byte reads or proof credit.'}


def future_namespace(future):
    if future is None:return
    epoch=Path(future['epoch']);owners=set(future['owners']);known={'BATCH.json','WHITELIST.json','GLOBAL_INPUTS.json','helpers','state','steps','accepted-contexts','home','tmp'}
    require({path.name for path in epoch.iterdir()}<=known,'Unknown excluded-future top-level namespace')
    require({str(path) for path in (epoch/'helpers').iterdir()}==set(future['helper_paths'])
        and all(path.is_file() and not path.is_symlink() for path in (epoch/'helpers').iterdir()),'Unknown excluded-future helper namespace')
    require({path.name for path in (epoch/'accepted-contexts').iterdir()}<={owner+'.json' for owner in owners},'Unknown excluded-future accepted owner')
    steps=epoch/'steps';allowed_files={'COMMAND.json','LOCAL_INPUTS.json','PROCESS_RETURN.json','RESULT.json','PENDING.json','output.log','normal.olean'}
    for path in steps.rglob('*') if steps.exists() else []:
        parts=path.relative_to(steps).parts
        require(not path.is_symlink() and 1<=len(parts)<=4 and parts[0] in owners and (len(parts)<2 or parts[1] in MODES),'Unknown future owner/mode/namespace')
        if path.is_dir():require(len(parts)<=3,'Unknown future nested attempt directory')
        else:require(len(parts)==4 and path.name in allowed_files and (path.name!='normal.olean' or parts[1]=='normal'),'Unknown future attempt artifact')
    for path in (epoch/'state').iterdir():
        require(path.is_file() and not path.is_symlink() and path.suffix=='.json' and (path.name in ('GLOBAL_PRE.json','BATCH_ACCEPTED.json','INTEGRITY_FAILED.json')
            or path.name.startswith(('PRE-','POST-','RESUME-'))),'Unknown excluded-future state namespace')
    require(not (epoch/'state/INTEGRITY_FAILED.json').exists(),'Excluded future integrity failure')


def object_namespace(root,catalog,native,future=None):
    required={info['selected_object']['path'] for info in catalog.values()}|{item['path'] for item in native}
    allowed=set(future['allowed_canonical_paths']) if future else set()
    actual={str(path) for path in (root/'objects').rglob('*') if path.is_file() or path.is_symlink()}
    require(required<=actual<=required|allowed and all(not Path(path).is_symlink() for path in actual),'Foreign/missing selected or future object namespace')


def inspect_endpoint(last_epoch,last_context_sha,last_seal_sha,excluded_future=None,excluded_future_sha=None):
    require(re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]{0,63}',last_epoch) is not None,'Unsafe endpoint epoch name')
    r=Readonly();started=time.monotonic();control=controls(r);old=old_parsers(r)
    old_profile=family_profile(r,OLD_FAMILY,OLD_FAMILY_SHA,OLD_BASE_SHA,OLD_GRAPH_SHA)
    new_profile=family_profile(r,NEW_FAMILY,NEW_FAMILY_SHA,NEW_BASE_SHA,NEW_GRAPH_SHA)
    require(old_profile['family']['protocol']==OLD_PROTOCOL and new_profile['family']['protocol']==NEW_PROTOCOL,'Actual protocol mix changed')
    publication,pub_pin=r.rooted(PUBLISHED/'CAPSULE.json',PUB_CAPSULE_SHA)
    require(publication['formal_acceptance'] is True and publication['accepted_project_union']==1512 and publication['accepted_owners']==FIRST8
        and publication['current_context']['sha256']==PUB_CONTEXT_SHA and publication['batch_seal']['sha256']==PUB_SEAL_SHA
        and publication['archive']['sha256']==PUB_ARCHIVE_SHA and publication['family']==old_profile['pin'],'Published1512 root changed')
    r.expect(publication['archive'],'published-archive-reference');r.expect(publication['manifest'],'published-manifest-reference')
    second,second_pin=r.rooted(OLD_FAMILY/'batches/second8/accepted-contexts'/(SECOND_LAST+'.json'),SECOND_CONTEXT_SHA)
    _,second_seal=r.rooted(OLD_FAMILY/'batches/second8/state/BATCH_ACCEPTED.json',SECOND_SEAL_SHA)
    require(second['batch_seal']==second_seal,'Old second8 external seal changed')
    old_result=verify_family(r,old,old_profile,second_pin,[OLD_FAMILY/'batches/third8'])
    require(len(old_result['groups'])==2 and old_result['groups'][0]['contexts'][-1][0]==publication['current_context']
        and old_result['groups'][0]['seal']==publication['batch_seal'],'Old published-first8 ancestry changed')
    migration=bridge(r,old_profile,old_result,new_profile)
    failed=failed_tail(r,old,old_profile,old_result,new_profile,migration['certificate'])
    epoch=NEW_FAMILY/'batches'/last_epoch;batch=r.read(pin(epoch/'BATCH.json'));owner=owner_name(batch['owners'][-1])
    current,current_pin=r.rooted(epoch/'accepted-contexts'/(owner+'.json'),last_context_sha);_,seal_pin=r.rooted(epoch/'state/BATCH_ACCEPTED.json',last_seal_sha)
    require(current['batch_seal']==seal_pin and current['batch']==r.expected[str(epoch/'BATCH.json')],'Last external context/seal/batch changed')
    require((excluded_future is None)==(excluded_future_sha is None),'Incomplete explicit future exclusion')
    future=None
    if excluded_future is not None:
        group_count=len(context_chain(r,new_profile,current_pin))
        future=inspect_future_metadata(r,new_profile,excluded_future,excluded_future_sha,current_pin,current,group_count)
    new_result=verify_family(r,old,new_profile,current_pin,[Path(future['epoch'])] if future else [])
    require(len(new_result['catalog'])==1520+len(new_result['accepted']),'New current count differs')
    all_groups=old_result['groups']+new_result['groups'];published_group=old_result['groups'][0]
    def namespaces():
        require({path for path in (OLD_FAMILY/'batches').iterdir()}==old_result['expected_dirs'] and {path for path in (NEW_FAMILY/'batches').iterdir()}==new_result['expected_dirs'],'Concurrent active/unknown epoch appeared')
        for result in (old_result,new_result):
            root=result['profile']['path'];family=result['profile']['family']
            require(not (root/'state/INTEGRITY_FAILED.json').exists(),'Provider sticky failure appeared')
            for ep,files in result['managed'].items():require({path for path in ep.rglob('*') if path.is_file()}==files,'Managed epoch changed')
            object_namespace(root,result['catalog'],family['native_artifacts'],future if result is new_result else None)
            require({str(path) for path in (root/'project').rglob('*') if path.is_file()}==set(family['project_files']),'Source namespace differs')
        require({path for path in failed['epoch'].rglob('*') if path.is_file()}==failed['files'],'Known failure namespace changed')
        if future:
            r._raw(future['batch'],'excluded-future-frozen-metadata');r._raw(future['whitelist'],'excluded-future-frozen-metadata');future_namespace(future)
        require({str(path) for path in (NEW_FAMILY/'evidence').rglob('*') if path.is_file()}=={row['physical']['path'] for row in migration['evidence_map']},'Copied evidence namespace differs')
    namespaces()
    return {'reader':r,'old_parser':old,'control':control,'old':old_result,'new':new_result,'migration':migration,'failed':failed,'publication':publication,'publication_pin':pub_pin,
        'current':current_pin,'seal':seal_pin,'last_epoch':last_epoch,'excluded_future':future,'groups':all_groups,'published_group':published_group,'namespace_check':namespaces,'seconds':time.monotonic()-started}

def coverage(old_metrics,new_metrics):
    require(len(old_metrics)==2,'Expected published-first8 and unpublished-second8')
    old_count=sum(len(item['owners']) for item in old_metrics);new_count=sum(len(item['owners']) for item in new_metrics)
    require(old_count==16 and len(old_metrics[0]['owners'])==8,'Old accepted1520 boundary differs')
    owners=[owner for item in old_metrics+new_metrics for owner in item['owners']]
    require(len(owners)==len(set(owners)),'Duplicate accepted owner across families')
    return {'current':1504+old_count+new_count,'new_since1512':old_count-8+new_count,
        'canonical_since1512':sum(item['canonical'] for item in old_metrics[1:]+new_metrics),
        'shared_since1512':sum(item['shared'] for item in old_metrics[1:]+new_metrics)}


def safe_name(name):
    path=Path(name);require(name not in ('','.') and not path.is_absolute() and '..' not in path.parts and '\\' not in name,'Unsafe archive name');return name


def output_path(path):
    path=Path(path).absolute();require(path!=TOOLS and path.resolve().is_relative_to(TOOLS),'Output outside new tools root')
    for parent in (path,*path.parents):
        if parent==TOOLS.parent:break
        require(not parent.is_symlink(),'Symlink in output path')
    require(not path.exists(),'Exclusive fresh output directory required');return path


def archive_size(size):
    require(type(size) is int and 0<size<MAX_ARCHIVE,'Compressed archive must be<90MiB; failed output retained, automatic split unimplemented');return size


def previous_boundary(r,verified,path,sha,commit):
    if path is None:
        require(sha is None and commit is None,'Incomplete previous checkpoint args');return 1,None
    require(sha is not None and commit is not None and re.fullmatch('[0-9a-f]{40}',commit) is not None,'Previous published checkpoint needs explicit SHA/commit')
    value,item=r.rooted(path,sha)
    require(value['schema']==SCHEMA+'_capsule' and value['formal_acceptance'] is True and value['Cell06_integral_complete'] is False and value['P2_6_complete'] is False
        and value['new_family']==verified['new']['profile']['pin'] and value['source_lock']['sha256']==SOURCE_LOCK_SHA
        and value['published1512']['commit']==PUBLISHED_COMMIT,'Previous checkpoint is not this exact accepted graph/family chain')
    boundaries=[group['contexts'][-1][0] for group in verified['groups']]
    require(value['current_context'] in boundaries,'Previous checkpoint endpoint is not a full current-chain epoch')
    cut=boundaries.index(value['current_context'])+1;require(1<=cut<len(boundaries),'No incremental completed epoch beyond prior checkpoint')
    require(value['last_seal']==verified['groups'][cut-1]['seal'],'Previous checkpoint seal transplant')
    r.expect(value['archive'],'prior-checkpoint-archive-reference');r.expect(value['manifest'],'prior-checkpoint-manifest-reference')
    return cut,{'capsule':item,'archive':value['archive'],'manifest':value['manifest'],'commit':commit,'current_context':value['current_context'],'cut':cut}


def sanitized_job(value,expected_seals):
    require(set(value)=={'status','output'},'Job record must be sanitized status/output only')
    status=value['status'];allowed={'job_id','task_id','cwd','timeout_seconds','memory_mb','cpu_threads','status','submitted_at','started_at','ended_at','exit_code','elapsed_seconds','peak_memory_bytes','cpu_seconds',
        'log_bytes','log_discarded_bytes','log_truncated','worker_pid','sandbox_pid'}
    require(set(status)<=allowed and status['status']=='succeeded' and status['exit_code']==0 and status['ended_at'] is not None
        and status.get('log_truncated') is False and status.get('log_discarded_bytes')==0,'Job evidence incomplete/unsafe/failed')
    output=json.loads(value['output']);require(output['formal_acceptance'] is True and output['P2_6_complete'] is False and output['batch_accepted'] in expected_seals,'Run record belongs to another epoch')
    require(set(output)<={'formal_acceptance','P2_6_complete','batch_accepted','scope'},'Unsafe/unknown run output fields')
    return status


def write(path,raw,output):
    require(path.parent==output and not path.is_symlink(),'Write outside exclusive output')
    with path.open('xb') as stream:stream.write(raw);stream.flush()
    actual=path.read_bytes();require(actual==raw,'Output byte readback mismatch: '+str(path))
    return raw_pin(path,actual)


def package(last_epoch,last_context_sha,last_seal_sha,packager_sha,output,previous=None,previous_sha=None,previous_commit=None,jobs=(),excluded_future=None,excluded_future_sha=None):
    own=pin(__file__);require(own['sha256']==packager_sha,'External candidate packager SHA differs')
    require(TOOLS==Path('/workspace/p26-cell06-checkpoint-revision3-20261128'),'Wrong writable tools root')
    output=output_path(output);verified=inspect_endpoint(last_epoch,last_context_sha,last_seal_sha,excluded_future,excluded_future_sha);r=verified['reader'];cut,prior=previous_boundary(r,verified,previous,previous_sha,previous_commit)
    selected_groups=verified['groups'][cut:];require(selected_groups,'No new completed payload')
    members={}
    def add(name,path,expected=None):
        safe_name(name);require(name not in members,'Duplicate archive name');path=Path(path);item=expected or r.expected.get(str(path))
        require(item is not None and item['path']==str(path),'Member lacks original pinned identity');r.check(item,'archive-payload');members[name]=item
    new_family=verified['new']['profile']['family'];old_family=verified['old']['profile']['family']
    for name in ('FAMILY.json','BASE_CONTEXT.json','PARENT_CERTIFICATE.json','BASE_GLOBAL_INPUTS.json','EVIDENCE_TRANSPORT_MAP.json','NORMAL_BARRIERS.json','FAILED_RELEASES.json'):
        path=NEW_FAMILY/name;expected=r.expected.get(str(path))
        if expected is None:
            table={'FAMILY.json':verified['new']['profile']['pin'],'BASE_CONTEXT.json':verified['new']['profile']['base_pin'],'PARENT_CERTIFICATE.json':new_family['certificate'],
                'BASE_GLOBAL_INPUTS.json':new_family['base_global_inputs'],'EVIDENCE_TRANSPORT_MAP.json':new_family['transport'],'NORMAL_BARRIERS.json':new_family['normal_barriers_manifest'],'FAILED_RELEASES.json':new_family['failed_releases_manifest']};expected=table[name]
        add('revision3-family/'+name,path,expected)
    add('inherited/old-FAMILY.json',OLD_FAMILY/'FAMILY.json',verified['old']['profile']['pin'])
    add('inherited/old-BASE_CONTEXT.json',OLD_FAMILY/'BASE_CONTEXT.json',verified['old']['profile']['base_pin'])
    add('published1512/CAPSULE.json',verified['publication_pin']['path'],verified['publication_pin'])
    add('source-revision/old-GRAPH.json',old_family['graph']['path'],old_family['graph'])
    add('source-revision/new-GRAPH.json',new_family['graph']['path'],new_family['graph'])
    add('source-revision/REVISION_REPORT.json',new_family['source_revision_manifest']['path'],new_family['source_revision_manifest'])
    failed=verified['failed'];release=failed['release']
    add('source-revision/FAILED_TAIL_ANCHOR.json',release['failed_anchor']['path'],release['failed_anchor'])
    for path in sorted(failed['files']):add('known-failed-third8/'+str(path.relative_to(failed['epoch'])),path)
    add('known-failed-third8/MCP_FAILED.json',failed['anchor']['mcp_record']['path'],failed['anchor']['mcp_record'])
    for change in verified['migration']['changes']:
        label=change['module'].replace('.','/')
        add('source-revision/before/'+label+'.lean',change['old_source']['path'],change['old_source'])
        add('source-revision/after/'+label+'.lean',change['new_source']['path'],change['new_source'])
    artifact_map={};new_owners=[]
    for group in selected_groups:
        result=verified['old'] if group in verified['old']['groups'] else verified['new'];label='old-family' if result is verified['old'] else 'revision3-family'
        for path in sorted(result['managed'][group['path']]):add(label+'/epochs/'+group['path'].name+'/'+str(path.relative_to(group['path'])),path)
        batch=r.read(group['batch'])
        for owner in batch['owners']:
            new_owners.append(owner);info=result['catalog'][owner];relative=owner.replace('.','/')
            add(label+'/sources/'+relative+'.lean',info['source']['path'],info['source']);add(label+'/objects/'+relative+'.olean',info['selected_object']['path'],info['selected_object'])
            require(info['normal_success_artifact'] in members.values(),'Permanent successful normal artifact omitted')
            artifact_map[owner]={'source':info['source'],'canonical':info['selected_object'],'permanent_normal':info['normal_success_artifact']}
    for item in new_family['raw_copies']:add('original-json/'+Path(item['path']).name,item['path'],item)
    for label,root,final,pinned in [('old',OLD_ROOT,verified['control']['old'],verified['control']['old_pin']),('revision3',NEW_ROOT,verified['control']['new'],verified['control']['new_pin'])]:
        add('controls/'+label+'/DELIVERY_MANIFEST.json',pinned['path'],pinned)
        for item in final['members']:add('controls/'+label+'/'+str(Path(item['path']).relative_to(root)),item['path'],item)
        for key in ('host_report','parent_delivery','tested_source_lock'):
            if key in final:
                item=final[key];add('controls/'+label+'/refs/'+key+'.json',item['path'],item)
    for item in [verified['old_parser'].delivery,*verified['old_parser'].code]:add('audited-parser/'+Path(item['path']).name,item['path'],item)
    add('checkpoint-tools/checkpoint.py',__file__,r.check(own,'packager-source'))
    for name in ('PLAN.md','README.md','CHECKPOINT_DELIVERY.json','test_checkpoint.py','TEST_RESULTS.json'):
        path=TOOLS/name;add('checkpoint-tools/'+name,path,r.check(pin(path),'packager-control'))
    job_metrics=[];expected_seals=[group['seal'] for group in selected_groups]
    for index,(path,sha) in enumerate(jobs):
        value,item=r.rooted(path,sha);status=sanitized_job(value,expected_seals);add('job-evidence/'+str(index).zfill(3)+'-'+Path(path).name,path,item);job_metrics.append({'record':item,'status':status})
    if prior:add('previous-published/CAPSULE.json',prior['capsule']['path'],prior['capsule'])
    retained_groups=[group for group in verified['groups'] if group not in selected_groups]
    retained_epochs=[]
    for group in retained_groups:
        result=verified['old'] if group in verified['old']['groups'] else verified['new']
        retained_epochs.append({'epoch':group['path'].name,'protocol':result['profile']['family']['protocol'],'seal':group['seal'],
            'last_context':group['contexts'][-1][0],'managed_refs':[r.expected[str(path)] for path in sorted(result['managed'][group['path']])]})
    refs={'published1512':{'commit':PUBLISHED_COMMIT,'capsule':verified['publication_pin'],'archive':verified['publication']['archive'],'manifest':verified['publication']['manifest']},
        'previous_checkpoint':prior,'retained_epochs':retained_epochs,'accepted1520_module_transport':verified['migration']['module_map'],
        'native555_transport':verified['migration']['native_map'],'historical_evidence_transport':verified['migration']['evidence_map'],
        'runtime':new_family['runtime'],'shared_external':verified['migration']['certificate']['shared_external_pins'],
        'recorded_G_bulk_refs':[r.expected[path] for path in sorted(r.expected) if 'recorded-G-reference-not-rehashed' in r.roles[path] or 'old-failed-PRE-reference-not-rehashed' in r.roles[path]],
        'current_bulk_rehashed':False,'provenance':'Original successful PRE/POST map reports, cold transport certificate/mapping and immutable external roots; no new full-G claim.'}
    revision_status={row['module']:{'source':row['new_source'],'status':'accepted_at_selected_endpoint' if row['module'] in verified['new']['catalog'] else 'SOURCE_CANDIDATE_unaccepted',
        'payload_path':'source-revision/after/'+row['module'].replace('.','/')+'.lean'} for row in verified['migration']['changes']}
    count=coverage(verified['old']['metrics'],verified['new']['metrics']);require(count['current']==len(verified['new']['catalog']),'Current actual count mismatch')
    scope=f'Incremental checkpoint ending {last_epoch}: accepted{count["current"]}; {count["new_since1512"]} owners since published1512, {len(new_owners)} in this archive. Integral/globalP2.6 remain open.'
    manifest={'schema':SCHEMA+'_manifest','formal_acceptance':True,'current_context':verified['current'],'last_seal':verified['seal'],'accepted_project_union':count['current'],
        'new_since_published1512':count['new_since1512'],'archive_new_owners':new_owners,'members':members,'artifacts':artifact_map,'retained_pinned_references':refs,
        'old_family':verified['old']['profile']['pin'],'new_family':verified['new']['profile']['pin'],'source_lock':verified['control']['source_lock_pin'],
        'protocols':[OLD_PROTOCOL,NEW_PROTOCOL],'revision_sources':revision_status,'excluded_future':verified['excluded_future'],'global_checks_repeated_by_packager':0,'proof_modes_repeated_by_packager':0,'coldcollect_repeated':False,
        'Cell06_integral_complete':False,'P2_6_complete':False,'scope':scope}
    raw_manifest=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode();verified['namespace_check']();output.mkdir(parents=True);archive=output/'evidence.tar.xz'
    with archive.open('xb') as stream,tarfile.open(fileobj=stream,mode='w:xz') as tar:
        for name,item in sorted(members.items()):
            raw=Path(item['path']).read_bytes();require(raw_pin(item['path'],raw)==item,'Member changed before archive write')
            entry=tarfile.TarInfo(name);entry.size=len(raw);entry.mode=0o644;tar.addfile(entry,io.BytesIO(raw))
        entry=tarfile.TarInfo('MANIFEST.json');entry.size=len(raw_manifest);entry.mode=0o644;tar.addfile(entry,io.BytesIO(raw_manifest))
    archive_size(archive.stat().st_size);expected=set(members)|{'MANIFEST.json'};seen=set()
    with tarfile.open(archive,'r:xz') as tar:
        for entry in tar:
            require(entry.isfile() and entry.name in expected and entry.name not in seen,'Unexpected/duplicate archive member');seen.add(entry.name);raw=tar.extractfile(entry).read()
            if entry.name=='MANIFEST.json':require(raw==raw_manifest,'Manifest byte readback mismatch')
            else:require(raw_pin(members[entry.name]['path'],raw)==members[entry.name] and raw==Path(members[entry.name]['path']).read_bytes(),'Member byte readback mismatch')
    require(seen==expected,'Archive member omitted');post=r.post_members(members.values());verified['namespace_check']();mp=write(output/'MANIFEST.json',raw_manifest,output)
    all_records=verified['old']['records']+verified['new']['records'];selected_paths={group['path'] for group in selected_groups}
    current_metrics=[]
    for record in all_records:
        result=record['process'];ep=Path(record['result']['path']).parents[4]
        current_metrics.append({'epoch':record['epoch'],'protocol':record['protocol'],'owner':record['owner'],'mode':record['mode'],'seconds':result['seconds'],
            'timings':result['timings'],'sampled_peak_tree_rss_bytes':result['sampled_peak_tree_rss_bytes'],'in_payload':ep in selected_paths,
            'validation_receipt':record['marker'],'canonical':record['validated']['canonical_count'] if record['mode']=='full-owned' else None,
            'shared':record['validated']['shared_occurrences'] if record['mode']=='full-owned' else None})
    capsule={'schema':SCHEMA+'_capsule','formal_acceptance':True,'current_context':verified['current'],'last_seal':verified['seal'],'last_epoch':last_epoch,'accepted_project_union':count['current'],
        'new_since_published1512':count['new_since1512'],'archive_new_owners':new_owners,'new_canonical_since1512':count['canonical_since1512'],'new_shared_since1512':count['shared_since1512'],
        'old_family':verified['old']['profile']['pin'],'new_family':verified['new']['profile']['pin'],'source_lock':verified['control']['source_lock_pin'],
        'published1512':refs['published1512'],'previous_checkpoint':prior,'revision_sources':revision_status,'excluded_future':verified['excluded_future'],'epoch_metrics':verified['old']['metrics']+verified['new']['metrics'],'mode_metrics':current_metrics,
        'archive_canonical':sum(record['validated']['canonical_count'] for record in all_records if record['mode']=='full-owned' and Path(record['result']['path']).parents[4] in selected_paths),
        'archive_shared':sum(record['validated']['shared_occurrences'] for record in all_records if record['mode']=='full-owned' and Path(record['result']['path']).parents[4] in selected_paths),
        'seed_metrics':{key:new_family[key] for key in ('qualification_seconds','namespace_and_evidence_materialization_seconds','cold_global_readback_seconds','cold_seed_seconds_excluding_qualification','copy_bytes_upper_bound')},
        'optional_job_metrics':job_metrics,'known_failed_release':release,'archive':pin(archive),'manifest':mp,'archive_readback_members':len(seen),'all_archive_members_byte_equal':True,
        'actual_payload_localD_metadata_checksum':{'files':len(r.verified),'selected_bytes':r.byte_count,'scope':'Metadata/localD/payload only; not a new G or inherited bulk verification.'},
        'inherited_bulk_reference_count':len(set(r.expected)-r.verified),'inherited_bulk_rehashed':False,'archive_member_postcheck':post,
        'global_checks_repeated_by_packager':0,'proof_modes_repeated_by_packager':0,'coldcollect_repeated':False,'provider_writes':0,'automatic_split_implemented':False,
        'Cell06_integral_complete':False,'P2_6_complete':False,'packager_source':own,'scope':scope}
    cp=write(output/'CAPSULE.json',(json.dumps(capsule,ensure_ascii=False,indent=2)+'\n').encode(),output)
    print(json.dumps({'capsule':cp,'archive':capsule['archive'],'manifest':mp,'accepted_project_union':count['current'],'formal_acceptance':True,'P2_6_complete':False}),flush=True)


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--last-epoch',required=True);parser.add_argument('--last-context-sha256',required=True);parser.add_argument('--last-seal-sha256',required=True)
    parser.add_argument('--packager-sha256',required=True);parser.add_argument('--output-directory',type=Path,required=True)
    parser.add_argument('--excluded-future-batch',type=Path);parser.add_argument('--excluded-future-batch-sha256')
    parser.add_argument('--previous-capsule',type=Path);parser.add_argument('--previous-capsule-sha256');parser.add_argument('--previous-publish-commit')
    parser.add_argument('--job-record',type=Path,action='append',default=[]);parser.add_argument('--job-record-sha256',action='append',default=[])
    args=parser.parse_args();require(len(args.job_record)==len(args.job_record_sha256),'Optional run evidence needs exact external SHAs')
    package(args.last_epoch,args.last_context_sha256,args.last_seal_sha256,args.packager_sha256,args.output_directory,args.previous_capsule,args.previous_capsule_sha256,args.previous_publish_commit,list(zip(args.job_record,args.job_record_sha256)),args.excluded_future_batch,args.excluded_future_batch_sha256)


if __name__=='__main__':main()
