"""Synthetic providers only; no actual endpoint/package/Lean/seed/G/MCP calls."""
import ast
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch
sys.dont_write_bytecode=True
import checkpoint as c
ROOT=Path(__file__).resolve().parent


def put(path,value):
    path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(value,indent=2)+'\n');return c.pin(path)


def audit_text(owner,parents,shared=True,bad_shared=False):
    name=owner+'.fact';decl={'module':owner,'name':name,'type':'Nat','unsafe':False,'partial':False,'axiom':False,'axioms':[]}
    serialized=[name];shared_names=[];rows=[('IMPORTS',sorted(parents|{owner})+['Init']),('DECL',decl)]
    if shared:
        common='ImbalancedChen.SyntheticParent.sharedEq';shared_names=[common];serialized.append(common)
        rows.append(('SHARED',{**decl,'name':common,'canonical_module':'ImbalancedChen.SyntheticParent','identical_metadata':True,
            'identical_body':not bad_shared,'proof_body_kernel_checked':not bad_shared}))
    rows += [('INVENTORY',{'module':owner,'serialized':serialized,'environment':[name],'shared':shared_names}),
             ('COMPLETE',{'module':owner,'count':1,'shared_count':len(shared_names),'serialized_count':len(serialized)})]
    return ''.join('P26_CELL06_AUDIT_'+tag+' '+json.dumps(value)+'\n' for tag,value in rows)


class Fixture:
    def __init__(self,protocol=c.OLD_PROTOCOL,targets=None):
        self.tmp=tempfile.TemporaryDirectory(prefix='SYNTHETIC-',dir=ROOT);self.root=Path(self.tmp.name);self.protocol=protocol
        for name in ('project/ImbalancedChen','objects/ImbalancedChen','batches','runtime'):(self.root/name).mkdir(parents=True)
        self.parent='ImbalancedChen.SyntheticParent';self.targets=targets or ['ImbalancedChen.SyntheticNext'+str(i) for i in range(3)]
        self.r=c.Readonly();self.old=c.old_parsers(self.r);self.prefix=[];self.accepted=[];self.records=[]
        source=self.root/'project/ImbalancedChen/SyntheticParent.lean';source.write_text('-- synthetic parent\n')
        obj=self.root/'objects/ImbalancedChen/SyntheticParent.olean';obj.write_bytes(b'SYNTHETIC_PARENT_NOT_LEAN')
        self.catalog={self.parent:{'source':c.pin(source),'selected_object':c.pin(obj)}};sources={self.parent:c.pin(source)}
        for owner in self.targets:
            path=self.root/'project'/Path(owner.replace('.','/')).with_suffix('.lean');path.write_text('import '+self.parent+'\n');sources[owner]=c.pin(path)
        lean=self.root/'runtime/lean';lean.write_bytes(b'NOT_EXECUTABLE');checker=self.root/'runtime/leanchecker';checker.write_bytes(b'NOT_EXECUTABLE_CHECKER')
        graph=put(self.root/'GRAPH.json',{'topological_order':self.targets,'entries':{o:{'source':sources[o],'imports':[self.parent]} for o in self.targets}})
        base=put(self.root/'BASE_CONTEXT.json',{'project_closure':self.catalog,'formal_acceptance':False,'verified_parent_formal_acceptance':True})
        # Deliberately nonexistent bulk ref proves no complete-G checksum occurs.
        self.bulk={'path':str(self.root/'BULK_NEVER_READ.bin'),'bytes':9*1024**3,'sha256':'0'*64}
        baseline=put(self.root/'BASE_GLOBAL_INPUTS.json',[self.bulk,c.pin(source),c.pin(obj),graph,base])
        self.family={'protocol':protocol,'family_root':str(self.root),'base_context':base,'base_catalog':self.catalog,'base_global_inputs':baseline,'graph':graph,
            'project_sources':sources,'runtime':{'lean':c.pin(lean),'leanchecker':c.pin(checker)},'environment':{'sysroot':str(self.root/'runtime')},
            'lean_path':str(self.root/'objects'),'external_modules':['Init'],'native_artifacts':[],'rss_gib':1,'wall_seconds':10,'code_pins':[]}
        self.fp=put(self.root/'FAMILY.json',self.family);self.current=base;self.prefix=[base]
        self.profile={'family':self.family,'pin':self.fp,'base_pin':base,'base':json.loads(Path(base['path']).read_text()),'graph':json.loads(Path(graph['path']).read_text()),
            'baseline':json.loads(Path(baseline['path']).read_text()),'path':self.root}
    def close(self):self.tmp.cleanup()
    def epoch(self,name,count=1):
        ep=self.root/'batches'/name;ep.mkdir()
        for part in ('helpers','steps','state','accepted-contexts','home','tmp'):(ep/part).mkdir()
        owners=c.next_owners(self.targets,set(self.catalog),count);parent=dict(self.catalog);parent_context=self.current;helpers=[]
        for owner in owners:
            path=ep/'helpers'/(owner+'.Owned.lean');path.write_text('-- synthetic auditor\n');helpers.append(c.pin(path))
        whitelist=put(ep/'WHITELIST.json',owners)
        spec=put(ep/'GLOBAL_INPUTS.json',{'protocol':self.protocol,'family':self.fp,'parent_context':self.current,'baseline':self.family['base_global_inputs'],
            'prefix_inputs':c.unique(self.prefix+[row['selected_object'] for row in self.catalog.values()]),'batch_static':helpers+[whitelist]})
        batch={'protocol':self.protocol,'family':self.fp,'parent_context':self.current,'epoch_index':len(list((self.root/'batches').iterdir())),
            'owners':owners,'accepted_before':list(self.accepted),'global_inputs':spec,'helpers':helpers,'whitelist':whitelist,
            'environment_sha256':c.env_sha(c.env_for(ep,self.family)),'concurrency':1,'failure_policy':'atomic_all_declared_owners','normal_success_recompile_allowed':False}
        bp=put(ep/'BATCH.json',batch);sv=json.loads(Path(spec['path']).read_text());g=c.unique(self.profile['baseline']+sv['prefix_inputs']+sv['batch_static']+[spec,self.family['base_global_inputs'],self.fp,bp])
        def report(purpose):return {'protocol':self.protocol,'purpose':purpose,'family':self.fp,'batch':bp,'global_inputs':spec,'matched':True,'mismatches':[],
            'global_validation_scope':'batch_boundary','files_checked':len(g),'bytes_read':sum(x['bytes'] for x in g),'actual_map_sha256':c.digest_map(g),'seconds':1.0}
        pre=put(ep/'state/PRE-fixture.json',report('PRE'));anchor=put(ep/'state/GLOBAL_PRE.json',{'snapshot':pre,'formal_acceptance':False})
        history=[];pending={};batch['_pre']=pre
        for owner_index,owner in enumerate(owners):
            for mode in c.MODES:
                directory=ep/'steps'/owner/mode/'one';directory.mkdir(parents=True)
                local=put(directory/'LOCAL_INPUTS.json',c.exact_local(self.family,batch,ep,owner,history,pending))
                ident={'protocol':self.protocol,'family':self.fp,'batch':bp,'key':owner,'mode':mode,'global_validation_scope':'batch_boundary','batch_pre':pre,
                    'environment_sha256':batch['environment_sha256'],'argv':c.argv_for(ep,self.family,owner,mode),'cwd':str(self.root/'project'),'timeout':10,'rss_bytes':1024**3}
                command=put(directory/'COMMAND.json',{'identity':ident,'actual_argv':[str(directory/'normal.olean') if x=='__NORMAL_OUTPUT__' else x for x in ident['argv']],'local_inputs':local})
                obj=None
                if mode=='normal':
                    artifact=directory/'normal.olean';artifact.write_bytes(('SYNTHETIC_NOT_LEAN_'+owner).encode());obj=c.pin(artifact);text='synthetic normal\n'
                elif mode=='stock-leanchecker':text='synthetic checker\n'
                else:text=audit_text(owner,set(parent)|set(owners[:owner_index+1]))
                log=directory/'output.log';log.write_text(text)
                process={'exit_code':0,'stop_reason':None,'seconds':0.1,'sampled_peak_tree_rss_bytes':1}
                returned=put(directory/'PROCESS_RETURN.json',{'protocol':self.protocol,'identity':ident,'command':command,'log':c.pin(log),'object':obj,'process_result':process,
                    'formal_acceptance':False,'status':'PROCESS_RETURNED_PENDING_LOCAL_AND_GLOBAL_CHECKS'})
                result=put(directory/'RESULT.json',{**process,'protocol':self.protocol,'formal_acceptance':False,'global_validation_scope':'batch_boundary','command':command,'process_return':returned,
                    'log':c.pin(log),'object':obj,'local_post':{'inputs':local,'all_local_files_matched':True,'file_count':len(json.loads(Path(local['path']).read_text()))},
                    'timings':{'local_D_pre_seconds':0.01,'local_D_post_seconds':0.01,'mode_validation_seconds':0.01}})
                value=json.loads(Path(result['path']).read_text())
                if mode=='normal':validated=self.old.controller.normal_validator(text,value)
                elif mode=='stock-leanchecker':validated={'stock_leanchecker_exit_zero':True}
                else:validated=self.old.evidence.validate_audit(text,[owner],set(parent)|set(owners[:owner_index+1]),['Init'])
                marker=put(directory/'PENDING.json',{'protocol':self.protocol,'status':'NORMAL_SUCCEEDED_PENDING_GLOBAL' if mode=='normal' else 'PROCESS_VALIDATED_PENDING_GLOBAL','identity':ident,
                    'result':result,'process_return':returned,'validated':validated,'formal_acceptance':False,'batch_post':None,'P2_6_complete':False})
                record={'owner':owner,'mode':mode,'marker':marker,'result':result,'command':command,'process_return':returned,'log':c.pin(log),'local_inputs':local,'object':obj}
                history.append(record)
                if mode=='normal':
                    pending[owner]=record;canonical=self.root/'objects'/Path(owner.replace('.','/')).with_suffix('.olean');canonical.write_bytes(Path(obj['path']).read_bytes())
        post=put(ep/'state/POST-fixture.json',report('POST'));delta=[]
        for record in history:
            delta += [record[key] for key in ('marker','result','command','log','local_inputs','process_return')]+json.loads(Path(record['local_inputs']['path']).read_text())
            if record['object']:delta.append(record['object'])
        for path in (ep/'steps').rglob('*'):
            if path.is_file():delta.append(c.pin(path))
        delta += [pre,post,anchor]
        seal=put(ep/'state/BATCH_ACCEPTED.json',{'protocol':self.protocol,'status':'BATCH_ACCEPTED','formal_acceptance':True,'P2_6_complete':False,'global_validation_scope':'batch_boundary',
            'family':self.fp,'batch':bp,'parent_context':parent_context,'owners':owners,'pending_mode_receipts':[x['marker'] for x in history],'delta_inputs':c.unique(delta),'global_pre':pre,'global_post':post})
        contexts=[]
        for index,owner in enumerate(owners):
            normal=pending[owner]['object'];canonical={**normal,'path':str(self.root/'objects'/Path(owner.replace('.','/')).with_suffix('.olean'))}
            origin='accepted_family_batch_global_boundary_v1' if self.protocol==c.OLD_PROTOCOL else 'accepted_source_revision3_family_batch_global_boundary_v1'
            self.catalog={**self.catalog,owner:{'source':self.family['project_sources'][owner],'selected_object':canonical,'origin':origin,'normal_success_artifact':normal}};self.accepted.append(owner)
            value={'protocol':self.protocol,'formal_acceptance':True,'P2_6_complete':False,'family':self.fp,'batch':bp,'batch_seal':seal,'accepted_parent':self.current,'epoch_parent':parent_context,
                'project_closure':self.catalog,'native_artifacts':[],'runtime':self.family['runtime'],'lean_path':self.family['lean_path'],'accepted_in_this_batch':owners[:index+1],
                'accepted_since_family_base':list(self.accepted),'global_validation_scope':'batch_boundary','scope':'Exact atomic1..8-owner family batch; no global P2.6 claim.'}
            self.current=put(ep/'accepted-contexts'/(owner+'.json'),value);contexts.append((self.current,value))
        self.prefix += [cp for cp,_ in contexts]+[bp,seal,spec,whitelist,anchor]+c.unique(delta)+sv['prefix_inputs']+sv['batch_static']+[sv['baseline']]+helpers
        self.prefix += [pre,post]+[record[key] for record in history for key in ('marker','result')]
        self.records+=history;self.last_epoch=ep;self.last_seal=seal;return seal
    def verify(self):return c.verify_family(c.Readonly(),self.old,self.profile,self.current)


def future_batch(f):
    ep=f.root/'batches/future';ep.mkdir()
    for name in ('helpers','steps','state','accepted-contexts','home','tmp'):(ep/name).mkdir()
    owners=c.next_owners(f.targets,set(f.catalog),1);helpers=[]
    for owner in owners:
        path=ep/'helpers'/(owner+'.Owned.lean');path.write_bytes(b'FUTURE_HELPER_MUST_NOT_BE_READ');helpers.append(c.pin(path))
    whitelist=put(ep/'WHITELIST.json',owners);glob=put(ep/'GLOBAL_INPUTS.json',{'future':'not inspected'})
    value={'protocol':c.NEW_PROTOCOL,'family':f.fp,'parent_context':f.current,'epoch_index':2,'accepted_before':list(f.accepted),'owners':owners,
        'helpers':helpers,'whitelist':whitelist,'global_inputs':glob,'concurrency':1,'failure_policy':'atomic_all_declared_owners','normal_success_recompile_allowed':False,
        'global_validation_scope':'batch_boundary','formal_acceptance':False,'P2_6_complete':False,'environment_sha256':c.env_sha(c.env_for(ep,f.family))}
    batch=put(ep/'BATCH.json',value);active=ep/'steps'/owners[0]/'normal/one';active.mkdir(parents=True)
    (active/'COMMAND.json').write_bytes(b'ACTIVE_BYTES_MUST_NOT_BE_READ');(active/'output.log').write_bytes(b'PARTIAL_ACTIVE_LOG')
    obj=f.root/'objects'/Path(owners[0].replace('.','/')).with_suffix('.olean');obj.write_bytes(b'FUTURE_OBJECT_MUST_NOT_BE_READ')
    return ep,batch,obj


class FutureExclusionTests(unittest.TestCase):
    def setUp(self):
        self.f=Fixture(c.NEW_PROTOCOL,[c.PILOT,'ImbalancedChen.AfterPilot','ImbalancedChen.Later']);self.f.epoch('pilot1');self.ep,self.bp,self.obj=future_batch(self.f)
    def tearDown(self):self.f.close()
    def inspect(self,sha=None):
        return c.inspect_future_metadata(c.Readonly(),self.f.profile,self.ep/'BATCH.json',sha or self.bp['sha256'],self.f.current,json.loads(Path(self.f.current['path']).read_text()),1)
    def test_target_sealed_future_active_allowed_without_future_body_reads(self):
        f=self.f;real=c.pin
        def guard(path):
            if Path(path).is_relative_to(self.ep/'steps') or str(path)==str(self.obj):self.fail('Future attempt/object bytes read')
            return real(path)
        with patch.object(c,'pin',side_effect=guard):
            future=self.inspect();result=c.verify_family(c.Readonly(),f.old,f.profile,f.current,[self.ep]);c.future_namespace(future)
            c.object_namespace(f.root,result['catalog'],[],future)
        self.assertEqual(future['owners'],['ImbalancedChen.AfterPilot']);self.assertNotIn('ImbalancedChen.AfterPilot',result['catalog'])
    def test_wrong_sha_parent_family_order_and_changed_metadata_rejected(self):
        with self.assertRaises(RuntimeError):self.inspect('0'*64)
        path=self.ep/'BATCH.json';original=path.read_bytes();value=json.loads(original)
        for key,changed in [('parent_context',{**value['parent_context'],'sha256':'0'*64}),('family',{**value['family'],'sha256':'0'*64}),('owners',['ImbalancedChen.Later'])]:
            put(path,{**value,key:changed});self.bp=c.pin(path)
            with self.assertRaises(RuntimeError):self.inspect()
            path.write_bytes(original)
        self.bp=c.pin(path);future=self.inspect();path.write_bytes(b'changed metadata')
        with self.assertRaises(RuntimeError):c.Readonly()._raw(future['batch'],'frozen-future-metadata')
    def test_foreign_future_or_object_namespace_rejected(self):
        f=self.f;future=self.inspect();wrong=self.ep/'helpers/Foreign.Owned.lean';wrong.write_text('unknown')
        with self.assertRaises(RuntimeError):c.future_namespace(future)
        wrong.unlink();foreign=f.root/'objects/ImbalancedChen/Foreign.olean';foreign.write_bytes(b'foreign')
        with self.assertRaises(RuntimeError):c.object_namespace(f.root,f.catalog,[],future)
    def test_changed_target_object_is_still_checksum_rejected(self):
        f=self.f;future=self.inspect();path=Path(f.catalog[c.PILOT]['selected_object']['path']);path.write_bytes(b'target changed')
        with self.assertRaises(RuntimeError):c.verify_family(c.Readonly(),f.old,f.profile,f.current,[self.ep])
    def test_unknown_future_normal_owner_is_not_ignored(self):
        future=self.inspect();path=self.ep/'steps/ImbalancedChen.Foreign/normal/one';path.mkdir(parents=True);(path/'COMMAND.json').write_bytes(b'unknown')
        with self.assertRaises(RuntimeError):c.future_namespace(future)


class CheckpointTests(unittest.TestCase):
    def test_old_two_epochs_and_new_protocol_pilot_shared_semantics(self):
        old=Fixture();new=Fixture(c.NEW_PROTOCOL,[c.PILOT,'ImbalancedChen.AfterPilot'])
        try:
            old.epoch('first',2);old.epoch('second',1);a=old.verify();new.epoch('pilot1');new.epoch('tail');b=new.verify()
            self.assertEqual(len(a['records']),9);self.assertEqual(len(b['records']),6)
            self.assertEqual(sum(x['shared'] for x in a['metrics']),3);self.assertEqual(sum(x['shared'] for x in b['metrics']),2)
            self.assertEqual({x['protocol'] for x in a['records']+b['records']},{c.OLD_PROTOCOL,c.NEW_PROTOCOL})
        finally:old.close();new.close()
    def test_bulk_reference_is_never_read_or_called_a_new_G(self):
        f=Fixture()
        try:
            f.epoch('one');real=c.pin
            def guard(path):
                if str(path)==f.bulk['path']:self.fail('Full-G bulk read attempted')
                return real(path)
            r=c.Readonly()
            with patch.object(c,'pin',side_effect=guard):c.verify_family(r,f.old,f.profile,f.current)
            self.assertIn(f.bulk['path'],r.expected);self.assertNotIn(f.bulk['path'],r.verified);self.assertFalse(Path(f.bulk['path']).exists())
        finally:f.close()
    def test_actual_localD_or_normal_artifact_mutation_rejects(self):
        for target in ('log','object','process_return'):
            f=Fixture()
            try:
                f.epoch('one');record=next(x for x in f.records if x['mode']=='normal');Path(record[target]['path']).write_bytes(b'changed')
                with self.assertRaises((RuntimeError,json.JSONDecodeError)):f.verify()
            finally:f.close()
    def test_unknown_active_epoch_rejects_before_its_body_read(self):
        f=Fixture()
        try:
            f.epoch('sealed');(f.root/'batches/active').mkdir()
            with self.assertRaisesRegex(RuntimeError,'Active/unsealed/unknown'):f.verify()
        finally:f.close()
    def test_missing_marker_or_result_is_never_repaired(self):
        for target in ('marker','result'):
            f=Fixture()
            try:
                f.epoch('one');path=Path(f.records[0][target]['path']);path.unlink()
                with self.assertRaises((RuntimeError,FileNotFoundError)):f.verify()
                self.assertFalse(path.exists())
            finally:f.close()
    def test_wrong_protocol_return_or_context_binding_rejects(self):
        f=Fixture(c.NEW_PROTOCOL,[c.PILOT])
        try:
            f.epoch('pilot');path=Path(f.current['path']);value=json.loads(path.read_text());value['protocol']=c.OLD_PROTOCOL;put(path,value)
            with self.assertRaises(RuntimeError):f.verify()
        finally:f.close()
    def test_shared_nonidentical_body_and_unsafe_types_reject(self):
        r=c.Readonly();old=c.old_parsers(r);owner='ImbalancedChen.Child';parents={'ImbalancedChen.SyntheticParent',owner}
        good=audit_text(owner,parents);validated=old.evidence.validate_audit(good,[owner],parents,['Init']);self.assertEqual(validated['shared_occurrences'],1)
        with self.assertRaises(RuntimeError):old.evidence.validate_audit(audit_text(owner,parents,bad_shared=True),[owner],parents,['Init'])
        with self.assertRaises(RuntimeError):old.evidence.validate_audit(good.replace('"unsafe": false','"unsafe": true'),[owner],parents,['Init'])
    def test_module_and_evidence_transport_are_explicit_not_count_only(self):
        with tempfile.TemporaryDirectory(prefix='MAP-',dir=ROOT) as temp:
            root=Path(temp);owner='ImbalancedChen.X';oldroot=root/'old';newroot=root/'new';digest='0'*64
            old={owner:{'source':{'path':str(oldroot/'project/ImbalancedChen/X.lean'),'bytes':1,'sha256':digest},'selected_object':{'path':str(oldroot/'objects/ImbalancedChen/X.olean'),'bytes':1,'sha256':digest}}}
            new={owner:{'source':{**old[owner]['source'],'path':str(newroot/'project/ImbalancedChen/X.lean')},'selected_object':{**old[owner]['selected_object'],'path':str(newroot/'objects/ImbalancedChen/X.olean')}}}
            self.assertEqual(len(c.module_transport(old,new,oldroot,newroot)),1)
            bad={owner:{**new[owner],'selected_object':{**new[owner]['selected_object'],'sha256':'1'*64}}}
            with self.assertRaises(RuntimeError):c.module_transport(old,bad,oldroot,newroot)
            row={'logical':old[owner]['source'],'physical':{**old[owner]['source'],'path':str(newroot/'evidence/file')},'identity_preserved':True}
            c.evidence_transport([row['logical']],[row],newroot)
            with self.assertRaises(RuntimeError):c.evidence_transport([row['logical']],[],newroot)
    def test_counts_are_dynamic_not31_or248(self):
        old=[{'owners':['a'+str(i) for i in range(8)],'canonical':248,'shared':0},{'owners':['b'+str(i) for i in range(8)],'canonical':233,'shared':2}]
        new=[{'owners':[c.PILOT],'canonical':10,'shared':3}]
        self.assertEqual(c.coverage(old,new),{'current':1521,'new_since1512':9,'canonical_since1512':243,'shared_since1512':5})
    def test_next_tail_and_size_limits(self):
        self.assertEqual(c.next_owners(['a','b'],{'a'},1),['b'])
        with self.assertRaises(RuntimeError):c.next_owners(['a','b'],{'a'},2)
        for size in (0,90*1024**2,True):
            with self.assertRaises(RuntimeError):c.archive_size(size)
        for name in ('../escape','/absolute','x\\escape'):
            with self.assertRaises(RuntimeError):c.safe_name(name)
    def test_no_mutable_proof_seed_or_G_entrypoint(self):
        forbidden={'run_batch','run_mode','verify_accepted','load_contract','recover_history','collect_revision3_parent','collect_1504_parent','real_process','Popen','system','spawn_agent'}
        for node in ast.walk(ast.parse(Path(c.__file__).read_text())):
            if isinstance(node,ast.Call):
                name=node.func.attr if isinstance(node.func,ast.Attribute) else node.func.id if isinstance(node.func,ast.Name) else ''
                self.assertNotIn(name,forbidden)
    def test_previous_checkpoint_requires_full_same_chain_epoch_and_new_delta(self):
        with tempfile.TemporaryDirectory(prefix='PREVIOUS-',dir=ROOT) as temp:
            root=Path(temp);pins=[{'path':str(root/('ctx'+str(i))),'bytes':1,'sha256':str(i)*64} for i in (1,2,3)]
            seals=[{'path':str(root/('seal'+str(i))),'bytes':1,'sha256':str(i+3)*64} for i in (1,2,3)]
            fp={'path':str(root/'FAMILY.json'),'bytes':1,'sha256':'9'*64}
            verified={'new':{'profile':{'pin':fp}},'groups':[{'contexts':[(cp,{})],'seal':sp} for cp,sp in zip(pins,seals)]}
            value={'schema':c.SCHEMA+'_capsule','formal_acceptance':True,'Cell06_integral_complete':False,'P2_6_complete':False,'new_family':fp,
                'source_lock':{'sha256':c.SOURCE_LOCK_SHA},'published1512':{'commit':c.PUBLISHED_COMMIT},'current_context':pins[1],'last_seal':seals[1],
                'archive':{'path':str(root/'prior.tar.xz'),'bytes':1,'sha256':'a'*64},'manifest':{'path':str(root/'prior-manifest.json'),'bytes':1,'sha256':'b'*64}}
            path=root/'prior.json';item=put(path,value);cut,prior=c.previous_boundary(c.Readonly(),verified,path,item['sha256'],'c'*40);self.assertEqual(cut,2)
            value['last_seal']=seals[0];item=put(path,value)
            with self.assertRaises(RuntimeError):c.previous_boundary(c.Readonly(),verified,path,item['sha256'],'c'*40)
    def test_verification_and_output_readback_do_not_modify_provider(self):
        f=Fixture()
        try:
            f.epoch('one');before={str(p):(p.stat().st_size,p.stat().st_mtime_ns,p.stat().st_ino) for p in f.root.rglob('*') if p.is_file()};f.verify()
            self.assertEqual(before,{str(p):(p.stat().st_size,p.stat().st_mtime_ns,p.stat().st_ino) for p in f.root.rglob('*') if p.is_file()})
            output=f.root/'own-output';output.mkdir();path=output/'CAPSULE.json';value=b'{"synthetic":true}\n'
            self.assertEqual(c.write(path,value,output),c.raw_pin(path,value));self.assertEqual(path.read_bytes(),value)
            with self.assertRaises(FileExistsError):c.write(path,value,output)
        finally:f.close()

    def test_job_record_rejects_environment_keys_and_wrong_epoch(self):
        item={'path':'/synthetic/SEAL','bytes':1,'sha256':'0'*64};value={'status':{'status':'succeeded','exit_code':0,'ended_at':1,'log_truncated':False,'log_discarded_bytes':0},
            'output':json.dumps({'formal_acceptance':True,'P2_6_complete':False,'batch_accepted':item})}
        c.sanitized_job(value,[item])
        with self.assertRaises(RuntimeError):c.sanitized_job(value,[])
        value['status']['environment']={'secret':'not copied'}
        with self.assertRaises(RuntimeError):c.sanitized_job(value,[item])

if __name__=='__main__':unittest.main(verbosity=2)
