# Readonly first8 accepted-evidence packager

Only this new output root is writable. Frozen family code/docs/stage/source/object/evidence and original JSON remain readonly. Implementation does not read the active first8 modes/objects, execute packaging, run a proof/controller mode, prepare a stage, invoke Lean/lake/MCP, or spawn an agent.

1. Implement a standalone readonly verifier rather than import controller/engine recovery or acceptance helpers, which can write canonical/PENDING/sticky files.
2. Require external packager SHA and the real run-output seal SHA; fix known FAMILY, BASE, BATCH, graph and FINAL roots. Refuse absent/unaccepted/incomplete receipts or any integrity marker.
3. Reconstruct all24 normal/stock/full-owned identity, exact-attempt command/local-input/log/return/result/PENDING chains. Parse already-existing audit logs with the pinned readonly parser; no proof repetition. Validate8 accepted contexts and canonical source/object pairs.
4. Verify the full G selector and inherited references by streaming actual bytes once per packaging verification transaction, plus source/object/evidence namespaces. Keep parent1504 objects/native/external and310MB historical physical evidence as explicit pinned refs, not archive payload. Do not substitute stat metadata for byte checking.
5. Archive required family metadata, graph, complete managed first8 epoch,8 source/object pairs, raw2JSON, reviewed FINAL/candidate13members/hostreport/parentdelivery and packager/support sources. Require root-supplied MCP_SEED/FREEZE/RUN successful-output records to match actual roots.
6. Manifest every archive member; exclusive-create output; compression<90MiB; read every member back byte-for-byte and recheck all input/member pins. Write CAPSULE only after success, reporting only8 new owners/current1512 and dynamic canonical/shared counts plus actual G/D/process/seed metrics. Cell06 integral and globalP2.6 remain false.
7. Run only pure/static synthetic guard tests and AST/CLI-help checks while preparing. Do not execute package or inspect active proof inputs. Root reviews and executes later with the actual seal SHA.
