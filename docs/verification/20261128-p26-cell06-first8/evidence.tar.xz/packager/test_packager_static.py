"""Pure/synthetic guards only: never calls package or reads a live stage."""
import ast
import json
from pathlib import Path
import sys
import tempfile
import unittest
sys.dont_write_bytecode=True
import package_first8 as p

class GuardTests(unittest.TestCase):
    def test_module_has_no_proof_or_recovery_entrypoints(self):
        tree=ast.parse(Path(p.__file__).read_text())
        forbidden={'run_batch','run_mode','execute_pending','recover_history','verify_accepted','load_contract','collect_1504_parent','prepare','Popen','run','system','spawn'}
        for node in ast.walk(tree):
            if isinstance(node,ast.Call):
                name=node.func.attr if isinstance(node.func,ast.Attribute) else node.func.id if isinstance(node.func,ast.Name) else ''
                self.assertNotIn(name,forbidden)
        self.assertNotIn('family_engine',Path(p.__file__).read_text())

    def test_archive_member_paths_are_relative_and_safe(self):
        self.assertEqual(p.safe_name('epoch/steps/Foo/normal/a/output.log'),'epoch/steps/Foo/normal/a/output.log')
        for name in ('','/absolute','../escape','epoch/../../escape','x\\escape'):
            with self.assertRaises(RuntimeError):p.safe_name(name)

    def test_exact90MiB_is_rejected(self):
        self.assertEqual(p.archive_size(89*1024**2),89*1024**2)
        for size in (90*1024**2,90*1024**2+1,0,-1,True):
            with self.assertRaises(RuntimeError):p.archive_size(size)

    def test_unknown_or_nonaccepted_seal_is_rejected(self):
        good={'protocol':p.PROTOCOL,'status':'BATCH_ACCEPTED','formal_acceptance':True,'P2_6_complete':False,'global_validation_scope':'batch_boundary'}
        p.require_accepted(good)
        for key,value in (('formal_acceptance',False),('P2_6_complete',True),('status','PENDING'),('protocol','old'),('global_validation_scope','per_step')):
            with self.assertRaises(RuntimeError):p.require_accepted({**good,key:value})

    def test_malformed_exit_is_not_a_failed_or_successful_process(self):
        good={'exit_code':0,'stop_reason':None,'seconds':0.1,'sampled_peak_tree_rss_bytes':0}
        self.assertEqual(p.process_schema(good),good)
        for key,value in (('exit_code',None),('exit_code',False),('exit_code','0'),('stop_reason','unknown'),('seconds',float('nan')),('seconds',-1),('sampled_peak_tree_rss_bytes',True)):
            with self.assertRaises(RuntimeError):p.process_schema({**good,key:value})
        with self.assertRaises(RuntimeError):p.process_schema({})

    def test_conflicting_same_path_refs_are_not_freshly_re_pinned(self):
        item={'path':'/synthetic','bytes':1,'sha256':'0'*64}
        self.assertEqual(p.unique([item,item]),[item])
        with self.assertRaises(RuntimeError):p.unique([item,{**item,'sha256':'1'*64}])

    def test_synthetic_pin_change_detected_by_post_byte_read(self):
        with tempfile.TemporaryDirectory(prefix='STATIC-',dir=Path(__file__).parent) as tmp:
            source=Path(tmp)/'input.json';source.write_text('{"ok":true}')
            expected=p.pin(source);reader=p.Readonly();self.assertEqual(reader.read(expected),{'ok':True})
            source.write_text('{"ok":false}')
            with self.assertRaises(RuntimeError):reader.postcheck()

    def test_readonly_input_checks_never_write_providers(self):
        with tempfile.TemporaryDirectory(prefix='STATIC-',dir=Path(__file__).parent) as tmp:
            source=Path(tmp)/'input.bin';source.write_bytes(b'abc');before=source.stat()
            reader=p.Readonly();reader.check(p.pin(source));reader.postcheck();after=source.stat()
            self.assertEqual((before.st_size,before.st_mtime_ns,before.st_ino),(after.st_size,after.st_mtime_ns,after.st_ino))

if __name__=='__main__':unittest.main(verbosity=2)
