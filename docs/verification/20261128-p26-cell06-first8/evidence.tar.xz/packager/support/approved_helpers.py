"""Pinned read-only helper imports. No old main/step/prepare is executed."""
import hashlib
import importlib
import json
from pathlib import Path
import sys
from types import SimpleNamespace

sys.dont_write_bytecode=True
OLD_ROOT=Path('/workspace/p26-cell06-source-candidate-20261128/runner')
OLD_DELIVERY_SHA='d14f188c6e011a5576db429e79378bb3bf9b1d8d080ff37584cbbb699008b462'
OLD_STAGE_SHA='83affec77d951a27ec2b7a172fea4e8c43c1d64579f173e275521b45689ccb41'
FOUNDATION_SHA='d528a2f388f10c22b89c218e675b534a76de129de50054fd1dc4a68e66398ad1'
GRAPH_SHA='0c0930dc27e9ee532ac4a8c78afb2dfb5c9cf40a364076e50cddae7f4cf8dd02'
OLD_INPUT='ImbalancedChen.P2OriginalSaving19Geometry06ScalableInput'
OLD_DATA=['ImbalancedChen.P2OriginalSaving19ArchiveGeometryData06','ImbalancedChen.P2OriginalSaving19ArchiveMomentData06']
TARGETS=['ImbalancedChen.P2OriginalSaving19Moment06Input','ImbalancedChen.P2OriginalSaving19Geometry06ScalableActive8EnumerationBlock000']


def pin(path):
    path=Path(path);h=hashlib.sha256();size=0
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b);size+=len(b)
    return {'path':str(path.absolute()),'bytes':size,'sha256':h.hexdigest()}


def require(ok,message):
    if not ok:raise RuntimeError(message)


def load():
    delivery=OLD_ROOT/'DELIVERY_MANIFEST.json'
    require(pin(delivery)['sha256']==OLD_DELIVERY_SHA,'Old reviewed helper delivery differs')
    manifest=json.loads(delivery.read_text());known={r['path']:r for r in manifest['members']}
    for name in ('controller.py','evidence.py','templates.py'):
        path=OLD_ROOT/name;require(pin(path)==known[str(path)],'Old helper source differs: '+name)
    before=list(sys.path);names=('evidence','templates','controller');saved={n:sys.modules.get(n) for n in names}
    for name in names:sys.modules.pop(name,None)
    sys.path.insert(0,str(OLD_ROOT))
    try:
        evidence=importlib.import_module('evidence');templates=importlib.import_module('templates');controller=importlib.import_module('controller')
    finally:
        sys.path[:]=before
        for name in names:
            if saved[name] is None:sys.modules.pop(name,None)
            else:sys.modules[name]=saved[name]
    for module,name in [(evidence,'evidence.py'),(templates,'templates.py'),(controller,'controller.py')]:
        require(Path(module.__file__).resolve()==OLD_ROOT/name,'Wrong imported helper identity')
    return SimpleNamespace(evidence=evidence,templates=templates,controller=controller,delivery=pin(delivery),
                           code=[known[str(OLD_ROOT/n)] for n in ('controller.py','evidence.py','templates.py')])


OLD=load()
