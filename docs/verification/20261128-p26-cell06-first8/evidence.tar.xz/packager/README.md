# Readonly accepted-first8 evidence packager candidate

This program archives an already accepted first8 batch. It does not execute Lean/lake/MCP, replay a proof, run a controller mode, qualify1504 again, restore canonical objects, create a PENDING marker, publish a context, or write sticky state. It does not import family_engine/family_controller. The only imported provider helper is the pinned readonly normal/full-owned parser; it parses existing logs without rerunning the audit.

All provider files are readonly. Missing/inconsistent evidence raises an error with no repair. Only this output directory receives exclusive-created MANIFEST.json, evidence.tar.xz and CAPSULE.json. Root supplies MCP_SEED.json, MCP_FREEZE.json and MCP_RUN.json after the actual jobs have ended successfully. Root executes packaging later; implementation only ran8 pure/synthetic static guard tests and CLI help. No actual package/archive was created by the implementation agent.

Run exactly after root has the real accepted seal pin and has reviewed this packager:

```bash
python -B /workspace/p26-cell06-family-first8-evidence-20261128/package_first8.py \
  --packager-sha256 PACKAGER_SHA_FROM_PACKAGER_DELIVERY \
  --seal-sha256 ACTUAL_FIRST8_SEAL_SHA_FROM_SUCCEEDED_RUN_OUTPUT
```

The packager pins the known FAMILY c172b52d…, BASE_CONTEXT397fa429…, first8 BATCH090b47d0…, source graph0c0930dc…, FINALf26363a1… and candidatee79eb12a…. The external seal SHA is never predicted. It must match the existing BATCH_ACCEPTED and root's untruncated succeeded MCP_RUN output. No1512/canonical/shared claim is emitted unless every mode/accepted context verifies.

The verifier reconstructs24 exact-attempt COMMAND/LOCAL_INPUTS/output.log/PROCESS_RETURN/RESULT/PENDING chains under the required protocol, key/mode/argv/environment identities. It compares every local D selector against the frozen source/helper/code/runtime and preceding mode/pending-object prefix. It parses the8 existing full-owned logs, retaining dynamic canonical/shared/freshalias/type/axiom checks and the complete actual importset. It verifies8 source/canonical object pairs, the8 exact accepted contexts and the complete sealed D namespace. Global PRE/POST reports must name the complete frozen G selector, true matched status, exact file/byte totals and expected map digest. It checks actual G/pinned-reference bytes in one deduplicated readonly transaction; this is an evidence-presence check, not a second proof or another global validation window. Post-archive reads repeat only archive member bytes, not the full inherited external/object/evidence G.

Archive payload includes FAMILY, BASE_CONTEXT, PARENT_CERTIFICATE, BASE_GLOBAL_INPUTS, EVIDENCE_TRANSPORT_MAP, NORMAL_BARRIERS, SOURCE_GRAPH, the complete managed first8 epoch (24 full attempts,8 contexts,8 helpers, all state and contracts),8 source/object pairs, raw2JSON, FINAL/candidate13 reviewed members/36-host report/parent delivery, binding design, packager/support source and root's3 MCP records. Parent1504 source/object selections,555 native artifacts, runtime/mathlib externals and the historical310MB physical evidence copies remain explicit exact pinned refs in MANIFEST. Their payloads are not copied wholesale into the archive.

Every archive member has an exact manifest pin. Compressed archive size must be strictly below90MiB. Every extracted member is compared byte-for-byte against its source, every name is checked for traversal/duplication, and all archive source pins are read again before CAPSULE is written. A failed attempt retains partial output as evidence; outputs cannot be overwritten automatically.

CAPSULE reports exactly8 newly accepted owners, current1512, dynamic canonical/shared counts, actual24 process/D timings, original global boundary timings and root's actual seed/freeze/run metrics. It separates packaging reference checks from original proof evidence. Cell06_integral_complete and P2_6_complete remain false; other geometry/moment/finite owners and postfinite17 are outside this capsule.

Actual root coldseed reference: elapsed109.4262s, qualification68.328873495s, materialization16.538405603s, coldread23.720494744s, copyupper1302602095bytes, peak321581056bytes. These human-supplied values are context only; the capsule takes exact values from the pinned FAMILY fields and root MCP_SEED record. First8 job metrics/seal/1512 are read only after actual success, not assumed by this candidate delivery.

Unverified here: actual archive size/member count/readback, production packager runtime/RSS and successful execution against the eventual first8 seal. The static suite does not substitute for that root-run packaging verification. No original source/parser/reader/data or accepted object is replaced.
