#!/usr/bin/env python3
"""Readonly accepted-first8 evidence packaging; never runs/repeats a proof mode."""
import argparse
import hashlib
import importlib.util
import io
import json
import math
from pathlib import Path
import sys
import tarfile
import time
sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent
ROOT=Path('/workspace/p26-cell06-family-20261128')
FAMILY=ROOT/'families/main'
EPOCH=FAMILY/'batches/first8'
PROTOCOL='family_batch_global_boundary_v1'
MODES=('normal','stock-leanchecker','full-owned')
OWNERS=['ImbalancedChen.P2OriginalSaving19Geometry06ScalableActive8EnumerationBlock'+str(i).zfill(3) for i in range(1,9)]
FAMILY_SHA='c172b52da388a8f068bafa925cfd9da8d8b1b47b270d93b3e9a157a17d1a522d'
BASE_SHA='397fa4294fc51aa8a5008b1be86e774aee53049a7b264a2d01ba666860466d94'
BATCH_SHA='090b47d0f03e05a8cf9ac7192903453679845585ae05a5a2d98671a86128eb63'
FINAL_SHA='f26363a19799e72deb1842e9befa3d204e8b603b262ecc08a132516bee86ec25'
CANDIDATE_SHA='e79eb12a90f34e794e0d9c8cd60c6c8c77eba1999625fa1962be2e6503736bde'
GRAPH_SHA='0c0930dc27e9ee532ac4a8c78afb2dfb5c9cf40a364076e50cddae7f4cf8dd02'
PARENT_SHA='c19494c887e8768213dfb8c15b43fc36f2f52c72d527a86f8095f4a66f25dcb8'
HELPER=Path('/workspace/p26-cell06-batch-boundary-20261128/approved_helpers.py')
HELPER_SHA='4e35f4d11c38e76ece4bdc429476e4fa4746c3c082f8db8eaea42b91d7a156bc'
PROCESS_FIELDS={'exit_code','stop_reason','seconds','sampled_peak_tree_rss_bytes'}
MAX_ARCHIVE=90*1024**2


def require(ok,message):
    if not ok:raise RuntimeError(message)


def bytes_pin(path,raw):return {'path':str(Path(path).absolute()),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}


def pin(path):
    path=Path(path);h=hashlib.sha256();size=0
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):h.update(block);size+=len(block)
    return {'path':str(path.absolute()),'bytes':size,'sha256':h.hexdigest()}


def unique(items):
    values={}
    for item in items:
        require(set(item)=={'path','bytes','sha256'},'Malformed pin fields')
        require(values.setdefault(item['path'],item)==item,'Conflicting expected pin: '+item['path'])
    return [values[path] for path in sorted(values)]


def safe_name(name):
    path=Path(name)
    require(not path.is_absolute() and name not in ('','.') and '..' not in path.parts and '\\' not in name,'Unsafe archive member name')
    return name


def write_bytes(path,raw):
    path=Path(path)
    require(path.parent==OUT and not path.is_symlink(),'Only exclusive output-root files may be written')
    with path.open('xb') as f:f.write(raw);f.flush()
    return pin(path)


def process_schema(value):
    require(PROCESS_FIELDS<=set(value),'Incomplete process status')
    require(type(value['exit_code']) is int,'Invalid process exit code')
    require(value['stop_reason'] is None or value['stop_reason'] in ('aggregate_tree_rss_limit','disk_reserve_512_MiB','wall_timeout'),'Unknown process stop reason')
    require(type(value['seconds']) in (int,float) and math.isfinite(value['seconds']) and value['seconds']>=0,'Invalid process seconds')
    require(type(value['sampled_peak_tree_rss_bytes']) is int and value['sampled_peak_tree_rss_bytes']>=0,'Invalid process RSS')
    return {key:value[key] for key in PROCESS_FIELDS}


def archive_size(size):
    require(type(size) is int and 0<size<MAX_ARCHIVE,'Compressed evidence must be strictly<90MiB; oversized archive retained as failure evidence')
    return size


def require_accepted(value):
    require(value['protocol']==PROTOCOL and value['status']=='BATCH_ACCEPTED' and value['formal_acceptance'] is True
            and value['P2_6_complete'] is False and value['global_validation_scope']=='batch_boundary','Existing seal is not accepted under the required protocol')


class Readonly:
    def __init__(self):self.expected={};self.verified=set();self.json_cache={};self.pre_bytes=0
    def check(self,item):
        require(set(item)=={'path','bytes','sha256'},'Malformed exact pin')
        require(self.expected.setdefault(item['path'],item)==item,'Conflicting reference pin')
        if item['path'] not in self.verified:
            actual=pin(item['path']);require(actual==item,'Pinned input differs: '+item['path'])
            self.pre_bytes+=actual['bytes'];self.verified.add(item['path'])
        return item
    def read(self,item):
        self.check(item)
        if item['path'] not in self.json_cache:
            raw=Path(item['path']).read_bytes();require(bytes_pin(item['path'],raw)==item,'Pinned JSON bytes changed while reading')
            self.json_cache[item['path']]=json.loads(raw)
        return self.json_cache[item['path']]
    def rooted(self,path,sha):
        item=pin(path);require(item['sha256']==sha,'External root SHA differs: '+str(path))
        return self.read(item),item
    def postcheck(self,items=None):
        total=0;started=time.monotonic();selected=unique(self.expected.values() if items is None else items)
        for item in selected:
            actual=pin(item['path']);require(actual==item,'Input changed during packaging: '+item['path']);total+=actual['bytes']
        return {'files_checked':len(selected),'bytes_read':total,'seconds':time.monotonic()-started,'matched':True,'scope':'Archive member postcheck only; retained G refs are streamed once during readonly verification. No proof mode repeated.'}


def load_parser(reader):
    helper_pin=reader.check({**pin(HELPER),'sha256':HELPER_SHA})
    spec=importlib.util.spec_from_file_location('_p26_first8_readonly_parser',HELPER)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    for item in [module.OLD.delivery,*module.OLD.code]:reader.check(item)
    return module.OLD,helper_pin


def environment(epoch,family):
    sysroot=family['environment']['sysroot']
    return {'HOME':str(epoch/'home'),'TMPDIR':str(epoch/'tmp'),'LANG':'C.UTF-8','LC_ALL':'C.UTF-8','TZ':'UTC',
            'LEAN_PATH':family['lean_path'],'LEAN_NUM_THREADS':'1','OMP_NUM_THREADS':'1','LEAN_SYSROOT':sysroot,'PATH':sysroot+'/bin:/usr/bin:/bin'}


def environment_sha(value):return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()


def argv(family,owner,mode):
    flags=['--trust=0','-DwarningAsError=true','-j1',f'-M{family["rss_gib"]*1024}','-DmaxRecDepth=1000000','-DmaxHeartbeats=0']
    if mode=='normal':return [family['runtime']['lean']['path'],*flags,'-o','__NORMAL_OUTPUT__',str(FAMILY/'project'/Path(owner.replace('.','/')).with_suffix('.lean'))]
    if mode=='stock-leanchecker':return [family['runtime']['leanchecker']['path'],'--verbose',owner]
    require(mode=='full-owned','Unknown proof mode')
    return [family['runtime']['lean']['path'],*flags,str(EPOCH/'helpers'/(owner+'.Owned.lean'))]


def verify_attempt(r,old,family,batch,fp,bp,pre,owner,mode,marker_pin,history,pending):
    marker=r.read(marker_pin);attempt=Path(marker_pin['path']).parent
    require(attempt.parent==EPOCH/'steps'/owner/mode and marker_pin['path']==str(attempt/'PENDING.json'),'Transplanted mode marker')
    require(list(attempt.parent.iterdir())==[attempt],'Exactly one immutable attempt per first8 owner/mode required')
    expected_names={'COMMAND.json','LOCAL_INPUTS.json','output.log','PROCESS_RETURN.json','RESULT.json','PENDING.json'}|({'normal.olean'} if mode=='normal' else set())
    require({path.name for path in attempt.iterdir() if path.is_file()}==expected_names,'Unknown/missing attempt artifact')
    ident={'protocol':PROTOCOL,'family':fp,'batch':bp,'key':owner,'mode':mode,'global_validation_scope':'batch_boundary','batch_pre':pre,
           'environment_sha256':batch['environment_sha256'],'argv':argv(family,owner,mode),'cwd':str(FAMILY/'project'),
           'timeout':family['wall_seconds'],'rss_bytes':family['rss_gib']*1024**3}
    require(marker['identity']==ident,'Mode contract/key/mode/env/argv transplant')
    require(marker['result']['path']==str(attempt/'RESULT.json'),'Result belongs to another attempt')
    result=r.read(marker['result']);require(result['command']['path']==str(attempt/'COMMAND.json'),'Command belongs to another attempt')
    command=r.read(result['command']);require(command['identity']==ident,'Command identity differs')
    require(command['actual_argv']==[str(attempt/'normal.olean') if item=='__NORMAL_OUTPUT__' else item for item in ident['argv']],'Actual argv differs')
    require(command['local_inputs']['path']==str(attempt/'LOCAL_INPUTS.json'),'D belongs to another attempt')
    local=r.read(command['local_inputs'])
    helpers=[item for item in batch['helpers'] if item['path']==str(EPOCH/'helpers'/(owner+'.Owned.lean'))]
    require(len(helpers)==1,'Wrong helper selector')
    expected_local=[family['project_sources'][owner],helpers[0],*family['code_pins'],*family['runtime'].values()]
    for record in history:
        expected_local += [record[key] for key in ('marker','result','command','log','local_inputs','process_return')]
        if record['object']:expected_local.append(record['object'])
    for name,record in pending.items():
        expected_local += [record['object'],{**record['object'],'path':str(FAMILY/'objects'/Path(name.replace('.','/')).with_suffix('.olean'))}]
    require(local==unique(expected_local),'Original D selector differs from exact mode prefix')
    for item in local:r.check(item)
    require(result['log']['path']==str(attempt/'output.log') and result['process_return']['path']==str(attempt/'PROCESS_RETURN.json'),'Log/process return transplant')
    r.check(result['log']);returned=r.read(result['process_return'])
    require(returned['identity']==ident and returned['protocol']==PROTOCOL and returned['command']==result['command'] and returned['log']==result['log']
            and returned['object']==result.get('object') and returned['formal_acceptance'] is False
            and returned['status']=='PROCESS_RETURNED_PENDING_LOCAL_AND_GLOBAL_CHECKS','Durable process return chain differs')
    require(set(returned['process_result'])==PROCESS_FIELDS and process_schema(returned['process_result'])==process_schema(result),'Process return/result status differs')
    require(result['exit_code']==0 and result['stop_reason'] is None,'Mode did not succeed')
    require(result['protocol']==PROTOCOL and result['global_validation_scope']=='batch_boundary' and result['formal_acceptance'] is False and 'postcheck' not in result,'False per-step global/formal claim')
    require(result['local_post']=={'inputs':command['local_inputs'],'all_local_files_matched':True,'file_count':len(local)},'D postcheck differs')
    if mode=='normal':
        require(result['object']['path']==str(attempt/'normal.olean'),'Normal artifact is not permanent exact-attempt output');r.check(result['object'])
    else:require(result.get('object') is None,'Non-normal mode claims an object')
    log_raw=Path(result['log']['path']).read_bytes();require(bytes_pin(result['log']['path'],log_raw)==result['log'],'Log changed while parsing')
    text=log_raw.decode();require('sorryAx' not in text,'Forbidden sorryAx')
    if mode=='normal':parsed=old.controller.normal_validator(text,result)
    elif mode=='stock-leanchecker':parsed={'stock_leanchecker_exit_zero':True}
    else:parsed=old.evidence.validate_audit(text,[owner],set(family['base_catalog'])|set(OWNERS[:OWNERS.index(owner)+1]),family['external_modules'])
    expected_marker={'protocol':PROTOCOL,'status':'NORMAL_SUCCEEDED_PENDING_GLOBAL' if mode=='normal' else 'PROCESS_VALIDATED_PENDING_GLOBAL',
        'identity':ident,'result':marker['result'],'process_return':result['process_return'],'validated':parsed,'formal_acceptance':False,'batch_post':None,'P2_6_complete':False}
    require(marker==expected_marker,'Pending evidence differs from original parser result/identity')
    return {'owner':owner,'mode':mode,'marker':marker_pin,'result':marker['result'],'command':result['command'],'log':result['log'],
            'local_inputs':command['local_inputs'],'process_return':result['process_return'],'object':result.get('object'),'validated':parsed,'process':result}


def job_record(r,name,key,expected):
    item=pin(OUT/name);value=r.read(item);status=value['status']
    require(status['status']=='succeeded' and status['exit_code']==0 and status['ended_at'] is not None
            and status.get('log_truncated') is False and status.get('log_discarded_bytes')==0,'MCP record did not complete without truncation')
    output=json.loads(value['output']);require(output[key]==expected,'MCP output root pin differs from accepted evidence')
    return item,status,output


def verify_existing(seal_sha):
    r=Readonly();started=time.monotonic()
    seal,sp=r.rooted(EPOCH/'state/BATCH_ACCEPTED.json',seal_sha);require_accepted(seal)
    require(not (EPOCH/'state/INTEGRITY_FAILED.json').exists() and not (FAMILY/'state/INTEGRITY_FAILED.json').exists(),'Observed integrity failure')
    final,final_pin=r.rooted(ROOT/'DELIVERY_MANIFEST.json',FINAL_SHA)
    candidate,candidate_pin=r.rooted(ROOT/'DELIVERY_CANDIDATE_v1.json',CANDIDATE_SHA)
    require(final['candidate']==candidate_pin and final['members']==candidate['members'] and final['host_report']==candidate['host_report'],'Reviewed final/candidate references differ')
    require(final['formal_acceptance'] is False and final['P2_6_complete'] is False,'Controller delivery cannot claim a proof')
    require(len(final['members'])==13,'Reviewed member count differs')
    for item in final['members']:r.check(item)
    host=r.read(final['host_report']);require(host['tests']==36 and host['failures']==host['errors']==0 and host['Lean_commands']==host['MCP_jobs']==0,'Host evidence differs')
    r.check(final['parent_delivery']);r.check(final['binding_design'])
    family,fp=r.rooted(FAMILY/'FAMILY.json',FAMILY_SHA);batch,bp=r.rooted(EPOCH/'BATCH.json',BATCH_SHA);base,base_pin=r.rooted(FAMILY/'BASE_CONTEXT.json',BASE_SHA)
    require(family['protocol']==batch['protocol']==PROTOCOL and family['family_root']==str(FAMILY),'Family identity differs')
    require(batch['family']==seal['family']==fp and seal['batch']==bp and family['base_context']==batch['parent_context']==seal['parent_context']==base_pin,'Accepted root identity differs')
    require(batch['owners']==seal['owners']==OWNERS and len(seal['pending_mode_receipts'])==24 and batch['epoch_index']==1 and batch['accepted_before']==[],'Not exact first8')
    require(batch['concurrency']==1 and batch['failure_policy']=='atomic_all_declared_owners' and batch['normal_success_recompile_allowed'] is False,'Wrong batch policy')
    require(base['formal_acceptance'] is False and base['verified_parent_formal_acceptance'] is True and base['original_accepted_context']['sha256']==PARENT_SHA
            and len(base['project_closure'])==1504 and base['project_closure']==family['base_catalog'],'Wrong inherited1504 transport')
    certificate=r.read(family['certificate']);transport=r.read(family['transport']);barriers=r.read(family['normal_barriers_manifest'])
    require(base['certificate']==family['certificate'] and certificate['accepted_context']==base['original_accepted_context'] and certificate['verified_parent_formal_acceptance'] is True,'Parent certificate differs')
    require(barriers==family['normal_barriers'] and len(barriers)==5 and sum(row['status']=='old_normal_forbidden' for row in barriers)==2,'Inherited normal ledger differs')
    require(transport['protocol']==PROTOCOL and transport['parent_context']==base['original_accepted_context'] and transport['same_source_graph']==family['graph'] and transport['original_identity_retained'] is True,'Historical transport identity differs')
    graph=r.read(family['graph']);require(family['graph']['sha256']==GRAPH_SHA,'Source graph differs')
    remaining=[owner for owner in graph['topological_order'] if owner not in family['base_catalog']]
    require(len(graph['entries'])==334 and len(remaining)==329 and remaining[:8]==OWNERS,'Not exact frozen graph next8')
    spec=r.read(batch['global_inputs']);baseline=r.read(family['base_global_inputs'])
    require(spec['protocol']==PROTOCOL and spec['family']==fp and spec['parent_context']==base_pin and spec['baseline']==family['base_global_inputs'],'G selector differs')
    require(spec['batch_static']==batch['helpers']+[batch['whitelist']] and r.read(batch['whitelist'])==OWNERS,'Static helper/whitelist selector differs')
    require(spec['prefix_inputs']==unique([base_pin]+[row['selected_object'] for row in family['base_catalog'].values()]),'First epoch inherited prefix selector differs')
    global_rows=unique(list(baseline)+spec['prefix_inputs']+spec['batch_static']+[batch['global_inputs'],family['base_global_inputs'],fp,bp])
    expected_map=hashlib.sha256(b''.join(json.dumps(item,sort_keys=True,separators=(',',':')).encode()+b'\n' for item in global_rows)).hexdigest()
    for purpose in ('PRE','POST'):
        report=r.read(seal['global_'+purpose.lower()])
        require(report['protocol']==PROTOCOL and report['purpose']==purpose and report['family']==fp and report['batch']==bp
                and report['global_inputs']==batch['global_inputs'] and report['matched'] is True and report['mismatches']==[]
                and report['global_validation_scope']=='batch_boundary' and report['files_checked']==len(global_rows)
                and report['bytes_read']==sum(item['bytes'] for item in global_rows) and report['actual_map_sha256']==expected_map,'Real global boundary report differs')
    anchor=pin(EPOCH/'state/GLOBAL_PRE.json');require(r.read(anchor)=={'snapshot':seal['global_pre'],'formal_acceptance':False},'Original PRE anchor differs')
    require(environment_sha(environment(EPOCH,family))==batch['environment_sha256'],'Final allowlist environment differs')
    old,helper_pin=load_parser(r)
    history=[];pending={}
    for index,owner in enumerate(OWNERS):
        for mode_index,mode in enumerate(MODES):
            record=verify_attempt(r,old,family,batch,fp,bp,seal['global_pre'],owner,mode,seal['pending_mode_receipts'][index*3+mode_index],history,pending)
            history.append(record)
            if mode=='normal':pending[owner]=record
    catalog=dict(family['base_catalog']);previous=base_pin;contexts=[]
    for index,owner in enumerate(OWNERS):
        path=EPOCH/'accepted-contexts'/(owner+'.json');item=pin(path);value=r.read(item)
        normal=pending[owner]['object'];obj={**normal,'path':str(FAMILY/'objects'/Path(owner.replace('.','/')).with_suffix('.olean'))}
        catalog[owner]={'source':family['project_sources'][owner],'selected_object':obj,'origin':'accepted_family_batch_global_boundary_v1','normal_success_artifact':normal}
        expected={'protocol':PROTOCOL,'formal_acceptance':True,'P2_6_complete':False,'family':fp,'batch':bp,'batch_seal':sp,
            'accepted_parent':previous,'epoch_parent':base_pin,'project_closure':dict(catalog),'native_artifacts':family['native_artifacts'],'runtime':family['runtime'],
            'lean_path':family['lean_path'],'accepted_in_this_batch':OWNERS[:index+1],'accepted_since_family_base':OWNERS[:index+1],
            'global_validation_scope':'batch_boundary','scope':'Exact atomic1..8-owner family batch; no global P2.6 claim.'}
        require(value==expected and len(value['project_closure'])==1505+index,'Accepted prefix context differs')
        r.check(obj);r.check(catalog[owner]['source']);contexts.append(item);previous=item
    require(len(catalog)==1512,'No1512 claim without all8 actual contexts')
    expected_delta=[]
    for record in history:
        expected_delta += [record[key] for key in ('marker','result','command','log','local_inputs','process_return')]
        expected_delta += r.read(record['local_inputs'])
        if record['object']:expected_delta.append(record['object'])
    managed={EPOCH/'BATCH.json',EPOCH/'GLOBAL_INPUTS.json',EPOCH/'WHITELIST.json',*(Path(item['path']) for item in contexts),*(Path(item['path']) for item in batch['helpers'])}
    for record in history:
        for path in Path(record['command']['path']).parent.iterdir():
            require(path.is_file(),'Unknown nested mode artifact');managed.add(path);expected_delta.append(pin(path))
    for path in (EPOCH/'state').iterdir():
        require(path.is_file() and path.suffix=='.json' and (path.name in ('GLOBAL_PRE.json','BATCH_ACCEPTED.json') or path.name.startswith(('PRE-','POST-','RESUME-'))),'Unknown state artifact')
        managed.add(path)
        if path.name!='BATCH_ACCEPTED.json':expected_delta.append(pin(path))
    require(seal['delta_inputs']==unique(expected_delta),'Sealed complete D selector differs')
    require({path for path in EPOCH.rglob('*') if path.is_file()}==managed,'Managed epoch includes unknown/missing artifact')
    require({path.name for path in (EPOCH/'steps').iterdir()}==set(OWNERS),'Wrong step owner namespace')
    require({path.name for path in (EPOCH/'accepted-contexts').iterdir()}=={owner+'.json' for owner in OWNERS},'Wrong context namespace')
    require({path for path in (FAMILY/'batches').iterdir()}=={EPOCH},'Later/unsealed epoch exists; freeze this capsule before further batches')
    require({str(path) for path in (FAMILY/'project').rglob('*') if path.is_file()}==set(family['project_files']),'Family source namespace differs')
    expected_objects={row['selected_object']['path'] for row in catalog.values()}|{row['path'] for row in family['native_artifacts']}
    require({str(path) for path in (FAMILY/'objects').rglob('*') if path.is_file()}==expected_objects,'Full selected object/native namespace differs')
    require({str(path) for path in (FAMILY/'evidence').rglob('*') if path.is_file()}=={row['physical']['path'] for row in transport['rows']},'Historical physical evidence namespace differs')
    for row in transport['rows']:
        require(row['identity_preserved'] is True and all(row['logical'][key]==row['physical'][key] for key in ('bytes','sha256')),'Transport edited historical bytes/identity')
        r.check(row['logical']);r.check(row['physical'])
    for item in global_rows+seal['delta_inputs']:r.check(item)
    for info in catalog.values():r.check(info['source']);r.check(info['selected_object'])
    for item in family['native_artifacts']:r.check(item)
    for item in old.controller.RAWS:r.check(item)
    require(len(family['raw_copies'])==2 and sorted((row['bytes'],row['sha256']) for row in family['raw_copies'])==sorted((row['bytes'],row['sha256']) for row in old.controller.RAWS),'Raw2JSON copies differ')
    for item in family['raw_copies']:r.check(item)
    seed_job=job_record(r,'MCP_SEED.json','family',fp);freeze_job=job_record(r,'MCP_FREEZE.json','batch',bp);run_job=job_record(r,'MCP_RUN.json','batch_accepted',sp)
    require(seed_job[2]['prepared_not_executed'] is True and seed_job[2]['Lean_commands']==0 and freeze_job[2]['Lean_commands']==0
            and run_job[2]['formal_acceptance'] is True and run_job[2]['P2_6_complete'] is False,'MCP output scope differs')
    return {'reader':r,'family':family,'batch':batch,'seal':seal,'family_pin':fp,'base_pin':base_pin,'batch_pin':bp,'seal_pin':sp,'contexts':contexts,
        'catalog':catalog,'managed':managed,'history':history,'final':final,'final_pin':final_pin,'candidate_pin':candidate_pin,'transport':transport,
        'old':old,'helper_pin':helper_pin,'jobs':{'seed':seed_job,'freeze':freeze_job,'run':run_job},'verification_seconds':time.monotonic()-started,
        'global_rows':global_rows,'baseline':baseline}


def package(seal_sha,packager_sha):
    own=pin(Path(__file__));require(own['sha256']==packager_sha,'Externally supplied packager SHA differs')
    require(OUT==Path('/workspace/p26-cell06-family-first8-evidence-20261128'),'Unexpected writable output root')
    for name in ('MANIFEST.json','CAPSULE.json','evidence.tar.xz'):require(not (OUT/name).exists(),'Exclusive evidence outputs already exist')
    verified=verify_existing(seal_sha);r=verified['reader'];family=verified['family'];seal=verified['seal'];members={}
    def add(name,path,expected=None):
        safe_name(name);path=Path(path);require(name not in members,'Repeated archive name')
        item=expected or pin(path);require(str(path)==item['path'],'Member physical path differs');r.check(item);members[name]=item
    for name in ('FAMILY.json','BASE_CONTEXT.json','PARENT_CERTIFICATE.json','BASE_GLOBAL_INPUTS.json','EVIDENCE_TRANSPORT_MAP.json','NORMAL_BARRIERS.json'):
        add('family/'+name,FAMILY/name)
    add('SOURCE_GRAPH.json',family['graph']['path'],family['graph'])
    for path in sorted(verified['managed']):add('epoch/'+str(path.relative_to(EPOCH)),path)
    for owner in OWNERS:
        info=verified['catalog'][owner];rel=owner.replace('.','/')
        add('sources/'+rel+'.lean',info['source']['path'],info['source']);add('objects/'+rel+'.olean',info['selected_object']['path'],info['selected_object'])
    for item in family['raw_copies']:add('raw/'+Path(item['path']).name,item['path'],item)
    add('programs/DELIVERY_MANIFEST.json',verified['final_pin']['path'],verified['final_pin'])
    add('programs/DELIVERY_CANDIDATE_v1.json',verified['candidate_pin']['path'],verified['candidate_pin'])
    for item in verified['final']['members']:add('programs/'+str(Path(item['path']).relative_to(ROOT)),item['path'],item)
    for key in ('host_report','parent_delivery','binding_design'):
        item=verified['final'][key];add('programs/refs/'+key+'.json',item['path'],item)
    add('packager/package_first8.py',__file__,own)
    for name in ('PLAN.md','README.md','PACKAGER_DELIVERY.json','test_packager_static.py','STATIC_TEST_RESULTS.json'):
        add('packager/'+name,OUT/name)
    add('packager/support/approved_helpers.py',HELPER,verified['helper_pin'])
    for item in [verified['old'].delivery,*verified['old'].code]:add('packager/support/old/'+Path(item['path']).name,item['path'],item)
    for name in ('MCP_SEED.json','MCP_FREEZE.json','MCP_RUN.json'):add(name,OUT/name)
    parent_refs=[{'module':owner,'source':info['source'],'selected_object':info['selected_object']} for owner,info in family['base_catalog'].items()]
    references={'parent1504':parent_refs,'native555':family['native_artifacts'],'runtime':family['runtime'],
        'shared_external':r.read(family['certificate'])['shared_external_pins'],'historical_physical_evidence':[row['physical'] for row in verified['transport']['rows']],
        'historical_logical_evidence':[row['logical'] for row in verified['transport']['rows']],
        'scope':'Exact pinned refs retained and byte-checked; their full payloads are deliberately not duplicated into this archive.'}
    scope='Exactly8 Active8EnumerationBlock001..008 added to inherited1504. Other Cell06 modules, integral and globalP2.6 remain open.'
    manifest={'schema':'p26_cell06_family_first8_archive_v1','protocol':PROTOCOL,'formal_acceptance':True,'accepted_project_union':1512,'new_owners':OWNERS,
        'Cell06_integral_complete':False,'P2_6_complete':False,'global_validation_scope':'batch_boundary','members':members,'retained_pinned_references':references,
        'seal':verified['seal_pin'],'family':verified['family_pin'],'batch':verified['batch_pin'],'scope':scope,'proof_modes_repeated_by_packager':0}
    raw_manifest=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode();archive=OUT/'evidence.tar.xz'
    with archive.open('xb') as output,tarfile.open(fileobj=output,mode='w:xz') as tar:
        for name,item in sorted(members.items()):
            raw=Path(item['path']).read_bytes();require(bytes_pin(item['path'],raw)==item,'Member changed before archive write')
            entry=tarfile.TarInfo(name);entry.size=len(raw);entry.mode=0o644;tar.addfile(entry,io.BytesIO(raw))
        entry=tarfile.TarInfo('MANIFEST.json');entry.size=len(raw_manifest);entry.mode=0o644;tar.addfile(entry,io.BytesIO(raw_manifest))
    archive_size(archive.stat().st_size)
    expected_names=set(members)|{'MANIFEST.json'};read_names=[]
    with tarfile.open(archive,'r:xz') as tar:
        for entry in tar:
            require(entry.isfile() and entry.name in expected_names and entry.name not in read_names,'Unexpected/duplicate archive entry')
            raw=tar.extractfile(entry).read();read_names.append(entry.name)
            if entry.name=='MANIFEST.json':require(raw==raw_manifest,'Manifest byte readback differs')
            else:
                item=members[entry.name];require(bytes_pin(item['path'],raw)==item and raw==Path(item['path']).read_bytes(),'Archive member byte readback differs')
    require(set(read_names)==expected_names,'Archive omitted a required member')
    post=r.postcheck(members.values());manifest_pin=write_bytes(OUT/'MANIFEST.json',raw_manifest)
    metrics=[];canonical=shared=0
    for record in verified['history']:
        result=record['process'];metrics.append({'owner':record['owner'],'mode':record['mode'],'seconds':result['seconds'],
            'sampled_peak_tree_rss_bytes':result['sampled_peak_tree_rss_bytes'],'timings':result['timings']})
        if record['mode']=='full-owned':canonical+=record['validated']['canonical_count'];shared+=record['validated']['shared_occurrences']
    totals={'process_seconds':math.fsum(item['seconds'] for item in metrics),
        'D_pre_seconds':math.fsum(item['timings']['local_D_pre_seconds'] for item in metrics),
        'D_post_seconds':math.fsum(item['timings']['local_D_post_seconds'] for item in metrics),
        'mode_validation_seconds':math.fsum(item['timings']['mode_validation_seconds'] for item in metrics)}
    capsule={'schema':'p26_cell06_family_first8_capsule_v1','protocol':PROTOCOL,'formal_acceptance':True,'accepted_project_union':1512,
        'accepted_owners':OWNERS,'new_normal_owners':8,'new_canonical_declarations':canonical,'new_shared_occurrences':shared,
        'Cell06_integral_complete':False,'P2_6_complete':False,'old_normal_recompilations':0,'proof_modes_repeated_by_packager':0,
        'batch_seal':verified['seal_pin'],'family':verified['family_pin'],'base_context':verified['base_pin'],'batch':verified['batch_pin'],
        'current_context':verified['contexts'][-1],'global_pre':r.read(seal['global_pre']),'global_post':r.read(seal['global_post']),
        'mode_metrics':metrics,'mode_metric_totals':totals,'seed_metrics':{key:family[key] for key in ('qualification_seconds','namespace_and_evidence_materialization_seconds','cold_global_readback_seconds','cold_seed_seconds_excluding_qualification','copy_bytes_upper_bound')},
        'job_metrics':{name:record[1] for name,record in verified['jobs'].items()},'archive':pin(archive),'manifest':manifest_pin,
        'archive_readback_members':len(read_names),'archive_members_all_byte_equal':True,'archive_compressed_limit_bytes':MAX_ARCHIVE,
        'retained_reference_counts':{'parent_modules':len(parent_refs),'native_files':len(family['native_artifacts']),
            'shared_external_files':len(references['shared_external']),'historical_physical_files':len(references['historical_physical_evidence']),
            'historical_physical_bytes':sum(item['bytes'] for item in references['historical_physical_evidence'])},
        'packaging_reference_precheck':{'files_checked':len(r.expected),'bytes_read':r.pre_bytes,'verification_seconds':verified['verification_seconds'],'matched':True},
        'packaging_archive_member_postcheck':post,'packager_source':own,'scope':scope,
        'original_full_snapshot_verified':False}
    write_bytes(OUT/'CAPSULE.json',(json.dumps(capsule,ensure_ascii=False,indent=2)+'\n').encode())
    print(json.dumps(capsule,ensure_ascii=False),flush=True)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--seal-sha256',required=True);parser.add_argument('--packager-sha256',required=True)
    args=parser.parse_args();package(args.seal_sha256,args.packager_sha256)


if __name__=='__main__':main()
