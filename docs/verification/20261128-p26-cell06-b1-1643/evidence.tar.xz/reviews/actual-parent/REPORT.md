# Actual B1 parent certificate and cold-seed command review

**Certificate findings: 0 Critical / 0 Important / 0 Minor. The actual certificate is suitable as the next cold-seed input.** Source-review Minor M1 remains explicitly deferred; it is not erased by this certificate result. The exact proposed seed command also has no new findings. No seed, G or proof process was run by this reviewer, and seed/math readiness is not preclaimed.

## Actual outcome and immutable anchors

Actual collector job `f61bd8d7cbcc4f778771bf1bed6a647a` succeeded with exit0,24.83367622899823s wall time,263405568 B peak RSS and22.67s CPU. Its safe local result is `/workspace/p26-cell06-shape-b1-root-execution-20261128/MCP_COLLECT_PARENT_RESULT.json`,923 B, SHA256 `b5be50902e8449294e83f592e3438a9d7d2e48b1fc850dbe8dcf3f585abbffc2`. Output was274 bytes, with no truncation or discarded bytes; the output's complete certificate pin exactly matches the actual file.

Certificate: `/workspace/p26-cell06-shapearrays-b1-controller-20261128/certificates/qualified1642-parent-001.json`, **50229802 B**, SHA256 **`59fef0d4861e5b5a8ead0d605ac587d994de7658b41aaf5ff8b3a876b5021e15`**.

The certificate's exact authority object equals the existing externally pinned real input `INPUT_CONTRACT_001.json` (2462 B,`eb53c0e88da8c88337a32654c5c1a7ba086430c5ccb689b0aea46ec6fb1b8336`). Its context/seal/outputs references equal that contract's pins and were read/hashed as metadata:

| Authority file | Bytes | SHA256 |
|---|---:|---|
| Qualified1642 CURRENT_ACCEPTED_CONTEXT | 4128322 | `e22fc5fc1f9803baa6269e255378b785d39fa669d8324399b7242f9143c0b5fa` |
| VERIFIED_PENDING_PREFIX_CERTIFICATE | 627087 | `7b947ff084e9e175e872d9b310a80f02b64ba88536f83ba63aebf2e1682c4ff6` |
| OUTPUTS_POST | 1165789 | `4a3c5f68eb66e354512853a3e81b30d5d8d4a0250ae27f6b2c43cac57fafb86c` |

The context and seal share exact qualification contract/source-lock/accepted-parent/environment identity, and outputs is the seal's referenced output. The existing independent R2 review1848cf… identifies those same context and seal with0/0/0 findings. The certificate is `formal_acceptance:false`, `verified_parent_formal_acceptance:true`, `executor_calls:0`, `Lean_commands:0`, `P2_6_complete:false`, `original_full_snapshot_verified:false`. Parent acceptance belongs to the existing qualification; this collector did not prove a new owner.

The certificate's controller SOURCE_LOCK is3737 B/`4a3457b38743c7cc2b067a75a3670172208487e372f1cb4c0e40c20810b48109`, and DELIVERY is23106 B/`2dd982733389f16b5346be787a2a0c28e8d2045c01d6376adb58fe8b5caf2ece`. These are the exact final-source-reviewed anchors. The12 production aliases retain an exact eight-alias subset equal to the actual R2 SOURCE_LOCK. The final F1 binding is present before delegated collection/failed-release validation and first legacy configure load. SELF/parent/common/loader bytes were also checked against the frozen lock in this readback. The unchanged complete helper/runtime closure and process guard policy inherit the prior final source review066caa… rather than being replaced by a certificate boolean.

## Catalog, transport and permission relationships

| Inventory | Exact count and cross-check |
|---|---|
| Project catalog |1642, exactly equal to the qualified context; original1641 parent keys plus original pending RowsNode000To014; ShapeArrays absent. |
| Native artifacts |555, exactly equal to qualified context/collected native pins and linked to sealed copy rows. |
| COPY_MAP |4069, exactly equal to the sealed file; unique physical paths and same byte pins as their explicit distinct logical origins. |
| Qualified files |4081, exactly9 qualification metadata pins +4069 copied physical pins + outputs/seal/context. This matches OUTPUTS_POST and the certificate's sorted fixed-file list. |
| Source mappings |143, exactly equal to context and original collected mappings; each graph-logical pin retains a distinct same-byte compiled-source pin linked through the catalog's copy origin. |
| Future source-only rows |191, exactly the graph owners outside the1642 catalog; no future object is installed by qualification. ShapeArrays is included here and has no accepted catalog entry or object-copy row. |
| Qualification input pins |371, exactly the referenced QUALIFIER_INPUTS list. |
| Original pending D/epoch pins |53 /37, exactly equal to the original collected pending descriptors. |

COPY_MAP roles are1641 formal-parent-source,1641 formal-parent-object,555 qualified-native,191 frozen-graph-source-candidate,37 original-unsealed-epoch-evidence,2 original-JSON-copy,1 original-pending-compiled-source and1 qualified-pending-selected-object. All existing1641 catalog entries retain their exact `original_accepted_entry`; catalog source/object and native selections map to the corresponding sealed physical rows. The two raw JSON origin/physical pins are preserved in READBACK.json. The original inode/byte-copy evidence is inherited from the accepted R2 qualification and the actual collector's checked output chain; this reviewer did not reread the copied gigabyte or claim a second independent byte/inode audit.

There are1642 barriers with exactly the1642 catalog membership set, and every row forbids normal,stock-leanchecker,full-owned. Statuses are1641 accepted-membership rows and1 original-pending-three-mode row. The two oldData entries are ArchiveGeometryData06 and ArchiveMomentData06; both retain `old_normal_forbidden` and a null normal receipt. They are not assigned invented normal successes. Every accepted-membership original provenance equals its original collected parent entry.

## Original8p successes and failed tail are not rewritten

The original successful RowsNode000To014 records are identical across collected pending, qualification seal, barrier and qualified catalog. Their original protocol remains `source_revision3_family_batch_global_boundary_v1`, and their COMMAND identities still refer to the old family and geometry8p BATCH. The original attempts are:

| Mode | Original attempt directory |
|---|---|
| normal | `1795850516047259759-1f29aeb5` |
| stock-leanchecker | `1795850521390488467-e5042169` |
| full-owned | `1795850526523393459-4c9126a5` |

The actual COMMAND/RETURN/RESULT/PENDING and LOCAL_INPUTS metadata were read and pinned. Identity, command/log/object references and all original return metrics match; results remain successful exit0/no stop and markers remain pending/formalfalse/batch_post null. Log/object pins remain the previously accepted original evidence, not new executions. The original normal object's pin matches the permanent-normal descriptor and the logical origin of the selected qualified copy. No original identifier is relabeled as a new B1 mode.

The ShapeArrays failed tail remains only normal attempt `1795850553477374435-63a4ed6a`. Its five actual directory members are exactly COMMAND.json,LOCAL_INPUTS.json,PROCESS_RETURN.json,RESULT.json,output.log. The five pinned files, failed anchor and release metadata match. COMMAND identity remains old family/geometry8p/ShapeArrays/normal; RETURN and RESULT agree on exit1/no stop/no object, with no PENDING or normal artifact. The release adds the revision/failed-anchor references without changing the original tuple identity. It does not turn that failed process into a successful normal or a broad retry permission.

The revised334-owner graph keeps333 complete source references exactly equal to v3, and all entry kinds/imports/topological order remain equal. The only changed source is ShapeArrays. A direct text comparison confirms exactly the two declared proof-body substitutions: replace each `simpa only [h.1] using ...` with explicit Fin index introduction and bound transport. Nothing else in that source changes. Source candidate19599 B/`c5bd66975121ec9c7cf89337f35e2c1ad855c43537e354979efccf05c001a8b4` is not accepted by this review or by parent collection.

## Complete G and observed-selector audit, metadata only

The original G list was independently reconstructed from the exact original FAMILY base selector, original geometry8p BATCH selector, prefix/static inputs and selector/family/batch anchors. It exactly equals the certificate's143258 rows, without replacing original physical paths by new aliases. Its canonical pin-map digest and byte sum are:

- Files:143258.
- Declared bytes:16974482127.
- Map SHA256:`7e7563e5852a08e36dcb8181581f1f0dca6e480a5c16f01adb5f4b6467548889`.

These values also equal collected.old_global_expected and the existing accepted qualification's historical fresh-G report. The report explicitly says old_POST_created false. **This readback only checked metadata and canonical pin-list arithmetic. It did not read those16.97GB of G payloads, run a fresh G, or synthesize an old POST.** The forthcoming cold seed must perform its actual full fixed-domain readback.

The observed4500 pins were not trusted as a count alone. Their exact path→full-pin map equals the union required by the frozen reader source: input/authority pins, original qualifier delivery and helper/runtime pins, qualification chain metadata,371 qualifier inputs,4081 qualified files, original pending COMMANDs, environment lock, original FAMILY/BATCH and both original G selector roots. There are0 missing,0 extra and0 conflicting entries. Canonical map SHA256 is `42461ebedfc7854ab4ad5e3b467163befd4dc80267b797181ef0e3ad5cf6ce66`.

The observed list includes2160 .olean and2138 .lean references as well as other native/control facets; those are reference identities, not a claim that this reviewer reread their bodies. The19 authority-D anchors exactly equal the source-defined union of the real authority pins, nine qualification-chain pins and the barrier/release anchors. The six normal-search roots exactly equal the original FAMILY roots plus original-family batches; later seed retains these and adds qualified-stage provenance. No new cross-root normal scan was performed by this review.

## Exact proposed seed command

Command file: `/workspace/p26-cell06-shape-b1-root-execution-20261128/ACTUAL_SEED_COMMAND.txt`,2181 B, SHA256 `c9f748ccc3bf38e79c4acc622999e8249ddc5aae8202a1ea2801835c21af312b`. It was read and AST/argv checked, never executed. SEED_COMMAND_READBACK.json preserves the exact command pin, argv and four checked roots.

It uses env -i with exactly PATH/HOME/TMPDIR/LANG/LC_ALL/TZ and pinned Pythonfa6744… with-I-B. It verifies raw SELF12762/5405…, LOCK3737/4a34…, DELIVERY23106/2dd9… and this actual CERT50229802/59fef0… before compiling/executing verified CLI bytes. SELF is rechecked on reread. The exact seed flag set includes delivery, certificate/path/SHA, family `/workspace/p26-cell06-shapearrays-b1-controller-20261128/families/main`, rss12 and wall2400. That family did not exist at review. HOME/TMPDIR remain independent empty non-symlink root-execution directories outside qualification.

Root's planned external MCP limits are4096MiB/CPU1/1200s for this cold-seed phase. They are invocation parameters, not shell assertions. Family metadata separately records the later proof ceiling13107MiB/3600s/CPU1 and internal12GiB/2400s. There is no substitution of the seed job ceiling for proof-mode limits. The seed command enters only the reviewed independent-copy/cold-G/namespace path, which also revalidates the parent; no Lean or proof mode is requested. It preserves the frozen source/delivery and old qualified stage.

No Important remains in the certificate or exact seed command. Root can use them for the next authorized one-time cold seed. Its actual FAMILY/BASE_CONTEXT/transport/cold-readback outputs still need their own readback after execution. This report does not assert that seed has passed, that any of the three new modes has run, or that1643/Cell06 integral/global P2.6 is established.

## Outputs and execution boundary

READBACK.json:46430 B, SHA256 `7f703d15dab742676e7c720a8bdb3cf0f837229fa48c2760ddfb150c88686853`.

SEED_COMMAND_READBACK.json:4288 B, SHA256 `3be4fc51be78166f5ea985383df8bbff463f99444f3f4999efa873dd5422d7e4`.

The final successful metadata-audit pass read55 explicitly related source/metadata/log files (109921619 bytes including the50MB certificate and original G selector metadata). No compiled-object copy was read. Reviewer calls:0 collector,0 tests,0 candidate imports,0 G,0 large-copy readback,0 Lean/lake/MCP,0 proof credit. All writes belong to this new review directory; providers and frozen sources are unchanged. `formal_acceptance:false`, `original_full_snapshot_verified:false` remain in force.
