# B1 Task1/Task2 原candidate独立静态审查

**结论：changes requested；C/I/M＝0/3/1。** 只审原TASK12三文件，不给新engine/CLI或生产ready。真实1642 qualification及实际input_ready不被重开。

**Pin边界：** 初读三文件均与任务pins完全匹配。随后common更新为19331B/93ef…。经root授权的限定diff，已实读作者task-evidence/task3/shape_common.py并核为19307B/e25a，独立复制成review目录historical-shape_common-e25a.py。当前93ef相对该原字节确实只有line233的一处24B插入：`'scope_owners':[TARGET],`；没有其他删改。parent/loader仍原pin。下面三个load-bearing findings及M1的相关代码均未变，因此继续open；这只补充了精确tiny-diff范围，不是对新engine/CLI的审查或ready。原source logical pin→作者snapshot→独立physical历史副本在REVIEW.json中显式记录，没有猜测重建。

本次没有import/执行candidate，没有测试、collector、seed、G、bulk、Lean、MCP作业或任何production调用；只做源码和AST静态读查，没有修改作者文件或派agent。既有host21 GREEN只是作者历史证据，未重跑，也不当reviewer测试结果。

## F1（important）：Checked final-R2 lock is not bound to the executed delegated helpers

位置：`shape_parent.py:103`，相关行80,101,102,130,133,134，被审SHA `916196650bbdb3fdacc03576e600e7c85f9bbe66f498fa6452ba7e8dc2cc6d70`。

触发：A valid externally pinned authority contract points to the real unchanged R2 lock/files, but the supplied SourceLoader pins revision4_transport/revision4_collect (or their revision4_core dependency) to different helper code.

静态依据：collect_qualified_prefix checks qlock source artifacts at101–103, then executes loader.load aliases at130/133/134; it never compares the loader helper pins with qlock modules. Static AST on the reviewed source found zero loader.pins references.

影响：The code whose bytes were verified need not be the code performing external directory/symlink, exact-revision or original-G selection checks. Another locked helper implementation can omit the final-R2 behavior and still produce the read-only verified-parent certificate. This does not allege that the supplied real authority or helper was actually substituted.

修正方向：Bind the executed helper closure to the checked final-R2 module pins before use. Extra shape modules may coexist; qualifier aliases must not point to different code. If same-byte copied helpers are intended, require an explicit reviewed logical/physical source binding.

建议作者TDD（本次未运行）：With real unchanged qlock files, a differently pinned revision4_transport/core or collect must be rejected before the alternate helper runs; executor calls remain0.

## F2（important）：Seed has no final physical namespace validation

位置：`shape_common.py:235`，相关行132,140,200,205,218,229,230,236，被审SHA `e25a1c3a28c9598fbe4406a4ae8422a2710eb991473f9084bd4b2611b42b9935`。

触发：An unlisted .olean, empty directory or directory symlink is added under the new family after the planned-layout check/copy phase and before seed returns.

静态依据：validate_seed_layout compares only planned dictionary paths. Cold readback hashes listed baseline items. The final collect_qualified_prefix checks the old qualified stage, not the new family. exact_tree exists at132 but has no call in seed_family (also confirmed by static AST).

影响：Task2 can return FAMILY while the actual new namespace differs from its declared fixed baseline. Listed-file hashes do not detect an extra loadable file or unlisted empty/symlink directory. No assumption about later engine detection substitutes for this seed invariant.

修正方向：Derive the exact physical file/directory inventory including generated family metadata and mandatory empty dirs; check actual namespace/symlink ancestry before a seeded family is returned. Failure must stick only inside the new family.

建议作者TDD（本次未运行）：Inject each extra-file/empty-directory/symlink case during seed after planned-layout validation; seed rejects without a usable FAMILY and with0 executor calls/unchanged qualified stage.

## F3（important）：Relative dir_fd mutations escape WriteGuard path interpretation

位置：`shape_common.py:98`，相关行90,94,95,97,99,101，被审SHA `e25a1c3a28c9598fbe4406a4ae8422a2710eb991473f9084bd4b2611b42b9935`。

触发：With cwd inside the new root and WriteGuard active, open an old-stage directory read-only, then call os.open("x", O_CREAT|O_WRONLY, dir_fd=old_dir_fd) or os.mkdir("x", dir_fd=old_dir_fd).

静态依据：The hook accepts relative str/PathLike paths, converts them with Path.absolute() using cwd, and does not handle/reject dir_fd. CPython open audit arguments do not expose that dir_fd; POSIX resolves the actual relative write against it.

影响：The apparent checked path is within the new root while the actual filesystem mutation targets the old stage/provider. Direct copy helpers currently use absolute paths, but the generic guard does not enforce its advertised boundary for this standard-library interface.

修正方向：Reject relative write targets while the guard is active, and reject or correctly handle dir_fd-based mutations. Keep strict no-symlink ancestry checks and no old-root exceptions.

建议作者TDD（本次未运行）：Under active WriteGuard, relative open/mkdir with an outside directory fd raises before any outside file/directory is created. Use isolated host fixtures only.

## M1（minor）：strict_json misses overflow-to-infinity numeric literals

位置：`shape_common.py:31`，相关行25,30，被审SHA `e25a1c3a28c9598fbe4406a4ae8422a2710eb991473f9084bd4b2611b42b9935`。

触发：JSON contains a literal such as1e999/-1e999, including in a nested value.

静态依据：parse_constant rejects NaN/Infinity tokens, but default parse_float can produce float infinity on an overflow literal without invoking parse_constant.

影响：Reject-all-nonfinite policy is incomplete; no evidence suggests the supplied real authority contains this value.

修正方向：Use a finite-checking parse_float or validate parsed floating-point values recursively, preserving duplicate-key rejection.

建议作者TDD（本次未运行）：Nested overflow literals are rejected before Reader accepts authority metadata.

## Spec与质量的限域结论

parent主链具备实际context/seal/output关系、12metadata、4069copy与qualified-stage namespace检查、1642/555与原pending/allmode/oldData结构。failed release有exact5file原namespace、身份/argv/返回/结果检查和333不变+两proof修订委托验证；F1要求把实际执行的委托代码与所检查final-R2锁绑定闭合。

seed计划保留1833源联合、1642 accepted对象、555native、独立restore/evidence copies；没有为未接受graph owner计划对象。copy用exclusive-create/真实SHA/inode readback。固定baseline union保留完整原143258物理G引用及新copies/controls，没有发现削减成report、digest或stat-only的代码。F2专指seed未在返回前验证新family真实namespace；不能用已定义但未调用的exact_tree或后来engine可能的检查代替。

SourceLoader与accepted R2 loader同63e904字节，保留private builtins、source pins和registered nested compile/exec；不据此给未审CLI的SELF/LOCK/isolated模式/stdlib-shadow/guard生命周期端到端通过。

资源备注（不另计finding）：e25a及tiny-diff93ef的common:233均仍记录13107MiB/3600s；24B scope字段没有改变它。plan提出16384MiB/9000s待provider绑定，最终运行资源需后续独立审。这里没有发现生产已执行，也没有批准任何生产命令。

三个Important是原candidate的load-bearing阻断，Minor是严格JSON非有限策略缺口。修改应由作者TDD提交新证据/新pins；随后做final-lock精确diff与另一次engine/CLI审查。本报告不能冒充新版或完整实现的ready。

## Pins

| 被审原源/输入 | bytes | SHA256 |
|---|---:|---|
| `/workspace/p26-cell06-shapearrays-b1-controller-20261128/shape_parent.py` | 16503 | `916196650bbdb3fdacc03576e600e7c85f9bbe66f498fa6452ba7e8dc2cc6d70` |
| `/workspace/p26-cell06-shapearrays-b1-controller-20261128/shape_common.py` | 19307 | `e25a1c3a28c9598fbe4406a4ae8422a2710eb991473f9084bd4b2611b42b9935` |
| `/workspace/p26-cell06-shapearrays-b1-controller-20261128/shape_source_loader.py` | 2731 | `63e9046309a0bb221dd992440ea4064bbd3cd12254fe9cc94beb5050cbd9dc74` |
| `/workspace/p26-cell06-v4-shape-b1-plan-20261128/PLAN.md` | 34168 | `4f23c1867ea7ee1a11ce92c35d34545692498c10d1ebcf34c8d9115214a2613d` |
| `/workspace/p26-cell06-shapearrays-b1-controller-20261128/TASK12_REVIEW_CANDIDATE.json` | 1647 | `e333c12d14e2a13bea2e4a433fbe41132db5656b29a431fbd1a202b32e67cbca` |
| `/workspace/p26-cell06-shapearrays-b1-controller-20261128/TASK1_REPORT.json` | 2632 | `94d603230864a0b29a057cfa06e525d4c8be4a04eb27045e10057362c49197c4` |
| `/workspace/p26-cell06-shapearrays-b1-controller-20261128/TASK2_ALL_GREEN.log` | 2604 | `c8db212f2f7b39d0f9179e5b92a215503bd703c4d6de055f240489eb9523064c` |
| `/workspace/p26-cell06-shape-b1-root-execution-20261128/INPUT_CONTRACT_001.json` | 2462 | `eb53c0e88da8c88337a32654c5c1a7ba086430c5ccb689b0aea46ec6fb1b8336` |
| `/workspace/p26-cell06-revision4-r2-root-execution-20261128/ACTUAL_QUALIFICATION_PINS.json` | 1564 | `5d3ad8f73c775a0d010fe13b01ac1dd0253da90e96eac50c33721f5495c4bb51` |
| `/workspace/p26-cell06-revision4-r2-qualification-review-20261128/READBACK.json` | 7400 | `1848cf3375265a1571468bdc870eba221950c315e46c6a0f39649c4f03d038f7` |
| `/workspace/p26-cell06-family-revision4-r2-20261128/SOURCE_LOCK.json` | 2471 | `ef736daf3aaaeadb8164ca9d5608fcad833cbcfc55c63a5d6a48375ad487f24d` |
| `/workspace/p26-cell06-family-revision4-r2-20261128/revision4_collect.py` | 16978 | `068ed3ae2e84f8b59cd44ce6824744c7ee188e45f137daa5411186f94e468f19` |
| `/workspace/p26-cell06-family-revision4-r2-20261128/revision4_transport.py` | 15553 | `bc9ab8cf10cd51e46d5785142b095f10a3aec666748eeb7e55db631feb637d7f` |

已限定核对的superseding common：19331B / `93ef39c974aff886da57f50eed401ffcd1b8b201c0dca204b12372ad98a890b0`，仅24B scope字段变动；findings代码不变。

历史独立snapshot：`/workspace/p26-cell06-shape-b1-task12-review-20261128/historical-shape_common-e25a.py`，19307B / `e25a1c3a28c9598fbe4406a4ae8422a2710eb991473f9084bd4b2611b42b9935`。

`REVIEW.json` SHA256：`3e8a6eb96c8ddad8db128699d2d829f6a582dc1376405e6c36d01875f5f73e0b`。
