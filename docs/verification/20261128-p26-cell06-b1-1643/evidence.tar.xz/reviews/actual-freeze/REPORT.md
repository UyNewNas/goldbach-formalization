# Actual B1 batch, Owned helper, selector and run-command QA

**New batch/command findings: 0 Critical / 0 Important / 0 Minor. The exact B1 batch and proposed run command are technically run-ready.** Source Minor M1 remains deferred (source residual0/0/1). This is a control/input review: no new normal, official stock replay or full-owned audit has run, and accepted membership remains1642.

## Actual freeze result and pins

Freeze job `13740cc6ca6d4f3698613f4a2093587d` succeeded with exit0 in34.9968305620132s,445505536 B peak memory and33.14s CPU. The safe local result is `/workspace/p26-cell06-shape-b1-root-execution-20261128/MCP_FREEZE_RESULT.json`,945 B, SHA256 `7140ba5b7f5272e6bed29465a467aca658d20f017d7c48edecb38854dd1f6958`. It binds the actual BATCH pin and reports FREEZE_ONLY/formalfalse/0Lean; no output was truncated/discarded. The actual pin index is1753 B/SHA`ee37add6405f781395dcc736d66826fbbb6423d0457226c6df5b0d81d705994b`.

Stage: `/workspace/p26-cell06-shapearrays-b1-controller-20261128/families/main/batches/shapeArraysB1`.

| Actual file | Bytes | SHA256 |
|---|---:|---|
| BATCH.json |1834|`f9c94ad2a6a9773d460aad9683ba817ef2e27c727082478fc4fa8b159bf89a8c`|
| GLOBAL_INPUTS.json |1814|`39ac6a06b3079644d195cc5f0621bbcfd4e10380bb223798056151956136be44`|
| WHITELIST.json |71|`817b1847d06648d88edb5e7a8fbd7b9c85deae0d72c6da7a8756c84769977338`|
| ShapeArrays.Owned.lean |113854|`ee744201af9412be5e5d7430332e3d8d7c992a55bf35fcd91b1afa0ab7e682c6`|

BATCH's family is exactly the actual seed FAMILY15559553/1eebda…; its parent is the actual **new** BASE_CONTEXT5604624/8a61d5…, not the original qualified context substituted by count. Both actual anchors were rechecked and match the accepted actual-seed reviewa6beca…. BASE_CONTEXT.project_closure exactly equals the1642 FAMILY base catalog and preserves verified-parenttrue/formalfalse. ShapeArrays is absent from that catalog.

The only owner is `ImbalancedChen.P2OriginalSaving19Geometry06ScalableShapeArrays`, epoch_index1, accepted_before empty, concurrency1, atomic_exact_B1, batch-boundary scope, normal_success_recompile_allowed false. BATCH's helper/selector/whitelist pins exactly equal actual files; WHITELIST contains exactly this owner. The graph's first unaccepted owner is exactly ShapeArrays and all of its project imports are already in the1642 base.

## Helper is exactly the complete locked render

The helper was independently reconstructed as text using the pinned OwnedSuppliersAudit template and the frozen renderer's explicit transformations, without importing/running that renderer or Lean. Its entire113854 bytes equal the expected result. The direct project imports are exactly sorted1642 parent modules followed by ShapeArrays, with1643 unique project imports total. The only additional explicit import is Lean.Util.CollectAxioms. The target module array contains **only ShapeArrays**; no parent or oldData owner is scheduled as a new audit target.

The pinned template/renderer identities are recorded in READBACK.json. Exact reconstruction preserves:

- Complete serialized/environment declaration inventory and explicit missing/duplicate/import-data checks.
- Full declaration types with pp.all/proofs/explicit/fullNames/privateNames and truncation rejection.
- Owned target unsafe/partial/new-axiom rejection and transitive axiom collection.
- Complete shared-theorem metadata/type comparisons and fresh-name serialized proof replay via `addDeclCore 0 0`.
- Exactly the standard allowed axiom set propext,Classical.choice,Quot.sound for both target and shared-proof checks.

This establishes the helper's intended obligations and scope, not that ShapeArrays has satisfied them. Its actual normal object does not yet exist; the helper belongs after successful normal and official stock replay. The legacy Cell01 audit labels/shared-proof alias prefix have been replaced by the pinned Cell06 labels; no stale target array is retained. Original parent modules are imported for context, not rescheduled for old normal/stock/full-owned execution.

## Fixed selector and full G domain

GLOBAL_INPUTS is exactly the frozen source-defined object: protocol/family/newBASE parent, complete BASE_GLOBAL_INPUTS118888… baseline, prefix list containing that newBASE pin, and batch_static consisting of the unique helper, whitelist and actual COLD82e937… pin. Its family/parent/selector links equal BATCH. This explicitly adds the later FAMILY/COLD/helper/whitelist anchors to the prior before-FAMILY cold domain.

The baseline metadata was read and its canonical member-map digest matched the independent actual-seed review:153267 baseline members, with the original143258 physical G references preserved by that unchanged seed baseline. The engine's exact union adds prefix/static/selector/baseline/FAMILY/BATCH pins. The resulting **expected metadata-only run G** is:

-153274 unique files.
-20088631248 declared bytes.
-Map SHA256 `136bad510b2ff4f479c51ad4c9d383833f3abb90897070677102fac0d12fbd19`.

No20GB payload pass was performed here. This is canonical pin-list arithmetic, not a fresh PRE or POST. The actual run must hash the full real-byte domain at PRE/POST and preserve its D/namespaces before accepting anything. Source/controller code continues to include the full old physical G and new copies; there is no report-only or sampled substitute.

## Actual empty epoch and authorization boundaries

The actual epoch has exactly four regular files and six nonsymlink directories: helpers,state,steps,accepted-contexts,home,tmp. State,steps,accepted-contexts,home,tmp are empty. There is one sibling epoch only, no sticky failure, no attempt/COMMAND/GLOBAL_PRE, no accepted context and no new canonical ShapeArrays object. Thus this review observes no started mode and creates none.

The FAMILY barrier manifest/array exactly match:1642 catalog members each forbid normal,stock-leanchecker,full-owned, including the original pending RowsNode000To014 three-mode success and both oldData entries. ShapeArrays is the sole authorized new owner, matching fixed graph ecd1… and current source C5. The sole exact failed release retains old source B7 (`b7a59beef8c3348b0791e3dc252ff73d30895ebe56bf00e557d0e77cab6956fc`) and revised source C5 (`c5bd66975121ec9c7cf89337f35e2c1ad855c43537e354979efccf05c001a8b4`). Its old typed exit1/no-object/no-PENDING tuple remains original; it is not a reused normal success. The source/tuple details and original mode provenance inherit the already read actual-certificate and actual-seed chains, not a new blanket failed-release permission.

The pinned engine still authorizes every mode before process creation, enforces exact executor capability, and checks the fixed graph/source and exact failed tuple. Cross-root normal discovery remains a runtime preflight. This review did not rescan the seven old search roots or claim immunity to future changes; actual run preflight and G/D checks remain required. No accepted/pending/oldData mode is allowed to execute again.

## Exact environment, modes and operator command

The ten-key Lean environment was independently derived from actual FAMILY and stage. Its canonical SHA256 is exactly BATCH/index `6bc03152d0967205fa7cc58ff36e28951b2b090c193703f990c6cd27314a80f6`. HOME/TMPDIR point to this new stage's home/tmp; LEAN_PATH begins with the single new family objects root and retains the unchanged external tail. LEAN_NUM_THREADS/OMP_NUM_THREADS are1; sysroot and PATH are the qualified runtime's. This derivation matches the prior seed expectation. The operator wrapper's separate root-execution HOME/TMPDIR do not leak into that explicit proof environment.

Run command: `/workspace/p26-cell06-shape-b1-root-execution-20261128/ACTUAL_RUN_COMMAND.txt`,2547 B/SHA`c86a65d702b203c3eeb0d2a134d6d049c5e556dcdcd37056358ff6631d45ac06`.

Its env-i uses exactly PATH/HOME/TMPDIR/LANG/LC_ALL/TZ and pinned resolved Pythonfa6744… with-I-B. The raw bootstrap checks six actual roots—SELF5405, LOCK4a34, DELIVERY2dd9, FAMILY1eeb, BASE8a61, BATCHf9c9—before executing verified CLI bytes, and rechecks the reread SELF. The literal argv exactly matches CLI's mandatory run flag set, including delivery, exact stage directory and family/batch/new-parent SHAs. Root-execution HOME/TMPDIR are independent empty nonsymlink directories. No fixture/default/latest flag or successor owner/count is introduced.

The externally planned MCP ceiling is13107MiB/CPU1/3600s, equal to FAMILY.outer_limits. These external parameters are not encoded/enforced by the shell text itself; root must submit those same values. Each mode retains12GiB/2400s, one thread, fixed cwd at family/project, and this order:

1. Normal: pinned Lean, `--trust=0 -DwarningAsError=true -j1 -M12288 -DmaxRecDepth=1000000 -DmaxHeartbeats=0`, output to the unique attempt's permanent normal.olean, exact new physical C5 source.
2. Official stock: pinned leanchecker `--verbose` on the owner.
3. Full-owned: pinned Lean with the same flags and this exact Owned helper; parser expects precisely1642 parents plus target and the locked external-module scope.

The CLI's invocation deadline reserves30s bootstrap margin. A new mode needs2400s plus300s reserve, so an unstarted mode can defer before COMMAND when remaining time is below2700s. A later same-byte run can continue only missing modes of this immutable BATCH; it reuses every successful same-attempt record. Deferred unstarted work is distinct from a durable failed/stopped or command-only ambiguous outcome: those do not authorize another attempt. Saved mode-validation errors stay blocking, and existing PRE/empty-history resume uses the repaired actual RESUME boundary.

All three unique successful records, true real-byte PRE/POST, unchanged D and actual namespaces are prerequisites to one seal/context1643. Recovered metadata/canonical bytes do not permit process repeats or fabricate original metrics. Nothing in the prepared command bypasses those conditions. Cancellation or an unknown process outcome must remain fail-closed rather than being interpreted as retry permission.

## Verdict, limits and output

The actual batch/helper/selector/whitelist/epoch and exact command have no new Important. Root may start the next authorized one-time B1 run with the reviewed command and external resource values. This does not predict that the ShapeArrays proofs compile or that the run finishes all modes in one job. Actual PRE,normal,stock,owned,POST,D,seal and context remain to be observed and reviewed.

READBACK.json is15492 B/SHA`b4f8e6af8a1340b131608312638f592ac7c7c70abf52fd5672e17bd8293678c8`; it contains exact raw anchors, helper scope/template pins, expected run-G metadata, environment, argv templates, external command/resource ABI and explicit zero-execution fields.

Reviewer calls:0 freeze/seed/collector/G/Lean/tests/candidate imports/MCP/actual executor. No full new-copy or original-G byte scan was repeated. Only this new review directory was written; frozen source/provider/stage files were unchanged. Source M1 remains deferred. `normal_passed:false`, `stock_passed:false`, `full_owned_passed:false`, `accepted_count:1642`, `formal_acceptance:false`, `Cell06_integral_complete:false`, `P2_6_complete:false`, `original_full_snapshot_verified:false` remain explicit.
