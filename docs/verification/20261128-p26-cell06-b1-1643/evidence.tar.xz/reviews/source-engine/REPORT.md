# B1 Task3/4 engine and CLI static review

The reviewed pre-repair snapshots need changes: **Critical 0 / Important 3 / Minor 0** new findings (E1–E3). This is a complete first static pass over the two requested engine/CLI snapshots, with the prior Task1/2 review treated as a dependency. It does not approve current live code, a final delivery, cold seed, a producer invocation, or production.

All three new findings were sent to root, who confirmed the relevant branches and authorized the author to include them in the current repair round. Code is already entering repair; this report preserves the verdict for the exact old snapshots rather than applying it to changing files.

## Scope, method and pins

Spec: `/workspace/p26-cell06-v4-shape-b1-plan-20261128/PLAN.md`, 34168 B, SHA256 `4f23c1867ea7ee1a11ce92c35d34545692498c10d1ebcf34c8d9115214a2613d`. Reviewed Global Constraints, crash table, external CLI/source-only ABI, resource boundaries, Review Focus, and Tasks3/4. In particular, PLAN:156 forbids recovery from a durable validation failure; PLAN:163 requires real G, exact D/namespaces and all three unique modes before sealing.

| Reviewed immutable physical snapshot | Bytes | SHA256 |
|---|---:|---|
| `task-evidence/task4-pre-review/shape_engine.py` | 35489 | `6b9685faaa14b2a2728fda1f485174a9f32f9e813b3dec3338305b5088554cfa` |
| `task-evidence/task4-pre-review/shape_controller.py` | 12666 | `9ace22ae8d330af73a92009fc60d29fe097b18aa10aeb5bb9aab9a3e13e49cb1` |

Both paths are under `/workspace/p26-cell06-shapearrays-b1-controller-20261128/`. Their logical implementation paths are that root's `shape_engine.py` and `shape_controller.py`. The snapshots were read as source, never executed; their snapshot `__file__` paths are not proposed execution roots. The engine's 493 lines and CLI's 145 lines were covered in the static pass. Relevant branches and all input pins were read back again before reporting.

This review performed **0 candidate imports, 0 tests, 0 producer/collector/seed/G calls, 0 MCP/Lean/lake commands, and 0 formal proof steps**. File reads, SHA256 checks and exclusive report writes are the only actions of this reporting task. No author/provider/runtime file was edited. `formal_acceptance:false`, `production_ready:false`, `original_full_snapshot_verified:false`.

## E1 — Ignore a saved validation failure during resume (Important)

Location: snapshot `shape_engine.py:311–319`, with producer branch at `371–379`.

`run_mode` catches a parser exception, saves its text in `RESULT.mode_validation_error`, persists RESULT, and rejects the invocation. On resume `_verify_record` checks exit status and stop reason but never checks that saved validation error. It reparses the log and, if that parse succeeds, creates PENDING and returns a successful history record.

A concrete trigger is an otherwise successful exit-0 process whose original parser suffered a transient MemoryError or I/O exception. The durable failure can become a successful record during a later invocation even though PLAN:156 says a mode-validation failure stops this B1. This finding does not claim that the process reruns: the invalid recovery is promotion of the existing failed validation state.

Reject a non-null saved validation error before reparse/promotion. Keep the exact original attempt/RESULT and permit neither PENDING/context creation nor a new attempt. The targeted regression should use a matching exit-0 log/object and non-null saved error, then require zero executor calls and no PENDING/context; also exercise the original transient-parser-exception path. No such regression was executed by this reviewer.

## E2 — Skip real G on empty-history resume after first-mode defer (Important)

Location: snapshot `shape_engine.py:482–490`; supporting paths `234–253`, `343–350`.

The budget check runs before the first attempt/COMMAND is created. Thus an invocation may legitimately have durable PRE/GLOBAL_PRE and a DEFER receipt while its history is empty. On the next invocation `pre_anchor` validates and reuses the old report. That metadata validation checks report pins and selectors; it does not rehash the complete physical G domain. `run_batch` performs actual RESUME only when `history` is nonempty and incomplete.

If an old G member outside local D/catalog checks changes between these invocations, the next first-mode process can execute before a full actual G recheck. POST should eventually reject the changed bytes, so this particular trace is an execution-boundary failure, not a demonstrated valid false seal. The supported resume path nevertheless needs the same integrity-before-new-process boundary as a nonempty history.

Detect pre-existing unsealed PRE/resume state independently of nonempty history and perform a full actual RESUME before any missing mode executes. Retain original PRE and all successful mode barriers. A targeted regression should defer before the first COMMAND, mutate an old physical G-only member, and require mismatch plus zero executor calls on resume; also retain the unchanged empty-history resume path.

## E3 — Omit undeclared active-epoch directories/symlinks (Important)

Location: snapshot `shape_engine.py:411–426`; supporting checks `85–92`, `441–458`, `462–473`.

`namespace_check` closes four family subtrees: objects, project, evidence and restore-parent. It does not close the active epoch. `complete_delta_inventory` processes files in steps and skips all nonfiles in state. Consequently an extra empty directory or directory symlink can remain undeclared, including beneath an otherwise valid attempt. These checks are also used at final seal and accepted verification, so the undeclared namespace may coexist with an accepted context.

This is separate from Task12 F2: a correct cold-seed exact-tree check does not close namespaces created or modified later in an active epoch. Define and validate the exact active epoch tree, including fixed directories, owner/mode/unique-attempt structure, permitted sidefiles and flat state reports, contexts, and controlled HOME/TMPDIR. Reject unapproved directory/file symlinks and empty directories at recovery, before/after processes, and finish/accepted verification. Targeted tests should insert empty-directory and directory-symlink variants below attempt/state and require no further execution or context.

## Reviewed behavior and remaining dependencies

| Surface | Static assessment at these pins |
|---|---|
| All-mode authorization | `authorize_mode` is used before process creation for normal/stock/full-owned; barrier map, B1 owner/scope, graph/source and exact failed-release checks are present. Its trustworthy helper binding still depends on F1 closure. |
| Cross-root normal barrier | Another successful or ambiguous normal is refused; only the declared original failed tuple can be released through the pinned logical/physical transport. No broad retry permission was found. |
| Durable same-attempt chain | COMMAND/LOCAL_INPUTS/log/object/RETURN/RESULT/PENDING are linked and rechecked; normal artifact location and non-normal absence of object are checked. E1 remains the saved-failure gap. |
| RETURN without RESULT | Recovery reuses original process fields and pinned log/object, rechecks D/namespaces, records a truthful recovery-time local observation, and does not call the executor. |
| Missing PENDING/canonical/context | Metadata marker recovery, exact permanent-to-canonical copy, and seal-based deterministic context materialization are present. These paths do not authorize another mode process. |
| Ambiguous or ordinary failed/stopped modes | Command-only ambiguity and existing failed/stopped attempts block another attempt; completed prefix modes are reused. E1 is a distinct omitted durable validation-failure case. |
| Mode order/parser ownership | History must be prefix-ordered normal → stock → full-owned; the actual parser/audit/template closure is accessed through the source-only loader. F1 must bind that closure before the first alias load. |
| Budget defer | Per-mode budget check precedes COMMAND; the CLI emits nonformal DEFER and a later job can continue only missing modes. E2 covers empty-history global revalidation. |
| G/D and atomic finish | Real fixed-union G snapshots and D rechecks precede one seal/context; mode receipts stay nonformal. E2/E3 prevent approving the full boundary contract at these pins. |
| CLI external authority | Explicit SELF/LOCK/Python and all locked source bytes are checked before local source execution; production family/batch/parent/epoch/count are fixed. No fixture/latest flags or automatic successor are exposed. |
| Process/write guards | Bootstrap/collect and nonexecuting operations use guards; production execution goes through the exact engine capability path rather than retaining the qualifier's process-forbidden guard. Guard/helper closure and write-boundary correctness retain Task12 dependencies. |

The prior Task12 report is `/workspace/p26-cell06-shape-b1-task12-review-20261128/REPORT.md`, 10648 B, SHA256 `33a291f60ceae9761e5e3a6b1037fae26dafa45954f2f4574eea5ac209790d0f`; its machine record is REVIEW.json, 16951 B, SHA256 `3e8a6eb96c8ddad8db128699d2d829f6a582dc1376405e6c36d01875f5f73e0b`. Its F1–F3 are not counted again here. F1 includes `engine.configure`'s first legacy evidence/controller/template loads (`engine:13–16`, `CLI:124`): final-R2 eight-helper source pins must be bound before those loads, not only in later release validation. M1 (strict JSON numeric-overflow rejection) is explicitly deferred by root and is not silently folded into this round.

The old CLI snapshot opens `EXECUTION.lock` at `CLI:103` without the author's later safe-stage/O_NOFOLLOW repair. The author separately reported that issue and a targeted RED→GREEN case to root. It is tracked as an existing final-diff dependency, not a fourth newly counted finding. This review has not read or approved that changing CLI, the current common/parent repairs, or their runtime effects.

The actual input contract remains an already separately reviewed input, not code approval: `/workspace/p26-cell06-shape-b1-root-execution-20261128/INPUT_CONTRACT_001.json`, 2462 B, SHA256 `eb53c0e88da8c88337a32654c5c1a7ba086430c5ccb689b0aea46ec6fb1b8336`. The R2 qualification readback is 7400 B, SHA256 `1848cf3375265a1571468bdc870eba221950c315e46c6a0f39649c4f03d038f7`, at `/workspace/p26-cell06-revision4-r2-qualification-review-20261128/READBACK.json`. This task does not rerun its collector or confer another1642 acceptance.

## Existing host evidence and next review boundary

These historical author logs were read and hashed, not rerun. Their test names are distinct across the three logs, totaling43 recorded cases. They do not cover the three new counterexample traces sufficiently to close them and do not constitute the future final locked-suite evidence.

| Existing log under implementation root | Recorded cases | Bytes | SHA256 |
|---|---:|---:|---|
| `TASK3_ALL_GREEN.log` | 38 | 4843 | `b1309bc432547006a3022a975998dacf186b2f66b648245bcd9d7a6278e7994d` |
| `TASK4_SCOPE_GREEN.log` | 2 | 338 | `4160e7f244dc96c24196d5230afb56b22b67273a2d569657cf938537bd235423` |
| `TASK4_INTEGRATION.log` | 3 | 534 | `d49857367e5d20693818cb930c87f3cb9c7a2e866d0118b4aa4e7b28cd2dbcab` |

Root additionally reports52 targeted distinct cases after the core8 and lock1 fixes, but this report does not independently pin that evolving aggregate and makes no final-suite claim. The author is repairing F1–F3, E1–E3 and the known lock issue under root's direction. Final whole-suite/freeze remains on hold.

After the author freezes the final delivery, the next independent review should be limited to the F1–F3/E1–E3 repair diffs, their necessary engine/CLI changes, the known lock fix, source-only/helper/runtime closure, final source-lock/delivery/host-evidence pins, and any genuinely new changed paths. Unchanged code already covered here does not need another complete pass. No production command is authorized by this report. Actual B1 must still separately establish exactly three new successful modes, real G/D/seal/context and unchanged old provider barriers before1643; Cell06 integral and global P2.6 remain open.
