# B1 final frozen-source limited review

**Final limited source verdict: 0 Critical / 0 Important / 1 Minor. F1–F3 and E1–E3 are ADDRESSED.** The one remaining Minor is M1, explicitly deferred by root. No new load-bearing breakage was found in the repair diffs. The frozen code is technically compatible with the reviewed real `eb53…` input and the next root-authorized `collect-parent` operation. This is source/control review, not evidence that real collection, seed, G or Lean execution has passed.

## Exact reviewed delivery and limits of this conclusion

Implementation root: `/workspace/p26-cell06-shapearrays-b1-controller-20261128`.

| Anchor | Bytes | SHA256 |
|---|---:|---|
| `shape_controller.py` (SELF) | 12762 | `5405eb7312f6b7988b9803cf319d53cf8b081a82b6f4388a36b12819cfbc2a5c` |
| `SOURCE_LOCK.json` | 3737 | `4a3457b38743c7cc2b067a75a3670172208487e372f1cb4c0e40c20810b48109` |
| `DELIVERY.json` | 23106 | `2dd982733389f16b5346be787a2a0c28e8d2045c01d6376adb58fe8b5caf2ece` |
| `HOST_REPORT.json` | 5348 | `5a713621b41826074e809508937eaecd1bb2d681cd53664b16e3b7b5f9afff51` |
| `TEST_SOURCE_LOCK.json` | 4780 | `b961ab0e30de816de75592f02a2843431ec481f1bd078ef02ff1067e05e7e3bf` |
| `BOOTSTRAP_READBACK.json` | 1247 | `134378746cf76cdca4a83fc6d270806ea075d986629de1c1c4268d2004589815` |

DELIVERY has **97 unique actual members**, totaling861577 bytes. Every listed member was read, checked as a regular non-symlink file, and SHA256/length matched. DELIVERY itself is an externally pinned anchor rather than its own member. All four cross-links (SELF, source lock, test lock, host report) agree with their actual files. Historical snapshots and diffs are members with distinct physical paths; their old pins are not presented as current code pins.

| Final code | Bytes | SHA256 |
|---|---:|---|
| `shape_common.py` | 20415 | `c415f1918890208ecc8e06b2781b8d6e22027342f78b1101cb9985c8ffc70d05` |
| `shape_parent.py` | 17291 | `ec652ee7be46803b72927dd7154caad2710d33bfca64549c4a68bca7334f95c7` |
| `shape_engine.py` | 39776 | `e1cd993b61519d5217170cc558b94edca4b015cc157f8383594a8ae01f53ea67` |
| `shape_source_loader.py` | 2731 | `63e9046309a0bb221dd992440ea4064bbd3cd12254fe9cc94beb5050cbd9dc74` |

This pass compared frozen `task-evidence/task4-pre-review/` against the final root and `task-evidence/round1-final/`. The saved unified diffs exactly reproduce those actual byte changes. The final snapshots exactly equal the final implementation files. The unchanged full source was not reread as a new full review; the previous two complete reviews remain the baseline. The loader is byte-identical. Prior Task12's already reviewed +24-byte `scope_owners` addition is represented by the pre-review common baseline19331/93ef…, and its earlier19307/e25a… snapshot remains preserved.

AST change scope is limited to:

- Common: `_audit`, `seed_family`, plus new `close_seed_namespace`.
- Parent: `collect_qualified_prefix`, `validate_failed_shape_release`, plus new `bind_qualified_helpers` and `final_R2_helpers`.
- Engine: `configure`, namespace/record/history/final-inventory paths, `run_mode`, `run_batch`, anchored `load_contract`, plus new `validate_epoch_namespace`.
- CLI: only `main`'s lock open. Module-level code is unchanged except engine's import of the two new binding helpers. No other production definition was added, removed or changed.

The new `load_contract` try/sticky wrapper preserves external caller SHA rejection before anchored-content validation, then makes content corruption sticky. It does not change owner/count/resource policy or authorize a retry. The test helper changes supply the previously absent `revision4_loader` alias and use a syntactically valid ambiguous-attempt directory/LOCAL_INPUTS pair, so the command-only regression still reaches the intended ambiguity branch.

## Resolution of the six findings

| Finding | Status | Final location and reason |
|---|---|---|
| F1 helper authority/first load | ADDRESSED | `shape_parent.py:62–74,105–114`; `shape_engine.py:13–17`. Final-R2 exact eight-alias set and complete path/length/SHA pins must equal the executed loader table. Collection/direct release bind before delegation. Configure binds before first evidence/controller/template load. The production lock's eight-alias subset exactly equals the qualified R2 lock. |
| F2 physical seed namespace | ADDRESSED | `shape_common.py:210–215,238–251`. Real file and directory closure uses the complete copied physical inventory plus metadata before cold read, after FAMILY creation, and after parent reread plus fresh copy/metadata byte readback. Unknown files, empty directories and symlinks enter the new-family sticky failure path. |
| F3 relative/dir_fd writes | ADDRESSED | `shape_common.py:82–104`. Every audited write path must be absolute; explicit mutation dir_fd values are rejected. Existing resolved-root, dotdot and symlink checks remain. Foreign-FD relative open/mkdir cannot be interpreted against the permitted cwd. |
| E1 saved validation failure | ADDRESSED | `shape_engine.py:314–331`. RESULT must contain `mode_validation_error` exactly equal to None before reparse/promotion. Missing, empty-string and other non-null values block. The original RESULT stays unchanged, without a new PENDING or executor call. |
| E2 empty-history resume | ADDRESSED | `shape_engine.py:531–541`. `had_pre` is recorded before pre_anchor; existing PRE plus incomplete modes causes actual RESUME even with empty history. Fresh PRE has no redundant RESUME, original PRE remains fixed, and already completed modes are not repeated. |
| E3 active epoch namespace | ADDRESSED | `shape_engine.py:86–130,314–365,404–408,429–431,460–461`. An actual complete directory/file grammar closes fixed epoch/helper/state/context/home/tmp structure and unique partial mode attempts. Unknown files, directory symlinks and empty directories fail. Validation runs during recovery, mode boundaries, final inventory and accepted-seal verification. |

The E3 grammar allows the legitimate partial COMMAND/LOCAL_INPUTS state, durable RETURN/log state, optional normal artifact before PENDING, later RESULT and PENDING, and context only with a seal. It rejects sibling epochs and duplicate/empty mode-attempt directories. Actual tree checking reaches undeclared directories as well as files. A mutation injected after the executor is detected before promotion; the recorded regression retains one real counting-executor normal call, PROCESS_RETURN and normal.olean, without a seal. It is not reported as zero process execution for that post-execution case.

The known CLI lock fix is also addressed: `shape_controller.py:103–105` uses `safe_stage` and `os.open(...O_NOFOLLOW,0o600)` before fdopen/flock. The original symlink escape case is retained in RED/GREEN evidence. It is not recounted as a new Important.

M1 remains **Minor / DEFERRED_BY_ROOT** at common strict_json and CLI decode: named NaN/Infinity is rejected, while a numeric overflow literal such as1e999 can become infinity. This round did not modify that behavior. The supplied exact real contract has no such value. This conclusion deliberately does not claim zero Minor findings.

## Source-only closure, runtime and roles

SOURCE_LOCK contains precisely12 loader aliases: the original qualified eight (`revision4_collect`, `revision4_core`, `revision4_loader`, `revision4_transport`, `evidence`, `templates`, `controller`, `checkpoint`) plus four new shape aliases (`shape_source_loader`, `shape_common`, `shape_parent`, `shape_engine`). The eight original pin dictionaries exactly equal the final R2 SOURCE_LOCK (`ef736d…`). All12 actual source files were independently hashed, as were SELF, the two Lean control/template inputs and the pinned resolved Python binary:16 source/runtime/control pins in total. The actual loader remains the previously reviewed byte-identical source-only implementation.

The pinned runtime is `/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3.12`, 30894944 B, SHA256 `fa67443527ed9647f760d807e2a38f26340757123e643c4639cf273ed15d5ea7`; required flags are `-I -B`. The host test command and bootstrap readback use this exact resolved runtime. TEST_SOURCE_LOCK's embedded production_lock is structurally identical to final SOURCE_LOCK, and its three test/control source pins match actual `test_shape_host.py`, `shape_host_fixture.py`, `FREEZE_DELIVERY.py` bytes.

| Role | Permitted path through the reviewed ABI |
|---|---|
| Source-only bootstrap | Explicit externally checked SELF/LOCK/runtime, locked source execution only; no producer, G, seed or Lean. |
| Parent collection | Exact real contract/graph/source; process guard active, writes limited to exclusive `certificates/` output and the new root lock. Qualified sources/objects/evidence stay read-only. |
| Seed/freeze | Explicit certificate/family/parent pins; process guard active, independent physical copy and exact namespace checks; no proof execution. |
| Run | Fixed B1/ShapeArrays/count1; exact per-mode executor capability, all accepted/pending/oldData barriers and exact failed-release validation remain in force. No automatic successor. |
| Host tests/fixtures/freeze/port scripts | Delivery evidence/control members, excluded from the12 production loader aliases. Their presence does not add a production command or fixture authority. |

The repair diff does not alter the all-mode barrier policy, original pending-three-mode identity, oldData prohibitions, exact old failed five-file tuple, old physical G union, 334-source graph or the two selected frozen source repairs. It does not touch Lean source/providers, create a new accepted owner or grant13-cell/integral credit.

## Existing host evidence: checked, not rerun

The single frozen `FINAL_HOST_GREEN.log` is8229 B, SHA256 `00b63c2e101c1d48583562bd064f9abab642744c69faf032261f4333b4c45dcd`; it records **62 cases,22.220s,0 failures,0 errors**. The62 distinct logged class/method identities exactly equal the frozen test source's62 test definitions. This is the author's existing one-suite evidence, not a new execution by this reviewer.

The targeted history was retained and read accurately:

- F1–F3:8 cases, first RED had7 failures and1 positive case; GREEN8 passed.
- CLI lock:1 RED failure, then GREEN1 passed.
- E1–E3/configure: initial RED had9 failures and1 fixture error; the corrected fixture RED had10 failures; GREEN10 passed. The first fixture error is not concealed or characterized as a production failure.
- Final62 is the previous43 plus8 core repair cases,1 lock case and10 engine/configure cases.

The new tests exercise all eight alternate helper aliases before loading, actual synthetic seed file/directory/symlink injection, foreign-dirfd writes with an allowed absolute-write positive case, saved non-null/empty/missing validation error, both changed/unchanged empty-history resume, unknown epoch file/directory/symlink before mode, and a post-executor namespace injection. Assertions retain original RESULT/PRE where relevant, count exact executor calls, and reject a seal/context on failure. These are synthetic storage/control tests and confer no Lean credit.

BOOTSTRAP_READBACK matches the final SELF/LOCK/runtime argv, exit0, empty stderr, `SOURCE_BOOTSTRAP_ONLY`, and0 executor/G/seed/Lean/production operations. Its exact source lock equals the final lock. At review time `families/`, `certificates/` and `EXECUTION.lock` were absent. Real parent collection, cold seed and proof execution have not occurred in this source delivery.

## Real input compatibility and exact next ABI

The existing real input is `/workspace/p26-cell06-shape-b1-root-execution-20261128/INPUT_CONTRACT_001.json`, 2462 B, SHA256 `eb53c0e88da8c88337a32654c5c1a7ba086430c5ccb689b0aea46ec6fb1b8336`. Its exact12-key schema/status match `shape_parent.FIELDS`; graph/source/R2 lock/delivery hashes equal the frozen policy constants. The input's real qualification review remains the previously accepted R2 readback1848cf…; this review does not repeat qualification or replace that authority with an assumed count.

The CLI collection flag set is exact and accepts this input. `--graph` must equal contract.graph and `--shape-source` must equal contract.shape_source as complete pins. Output must be a new file directly in this root's `certificates/`; `certificates/PARENT_001.json` is the suggested exclusive output, not an existing certificate. REVIEW.json records the full literal collection argv and required external launcher anchors. Root should use its externally checked stdlib launcher to verify SELF, SOURCE_LOCK and DELIVERY before compiling/executing the checked controller; a controller's self-check alone is not substituted for that bootstrap boundary.

After actual collection returns, subsequent flags must use its actual new certificate pin. Seed uses exact `families/main`, rss12/wall2400; freeze uses the actual cold-seed BASE_CONTEXT pin, epoch `shapeArraysB1`, count1. Run uses the same exact FAMILY/BATCH/parent pins and epoch path. No guessed future hashes or generated production fixtures are supplied here.

Outer run ABI is13107MiB,3600s,CPU1; each mode remains12GiB/2400s and `--trust=0 -DwarningAsError=true -j1 -M12288 -DmaxRecDepth=1000000 -DmaxHeartbeats=0`. Seed and freeze use separate jobs. CLI records an invocation deadline with30s bootstrap margin; each new mode requires2400s plus300s reserve before COMMAND. Insufficient time emits nonformal UNSTARTED_MODE_DEFERRED, creates no COMMAND for that mode, and permits only missing modes of the same frozen batch in a later job. Durable failed/stopped/ambiguous attempts remain blocking. Completed modes and all historical successes are never repeated.

No code-review blocker remains for root's next actual collect-parent under this exact contract and pinned source delivery. Actual collector validation, cold-copy/G closure and any normal/stock/full-owned process still require their own real outcomes. This review does not assert their success,1643 acceptance, Cell06 integral closure or P2.6 completion.

## Audit outputs

`READBACK.json` in this review directory contains all97 member pins, the16 source/runtime/control pins, exact AST change scope and diff pins, actual input pin/schema checks,62 case identities, targeted RED/GREEN summaries and no-production-state observations. Its SHA256 is `30c838efd6a96cdecfc099d9358e5baea76d410f70018ff1acdb802b51157f27` (46116 B).

Reviewer operations were bounded source/metadata reads, streaming SHA256 checks, AST/diff analysis and exclusive review-file writes only: **0 tests,0 candidate imports,0 bootstrap executions,0 collector/seed/G calls,0 Lean/lake/MCP commands**. No old or new provider was changed. `formal_acceptance:false`, `proof_credit:0`, `original_full_snapshot_verified:false`.
