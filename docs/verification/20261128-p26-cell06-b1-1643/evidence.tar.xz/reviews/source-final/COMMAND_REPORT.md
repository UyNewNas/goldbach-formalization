# Actual collect-parent command: limited static annex

The exact2900-byte command SHA256 `89080860b810f58ed4f6bc356be10b42860c86730bcbc26f5d9fb0f836188f86` is compatible with the final reviewed source and real eb53 input. New command findings:0 Critical /0 Important /0 Minor; source M1 remains explicitly deferred. The command was read and AST/argv checked, never executed.

The shell starts `env -i` with exactly PATH/HOME/TMPDIR/LANG/LC_ALL/TZ and the pinned resolved Python with `-I -B`. Before local CLI execution the stdlib wrapper hashes all six explicit actual roots: SELF, SOURCE_LOCK, DELIVERY, real input, graph and ShapeArrays source, matching their complete lengths/SHAs. It rereads and rechecks SELF before compiling those verified bytes. `__file__` is the real implementation path and `__name__` is `__main__`, with package/cache None. The final CLI then checks its complete lock/runtime/module closure and delivery.

The literal collect-parent argv exactly matches CLI's required flag set, including `--delivery-sha256`, and contract graph/source identities. Its exclusive output is `/workspace/p26-cell06-shapearrays-b1-controller-20261128/certificates/qualified1642-parent-001.json`; it did not exist at review. HOME/TMPDIR are separate empty, non-symlink directories below root-execution, outside qualification. The command invokes no seed/G/proof entry point. Process/write guards remain the reviewed collector path.

Root's proposed MCP limits4096MiB/CPU1/1200s are external invocation parameters, not assertions enforced in the shell text. They do not change the later seed/run limits. This annex checks their intended collection-only role and does not claim the real collector completes within them.

Root may execute this next authorized collection using the exact command/pins. The generated certificate and actual return still need readback; no certificate, real collector success, formal credit or1643 acceptance is preclaimed. The main source verdict remains REPORT.md/REVIEW.json unchanged. COMMAND_READBACK.json contains precise argv, roots and observations. Reviewer executed0 tests/collector/seed/G/Lean/MCP commands.
