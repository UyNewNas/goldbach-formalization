# Actual B1 cold-seed and freeze-command independent QA

**New seed findings: 0 Critical / 0 Important / 0 Minor. Seed is ready for the fixed B1 freeze.** The exact proposed freeze command also has0/0/0 new findings. Source Minor M1 remains deferred, so the inherited source result is still0/0/1. This is seed-only readiness: accepted membership remains1642, not1643. No new proof mode, integral/global closure or full archival-snapshot verification is claimed.

## Actual seed outcome and anchors

Actual MCP job `61f136aeeeb74a8ab61bbe2c45379adf` returned exit0 in142.99227188598888s, with591118336 B peak memory and114.73s CPU. The safe result is `/workspace/p26-cell06-shape-b1-root-execution-20261128/MCP_SEED_RESULT.json`,942 B, SHA256 `c9966372f08ea2242675fb5e60c0a3bf9e93acca81af09f61ae60faf5ff3ef9e`. Its output binds the actual FAMILY pin, `SEED_ONLY`, formalfalse and0Lean; no log bytes were discarded or truncated. External job limits were4096MiB/CPU1/1200s.

Family root: `/workspace/p26-cell06-shapearrays-b1-controller-20261128/families/main`.

| Actual anchor | Bytes | SHA256 |
|---|---:|---|
| FAMILY.json |15559553|`1eebda23176f642e069d2dfa927d996010963d910e00f392797556a0d24ee4f2`|
| BASE_CONTEXT.json |5604624|`8a61d56d6f143a386dcc6fd0305a8ffe7e27863e00250f2048b9677765ead386`|
| TRANSPORT.json |4248069|`1d7c2cf6e48404c2065d9a4020cb7946a7f93b862c05d4d774ddffedf6befd57`|
| BASE_GLOBAL_INPUTS.json |38178967|`1188885a9d9c57211509a22e96bcad777d3722e52da3dcd6d7988d47c1e0cb4a`|
| COLD_READBACK.json |656|`82e9378437b3156f7f39ee3387fed7769eaea657e5e94ea8ab40e3582e333fb0`|

The root-created ACTUAL_SEED_PINS index is2223 B/`e4452c84d573bde06530850a785630175c93fb1f842518f0c981f414d2edb225`; every indexed anchor matched actual bytes. FAMILY references exactly those base/transport/baseline/cold anchors. BASE_CONTEXT references the actual50229802-byte59fef0… certificate and its existing qualified context; its project/native/runtime data exactly equal FAMILY. It is copied membership with formalfalse/verified-parenttrue, not new proof acceptance. TRANSPORT's5725 rows exactly equal FAMILY.copy_map and preserve original logical identities.

The actual certificate remains the independently accepted cold-seed input from `/workspace/p26-cell06-shape-b1-actual-certificate-review-20261128/READBACK.json`,46430 B/`7f703d15dab742676e7c720a8bdb3cf0f837229fa48c2760ddfb150c88686853`. It still binds real eb53 authority, final4a34 source lock and2dd9 delivery. Its1642 membership and old successful/failed mode identities are the unchanged basis of this seed QA.

## Exact copy plans and independent actual readback

The copy plan was independently reconstructed from the actual certificate and frozen seed function's target/role rules. Every target, logical full pin, role, catalog mapping, native relative path, evidence/control path and raw-copy path matches the actual transport. No source/copy count alone was used as authority.

| Copy role | Count |
|---|---:|
| qualified-parent-source |1642|
| qualified-parent-object |1642|
| qualified-parent-object-restore-copy |1642|
| unaccepted-fixed-graph-source |191|
| qualified-native |555|
| qualified-original-evidence-or-control |51|
| qualified-original-raw |2|
| Total |5725|

All5725 **new physical copies** were streamed and SHA256/length checked against their declared original-byte pins: **1849171718 bytes**, in7.962s of this readback. No old qualified-object payload or original G payload was hashed again. All new copies have distinct physical(dev,inode) identities, link count1, and an inode different from their declared logical origin. The4081 unique logical origins were statted; size/inode/mtime/ctime stayed fixed during this review window. That stat observation is not advertised as a new old-provider byte scan. Old-provider byte validity remains grounded in the accepted R2/certificate chain and the actual seed's complete cold readback.

The1642 catalog entries preserve their entire qualified original entry. Each accepted object has one new canonical copy and one independent restore-parent copy with the same accepted byte pin. The restore dictionary has exactly1642 keys; it contains no unaccepted owner and invents no normal receipt. Existing oldData entries retain their original prohibitions and provenance. The1833 physical project sources are exactly qualified catalog union334 graph sources. The555 native outputs use the exact original relative names under the single new object root.

ShapeArrays retains source19599 B/SHA`c5bd66975121ec9c7cf89337f35e2c1ad855c43537e354979efccf05c001a8b4` but is absent from the base catalog, canonical object plan and restore plan. Its334-source graph/revision references equal the reviewed actual certificate, which established333 unchanged full source references and exactly two ShapeArrays proof-body edits. None of the191 future-source copies receives acceptance through seed.

All1642 three-mode barriers exactly equal the certificate and their new manifest. Both oldData barriers remain present. The failed-release array exactly equals the existing one exact typed-failure release; original pending8p successes and failed ShapeArrays identities are carried unchanged through original entries/barriers. Normal search roots retain all six original roots and add the qualified stage. There are23 exact authority-D anchors and109 exact code/control pins, all reconstructed from the source-defined unions.

## Actual namespace closure

The complete family tree has **5732 files and65 directories**:5725 copied payload/control files plus the seven anchor/ledger metadata files. File and directory sets exactly match generated ancestors and allowed `batches`, `home`, `tmp` empty directories. There are no file/directory symlinks, unknown empty directories, nonregular entries, hardlinked new copies, sticky integrity files or premature epoch. Family ancestors are nonsymlink paths. `batches`, `home`, `tmp` are empty and `batches/shapeArraysB1` does not yet exist.

This actual directory/file check supplements the seed's F2 closure rather than inferring namespace correctness from planned paths. The review wrote only to this new review directory; it did not alter family, qualification, source or provider files.

## Complete fixed baseline and truthful cold scope

The baseline was independently rebuilt from every source-defined certificate field: complete original_physical_G, qualified_files, qualification_input_pins, original_pending_local_D, original_epoch_pins, authority_D_anchors and observed_metadata_pins; then all new physical copies, base/transport/barrier/release metadata, certificate, final controls, graph and revision anchors. The full pin union exactly equals BASE_GLOBAL_INPUTS, **153267 unique members**. All original143258 physical G rows remain present with unchanged full pins; no original physical identity was replaced by a new copy or dropped because of duplicate content.

COLD's checked domain is that exact baseline plus BASE_GLOBAL_INPUTS's own pin:

- Files:153268.
- Bytes:20072953466.
- Canonical pin-map SHA256:`b9724bf4221819f9e7ccc0fc46f0709227fa82218de7e9b19c80851243be607e`.

These values match the actual COLD report and root's actual pin index. The actual source-controlled seed performs fresh byte checks for this entire fixed set before writing COLD/FAMILY, and the successful MCP output binds the resulting FAMILY→COLD→baseline chain. Reported copy/cold times19.04458988000988s/86.03237487899605s fit within the142.992s job outcome. This is the existing actual full cold-readback evidence, not a second20GB G pass by this reviewer.

The scope is exactly **"Complete fixed baseline before FAMILY anchor is created"**. FAMILY.json and COLD_READBACK.json are both absent from that earlier cold member set. BASE_CONTEXT, transport and frozen ledgers are covered. No claim is made that this cold pass already hashed the later FAMILY or the COLD report itself. Their actual metadata pins were independently checked here; subsequent freeze/run must preserve their appropriate exact anchors.

## Frozen sources, runtime and future Lean environment

FAMILY.code_pins exactly equals the source-defined union of SELF, SOURCE_LOCK, DELIVERY, Python,12 loader modules, two Lean control/template inputs and97 delivery members:109 unique pins. The freeze-command annex also independently rehashed all109 current source/control/runtime files,31994562 bytes, with no mismatch. This includes Python30894944 B/SHA`fa67443527ed9647f760d807e2a38f26340757123e643c4639cf273ed15d5ea7`; SOURCE_LOCK4a34 and DELIVERY2dd9 remain exact. These are source/control checks, not another original G or qualified-object scan.

FAMILY runtime/environment/environment-lock/external-module values equal the qualified certificate. LEAN_PATH is exactly the new family's `objects` directory followed by the unchanged external tail. The previous qualified object root is removed, and the new project object root occurs once. No old private project object root is added back through this rebase.

The reviewed env_for code deterministically gives future B1 HOME/TMPDIR as this family's `batches/shapeArraysB1/home` and `tmp`; it does not reuse qualification's home/tmp. It sets LANG/LC_ALL C.UTF-8, TZ UTC, LEAN_NUM_THREADS and OMP_NUM_THREADS1, the exact rebased LEAN_PATH, qualified sysroot and sysroot/bin:/usr/bin:/bin PATH. READBACK.json records the literal derived ten-key environment. This is an environment derivation, not observation of a Lean process: the B1 epoch and such a process do not yet exist.

Family proof metadata remains rss12GiB/wall2400s and outer13107MiB/3600s/CPU1, one owner/count1 and concurrency1. The actual seed job's4096MiB/1200s ceiling applies to this copy/cold phase and does not silently replace later proof-mode limits. The two pinned Lean audit/template inputs remain exact; no helper or BATCH is fabricated by this report.

## Proposed actual freeze command

`/workspace/p26-cell06-shape-b1-root-execution-20261128/ACTUAL_FREEZE_COMMAND.txt` is2405 B, SHA256 `98d419bac14411c985aa6c14fcc67ca6c7900f4221c20d9df71be76fa2bc3aa7`. It was statically parsed, not executed. It uses env-i with exactly six reviewed variables, pinned Pythonfa6744… and-I-B; its stdlib bootstrap checks five raw roots before verified SELF compile/exec: SELF5405, LOCK4a34, DELIVERY2dd9, actual FAMILY15559553/1eeb and actual new BASE_CONTEXT5604624/8a61. SELF is reread/rechecked before compile.

The exact CLI flags include delivery, family/SHA1eeb, **parent-context equal to the new cold-seed BASE_CONTEXT/SHA8a61**, epoch shapeArraysB1 and count1. It does not substitute the old qualified context pin for the newly copied base context. The intended epoch is absent, batches is empty and root-execution HOME/TMPDIR remain separate empty nonsymlink directories. Root's planned external budget4096MiB/CPU1/1200s is suitable to this metadata-freeze phase as an explicit invocation limit; completion is not guaranteed or claimed by this static review. No proof mode is requested.

Root may proceed with this next authorized one-time freeze. The actual BATCH, global selector, whitelist and owned-helper output pins must then be independently checked before any normal/stock/full-owned run. This QA does not assert freeze success or authorize reexecution of any old successful mode.

## Scope and output pins

READBACK.json:12621 B, SHA256 `a6beca3049176c38d59071cf1614d7121cbf918628adc4a8ba3366b8957736f6`.

FREEZE_COMMAND_READBACK.json:28729 B, SHA256 `e5adb94662c806ddb4e685d0cc8ef4f07122ffc89bf88418dc7e4ad388108882`.

Reviewer actions were bounded actual metadata/source reads, full new-copy transport readback, inode/namespace checks, pin-list arithmetic and exclusive review-file writes. There were0 seed/collector/test/candidate-import/old-full-G/old-qualified-object-scan/Lean/lake/MCP calls and0 proof credit. New-copy hashing is reported separately from global G. Source M1 remains deferred; no zero-Minor claim is made for the inherited source review. `formal_acceptance:false`, `accepted_count:1642`, `freeze_passed:false`, `new_modes_passed:false`, `Cell06_integral_complete:false`, `P2_6_complete:false`, `original_full_snapshot_verified:false` remain explicit.
