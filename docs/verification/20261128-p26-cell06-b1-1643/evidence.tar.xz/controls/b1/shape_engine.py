"""New B1 engine; immutable source port, no old module monkeypatch/ROOT rebinding."""
import hashlib,json,os,shutil,time,uuid,math
from pathlib import Path
from types import SimpleNamespace
from shape_common import *
from shape_parent import collect_qualified_prefix,validate_failed_shape_release,bind_qualified_helpers,final_R2_helpers,GRAPH_SHA,SOURCE_SHA
_loader=None
LEGACY=None
_executor_capability=None
_provider_validator=None
_release_validator=None

def configure(loader,provider_validator=None,release_validator=None):
 global _loader,LEGACY,_provider_validator,_release_validator
 _provider_validator=provider_validator;_release_validator=release_validator
 bind_qualified_helpers(final_R2_helpers(Reader(),loader),loader)
 _loader=loader;LEGACY=SimpleNamespace(evidence=loader.load('evidence'),controller=loader.load('controller'),templates=loader.load('templates'))

class BudgetDeferred(RuntimeError):pass
class AmbiguousInterruption(RuntimeError):pass
class ExistingProcessFailure(RuntimeError):pass

def argv_for(stage,extension,owner,mode):
 if mode=='normal':return list(map(str,[extension['runtime']['lean']['path'],*flags(extension),'-o','__NORMAL_OUTPUT__',source_path(family_path(extension),owner)]))
 if mode=='stock-leanchecker':return [extension['runtime']['leanchecker']['path'],'--verbose',owner]
 require(mode=='full-owned','Unknown mode');return list(map(str,[extension['runtime']['lean']['path'],*flags(extension),Path(stage)/'helpers'/(owner+'.Owned.lean')]))

def require_mode_budget(deadline,now,wall=2400,reserve=300):
 if deadline-now<wall+reserve:raise BudgetDeferred('Unstarted mode deferred before COMMAND: need2400s plus300s post/exit reserve')

def original_command_reference(item,rows):
 current=item;seen=set()
 while True:
  require(current['path'] not in seen,'Transport command alias cycle');seen.add(current['path'])
  matches=[row for row in rows if row['physical']==current]
  if not matches:return current
  require(len(matches)==1,'Conflicting command transport aliases');row=matches[0]
  require(row['original_identity_preserved'] is True and same_bytes(row['logical'],row['physical']),'Command identity rewritten during transport')
  check(row['physical']);check(row['logical']);current=row['logical']

def authorize_mode(extension,owner,mode,loader,release_validator=None):
 require(mode in MODES,'Unknown mode')
 blocked={row['module']:row for row in extension['all_mode_barriers']}
 require(owner not in blocked or mode not in blocked[owner]['forbidden_modes'],'All-mode membership/pending/oldData barrier')
 require(owner==OWNER and extension['scope_owners']==[OWNER],'Only fixed ShapeArrays B1 is authorized')
 require(extension['graph']['sha256']==GRAPH_SHA and extension['project_sources'][owner]['sha256']==SOURCE_SHA,'Wrong B1 graph/source')
 check(extension['graph']);check(extension['project_sources'][owner])
 cert=read(extension['certificate']['path']);check(extension['certificate'])
 require(extension['failed_releases']==cert['failed_releases'] and len(extension['failed_releases'])==1,'Failed-release class/tuple changed')
 validator=release_validator or _release_validator or validate_failed_shape_release
 validator(extension['failed_releases'][0],extension['graph'],extension['project_sources'][owner],loader)

def require_durable_outcome(attempt):
 attempt=Path(attempt)
 if not (attempt/'RESULT.json').exists() and not (attempt/'PROCESS_RETURN.json').exists():raise AmbiguousInterruption('Unknown COMMAND interruption; no guessed retry')

def durable_result_payload(command,returned,command_pin,local_pin,log_pin,object_pin,local_count,observed_ns):
 require(returned['identity']==command['identity'] and returned['command']==command_pin and command['local_inputs']==local_pin,'Durable COMMAND/identity/D transplant')
 require(returned['log']==log_pin and returned['object']==object_pin and returned['formal_acceptance'] is False and returned['status']=='PROCESS_RETURNED_PENDING_LOCAL_AND_GLOBAL_CHECKS','Durable return/log/object differs')
 metrics=process_schema(returned['process_result'])
 require(set(returned['process_result'])==set(metrics),'Unexpected durable process fields')
 return {**metrics,'protocol':returned['protocol'],'global_validation_scope':'batch_boundary','command':command_pin,'process_return':None,'log':log_pin,'local_post':{'inputs':local_pin,'all_local_files_matched':True,'file_count':local_count},'object':object_pin,'formal_acceptance':False,'timings':{'process_seconds':metrics['seconds']},'recovery_local_post':{'observed_unix_ns':observed_ns,'scope':'actual_recovery_time'},'mode_validation_error':None}

def validate_provider(extension):
 if _provider_validator is not None:return _provider_validator(extension)
 cert=read(extension['certificate']['path']);check(extension['certificate']);current=collect_qualified_prefix(cert['input_contract'],_loader)
 require({k:v for k,v in cert.items() if k not in ('controller_source_lock','controller_delivery')}==current,'Qualified parent provider changed')
 return cert

def catalog_objects(stage,extension,pending):
 selected=[];root=family_path(extension)
 for owner,entry in extension['parent_catalog'].items():
  target=object_path(root,owner);expected=entry['selected_object'];require(expected['path']==str(target),'Canonical parent object path differs')
  if target.exists():check(expected)
  else:
   source=extension['restore_parent_objects'][owner];check(source);copy_exact(source['path'],target,source);check(expected)
  selected.append(expected)
 for item in extension['native_artifacts']:check(item);selected.append(item)
 for owner,record in pending.items():
  require(owner not in extension['parent_catalog'],'Pending owner overlaps accepted parent');target=object_path(root,owner);expected={**record['object'],'path':str(target)}
  if target.exists():check(expected)
  else:copy_exact(record['object']['path'],target,record['object'])
  selected.append(expected)
 return unique(selected)

def validate_epoch_namespace(stage,batch=None):
 """Actual file AND directory grammar, including partial durable attempts. No writes."""
 stage=Path(stage);siblings=stage.parent
 require(siblings.is_dir() and all(p==stage for p in siblings.iterdir()),'Unknown sibling epoch; only exact B1')
 if not stage.exists():return
 require(stage.is_dir() and not stage.is_symlink(),'Invalid epoch root')
 for name in ('helpers','state','steps','accepted-contexts','home','tmp'):require((stage/name).is_dir() and not (stage/name).is_symlink(),'Missing/symlink required epoch directory')
 for parent in (stage,*stage.parents):require(not parent.is_symlink(),'Epoch ancestor symlink')
 batch=batch or read(stage/'BATCH.json')
 require(batch['owners']==[OWNER] and batch['helpers'] and {x['path'] for x in batch['helpers']}=={str(stage/'helpers'/(OWNER+'.Owned.lean'))},'Wrong B1 helper/owner namespace')
 require(batch['global_inputs']['path']==str(stage/'GLOBAL_INPUTS.json') and batch['whitelist']['path']==str(stage/'WHITELIST.json'),'Epoch fixed selector path transplant')
 files={str(stage/n) for n in ('BATCH.json','GLOBAL_INPUTS.json','WHITELIST.json')}|{x['path'] for x in batch['helpers']}
 for path in (stage/'state').iterdir():
  require(path.is_file() and not path.is_symlink(),'Unknown state directory/symlink')
  require(path.name in ('GLOBAL_PRE.json','BATCH_ACCEPTED.json') or re.fullmatch(r'(PRE|RESUME|POST|DEFER)-[0-9]+\.json',path.name),'Unknown epoch state file');files.add(str(path))
 contexts=list((stage/'accepted-contexts').iterdir())
 for path in contexts:
  require(path.name==OWNER+'.json' and (stage/'state/BATCH_ACCEPTED.json').is_file() and path.is_file() and not path.is_symlink(),'Unknown/unsealed accepted context');files.add(str(path))
 allowed={'LOCAL_INPUTS.json','COMMAND.json','output.log','PROCESS_RETURN.json','RESULT.json','PENDING.json','normal.olean'}
 for owner in (stage/'steps').iterdir():
  require(owner.name==OWNER and owner.is_dir() and not owner.is_symlink(),'Unknown steps owner/file/symlink')
  modes=list(owner.iterdir());require(modes,'Unknown empty steps owner')
  for mode in modes:
   require(mode.name in MODES and mode.is_dir() and not mode.is_symlink(),'Unknown steps mode/file/symlink')
   attempts=list(mode.iterdir());require(len(attempts)==1,'Unknown empty/duplicate attempts')
   attempt=attempts[0];require(re.fullmatch(r'[0-9]+-[0-9a-f]{8}',attempt.name) and attempt.is_dir() and not attempt.is_symlink(),'Unknown attempt directory')
   contents=list(attempt.iterdir());names={x.name for x in contents}
   require({'COMMAND.json','LOCAL_INPUTS.json'}<=names<=allowed and all(x.is_file() and not x.is_symlink() for x in contents),'Unknown/missing attempt sidefiles or directory')
   require(mode.name=='normal' or 'normal.olean' not in names,'Non-normal provisional object')
   if 'PROCESS_RETURN.json' in names:require('output.log' in names,'Durable return without log')
   if 'RESULT.json' in names:require({'PROCESS_RETURN.json','output.log'}<=names,'Result without durable return/log')
   if 'PENDING.json' in names:require({'RESULT.json','PROCESS_RETURN.json','output.log'}<=names and (mode.name!='normal' or 'normal.olean' in names),'Pending without permanent durable outcome')
   files.update(str(x) for x in contents)
 exact_tree(stage,files,empty=('helpers','state','steps','accepted-contexts','home','tmp'))

def namespace_check(stage,extension,pending):
 try:validate_epoch_namespace(stage)
 except Exception as exc:sticky(stage,'Observed epoch namespace mismatch',str(exc))
 root=family_path(extension);objects=catalog_objects(stage,extension,pending)
 exact_tree(root/'objects',[i['path'] for i in objects]);exact_tree(root/'project',extension['project_files'])
 transport=read(extension['transport']['path']);check(extension['transport'])
 evidence=[row['physical']['path'] for row in transport['rows'] if Path(row['physical']['path']).is_relative_to(root/'evidence')]
 exact_tree(root/'evidence',evidence)
 restore=[x['path'] for x in extension['restore_parent_objects'].values()];exact_tree(root/'restore-parent',restore)
 validate_provider(extension)

def delta_items(stage,extension,batch,owner,mode,history,pending):
 helper=[x for x in batch['helpers'] if x['path']==str(Path(stage)/'helpers'/(owner+'.Owned.lean'))];require(len(helper)==1,'Exact auditor helper required')
 items=[extension['project_sources'][owner],helper[0],*extension['code_pins'],*extension['runtime'].values(),*extension['authority_D_anchors']]
 for record in history:
  items += [record[k] for k in ('marker','result','command','log','local_inputs','process_return')]
  if record['object']:items.append(record['object'])
 for name,record in pending.items():
  target=object_path(family_path(extension),name);copy_exact(record['object']['path'],target,record['object']);items += [record['object'],pin(target)]
 return unique(items)

def refuse_other_stage_normal(stage,extension,owner):
 authorize_mode(extension,owner,'normal',_loader)
 cert=read(extension['certificate']['path']);aliases=cert['copy_map']+extension['copy_map'];released=extension['failed_releases'][0]['command']
 roots=extension['normal_search_roots']+[str(ROOT)]
 for root in roots:
  require(Path(root).is_dir(),'Declared normal search root missing')
  for command in Path(root).glob('**/steps/'+owner+'/normal/*/COMMAND.json'):
   if command.is_relative_to(Path(stage)):continue
   original=original_command_reference(pin(command),aliases)
   require(original==released,'Foreign successful/failed/ambiguous command blocks new normal; only exact released tuple aliases permitted')

def invoke_executor(executor,extension,mode,owner,argv,cwd,env,log,timeout,rss):
 global _executor_capability
 authorize_mode(extension,owner,mode,_loader)
 require(_executor_capability is None,'Nested executor capability')
 _executor_capability=(mode,owner,list(argv),str(cwd),dict(env),str(log),timeout,rss)
 try:return executor(mode,owner,argv,cwd,env,log,timeout,rss)
 finally:_executor_capability=None

def real_executor(mode,owner,argv,cwd,env,log,timeout,rss):
 require(_executor_capability==(mode,owner,list(argv),str(cwd),dict(env),str(log),timeout,rss),'No exact authorized executor capability')
 return LEGACY.evidence.real_process(argv,cwd,env,log,timeout,rss)

def recover_durable_result(stage,extension,batch,owner,mode,pre,attempt,history,pending):
 attempt=Path(attempt)
 if (attempt/'RESULT.json').exists():return None
 require_durable_outcome(attempt)
 command=read(attempt/'COMMAND.json');expected=identity(stage,extension,batch,owner,mode,pre);require(command['identity']==expected,'Interrupted COMMAND identity changed')
 local_pin=command['local_inputs'];require(local_pin['path']==str(attempt/'LOCAL_INPUTS.json'),'Interrupted D path transplant');check(local_pin);local=read(local_pin['path']);require(local==delta_items(stage,extension,batch,owner,mode,history,pending),'Interrupted exactD differs')
 for item in local:check(item)
 returned_pin=pin(attempt/'PROCESS_RETURN.json');returned=read(returned_pin['path']);log=returned['log'];require(log['path']==str(attempt/'output.log'),'Interrupted log transplant');check(log)
 obj=returned['object']
 if obj:require(mode=='normal' and obj['path']==str(attempt/'normal.olean'),'Interrupted normal object path differs');check(obj)
 namespace_check(stage,extension,pending)
 value=durable_result_payload(command,returned,pin(attempt/'COMMAND.json'),local_pin,log,obj,len(local),time.time_ns());value['process_return']=returned_pin
 if value['exit_code']==0 and value['stop_reason'] is None:
  parsed=parse_mode(stage,extension,batch,owner,mode,Path(log['path']).read_text(),value)
 else:parsed=None
 for item in local:check(item)
 value['mode_validation_error']=None;return dump(attempt/'RESULT.json',value)

def find_record(stage,extension,batch,owner,mode,pre,history=None,pending=None):
 base=Path(stage)/'steps'/owner/mode
 if not base.exists():return None
 attempts=list(base.iterdir());require(len(attempts)<=1,'No repeated attempts permitted')
 if not attempts:return None
 attempt=attempts[0];require(attempt.is_dir() and not attempt.is_symlink(),'Unknown attempt namespace')
 record=verify_record(stage,extension,batch,owner,mode,pre,attempt,history or [],pending or {})
 if record is None:raise ExistingProcessFailure('Existing durable failed/stopped attempt; no retry permission')
 return record

def materialize_contexts(stage,extension,batch,seal,history,pending):
 require(batch['owners']==[OWNER],'Only atomic ShapeArrays B1 context');catalog=dict(extension['parent_catalog']);normal=pending[OWNER]
 catalog[OWNER]={'source':extension['project_sources'][OWNER],'selected_object':pin(object_path(family_path(extension),OWNER)),'normal_success_artifact':normal['object'],'origin':'new_shape_B1_original_successful_modes'}
 path=Path(stage)/'accepted-contexts'/(OWNER+'.json');value={'schema':'shape_b1_accepted1643_context_v1','protocol':PROTOCOL,'family':extension['_anchor'],'batch':batch['_anchor'],'batch_seal':seal,'accepted_parent':batch['parent_context'],'project_closure':catalog,'native_artifacts':extension['native_artifacts'],'runtime':extension['runtime'],'lean_path':extension['lean_path'],'qualified_parent':extension['certificate'],'accepted_new_modules':[OWNER],'original_full_snapshot_verified':False,'formal_acceptance':True,'Cell06_integral_complete':False,'P2_6_complete':False}
 if path.exists():require(read(path)==value,'Existing accepted context differs')
 else:dump(path,value)

def load_contract(stage,family_sha,batch_sha,controller_sha,parent_sha):
 stage=safe_stage(ROOT,stage);family=stage.parent.parent
 require(family==ROOT/'families/main' and stage==family/'batches/shapeArraysB1','Only fixed B1 epoch')
 require(pin(ROOT/'shape_controller.py')['sha256']==controller_sha,'External controller SHA differs')
 fp=pin(family/'FAMILY.json');bp=pin(stage/'BATCH.json');require(fp['sha256']==family_sha and bp['sha256']==batch_sha,'External family/batch SHA differs')
 ext=read(fp['path']);batch=read(bp['path']);ext['_anchor']=fp;batch['_anchor']=bp
 require(batch['parent_context']['sha256']==parent_sha,'External parent SHA differs')
 try:
  ensure_clean(stage,ext)
  require(ext['protocol']==batch['protocol']==PROTOCOL and ext['family_root']==str(family),'Family/protocol path transplant')
  require(batch['family']==fp and batch['parent_context']==ext['base_context'] and batch['owners']==[OWNER] and batch['concurrency']==1,'Wrong exact B1 parent/owner')
  require(ext['scope_owners']==[OWNER] and ext['maximum_batch_size']==1 and ext['rss_gib']==12 and ext['wall_seconds']==2400,'Scope/internal limits changed')
  require(ext['outer_limits']=={'memory_mb':13107,'timeout_seconds':3600,'cpu_threads':1},'Outer resource ruling changed')
  check(ext['all_mode_barriers_manifest']);check(ext['failed_releases_manifest']);require(read(ext['all_mode_barriers_manifest']['path'])==ext['all_mode_barriers'] and read(ext['failed_releases_manifest']['path'])==ext['failed_releases'],'Frozen mode ledgers changed')
  require(read(ext['base_context']['path'])['project_closure']==ext['base_catalog'],'Copied1642 base differs')
  ext['parent_catalog']=ext['base_catalog'];ext['foundation']=ext['base_context'];ext['global_inputs']=batch['global_inputs'];ext['_closed_namespaces']={}
  require(env_hash(env_for(stage,ext))==batch['environment_sha256'],'Final mode environment differs')
  for item in ext['code_pins']+ext['authority_D_anchors']+batch['helpers']:check(item)
  require({i['path'] for i in batch['helpers']}=={str(stage/'helpers'/(OWNER+'.Owned.lean'))},'Full-owned helper selector differs')
  namespace_check(stage,ext,{}) if not (stage/'steps'/OWNER/'normal').exists() else validate_provider(ext)
  return ext,batch
 except Exception as exc:sticky(stage,'Anchored B1 contract/content mismatch',str(exc))


def anchors(stage,extension,batch):
    extension.setdefault('_anchor',pin(family_path(extension)/'FAMILY.json'))
    batch.setdefault('_anchor',pin(Path(stage)/'BATCH.json'))
    try:check(extension['_anchor']);check(batch['_anchor'])
    except Exception as exc:sticky(stage,'Anchored extension/batch content changed',str(exc))
    return extension['_anchor'],batch['_anchor']


def global_items(stage,extension,batch):
    try:
        selector=batch['global_inputs'];check(selector);spec=read(selector['path'])
        require(spec['protocol']==PROTOCOL and spec['family']==extension['_anchor'] and spec['parent_context']==batch['parent_context'],'Global selector transplant')
        require(spec['baseline']==extension['base_global_inputs'],'Global baseline selector differs')
        check(spec['baseline']);items=read(spec['baseline']['path'])
        require(isinstance(items,list),'Malformed global baseline')
        items+=spec['prefix_inputs']+spec['batch_static']+[selector,spec['baseline']]
    except Exception as exc:sticky(stage,'Anchored global input selector mismatch',str(exc),extension)
    family_pin,batch_pin=anchors(stage,extension,batch)
    return unique(items+[family_pin,batch_pin])


def snapshot(stage,extension,batch,purpose,pending):
    ensure_clean(stage,extension);started=time.monotonic()
    try:items=global_items(stage,extension,batch)
    except Exception as exc:sticky(stage,'Global contract/input-selector mismatch before '+purpose,str(exc))
    selector_seconds=time.monotonic()-started;namespace_started=time.monotonic()
    mismatches=[];total=0;digest=hashlib.sha256()
    try:namespace_check(stage,extension,pending)
    except Exception as exc:sticky(stage,'namespace mismatch before '+purpose,str(exc))
    namespace_pre_seconds=time.monotonic()-namespace_started;hash_started=time.monotonic()
    for expected in items:
        try:actual=pin(expected['path'])
        except (FileNotFoundError,OSError) as exc:
            mismatches.append({'expected':expected,'error':str(exc)});continue
        total+=actual['bytes'];digest.update(json.dumps(actual,sort_keys=True,separators=(',',':')).encode()+b'\n')
        if actual!=expected:mismatches.append({'expected':expected,'actual':actual})
    hash_seconds=time.monotonic()-hash_started;namespace_started=time.monotonic()
    try:namespace_check(stage,extension,pending)
    except Exception as exc:mismatches.append({'namespace':str(exc)})
    namespace_post_seconds=time.monotonic()-namespace_started
    report={'protocol':PROTOCOL,'purpose':purpose,'global_validation_scope':'batch_boundary',
            'family':pin(family_path(extension)/'FAMILY.json'),'batch':pin(Path(stage)/'BATCH.json'),
            'global_inputs':extension['global_inputs'],'files_checked':len(items),'bytes_read':total,
            'actual_map_sha256':digest.hexdigest(),'seconds':time.monotonic()-started,'matched':not mismatches,
            'timings':{'selector_seconds':selector_seconds,'global_byte_hash_seconds':hash_seconds,
                       'namespace_pre_seconds':namespace_pre_seconds,'namespace_post_seconds':namespace_post_seconds},
            'mismatches':mismatches,'checked_unix_ns':time.time_ns(),'formal_acceptance':False}
    path=Path(stage)/'state'/f'{purpose}-{time.time_ns()}.json';report_pin=dump(path,report)
    if mismatches:sticky(stage,'Observed global '+purpose+' mismatch',report_pin)
    return report_pin


def _validate_snapshot(snapshot_pin,stage,extension,batch,purpose=None):
    check(snapshot_pin);value=read(snapshot_pin['path'])
    require(value['protocol']==PROTOCOL and value['global_validation_scope']=='batch_boundary' and value['matched'] is True,'Invalid global snapshot')
    require(value['family']==pin(family_path(extension)/'FAMILY.json') and value['batch']==pin(Path(stage)/'BATCH.json'),'Snapshot contract transplant')
    require(value['global_inputs']==extension['global_inputs'] and value['files_checked']==len(global_items(stage,extension,batch)),'Snapshot input selector differs')
    if purpose is not None:require(value['purpose']==purpose,'Wrong snapshot purpose')
    return value


def validate_snapshot(snapshot_pin,stage,extension,batch,purpose=None):
    try:return _validate_snapshot(snapshot_pin,stage,extension,batch,purpose)
    except Exception as exc:sticky(stage,'Anchored global snapshot/reference mismatch',str(exc))


def pre_anchor(stage,extension,batch):
    path=Path(stage)/'state/GLOBAL_PRE.json'
    if path.exists():
        anchor=read(path);validate_snapshot(anchor['snapshot'],stage,extension,batch,'PRE');return anchor['snapshot']
    value=snapshot(stage,extension,batch,'PRE',{})
    dump(path,{'snapshot':value,'formal_acceptance':False});return value


def identity(stage,extension,batch,owner,mode,pre):
    extension_pin,batch_pin=anchors(stage,extension,batch)
    return {'protocol':PROTOCOL,'family':extension_pin,'batch':batch_pin,
            'key':owner,'mode':mode,'global_validation_scope':'batch_boundary','batch_pre':pre,
            'environment_sha256':env_hash(env_for(stage,extension)),'argv':argv_for(stage,extension,owner,mode),
            'cwd':str(family_path(extension)/'project'),'timeout':extension['wall_seconds'],'rss_bytes':extension['rss_gib']*1024**3}


def parse_mode(stage,extension,batch,owner,mode,text,result):
    require('sorryAx' not in text,'Forbidden sorryAx')
    if mode=='normal':return LEGACY.controller.normal_validator(text,result)
    if mode=='stock-leanchecker':return {'stock_leanchecker_exit_zero':True}
    prefix=batch['owners'][:batch['owners'].index(owner)+1]
    return LEGACY.evidence.validate_audit(text,[owner],set(extension['parent_catalog'])|set(prefix),extension['external_modules'])


def _verify_record(stage,extension,batch,owner,mode,pre,attempt,history=None,pending=None):
    validate_epoch_namespace(stage,batch)
    command_path,result_path,marker_path=(attempt/n for n in ('COMMAND.json','RESULT.json','PENDING.json'))
    require(command_path.is_file(),'Unknown attempt directory')
    recover_durable_result(stage,extension,batch,owner,mode,pre,attempt,history or [],pending or {})
    command=read(command_path);expected=identity(stage,extension,batch,owner,mode,pre)
    require(command['identity']==expected,'Wrong extension/batch/key/mode/environment/argv receipt')
    require(command['local_inputs']['path']==str(attempt/'LOCAL_INPUTS.json'),'LOCAL_INPUTS must belong to this exact attempt')
    check(command['local_inputs']);local=read(command['local_inputs']['path'])
    require(local==delta_items(stage,extension,batch,owner,mode,history or [],pending or {}),'Stored exact local D selector differs')
    try:
        for item in local:check(item)
    except Exception as exc:sticky(stage,'Stored local D byte mismatch',{'attempt':str(attempt),'error':str(exc)})
    actual=[str(attempt/'normal.olean') if a=='__NORMAL_OUTPUT__' else a for a in expected['argv']]
    require(command['actual_argv']==actual,'Actual argv transplant')
    require(result_path.exists(),'Unknown COMMAND interruption: recover evidence, never guess/re-normal')
    result=read(result_path)
    require('mode_validation_error' in result and result['mode_validation_error'] is None,'Recorded mode-validation failure or invalid RESULT schema; no promotion/retry')
    require(result['command']==pin(command_path),'Result/command chain differs')
    require(result['log']['path']==str(attempt/'output.log'),'Log must belong to this exact attempt')
    require(result['process_return']['path']==str(attempt/'PROCESS_RETURN.json'),'PROCESS_RETURN must belong to this exact attempt')
    check(result['process_return']);returned=read(result['process_return']['path'])
    require(returned['protocol']==PROTOCOL and returned['identity']==expected and returned['formal_acceptance'] is False
            and returned['status']=='PROCESS_RETURNED_PENDING_LOCAL_AND_GLOBAL_CHECKS','Wrong durable process return identity/status')
    require(returned['command']==pin(command_path) and returned['log']==result['log'] and returned['object']==result.get('object'),
            'Durable process return command/log/object differs')
    validate_process_schema(returned['process_result']);validate_process_schema(result)
    process_fields={'exit_code','stop_reason','seconds','sampled_peak_tree_rss_bytes'}
    require(set(returned['process_result'])==process_fields,'Unexpected process-return field set')
    require(type(returned['process_result']['exit_code']) is int and isinstance(returned['process_result']['seconds'],(int,float))
            and math.isfinite(returned['process_result']['seconds']) and returned['process_result']['seconds']>=0 and type(returned['process_result']['sampled_peak_tree_rss_bytes']) is int
            and returned['process_result']['sampled_peak_tree_rss_bytes']>=0,'Invalid process timing/status values')
    require(all(result[k]==returned['process_result'][k] for k in process_fields),'Durable process return fields differ from RESULT')
    require(result['protocol']==PROTOCOL and result['global_validation_scope']=='batch_boundary' and 'postcheck' not in result
            and result['formal_acceptance'] is False,'Mode falsely reports per-step global/formal validation')
    require(result['local_post']=={'inputs':command['local_inputs'],'all_local_files_matched':True,'file_count':len(local)},'Wrong local D postcheck')
    check(result['log'])
    if result.get('object'):check(result['object'])
    if mode=='normal':
        if result.get('object'):require(result['object']['path']==str(attempt/'normal.olean'),'Wrong exact normal artifact path')
    else:require(result.get('object') is None,'Non-normal mode cannot claim a new object')
    if result['exit_code']!=0 or result.get('stop_reason'):
        require(not marker_path.exists(),'Failed process has pending-success marker');return None
    if mode=='normal':require(result['object']['path']==str(attempt/'normal.olean'),'Wrong permanent normal artifact')
    parsed=parse_mode(stage,extension,batch,owner,mode,Path(result['log']['path']).read_text(),result)
    marker={'protocol':PROTOCOL,'status':'NORMAL_SUCCEEDED_PENDING_GLOBAL' if mode=='normal' else 'PROCESS_VALIDATED_PENDING_GLOBAL',
            'identity':expected,'result':pin(result_path),'process_return':result['process_return'],
            'validated':parsed,'formal_acceptance':False,'batch_post':None,'P2_6_complete':False}
    if marker_path.exists():require(read(marker_path)==marker,'Pending marker differs or makes a false formal/global claim')
    else:dump(marker_path,marker) # Recover a durable successful result without execution.
    validate_epoch_namespace(stage,batch)
    return {'owner':owner,'mode':mode,'marker':pin(marker_path),'result':pin(result_path),'command':pin(command_path),
            'log':result['log'],'local_inputs':command['local_inputs'],'process_return':result['process_return'],'object':result.get('object'),'validated':parsed}


def verify_record(stage,extension,batch,owner,mode,pre,attempt,history=None,pending=None):
    try:return _verify_record(stage,extension,batch,owner,mode,pre,attempt,history,pending)
    except RuntimeError as exc:
        if 'Unknown COMMAND interruption' in str(exc):raise
        sticky(stage,'Anchored mode D receipt/content mismatch',str(exc))
    except Exception as exc:sticky(stage,'Anchored mode D receipt/content mismatch',str(exc))


def run_mode(stage,extension,batch,owner,mode,pre,history,pending,executor=real_executor):
    ensure_clean(stage,extension);validate_snapshot(pre,stage,extension,batch,'PRE')
    previous=find_record(stage,extension,batch,owner,mode,pre,history,pending)
    if previous:return previous
    authorize_mode(extension,owner,mode,_loader)
    if mode=='normal':
        try:refuse_other_stage_normal(stage,extension,owner)
        except Exception as exc:sticky(stage,'Observed cross-root normal barrier mismatch',str(exc),extension)
    require(shutil.disk_usage(stage).free>1024**3,'Leave1GiB reserve before a new mode')
    local_started=time.monotonic()
    try:
        local=delta_items(stage,extension,batch,owner,mode,history,pending)
        namespace_check(stage,extension,pending)
        for item in local:check(item)
    except Exception as exc:sticky(stage,'Observed local D mismatch before mode',str(exc))
    local_pre_seconds=time.monotonic()-local_started
    extension['_deferred_mode']=mode
    require_mode_budget(extension['_invocation_deadline'],time.monotonic(),extension['wall_seconds'],300)
    attempt=Path(stage)/'steps'/owner/mode/(str(time.time_ns())+'-'+uuid.uuid4().hex[:8]);attempt.mkdir(parents=True)
    local_pin=dump(attempt/'LOCAL_INPUTS.json',local);ident=identity(stage,extension,batch,owner,mode,pre)
    actual=[str(attempt/'normal.olean') if a=='__NORMAL_OUTPUT__' else a for a in ident['argv']]
    dump(attempt/'COMMAND.json',{'identity':ident,'actual_argv':actual,'local_inputs':local_pin,'started_unix_ns':time.time_ns()})
    log=attempt/'output.log';result=invoke_executor(executor,extension,mode,owner,actual,ident['cwd'],env_for(stage,extension),log,ident['timeout'],ident['rss_bytes'])
    returned={'protocol':PROTOCOL,'identity':ident,'process_result':result,'command':pin(attempt/'COMMAND.json'),
              'log':pin(log),'object':pin(attempt/'normal.olean') if mode=='normal' and (attempt/'normal.olean').is_file() else None,
              'status':'PROCESS_RETURNED_PENDING_LOCAL_AND_GLOBAL_CHECKS','formal_acceptance':False}
    return_pin=dump(attempt/'PROCESS_RETURN.json',returned)
    local_started=time.monotonic()
    try:
        for item in local:check(item)
        namespace_check(stage,extension,pending)
    except Exception as exc:sticky(stage,'Observed local D mismatch after mode',{'attempt':str(attempt),'error':str(exc)})
    local_post_seconds=time.monotonic()-local_started
    obj=attempt/'normal.olean'
    result={**result,'protocol':PROTOCOL,'global_validation_scope':'batch_boundary','command':pin(attempt/'COMMAND.json'),
            'process_return':return_pin,
            'log':pin(log),'local_post':{'inputs':local_pin,'all_local_files_matched':True,'file_count':len(local)},
            'object':pin(obj) if mode=='normal' and obj.is_file() else None,'formal_acceptance':False,
            'timings':{'local_D_pre_seconds':local_pre_seconds,'local_D_post_seconds':local_post_seconds,
                       'local_D_expected_bytes':sum(i['bytes'] for i in local),'process_seconds':result.get('seconds')}}
    validation_error=None;validation_started=time.monotonic()
    if result['exit_code']==0 and not result.get('stop_reason'):
        try:parse_mode(stage,extension,batch,owner,mode,log.read_text(),result)
        except Exception as exc:validation_error=str(exc)
    result['timings']['mode_validation_seconds']=time.monotonic()-validation_started
    result['mode_validation_error']=validation_error
    dump(attempt/'RESULT.json',result)
    require(result['exit_code']==0 and not result.get('stop_reason'),'Mode failed; evidence/output retained')
    require(validation_error is None,'Mode validation failed; successful process artifact retained: '+str(validation_error))
    return verify_record(stage,extension,batch,owner,mode,pre,attempt,history,pending)


def recover_history(stage,extension,batch,pre):
    try:validate_epoch_namespace(stage,batch)
    except Exception as exc:sticky(stage,'Observed recovered epoch namespace mismatch',str(exc))
    history=[];pending={};gap=False
    for owner in batch['owners']:
        for mode in MODES:
            record=find_record(stage,extension,batch,owner,mode,pre,history,pending)
            if record is None:gap=True;continue
            require(not gap,'Non-prefix provisional mode history')
            history.append(record)
            if mode=='normal':
                pending[owner]=record
                try:catalog_objects(stage,extension,pending)
                except Exception as exc:sticky(stage,'Provisional canonical object mismatch',str(exc))
    try:namespace_check(stage,extension,pending)
    except Exception as exc:sticky(stage,'Recovered provisional namespace mismatch',str(exc))
    return history,pending


def validate_all_delta(history):
    items=[]
    for record in history:
        for key in ('marker','result','command','log','local_inputs','process_return'):items.append(record[key])
        items += read(record['local_inputs']['path'])
        if record['object']:items.append(record['object'])
    items=unique(items)
    for item in items:check(item)
    return items


def complete_delta_inventory(stage,history):
    validate_epoch_namespace(stage)
    expected=validate_all_delta(history)
    allowed={'COMMAND.json','RESULT.json','PENDING.json','LOCAL_INPUTS.json','PROCESS_RETURN.json','output.log','normal.olean'}
    owners={r['owner'] for r in history}
    for path in (Path(stage)/'steps').rglob('*') if (Path(stage)/'steps').exists() else []:
        if path.is_file():
            parts=path.relative_to(Path(stage)/'steps').parts
            require(len(parts)==4 and parts[0] in owners and parts[1] in MODES and path.name in allowed and (path.name!='normal.olean' or parts[1]=='normal'),'Unknown file in mode D namespace')
            expected.append(pin(path))
    # All prior global boundary/resume reports are retained and bound, too.
    for path in (Path(stage)/'state').rglob('*'):
        if not path.is_file():continue
        require(path.parent==Path(stage)/'state' and path.suffix=='.json','Unknown non-JSON/nested state artifact')
        if path.name=='GLOBAL_PRE.json' or path.name.startswith(('PRE-','RESUME-','POST-','DEFER-')):expected.append(pin(path))
        else:require(path.name in ('BATCH_ACCEPTED.json','INTEGRITY_FAILED.json'),'Unknown batch state file')
    return unique(expected)


def execute_pending(stage,extension,batch,pre,executor=real_executor):
    history,pending=recover_history(stage,extension,batch,pre)
    completed={(r['owner'],r['mode']) for r in history}
    for owner in batch['owners']:
        for mode in MODES:
            if (owner,mode) in completed:continue
            record=run_mode(stage,extension,batch,owner,mode,pre,history,pending,executor)
            history.append(record);completed.add((owner,mode))
            if mode=='normal':pending[owner]=record
    return history,pending


def finish(stage,extension,batch,pre,history,pending):
    ensure_clean(stage,extension);require(len(history)==3*len(batch['owners']) and set(pending)==set(batch['owners']),'All declared owners require all three modes')
    try:delta=complete_delta_inventory(stage,history);namespace_check(stage,extension,pending)
    except Exception as exc:sticky(stage,'Final D mismatch',str(exc))
    post=snapshot(stage,extension,batch,'POST',pending)
    if validate_snapshot(post,stage,extension,batch,'POST')['actual_map_sha256']!=validate_snapshot(pre,stage,extension,batch,'PRE')['actual_map_sha256']:
        sticky(stage,'PRE/POST actual maps differ',{'pre':pre,'post':post})
    try:
        for item in delta:check(item)
        validate_all_delta(history);namespace_check(stage,extension,pending)
        delta=complete_delta_inventory(stage,history)
        for item in delta:check(item)
    except Exception as exc:sticky(stage,'Final D changed around global POST',str(exc))
    accepted={'protocol':PROTOCOL,'status':'BATCH_ACCEPTED','family':pin(family_path(extension)/'FAMILY.json'),'batch':pin(Path(stage)/'BATCH.json'),
              'global_validation_scope':'batch_boundary','parent_context':batch['parent_context'],'global_pre':pre,'global_post':post,'owners':batch['owners'],
              'pending_mode_receipts':[r['marker'] for r in history],'delta_inputs':delta,'formal_acceptance':True,'P2_6_complete':False}
    seal=dump(Path(stage)/'state/BATCH_ACCEPTED.json',accepted)
    materialize_contexts(stage,extension,batch,seal,history,pending)
    return seal


def _verify_accepted(stage,extension,batch):
    ensure_clean(stage,extension);path=Path(stage)/'state/BATCH_ACCEPTED.json';value=read(path)
    require(value['protocol']==PROTOCOL and value['status']=='BATCH_ACCEPTED' and value['formal_acceptance'] is True,'Wrong accepted batch seal')
    require(value['family']==pin(family_path(extension)/'FAMILY.json') and value['batch']==pin(Path(stage)/'BATCH.json'),'Accepted seal transplant')
    validate_snapshot(value['global_pre'],stage,extension,batch,'PRE');validate_snapshot(value['global_post'],stage,extension,batch,'POST')
    history,pending=recover_history(stage,extension,batch,value['global_pre'])
    require([r['marker'] for r in history]==value['pending_mode_receipts'] and len(history)==3*len(batch['owners']),'Accepted mode set differs')
    for item in value['delta_inputs']:check(item)
    require(value['delta_inputs']==complete_delta_inventory(stage,history),'Accepted final D inventory differs')
    for item in global_items(stage,extension,batch):check(item)
    namespace_check(stage,extension,pending)
    materialize_contexts(stage,extension,batch,pin(path),history,pending)
    return pin(path)


def verify_accepted(stage,extension,batch):
    try:return _verify_accepted(stage,extension,batch)
    except Exception as exc:sticky(stage,'Accepted batch referenced content mismatch',str(exc))


def run_batch(stage,extension,batch,executor=real_executor):
    ensure_clean(stage,extension)
    if (Path(stage)/'state/BATCH_ACCEPTED.json').exists():return verify_accepted(stage,extension,batch)
    had_pre=(Path(stage)/'state/GLOBAL_PRE.json').exists()
    pre=pre_anchor(stage,extension,batch)
    history,pending=recover_history(stage,extension,batch,pre)
    if had_pre and len(history)<3*len(batch['owners']):
        # A resumed unfinished batch gets a fresh complete real-byte recheck.
        snapshot(stage,extension,batch,'RESUME',pending)
    history,pending=execute_pending(stage,extension,batch,pre,executor)
    return finish(stage,extension,batch,pre,history,pending)


