#!/usr/bin/env python3
"""Source-only exact ShapeArrays B1 controller. No implicit authority or successor."""
import sys
if not sys.flags.isolated or not sys.dont_write_bytecode:raise SystemExit('Use isolated python -I -B')
import hashlib,json,os,types
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def fail(message):raise SystemExit(message)
def pairs(rows):
 d={}
 for k,v in rows:
  if k in d:fail('Duplicate JSON key')
  d[k]=v
 return d

def decode(raw):return json.loads(raw,object_pairs_hook=pairs,parse_constant=lambda x:fail('Nonfinite JSON'))
def rawpin(path,raw):return {'path':str(Path(path).absolute()),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def source(item):
 raw=Path(item['path']).read_bytes()
 if rawpin(item['path'],raw)!=item:fail('Source/runtime pin mismatch')
 return raw

def validate_B1_request(extension,graph,parent_pin,name,count,epoch_index):
 owner='ImbalancedChen.P2OriginalSaving19Geometry06ScalableShapeArrays'
 if type(count) is not int or count!=1 or name!='shapeArraysB1' or epoch_index!=1:raise RuntimeError('Only first exact ShapeArrays B1/count1 is enabled')
 if parent_pin!=extension['base_context'] or extension['scope_owners']!=[owner]:raise RuntimeError('Wrong exact B1 parent/scope')
 remaining=[n for n in graph['topological_order'] if n not in extension['base_catalog']]
 if not remaining or remaining[0]!=owner:raise RuntimeError('Wrong next graph owner')
 return [owner]

def validate_family(common,loader,family_pin,lockpin,delivery):
 family=Path(family_pin['path']).parent;common.require(family==ROOT/'families/main','Only independent fixed family')
 extension=common.read(family_pin['path']);extension['_anchor']=family_pin
 try:
  common.ensure_clean(family)
  common.require(extension['protocol']==common.PROTOCOL and extension['family_root']==str(family) and extension['scope_owners']==[common.OWNER],'Wrong fixed family scope')
  common.require(extension['maximum_batch_size']==1 and extension['concurrency']==1 and extension['rss_gib']==12 and extension['wall_seconds']==2400,'Wrong fixed limits')
  common.require(extension['outer_limits']=={'memory_mb':13107,'timeout_seconds':3600,'cpu_threads':1},'Wrong outer resource ruling')
  common.require(lockpin in extension['code_pins'] and delivery in extension['code_pins'],'Code/lock/delivery transplant')
  for item in extension['code_pins']+extension['authority_D_anchors']+[extension['base_context'],extension['certificate'],extension['transport'],extension['cold_readback']]:common.check(item)
  base=common.read(extension['base_context']['path']);common.require(base['project_closure']==extension['base_catalog'] and len(base['project_closure'])==1642 and len(extension['native_artifacts'])==555,'Copied qualified1642 differs')
  cold=common.read(extension['cold_readback']['path']);common.require(cold['actual_matched'] is True and cold['baseline']==extension['base_global_inputs'] and cold['family_root']==str(family),'Cold readback transplant')
 except Exception as exc:common.sticky(family,'Anchored family preflight mismatch',str(exc))
 return extension

def freeze_B1(common,engine,loader,extension,parent_pin,name,count):
 family=Path(extension['family_root']);graph=common.read(extension['graph']['path'])
 validate_B1_request(extension,graph,parent_pin,name,count,1)
 common.check(parent_pin);common.check(extension['graph']);epoch=common.safe_stage(ROOT,family/'batches'/name)
 common.require(not list((family/'batches').iterdir()),'Only one exclusive first B1 epoch; no successor')
 try:
  engine.validate_provider(extension)
  available=set(extension['base_catalog'])
  common.require({n for n in graph['entries'][common.OWNER]['imports'] if n.startswith('ImbalancedChen.')}<=available,'Unaccepted project dependency')
  extension['parent_catalog']=extension['base_catalog'];engine.namespace_check(epoch,extension,{})
  engine.refuse_other_stage_normal(epoch,extension,common.OWNER)
 except Exception as exc:common.sticky(family,'Anchored B1 freeze preflight mismatch',str(exc))
 epoch.mkdir()
 for part in ('helpers','state','steps','accepted-contexts','home','tmp'):(epoch/part).mkdir()
 helper=epoch/'helpers'/(common.OWNER+'.Owned.lean')
 with helper.open('x') as f:f.write(engine.LEGACY.templates.audit(sorted(extension['base_catalog'])+[common.OWNER],[common.OWNER]))
 hp=common.pin(helper);whitelist=common.dump(epoch/'WHITELIST.json',[common.OWNER])
 selector=common.dump(epoch/'GLOBAL_INPUTS.json',{'protocol':common.PROTOCOL,'family':extension['_anchor'],'parent_context':parent_pin,'baseline':extension['base_global_inputs'],'prefix_inputs':[parent_pin],'batch_static':[hp,whitelist,extension['cold_readback']]})
 value={'schema':'shape_b1_exact_single_epoch_v1','protocol':common.PROTOCOL,'family':extension['_anchor'],'epoch_index':1,'parent_context':parent_pin,'owners':[common.OWNER],'accepted_before':[],'global_inputs':selector,'helpers':[hp],'whitelist':whitelist,'environment_sha256':common.env_hash(common.env_for(epoch,extension)),'concurrency':1,'failure_policy':'atomic_exact_B1','global_validation_scope':'batch_boundary','normal_success_recompile_allowed':False,'formal_acceptance':False,'P2_6_complete':False}
 return common.dump(epoch/'BATCH.json',value)

def main():
 if sys.argv[1:]==['--help']:print('check-bootstrap | collect-parent | seed | freeze | run; explicit external SELF/LOCK and real authority required');return
 args=sys.argv[1:]
 if not args:fail('Explicit command required')
 command=args.pop(0);options={}
 if command not in ('check-bootstrap','collect-parent','seed','freeze','run') or len(args)%2:fail('Invalid command/flag pairs')
 for k,v in zip(args[::2],args[1::2]):
  if not k.startswith('--') or k in options:fail('Duplicate/invalid option')
  options[k]=v
 common_flags={'--controller-sha256','--source-lock-file','--source-lock-sha256'}
 command_flags={'check-bootstrap':set(),'collect-parent':{'--input-contract','--input-contract-sha256','--graph','--graph-sha256','--shape-source','--shape-source-sha256','--output','--delivery-sha256'},'seed':{'--certificate','--certificate-sha256','--family','--rss-gib','--wall-seconds','--delivery-sha256'},'freeze':{'--family','--family-sha256','--parent-context','--parent-sha256','--epoch','--count','--delivery-sha256'},'run':{'--epoch-directory','--family-sha256','--batch-sha256','--parent-sha256','--delivery-sha256'}}
 if set(options)!=common_flags|command_flags[command]:fail('Missing/unknown explicit command flags')
 for k in ('--controller-sha256','--source-lock-file','--source-lock-sha256'):
  if k not in options:fail('Missing external '+k)
 ownraw=Path(__file__).read_bytes();own=rawpin(__file__,ownraw)
 if own['sha256']!=options['--controller-sha256']:fail('External SELF SHA mismatch')
 lp=Path(options['--source-lock-file']).absolute();lr=lp.read_bytes();lockpin=rawpin(lp,lr)
 if lockpin['sha256']!=options['--source-lock-sha256']:fail('External LOCK SHA mismatch')
 lock=decode(lr)
 if lock['schema']!='shape_b1_source_lock_v1' or lock['controller']!=own:fail('Wrong source-only lock/controller')
 for item in list(lock['modules'].values())+lock.get('inputs',[]):source(item)
 if lock['python']['path']!=str(Path(sys.executable).resolve()):fail('Wrong isolated Python runtime')
 source(lock['python'])
 item=lock['modules']['shape_source_loader'];m=types.ModuleType('shape_bootstrap_loader');m.__file__=item['path'];m.__cached__=None
 exec(compile(source(item),item['path'],'exec',dont_inherit=True),m.__dict__);loader=m.SourceLoader(lock['modules']);common=loader.load('shape_common')
 if command=='check-bootstrap':
  with common.ProcessGuard() as guard,common.WriteGuard(ROOT/'.no-bootstrap-writes'):
   loader.load('shape_parent')
  print(json.dumps({'status':'SOURCE_BOOTSTRAP_ONLY','source_lock':lockpin,'executor_calls':guard.attempts,'G_runs':0,'seed_runs':0,'Lean_commands':0,'formal_acceptance':False}));return
 import fcntl,time
 invocation_started=time.monotonic()
 delivery=common.external(ROOT/'DELIVERY.json',options['--delivery-sha256'])
 manifest=common.read(delivery['path'])
 for item in manifest['members']:common.check(item)
 controls=common.unique([own,lockpin,delivery,lock['python'],*lock['modules'].values(),*lock.get('inputs',[]),*manifest['members']])
 lockpath=common.safe_stage(ROOT,ROOT/'EXECUTION.lock')
 with os.fdopen(os.open(lockpath,os.O_RDWR|os.O_CREAT|os.O_NOFOLLOW,0o600),'a+') as execution_lock:
  fcntl.flock(execution_lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  return operate(command,options,common,loader,lockpin,delivery,controls,invocation_started)

def operate(command,options,common,loader,lockpin,delivery,controls,invocation_started):
 import time
 if command=='collect-parent':
  needed=['--input-contract','--input-contract-sha256','--graph','--graph-sha256','--shape-source','--shape-source-sha256','--output','--delivery-sha256']
  for k in needed:
   if k not in options:fail('Missing explicit '+k)
  output=common.safe_stage(ROOT,options['--output']);common.require(output.parent==ROOT/'certificates','Certificate must be directly under exclusive certificates/')
  with common.ProcessGuard(),common.WriteGuard(output.parent):
   parent=loader.load('shape_parent');ip=common.external(options['--input-contract'],options['--input-contract-sha256']);authority=parent.validate_authority_contract(common.strict_json(Path(ip['path']).read_bytes()))
   if common.external(options['--graph'],options['--graph-sha256'])!=authority['graph'] or common.external(options['--shape-source'],options['--shape-source-sha256'])!=authority['shape_source']:fail('Explicit graph/source differs from authority contract')
   output=common.safe_stage(ROOT,options['--output']);common.require(not output.exists(),'Exclusive certificate required');certificate=parent.collect_qualified_prefix(ip,loader);certificate['controller_source_lock']=lockpin;certificate['controller_delivery']=common.external(ROOT/'DELIVERY.json',options['--delivery-sha256']);result=common.dump(output,certificate)
  print(json.dumps({'certificate':result,'formal_acceptance':False,'Lean_commands':0}));return
 if command=='seed':
  family=common.safe_stage(ROOT,options['--family']);certificate=common.external(options['--certificate'],options['--certificate-sha256'])
  common.require(family==ROOT/'families/main','Only fixed independent family')
  with common.ProcessGuard(),common.WriteGuard(family.parent):fp=common.seed_family(family,certificate,int(options['--rss-gib']),int(options['--wall-seconds']),loader,controls)
  print(json.dumps({'family':fp,'formal_acceptance':False,'Lean_commands':0,'scope':'SEED_ONLY'}));return
 engine=loader.load('shape_engine');engine.configure(loader)
 if command=='freeze':
  family=common.safe_stage(ROOT,options['--family']);common.require(family==ROOT/'families/main','Only fixed family')
  fp=common.external(family/'FAMILY.json',options['--family-sha256']);parent_pin=common.external(options['--parent-context'],options['--parent-sha256']);count=int(options['--count'])
  # Pure input mistakes are rejected before anchored integrity checks.
  common.require(options['--epoch']=='shapeArraysB1' and count==1,'Only fixed first B1/count1')
  with common.ProcessGuard(),common.WriteGuard(family):
   ext=validate_family(common,loader,fp,lockpin,delivery);bp=freeze_B1(common,engine,loader,ext,parent_pin,options['--epoch'],count)
  print(json.dumps({'batch':bp,'formal_acceptance':False,'Lean_commands':0,'scope':'FREEZE_ONLY'}));return
 stage=common.safe_stage(ROOT,options['--epoch-directory']);common.require(stage==ROOT/'families/main/batches/shapeArraysB1','Only exact B1 epoch')
 fp=common.external(stage.parent.parent/'FAMILY.json',options['--family-sha256']);common.external(stage/'BATCH.json',options['--batch-sha256'])
 with common.WriteGuard(stage.parent.parent):
  validate_family(common,loader,fp,lockpin,delivery)
  ext,batch=engine.load_contract(stage,options['--family-sha256'],options['--batch-sha256'],options['--controller-sha256'],options['--parent-sha256'])
  ext['_invocation_deadline']=invocation_started+3600-30
  try:seal=engine.run_batch(stage,ext,batch)
  except engine.BudgetDeferred as exc:
   receipt=common.dump(stage/'state'/('DEFER-'+str(time.time_ns())+'.json'),{'protocol':common.PROTOCOL,'status':'UNSTARTED_MODE_DEFERRED','family':fp,'batch':batch['_anchor'],'mode':ext['_deferred_mode'],'reason':str(exc),'COMMAND_created_for_deferred_mode':False,'formal_acceptance':False})
   print(json.dumps({'deferred':receipt,'formal_acceptance':False,'missing_modes_may_resume_samebytes':True}));return
 print(json.dumps({'seal':seal,'context':common.pin(stage/'accepted-contexts'/(common.OWNER+'.json')),'formal_acceptance':True,'Cell06_integral_complete':False,'P2_6_complete':False}))

if __name__=='__main__':main()
