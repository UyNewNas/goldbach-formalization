"""Source-reviewed function port; never imports or executes the v3 engine/main."""
from pathlib import Path
import ast,hashlib
ROOT=Path(__file__).resolve().parent
p=Path('/workspace/p26-cell06-family-revision3-20261128/revision_engine.py');raw=p.read_bytes();assert hashlib.sha256(raw).hexdigest()=='e442e624455b96fcc6f22401f9f6d2fb0ac34100b59136109c16bf42809cdbc1'
s=raw.decode();lines=s.splitlines(True);tree=ast.parse(s)
keep=['anchors','global_items','snapshot','_validate_snapshot','validate_snapshot','pre_anchor','identity','parse_mode','_verify_record','verify_record','run_mode','recover_history','validate_all_delta','complete_delta_inventory','execute_pending','finish','_verify_accepted','verify_accepted','run_batch']
parts=[]
for node in tree.body:
 if isinstance(node,ast.FunctionDef) and node.name in keep:parts.append(''.join(lines[node.lineno-1:node.end_lineno])+'\n\n')
text=''.join(parts).replace('OLD.','LEGACY.')
text=text.replace("def _verify_record(stage,extension,batch,owner,mode,pre,attempt):","def _verify_record(stage,extension,batch,owner,mode,pre,attempt,history=None,pending=None):")
text=text.replace("    command=read(command_path);expected=identity(stage,extension,batch,owner,mode,pre)","    recover_durable_result(stage,extension,batch,owner,mode,pre,attempt,history or [],pending or {})\n    command=read(command_path);expected=identity(stage,extension,batch,owner,mode,pre)")
text=text.replace("check(command['local_inputs']);local=read(command['local_inputs']['path'])","check(command['local_inputs']);local=read(command['local_inputs']['path'])\n    require(local==delta_items(stage,extension,batch,owner,mode,history or [],pending or {}),'Stored exact local D selector differs')")
text=text.replace("def verify_record(stage,extension,batch,owner,mode,pre,attempt):","def verify_record(stage,extension,batch,owner,mode,pre,attempt,history=None,pending=None):")
text=text.replace("_verify_record(stage,extension,batch,owner,mode,pre,attempt)","_verify_record(stage,extension,batch,owner,mode,pre,attempt,history,pending)")
text=text.replace("previous=find_record(stage,extension,batch,owner,mode,pre)","previous=find_record(stage,extension,batch,owner,mode,pre,history,pending)")
text=text.replace("record=find_record(stage,extension,batch,owner,mode,pre)","record=find_record(stage,extension,batch,owner,mode,pre,history,pending)")
text=text.replace("    if mode=='normal':\n        try:refuse_other_stage_normal", "    authorize_mode(extension,owner,mode,_loader)\n    if mode=='normal':\n        try:refuse_other_stage_normal")
text=text.replace("attempt=Path(stage)/'steps'/owner/mode/(str(time.time_ns())+'-'+uuid.uuid4().hex[:8]);attempt.mkdir(parents=True)","require_mode_budget(extension['_invocation_deadline'],time.monotonic(),extension['wall_seconds'],300)\n    attempt=Path(stage)/'steps'/owner/mode/(str(time.time_ns())+'-'+uuid.uuid4().hex[:8]);attempt.mkdir(parents=True)")
text=text.replace("return unique(items+spec['prefix_inputs']+spec['batch_static']+[selector,spec['baseline'],*anchors(stage,extension,batch)])", "return unique(items+spec['prefix_inputs']+spec['batch_static']+[selector,spec['baseline'],extension['cold_readback'],*anchors(stage,extension,batch)])")
text=text.replace("def execute_pending(stage,extension,batch,pre,executor=real_executor):", "def execute_pending(stage,extension,batch,pre,executor=real_executor):")
text=text.replace("if path.name=='GLOBAL_PRE.json' or path.name.startswith(('PRE-','RESUME-','POST-'))", "if path.name=='GLOBAL_PRE.json' or path.name.startswith(('PRE-','RESUME-','POST-','DEFER-'))")
header='''"""New B1 engine; immutable source port, no old module monkeypatch/ROOT rebinding."""
import hashlib,json,os,shutil,time,uuid,math
from pathlib import Path
from types import SimpleNamespace
from shape_common import *
from shape_parent import collect_qualified_prefix,validate_failed_shape_release,GRAPH_SHA,SOURCE_SHA
_loader=None
LEGACY=None

def configure(loader):
 global _loader,LEGACY
 _loader=loader;LEGACY=SimpleNamespace(evidence=loader.load('evidence'),controller=loader.load('controller'),templates=loader.load('templates'))

class BudgetDeferred(RuntimeError):pass
class AmbiguousInterruption(RuntimeError):pass
class ExistingProcessFailure(RuntimeError):pass

def require_mode_budget(deadline,now,wall=2400,reserve=300):
 if deadline-now<wall+reserve:raise BudgetDeferred('Unstarted mode deferred before COMMAND: need2400s plus300s post/exit reserve')

def original_command_reference(item,rows):
 current=item;seen=set()
 while True:
  require(current['path'] not in seen,'Transport command alias cycle');seen.add(current['path'])
  matches=[row for row in rows if row['physical']==current]
  if not matches:return current
  require(len(matches)==1,'Conflicting command transport aliases');row=matches[0]
  require(row['original_identity_preserved'] is True and same_bytes(row['logical'],row['physical']),'Command identity rewritten during transport')
  check(row['physical']);check(row['logical']);current=row['logical']

def authorize_mode(extension,owner,mode,loader,release_validator=None):
 require(mode in MODES,'Unknown mode')
 blocked={row['module']:row for row in extension['all_mode_barriers']}
 require(owner not in blocked or mode not in blocked[owner]['forbidden_modes'],'All-mode membership/pending/oldData barrier')
 require(owner==OWNER and extension['scope_owners']==[OWNER],'Only fixed ShapeArrays B1 is authorized')
 require(extension['graph']['sha256']==GRAPH_SHA and extension['project_sources'][owner]['sha256']==SOURCE_SHA,'Wrong B1 graph/source')
 check(extension['graph']);check(extension['project_sources'][owner])
 cert=read(extension['certificate']['path']);check(extension['certificate'])
 require(extension['failed_releases']==cert['failed_releases'] and len(extension['failed_releases'])==1,'Failed-release class/tuple changed')
 validator=release_validator or validate_failed_shape_release
 validator(extension['failed_releases'][0],extension['graph'],extension['project_sources'][owner],loader)

def require_durable_outcome(attempt):
 attempt=Path(attempt)
 if not (attempt/'RESULT.json').exists() and not (attempt/'PROCESS_RETURN.json').exists():raise AmbiguousInterruption('Unknown COMMAND interruption; no guessed retry')

def durable_result_payload(command,returned,command_pin,local_pin,log_pin,object_pin,local_count,observed_ns):
 require(returned['identity']==command['identity'] and returned['command']==command_pin and command['local_inputs']==local_pin,'Durable COMMAND/identity/D transplant')
 require(returned['log']==log_pin and returned['object']==object_pin and returned['formal_acceptance'] is False and returned['status']=='PROCESS_RETURNED_PENDING_LOCAL_AND_GLOBAL_CHECKS','Durable return/log/object differs')
 metrics=process_schema(returned['process_result'])
 require(set(returned['process_result'])==set(metrics),'Unexpected durable process fields')
 return {**metrics,'protocol':returned['protocol'],'global_validation_scope':'batch_boundary','command':command_pin,'process_return':None,'log':log_pin,'local_post':{'inputs':local_pin,'all_local_files_matched':True,'file_count':local_count},'object':object_pin,'formal_acceptance':False,'timings':{'process_seconds':metrics['seconds']},'recovery_local_post':{'observed_unix_ns':observed_ns,'scope':'actual_recovery_time'},'mode_validation_error':None}

def validate_provider(extension):
 cert=read(extension['certificate']['path']);check(extension['certificate']);current=collect_qualified_prefix(cert['input_contract'],_loader)
 require({k:v for k,v in cert.items() if k not in ('controller_source_lock','controller_delivery')}==current,'Qualified parent provider changed')
 return cert

def catalog_objects(stage,extension,pending):
 selected=[];root=family_path(extension)
 for owner,entry in extension['parent_catalog'].items():
  target=object_path(root,owner);expected=entry['selected_object'];require(expected['path']==str(target),'Canonical parent object path differs')
  if target.exists():check(expected)
  else:
   source=extension['restore_parent_objects'][owner];check(source);copy_exact(source['path'],target,source);check(expected)
  selected.append(expected)
 for item in extension['native_artifacts']:check(item);selected.append(item)
 for owner,record in pending.items():
  require(owner not in extension['parent_catalog'],'Pending owner overlaps accepted parent');target=object_path(root,owner);expected={**record['object'],'path':str(target)}
  if target.exists():check(expected)
  else:copy_exact(record['object']['path'],target,record['object'])
  selected.append(expected)
 return unique(selected)

def namespace_check(stage,extension,pending):
 root=family_path(extension);objects=catalog_objects(stage,extension,pending)
 exact_tree(root/'objects',[i['path'] for i in objects]);exact_tree(root/'project',extension['project_files'])
 transport=read(extension['transport']['path']);check(extension['transport'])
 evidence=[row['physical']['path'] for row in transport['rows'] if Path(row['physical']['path']).is_relative_to(root/'evidence')]
 exact_tree(root/'evidence',evidence)
 restore=[x['path'] for x in extension['restore_parent_objects'].values()];exact_tree(root/'restore-parent',restore)
 validate_provider(extension)

def delta_items(stage,extension,batch,owner,mode,history,pending):
 helper=[x for x in batch['helpers'] if x['path']==str(Path(stage)/'helpers'/(owner+'.Owned.lean'))];require(len(helper)==1,'Exact auditor helper required')
 items=[extension['project_sources'][owner],helper[0],*extension['code_pins'],*extension['runtime'].values(),*extension['authority_D_anchors']]
 for record in history:
  items += [record[k] for k in ('marker','result','command','log','local_inputs','process_return')]
  if record['object']:items.append(record['object'])
 for name,record in pending.items():
  target=object_path(family_path(extension),name);copy_exact(record['object']['path'],target,record['object']);items += [record['object'],pin(target)]
 return unique(items)

def refuse_other_stage_normal(stage,extension,owner):
 authorize_mode(extension,owner,'normal',_loader)
 cert=read(extension['certificate']['path']);aliases=cert['copy_map']+extension['copy_map'];released=extension['failed_releases'][0]['command']
 roots=extension['normal_search_roots']+[str(ROOT)]
 for root in roots:
  require(Path(root).is_dir(),'Declared normal search root missing')
  for command in Path(root).glob('**/steps/'+owner+'/normal/*/COMMAND.json'):
   if command.is_relative_to(Path(stage)):continue
   original=original_command_reference(pin(command),aliases)
   require(original==released,'Foreign successful/failed/ambiguous command blocks new normal; only exact released tuple aliases permitted')

def real_executor(mode,owner,argv,cwd,env,log,timeout,rss):
 # Reached only after exact authorize_mode; no qualified/accepted mode can reach here.
 return LEGACY.evidence.real_process(argv,cwd,env,log,timeout,rss)

def recover_durable_result(stage,extension,batch,owner,mode,pre,attempt,history,pending):
 attempt=Path(attempt)
 if (attempt/'RESULT.json').exists():return None
 require_durable_outcome(attempt)
 command=read(attempt/'COMMAND.json');expected=identity(stage,extension,batch,owner,mode,pre);require(command['identity']==expected,'Interrupted COMMAND identity changed')
 local_pin=command['local_inputs'];require(local_pin['path']==str(attempt/'LOCAL_INPUTS.json'),'Interrupted D path transplant');check(local_pin);local=read(local_pin['path']);require(local==delta_items(stage,extension,batch,owner,mode,history,pending),'Interrupted exactD differs')
 for item in local:check(item)
 returned_pin=pin(attempt/'PROCESS_RETURN.json');returned=read(returned_pin['path']);log=returned['log'];require(log['path']==str(attempt/'output.log'),'Interrupted log transplant');check(log)
 obj=returned['object']
 if obj:require(mode=='normal' and obj['path']==str(attempt/'normal.olean'),'Interrupted normal object path differs');check(obj)
 namespace_check(stage,extension,pending)
 value=durable_result_payload(command,returned,pin(attempt/'COMMAND.json'),local_pin,log,obj,len(local),time.time_ns());value['process_return']=returned_pin
 if value['exit_code']==0 and value['stop_reason'] is None:
  parsed=parse_mode(stage,extension,batch,owner,mode,Path(log['path']).read_text(),value)
 else:parsed=None
 for item in local:check(item)
 value['mode_validation_error']=None;return dump(attempt/'RESULT.json',value)

def find_record(stage,extension,batch,owner,mode,pre,history=None,pending=None):
 base=Path(stage)/'steps'/owner/mode
 if not base.exists():return None
 attempts=list(base.iterdir());require(len(attempts)<=1,'No repeated attempts permitted')
 if not attempts:return None
 attempt=attempts[0];require(attempt.is_dir() and not attempt.is_symlink(),'Unknown attempt namespace')
 record=verify_record(stage,extension,batch,owner,mode,pre,attempt,history or [],pending or {})
 if record is None:raise ExistingProcessFailure('Existing durable failed/stopped attempt; no retry permission')
 return record

def materialize_contexts(stage,extension,batch,seal,history,pending):
 require(batch['owners']==[OWNER],'Only atomic ShapeArrays B1 context');catalog=dict(extension['parent_catalog']);normal=pending[OWNER]
 catalog[OWNER]={'source':extension['project_sources'][OWNER],'selected_object':pin(object_path(family_path(extension),OWNER)),'normal_success_artifact':normal['object'],'origin':'new_shape_B1_original_successful_modes'}
 path=Path(stage)/'accepted-contexts'/(OWNER+'.json');value={'schema':'shape_b1_accepted1643_context_v1','protocol':PROTOCOL,'family':extension['_anchor'],'batch':batch['_anchor'],'batch_seal':seal,'accepted_parent':batch['parent_context'],'project_closure':catalog,'native_artifacts':extension['native_artifacts'],'runtime':extension['runtime'],'lean_path':extension['lean_path'],'qualified_parent':extension['certificate'],'accepted_new_modules':[OWNER],'original_full_snapshot_verified':False,'formal_acceptance':True,'Cell06_integral_complete':False,'P2_6_complete':False}
 if path.exists():require(read(path)==value,'Existing accepted context differs')
 else:dump(path,value)

def load_contract(stage,family_sha,batch_sha,controller_sha,parent_sha):
 stage=safe_stage(ROOT,stage);family=stage.parent.parent
 require(family==ROOT/'families/main' and stage==family/'batches/shapeArraysB1','Only fixed B1 epoch')
 require(pin(ROOT/'shape_controller.py')['sha256']==controller_sha,'External controller SHA differs')
 fp=pin(family/'FAMILY.json');bp=pin(stage/'BATCH.json');require(fp['sha256']==family_sha and bp['sha256']==batch_sha,'External family/batch SHA differs')
 ext=read(fp['path']);batch=read(bp['path']);ext['_anchor']=fp;batch['_anchor']=bp
 ensure_clean(stage,ext)
 require(ext['protocol']==batch['protocol']==PROTOCOL and ext['family_root']==str(family),'Family/protocol path transplant')
 require(batch['family']==fp and batch['parent_context']==ext['base_context'] and batch['parent_context']['sha256']==parent_sha and batch['owners']==[OWNER] and batch['concurrency']==1,'Wrong exact B1 parent/owner')
 require(ext['scope_owners']==[OWNER] and ext['maximum_batch_size']==1 and ext['rss_gib']==12 and ext['wall_seconds']==2400,'Scope/internal limits changed')
 require(ext['outer_limits']=={'memory_mb':13107,'timeout_seconds':3600,'cpu_threads':1},'Outer resource ruling changed')
 check(ext['all_mode_barriers_manifest']);check(ext['failed_releases_manifest']);require(read(ext['all_mode_barriers_manifest']['path'])==ext['all_mode_barriers'] and read(ext['failed_releases_manifest']['path'])==ext['failed_releases'],'Frozen mode ledgers changed')
 require(read(ext['base_context']['path'])['project_closure']==ext['base_catalog'],'Copied1642 base differs')
 ext['parent_catalog']=ext['base_catalog'];ext['foundation']=ext['base_context'];ext['global_inputs']=batch['global_inputs'];ext['_closed_namespaces']={}
 require(env_hash(env_for(stage,ext))==batch['environment_sha256'],'Final mode environment differs')
 for item in ext['code_pins']+ext['authority_D_anchors']+batch['helpers']:check(item)
 require({i['path'] for i in batch['helpers']}=={str(stage/'helpers'/(OWNER+'.Owned.lean'))},'Full-owned helper selector differs')
 namespace_check(stage,ext,{}) if not (stage/'steps'/OWNER/'normal').exists() else validate_provider(ext)
 return ext,batch

'''
# Preserve exact already-reviewed source algorithms as new functions, with declared adapters.
(ROOT/'shape_engine.py').write_text(header+text)
