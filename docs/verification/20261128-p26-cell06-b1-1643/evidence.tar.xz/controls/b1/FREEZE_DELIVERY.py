#!/usr/bin/env python3
"""Exclusive host-source freeze only. Never call production reader/seed/G/proof."""
import sys
if not sys.flags.isolated or not sys.dont_write_bytecode:raise SystemExit('Use -I -B')
from pathlib import Path
import hashlib,json,re,subprocess,time
ROOT=Path(__file__).resolve().parent

def require(ok,message):
 if not ok:raise RuntimeError(message)
def pin(path):
 p=Path(path).absolute();b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def write(path,value):
 p=Path(path)
 with p.open('x') as f:json.dump(value,f,indent=2,ensure_ascii=False,allow_nan=False);f.write('\n')
 return pin(p)
def check(p):require(pin(p['path'])==p,'Freeze input changed: '+p['path'])
def production_lock():
 r2=ROOT.parent/'p26-cell06-family-revision4-r2-20261128/SOURCE_LOCK.json';require(pin(r2)['sha256']=='ef736daf3aaaeadb8164ca9d5608fcad833cbcfc55c63a5d6a48375ad487f24d','R2 closure authority differs');q=json.loads(r2.read_bytes());modules=dict(q['modules'])
 for p in modules.values():check(p)
 for name in ('shape_source_loader','shape_common','shape_parent','shape_engine'):modules[name]=pin(ROOT/(name+'.py'))
 inputs=[pin(ROOT.parent/'p26-proof-continuation-20261127/tools/p26/cell01-integral'/n) for n in ('OwnedSuppliersAudit.lean','ReplayJoin.lean')]
 runtime=pin(Path(sys.executable).resolve());require(runtime['sha256']=='fa67443527ed9647f760d807e2a38f26340757123e643c4639cf273ed15d5ea7','Wrong host/MCP pinned Python')
 return {'schema':'shape_b1_source_lock_v1','controller':pin(ROOT/'shape_controller.py'),'modules':modules,'inputs':inputs,'python':runtime,'required_flags':['-I','-B'],'formal_acceptance':False,'P2_6_complete':False}
def main():
 require(sys.argv[1:] in (['test-lock'],['freeze']),'test-lock | freeze')
 if sys.argv[1]=='test-lock':
  lock=production_lock();sources=[pin(ROOT/n) for n in ('test_shape_host.py','shape_host_fixture.py','FREEZE_DELIVERY.py')]
  out=write(ROOT/'TEST_SOURCE_LOCK.json',{'schema':'shape_b1_host_source_lock_v1','production_lock':lock,'test_sources':sources,'scope':'Synthetic host control/storage fixtures only; no real authority collection/seed/G/proof','formal_acceptance':False});print(json.dumps(out));return
 tlp=pin(ROOT/'TEST_SOURCE_LOCK.json');tl=json.loads(Path(tlp['path']).read_bytes());require(tl['production_lock']==production_lock(),'Tested production source differs')
 for p in tl['test_sources']:check(p)
 log=ROOT/'FINAL_HOST_GREEN.log';text=log.read_text();m=re.search(r'Ran (\d+) tests in ([0-9.]+)s',text);require(m and text.rstrip().endswith('OK') and 'FAILED (' not in text,'Final host suite not green')
 sp=write(ROOT/'SOURCE_LOCK.json',tl['production_lock']);lock=tl['production_lock'];argv=[lock['python']['path'],'-I','-B',str(ROOT/'shape_controller.py'),'check-bootstrap','--controller-sha256',lock['controller']['sha256'],'--source-lock-file',sp['path'],'--source-lock-sha256',sp['sha256']]
 start=time.monotonic();p=subprocess.run(argv,cwd=ROOT,env={'PATH':str(Path(lock['python']['path']).parent)+':/usr/bin:/bin','LANG':'C.UTF-8','LC_ALL':'C.UTF-8','TZ':'UTC'},capture_output=True,text=True);require(p.returncode==0,'Source-only bootstrap failed: '+p.stderr)
 value=json.loads(p.stdout);require(value['status']=='SOURCE_BOOTSTRAP_ONLY' and value['source_lock']==sp and value['executor_calls']==value['G_runs']==value['seed_runs']==value['Lean_commands']==0 and value['formal_acceptance'] is False,'Wrong bootstrap scope')
 bp=write(ROOT/'BOOTSTRAP_READBACK.json',{'argv':argv,'runtime':lock['python'],'exit_code':p.returncode,'stdout':value,'stderr':p.stderr,'seconds':time.monotonic()-start,'production_operations':0})
 report=write(ROOT/'HOST_REPORT.json',{'schema':'shape_b1_host_candidate_report_v1','tests':int(m.group(1)),'failures':0,'errors':0,'seconds':float(m.group(2)),'suite_log':pin(log),'test_source_lock':tlp,'source_lock':sp,'bootstrap':bp,'RED_logs':[pin(p) for p in sorted(ROOT.glob('*RED*.log'))],'task_reports':[pin(ROOT/n) for n in ('TASK1_REPORT.json','TASK23_REPORT.json','REVIEW_ROUND1_F123_CANDIDATE.json')],'source_snapshots':'task-evidence/ preserves exact historical bytes; old report logical pins are superseded aliases, not current source claims','known_deferred_minor':{'id':'M1','description':'strict_json rejects named NaN/Infinity but overflow numeric literals can become infinity; no observed real input; root explicitly deferred'},'fixtures':'Synthetic fake parent/proof bytes with internal counting executor/readonly boundaries; no Lean credit','production_collect_parent_calls':0,'production_seed_calls':0,'production_G_runs':0,'Lean_commands':0,'MCP_jobs':0,'formal_acceptance':False,'Cell06_integral_complete':False,'P2_6_complete':False})
 require(not (ROOT/'families').exists() and not (ROOT/'certificates').exists() and not (ROOT/'EXECUTION.lock').exists(),'Production state in source delivery')
 members=[]
 for path in sorted(ROOT.rglob('*')):
  require(not path.is_symlink(),'Unexpected source-delivery symlink')
  if path.is_file():require(path.suffix!='.pyc','Unpinned bytecode forbidden');members.append(pin(path))
 dp=write(ROOT/'DELIVERY.json',{'schema':'shape_b1_source_candidate_delivery_v1','controller':lock['controller'],'source_lock':sp,'test_source_lock':tlp,'host_report':report,'members':members,'review_status':'Await independent final code review; known M1 Minor deferred','production_scope':'Only exact ShapeArrays B1/count1 from qualified1642; no successor','outer_limits':{'memory_mb':13107,'timeout_seconds':3600,'cpu_threads':1},'inner_mode_limits':{'rss_gib':12,'wall_seconds':2400,'threads':1},'formal_acceptance':False,'Cell06_integral_complete':False,'P2_6_complete':False})
 for row in members:check(row)
 print(json.dumps({'DELIVERY':dp,'SELF':lock['controller'],'SOURCE_LOCK':sp,'TEST_SOURCE_LOCK':tlp,'HOST_REPORT':report,'BOOTSTRAP':bp},indent=2))
if __name__=='__main__':main()
