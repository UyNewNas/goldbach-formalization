# SDD ledger — plan: /workspace/p26-cell06-v4-shape-b1-plan-20261128/PLAN.md

Plan SHA256:4f23c1867ea7ee1a11ce92c35d34545692498c10d1ebcf34c8d9115214a2613d.

Ruling: Use the explicitly assigned independent new directory as the isolated workspace; no Git checkout/commit or skill workspace deletion — all frozen providers remain readonly and evidence must persist — wrong implementation must not affect the old tree.
Ruling: Outer MCP ceiling13107MiB/3600s/1CPU supersedes plan16384MiB/9000s; internal Lean12GiB/2400s and one thread unchanged — actual provider limit is binding — fail before a mode without sufficient remaining outer budget, preserve interruptions and never repeat modes.
Ruling: No production INPUT_CONTRACT authority is created while real reviewed1642 outputs are absent. Disabled template has no zero/dummy pins and all production commands reject it — numeric1642 is not authority.
Ruling: Root assigns independent final review; no child agents are spawned here. No production collect-parent/seed/freeze/G/run/Lean during implementation.

Pre-flight interfaces:
- Task1 ->Task2: certificate supplies exact original qualified context/seal/copy/inputs/G union/barriers/release; seed may not parse it as a v3 batch context.
- Task2 ->Task3: independent1642 base catalog + fixed old-and-new physical baseline + explicit authority-D anchors, all-mode registry and exact ShapeArrays release; runtime keeps original tail and native555.
- Task3 ->Task4: only ShapeArrays count1; durable RETURN recovery must label the recovery-time D postcheck honestly; no subsequent epoch enabled.
- Task1/3 source-only loader must include actual pure parsers/templates/real_process under external SELF/LOCK; no PYC/local import fallback.

Task1: in progress. Actual parent1642 authority not yet supplied; only static frozen R2 ABI read. Production validation remains blocked.

Task1: host complete candidate — RED8 +chainRED4 +bootstrapRED3 -> GREEN15; TASK1_REPORT.json pins exact source/test/logs. Actual qualified1642 pin metadata now exists; actual independent review still pending. No collect-parent/seed/G/Lean executed.
Ruling: qualification_review JSON uses exact context/qualification Pins and findings critical/important/minor zero; this review attestation supplements, never substitutes, full context/seal/output/copy-byte validation.
Ruling: transported original failed COMMAND physical copies are provenance aliases only when explicitly chained through sealed copy maps; cross-root discovery must resolve those maps without rewriting nested original identity, and reject any unregistered lookalike.
Task2: in progress — independent seed/full fixed G, host tests only.

Task2: host complete candidate — RED4+layoutRED2 -> validated in suite21; original G expected digest is carried explicitly by certificate; copied BASE/FAMILY remains formalfalse. Cold baseline readback precedes FAMILY and FAMILY binds its pin, avoiding a cycle.
Task3: host complete candidate — RED7+capabilityRED2+serial RED -> GREEN38; exact all-mode gates, one-shot failed/unknown blocking, durable RETURN→RESULT truthful recovery, PENDING/canonical/seal-context recovery and budget defer/resume tested with counting synthetic executor. Source snapshots and logs in TASK23_REPORT.json.
Ruling: unit storage/engine fixtures inject pure provider/release boundaries to avoid production inspection. No CLI fixture switch is exposed; production configure always uses the locked real reader/validator.
Ruling: need2400s+300s remaining at each mode before COMMAND; defer is not failure/retry permission; same BATCH can continue missing modes in a new3600s job with zero repeated completed calls.
Task4: in progress — B1-only seed/freeze/run CLI, source delivery and independent review package.

Task4 scopeRED2 -> GREEN2; independent freeze/CLI integration GREEN3. Current43 distinct synthetic cases have passed their targeted runs. Final whole-suite and final locks/delivery intentionally held pending parallel Task1/2 review F1/F2/F3. No production adapter, copy, G or Lean operation performed.
Task4 seed FAMILY field alignment: original common19307/e25a retained task-evidence/task3; interim19331/93ef retained task-evidence/task4-pre-review, only +24bytes scope_owners:[TARGET]. The earlier candidate review refers to its original bytes.

Review round1 formally dispatched for Task1/2 F1/F2/F3 (review16951/3e8a6e...). New8 tests: actual RED7fail/1positive then targeted GREEN8; originals/snapshots and unified diffs preserved. F1 binds every8 final-R2 helper alias before the parent delegated calls, including direct failed-release entry. F2 seed now closes actual full physical file/directory namespace before cold readback and again around final return, plus actual new copy/metadata recheck. F3 denies relative writes and exposed nondefault dir_fd mutations; synthetic outside-FD file/directory fixtures remain unchanged. Task4 own EXECUTION.lock symlink regression separately RED1/GREEN1 and fixed via canonical safe_stage + O_NOFOLLOW.
M1 strict_json overflow literal nonfinite policy remains a known deferred Minor under root ruling; no real input evidence of that value, and this delivery must not claim0Minor.
Full engine/CLI review ongoing. E1 recorded mode_validation_error persistence and the F1 configure-before-legacy-load edge await the unified dispatch; engine unchanged35489/6b9685. Final whole-suite and SOURCE_LOCK/DELIVERY remain held. No production collection/seed/G/Lean was executed; synthetic seed-path injections use a fixture parent adapter and tiny local fake artifacts only.

Unified round1 engine/CLI dispatch: E1/E2/E3 + configure closure. New10 regression cases: original RED9fail/1fixture duplicate-injection error preserved; corrected fixture RED10fail; minimal implementation GREEN10 then final namespace-sticky closure GREEN10. E1 nonnull/empty/missing error field blocks promotion. E2 existing PRE+empty history gets full real RESUME before any executor, original PRE unchanged; all-modes-complete uses genuine POST without executing modes. E3 validates actual full epoch files/directories/known partial sidefiles and rejects directory links/unknown empty dirs before modes, after executor return and final closure. Required epoch dirs are checked before traversing them. Recorded process validation failure never rewrites RESULT or creates success marker. All8 R2 helper pins are now bound before configure first helper load.
Task3 COMMAND-only fixture spelling changed from arbitrary unknown directory to actual attempt grammar1-deadbeef and existing LOCAL_INPUTS, so the same unknown-outcome test reaches durable-outcome classification under the new complete namespace guard; original test source is preserved in task-evidence/task3. Known M1 remains deferred Minor unchanged. Task4 new lock symlink case is separate RED/GREEN1. Full intended suite62 synthetic cases follows once after final test-source-lock. No real parent collect, seed, G, Lean/stock/owned mode or MCP job executed here.

Final unified host suite:62 cases /0failures/0errors,22.220s, once against TEST_SOURCE_LOCK b961ab0e30de816de75592f02a2843431ec481f1bd078ef02ff1067e05e7e3bf. Next is source-only bootstrap/freeze, then independent final diff/pin review. All production operations remain0. M1 remains deferred Minor.
