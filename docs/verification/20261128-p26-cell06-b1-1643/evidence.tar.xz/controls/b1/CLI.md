# Exact B1 CLI ABI — candidate, do not execute without final source review

Use the pinned resolved Python3.12 binary with `-I -B`. Root additionally verifies the controller and source-lock bytes externally in a minimal stdlib bootstrap before compiling the checked controller as `__main__`. Every command requires:

```
--controller-sha256 SELF_SHA
--source-lock-file /workspace/p26-cell06-shapearrays-b1-controller-20261128/SOURCE_LOCK.json
--source-lock-sha256 LOCK_SHA
```

Every command except `check-bootstrap` also requires `--delivery-sha256 DELIVERY_SHA`. All option sets are exact: missing, duplicate, unknown and fixture flags fail. SELF/LOCK/DELIVERY are actual hashes in the final delivery; generated certificate/FAMILY/BATCH pins are obtained only from actual successful prior commands and remain external anchors.

| Command | Additional flags, all mandatory |
|---|---|
| check-bootstrap | none; verifies code only, no output stage or EXECUTION.lock |
| collect-parent | `--input-contract PATH --input-contract-sha256 SHA --graph PATH --graph-sha256 SHA --shape-source PATH --shape-source-sha256 SHA --output PATH` |
| seed | `--certificate PATH --certificate-sha256 SHA --family PATH --rss-gib 12 --wall-seconds 2400` |
| freeze | `--family PATH --family-sha256 SHA --parent-context PATH --parent-sha256 SHA --epoch shapeArraysB1 --count 1` |
| run | `--epoch-directory PATH --family-sha256 SHA --batch-sha256 SHA --parent-sha256 SHA` |

`collect-parent --output` must name a new file directly in this root's `certificates/`. The separate real input contract is `/workspace/p26-cell06-shape-b1-root-execution-20261128/INPUT_CONTRACT_001.json`, SHAeb53c0e88da8c88337a32654c5c1a7ba086430c5ccb689b0aea46ec6fb1b8336. Its exact12-key schema is in `shape_parent.FIELDS`; all10 pin fields must be real and verified. No generated production template or fixture authority is provided.

`--family` is exactly this root's `families/main`. Freeze parent is the actual cold-seed `BASE_CONTEXT.json`, externally pinned using the seed output bytes. The only epoch directory is `families/main/batches/shapeArraysB1`. A repeated freeze or successor count/name is rejected. Run may resume this same immutable BATCH only; a durable failed/stopped or unknown command is blocked, not retried.

Seed and freeze use separate MCP jobs. Run uses MCP memory13107MiB, timeout3600s, CPU1; internal each Lean/stock/audit mode12GiB, timeout2400s. A new mode starts only with2400s plus300s reserve after a30s bootstrap margin; otherwise it emits UNSTARTED_MODE_DEFERRED and creates no COMMAND for that mode. Run the same exact BATCH in a later job to continue missing modes; all completed modes remain original evidence. A returned process without RESULT recovers only its exact durable record and current D, with explicit recovery-time postcheck attribution.

No command sequence in this document has been executed against real authority. Actual collect-parent, cold G, freeze and B1 execution are root operations after independent code review. B1 acceptance alone leaves Cell06 integral and P2.6 incomplete.
