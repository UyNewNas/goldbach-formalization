"""New synthetic host cases only; never inspect real qualified stage or run Lean."""
import unittest,tempfile,types,hashlib,json,sys,subprocess,os,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def pin(p):p=Path(p).absolute();b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def mod(n):
 p=ROOT/(n+'.py')
 if not p.exists():raise AssertionError('Task feature missing: '+n)
 m=types.ModuleType(n);m.__file__=str(p);exec(compile(p.read_bytes(),str(p),'exec',dont_inherit=True),m.__dict__);return m

def loaded(n):
 if not (ROOT/(n+'.py')).exists():raise AssertionError('Task feature missing: '+n)
 loader=mod('shape_source_loader');paths={p.stem:pin(p) for p in ROOT.glob('shape_*.py') if p.name!='shape_controller.py'}
 base=Path('/workspace/p26-cell06-family-revision4-r2-20261128')
 paths.update({name:pin(base/(name+'.py')) for name in ['revision4_core','revision4_collect','revision4_transport']})
 old=Path('/workspace/p26-cell06-source-candidate-20261128/runner');paths.update({name:pin(old/(name+'.py')) for name in ['evidence','templates','controller']})
 paths['checkpoint']=pin('/workspace/p26-cell06-checkpoint-revision3-20261128/checkpoint.py')
 l=loader.SourceLoader(paths);return l.load(n),l

class Temp(unittest.TestCase):
 def setUp(self):self.tmp=tempfile.TemporaryDirectory(dir=ROOT);self.root=Path(self.tmp.name)
 def tearDown(self):self.tmp.cleanup()
 def file(self,n,b):p=self.root/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return p
 def js(self,n,d):return pin(self.file(n,(json.dumps(d,indent=2)+'\n').encode()))

class Task1Tests(Temp):
 def test_disabled_or_numeric_authority_rejected(self):
  p,l=loaded('shape_parent')
  for d in [{'status':'AWAITING_REAL_1642_AUTHORITY'},{'accepted_project_union':1642},{}]:
   with self.assertRaises(RuntimeError):p.validate_authority_contract(d)
 def test_all_external_authority_pins_required(self):
  p,l=loaded('shape_parent');d=p.authority_contract_skeleton()
  self.assertNotIn('context',d)
  with self.assertRaises(RuntimeError):p.validate_authority_contract(d)
 def test_source_loader_rejects_unlocked_exec(self):
  loader=mod('shape_source_loader');x=self.file('x.py',b'exec("bad=1", {})\n')
  with self.assertRaises(RuntimeError):loader.SourceLoader({'x':pin(x)}).load('x')
 def test_source_loader_ignores_cached_module(self):
  loader=mod('shape_source_loader');x=self.file('x.py',b'value=7\n');sys.modules['shape_fixture']=types.SimpleNamespace(value=999)
  try:self.assertEqual(loader.SourceLoader({'shape_fixture':pin(x)}).load('shape_fixture').value,7)
  finally:sys.modules.pop('shape_fixture',None)
 def test_qualified_tree_rejects_unknown_empty_directory(self):
  p,l=loaded('shape_parent');stage=self.root/'qualified';stage.mkdir();(stage/'home').mkdir();(stage/'tmp').mkdir();f=stage/'data';f.write_bytes(b'x')
  p.exact_stage_namespace(stage,[pin(f)])
  (stage/'foreign').mkdir()
  with self.assertRaises(RuntimeError):p.exact_stage_namespace(stage,[pin(f)])
 def test_qualified_tree_rejects_directory_symlink(self):
  p,l=loaded('shape_parent');stage=self.root/'qualified';stage.mkdir();(stage/'home').mkdir();(stage/'tmp').mkdir();f=stage/'data';f.write_bytes(b'x');outside=self.root/'outside';outside.mkdir();(stage/'foreign').symlink_to(outside,target_is_directory=True)
  with self.assertRaises(RuntimeError):p.exact_stage_namespace(stage,[pin(f)])
 def test_copy_map_wrong_physical_or_hardlink_rejected(self):
  p,l=loaded('shape_parent');a=self.file('logical',b'a');b=self.file('physical',b'a');row={'logical':pin(a),'physical':pin(b),'original_identity_preserved':True,'independent_inode':True,'role':'fixture'}
  p.validate_copy_map([row]);b.write_bytes(b'b')
  with self.assertRaises(RuntimeError):p.validate_copy_map([row])
 def test_all_members_forbid_all_modes_without_invented_normal(self):
  p,l=loaded('shape_parent');rows=[{'module':'ImbalancedChen.A','status':'accepted_membership_forbidden','forbidden_modes':p.MODES,'old_data_forbidden':True},{'module':'ImbalancedChen.P','status':'original_pending_three_modes_forbidden','forbidden_modes':p.MODES,'original_mode_records':[{'mode':m,'protocol':'original'} for m in p.MODES]}]
  p.validate_barriers(rows,{'ImbalancedChen.A':{},'ImbalancedChen.P':{}},'ImbalancedChen.P',1)
  rows[-1]['forbidden_modes']=['normal']
  with self.assertRaises(RuntimeError):p.validate_barriers(rows,{'ImbalancedChen.A':{},'ImbalancedChen.P':{}},'ImbalancedChen.P',1)

class Task1ChainTests(Temp):
 def identity(self):
  p,l=loaded('shape_parent');self.assertTrue(hasattr(p,'validate_qualified_identity'),'Missing qualified identity interface')
  c=self.js('contract',{});lock=self.js('lock',{});base=self.js('parent',{});sealpin=self.js('seal',{});out=self.js('outputs',{})
  common={'schema':'p26_revision4_transported1642_context_v1','protocol':p.QPROTOCOL,'contract':c,'source_lock':lock,'accepted_parent':base,'qualification_environment_sha256':'fixture-env','formal_acceptance':True,'P2_6_complete':False,'executor_calls':0,'Lean_commands':0,'proof_modes_repeated':0}
  ctx={**common,'qualification':sealpin,'project_closure':{'A':{},'B':{},p.PENDING:{}},'native_artifacts':[]}
  seal={**common,'schema':'p26_revision4_verified_pending_prefix_v1','outputs_post':out,'transported_count':3,'accepted_parent_count':2}
  auth={'qualification_seal':sealpin,'qualification_outputs_post':out,'qualification_contract':c,'qualifier_source_lock':lock}
  return p,ctx,seal,auth
 def test_context_transplant_rejected(self):
  p,c,s,a=self.identity();p.validate_qualified_identity(c,s,a,3,0);c['qualification']=self.js('foreign',{})
  with self.assertRaises(RuntimeError):p.validate_qualified_identity(c,s,a,3,0)
 def test_outputs_post_transplant_rejected(self):
  p,c,s,a=self.identity();s['outputs_post']=self.js('foreign',{})
  with self.assertRaises(RuntimeError):p.validate_qualified_identity(c,s,a,3,0)
 def test_numeric_count_cannot_hide_missing_member(self):
  p,c,s,a=self.identity();c['project_closure'].pop('A')
  with self.assertRaises(RuntimeError):p.validate_qualified_identity(c,s,a,3,0)
 def test_output_manifest_and_copy_map_relationship(self):
  p,l=loaded('shape_parent');self.assertTrue(hasattr(p,'validate_output_closure'),'Missing output closure interface')
  refs=[self.js('m'+str(i),{}) for i in range(9)];a=pin(self.file('logical',b'x'));b=pin(self.file('copy',b'x'));copies=[{'logical':a,'physical':b}];out={'metadata_pins':refs,'physical_copies':[b],'all_actual_bytes_matched':True}
  p.validate_output_closure(out,refs,copies);out['metadata_pins']=refs[:-1]
  with self.assertRaises(RuntimeError):p.validate_output_closure(out,refs,copies)

class BootstrapTests(Temp):
 def setup_bootstrap(self):
  cli=ROOT/'shape_controller.py';self.assertTrue(cli.exists(),'Task feature missing: shape_controller bootstrap')
  tool=self.root/'tool';tool.mkdir()
  for src in ROOT.glob('shape_*.py'):shutil.copyfile(src,tool/src.name)
  names={p.stem:pin(p) for p in tool.glob('shape_*.py') if p.name!='shape_controller.py'}
  r2=Path('/workspace/p26-cell06-family-revision4-r2-20261128');names.update({n:pin(r2/(n+'.py')) for n in ['revision4_core','revision4_collect','revision4_transport']})
  old=Path('/workspace/p26-cell06-source-candidate-20261128/runner');names.update({n:pin(old/(n+'.py')) for n in ['evidence','templates','controller']});names['checkpoint']=pin('/workspace/p26-cell06-checkpoint-revision3-20261128/checkpoint.py')
  cli=tool/'shape_controller.py';lock={'schema':'shape_b1_source_lock_v1','controller':pin(cli),'modules':names,'python':pin(Path(sys.executable).resolve())};lp=tool/'SOURCE_LOCK.json';lp.write_text(json.dumps(lock));return tool,cli,lp,lock
 def call(self,cli,lp,lock,badself=False,badlock=False):
  return subprocess.run([sys.executable,'-I','-B',str(cli),'check-bootstrap','--controller-sha256','0'*64 if badself else lock['controller']['sha256'],'--source-lock-file',str(lp),'--source-lock-sha256','0'*64 if badlock else pin(lp)['sha256']],cwd=self.root,env={'PATH':str(Path(sys.executable).resolve().parent)+':/usr/bin:/bin','LANG':'C.UTF-8','LC_ALL':'C.UTF-8','TZ':'UTC'},text=True,capture_output=True)
 def test_bootstrap_actual_entry_and_locked_modules(self):
  tool,cli,lp,l=self.setup_bootstrap();p=self.call(cli,lp,l);self.assertEqual(p.returncode,0,p.stderr);self.assertIn('SOURCE_BOOTSTRAP_ONLY',p.stdout);self.assertFalse((tool/'families').exists())
 def test_bad_external_hashes_precede_localcode(self):
  tool,cli,lp,l=self.setup_bootstrap()
  for a,b in [(True,False),(False,True)]:
   p=self.call(cli,lp,l,a,b);self.assertNotEqual(p.returncode,0);self.assertFalse((tool/'families').exists())
 def test_cwd_and_pycache_cannot_shadow_source(self):
  import py_compile,importlib.util
  tool,cli,lp,l=self.setup_bootstrap();self.file('shape_common.py',b'raise RuntimeError("CWD_POISON")\n');target=tool/'shape_common.py';stat=target.stat();poison=self.file('poison.py',b'raise RuntimeError("PYC_POISON")\n');poison.write_bytes(poison.read_bytes().ljust(stat.st_size,b' '));os.utime(poison,ns=(stat.st_atime_ns,stat.st_mtime_ns));cache=Path(importlib.util.cache_from_source(str(target)));cache.parent.mkdir();py_compile.compile(str(poison),cfile=str(cache),dfile=str(target),doraise=True)
  p=self.call(cli,lp,l);self.assertEqual(p.returncode,0,p.stderr)

if __name__=='__main__':unittest.main(verbosity=2)
