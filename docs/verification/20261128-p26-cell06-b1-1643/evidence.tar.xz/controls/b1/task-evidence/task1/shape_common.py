"""Bounded immutable IO and zero-process/write confinement; no proof executor."""
import hashlib, json, math, os, re, sys
from pathlib import Path

class IntegrityError(RuntimeError):pass

def require(ok,message):
    if not ok:raise IntegrityError(message)

def valid_pin(row):
    require(isinstance(row,dict) and set(row)=={'path','bytes','sha256'} and isinstance(row['path'],str) and Path(row['path']).is_absolute() and type(row['bytes']) is int and row['bytes']>=0 and isinstance(row['sha256'],str) and re.fullmatch('[0-9a-f]{64}',row['sha256']) is not None,'Malformed exact pin')
    return row

def raw_pin(path,raw):return {'path':str(Path(path).absolute()),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}

def pin(path):
    path=Path(path).absolute();h=hashlib.sha256();size=0
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b);size+=len(b)
    return {'path':str(path),'bytes':size,'sha256':h.hexdigest()}

def external(path,sha):
    p=pin(path);require(p['sha256']==sha,'External SHA mismatch: '+str(path));return p

def strict_json(raw):
    def pairs(rows):
        result={}
        for k,v in rows:require(k not in result,'Duplicate JSON key');result[k]=v
        return result
    def bad(v):raise IntegrityError('Nonfinite JSON: '+v)
    return json.loads(raw,object_pairs_hook=pairs,parse_constant=bad)

class Reader:
    def __init__(self):self.expected={};self.seen=set();self.actual_checks=0
    def expect(self,item):
        valid_pin(item);require(self.expected.setdefault(item['path'],item)==item,'Conflicting expected pin');return item
    def check(self,item,fresh=False):
        self.expect(item)
        if fresh or item['path'] not in self.seen:
            require(pin(item['path'])==item,'Pinned bytes mismatch: '+item['path']);self.seen.add(item['path']);self.actual_checks+=1
        return item
    def raw(self,item):
        self.expect(item);raw=Path(item['path']).read_bytes();require(raw_pin(item['path'],raw)==item,'Pinned metadata mismatch: '+item['path']);self.seen.add(item['path']);self.actual_checks+=1;return raw
    def read(self,item):return strict_json(self.raw(item))
    def post(self):
        for item in list(self.expected.values()):self.check(item,fresh=True)
        return {'files':len(self.expected),'all_actual_bytes_matched':True}

def unique(rows):
    by={}
    for row in rows:valid_pin(row);require(by.setdefault(row['path'],row)==row,'Conflicting pin union')
    return [by[k] for k in sorted(by)]

def digest(rows):
    h=hashlib.sha256()
    for row in unique(rows):h.update(json.dumps(row,sort_keys=True,separators=(',',':')).encode()+b'\n')
    return h.hexdigest()

def same_bytes(a,b):return all(a[k]==b[k] for k in ('bytes','sha256'))

def dump(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x') as f:json.dump(value,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
    return pin(path)

def safe_stage(root,path):
    root=Path(root);path=Path(path);require('..' not in root.parts and '..' not in path.parts,'Dotdot output path forbidden')
    root=root.absolute();path=path.absolute();require(root==root.resolve() and path!=root and path.resolve().is_relative_to(root),'Output outside canonical new root')
    for p in (path,*path.parents):
        require(not p.is_symlink(),'Output symlink')
        if p==root:break
    return path

def process_schema(value):
    fields={'exit_code','stop_reason','seconds','sampled_peak_tree_rss_bytes'}
    require(fields<=set(value) and type(value['exit_code']) is int and value['stop_reason'] is None,'Malformed/stopped process')
    require(type(value['seconds']) in (int,float) and math.isfinite(value['seconds']) and value['seconds']>=0 and type(value['sampled_peak_tree_rss_bytes']) is int and value['sampled_peak_tree_rss_bytes']>=0,'Malformed process metrics')
    return {k:value[k] for k in fields}

_PROCESS_GUARDS=[]
_WRITE_GUARDS=[]
def _audit(event,args):
    if event.startswith(('subprocess.','os.exec','os.spawn','os.posix_spawn')) or event in ('os.system','os.fork','os.forkpty'):
        active=[guard for guard in _PROCESS_GUARDS if guard.active]
        for guard in active:guard.attempts+=1
        if active:raise IntegrityError('Process execution forbidden: '+event)
    for guard in _WRITE_GUARDS:
        if not guard.active:continue
        paths=[]
        if event=='open':
            path,mode,flags=args
            writing=(isinstance(mode,str) and any(v in mode for v in ('w','a','x','+'))) or (isinstance(flags,int) and bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND)))
            if writing:paths=[path]
        elif event in ('os.mkdir','os.remove','os.rmdir','os.utime','os.chmod','os.truncate'):paths=[args[0]]
        elif event in ('os.rename','os.link','os.symlink'):paths=list(args[:2])
        for p in paths:
            require(isinstance(p,(str,bytes,os.PathLike)),'FD/relative write not allowed')
            q=Path(os.fsdecode(p));require('..' not in q.parts,'Dotdot write path forbidden');q=q.absolute();require(q.resolve()==guard.root or q.resolve().is_relative_to(guard.root),'Write outside exclusive new stage: '+str(q))
            for parent in (q,*q.parents):
                require(not parent.is_symlink(),'Symlink in writable path')
                if parent==guard.root:break
sys.addaudithook(_audit)

class ProcessGuard:
    def __init__(self):self.active=False;self.attempts=0;_PROCESS_GUARDS.append(self)
    def __enter__(self):self.active=True;return self
    def __exit__(self,*exc):self.active=False

class WriteGuard:
    def __init__(self,root):
        root=Path(root);require('..' not in root.parts,'Dotdot write root forbidden');self.root=root.absolute();require(self.root==self.root.resolve(),'Noncanonical write root');self.active=False;_WRITE_GUARDS.append(self)
    def __enter__(self):self.active=True;return self
    def __exit__(self,*exc):self.active=False
