#!/usr/bin/env python3
"""Source-only exact ShapeArrays B1 controller. No implicit authority or successor."""
import sys
if not sys.flags.isolated or not sys.dont_write_bytecode:raise SystemExit('Use isolated python -I -B')
import hashlib,json,os,types
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def fail(message):raise SystemExit(message)
def pairs(rows):
 d={}
 for k,v in rows:
  if k in d:fail('Duplicate JSON key')
  d[k]=v
 return d

def decode(raw):return json.loads(raw,object_pairs_hook=pairs,parse_constant=lambda x:fail('Nonfinite JSON'))
def rawpin(path,raw):return {'path':str(Path(path).absolute()),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def source(item):
 raw=Path(item['path']).read_bytes()
 if rawpin(item['path'],raw)!=item:fail('Source/runtime pin mismatch')
 return raw

def main():
 if sys.argv[1:]==['--help']:print('check-bootstrap | collect-parent | seed | freeze | run; explicit external SELF/LOCK and real authority required');return
 args=sys.argv[1:]
 if not args:fail('Explicit command required')
 command=args.pop(0);options={}
 if command not in ('check-bootstrap','collect-parent','seed','freeze','run') or len(args)%2:fail('Invalid command/flag pairs')
 for k,v in zip(args[::2],args[1::2]):
  if not k.startswith('--') or k in options:fail('Duplicate/invalid option')
  options[k]=v
 for k in ('--controller-sha256','--source-lock-file','--source-lock-sha256'):
  if k not in options:fail('Missing external '+k)
 ownraw=Path(__file__).read_bytes();own=rawpin(__file__,ownraw)
 if own['sha256']!=options['--controller-sha256']:fail('External SELF SHA mismatch')
 lp=Path(options['--source-lock-file']).absolute();lr=lp.read_bytes();lockpin=rawpin(lp,lr)
 if lockpin['sha256']!=options['--source-lock-sha256']:fail('External LOCK SHA mismatch')
 lock=decode(lr)
 if lock['schema']!='shape_b1_source_lock_v1' or lock['controller']!=own:fail('Wrong source-only lock/controller')
 for item in lock['modules'].values():source(item)
 if lock['python']['path']!=str(Path(sys.executable).resolve()):fail('Wrong isolated Python runtime')
 source(lock['python'])
 item=lock['modules']['shape_source_loader'];m=types.ModuleType('shape_bootstrap_loader');m.__file__=item['path'];m.__cached__=None
 exec(compile(source(item),item['path'],'exec',dont_inherit=True),m.__dict__);loader=m.SourceLoader(lock['modules']);common=loader.load('shape_common')
 if command=='check-bootstrap':
  with common.ProcessGuard() as guard,common.WriteGuard(ROOT/'.no-bootstrap-writes'):
   loader.load('shape_parent')
  print(json.dumps({'status':'SOURCE_BOOTSTRAP_ONLY','source_lock':lockpin,'executor_calls':guard.attempts,'G_runs':0,'seed_runs':0,'Lean_commands':0,'formal_acceptance':False}));return
 if command=='collect-parent':
  needed=['--input-contract','--input-contract-sha256','--graph','--graph-sha256','--shape-source','--shape-source-sha256','--output']
  for k in needed:
   if k not in options:fail('Missing explicit '+k)
  with common.ProcessGuard(),common.WriteGuard(common.safe_stage(ROOT,options['--output'])):
   parent=loader.load('shape_parent');ip=common.external(options['--input-contract'],options['--input-contract-sha256']);authority=parent.validate_authority_contract(common.strict_json(Path(ip['path']).read_bytes()))
   if common.external(options['--graph'],options['--graph-sha256'])!=authority['graph'] or common.external(options['--shape-source'],options['--shape-source-sha256'])!=authority['shape_source']:fail('Explicit graph/source differs from authority contract')
   output=common.safe_stage(ROOT,options['--output']);common.require(not output.exists(),'Exclusive certificate required');certificate=parent.collect_qualified_prefix(ip,loader);certificate['controller_source_lock']=lockpin;certificate['controller_delivery']=common.external(ROOT/'DELIVERY.json',options['--delivery-sha256']);result=common.dump(output,certificate)
  print(json.dumps({'certificate':result,'formal_acceptance':False,'Lean_commands':0}));return
 fail('Task not yet implemented; no production operation executed')

if __name__=='__main__':main()
