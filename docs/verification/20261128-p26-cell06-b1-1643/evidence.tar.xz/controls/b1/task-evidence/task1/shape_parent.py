"""Readonly exact qualified1642 ABI; never creates/resumes qualification."""
from pathlib import Path
import json
from shape_common import *

OWNER='ImbalancedChen.P2OriginalSaving19Geometry06ScalableShapeArrays'
PENDING='ImbalancedChen.P2OriginalSaving19Geometry06ScalableRowsNode000To014'
MODES=['normal','stock-leanchecker','full-owned']
PROTOCOL='source_revision4_shape_family_batch_global_boundary_v1'
QPROTOCOL='source_revision4_transport_verified_pending_prefix_v1'
GRAPH_SHA='ecd1c7e2156e69acd099b7e08f9b47f448c8ac2bf75d7f531a3cb7785e99895b'
SOURCE_SHA='c5bd66975121ec9c7cf89337f35e2c1ad855c43537e354979efccf05c001a8b4'
R2_LOCK_SHA='ef736daf3aaaeadb8164ca9d5608fcad833cbcfc55c63a5d6a48375ad487f24d'
R2_DELIVERY_SHA='7abdcc3fdd71f11d7e33372a8bf2bdbde78773b99e51d05e8b692247749ab887'
FIELDS={'schema','status','qualification_context','qualification_seal','qualification_outputs_post','qualification_contract','qualifier_source_lock','qualifier_delivery','qualification_review','graph','shape_source','revision_report'}

def authority_contract_skeleton():
    return {'schema':'shape_b1_authority_contract_v1','status':'AWAITING_REAL_1642_AUTHORITY','required_fields':sorted(FIELDS-{'schema','status'}),'known_graph_sha256':GRAPH_SHA,'known_shape_source_sha256':SOURCE_SHA,'formal_acceptance':False}

def validate_authority_contract(value):
    require(isinstance(value,dict) and set(value)==FIELDS and value['schema']=='shape_b1_authority_contract_v1' and value['status']=='REAL_REVIEWED_1642_AUTHORITY','Actual reviewed qualification authority required; template/numeric1642 rejected')
    for key in FIELDS-{'schema','status'}:valid_pin(value[key]);require(value[key]['sha256']!='0'*64,'Placeholder authority hash rejected')
    for key,sha in [('graph',GRAPH_SHA),('shape_source',SOURCE_SHA),('qualifier_source_lock',R2_LOCK_SHA),('qualifier_delivery',R2_DELIVERY_SHA)]:require(value[key]['sha256']==sha,'Fixed authority/policy SHA differs: '+key)
    return value

def exact_stage_namespace(stage,items):
    stage=Path(stage).absolute();expected={p['path'] for p in unique(items)}
    require(all(Path(p).is_relative_to(stage) for p in expected),'Qualified artifact path transplant')
    for parent in (stage,*stage.parents):require(not parent.is_symlink(),'Qualified stage ancestor symlink')
    actual={str(p) for p in stage.rglob('*') if p.is_file() or p.is_symlink()};require(actual==expected,'Unknown/missing qualified artifact')
    dirs={stage/'home',stage/'tmp'}
    for path in map(Path,expected):
        for p in path.parents:
            if p==stage:break
            dirs.add(p)
    require({p for p in stage.rglob('*') if p.is_dir()}==dirs,'Unknown/missing qualified empty directory')
    require(all(not p.is_symlink() for p in stage.rglob('*')),'Qualified symlink forbidden')

def validate_copy_map(rows):
    physical=set()
    for row in rows:
        a,b=row['logical'],row['physical'];valid_pin(a);valid_pin(b)
        require(row['original_identity_preserved'] is True and row['independent_inode'] is True and same_bytes(a,b),'Copy logical/physical identity mismatch')
        require(b['path'] not in physical,'Duplicate physical copy');physical.add(b['path'])
        require(pin(a['path'])==a and pin(b['path'])==b,'Actual copied/source bytes changed')
        aa=Path(a['path']).stat();bb=Path(b['path']).stat();require((aa.st_dev,aa.st_ino)!=(bb.st_dev,bb.st_ino),'Copy is a hardlink')
    return rows

def validate_barriers(rows,catalog,pending_owner=PENDING,olddata_count=2):
    by={x['module']:x for x in rows};require(len(by)==len(rows) and set(by)==set(catalog),'Lost/duplicate accepted membership barrier')
    for owner,row in by.items():
        require(row['forbidden_modes']==MODES,'Accepted owner permits a mode')
        require(row['status']==('original_pending_three_modes_forbidden' if owner==pending_owner else 'accepted_membership_forbidden'),'Accepted/provisional provenance category rewritten')
        if owner==pending_owner:require([v['mode'] for v in row['original_mode_records']]==MODES,'Missing original three-mode barriers')
    require(sum(bool(x.get('old_data_forbidden')) for x in rows)==olddata_count,'Lost oldData prohibition')
    return by

def validate_failed_shape_release(release,graph_pin,active_source_pin,loader):
    r=Reader();anchor=r.read(release['failed_anchor']);require(anchor['module']==OWNER and release=={**anchor,'revision_manifest':release['revision_manifest'],'failed_anchor':release['failed_anchor']},'Failed release is not exact original tuple')
    require(release['new_graph']==graph_pin and graph_pin['sha256']==GRAPH_SHA and release['new_source']==active_source_pin and active_source_pin['sha256']==SOURCE_SHA,'Failed release new graph/source differs')
    require(type(release['exit_code']) is int and release['exit_code']==1 and release['stop_reason'] is None and release['object'] is None and release['no_pending'] is True,'Failed class is not exact typed exit1/noobject')
    directory=Path(release['command']['path']).parent
    require(directory.name=='1795850553477374435-63a4ed6a' and directory.parent.name=='normal' and directory.parent.parent.name==OWNER,'Wrong failed attempt')
    names={'command':'COMMAND.json','process_return':'PROCESS_RETURN.json','result':'RESULT.json','log':'output.log','local_inputs':'LOCAL_INPUTS.json'}
    require({p.name for p in directory.iterdir()}==set(names.values()) and all(p.is_file() and not p.is_symlink() for p in directory.iterdir()),'Failed namespace has unknown/ambiguous outcome')
    for key,name in names.items():require(release[key]['path']==str(directory/name),'Failed tuple sidefile transplant');r.check(release[key])
    command=r.read(release['command']);ret=r.read(release['process_return']);result=r.read(release['result']);ident=command['identity']
    require(ident==release['old_identity'] and ident['key']==OWNER and ident['mode']=='normal' and ident['family']==release['old_family'] and ident['batch']==release['old_batch'],'Failed original identity differs')
    require(command['local_inputs']==release['local_inputs'] and command['actual_argv']==[str(directory/'normal.olean') if x=='__NORMAL_OUTPUT__' else x for x in ident['argv']],'Failed actual argv/D differs')
    require(ident['argv'][-1]==release['old_source']['path'],'Logical source substituted into original COMMAND')
    require(ret['identity']==ident and ret['command']==result['command']==release['command'] and ret['log']==result['log']==release['log'] and result['process_return']==release['process_return'] and ret['object']==result['object'] is None,'Failed durable process chain differs')
    require(process_schema(result)==process_schema(ret['process_result']) and result['exit_code']==1 and result['stop_reason'] is None,'Failed metrics/status differ')
    for item in r.read(release['local_inputs']):r.check(item)
    oldgraph=r.read(release['old_graph']);newgraph=r.read(graph_pin);report=r.read(release['revision_manifest'])
    loader.load('revision4_collect').validate_revision(r,oldgraph,newgraph,report)
    return release

def validate_qualified_identity(ctx,seal,authority,count=1642,native_count=555):
    require(ctx['schema']=='p26_revision4_transported1642_context_v1' and seal['schema']=='p26_revision4_verified_pending_prefix_v1' and ctx['protocol']==seal['protocol']==QPROTOCOL,'Wrong qualified ABI')
    require(ctx['qualification']==authority['qualification_seal'] and seal['outputs_post']==authority['qualification_outputs_post'],'Qualified seal/output transplant')
    for key in ('contract','source_lock','accepted_parent','qualification_environment_sha256'):require(ctx[key]==seal[key],'Qualified identity differs: '+key)
    require(ctx['contract']==authority['qualification_contract'] and ctx['source_lock']==authority['qualifier_source_lock'],'Qualifier contract/code identity differs')
    for obj in (ctx,seal):require(obj['formal_acceptance'] is True and obj['P2_6_complete'] is False and obj['executor_calls']==obj['Lean_commands']==obj['proof_modes_repeated']==0,'Qualification was not zero-execution transport')
    require(len(ctx['project_closure'])==seal['transported_count']==count and seal['accepted_parent_count']==count-1 and len(ctx['native_artifacts'])==native_count and PENDING in ctx['project_closure'] and OWNER not in ctx['project_closure'],'Not exact qualified prefix')

def validate_output_closure(outputs,expected_metadata,copies):
    require(outputs['metadata_pins']==expected_metadata and outputs['physical_copies']==[x['physical'] for x in copies] and outputs['all_actual_bytes_matched'] is True,'OUTPUTS_POST/COPY_MAP differs')

def collect_qualified_prefix(input_contract_pin,loader):
    r=Reader();authority=validate_authority_contract(r.read(input_contract_pin))
    values={k:r.read(v) for k,v in authority.items() if k not in ('schema','status','shape_source')};r.check(authority['shape_source'])
    ctx=values['qualification_context'];seal=values['qualification_seal'];outputs=values['qualification_outputs_post'];stage=Path(authority['qualification_context']['path']).parent
    validate_qualified_identity(ctx,seal,authority)
    require(ctx['new_graph']==authority['graph'],'Wrong qualified source graph')
    review=values['qualification_review'];require(review['context']==authority['qualification_context'] and review['qualification']==authority['qualification_seal'] and review['findings']=={'critical':0,'important':0,'minor':0},'Actual qualification review mismatch')
    for item in values['qualifier_delivery']['members']:r.check(item)
    qlock=values['qualifier_source_lock']
    for item in [qlock['qualifier'],qlock['python'],*qlock['modules'].values()]:r.check(item)
    started=r.read(seal['qualification_started']);collected_pin=started['collected'];col=r.read(collected_pin)
    require(started['contract']==col['contract']==ctx['contract'] and started['source_lock']==col['source_lock']==ctx['source_lock'] and col['accepted_parent']==ctx['accepted_parent'],'Qualified collected lineage differs')
    require(len(col['parent_catalog'])==1641 and set(ctx['project_closure'])==set(col['parent_catalog'])|{PENDING},'Accepted parent membership changed')
    require(ctx['runtime']==col['runtime'] and ctx['external_modules']==col['external_modules'] and ctx['lean_path'].split(':')[1:]==col['lean_path'].split(':')[1:],'Qualified runtime/search scope differs')
    dpre=r.read(seal['D_PRE']);post=r.read(seal['D_and_copy_POST']);snapshot=r.read(seal['fresh_original_G_current']);copies=r.read(seal['copy_map']);barriers=r.read(seal['all_mode_barriers']);release=r.read(seal['exact_failed_release'])
    require(dpre['contract']==post['contract']==ctx['contract'] and dpre['pins']==unique(col['pending']['actual_local_pins']) and dpre['actual_matched'] is True,'Qualification exact D pre differs')
    require(post['actual_D_matched'] is True and post['metadata_input_post_matched'] is True and post['copy_readback']['source_and_copy_actual_bytes_matched'] is True,'Qualification D/copy post incomplete')
    qinputs=r.read(post['qualifier_inputs'])
    for item in qinputs['pins']:r.check(item)
    require(snapshot['purpose']=='PENDING_PREFIX_QUALIFICATION_OLD_G_CURRENT' and snapshot['matched'] is True and snapshot['mismatches']==[] and snapshot['old_POST_created'] is False,'Not truthful fresh qualification boundary')
    require(snapshot['identity']=={'contract':ctx['contract'],'old_family':col['original_family'],'old_batch':col['original_batch'],'old_pre':col['old_global_pre'],'original_selector':col['old_global_selector']},'Fresh original G identity differs')
    require(snapshot['expected']==col['old_global_expected'] and snapshot['files_hashed']==snapshot['files_attempted']==snapshot['expected']['files'] and snapshot['bytes_read']==snapshot['expected']['bytes'] and snapshot['actual_map_sha256']==snapshot['expected']['map_sha256'],'Fresh original G not complete')
    expected_metadata=[collected_pin,seal['qualification_started'],seal['D_PRE'],seal['copy_map'],seal['fresh_original_G_current'],post['qualifier_inputs'],seal['D_and_copy_POST'],seal['all_mode_barriers'],seal['exact_failed_release']]
    validate_output_closure(outputs,expected_metadata,copies)
    validate_copy_map(copies)
    for item in expected_metadata+outputs['physical_copies']:r.check(item)
    copy_by_physical={row['physical']['path']:row for row in copies}
    for owner,entry in ctx['project_closure'].items():
        for key in ('source','selected_object'):require(copy_by_physical[entry[key]['path']]['physical']==entry[key],'Catalog copy identity differs')
        if owner!=PENDING:require(entry['original_accepted_entry']==col['parent_catalog'][owner],'Original accepted provenance rewritten')
    for item in ctx['native_artifacts']:require(copy_by_physical[item['path']]['physical']==item,'Native copy missing')
    require(ctx['source_mappings']==col['source_mappings'] and ctx['all_mode_barriers']==seal['all_mode_barriers'] and ctx['failed_release']==seal['exact_failed_release'],'Qualified mappings/ledgers differ')
    validate_barriers(barriers,ctx['project_closure']);pending=col['pending']
    require(seal['original_mode_records']==pending['records'] and [v['mode'] for v in pending['records']]==MODES,'Original three-mode evidence lost')
    for record in pending['records']:
        ident=r.read(record['command'])['identity'];require(ident['key']==PENDING and ident['mode']==record['mode'] and ident['family']==col['original_family'] and ident['batch']==col['original_batch'],'Original pending identity rewritten')
    validate_failed_shape_release(release,authority['graph'],authority['shape_source'],loader)
    fixed_files=unique(expected_metadata+outputs['physical_copies']+[authority['qualification_outputs_post'],authority['qualification_seal'],authority['qualification_context']])
    exact_stage_namespace(stage,fixed_files)
    ext=loader.load('revision4_transport').external_namespace(r,col['environment_lock'])
    oldfamily=r.read(col['original_family']);oldbatch=r.read(col['original_batch']);oldG=loader.load('revision4_collect').original_global_items(r,oldfamily,col['original_family'],oldbatch,col['original_batch'])
    require({'files':len(oldG),'bytes':sum(x['bytes'] for x in oldG),'map_sha256':digest(oldG)}==col['old_global_expected'],'Original physical G union differs')
    result={'schema':'shape_b1_readonly_qualified_prefix_certificate_v1','protocol':PROTOCOL,'input_contract':input_contract_pin,'authority':authority,'qualified_context':authority['qualification_context'],'qualified_seal':authority['qualification_seal'],'qualification_outputs_post':authority['qualification_outputs_post'],
      'qualified_stage':str(stage),'qualified_files':fixed_files,'project_closure':ctx['project_closure'],'native_artifacts':ctx['native_artifacts'],'runtime':ctx['runtime'],'lean_path':ctx['lean_path'],'external_modules':ctx['external_modules'],'environment_lock':col['environment_lock'],'environment':oldfamily['environment'],'raw_inputs':[x['physical'] for x in copies if x['role']=='original-JSON-copy'],
      'graph':authority['graph'],'shape_source':authority['shape_source'],'source_revision_manifest':authority['revision_report'],'all_mode_barriers':barriers,'failed_releases':[release],'original_physical_G':oldG,'qualification_input_pins':qinputs['pins'],'original_pending_local_D':pending['actual_local_pins'],'original_epoch_pins':pending['exact_epoch_pins'],'copy_map':copies,'source_mappings':ctx['source_mappings'],
      'normal_search_roots':oldfamily['normal_search_roots']+[str(Path(col['original_family']['path']).parent/'batches')],'authority_D_anchors':unique(list(authority[k] for k in FIELDS-{'schema','status'})+expected_metadata+[ctx['all_mode_barriers'],ctx['failed_release']]),
      'observed_metadata_pins':list(r.expected.values()),'verified_parent_formal_acceptance':True,'executor_calls':0,'Lean_commands':0,'formal_acceptance':False,'original_full_snapshot_verified':False,'P2_6_complete':False}
    r.post();exact_stage_namespace(stage,fixed_files);return result
