"""Bounded immutable IO and zero-process/write confinement; no proof executor."""
import hashlib, json, math, os, re, sys
from pathlib import Path

class IntegrityError(RuntimeError):pass

def require(ok,message):
    if not ok:raise IntegrityError(message)

def valid_pin(row):
    require(isinstance(row,dict) and set(row)=={'path','bytes','sha256'} and isinstance(row['path'],str) and Path(row['path']).is_absolute() and type(row['bytes']) is int and row['bytes']>=0 and isinstance(row['sha256'],str) and re.fullmatch('[0-9a-f]{64}',row['sha256']) is not None,'Malformed exact pin')
    return row

def raw_pin(path,raw):return {'path':str(Path(path).absolute()),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}

def pin(path):
    path=Path(path).absolute();h=hashlib.sha256();size=0
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b);size+=len(b)
    return {'path':str(path),'bytes':size,'sha256':h.hexdigest()}

def external(path,sha):
    p=pin(path);require(p['sha256']==sha,'External SHA mismatch: '+str(path));return p

def strict_json(raw):
    def pairs(rows):
        result={}
        for k,v in rows:require(k not in result,'Duplicate JSON key');result[k]=v
        return result
    def bad(v):raise IntegrityError('Nonfinite JSON: '+v)
    return json.loads(raw,object_pairs_hook=pairs,parse_constant=bad)

class Reader:
    def __init__(self):self.expected={};self.seen=set();self.actual_checks=0
    def expect(self,item):
        valid_pin(item);require(self.expected.setdefault(item['path'],item)==item,'Conflicting expected pin');return item
    def check(self,item,fresh=False):
        self.expect(item)
        if fresh or item['path'] not in self.seen:
            require(pin(item['path'])==item,'Pinned bytes mismatch: '+item['path']);self.seen.add(item['path']);self.actual_checks+=1
        return item
    def raw(self,item):
        self.expect(item);raw=Path(item['path']).read_bytes();require(raw_pin(item['path'],raw)==item,'Pinned metadata mismatch: '+item['path']);self.seen.add(item['path']);self.actual_checks+=1;return raw
    def read(self,item):return strict_json(self.raw(item))
    def post(self):
        for item in list(self.expected.values()):self.check(item,fresh=True)
        return {'files':len(self.expected),'all_actual_bytes_matched':True}

def unique(rows):
    by={}
    for row in rows:valid_pin(row);require(by.setdefault(row['path'],row)==row,'Conflicting pin union')
    return [by[k] for k in sorted(by)]

def digest(rows):
    h=hashlib.sha256()
    for row in unique(rows):h.update(json.dumps(row,sort_keys=True,separators=(',',':')).encode()+b'\n')
    return h.hexdigest()

def same_bytes(a,b):return all(a[k]==b[k] for k in ('bytes','sha256'))

def dump(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x') as f:json.dump(value,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
    return pin(path)

def safe_stage(root,path):
    root=Path(root);path=Path(path);require('..' not in root.parts and '..' not in path.parts,'Dotdot output path forbidden')
    root=root.absolute();path=path.absolute();require(root==root.resolve() and path!=root and path.resolve().is_relative_to(root),'Output outside canonical new root')
    for p in (path,*path.parents):
        require(not p.is_symlink(),'Output symlink')
        if p==root:break
    return path

def process_schema(value):
    fields={'exit_code','stop_reason','seconds','sampled_peak_tree_rss_bytes'}
    require(fields<=set(value) and type(value['exit_code']) is int and value['stop_reason'] in (None,'aggregate_tree_rss_limit','disk_reserve_512_MiB','wall_timeout'),'Malformed/stopped process')
    require(type(value['seconds']) in (int,float) and math.isfinite(value['seconds']) and value['seconds']>=0 and type(value['sampled_peak_tree_rss_bytes']) is int and value['sampled_peak_tree_rss_bytes']>=0,'Malformed process metrics')
    return {k:value[k] for k in fields}

_PROCESS_GUARDS=[]
_WRITE_GUARDS=[]
def _audit(event,args):
    if event.startswith(('subprocess.','os.exec','os.spawn','os.posix_spawn')) or event in ('os.system','os.fork','os.forkpty'):
        active=[guard for guard in _PROCESS_GUARDS if guard.active]
        for guard in active:guard.attempts+=1
        if active:raise IntegrityError('Process execution forbidden: '+event)
    for guard in _WRITE_GUARDS:
        if not guard.active:continue
        paths=[]
        if event=='open':
            path,mode,flags=args
            writing=(isinstance(mode,str) and any(v in mode for v in ('w','a','x','+'))) or (isinstance(flags,int) and bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND)))
            if writing:paths=[path]
        elif event in ('os.mkdir','os.remove','os.rmdir','os.utime','os.chmod','os.truncate'):paths=[args[0]]
        elif event in ('os.rename','os.link','os.symlink'):paths=list(args[:2])
        for p in paths:
            require(isinstance(p,(str,bytes,os.PathLike)),'FD/relative write not allowed')
            q=Path(os.fsdecode(p));require('..' not in q.parts,'Dotdot write path forbidden');q=q.absolute();require(q.resolve()==guard.root or q.resolve().is_relative_to(guard.root),'Write outside exclusive new stage: '+str(q))
            for parent in (q,*q.parents):
                require(not parent.is_symlink(),'Symlink in writable path')
                if parent==guard.root:break
sys.addaudithook(_audit)

class ProcessGuard:
    def __init__(self):self.active=False;self.attempts=0;_PROCESS_GUARDS.append(self)
    def __enter__(self):self.active=True;return self
    def __exit__(self,*exc):self.active=False

class WriteGuard:
    def __init__(self,root):
        root=Path(root);require('..' not in root.parts,'Dotdot write root forbidden');self.root=root.absolute();require(self.root==self.root.resolve(),'Noncanonical write root');self.active=False;_WRITE_GUARDS.append(self)
    def __enter__(self):self.active=True;return self
    def __exit__(self,*exc):self.active=False

# New shape-family ports. No eager legacy imports or proof execution here.
ROOT=Path(__file__).resolve().parent
PROTOCOL='source_revision4_shape_family_batch_global_boundary_v1'
OWNER='ImbalancedChen.P2OriginalSaving19Geometry06ScalableShapeArrays'
MODES=['normal','stock-leanchecker','full-owned']

def copy_artifact(item,target,role):
    valid_pin(item);target=safe_stage(ROOT,target);target.parent.mkdir(parents=True,exist_ok=True)
    h=hashlib.sha256();size=0
    with Path(item['path']).open('rb') as src,target.open('xb') as dst:
        for b in iter(lambda:src.read(1024*1024),b''):dst.write(b);h.update(b);size+=len(b)
        dst.flush();os.fsync(dst.fileno())
    require(size==item['bytes'] and h.hexdigest()==item['sha256'],'Copy source bytes changed')
    physical={**item,'path':str(target)};require(pin(target)==physical,'Copy byte readback mismatch')
    a=Path(item['path']).stat();b=target.stat();require((a.st_dev,a.st_ino)!=(b.st_dev,b.st_ino),'Independent inode required')
    return {'logical':item,'physical':physical,'role':role,'original_identity_preserved':True,'independent_inode':True}

def exact_tree(root,expected,empty=()):
    root=Path(root).absolute();expected=set(map(str,expected));actual={str(p) for p in root.rglob('*') if p.is_file() or p.is_symlink()}
    require(actual==expected and all(not p.is_symlink() for p in root.rglob('*')),'Unknown/missing/symlink new namespace')
    directories={root/Path(p) for p in empty}
    for item in map(Path,expected):
        for parent in item.parents:
            if parent==root:break
            require(parent.is_relative_to(root),'Namespace path transplant');directories.add(parent)
    require({p for p in root.rglob('*') if p.is_dir()}==directories,'Unknown/missing empty namespace directory')

def baseline_union(certificate,new_files,controls):
    fields=['original_physical_G','qualified_files','qualification_input_pins','original_pending_local_D','original_epoch_pins','authority_D_anchors','observed_metadata_pins']
    return unique([item for key in fields for item in certificate[key]]+list(new_files)+list(controls))

def require_copy_budget(required,free):require(type(required) is int and required>=0 and free>=required+2*1024**3,'Insufficient cold copy bytes plus2GiB reserve')

def env_for(epoch,extension):
    epoch=Path(epoch);sysroot=extension['environment']['sysroot']
    return {'HOME':str(epoch/'home'),'TMPDIR':str(epoch/'tmp'),'LANG':'C.UTF-8','LC_ALL':'C.UTF-8','TZ':'UTC','LEAN_PATH':extension['lean_path'],'LEAN_NUM_THREADS':'1','OMP_NUM_THREADS':'1','LEAN_SYSROOT':sysroot,'PATH':sysroot+'/bin:/usr/bin:/bin'}

def env_hash(env):return hashlib.sha256(json.dumps(env,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def flags(extension):return ['--trust=0','-DwarningAsError=true','-j1','-M12288','-DmaxRecDepth=1000000','-DmaxHeartbeats=0']
def module_path(root,folder,owner,suffix):
    require(re.fullmatch(r'ImbalancedChen(?:\.[A-Za-z0-9_]+)+',owner) is not None,'Unsafe project module')
    return Path(root)/folder/Path(owner.replace('.','/')).with_suffix(suffix)
def source_path(root,owner):return module_path(root,'project',owner,'.lean')
def object_path(root,owner):return module_path(root,'objects',owner,'.olean')
def family_path(extension):return Path(extension['family_root'])

def sticky(stage,reason,detail=None,*unused):
    stage=safe_stage(ROOT,stage)
    if not (stage/'INTEGRITY_FAILED.json').exists():dump(stage/'INTEGRITY_FAILED.json',{'reason':reason,'detail':detail,'formal_acceptance':False,'P2_6_complete':False})
    raise IntegrityError(reason)

def ensure_clean(stage,extension=None):
    stage=Path(stage);family=family_path(extension) if extension else stage
    require(not (stage/'INTEGRITY_FAILED.json').exists() and not (family/'INTEGRITY_FAILED.json').exists(),'Sticky integrity failure prohibits execution')

def next_owners(order,accepted,count):
    require(type(count) is int and 1<=count<=8 and len(order)==len(set(order)),'Invalid exact next owner count')
    remaining=[n for n in order if n not in accepted];require(len(remaining)>=count,'No padded/repeated tail');return remaining[:count]

def seed_files(certificate,graph,family):
    family=safe_stage(ROOT,family);plans={};catalog={};rows=[]
    def plan(item,target,role):
        target=str(target);old=plans.setdefault(target,(item,role));require(same_bytes(old[0],item),'Conflicting seed target')
        return {**item,'path':target}
    for owner,entry in sorted(certificate['project_closure'].items()):
        s=plan(entry['source'],source_path(family,owner),'qualified-parent-source');o=plan(entry['selected_object'],object_path(family,owner),'qualified-parent-object')
        restore=plan(entry['selected_object'],module_path(family,'restore-parent',owner,'.olean'),'qualified-parent-object-restore-copy')
        catalog[owner]={**entry,'source':s,'selected_object':o,'original_accepted_entry':entry};rows.append((owner,restore))
    for owner,entry in graph['entries'].items():
        if owner in catalog:require(same_bytes(catalog[owner]['source'],entry['source']),'Qualified accepted source changed')
        else:plan(entry['source'],source_path(family,owner),'unaccepted-fixed-graph-source')
    original_object_root=Path(certificate['lean_path'].split(':')[0]);native=[]
    for item in certificate['native_artifacts']:
        relative=Path(item['path']).relative_to(original_object_root);require('..' not in relative.parts,'Unsafe native path');native.append(plan(item,family/'objects'/relative,'qualified-native'))
    stage=Path(certificate['qualified_stage'])
    for item in certificate['qualified_files']:
        relative=Path(item['path']).relative_to(stage)
        if relative.parts[0] not in ('project','objects'):plan(item,family/'evidence/qualification'/relative,'qualified-original-evidence-or-control')
    raws=[plan(item,family/'raw'/Path(item['path']).name,'qualified-original-raw') for item in certificate['raw_inputs']]
    return {'plans':plans,'catalog':catalog,'native':native,'restore_parent':dict(rows),'raws':raws}

def validate_original_G(rows,expected):
    rows=unique(rows);require({'files':len(rows),'bytes':sum(x['bytes'] for x in rows),'map_sha256':digest(rows)}==expected,'Missing/altered original physical G reference')
    return rows

def validate_seed_layout(layout,certificate,graph,family):
    family=Path(family);catalog=certificate['project_closure'];expected_sources=set(catalog)|set(graph['entries'])
    sources={str(source_path(family,n)) for n in expected_sources};objects={str(object_path(family,n)) for n in catalog}
    oldroot=Path(certificate['lean_path'].split(':')[0]);objects|={str(family/'objects'/Path(x['path']).relative_to(oldroot)) for x in certificate['native_artifacts']}
    actual_sources={p for p in layout['plans'] if Path(p).is_relative_to(family/'project')};actual_objects={p for p in layout['plans'] if Path(p).is_relative_to(family/'objects')}
    require(actual_sources==sources and actual_objects==objects and set(layout['catalog'])==set(catalog),'Seed source/object/native namespace not exact')

def seed_family(family,certificate_pin,rss_gib,wall_seconds,loader,controls):
    import shutil,time
    from shape_parent import collect_qualified_prefix,OWNER as TARGET,GRAPH_SHA,SOURCE_SHA
    family=safe_stage(ROOT,family);require(family==ROOT/'families/main' and not family.exists(),'One exclusive independent family required')
    require(rss_gib==12 and wall_seconds==2400,'Original internal proof resource limits required')
    r=Reader();certificate=r.read(certificate_pin);require(certificate['verified_parent_formal_acceptance'] is True and certificate['formal_acceptance'] is False,'Unqualified parent certificate')
    current=collect_qualified_prefix(certificate['input_contract'],loader)
    require({k:v for k,v in certificate.items() if k not in ('controller_source_lock','controller_delivery')}==current,'Adapter certificate authority changed')
    require(len(current['project_closure'])==1642 and len(current['native_artifacts'])==555 and current['graph']['sha256']==GRAPH_SHA and current['shape_source']['sha256']==SOURCE_SHA,'Wrong production seed authority')
    graph=r.read(current['graph']);require(next_owners(graph['topological_order'],set(current['project_closure']),1)==[TARGET],'ShapeArrays is not exact next owner')
    validate_original_G(current['original_physical_G'],current['original_global_expected'])
    layout=seed_files(current,graph,family);validate_seed_layout(layout,current,graph,family);require_copy_budget(sum(p['bytes'] for p,role in layout['plans'].values()),shutil.disk_usage(ROOT).free)
    started=__import__('time').monotonic();family.mkdir(parents=True);copies=[]
    try:
        for target,(item,role) in layout['plans'].items():copies.append(copy_artifact(item,target,role))
        for part in ['batches','home','tmp']:(family/part).mkdir()
        base=dump(family/'BASE_CONTEXT.json',{'schema':'shape_b1_copied1642_base_v1','protocol':PROTOCOL,'formal_acceptance':False,'verified_parent_formal_acceptance':True,'qualified_context':current['qualified_context'],'certificate':certificate_pin,'project_closure':layout['catalog'],'native_artifacts':layout['native'],'runtime':current['runtime'],'original_full_snapshot_verified':False,'P2_6_complete':False})
        transport=dump(family/'TRANSPORT.json',{'qualified_context':current['qualified_context'],'rows':copies,'original_identities_unchanged':True,'formal_acceptance':False})
        barriers=dump(family/'ALL_MODE_BARRIERS.json',current['all_mode_barriers']);release=dump(family/'FAILED_RELEASES.json',current['failed_releases'])
        frozen=unique([row['physical'] for row in copies]+[base,transport,barriers,release,certificate_pin,*controls,current['graph'],current['source_revision_manifest']])
        baseline=dump(family/'BASE_GLOBAL_INPUTS.json',baseline_union(current,frozen,controls))
        cold_started=time.monotonic();items=unique(r.read(baseline)+[baseline]);actual=[]
        for item in items:r.check(item,fresh=True);actual.append(item)
        cold=dump(family/'COLD_READBACK.json',{'family_root':str(family),'baseline':baseline,'scope':'Complete fixed baseline before FAMILY anchor is created','files':len(actual),'bytes':sum(x['bytes'] for x in actual),'map_sha256':digest(actual),'actual_matched':True,'copy_seconds':cold_started-started,'cold_seconds':time.monotonic()-cold_started,'formal_acceptance':False})
        extension={'schema':'shape_b1_independent_family_v1','protocol':PROTOCOL,'family_root':str(family),'base_catalog':layout['catalog'],'project_sources':{owner:entry['source'] for owner,entry in layout['catalog'].items()},'project_files':[target for target in layout['plans'] if str(family/'project')+'/' in target],
          'native_artifacts':layout['native'],'runtime':current['runtime'],'environment':current['environment'],'environment_lock':current['environment_lock'],'lean_path':str(family/'objects')+':'+':'.join(current['lean_path'].split(':')[1:]),'external_modules':current['external_modules'],'graph':current['graph'],'base_context':base,'certificate':certificate_pin,'transport':transport,'base_global_inputs':baseline,'cold_readback':cold,'code_pins':controls,'authority_D_anchors':unique(current['authority_D_anchors']+[certificate_pin,base,barriers,release]),
          'all_mode_barriers':current['all_mode_barriers'],'all_mode_barriers_manifest':barriers,'failed_releases':current['failed_releases'],'failed_releases_manifest':release,'source_revision_manifest':current['source_revision_manifest'],'normal_search_roots':current['normal_search_roots']+[current['qualified_stage']],'restore_parent_objects':layout['restore_parent'],'raw_copies':layout['raws'],'copy_map':copies,'rss_gib':12,'wall_seconds':2400,'outer_limits':{'memory_mb':13107,'timeout_seconds':3600,'cpu_threads':1},'maximum_batch_size':1,'concurrency':1,'scope':'Only revised ShapeArrays B1 from real qualified1642; no successor or integral/global closure.','original_full_snapshot_verified':False,'formal_acceptance':False,'P2_6_complete':False}
        for owner,row in graph['entries'].items():extension['project_sources'].setdefault(owner,{**row['source'],'path':str(source_path(family,owner))})
        fp=dump(family/'FAMILY.json',extension);r.check(fp,fresh=True)
        collect_qualified_prefix(current['input_contract'],loader);return fp
    except Exception as exc:sticky(family,'Observed seed integrity failure',str(exc))

# v3-compatible pure names for source-reviewed new engine ports.
def read(path):return strict_json(Path(path).read_bytes())
def check(item):valid_pin(item);require(pin(item['path'])==item,'Actual pinned bytes changed: '+item['path']);return item
def copy_exact(source,target,expected):
    require(str(Path(source))==expected['path'],'Copy source identity differs')
    if Path(target).exists():require(same_bytes(pin(target),expected),'Existing canonical copy mismatch');return pin(target)
    return copy_artifact(expected,target,'samebytes-restore')['physical']

# Engine durable outcomes may legitimately be failed/stopped; they never grant retry.
def validate_process_schema(value):return process_schema(value)
