"""New synthetic host cases only; never inspect real qualified stage or run Lean."""
import unittest,tempfile,types,hashlib,json,sys,subprocess,os,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def pin(p):p=Path(p).absolute();b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def mod(n):
 p=ROOT/(n+'.py')
 if not p.exists():raise AssertionError('Task feature missing: '+n)
 m=types.ModuleType(n);m.__file__=str(p);exec(compile(p.read_bytes(),str(p),'exec',dont_inherit=True),m.__dict__);return m

def loaded(n):
 if not (ROOT/(n+'.py')).exists():raise AssertionError('Task feature missing: '+n)
 loader=mod('shape_source_loader');paths={p.stem:pin(p) for p in ROOT.glob('shape_*.py') if p.name!='shape_controller.py'}
 base=Path('/workspace/p26-cell06-family-revision4-r2-20261128')
 paths.update({name:pin(base/(name+'.py')) for name in ['revision4_core','revision4_collect','revision4_loader','revision4_transport']})
 old=Path('/workspace/p26-cell06-source-candidate-20261128/runner');paths.update({name:pin(old/(name+'.py')) for name in ['evidence','templates','controller']})
 paths['checkpoint']=pin('/workspace/p26-cell06-checkpoint-revision3-20261128/checkpoint.py')
 l=loader.SourceLoader(paths);return l.load(n),l

class Temp(unittest.TestCase):
 def setUp(self):self.tmp=tempfile.TemporaryDirectory(dir=ROOT);self.root=Path(self.tmp.name)
 def tearDown(self):self.tmp.cleanup()
 def file(self,n,b):p=self.root/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return p
 def js(self,n,d):return pin(self.file(n,(json.dumps(d,indent=2)+'\n').encode()))

class Task1Tests(Temp):
 def test_disabled_or_numeric_authority_rejected(self):
  p,l=loaded('shape_parent')
  for d in [{'status':'AWAITING_REAL_1642_AUTHORITY'},{'accepted_project_union':1642},{}]:
   with self.assertRaises(RuntimeError):p.validate_authority_contract(d)
 def test_all_external_authority_pins_required(self):
  p,l=loaded('shape_parent');d=p.authority_contract_skeleton()
  self.assertNotIn('context',d)
  with self.assertRaises(RuntimeError):p.validate_authority_contract(d)
 def test_source_loader_rejects_unlocked_exec(self):
  loader=mod('shape_source_loader');x=self.file('x.py',b'exec("bad=1", {})\n')
  with self.assertRaises(RuntimeError):loader.SourceLoader({'x':pin(x)}).load('x')
 def test_source_loader_ignores_cached_module(self):
  loader=mod('shape_source_loader');x=self.file('x.py',b'value=7\n');sys.modules['shape_fixture']=types.SimpleNamespace(value=999)
  try:self.assertEqual(loader.SourceLoader({'shape_fixture':pin(x)}).load('shape_fixture').value,7)
  finally:sys.modules.pop('shape_fixture',None)
 def test_qualified_tree_rejects_unknown_empty_directory(self):
  p,l=loaded('shape_parent');stage=self.root/'qualified';stage.mkdir();(stage/'home').mkdir();(stage/'tmp').mkdir();f=stage/'data';f.write_bytes(b'x')
  p.exact_stage_namespace(stage,[pin(f)])
  (stage/'foreign').mkdir()
  with self.assertRaises(RuntimeError):p.exact_stage_namespace(stage,[pin(f)])
 def test_qualified_tree_rejects_directory_symlink(self):
  p,l=loaded('shape_parent');stage=self.root/'qualified';stage.mkdir();(stage/'home').mkdir();(stage/'tmp').mkdir();f=stage/'data';f.write_bytes(b'x');outside=self.root/'outside';outside.mkdir();(stage/'foreign').symlink_to(outside,target_is_directory=True)
  with self.assertRaises(RuntimeError):p.exact_stage_namespace(stage,[pin(f)])
 def test_copy_map_wrong_physical_or_hardlink_rejected(self):
  p,l=loaded('shape_parent');a=self.file('logical',b'a');b=self.file('physical',b'a');row={'logical':pin(a),'physical':pin(b),'original_identity_preserved':True,'independent_inode':True,'role':'fixture'}
  p.validate_copy_map([row]);b.write_bytes(b'b')
  with self.assertRaises(RuntimeError):p.validate_copy_map([row])
 def test_all_members_forbid_all_modes_without_invented_normal(self):
  p,l=loaded('shape_parent');rows=[{'module':'ImbalancedChen.A','status':'accepted_membership_forbidden','forbidden_modes':p.MODES,'old_data_forbidden':True},{'module':'ImbalancedChen.P','status':'original_pending_three_modes_forbidden','forbidden_modes':p.MODES,'original_mode_records':[{'mode':m,'protocol':'original'} for m in p.MODES]}]
  p.validate_barriers(rows,{'ImbalancedChen.A':{},'ImbalancedChen.P':{}},'ImbalancedChen.P',1)
  rows[-1]['forbidden_modes']=['normal']
  with self.assertRaises(RuntimeError):p.validate_barriers(rows,{'ImbalancedChen.A':{},'ImbalancedChen.P':{}},'ImbalancedChen.P',1)

class Task1ChainTests(Temp):
 def identity(self):
  p,l=loaded('shape_parent');self.assertTrue(hasattr(p,'validate_qualified_identity'),'Missing qualified identity interface')
  c=self.js('contract',{});lock=self.js('lock',{});base=self.js('parent',{});sealpin=self.js('seal',{});out=self.js('outputs',{})
  common={'schema':'p26_revision4_transported1642_context_v1','protocol':p.QPROTOCOL,'contract':c,'source_lock':lock,'accepted_parent':base,'qualification_environment_sha256':'fixture-env','formal_acceptance':True,'P2_6_complete':False,'executor_calls':0,'Lean_commands':0,'proof_modes_repeated':0}
  ctx={**common,'qualification':sealpin,'project_closure':{'A':{},'B':{},p.PENDING:{}},'native_artifacts':[]}
  seal={**common,'schema':'p26_revision4_verified_pending_prefix_v1','outputs_post':out,'transported_count':3,'accepted_parent_count':2}
  auth={'qualification_seal':sealpin,'qualification_outputs_post':out,'qualification_contract':c,'qualifier_source_lock':lock}
  return p,ctx,seal,auth
 def test_context_transplant_rejected(self):
  p,c,s,a=self.identity();p.validate_qualified_identity(c,s,a,3,0);c['qualification']=self.js('foreign',{})
  with self.assertRaises(RuntimeError):p.validate_qualified_identity(c,s,a,3,0)
 def test_outputs_post_transplant_rejected(self):
  p,c,s,a=self.identity();s['outputs_post']=self.js('foreign',{})
  with self.assertRaises(RuntimeError):p.validate_qualified_identity(c,s,a,3,0)
 def test_numeric_count_cannot_hide_missing_member(self):
  p,c,s,a=self.identity();c['project_closure'].pop('A')
  with self.assertRaises(RuntimeError):p.validate_qualified_identity(c,s,a,3,0)
 def test_output_manifest_and_copy_map_relationship(self):
  p,l=loaded('shape_parent');self.assertTrue(hasattr(p,'validate_output_closure'),'Missing output closure interface')
  refs=[self.js('m'+str(i),{}) for i in range(9)];a=pin(self.file('logical',b'x'));b=pin(self.file('copy',b'x'));copies=[{'logical':a,'physical':b}];out={'metadata_pins':refs,'physical_copies':[b],'all_actual_bytes_matched':True}
  p.validate_output_closure(out,refs,copies);out['metadata_pins']=refs[:-1]
  with self.assertRaises(RuntimeError):p.validate_output_closure(out,refs,copies)

class BootstrapTests(Temp):
 def setup_bootstrap(self):
  cli=ROOT/'shape_controller.py';self.assertTrue(cli.exists(),'Task feature missing: shape_controller bootstrap')
  tool=self.root/'tool';tool.mkdir()
  for src in ROOT.glob('shape_*.py'):shutil.copyfile(src,tool/src.name)
  names={p.stem:pin(p) for p in tool.glob('shape_*.py') if p.name!='shape_controller.py'}
  r2=Path('/workspace/p26-cell06-family-revision4-r2-20261128');names.update({n:pin(r2/(n+'.py')) for n in ['revision4_core','revision4_collect','revision4_loader','revision4_transport']})
  old=Path('/workspace/p26-cell06-source-candidate-20261128/runner');names.update({n:pin(old/(n+'.py')) for n in ['evidence','templates','controller']});names['checkpoint']=pin('/workspace/p26-cell06-checkpoint-revision3-20261128/checkpoint.py')
  cli=tool/'shape_controller.py';lock={'schema':'shape_b1_source_lock_v1','controller':pin(cli),'modules':names,'python':pin(Path(sys.executable).resolve())};lp=tool/'SOURCE_LOCK.json';lp.write_text(json.dumps(lock));return tool,cli,lp,lock
 def call(self,cli,lp,lock,badself=False,badlock=False):
  return subprocess.run([sys.executable,'-I','-B',str(cli),'check-bootstrap','--controller-sha256','0'*64 if badself else lock['controller']['sha256'],'--source-lock-file',str(lp),'--source-lock-sha256','0'*64 if badlock else pin(lp)['sha256']],cwd=self.root,env={'PATH':str(Path(sys.executable).resolve().parent)+':/usr/bin:/bin','LANG':'C.UTF-8','LC_ALL':'C.UTF-8','TZ':'UTC'},text=True,capture_output=True)
 def test_bootstrap_actual_entry_and_locked_modules(self):
  tool,cli,lp,l=self.setup_bootstrap();p=self.call(cli,lp,l);self.assertEqual(p.returncode,0,p.stderr);self.assertIn('SOURCE_BOOTSTRAP_ONLY',p.stdout);self.assertFalse((tool/'families').exists())
 def test_bad_external_hashes_precede_localcode(self):
  tool,cli,lp,l=self.setup_bootstrap()
  for a,b in [(True,False),(False,True)]:
   p=self.call(cli,lp,l,a,b);self.assertNotEqual(p.returncode,0);self.assertFalse((tool/'families').exists())
 def test_cwd_and_pycache_cannot_shadow_source(self):
  import py_compile,importlib.util
  tool,cli,lp,l=self.setup_bootstrap();self.file('shape_common.py',b'raise RuntimeError("CWD_POISON")\n');target=tool/'shape_common.py';stat=target.stat();poison=self.file('poison.py',b'raise RuntimeError("PYC_POISON")\n');poison.write_bytes(poison.read_bytes().ljust(stat.st_size,b' '));os.utime(poison,ns=(stat.st_atime_ns,stat.st_mtime_ns));cache=Path(importlib.util.cache_from_source(str(target)));cache.parent.mkdir();py_compile.compile(str(poison),cfile=str(cache),dfile=str(target),doraise=True)
  p=self.call(cli,lp,l);self.assertEqual(p.returncode,0,p.stderr)

class Task2Tests(Temp):
 def test_independent_artifact_copy(self):
  c,l=loaded('shape_common');self.assertTrue(hasattr(c,'copy_artifact'),'Missing seed copy primitive');a=self.file('old',b'bytes');row=c.copy_artifact(pin(a),self.root/'new/data','fixture')
  self.assertNotEqual(a.stat().st_ino,Path(row['physical']['path']).stat().st_ino);self.assertEqual(row['logical'],pin(a))
 def test_fixed_union_keeps_original_and_new_physical_refs(self):
  c,l=loaded('shape_common');self.assertTrue(hasattr(c,'baseline_union'),'Missing complete baseline constructor');a=pin(self.file('original',b'x'));b=pin(self.file('new',b'x'));authority=pin(self.file('authority',b'{}'))
  cert={'original_physical_G':[a],'qualified_files':[authority],'qualification_input_pins':[],'original_pending_local_D':[],'original_epoch_pins':[],'authority_D_anchors':[],'observed_metadata_pins':[]}
  union=c.baseline_union(cert,[b],[]);self.assertEqual({x['path'] for x in union},{a['path'],b['path'],authority['path']})
  with self.assertRaises(RuntimeError):c.baseline_union(cert,[{**a,'sha256':'0'*64}],[])
 def test_unknown_empty_or_symlink_new_namespace_rejected(self):
  c,l=loaded('shape_common');self.assertTrue(hasattr(c,'exact_tree'),'Missing new-family namespace helper');root=self.root/'new';root.mkdir();f=root/'data';f.write_bytes(b'x');c.exact_tree(root,[str(f)])
  (root/'unknown').mkdir()
  with self.assertRaises(RuntimeError):c.exact_tree(root,[str(f)])
 def test_layout_rejects_unaccepted_target_object(self):
  c,l=loaded('shape_common');self.assertTrue(hasattr(c,'validate_seed_layout'),'Missing seed layout closure gate')
  parent='ImbalancedChen.Parent';owner=c.OWNER;old=self.root/'qualified';old.mkdir();source=pin(self.file('qualified/project/ImbalancedChen/Parent.lean',b'source'));obj=pin(self.file('qualified/objects/ImbalancedChen/Parent.olean',b'object'));shape=pin(self.file('shape.lean',b'shape'))
  cert={'project_closure':{parent:{'source':source,'selected_object':obj}},'native_artifacts':[],'lean_path':str(old/'objects'),'qualified_stage':str(old),'qualified_files':[],'raw_inputs':[]};graph={'entries':{owner:{'source':shape}}};family=self.root/'family';layout=c.seed_files(cert,graph,family)
  c.validate_seed_layout(layout,cert,graph,family)
  layout['plans'][str(c.object_path(family,owner))]=(obj,'forbidden-unaccepted-object')
  with self.assertRaises(RuntimeError):c.validate_seed_layout(layout,cert,graph,family)
 def test_old_G_reference_cannot_be_omitted(self):
  c,l=loaded('shape_common');self.assertTrue(hasattr(c,'validate_original_G'),'Missing original G completeness gate');a=pin(self.file('a',b'a'));b=pin(self.file('b',b'b'));expected={'files':2,'bytes':2,'map_sha256':c.digest([a,b])}
  c.validate_original_G([a,b],expected)
  with self.assertRaises(RuntimeError):c.validate_original_G([a],expected)
 def test_cold_copy_budget_preserves_two_GiB(self):
  c,l=loaded('shape_common');self.assertTrue(hasattr(c,'require_copy_budget'),'Missing cold copy disk gate')
  with self.assertRaises(RuntimeError):c.require_copy_budget(100,100+2*1024**3-1)
  c.require_copy_budget(100,100+2*1024**3)

class Task3Tests(Temp):
 def test_all_accepted_modes_rejected_before_executor(self):
  e,l=loaded('shape_engine')
  for owner in ['ImbalancedChen.Accepted','ImbalancedChen.Pending','ImbalancedChen.OldData']:
   ext={'all_mode_barriers':[{'module':owner,'forbidden_modes':['normal','stock-leanchecker','full-owned']} ]}
   for mode in ['normal','stock-leanchecker','full-owned']:
    with self.assertRaises(RuntimeError):e.authorize_mode(ext,owner,mode,l)
 def test_B1_scope_and_source_are_exact(self):
  e,l=loaded('shape_engine');p=l.load('shape_parent');shape=pin(Path('/workspace/p26-cell06-source-revision-20261128/v4/project/ImbalancedChen/P2OriginalSaving19Geometry06ScalableShapeArrays.lean'));graph=pin('/workspace/p26-cell06-source-revision-20261128/v4/CANDIDATE_GRAPH_v4.json');release={'exact':'tuple'}
  cert=self.js('certificate',{'failed_releases':[release]});ext={'all_mode_barriers':[],'graph':graph,'project_sources':{p.OWNER:shape},'failed_releases':[release],'certificate':cert,'scope_owners':[p.OWNER]}
  e.authorize_mode(ext,p.OWNER,'normal',l,lambda *a:release)
  ext['failed_releases']=[{'exact':'different'}]
  with self.assertRaises(RuntimeError):e.authorize_mode(ext,p.OWNER,'normal',l,lambda *a:release)
 def test_real_executor_requires_authorized_capability(self):
  e,l=loaded('shape_engine')
  try:e.real_executor('normal','ImbalancedChen.Accepted',[],str(self.root),{},self.root/'log',2400,12*1024**3)
  except RuntimeError:pass
  except Exception as exc:self.fail('Executor capability must reject before touching legacy runner: '+str(exc))
  else:self.fail('Unpermitted executor call accepted')
 def test_active_source_clone_keeps_distinct_logical_identity(self):
  p,l=loaded('shape_parent');self.assertTrue(hasattr(p,'validate_source_pair'),'Missing distinct logical/physical source validation');a=pin(self.file('logical',b'proof'));b=pin(self.file('physical',b'proof'));pair=p.validate_source_pair(a,b);self.assertEqual(pair['logical'],a);self.assertEqual(pair['physical'],b)
  Path(b['path']).write_bytes(b'wrong')
  with self.assertRaises(RuntimeError):p.validate_source_pair(a,b)
 def test_defer_before_command_if_budget_insufficient(self):
  e,l=loaded('shape_engine')
  with self.assertRaises(e.BudgetDeferred):e.require_mode_budget(2600,0,2400,300)
  e.require_mode_budget(2701,0,2400,300)
 def durable(self):
  e,l=loaded('shape_engine');command_pin=self.js('COMMAND',{});local=self.js('LOCAL',[]);log=pin(self.file('log',b'original'));obj=pin(self.file('normal.olean',b'original object'));ident={'protocol':'new','mode':'normal'};cmd={'identity':ident,'local_inputs':local};ret={'identity':ident,'protocol':'new','command':command_pin,'log':log,'object':obj,'process_result':{'exit_code':0,'stop_reason':None,'seconds':3.0,'sampled_peak_tree_rss_bytes':10},'status':'PROCESS_RETURNED_PENDING_LOCAL_AND_GLOBAL_CHECKS','formal_acceptance':False};return e,cmd,ret,command_pin,local,log,obj
 def test_durable_result_recovery_preserves_metrics_and_time_scope(self):
  e,cmd,ret,cp,local,log,obj=self.durable();value=e.durable_result_payload(cmd,ret,cp,local,log,obj,3,999)
  self.assertEqual(value['seconds'],3.0);self.assertFalse(value['formal_acceptance']);self.assertEqual(value['recovery_local_post']['observed_unix_ns'],999);self.assertEqual(value['recovery_local_post']['scope'],'actual_recovery_time')
 def test_durable_return_transplant_rejected(self):
  e,cmd,ret,cp,local,log,obj=self.durable();ret['command']=self.js('OTHER',{})
  with self.assertRaises(RuntimeError):e.durable_result_payload(cmd,ret,cp,local,log,obj,3,999)
 def test_unknown_command_interruption_never_retry(self):
  e,l=loaded('shape_engine');attempt=self.root/'attempt';attempt.mkdir();(attempt/'COMMAND.json').write_text('{}')
  with self.assertRaises(e.AmbiguousInterruption):e.require_durable_outcome(attempt)
 def test_transport_alias_requires_declared_map(self):
  e,l=loaded('shape_engine');a=pin(self.file('original',b'command'));b=pin(self.file('copied',b'command'));row={'logical':a,'physical':b,'original_identity_preserved':True,'independent_inode':True}
  self.assertEqual(e.original_command_reference(b,[row]),a)
  self.assertEqual(e.original_command_reference(b,[]),b)

class Task3SerialTests(Temp):
 def fixture(self):
  e,l=loaded('shape_engine');f=mod('shape_host_fixture')
  try:values=f.build(self.root,e,l)
  except Exception as exc:self.fail('Serial fixture setup needs reviewed dependency interfaces: '+repr(exc))
  return e,l,values
 def test_serial_modes_once_and_seal_context_recovery(self):
  e,l,(family,stage,ext,batch,executor,calls)=self.fixture()
  try:e.run_batch(stage,ext,batch,executor)
  except Exception as exc:self.fail('Serial new engine must complete fixture: '+repr(exc))
  self.assertEqual(calls,e.MODES);context=stage/'accepted-contexts'/(e.OWNER+'.json');self.assertTrue(context.exists());context.unlink()
  e.run_batch(stage,ext,batch,executor);self.assertEqual(calls,e.MODES);self.assertTrue(context.exists())
 def test_RETURN_without_RESULT_recovers_without_normal_again(self):
  e,l,(family,stage,ext,batch,executor,calls)=self.fixture();pre=e.pre_anchor(stage,ext,batch)
  try:record=e.run_mode(stage,ext,batch,e.OWNER,'normal',pre,[],{},executor)
  except Exception as exc:self.fail('Normal fixture needs exact chain: '+repr(exc))
  attempt=Path(record['result']['path']).parent;(attempt/'RESULT.json').unlink();(attempt/'PENDING.json').unlink()
  e.run_batch(stage,ext,batch,executor);self.assertEqual(calls,e.MODES);self.assertTrue((attempt/'RESULT.json').exists());self.assertIn('recovery_local_post',json.loads((attempt/'RESULT.json').read_bytes()))
 def test_pending_and_canonical_missing_are_restored_without_normal(self):
  e,l,(family,stage,ext,batch,executor,calls)=self.fixture();pre=e.pre_anchor(stage,ext,batch);record=e.run_mode(stage,ext,batch,e.OWNER,'normal',pre,[],{},executor);e.catalog_objects(stage,ext,{e.OWNER:record});Path(record['marker']['path']).unlink();e.object_path(family,e.OWNER).unlink()
  e.run_batch(stage,ext,batch,executor);self.assertEqual(calls,e.MODES);self.assertTrue(Path(record['marker']['path']).exists())
 def test_all_modes_complete_missing_POST_executes_none(self):
  e,l,(family,stage,ext,batch,executor,calls)=self.fixture();pre=e.pre_anchor(stage,ext,batch);e.execute_pending(stage,ext,batch,pre,executor);self.assertEqual(calls,e.MODES);self.assertFalse((stage/'state/BATCH_ACCEPTED.json').exists());e.run_batch(stage,ext,batch,executor);self.assertEqual(calls,e.MODES)
 def test_budget_defer_creates_no_next_COMMAND_then_resumes(self):
  import time
  e,l,(family,stage,ext,batch,executor,calls)=self.fixture();pre=e.pre_anchor(stage,ext,batch);e.run_mode(stage,ext,batch,e.OWNER,'normal',pre,[],{},executor);ext['_invocation_deadline']=time.monotonic()+2600
  with self.assertRaises(e.BudgetDeferred):e.run_batch(stage,ext,batch,executor)
  self.assertEqual(calls,['normal']);self.assertFalse((stage/'steps'/e.OWNER/'stock-leanchecker').exists());ext['_invocation_deadline']=time.monotonic()+10000;e.run_batch(stage,ext,batch,executor);self.assertEqual(calls,e.MODES)
 def test_command_only_is_blocked_without_executor(self):
  e,l,(family,stage,ext,batch,executor,calls)=self.fixture();pre=e.pre_anchor(stage,ext,batch);attempt=stage/'steps'/e.OWNER/'normal/1-deadbeef';attempt.mkdir(parents=True);(attempt/'COMMAND.json').write_text('{}');(attempt/'LOCAL_INPUTS.json').write_text('[]')
  with self.assertRaises(e.AmbiguousInterruption):e.run_batch(stage,ext,batch,executor)
  self.assertEqual(calls,[])
 def test_stopped_mode_is_not_a_retry_permission(self):
  e,l,(family,stage,ext,batch,executor,calls)=self.fixture();pre=e.pre_anchor(stage,ext,batch)
  def stopped(mode,name,argv,cwd,env,log,timeout,rss):calls.append(mode);Path(log).write_text('stopped');return {'exit_code':-9,'stop_reason':'wall_timeout','seconds':0.01,'sampled_peak_tree_rss_bytes':16}
  with self.assertRaises(RuntimeError):e.run_mode(stage,ext,batch,e.OWNER,'normal',pre,[],{},stopped)
  with self.assertRaises(e.ExistingProcessFailure):e.run_batch(stage,ext,batch,stopped)
  self.assertEqual(calls,['normal'])
 def test_existing_failed_mode_no_new_attempt_or_executor(self):
  e,l,(family,stage,ext,batch,executor,calls)=self.fixture();pre=e.pre_anchor(stage,ext,batch)
  def fail(mode,name,argv,cwd,env,log,timeout,rss):
   calls.append(mode);Path(log).write_text('typed failed');return {'exit_code':1,'stop_reason':None,'seconds':0.01,'sampled_peak_tree_rss_bytes':16}
  with self.assertRaises(RuntimeError):e.run_mode(stage,ext,batch,e.OWNER,'normal',pre,[],{},fail)
  for _ in range(2):
   with self.assertRaises(RuntimeError):e.run_batch(stage,ext,batch,fail)
  self.assertEqual(calls,['normal']);self.assertEqual(len(list((stage/'steps'/e.OWNER/'normal').iterdir())),1)

class Task4Tests(Temp):
 def test_B1_request_exact_parent_owner_count_no_successor(self):
  c=mod('shape_controller');self.assertTrue(hasattr(c,'validate_B1_request'),'Missing production B1 scope gate');parent=self.js('BASE',{});owner='ImbalancedChen.P2OriginalSaving19Geometry06ScalableShapeArrays';ext={'base_context':parent,'base_catalog':{'ImbalancedChen.A':{}},'scope_owners':[owner]};graph={'topological_order':['ImbalancedChen.A',owner,'ImbalancedChen.Next']}
  c.validate_B1_request(ext,graph,parent,'shapeArraysB1',1,1)
  for name,count in [('next',1),('shapeArraysB1',2),('shapeArraysB1',True)]:
   with self.assertRaises(RuntimeError):c.validate_B1_request(ext,graph,parent,name,count,1)
  with self.assertRaises(RuntimeError):c.validate_B1_request(ext,graph,self.js('FOREIGN',{}),'shapeArraysB1',1,1)
 def test_bootstrap_refuses_fixture_flags(self):
  b=BootstrapTests();b.root=self.root
  tool,cli,lp,l=b.setup_bootstrap();p=subprocess.run([sys.executable,'-I','-B',str(cli),'check-bootstrap','--controller-sha256',l['controller']['sha256'],'--source-lock-file',str(lp),'--source-lock-sha256',pin(lp)['sha256'],'--fixture','yes'],cwd=self.root,env={'PATH':str(Path(sys.executable).resolve().parent)+':/usr/bin:/bin','LANG':'C.UTF-8','LC_ALL':'C.UTF-8','TZ':'UTC'},text=True,capture_output=True)
  self.assertNotEqual(p.returncode,0);self.assertFalse((tool/'families').exists())

class Task4IntegrationTests(Temp):
 def freeze_fixture(self):
  from types import SimpleNamespace
  c=mod('shape_controller');e,l=loaded('shape_engine');fixture=mod('shape_host_fixture');family,epoch,ext,batch,executor,calls=fixture.build(self.root,e,l);shutil.rmtree(epoch);common=l.load('shape_common');c.ROOT=self.root
  graph={'topological_order':list(ext['base_catalog'])+[e.OWNER,'ImbalancedChen.Future'],'entries':{e.OWNER:{'imports':list(ext['base_catalog'])}}};ext['graph']=self.js('graph.json',graph);ext['scope_owners']=[e.OWNER]
  checked=[];fake=SimpleNamespace(validate_provider=lambda x:checked.append('provider'),namespace_check=lambda *x:checked.append('namespace'),refuse_other_stage_normal=lambda *x:checked.append('crossroot'),LEGACY=e.LEGACY)
  return c,common,l,family,epoch,ext,fake,checked
 def test_freeze_writes_exact_helper_selector_and_no_attempt(self):
  c,common,l,family,epoch,ext,fake,checked=self.freeze_fixture();bp=c.freeze_B1(common,fake,l,ext,ext['base_context'],'shapeArraysB1',1);batch=json.loads(Path(bp['path']).read_bytes())
  self.assertEqual(batch['owners'],[common.OWNER]);self.assertEqual(checked,['provider','namespace','crossroot']);self.assertFalse(any((epoch/'steps').iterdir()));self.assertFalse(batch['formal_acceptance']);self.assertEqual(batch['concurrency'],1)
  helper=Path(batch['helpers'][0]['path']).read_text();self.assertIn('addDeclCore 0 0 declaration',helper);self.assertIn('original with name := aliasName',helper)
  for name in list(ext['base_catalog'])+[common.OWNER]:self.assertIn('import '+name+'\n',helper)
  spec=json.loads(Path(batch['global_inputs']['path']).read_bytes());self.assertIn(ext['cold_readback'],spec['batch_static'])
  with self.assertRaises(RuntimeError):c.freeze_B1(common,fake,l,ext,ext['base_context'],'shapeArraysB1',1)
 def test_wrong_order_or_parent_produces_no_batch(self):
  c,common,l,family,epoch,ext,fake,checked=self.freeze_fixture();wrong=self.js('other-context.json',{})
  with self.assertRaises(RuntimeError):c.freeze_B1(common,fake,l,ext,wrong,'shapeArraysB1',1)
  self.assertEqual(checked,[]);self.assertFalse(epoch.exists());graph=json.loads(Path(ext['graph']['path']).read_bytes());graph['topological_order']=['ImbalancedChen.Future',common.OWNER];Path(ext['graph']['path']).write_text(json.dumps(graph));ext['graph']=pin(ext['graph']['path'])
  with self.assertRaises(RuntimeError):c.freeze_B1(common,fake,l,ext,ext['base_context'],'shapeArraysB1',1)
  self.assertFalse(epoch.exists())
 def test_CLI_freeze_missing_external_anchor_has_zero_outputs(self):
  b=BootstrapTests();b.root=self.root;tool,cli,lp,lock=b.setup_bootstrap();p=subprocess.run([sys.executable,'-I','-B',str(cli),'freeze','--controller-sha256',lock['controller']['sha256'],'--source-lock-file',str(lp),'--source-lock-sha256',pin(lp)['sha256']],cwd=self.root,text=True,capture_output=True)
  self.assertNotEqual(p.returncode,0);self.assertFalse((tool/'families').exists());self.assertFalse((tool/'EXECUTION.lock').exists())

class ReviewFixesTests(Temp):
 def test_F1_all_R2_helpers_bound_and_substitution_rejected_before_load(self):
  p,l=loaded('shape_parent');lock=json.loads(Path('/workspace/p26-cell06-family-revision4-r2-20261128/SOURCE_LOCK.json').read_bytes())
  self.assertTrue(hasattr(p,'bind_qualified_helpers'),'F1 missing checked/executed closure binding')
  p.bind_qualified_helpers(lock,l)
  for name in lock['modules']:
   original=l.pins[name];l.pins[name]=pin(self.file('alternate-'+name+'.py',b'raise RuntimeError("ALTERNATE_EXECUTED")'))
   with self.assertRaises(RuntimeError):p.bind_qualified_helpers(lock,l)
   self.assertNotIn(name,l.loaded);l.pins[name]=original
 def test_F1_collect_and_direct_release_use_the_binding(self):
  import ast
  p=ast.parse((ROOT/'shape_parent.py').read_bytes());func={n.name:n for n in p.body if isinstance(n,ast.FunctionDef)}
  for name in ['collect_qualified_prefix','validate_failed_shape_release']:
   calls=[n for n in ast.walk(func[name]) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='bind_qualified_helpers']
   self.assertTrue(calls,'F1 missing binding in '+name)
 def synthetic_seed(self,kind):
  c,l=loaded('shape_common');p=l.load('shape_parent');c.ROOT=self.root
  base=self.root/'synthetic-provider';base.mkdir();(base/'objects').mkdir()
  src=pin(self.file('synthetic-provider/source',b'synthetic-source'));obj=pin(self.file('synthetic-provider/object',b'synthetic-object'));shape=pin(self.file('synthetic-provider/shape',b'synthetic-shape'))
  catalog={'ImbalancedChen.Fixture'+str(i):{'source':src,'selected_object':obj} for i in range(1642)}
  native=[pin(self.file('synthetic-provider/objects/native'+str(i)+'.so',b'fixture-native')) for i in range(555)]
  graph=self.js('synthetic-provider/graph.json',{'entries':{c.OWNER:{'source':shape}},'topological_order':[c.OWNER]});p.GRAPH_SHA=graph['sha256'];p.SOURCE_SHA=shape['sha256']
  original=[src];lock=self.js('synthetic-provider/environment.json',{});report=self.js('synthetic-provider/revision.json',{})
  cert={'verified_parent_formal_acceptance':True,'formal_acceptance':False,'input_contract':lock,'qualified_context':lock,'qualified_stage':str(base),'project_closure':catalog,'native_artifacts':native,'lean_path':str(base/'objects'),'qualified_files':[],'raw_inputs':[],'graph':graph,'shape_source':shape,'original_physical_G':original,'original_global_expected':{'files':1,'bytes':src['bytes'],'map_sha256':c.digest(original)},'runtime':{'lean':obj,'leanchecker':obj},'environment':{'sysroot':str(base)},'environment_lock':lock,'external_modules':[],'all_mode_barriers':[],'failed_releases':[],'source_revision_manifest':report,'normal_search_roots':[]}
  for k in ['authority_D_anchors','qualification_input_pins','original_pending_local_D','original_epoch_pins','observed_metadata_pins']:cert[k]=[]
  cp=self.js('synthetic-provider/certificate.json',cert);p.collect_qualified_prefix=lambda *args:cert
  original_copy=c.copy_artifact;injected=[];family=self.root/'families/main'
  def copy(item,target,role):
   row=original_copy(item,target,role)
   if not injected:
    if kind=='file':(family/'unlisted.olean').write_bytes(b'foreign')
    elif kind=='directory':(family/'unknown-empty').mkdir()
    else:(family/'unknown-link').symlink_to(base,target_is_directory=True)
    injected.append(True)
   return row
  c.copy_artifact=copy
  with self.assertRaises(RuntimeError):c.seed_family(family,cp,12,2400,l,[])
  self.assertTrue((family/'INTEGRITY_FAILED.json').exists());self.assertEqual(src,pin(src['path']));self.assertEqual(obj,pin(obj['path']))
 def test_F2_seed_extra_file_is_sticky(self):self.synthetic_seed('file')
 def test_F2_seed_extra_empty_directory_is_sticky(self):self.synthetic_seed('directory')
 def test_F2_seed_directory_symlink_is_sticky(self):self.synthetic_seed('link')
 def relative_write(self,kind):
  c,l=loaded('shape_common');allowed=self.root/'new';outside=self.root/'provider';allowed.mkdir();outside.mkdir();before=set(outside.iterdir());fd=os.open(outside,os.O_RDONLY);cwd=Path.cwd();blocked=False
  try:
   os.chdir(allowed)
   with c.WriteGuard(allowed):
    try:
     if kind=='open':
      created=os.open('escaped',os.O_WRONLY|os.O_CREAT,0o600,dir_fd=fd);os.close(created)
     else:os.mkdir('escaped',dir_fd=fd)
    except RuntimeError:blocked=True
  finally:os.chdir(cwd);os.close(fd)
  self.assertTrue(blocked,'F3 relative dir_fd write escaped guard');self.assertEqual(before,set(outside.iterdir()))
 def test_F3_relative_open_with_foreign_fd_rejected(self):self.relative_write('open')
 def test_F3_relative_mkdir_with_foreign_fd_rejected(self):self.relative_write('mkdir')
 def test_F3_absolute_allowed_write_still_works(self):
  c,l=loaded('shape_common');allowed=self.root/'new';allowed.mkdir();target=allowed/'actual'
  with c.WriteGuard(allowed):target.write_bytes(b'allowed')
  self.assertEqual(target.read_bytes(),b'allowed')

class FinalCLIConfinementTests(Temp):
 def test_EXECUTION_lock_symlink_rejected_before_outside_creation(self):
  b=BootstrapTests();b.root=self.root;tool,cli,lp,lock=b.setup_bootstrap();outside=self.root/'provider';outside.mkdir();target=outside/'LOCK';(tool/'EXECUTION.lock').symlink_to(target)
  delivery=self.js('tool/DELIVERY.json',{'members':[]});cp=self.js('invalid-certificate.json',{})
  p=subprocess.run([sys.executable,'-I','-B',str(cli),'seed','--controller-sha256',lock['controller']['sha256'],'--source-lock-file',str(lp),'--source-lock-sha256',pin(lp)['sha256'],'--delivery-sha256',delivery['sha256'],'--certificate',cp['path'],'--certificate-sha256',cp['sha256'],'--family',str(tool/'families/main'),'--rss-gib','12','--wall-seconds','2400'],cwd=self.root,text=True,capture_output=True)
  self.assertNotEqual(p.returncode,0);self.assertFalse(target.exists(),'CLI lock followed outside symlink')

class EngineReviewTests(Temp):
 def fixture(self,slot='one'):
  e,l=loaded('shape_engine');f=mod('shape_host_fixture');root=self.root/slot;root.mkdir();return e,l,f.build(root,e,l)
 def validation_failure(self,message):
  e,l,(family,stage,ext,batch,executor,calls)=self.fixture();pre=e.pre_anchor(stage,ext,batch);original=e.parse_mode
  def rejected(*args):raise RuntimeError(message)
  e.parse_mode=rejected
  with self.assertRaises(RuntimeError):e.run_mode(stage,ext,batch,e.OWNER,'normal',pre,[],{},executor)
  attempt=next((stage/'steps'/e.OWNER/'normal').iterdir());before=pin(attempt/'RESULT.json');self.assertEqual(json.loads((attempt/'RESULT.json').read_bytes())['mode_validation_error'],message);e.parse_mode=original
  with self.assertRaises(RuntimeError):e.run_batch(stage,ext,batch,executor)
  self.assertEqual(calls,['normal']);self.assertEqual(before,pin(attempt/'RESULT.json'));self.assertFalse((attempt/'PENDING.json').exists());self.assertFalse((stage/'state/BATCH_ACCEPTED.json').exists())
 def test_E1_persisted_validation_error_cannot_be_promoted(self):self.validation_failure('recorded validation failure')
 def test_E1_empty_validation_error_cannot_be_promoted(self):self.validation_failure('')
 def test_E1_missing_error_field_is_failclosed(self):
  e,l,(family,stage,ext,batch,executor,calls)=self.fixture();pre=e.pre_anchor(stage,ext,batch);r=e.run_mode(stage,ext,batch,e.OWNER,'normal',pre,[],{},executor);attempt=Path(r['result']['path']).parent;(attempt/'PENDING.json').unlink();result=json.loads((attempt/'RESULT.json').read_bytes());result.pop('mode_validation_error');(attempt/'RESULT.json').write_text(json.dumps(result))
  with self.assertRaises(RuntimeError):e.run_batch(stage,ext,batch,executor)
  self.assertEqual(calls,['normal']);self.assertFalse((attempt/'PENDING.json').exists())
 def test_E2_empty_history_defer_resume_checks_real_global_before_executor(self):
  import time
  e,l,(family,stage,ext,batch,executor,calls)=self.fixture();ext['_invocation_deadline']=time.monotonic()+2600
  with self.assertRaises(e.BudgetDeferred):e.run_batch(stage,ext,batch,executor)
  pre=pin(stage/'state/GLOBAL_PRE.json');self.assertEqual(calls,[]);self.assertFalse(list((stage/'state').glob('RESUME-*')))
  only_G=Path(ext['project_sources']['ImbalancedChen.ParentA']['path']);only_G.write_bytes(b'changed outside current local D');ext['_invocation_deadline']=time.monotonic()+10000
  with self.assertRaises(RuntimeError):e.run_batch(stage,ext,batch,executor)
  self.assertEqual(calls,[]);self.assertEqual(pre,pin(stage/'state/GLOBAL_PRE.json'));self.assertFalse((stage/'steps'/e.OWNER/'normal').exists())
 def test_E2_empty_history_samebytes_resume_retains_PRE(self):
  import time
  e,l,(family,stage,ext,batch,executor,calls)=self.fixture();ext['_invocation_deadline']=time.monotonic()+2600
  with self.assertRaises(e.BudgetDeferred):e.run_batch(stage,ext,batch,executor)
  pre=pin(stage/'state/GLOBAL_PRE.json');ext['_invocation_deadline']=time.monotonic()+10000;e.run_batch(stage,ext,batch,executor);self.assertEqual(calls,e.MODES);self.assertEqual(pre,pin(stage/'state/GLOBAL_PRE.json'));self.assertEqual(len(list((stage/'state').glob('RESUME-*'))),1)
 def test_F1_configure_rejects_all_alternate_helpers_before_loading(self):
  lock=json.loads(Path('/workspace/p26-cell06-family-revision4-r2-20261128/SOURCE_LOCK.json').read_bytes())
  for name in lock['modules']:
   e,l=loaded('shape_engine');l.pins[name]=pin(self.file('bad-'+name+'.py',b'raise RuntimeError("ALTERNATE_EXECUTED")'))
   with self.assertRaises(RuntimeError):e.configure(l)
   self.assertFalse(set(lock['modules'])&set(l.loaded))
 def mutation(self,stage,kind):
  if kind=='file':(stage/'foreign.txt').write_bytes(b'unknown')
  elif kind=='directory':(stage/'steps/foreign-empty').mkdir()
  else:(stage/'state/foreign-link').symlink_to(stage/'steps',target_is_directory=True)
 def test_E3_unknown_file_before_mode_zero_calls_and_no_seal(self):self.before_mutation('file')
 def test_E3_unknown_empty_directory_before_mode_zero_calls_and_no_seal(self):self.before_mutation('directory')
 def test_E3_directory_symlink_before_mode_zero_calls_and_no_seal(self):self.before_mutation('link')
 def before_mutation(self,kind):
  e,l,(family,stage,ext,batch,executor,calls)=self.fixture();self.mutation(stage,kind)
  with self.assertRaises(RuntimeError):e.run_batch(stage,ext,batch,executor)
  self.assertEqual(calls,[]);self.assertFalse((stage/'state/BATCH_ACCEPTED.json').exists())
 def test_E3_post_executor_injection_retains_one_true_call_no_seal(self):
  e,l,(family,stage,ext,batch,executor,calls)=self.fixture()
  def injected(*args):
   result=executor(*args)
   if len(calls)==1:self.mutation(stage,'directory')
   return result
  with self.assertRaises(RuntimeError):e.run_batch(stage,ext,batch,injected)
  self.assertEqual(calls,['normal']);self.assertFalse((stage/'state/BATCH_ACCEPTED.json').exists());attempt=next((stage/'steps'/e.OWNER/'normal').iterdir());self.assertTrue((attempt/'PROCESS_RETURN.json').exists());self.assertTrue((attempt/'normal.olean').exists())

if __name__=='__main__':unittest.main(verbosity=2)
