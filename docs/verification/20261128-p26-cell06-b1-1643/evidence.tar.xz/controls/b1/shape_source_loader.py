"""Externally pinned source-only loader, including nested legacy compile/import."""
import builtins, hashlib, sys, types
from pathlib import Path

class SourceLoader:
    def __init__(self,pins):self.pins=pins;self.loaded={};self.loading=set();self.executed=[];self.codes={}
    def source(self,item):
        raw=Path(item['path']).read_bytes()
        if len(raw)!=item['bytes'] or hashlib.sha256(raw).hexdigest()!=item['sha256']:raise RuntimeError('Locked source bytes mismatch')
        return raw
    def compile(self,source,filename,mode,*args,**kwargs):
        known=[p for p in self.pins.values() if p['path']==filename]
        if len(known)!=1:raise RuntimeError('Nested compile source not locked: '+str(filename))
        raw=source.encode() if isinstance(source,str) else bytes(source)
        expected=self.source(known[0])
        if raw!=expected or mode!='exec':raise RuntimeError('Nested compile bytes differ')
        code=builtins.compile(raw,filename,mode,*args,**kwargs)
        if not isinstance(code,types.CodeType):raise RuntimeError('Only compiled executable code is supported')
        self.codes[id(code)]=code;return code
    def execute(self,code,globals=None,locals=None):
        if globals is None:raise RuntimeError('Implicit exec globals forbidden')
        if not isinstance(code,types.CodeType) or self.codes.get(id(code)) is not code:raise RuntimeError('Unregistered executable code forbidden')
        globals['__builtins__']=self.builtins()
        return builtins.exec(code,globals,locals)
    def importer(self,name,globals=None,locals=None,fromlist=(),level=0):
        if level:raise ImportError('Relative local imports forbidden')
        if name in self.pins:return self.load(name)
        if name.split('.')[0] not in sys.stdlib_module_names:raise ImportError('Unlocked local import: '+name)
        return builtins.__import__(name,globals,locals,fromlist,level)
    def builtins(self):
        return {**vars(builtins),'__import__':self.importer,'compile':self.compile,'exec':self.execute}
    def load(self,name):
        if name in self.loaded:return self.loaded[name]
        if name not in self.pins:raise ImportError('Module absent from source lock')
        if name in self.loading:raise RuntimeError('Source import cycle')
        self.loading.add(name);item=self.pins[name];raw=self.source(item);m=types.ModuleType(name);m.__file__=item['path'];m.__cached__=None;m.__dict__['__builtins__']=self.builtins()
        try:
            code=builtins.compile(raw,item['path'],'exec',dont_inherit=True);self.codes[id(code)]=code
            builtins.exec(code,m.__dict__)
            self.loaded[name]=m;self.executed.append(item);return m
        finally:self.loading.remove(name)
