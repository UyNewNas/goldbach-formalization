"""Synthetic files for new engine crash/count tests; never production authority."""
from pathlib import Path
import json,hashlib,time
ROOT=Path(__file__).resolve().parent

def pin(p):b=Path(p).read_bytes();return {'path':str(Path(p).absolute()),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def write(p,d):p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,indent=2)+'\n');return pin(p)
def raw(p,b):p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return pin(p)

def build(root,e,l):
 c=l.load('shape_common');root=Path(root);family=root/'family';epoch=family/'batches/shapeArraysB1'
 for name in ['project','objects','restore-parent','evidence','home','tmp']: (family/name).mkdir(parents=True)
 for name in ['helpers','state','steps','accepted-contexts','home','tmp']:(epoch/name).mkdir(parents=True)
 owner=c.OWNER;parent={};sources={};restores={}
 for name in ['ImbalancedChen.ParentA','ImbalancedChen.ParentB']:
  s=raw(c.source_path(family,name),b'parent source');o=raw(c.object_path(family,name),name.encode());restore=raw(c.module_path(family,'restore-parent',name,'.olean'),name.encode());parent[name]={'source':s,'selected_object':o};sources[name]=s;restores[name]=restore
 shape=Path('/workspace/p26-cell06-source-revision-20261128/v4/project/ImbalancedChen/P2OriginalSaving19Geometry06ScalableShapeArrays.lean');sources[owner]=raw(c.source_path(family,owner),shape.read_bytes())
 graph=pin('/workspace/p26-cell06-source-revision-20261128/v4/CANDIDATE_GRAPH_v4.json');release={'exact':'synthetic release','command':write(root/'ORIGINAL_RELEASED_COMMAND.json',{'scope':'synthetic old failure'})};cert=write(root/'certificate.json',{'failed_releases':[release],'copy_map':[]});transport=write(family/'TRANSPORT.json',{'rows':[]});base=write(family/'BASE_CONTEXT.json',{'project_closure':parent});cold=write(family/'COLD_READBACK.json',{'actual_matched':True})
 runtime={k:raw(root/k,k.encode()) for k in ['lean','leanchecker']};baseline=write(family/'BASE_GLOBAL_INPUTS.json',list(runtime.values())+list(sources.values())+[cert,base,transport,cold])
 ext={'protocol':c.PROTOCOL,'family_root':str(family),'parent_catalog':parent,'base_catalog':parent,'native_artifacts':[],'runtime':runtime,'environment':{'sysroot':str(root/'sysroot')},'lean_path':str(family/'objects'),'external_modules':[],'graph':graph,'certificate':cert,'base_context':base,'foundation':base,'transport':transport,'copy_map':[],'base_global_inputs':baseline,'cold_readback':cold,'project_sources':sources,'project_files':[v['path'] for v in sources.values()],'restore_parent_objects':restores,'authority_D_anchors':[cert,base],'code_pins':[],'all_mode_barriers':[{'module':n,'forbidden_modes':c.MODES} for n in parent],'failed_releases':[release],'scope_owners':[owner],'normal_search_roots':[],'wall_seconds':2400,'rss_gib':12}
 fp=write(family/'FAMILY.json',ext);ext['_anchor']=fp
 helper=raw(epoch/'helpers'/(owner+'.Owned.lean'),b'owned helper');whitelist=write(epoch/'WHITELIST.json',[owner]);selector=write(epoch/'GLOBAL_INPUTS.json',{'protocol':c.PROTOCOL,'family':fp,'parent_context':base,'baseline':baseline,'prefix_inputs':[],'batch_static':[helper,whitelist]})
 batch={'protocol':c.PROTOCOL,'family':fp,'owners':[owner],'parent_context':base,'helpers':[helper],'whitelist':whitelist,'global_inputs':selector,'environment_sha256':c.env_hash(c.env_for(epoch,ext))};bp=write(epoch/'BATCH.json',batch);batch['_anchor']=bp;ext['global_inputs']=selector;ext['_invocation_deadline']=time.monotonic()+10000
 e.configure(l,provider_validator=lambda ex:json.loads(Path(cert['path']).read_bytes()),release_validator=lambda *a:release)
 calls=[]
 def executor(mode,name,argv,cwd,env,log,timeout,rss):
  calls.append(mode)
  if mode=='normal':
   Path(argv[argv.index('-o')+1]).write_bytes(b'synthetic module artifact');Path(log).write_text('depends on axioms: []\n')
  elif mode=='full-owned':
   decl={'module':owner,'name':owner+'.theorem','type':'True','axioms':[],'unsafe':False,'partial':False,'axiom':False};inv={'module':owner,'environment':[decl['name']],'shared':[],'serialized':[decl['name']]}
   rows=[('IMPORTS',list(parent)+[owner]),('INVENTORY',inv),('DECL',decl),('COMPLETE',{'module':owner,'count':1,'shared_count':0,'serialized_count':1})]
   Path(log).write_text('\n'.join('P26_CELL06_AUDIT_'+k+' '+json.dumps(v) for k,v in rows)+'\n')
  else:Path(log).write_text('synthetic stock exit0\n')
  return {'exit_code':0,'stop_reason':None,'seconds':0.01,'sampled_peak_tree_rss_bytes':16}
 return family,epoch,ext,batch,executor,calls
