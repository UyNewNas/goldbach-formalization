"""Read-only accepted-parent and pending-prefix qualification inputs. No executors."""
from pathlib import Path
from types import SimpleNamespace
import json, re
from revision4_core import *

MODES=['normal','stock-leanchecker','full-owned']
POLICY={
 'source_delivery':'038ad99a7a5fd25c6d891b68140dbfa46c368c8429fdcc733187784abad31ca0',
 'review_anchor':'a680319e8f272cc4337bd5529c4bc04cfde1ec7b044b3b1d8a8fe85a33e9cd9d',
 'published_capsule':'9b1459c697f25dc5e281a179dc405967c174333782a8711e2ca4e96e0485570e',
 'new_graph':'ecd1c7e2156e69acd099b7e08f9b47f448c8ac2bf75d7f531a3cb7785e99895b',
 'revision_report':'5e35bff706a07088d74de583d642beb6b9041d06ca38b8d00a7fe0646a9ee6a8',
 'pending_anchor':'bf1181d5381ac01dbefcc168fb6e8f4d1801af211a582f9d0734ff1cc0e2ee8a',
 'failed_anchor':'b8c26df3046bdeb9dcb3f342d65d4e77147c37bca1745478bb68bbccc7dcdf25'}

def membership_barriers(parent,count,original_barriers,mode_records=()):
    catalog=parent['project_closure'];require(parent['formal_acceptance'] is True and len(catalog)==count,'Incomplete accepted membership')
    originals={row['module']:row for row in original_barriers};require(len(originals)==len(original_barriers),'Duplicate inherited barrier')
    require(set(originals)<=set(catalog),'Inherited barrier outside accepted parent')
    modes={}
    for row in mode_records:
        visible={k:row[k] for k in ('owner','mode','protocol','marker','result','command','process_return','local_inputs','log','object','identity') if k in row}
        modes.setdefault(row['owner'],[]).append(visible)
    return [{'module':owner,'status':'accepted_membership_forbidden','forbidden_modes':list(MODES),
             'original_accepted_provenance':entry,'original_barrier':originals.get(owner),
             'visible_original_mode_records':modes.get(owner,[]),'old_data_forbidden':originals.get(owner,{}).get('status')=='old_normal_forbidden'}
            for owner,entry in sorted(catalog.items())]

def source_mapping(reader,module,logical,physical):
    reader.check(logical);reader.check(physical)
    require(same_bytes(logical,physical),'Graph logical source and compiled physical source differ')
    return {'module':module,'graph_logical_source':logical,'compiled_physical_source':physical,'same_original_bytes':True,'identities_interchanged':False}

def validate_pending(anchor,family,batch,parent,graph,loader):
    parser=loader.load('checkpoint');old=SimpleNamespace(evidence=loader.load('evidence'),controller=loader.load('controller'))
    r=parser.Readonly();fp=anchor['family'];bp=anchor['batch'];epoch=Path(bp['path']).parent
    require(r.read(fp)==family and {k:v for k,v in batch.items() if k!='_pre'}==r.read(bp),'Original family/batch bytes differ')
    require(batch['parent_context']==anchor['accepted_parent'] and r.read(anchor['accepted_parent'])==parent,'Parent transplant')
    require(batch['environment_sha256']==anchor['environment_sha256']==parser.env_sha(parser.env_for(epoch,family)),'Final environment differs')
    cohort=anchor['successful_pending_owner'];owner=cohort['owner'];failed=anchor['failed_normal_tuple'];failed_owner=failed['owner']
    require(batch['owners'][:2]==[owner,failed_owner] and owner not in parent['project_closure'],'Pending owner is not exact first unaccepted owner')
    require(anchor['unstarted_tail_owners']==batch['owners'][2:],'Tail owner selector differs')
    require([v['mode'] for v in cohort['modes']]==MODES,'Missing/duplicate original pending mode')
    mapping=source_mapping(r,owner,graph['entries'][owner]['source'],family['project_sources'][owner])
    require(cohort['source']==family['project_sources'][owner],'Pending source is not original COMMAND physical source')
    require(not (epoch/'state/BATCH_ACCEPTED.json').exists() and not list((epoch/'state').glob('POST*'))
            and not (epoch/'state/INTEGRITY_FAILED.json').exists() and not list((epoch/'accepted-contexts').iterdir()),'Old failed B8 already has POST/seal/context/sticky')
    delta={row['path']:row for row in anchor['namespace']['exact_epoch_file_pins']};require(len(delta)==len(anchor['namespace']['exact_epoch_file_pins']),'Duplicate epoch pin')
    require({str(p) for p in epoch.rglob('*') if p.is_file() or p.is_symlink()}==set(delta),'Unknown/missing original epoch file')
    for item in delta.values():r.check(item,'exact-old-epoch')
    batch={**batch,'_pre':anchor['global_pre_report']};history=[];pending={}
    expected_steps=set();records=[]
    for mode,saved in zip(MODES,cohort['modes']):
        directory=Path(saved['command']['path']).parent
        require(directory.parent==epoch/'steps'/owner/mode,'Pending attempt namespace transplant')
        require(list(directory.parent.iterdir())==[directory],'Multiple/unknown pending attempt')
        record=parser.attempt(r,old,family,fp,batch,bp,epoch,owner,mode,directory,saved['marker'],history,pending,parent['project_closure'],delta)
        require(record['successful'] and record['process']['mode_validation_error'] is None,'Original pending mode did not succeed')
        require(r.read(record['command'])['identity']==saved['identity'],'Original mode identity changed')
        for key in ('marker','result','command','log','local_inputs','process_return','object'):require(record[key]==saved[key],'Review original mode pin differs')
        history.append(record);records.append(record)
        if mode=='normal':pending[owner]=record
        expected_steps|={directory.parent.parent,directory.parent,directory,*directory.iterdir()}
    directory=Path(failed['command']['path']).parent
    require(directory==Path(failed['attempt']) and directory.parent==epoch/'steps'/failed_owner/'normal'
            and list(directory.parent.iterdir())==[directory],'Failed attempt namespace differs')
    failed_record=parser.attempt(r,old,family,fp,batch,bp,epoch,failed_owner,'normal',directory,None,history,pending,parent['project_closure'],delta)
    require(not failed_record['successful'] and type(failed_record['process']['exit_code']) is int and failed_record['process']['exit_code']==1
            and failed_record['process']['stop_reason'] is None and failed_record['object'] is None,'Exact failed exit1/noobject class changed')
    for key in ('command','result','process_return','log','local_inputs'):require(failed_record[key]==failed[key],'Failed five-file tuple changed')
    require(r.read(failed_record['command'])['identity']==failed['identity'] and failed['pending_receipt'] is None,'Failed identity/PENDING differs')
    require(failed['source']==family['project_sources'][failed_owner],'Failed physical source differs')
    expected_steps|={directory.parent.parent,directory.parent,directory,*directory.iterdir()}
    require(set((epoch/'steps').rglob('*'))==expected_steps and all(not p.is_symlink() for p in epoch.rglob('*')),'Foreign/unknown attempt directory')
    expected_dirs={epoch/p for p in ('helpers','state','steps','accepted-contexts','home','tmp')}
    expected_dirs|={p for p in expected_steps if p.is_dir()}
    require({p for p in epoch.rglob('*') if p.is_dir()}==expected_dirs,'Foreign empty directory')
    permanent=records[0]['object'];canonical=cohort['canonical_object'];r.check(permanent);r.check(canonical)
    require(cohort['normal_object']==permanent and same_bytes(permanent,canonical)
            and canonical['path']==str(Path(family['family_root'])/'objects'/Path(owner.replace('.','/')).with_suffix('.olean')),'Current normal artifact mismatch')
    expected_objects={v['selected_object']['path'] for v in parent['project_closure'].values()}|{v['path'] for v in family['native_artifacts']}|{canonical['path']}
    root=Path(family['family_root'])
    require({str(p) for p in (root/'objects').rglob('*') if p.is_file() or p.is_symlink()}==expected_objects,'Unexpected selected/pending object namespace')
    require(all(not Path(p).is_symlink() for p in expected_objects),'Object symlink')
    return {'records':records,'failed_record':failed_record,'typed_inventory':records[-1]['validated'],'source_mapping':mapping,
            'permanent_normal':permanent,'canonical_object':canonical,'exact_epoch_pins':list(delta.values()),
            'actual_local_pins':list(r.expected.values()),'old_post_exists':False,'old_seal_exists':False,'old_contexts':0,
            'pending_barrier':{'module':owner,'status':'original_pending_three_modes_forbidden','forbidden_modes':list(MODES),'original_mode_records':records,'source_mapping':mapping,'permanent_normal':permanent},
            'formal_acceptance':False}

def original_global_items(reader,family,fp,batch,bp):
    baseline=reader.read(family['base_global_inputs']);spec=reader.read(batch['global_inputs'])
    require(isinstance(baseline,list) and spec['family']==fp and spec['parent_context']==batch['parent_context'] and spec['baseline']==family['base_global_inputs'],'Original G selector roots differ')
    return unique(baseline+spec['prefix_inputs']+spec['batch_static']+[batch['global_inputs'],family['base_global_inputs'],fp,bp])

def validate_revision(reader,old,new,report):
    require(len(old['entries'])==len(new['entries'])==334 and old['topological_order']==new['topological_order'],'Not same334 graph')
    changes=[m for m in old['entries'] if old['entries'][m]!=new['entries'][m]]
    require(changes==['ImbalancedChen.P2OriginalSaving19Geometry06ScalableShapeArrays'],'Unexpected source change')
    owner=changes[0];before=old['entries'][owner];after=new['entries'][owner]
    require({k:v for k,v in before.items() if k!='source'}=={k:v for k,v in after.items() if k!='source'},'Source import/type selection changed')
    original=reader.raw(before['source']);replacement=reader.raw(after['source'])
    for suffix in ('h.2.2','h.2.2.1'):
        needle=('  simpa only [h.1] using '+suffix+'\n').encode();new=('  intro i\n  exact '+suffix+' ⟨i.val, h.1 ▸ i.isLt⟩\n').encode()
        require(original.count(needle)==1,'Unexpected old proof-body');original=original.replace(needle,new,1)
    require(original==replacement and report['unchanged_source_count']==333 and report['source_change']['replacement_count']==2,'Not exact two proof repairs')
    return owner

def check_code_lock(reader,lock_pin,loader):
    lock=reader.read(lock_pin);require(lock['modules']==loader.pins,'Executed source lock differs')
    for item in [lock['qualifier'],lock['python'],*lock['modules'].values()]:reader.check(item)
    return lock

def collect(contract,loader):
    require(contract['protocol']=='source_revision4_transport_verified_pending_prefix_v1','Wrong new qualification protocol')
    require(contract['expected_parent_count']==1641 and contract['expected_transport_count']==1642,'Wrong production membership counts')
    r=Reader();r.check(contract['_anchor']);roots=contract['roots']
    for name,sha in POLICY.items():require(roots[name]['sha256']==sha,'Unapproved external production root: '+name);r.check(roots[name])
    lock=check_code_lock(r,contract['source_lock'],loader)
    delivery=r.read(roots['source_delivery'])
    for item in delivery['members']:r.check(item)
    review=r.read(roots['review_anchor']);r.read(review['original_MCP_failed_run']);capsule=r.read(roots['published_capsule']);newgraph=r.read(roots['new_graph']);report=r.read(roots['revision_report'])
    require(capsule['formal_acceptance'] is True and capsule['accepted_project_union']==1641 and capsule['current_context']==review['accepted_parent'],'Published1641 authority differs')
    parser=loader.load('checkpoint')
    inspected=parser.inspect_endpoint(capsule['last_epoch'],capsule['current_context']['sha256'],capsule['last_seal']['sha256'],review['batch']['path'],review['batch']['sha256'])
    require(inspected['current']==capsule['current_context'] and inspected['seal']==capsule['last_seal'],'Readonly full parent inspection differs')
    parent=r.read(review['accepted_parent']);family=r.read(review['family']);batch=r.read(review['batch']);oldgraph=r.read(review['original_graph'])
    require(parent['project_closure']==inspected['new']['catalog'] and len(parent['native_artifacts'])==555,'Incomplete actual parent authority')
    require(parent['runtime']==family['runtime'] and parent['native_artifacts']==family['native_artifacts'] and parent['lean_path']==family['lean_path'],'Parent runtime/native/LEAN_PATH differs')
    validate_revision(r,oldgraph,newgraph,report)
    mappings=[]
    for owner,entry in parent['project_closure'].items():
        if owner in newgraph['entries']:mappings.append(source_mapping(r,owner,newgraph['entries'][owner]['source'],entry['source']))
    pending=validate_pending(review,family,batch,parent,newgraph,loader)
    pending_anchor=r.read(roots['pending_anchor']);failed_anchor=r.read(roots['failed_anchor'])
    require(len(pending_anchor['modes'])==3 and pending_anchor['old_family']==review['family'] and pending_anchor['old_graph']==review['original_graph'],'Pending anchor scope differs')
    require(pending_anchor['owner']==pending['pending_barrier']['module'] and pending_anchor['old_batch']==review['batch'] and pending_anchor['old_parent_context']==review['accepted_parent'],'Pending anchor ancestry differs')
    require(pending_anchor['permanent_normal']==pending['permanent_normal'] and pending_anchor['current_canonical']==pending['canonical_object'],'Pending artifact anchor differs')
    for row,original in zip(pending_anchor['modes'],pending['records']):
        for key in ('marker','result','command','process_return','local_inputs','log','object'):require(row[key]==original[key],'Candidate pending anchor differs')
    require(failed_anchor['old_family']==review['family'] and failed_anchor['old_graph']==review['original_graph'],'Failed anchor original graph/family differs')
    require(failed_anchor['old_batch']==review['batch'] and failed_anchor['new_graph']==roots['new_graph'] and failed_anchor['new_source']==newgraph['entries'][failed_anchor['module']]['source'],'Failed release source/graph bridge differs')
    failed=pending['failed_record']
    for key in ('command','result','process_return','log','local_inputs'):require(failed_anchor[key]==failed[key],'Failed anchor tuple differs')
    require(failed_anchor['old_identity']==r.read(failed['command'])['identity'] and failed_anchor['old_source']==family['project_sources'][failed['owner']]
            and failed_anchor['exit_code']==1 and failed_anchor['stop_reason'] is None and failed_anchor['object'] is None and failed_anchor['no_pending'] is True,'Invalid exact failed release')
    rows=original_global_items(r,family,review['family'],batch,review['batch']);pre=r.read(review['global_pre_report'])
    require(r.read(review['global_pre_anchor'])=={'snapshot':review['global_pre_report'],'formal_acceptance':False},'Old PRE anchor differs')
    require(pre['purpose']=='PRE' and pre['family']==review['family'] and pre['batch']==review['batch'] and pre['global_inputs']==batch['global_inputs']
            and pre['matched'] is True and pre['mismatches']==[] and pre['files_checked']==len(rows) and pre['bytes_read']==sum(x['bytes'] for x in rows) and pre['actual_map_sha256']==digest(rows),'Original full G PRE coverage differs')
    for item in review['raw_inputs']+review['frozen_controls']+list(review['runtime'].values()):r.check(item)
    barrier_records=inspected['old']['records']+inspected['new']['records']
    barriers=membership_barriers(parent,1641,family['normal_barriers'],barrier_records)
    require(sum(x['old_data_forbidden'] for x in barriers)==2,'Lost restoredData no-normal barriers')
    inspected['namespace_check']()
    return {'schema':'p26_revision4_collected_parent_pending_v1','protocol':contract['protocol'],'contract':contract['_anchor'],'source_lock':contract['source_lock'],
      'roots':roots,'accepted_parent':review['accepted_parent'],'parent_catalog':parent['project_closure'],'native_artifacts':parent['native_artifacts'],
      'runtime':parent['runtime'],'lean_path':parent['lean_path'],'external_modules':family['external_modules'],'original_family':review['family'],'original_batch':review['batch'],
      'new_graph':roots['new_graph'],'source_mappings':mappings+[pending['source_mapping']],'pending':pending,'membership_barriers':barriers,
      'failed_release':{**failed_anchor,'revision_manifest':roots['revision_report'],'failed_anchor':roots['failed_anchor']},
      'old_global_selector':batch['global_inputs'],'old_global_pre':review['global_pre_report'],'old_global_expected':{'files':len(rows),'bytes':sum(x['bytes'] for x in rows),'map_sha256':digest(rows)},
      'raw_inputs':review['raw_inputs'],'environment_lock':review['environment_lock'],'observed_metadata_pins':list(r.expected.values()),
      'qualification_environment_sha256':hashlib.sha256(json.dumps(contract['qualification_env'],sort_keys=True,separators=(',',':')).encode()).hexdigest(),
      'fresh_global_readback_performed':False,'executor_calls':0,'Lean_commands':0,'formal_acceptance':False,'P2_6_complete':False}
