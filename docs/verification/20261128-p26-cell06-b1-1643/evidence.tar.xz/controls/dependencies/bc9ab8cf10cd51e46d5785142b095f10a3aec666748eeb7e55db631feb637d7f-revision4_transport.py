"""Fresh full original-G readback and physical transport; zero proof execution."""
from pathlib import Path
import os, re, time
from revision4_core import *
from revision4_collect import collect, original_global_items

PURPOSE='PENDING_PREFIX_QUALIFICATION_OLD_G_CURRENT'

def fresh_snapshot(rows,expected,identity,hash_file=pin):
    rows=unique(rows)
    require({'files':len(rows),'bytes':sum(x['bytes'] for x in rows),'map_sha256':digest(rows)}==expected,'Incomplete/altered original G selector')
    started=time.monotonic();actual=[];bad=[]
    for item in rows:
        try:
            value=hash_file(item['path']);actual.append(value)
            if value!=item:bad.append({'expected':item,'actual':value})
        except (OSError,RuntimeError) as exc:bad.append({'expected':item,'error':str(exc)})
    return {'schema':'p26_revision4_fresh_original_global_readback_v1','purpose':PURPOSE,'identity':identity,
            'files_attempted':len(rows),'files_hashed':len(actual),'bytes_read':sum(x['bytes'] for x in actual),
            'actual_map_sha256':digest(actual),'expected':expected,'matched':not bad,'mismatches':bad,
            'seconds':time.monotonic()-started,'observed_unix_ns':time.time_ns(),'old_POST_created':False,'formal_acceptance':False}

def copy_exact(item,target):
    valid_pin(item);target=safe_stage(Path(__file__).resolve().parent,target);require(not target.is_symlink(),'Copy target symlink');target.parent.mkdir(parents=True,exist_ok=True)
    h=hashlib.sha256();size=0
    with Path(item['path']).open('rb') as src,target.open('xb') as dst:
        for b in iter(lambda:src.read(1024*1024),b''):dst.write(b);h.update(b);size+=len(b)
        dst.flush();os.fsync(dst.fileno())
    require(size==item['bytes'] and h.hexdigest()==item['sha256'],'Copy input changed or mismatched')
    physical={**item,'path':str(target.absolute())};require(pin(target)==physical,'Copied bytes readback failed')
    require(Path(item['path']).stat().st_ino!=target.stat().st_ino or Path(item['path']).stat().st_dev!=target.stat().st_dev,'Copy must use independent inode')
    return {'logical':item,'physical':physical,'original_identity_preserved':True,'independent_inode':True}

def verify_copies(rows):
    for row in rows:
        require(pin(row['logical']['path'])==row['logical'] and pin(row['physical']['path'])==row['physical'] and same_bytes(row['logical'],row['physical']),'Source/copy postcheck mismatch')
        a=Path(row['logical']['path']).stat();b=Path(row['physical']['path']).stat();require((a.st_dev,a.st_ino)!=(b.st_dev,b.st_ino),'Transport became a hardlink')
    return {'files':len(rows),'source_and_copy_actual_bytes_matched':True,'independent_inodes':True}

def guarded(stage,fn):
    stage=safe_stage(Path(__file__).resolve().parent,stage);require(not (stage/'INTEGRITY_FAILED.json').exists(),'Sticky qualification failure cannot resume')
    try:return fn()
    except Exception as exc:
        if not (stage/'INTEGRITY_FAILED.json').exists():dump(stage/'INTEGRITY_FAILED.json',{'status':'QUALIFICATION_INTEGRITY_FAILED','reason':str(exc),'formal_acceptance':False,'P2_6_complete':False})
        raise

def qualified_namespace(stage,expected):
    stage=Path(stage);actual={str(p) for p in stage.rglob('*') if p.is_file() or p.is_symlink()}
    require(actual==set(expected) and all(not Path(p).is_symlink() for p in actual),'Unknown/missing new transport artifact')
    directories={stage/'home',stage/'tmp'}
    for p in map(Path,expected):
        for parent in p.parents:
            if parent==stage:break
            directories.add(parent)
    require({p for p in stage.rglob('*') if p.is_dir()}=={p for p in directories if p.exists()},'Unknown/missing transport directory')

def external_namespace(reader,lock_pin):
    lock=reader.read(lock_pin);root=Path(lock['mathlib_root']);git=root/'.git'
    if git.is_file():
        text=git.read_text().strip();require(text.startswith('gitdir: '),'Malformed gitdir');git=(root/text[8:]).resolve()
    head=git/'HEAD';headpin=pin(head);reader.check(headpin);value=head.read_text().strip()
    if value.startswith('ref: '):
        name=value[5:];require(name.startswith('refs/') and '..' not in Path(name).parts,'Unsafe Git ref');p=git/name
        if p.is_file():reader.check(pin(p));value=p.read_text().strip()
        else:
            packed=git/'packed-refs';reader.check(pin(packed));matches=[line.split(' ')[0] for line in packed.read_text().splitlines() if line and not line.startswith(('#','^')) and line.split(' ')[-1]==name]
            require(len(matches)==1,'Git ref not uniquely resolved');value=matches[0]
    require(re.fullmatch('[0-9a-f]{40}',value) is not None and value==lock['mathlib_commit'],'Locked Mathlib commit changed')
    roots=[Path(v) for v in lock['lean_path_tail']]+[Path(lock['sysroot'])/'lib'];files=set()
    locked_files=set(lock['active_search_files'])
    for root in roots:
        require(root.is_dir(),'Missing locked external root')
        for parent in (root,*root.parents):
            require(not parent.is_symlink(),'Unpermitted directory symlink in external root path')
        for path in root.rglob('*'):
            if path.is_symlink():
                require(path.exists() and path.is_file(),'Unpermitted directory or dangling external symlink')
                require(str(path.absolute()) in locked_files,'Unknown external file symlink')
            if path.is_file():files.add(path.absolute())
    # The immutable original environment lock was produced by sorted(Path), not sorted(str).
    require(list(map(str,sorted(files)))==lock['active_search_files'],'External loadable/runtime namespace changed')
    return {'files':len(files),'mathlib_commit':value,'namespace_matches_lock':True,'subprocess_calls':0}

def transport_files(collected,graph,stage):
    stage=Path(stage);copies=[];targets={};catalog={}
    def cp(item,target,role):
        target=str(Path(target).absolute())
        if target in targets:
            row=targets[target];require(same_bytes(row['logical'],item),'Conflicting copy target');return row['physical']
        row=copy_exact(item,target);row['role']=role;copies.append(row);targets[target]=row;return row['physical']
    def path(owner,folder,suffix):
        require(re.fullmatch(r'ImbalancedChen(?:\.[A-Za-z0-9_]+)+',owner) is not None,'Unsafe module name')
        return stage/folder/Path(owner.replace('.','/')).with_suffix(suffix)
    for owner,entry in sorted(collected['parent_catalog'].items()):
        source=cp(entry['source'],path(owner,'project','.lean'),'formal-parent-source');obj=cp(entry['selected_object'],path(owner,'objects','.olean'),'formal-parent-object')
        catalog[owner]={**entry,'source':source,'selected_object':obj,'transport_origin':'accepted_membership_samebytes_transport','original_accepted_entry':entry}
    pending=collected['pending'];owner=pending['pending_barrier']['module']
    source=cp(pending['source_mapping']['compiled_physical_source'],path(owner,'project','.lean'),'original-pending-compiled-source')
    obj=cp(pending['permanent_normal'],path(owner,'objects','.olean'),'qualified-pending-selected-object')
    require(owner not in catalog,'Pending owner was already accepted')
    catalog[owner]={'source':source,'selected_object':obj,'origin':'transported_original_three_modes_after_fresh_qualification','original_mode_records':pending['records'],'source_mapping':pending['source_mapping'],'original_permanent_normal':pending['permanent_normal']}
    for owner,row in graph['entries'].items():
        if owner in catalog:require(same_bytes(row['source'],catalog[owner]['source']),'Graph/accepted copy source mismatch')
        else:cp(row['source'],path(owner,'project','.lean'),'frozen-graph-source-candidate')
    old_objects=Path(collected['lean_path'].split(':')[0]);native=[]
    for item in collected['native_artifacts']:
        relative=Path(item['path']).relative_to(old_objects);require('..' not in relative.parts,'Unsafe native relative path');native.append(cp(item,stage/'objects'/relative,'qualified-native'))
    old_epoch=Path(collected['original_batch']['path']).parent
    for item in pending['exact_epoch_pins']:
        relative=Path(item['path']).relative_to(old_epoch);cp(item,stage/'evidence/old8p'/relative,'original-unsealed-epoch-evidence')
    for item in collected['raw_inputs']:cp(item,stage/'raw'/Path(item['path']).name,'original-JSON-copy')
    return catalog,native,copies

def qualify(contract,collected_pin,loader,stage,collector=collect):
    stage=Path(stage);reader=Reader();stored=reader.read(collected_pin)
    require(stored['contract']==contract['_anchor'] and stored['source_lock']==contract['source_lock'],'Collected certificate belongs to another contract')
    require(Path(collected_pin['path'])==stage/'COLLECTED.json','Collected pin path transplant')
    require(not (stage/'QUALIFICATION_STARTED.json').exists(),'Same-stage qualification retry/resume not implemented; preserve output and use new explicit contract')
    def action():
        process=ProcessGuard()
        with process,WriteGuard(stage):
            started=dump(stage/'QUALIFICATION_STARTED.json',{'contract':contract['_anchor'],'source_lock':contract['source_lock'],'collected':collected_pin,'executor_calls':0,'formal_acceptance':False})
            before=collector(contract,loader);require(before==stored,'Collected authority/pending inputs changed before qualification')
            for item in before['pending']['actual_local_pins']+before['observed_metadata_pins']:reader.check(item,fresh=True)
            dpre=dump(stage/'D_PRE.json',{'contract':contract['_anchor'],'pins':unique(before['pending']['actual_local_pins']),'actual_matched':True,'executor_calls':0,'formal_acceptance':False})
            family=reader.read(before['original_family']);batch=reader.read(before['original_batch']);graph=reader.read(before['new_graph'])
            external_pre=external_namespace(reader,before['environment_lock'])
            catalog,native,copies=transport_files(before,graph,stage)
            copy_manifest=dump(stage/'COPY_MAP.json',copies)
            rows=original_global_items(reader,family,before['original_family'],batch,before['original_batch'])
            qualifier_inputs=dump(stage/'QUALIFIER_INPUTS.json',{'contract':contract['_anchor'],'pins':unique(reader.expected.values()),'scope':'Exact qualifier metadata/runtime/code/git inputs, independent from full original G selector','formal_acceptance':False})
            reader.check(qualifier_inputs,fresh=True)
            snapshot=fresh_snapshot(rows,before['old_global_expected'],{'contract':contract['_anchor'],'old_family':before['original_family'],'old_batch':before['original_batch'],'old_pre':before['old_global_pre'],'original_selector':before['old_global_selector']})
            snapshot_pin=dump(stage/'FRESH_ORIGINAL_G_CURRENT.json',snapshot);require(snapshot['matched'],'Fresh complete original G current mismatch')
            copy_result=verify_copies(copies)
            after=collector(contract,loader);require(after==before,'Parent/pending authority changed during qualification')
            for item in after['pending']['actual_local_pins']+after['observed_metadata_pins']:reader.check(item,fresh=True)
            require(external_namespace(reader,before['environment_lock'])==external_pre,'External namespace changed during qualification')
            reader.post();copy_result=verify_copies(copies)
            post=dump(stage/'D_AND_COPY_POST.json',{'contract':contract['_anchor'],'actual_D_matched':True,'metadata_input_post_matched':True,'qualifier_inputs':qualifier_inputs,'copy_readback':copy_result,'external_namespace':external_pre,'executor_calls':0,'formal_acceptance':False})
            barriers=before['membership_barriers']+[before['pending']['pending_barrier']]
            barriers_pin=dump(stage/'ALL_MODE_BARRIERS.json',barriers);failure_pin=dump(stage/'EXACT_FAILED_RELEASE.json',before['failed_release'])
            expected={str(stage/n) for n in ['COLLECTED.json','QUALIFICATION_STARTED.json','D_PRE.json','COPY_MAP.json','FRESH_ORIGINAL_G_CURRENT.json','D_AND_COPY_POST.json','ALL_MODE_BARRIERS.json','EXACT_FAILED_RELEASE.json','QUALIFIER_INPUTS.json','OUTPUTS_POST.json']}
            metadata=[collected_pin,started,dpre,copy_manifest,snapshot_pin,qualifier_inputs,post,barriers_pin,failure_pin]
            for item in metadata:reader.check(item,fresh=True)
            outputs_post=dump(stage/'OUTPUTS_POST.json',{'metadata_pins':metadata,'physical_copies':[row['physical'] for row in copies],'all_actual_bytes_matched':True,'formal_acceptance':False})
            reader.check(outputs_post,fresh=True)
            expected|={row['physical']['path'] for row in copies};qualified_namespace(stage,expected)
            require(len(catalog)==contract['expected_transport_count'] and len(barriers)==len(catalog) and process.attempts==0,'Incomplete transported closure/barrier or process attempt')
            seal=dump(stage/'VERIFIED_PENDING_PREFIX_CERTIFICATE.json',{'schema':'p26_revision4_verified_pending_prefix_v1','protocol':contract['protocol'],'contract':contract['_anchor'],'source_lock':contract['source_lock'],'accepted_parent':before['accepted_parent'],
                'original_family':before['original_family'],'original_unsealed_batch':before['original_batch'],'old_POST_exists':False,'old_seal_exists':False,'original_mode_records':before['pending']['records'],
                'qualification_started':started,'D_PRE':dpre,'fresh_original_G_current':snapshot_pin,'D_and_copy_POST':post,'copy_map':copy_manifest,'all_mode_barriers':barriers_pin,'exact_failed_release':failure_pin,
                'outputs_post':outputs_post,'qualification_environment_sha256':before['qualification_environment_sha256'],'accepted_parent_count':contract['expected_parent_count'],'transported_count':len(catalog),'proof_modes_repeated':0,'executor_calls':0,'Lean_commands':0,'formal_acceptance':True,'P2_6_complete':False})
            context=dump(stage/'CURRENT_ACCEPTED_CONTEXT.json',{'schema':'p26_revision4_transported1642_context_v1','protocol':contract['protocol'],'contract':contract['_anchor'],'source_lock':contract['source_lock'],'qualification':seal,'qualification_environment_sha256':before['qualification_environment_sha256'],'accepted_parent':before['accepted_parent'],
                'project_closure':catalog,'native_artifacts':native,'runtime':before['runtime'],'lean_path':str(stage/'objects')+':'+':'.join(before['lean_path'].split(':')[1:]),'external_modules':before['external_modules'],
                'new_graph':before['new_graph'],'source_mappings':before['source_mappings'],'all_mode_barriers':barriers_pin,'failed_release':failure_pin,'original_pending_modes_remain_original_contract':True,
                'global_validation_scope':'new_qualification_current_original_global_readback_and_exact_D','scope':'Formal parent membership plus original three-mode pending owner accepted only through new fresh qualification; old failed B8 remains unaccepted.',
                'proof_modes_repeated':0,'executor_calls':0,'Lean_commands':0,'formal_acceptance':True,'Cell06_integral_complete':False,'P2_6_complete':False})
            # Read back final artifacts and confirm exact output namespace. No work follows acceptance except checks.
            expected|={seal['path'],context['path']};qualified_namespace(stage,expected);reader.check(seal,fresh=True);reader.check(context,fresh=True)
            return context
    return guarded(stage,action)
