import os,sys,pathlib,json,hashlib,subprocess,signal,time,datetime,uuid,re,shutil,importlib.util,tomllib,gzip,traceback
P=pathlib.Path
INPUTS=[{"module":"ImbalancedChen.P2FiniteMarkedGamma5FrozenConstants","blob":"2bd068f48afb9d7f083491bcb0f056692283d8f2","source":"import Mathlib.Data.Real.Archimedean\nimport Mathlib.Tactic.Positivity\n\n/-!\nSOURCE ONLY / UNCOMPILED / ZERO NEW FORMAL CREDIT.\n\nMechanical relocation of the original frozen-history constants and the\noriginal source-rank definition. Every fully qualified name and defining\nexpression is unchanged. Select the recorded owner postimages whenever\nthe original history modules are in the same import closure.\n\nThe cutoff is fixed before the scale or source occurrence. No numerical\nevaluation of its reciprocal or of the resulting rank is performed.\n-/\nnamespace ImbalancedChen.Part5OriginalH430FrozenRootRefinement\nnoncomputable section\n\ndef frozenResidualFloor : ℝ := (11 / 384) / (101 : ℝ)^440\ndef frozenLeafCutoffFloor : ℝ := frozenResidualFloor / 6\n\ntheorem frozenLeafCutoffFloor_pos : 0 < frozenLeafCutoffFloor := by\n  unfold frozenLeafCutoffFloor frozenResidualFloor\n  positivity\n\nend\nend ImbalancedChen.Part5OriginalH430FrozenRootRefinement\n\nnamespace ImbalancedChen.P2FiniteMarkedGamma5ActualRank\nnoncomputable section\nopen Part5OriginalH430FrozenRootRefinement\n\n/-- Fixed by the existing frozen-history cutoff before N or any source\noccurrence is chosen. The number 440 is a depth budget, not this rank. -/\ndef frozenSourceRankBound : ℕ := ⌊frozenLeafCutoffFloor⁻¹⌋₊\n\nend\nend ImbalancedChen.P2FiniteMarkedGamma5ActualRank\n","sha256":"fb5cb2655a7907efb595a5e51ec87d1f3f0ce846316e65564e0e1a1a2e0ba093"},{"module":"ImbalancedChen.P2FiniteMarkedGamma5RadialRoughMass","blob":"b2919a1dab907504bca7d32beeaa85dc803678e5","source":"import ImbalancedChen.P2FiniteMarkedGamma5FrozenConstants\nimport MathlibNt.SieveTheory.LiLiuPrereqBuchstabUniformFixedCompat\n\n/-!\nSOURCE ONLY / UNCOMPILED / ZERO NEW FORMAL CREDIT.\n\nThe existing radial endpoint argument at the actual frozen-history\ncutoff exponent divided by two. The unrestricted finite-band theorem is\nimported from the already supplied FixedCompat module. No Buchstab or PNT\nestimate is re-proved here. The band index is a fixed symbolic natural\nnumber, chosen before N, with no cap of 100.\n\nThe absolute physical shell is measured in M/N. Its width is fixed while\nN tends to infinity, as required by the 1106 positive outer-approximation\nargument. An exponent-coordinate measure-zero statement is not used.\n-/\nnamespace ImbalancedChen.P2FiniteMarkedGamma5RadialRoughMass\nnoncomputable section\nopen Filter Finset Real LiLiuPrereqBuchstab\nopen Part5OriginalH430FrozenRootRefinement\nopen scoped Classical Topology BigOperators\n\ndef cutExponent : ℝ := frozenLeafCutoffFloor / 2\ndef cut (N : ℕ) : ℝ := (N : ℝ) ^ cutExponent\ndef norm (N : ℕ) : ℝ := log (N : ℝ) / (N : ℝ)\ndef shell (N : ℕ) (b c : ℝ) : Finset ℕ :=\n  roughNumbers (c * (N : ℝ)) (cut N) \\ roughNumbers (b * (N : ℝ)) (cut N)\n\ntheorem cutExponent_pos : 0 < cutExponent :=\n  half_pos frozenLeafCutoffFloor_pos\n\ntheorem cutExponent_lt_one : cutExponent < 1 := by\n  have hpow : (1 : ℝ) ≤ (101 : ℝ) ^ 440 := one_le_pow₀ (by norm_num)\n  have hres : frozenResidualFloor ≤ 11 / 384 := by\n    unfold frozenResidualFloor\n    exact div_le_self (by norm_num) hpow\n  unfold cutExponent frozenLeafCutoffFloor\n  linarith only [hres]\n\ntheorem one_le_inv_cutExponent : 1 ≤ cutExponent⁻¹ := by\n  simpa only [one_div] using (one_le_div cutExponent_pos).mpr cutExponent_lt_one.le\n\ntheorem cut_tendsto : Tendsto cut atTop atTop :=\n  (tendsto_rpow_atTop cutExponent_pos).comp tendsto_natCast_atTop_atTop\n\nprivate def bandRank : ℕ := Nat.ceil cutExponent⁻¹ + 1\n\nprivate theorem one_lt_cutExponent_mul_bandRank :\n    1 < cutExponent * (bandRank : ℝ) := by\n  have hr : cutExponent⁻¹ < (bandRank : ℝ) := by\n    dsimp only [bandRank]\n    rw [Nat.cast_add, Nat.cast_one]\n    linarith only [Nat.le_ceil cutExponent⁻¹]\n  have hh := mul_lt_mul_of_pos_left hr cutExponent_pos\n  simpa only [mul_inv_cancel₀ cutExponent_pos.ne'] using hh\n\nprivate theorem cut_div_N :\n    Tendsto (fun N : ℕ => cut N / (N : ℝ)) atTop (𝓝 0) := by\n  apply ((tendsto_rpow_neg_atTop (sub_pos.mpr cutExponent_lt_one)).comp\n    tendsto_natCast_atTop_atTop).congr'\n  filter_upwards [eventually_gt_atTop (0 : ℕ)] with N hN\n  have h0 : (0 : ℝ) < N := Nat.cast_pos.mpr hN\n  change (N : ℝ) ^ (-(1 - cutExponent)) = (N : ℝ) ^ cutExponent / (N : ℝ)\n  rw [show -(1 - cutExponent) = cutExponent - 1 by ring, rpow_sub h0, rpow_one]\n\nprivate theorem parameters {c : ℝ} (hc : 0 < c) :\n    Tendsto (fun N : ℕ => log (c * (N : ℝ)) / log (cut N))\n      atTop (𝓝 cutExponent⁻¹) := by\n  have hlog := Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop\n  have hsmall : Tendsto (fun N : ℕ => (cutExponent⁻¹ * log c) / log (N : ℝ))\n      atTop (𝓝 0) := tendsto_const_nhds.div_atTop hlog\n  have hh := hsmall.const_add cutExponent⁻¹\n  rw [add_zero] at hh\n  apply hh.congr'\n  filter_upwards [eventually_gt_atTop (1 : ℕ)] with N hN\n  have hNr : (1 : ℝ) < N := by exact_mod_cast hN\n  have h0 := zero_lt_one.trans hNr\n  simp only [cut, log_mul hc.ne' h0.ne', log_rpow h0]\n  field_simp [cutExponent_pos.ne', (log_pos hNr).ne'] <;> ring\n\n/-- Actual rough-integer endpoint, including its full absolute error.\nThe fixed band may be as large as the original cutoff requires. -/\ntheorem endpoint {c : ℝ} (hc : 0 < c) :\n    Tendsto (fun N : ℕ => norm N * (roughCount (c * (N : ℝ)) (cut N) : ℝ))\n      atTop (𝓝 (cutExponent⁻¹ * c * buchstab cutExponent⁻¹)) := by\n  let C := buchstabBandConstant bandRank\n  let main := fun N : ℕ =>\n    cutExponent⁻¹ * c * buchstab (log (c * (N : ℝ)) / log (cut N))\n  let error := fun N : ℕ =>\n    (cutExponent⁻¹ * C) * (c * buchstabRemainder (cut N) + cut N / (N : ℝ))\n  let X := fun N : ℕ => norm N * (roughCount (c * (N : ℝ)) (cut N) : ℝ)\n  have hmain : Tendsto main atTop (𝓝 (cutExponent⁻¹ * c * buchstab cutExponent⁻¹)) :=\n    ((continuous_buchstab.tendsto cutExponent⁻¹).comp (parameters hc)).const_mul _\n  have herror : Tendsto error atTop (𝓝 0) := by\n    simpa only [mul_zero, zero_add] using\n      ((((tendsto_buchstabRemainder.comp cut_tendsto).const_mul c).add cut_div_N).const_mul\n        (cutExponent⁻¹ * C))\n  have hpow := (tendsto_rpow_atTop\n    (sub_pos.mpr one_lt_cutExponent_mul_bandRank)).comp tendsto_natCast_atTop_atTop\n  have hb : ∀ᶠ N : ℕ in atTop, |X N - main N| ≤ error N := by\n    filter_upwards [eventually_gt_atTop (1 : ℕ),\n      cut_tendsto.eventually_ge_atTop primeErrorStart,\n      cut_div_N.eventually (gt_mem_nhds hc), hpow.eventually_ge_atTop c]\n      with N hN hstart hlo hhi\n    have hNr : (1 : ℝ) < N := by exact_mod_cast hN\n    have h0 := zero_lt_one.trans hNr\n    have hL := log_pos hNr\n    have hlogcut : log (cut N) = cutExponent * log (N : ℝ) := log_rpow h0 _\n    have hhigh : c * (N : ℝ) ≤ cut N ^ bandRank := by\n      have hh := mul_le_mul_of_nonneg_right hhi h0.le\n      calc\n        _ ≤ (N : ℝ) ^ (cutExponent * (bandRank : ℝ) - 1) * (N : ℝ) := hh\n        _ = (N : ℝ) ^ ((cutExponent * (bandRank : ℝ) - 1) + 1) := by\n          rw [rpow_add h0, rpow_one]\n        _ = cut N ^ bandRank := by\n          rw [show (cutExponent * (bandRank : ℝ) - 1) + 1 =\n            cutExponent * (bandRank : ℝ) by ring, rpow_mul h0.le, rpow_natCast] <;> rfl\n    have hlow : cut N < c * (N : ℝ) := (div_lt_iff₀ h0).mp hlo\n    have hm := roughCount_buchstab_band_error_unrestricted bandRank hstart hlow.le hhigh\n    have hnorm : 0 ≤ norm N := div_nonneg hL.le h0.le\n    have heq : X N - main N = norm N *\n        ((roughCount (c * (N : ℝ)) (cut N) : ℝ) -\n          (c * (N : ℝ)) * buchstab (log (c * (N : ℝ)) / log (cut N)) / log (cut N)) := by\n      dsimp only [X, main, norm]\n      rw [hlogcut]\n      field_simp [cutExponent_pos.ne', h0.ne', hL.ne'] <;> ring\n    rw [heq, abs_mul, abs_of_nonneg hnorm]\n    apply (mul_le_mul_of_nonneg_left hm hnorm).trans_eq\n    dsimp only [norm, error, C]\n    rw [hlogcut]\n    field_simp [cutExponent_pos.ne', h0.ne', hL.ne'] <;> ring\n  apply tendsto_of_tendsto_of_tendsto_of_le_of_le'\n    (by simpa only [sub_zero] using hmain.sub herror)\n    (by simpa only [add_zero] using hmain.add herror)\n  · filter_upwards [hb] with N hN\n    linarith only [(abs_le.mp hN).1]\n  · filter_upwards [hb] with N hN\n    linarith only [(abs_le.mp hN).2]\n\ntheorem mem_shell {N M : ℕ} {b c : ℝ} :\n    M ∈ shell N b c ↔ 0 < M ∧ b * (N : ℝ) < (M : ℝ) ∧\n      (M : ℝ) ≤ c * (N : ℝ) ∧ Rough (cut N) M := by\n  simp only [shell, mem_sdiff, mem_roughNumbers]\n  constructor\n  · rintro ⟨⟨hM, hhi, hr⟩, he⟩\n    exact ⟨hM, lt_of_not_ge (fun h => he ⟨hM, h, hr⟩), hhi, hr⟩\n  · rintro ⟨hM, hlo, hhi, hr⟩\n    exact ⟨⟨hM, hhi, hr⟩, fun h => (not_le_of_gt hlo) h.2.1⟩\n\ntheorem shell_limit {b c : ℝ} (hb : 0 < b) (hbc : b ≤ c) :\n    Tendsto (fun N : ℕ => norm N * ((shell N b c).card : ℝ)) atTop\n      (𝓝 (cutExponent⁻¹ * (c - b) * buchstab cutExponent⁻¹)) := by\n  have h := (endpoint (hb.trans_le hbc)).sub (endpoint hb)\n  have he : cutExponent⁻¹ * c * buchstab cutExponent⁻¹ -\n      cutExponent⁻¹ * b * buchstab cutExponent⁻¹ =\n      cutExponent⁻¹ * (c - b) * buchstab cutExponent⁻¹ := by ring\n  rw [he] at h\n  apply h.congr'\n  filter_upwards [] with N\n  have hs : roughNumbers (b * (N : ℝ)) (cut N) ⊆\n      roughNumbers (c * (N : ℝ)) (cut N) := by\n    intro m hm\n    obtain ⟨hm0, hmle, hr⟩ := mem_roughNumbers.mp hm\n    exact mem_roughNumbers.mpr ⟨hm0,\n      hmle.trans (mul_le_mul_of_nonneg_right hbc (Nat.cast_nonneg N)), hr⟩\n  have hh := card_sdiff_add_card_eq_card hs\n  have hcast : ((shell N b c).card : ℝ) + (roughCount (b * (N : ℝ)) (cut N) : ℝ) =\n      (roughCount (c * (N : ℝ)) (cut N) : ℝ) := by exact_mod_cast hh\n  dsimp only\n  rw [← hcast]\n  ring\n\n/-- Nonzero original profile coordinates are > N^a/2. Eventually that\nsame floor is above N^(a/2); no extra positive-exponent assumption is\nintroduced for an actual source. -/\ntheorem eventually_cut_le_half_floor :\n    ∀ᶠ N : ℕ in atTop, cut N ≤ (N : ℝ) ^ frozenLeafCutoffFloor / 2 := by\n  filter_upwards [cut_tendsto.eventually_ge_atTop 2,\n    eventually_gt_atTop (0 : ℕ)] with N hlarge hN\n  have hN0 : (0 : ℝ) < N := Nat.cast_pos.mpr hN\n  have hsq : (N : ℝ) ^ frozenLeafCutoffFloor = cut N ^ 2 := by\n    rw [show frozenLeafCutoffFloor = cutExponent * (2 : ℝ) by\n      unfold cutExponent; ring, rpow_mul hN0.le, rpow_natCast] <;> rfl\n  have hprod := mul_le_mul_of_nonneg_right hlarge\n    (show 0 ≤ cut N by linarith only [hlarge])\n  rw [← pow_two, ← hsq] at hprod\n  exact (le_div_iff₀ (by norm_num : (0 : ℝ) < 2)).mpr\n    (by simpa only [mul_comm] using hprod)\n\nend\nend ImbalancedChen.P2FiniteMarkedGamma5RadialRoughMass\n","sha256":"752622366765f200dba24e6a5bfadce2a3f7b14a78a45bd7475b5f59c38f8667"},{"module":"ImbalancedChen.P2MarkedPrimeDivisorFloorCore","blob":"1297496532c982a909709e3137e763fc86d1185c","source":"import Mathlib.Data.Nat.Prime.Basic\nimport Mathlib.Data.Real.Basic\nimport Mathlib.Algebra.BigOperators.Group.List.Basic\n\n/-!\nSOURCE ONLY / UNCOMPILED / ZERO NEW FORMAL CREDIT.\n\nThe existing prime-divisor floor lemma, relocated from the classical\nfixed-clamp geometry owner without changing its statement or fully\nqualified name. Only the two list-membership proof terms are expressed\nwith simp. This supplies no new counting or analytic estimate.\n-/\nnamespace ImbalancedChen.Part5OriginalH430ClassicalFixedClampGeometry\nnoncomputable section\n\ntheorem prime_divisor_floor {L : List ℕ} {z : ℝ}\n    (hL : ∀q∈L,q.Prime ∧ z≤(q:ℝ)) (v : ℕ) (hv : v.Prime) (hd : v∣L.prod) : z≤(v:ℝ) := by\n  induction L with\n  | nil => exact (hv.not_dvd_one hd).elim\n  | cons p L ih =>\n    rcases hv.dvd_mul.mp hd with h | h\n    · have hp := hL p (by simp)\n      rw [(Nat.prime_dvd_prime_iff_eq hv hp.1).mp h]\n      exact hp.2\n    · exact ih (fun q hq => hL q (by simp only [List.mem_cons]; exact Or.inr hq)) h\n\nend\nend ImbalancedChen.Part5OriginalH430ClassicalFixedClampGeometry\n","sha256":"ac91544adae2c2b3309d154a5f71aee7397d4eb7139a2c72812bf5bd435e7e75"}]
SUPPLY=P('/workspace/p29-native-supply-20261125')
MEMBER=P('/workspace/blue-member-build')
GUARD=P('/workspace/goldbach-formalization/docs/source-only/20261110-yellow-closure-10t/t01_remote_fifth_kernel/ci_runtime_guard.py')
RUNNER=P('/workspace/blue-build-tools/run_guarded.py')
OWNED=P('/workspace/blue-build-tools/validate_member_roots_owned.py')
PIN='leanprover/lean4:v4.33.0-rc1'
def sha(p):return hashlib.sha256(P(p).read_bytes()).hexdigest()
def stamp(p):
 s=P(p).stat();return [s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns]
def save(p,x):
 p=P(p);p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('x')as f:json.dump(x,f,indent=2);f.write('\n')
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
assert sha(GUARD)=='837f00360ca1364eb6adede88c05a72122acbbbbff2437c83026f2851836a877'
assert sha(RUNNER)=='c202e53a319d9f30ee78db1582f53fe2104872f4ee749e1e5cac7d3ad5cfb526'
assert sha(OWNED)=='ed4dc724deb5e2cb28cbd461014c59bed52c373f6b18613f07cf663e456d8201'
binding=SUPPLY/'supply-bindings/BINDING_RECEIPT.json'
assert binding.is_file(),'Native supply binding receipt not yet complete'
supply=json.loads(binding.read_text());assert supply['status']=='PASS_CURRENT_P1_EXISTING_NATIVE_SUPPLY',supply
for row in INPUTS:assert hashlib.sha256(row['source'].encode()).hexdigest()==row['sha256']
root=P('/workspace/p29-radial-20261125');out=P('/workspace/p29-radial-verification-20261125')
if root.exists()or out.exists():
 suffix=utc().replace(':','').replace('-','').split('.')[0]+'-'+uuid.uuid4().hex[:8]
 root=P(str(root)+'-'+suffix);out=P(str(out)+'-'+suffix)
root.mkdir();out.mkdir();(out/'driver.py').write_text(SOURCE_TEXT)
mods=[x['module']for x in INPUTS]
allowed_sources=set()
for row in INPUTS:
 p=root/(row['module'].replace('.','/')+'.lean');p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(row['source'].encode())
 allowed_sources.add(str(p.resolve()))
 save(out/'input-blobs'/(row['module']+'.json'),{'repository':'UyNewNas/goldbach-formalization','blob':row['blob'],'source_sha256':row['sha256'],'bytes':p.stat().st_size,'installed_path':str(p)})
old_toml=(MEMBER/'lakefile.toml').read_text()
old_config=tomllib.loads(old_toml)
manifest=json.loads((MEMBER/'lake-manifest.json').read_text())
assert any(x.get('name')=='ImbalancedChen'for x in old_config.get('lean_lib',[])), 'Expected original ImbalancedChen library configuration'
packages=[];mapping=[]
for rec in manifest['packages']:
 name=rec['name'];path=(MEMBER/'.lake/packages'/name).resolve()
 assert path.is_dir(),('Missing existing package',name,str(path))
 cfg=rec.get('configFile','lakefile.lean')
 assert (path/cfg).is_file(),('Missing package config',name,str(path/cfg))
 packages.append({'type':'path','name':name,'scope':rec.get('scope',''),'dir':str(path),'configFile':cfg,'manifestFile':rec.get('manifestFile','lake-manifest.json'),'inherited':False})
 mapping.append({'package':name,'old_manifest_entry':rec,'resolved_existing_path':str(path),'config_sha256':sha(path/cfg)})
assert any(x['name']=='goldbach'and x['dir']==str(MEMBER/'.lake/packages/goldbach')for x in packages),'Native provider path must be unchanged'
# Change only dependency location declarations; all original Lean/library options remain.
new_toml=re.sub(r'(?ms)^\[\[require\]\][^\n]*\n.*?(?=^\[|\Z)','',old_toml).rstrip()+'\n'
assert not tomllib.loads(new_toml).get('require'),'Unrecognized require syntax'
for rec in packages:new_toml+='\n[[require]]\nname = '+json.dumps(rec['name'])+'\npath = '+json.dumps(rec['dir'])+'\n'
new_config=tomllib.loads(new_toml)
assert {k:v for k,v in new_config.items()if k!='require'}=={k:v for k,v in old_config.items()if k!='require'}
(root/'lakefile.toml').write_text(new_toml)
new_manifest={**manifest,'packages':packages}
(root/'lake-manifest.json').write_text(json.dumps(new_manifest,indent=2)+'\n')
(root/'lean-toolchain').write_bytes((MEMBER/'lean-toolchain').read_bytes())
assert (root/'lean-toolchain').read_text().strip()==PIN
save(out/'CONFIGURATION_ADAPTATION.json',{'schema':'p29_isolated_same_options_absolute_existing_dependency_paths_v1','original_root':str(MEMBER),'new_root':str(root),'old_lakefile_sha256':sha(MEMBER/'lakefile.toml'),'new_lakefile_sha256':sha(root/'lakefile.toml'),'old_manifest_sha256':sha(MEMBER/'lake-manifest.json'),'new_manifest_sha256':sha(root/'lake-manifest.json'),'lean_and_library_options_byte_semantics_unchanged':True,'package_path_mapping':mapping,'native_cache_copied':False,'native_cache_rewritten':False,'mathlib_and_native_source_pins_changed':False})
for name in ['lakefile.toml','lake-manifest.json','lean-toolchain']:shutil.copy2(root/name,out/name)
config_before={str(root/name):sha(root/name)for name in ['lakefile.toml','lake-manifest.json','lean-toolchain']}
# Preserve the exact current imported-object bytes without a whole native-library hash scan.
partdata=json.loads((SUPPLY/'supply-bindings/IMPORT_PART_BINDINGS.json').read_text())['parts']
cache_before={}
for row in partdata:
 ident=row['identity'];p=ident['path'];st=stamp(p)
 if st!=row['current_stat_snapshot']:assert sha(p)==ident['sha256'],('Existing dependency changed',p)
 cache_before[p]=st
for p,rec in json.loads((SUPPLY/'SOURCE_AND_OUTPUTS_AFTER.json').read_text()).items():
 assert sha(p)==rec['sha256'];cache_before[p]=stamp(p)
save(out/'CONTEXT_BEFORE.json',{'modules':mods,'native_supply_receipt_path':str(binding),'native_supply_receipt_sha256':sha(binding),'dependency_parts':len(partdata),'config':config_before,'tool_sha256':{'guard':sha(GUARD),'runner':sha(RUNNER),'owned':sha(OWNED)}})
runtime_parent=root/'runtime';runtime_parent.mkdir()
runtime_evidence=out/'runtime-evidence'
base_env=os.environ.copy()
for k in ['LEAN_SYSROOT','LEAN','LEAN_AR','LEAN_CC','LAKE','LAKE_HOME','LAKE_OVERRIDE_LEAN','LEAN_PATH','LEAN_SRC_PATH','P0_CI_GUARD_STATE','P0_COMPILER_SLOT_HELD','P0_COMPILER_SLOT_FD','P0_COMPILER_SLOT_TOOL']:base_env.pop(k,None)
base_env.update(LEAN_NUM_THREADS='2',ELAN_TOOLCHAIN=PIN,ELAN_HOME='/workspace/.elan',RUNNER_TEMP=str(runtime_parent),LEAN_ACTION_DIR='/workspace/blue-build-tools/lean-action',GITHUB_ENV=str(out/'runtime.env'),GITHUB_PATH=str(out/'runtime.path'))
base_env['PATH']='/workspace/.elan/bin:'+base_env.get('PATH','')
setup_cmd=['python3',str(GUARD),'setup','--evidence',str(runtime_evidence)]
with (out/'runtime-setup.log').open('xb')as f:r=subprocess.run(setup_cmd,cwd=root,env=base_env,stdout=f,stderr=subprocess.STDOUT)
save(out/'runtime-setup-process.json',{'command':setup_cmd,'cwd':str(root),'exit_code':r.returncode,'log_sha256':sha(out/'runtime-setup.log')})
assert r.returncode==0,'Original runtime guard setup failed; see runtime-setup.log'
state_path=runtime_evidence/'state.json';state=json.loads(state_path.read_text());guardlog=P(state['log'])
runprefix=['python3',str(RUNNER),'--state',str(state_path)]
runs=[]
def stage(label,command,stdin=None,allow_sources=(),allow_audit=False,timeout=900):
 initial=guardlog.stat().st_size;pos=initial;pending=b'';rows=[];bad=[];started=utc();t0=time.monotonic();last=t0
 log=out/(label+'.log')
 with log.open('xb')as f:
  proc=subprocess.Popen(command,cwd=root,env=base_env,stdin=subprocess.PIPE if stdin is not None else None,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  if stdin is not None:proc.stdin.write(stdin);proc.stdin.close()
  while True:
   with guardlog.open('rb')as g:g.seek(pos);raw=g.read();pos+=len(raw)
   pending+=raw;lines=pending.split(b'\n');pending=lines.pop()
   for line in lines:
    if not line.strip():continue
    row=json.loads(line);rows.append(row)
    if row.get('tool')=='lean':
     args=row.get('input_args',[])
     if '--stdin'in args and not allow_audit:bad.append({'reason':'UNEXPECTED_STDIN_AUDIT','record':row})
     for a in args:
      if str(a).endswith('.lean'):
       q=P(a);q=q if q.is_absolute()else P(row['cwd'])/q
       if str(q.resolve())not in allow_sources and not(allow_audit and q.resolve().is_relative_to(out.resolve())):
        bad.append({'reason':'UNAUTHORIZED_SOURCE_REBUILD','record':row})
   code=proc.poll()
   if code is not None:break
   if bad or time.monotonic()-t0>timeout:
    os.killpg(proc.pid,signal.SIGTERM)
    try:proc.wait(timeout=10)
    except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
    code=96 if bad else 124;break
   if time.monotonic()-last>=30:
    print(json.dumps({'stage':label,'root':str(root),'elapsed_seconds':round(time.monotonic()-t0,1),'forbidden_source_calls':len(bad)}),flush=True);last=time.monotonic()
   time.sleep(.2)
 rec={'stage':label,'command':command,'cwd':str(root),'started_utc':started,'finished_utc':utc(),'exit_code':code,'guard_log_start':initial,'guard_log_end':pos,'guarded_commands':rows,'forbidden_source_calls':bad,'log_path':str(log),'log_sha256':sha(log)}
 if stdin is not None:rec['stdin_sha256']=hashlib.sha256(stdin).hexdigest()
 save(out/(label+'-process.json'),rec);runs.append(rec)
 print(json.dumps({'stage':label,'exit_code':code,'forbidden_source_calls':len(bad),'log_path':str(log)}),flush=True)
 if code:print(log.read_text()[-22000:],flush=True);raise RuntimeError('Gate failed: '+label)
 return rec
def source_outputs():
 result={}
 for row in INPUTS:
  rel=row['module'].replace('.','/')
  paths=[root/(rel+'.lean')]+[root/'.lake/build/lib/lean'/(rel+s)for s in ['.olean','.ilean','.trace']]+[root/'.lake/build/ir'/(rel+s)for s in ['.c','.setup.json']]
  for p in paths:result[str(p)]={'bytes':p.stat().st_size,'sha256':sha(p)}
 return result
try:
 stage('runtime-initial-audit',runprefix+['python3',str(GUARD),'audit','--state',str(state_path),'--probe'])
 shutil.copy2(runtime_evidence/'audit.json',out/'runtime-initial-audit.json')
 # Prove the borrowed dependency cache is already current in this isolated Lake context.
 deps=['MathlibNt.SieveTheory.LiLiuPrereqBuchstabUniformFixedCompat']
 for row in INPUTS:
  for m in re.findall(r'^import\s+(\S+)',row['source'],re.M):
   if not m.startswith('ImbalancedChen.')and m not in deps:deps.append(m)
 stage('dependency-stock-preflight',runprefix+['lake','--no-build','build',*['+'+m+':olean'for m in deps]])
 print(json.dumps({'stage':'begin_three_exact_new_modules','root':str(root),'evidence':str(out),'modules':mods}),flush=True)
 normal=stage('normal-build',runprefix+['lake','build',*['+'+m+':olean'for m in mods]],allow_sources=allowed_sources)
 production=source_outputs();save(out/'SOURCE_AND_OUTPUTS_AFTER_NORMAL.json',production)
 kernel=stage('named-kernel',runprefix+['lake','env','leanchecker','--verbose',*mods])
 replayed=[l.removeprefix('replaying ')for l in (out/'named-kernel.log').read_text().splitlines()if l.startswith('replaying ')]
 assert len(replayed)==len(set(replayed))==len(mods)and set(replayed)==set(mods)
 sys.dont_write_bytecode=True
 spec=importlib.util.spec_from_file_location('p29_original_owned_auditor',OWNED);lib=importlib.util.module_from_spec(spec);spec.loader.exec_module(lib)
 code=lib.make_audit_code(mods).encode();(out/'ModuleAudit.lean').write_bytes(code)
 audit=stage('full-owned',runprefix+['lake','env','lean','-DmaxRecDepth=100000','-DmaxHeartbeats=4000000','--stdin'],stdin=code,allow_audit=True)
 declarations,inventory,axioms=lib.read_audit((out/'full-owned.log').read_text(),mods,audit['exit_code'])
 save(out/'DECLARATION_TYPES_AXIOMS.json',declarations);save(out/'INVENTORY_NAME_SET_CHECK.json',inventory)
 stock=stage('final-stock',runprefix+['lake','--no-build','build',*['+'+m+':olean'for m in mods]])
 assert not any(r.get('tool')=='lean'and('--stdin'in r.get('input_args',[])or any(str(a).endswith('.lean')for a in r.get('input_args',[])))for r in stock['guarded_commands'])
 stage('runtime-final-audit',runprefix+['python3',str(GUARD),'audit','--state',str(state_path),'--probe','--require-source'])
 final=source_outputs();assert final==production
 assert {p:sha(p)for p in config_before}==config_before
 changed=[p for p,s in cache_before.items()if not P(p).is_file()or stamp(p)!=s]
 assert not changed,('Borrowed cache changed',changed[:20])
 assert sha(GUARD)=='837f00360ca1364eb6adede88c05a72122acbbbbff2437c83026f2851836a877'and sha(OWNED)=='ed4dc724deb5e2cb28cbd461014c59bed52c373f6b18613f07cf663e456d8201'
 save(out/'SOURCE_AND_OUTPUTS_AFTER.json',final)
 result={'schema':'p29_three_thin_modules_isolated_normal_stock_kernel_owned_v1','result':'PASS_THREE_EXACT_SOURCE_MODULES_NORMAL_STOCK_NAMED_KERNEL_FULL_OWNED','root':str(root),'evidence':str(out),'modules':mods,'inputs':[{k:v for k,v in row.items()if k!='source'}for row in INPUTS],'normal':normal,'kernel':kernel,'owned':audit,'stock':stock,'owned_declaration_counts':inventory['module_counts'],'owned_declarations':len(declarations),'observed_axioms':axioms,'full_owned_private_generated_ast_universes':True,'source_and_outputs_unchanged_after_normal':True,'borrowed_cache_parts_unchanged':len(cache_before),'runtime_policy':state['policy'],'native_supply_receipt_sha256':sha(binding),'all_import_replay_claim':False,'owner_scope':'Exact three new module sources; frozen constants and prime-divisor lemma retain their original FQN/statement, no manuscript endpoint or whole-history completion claim.'}
 save(out/'VALIDATION_RESULTS.json',result)
 print(json.dumps({k:result[k]for k in ['result','root','evidence','modules','owned_declaration_counts','owned_declarations','observed_axioms','borrowed_cache_parts_unchanged']}),flush=True)
except Exception as e:
 failure={'schema':'p29_three_module_gate_failure_v1','root':str(root),'evidence':str(out),'error':str(e),'traceback':traceback.format_exc(),'completed_stages':[x['stage']for x in runs],'borrowed_cache_changed':[p for p,s in cache_before.items()if not P(p).is_file()or stamp(p)!=s]}
 save(out/'FAILURE.json',failure)
 print(json.dumps(failure),flush=True)
 raise
