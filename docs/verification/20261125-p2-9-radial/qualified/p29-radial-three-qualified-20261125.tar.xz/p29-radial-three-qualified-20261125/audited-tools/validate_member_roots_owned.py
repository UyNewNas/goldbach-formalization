#!/usr/bin/env python3
"""Replay the ten built Member roots and export every owned constant.

No source build is invoked. Run only after the sole Member normal aggregate
has passed. Kernel replay is limited to the exact ten named root modules,
relative to their existing imports; this is not fresh all-import validation.
"""
from pathlib import Path
import argparse
import collections
import datetime
import fcntl
import hashlib
import json
import re
import subprocess
import time

PROJECT = Path('/workspace/blue-member-build')
MODULE_ROOT = PROJECT
ROOT = Path('/workspace/blue-member-aggregate-evidence')
ROOT_LIST = ROOT / 'PENDING_ROOTS.txt'
DEFAULT_OUT = ROOT / 'owned-validation'
CONTROLLER_LOCK = ROOT / 'owned-validation-controller.lock'
GUARD_STATE = Path('/workspace/blue-build-tools/member-runtime-evidence/state.json')
GUARD = ['python3', '/workspace/blue-build-tools/run_guarded.py', '--state', str(GUARD_STATE)]
FIXED_ROOTS = (
    'ImbalancedChen.Part5OriginalH430AllRootRejectedWindows',
    'ImbalancedChen.Part5OriginalH430AttachedUpperMember',
    'ImbalancedChen.Part5OriginalH430EnhancedMemberFactors',
    'ImbalancedChen.Part5OriginalH430EnhancedPositivePrices',
    'ImbalancedChen.Part5OriginalH430LowerRoughMember',
    'ImbalancedChen.Part5OriginalH430MemberAttachedPrimeCarrier',
    'ImbalancedChen.Part5OriginalH430PositiveHistoryErrors',
    'ImbalancedChen.Part5OriginalH430PresievedBoxCatalog',
    'ImbalancedChen.Part5OriginalH430RootTentOwnTheta',
    'ImbalancedChen.Part5OriginalH430RootTentScreen',
)


def digest(path):
    with path.open('rb') as source:
        value = hashlib.file_digest(source, 'sha256').hexdigest()
    return {'bytes': path.stat().st_size, 'sha256': value}


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def source_output_paths(modules):
    paths = []
    for module in modules:
        relative = module.replace('.', '/')
        paths.extend([MODULE_ROOT / (relative + '.lean'),
                      MODULE_ROOT / '.lake/build/lib/lean' / (relative + '.olean'),
                      MODULE_ROOT / '.lake/build/lib/lean' / (relative + '.ilean'),
                      MODULE_ROOT / '.lake/build/ir' / (relative + '.c'),
                      MODULE_ROOT / '.lake/build/ir' / (relative + '.setup.json'),
                      MODULE_ROOT / '.lake/build/lib/lean' / (relative + '.trace')])
    return paths


def context(modules):
    return {'modules': modules, 'cwd': str(PROJECT),
            'root_list': {'path': str(ROOT_LIST), **digest(ROOT_LIST)},
            'guard_state': {'path': str(GUARD_STATE), **digest(GUARD_STATE)},
            'configuration': {name: digest(PROJECT / name)
                              for name in ['lakefile.toml', 'lake-manifest.json', 'lean-toolchain']}}


def make_audit_code(modules):
    imports = '\n'.join('import ' + module for module in modules)
    names = ',\n    '.join('`' + module for module in modules)
    return imports + '\nimport Lean.Util.CollectAxioms\n\n' + r'''set_option pp.all true
set_option pp.universes true

open Lean Elab Command in
run_cmd do
  let env ← getEnv
  let modules := #[
    ''' + names + r''']
  let allowed := #[`propext, `Classical.choice, `Quot.sound]
  -- Cache this computed modules.map exactly once, outside the full constant fold.
  let moduleNames := env.header.moduleNames
  let selected := env.constants.fold (init := #[]) fun names name _ =>
    match env.getModuleIdxFor? name with
    | some idx => if modules.contains moduleNames[idx.toNat]! then names.push name else names
    | none => names
  let names := selected.qsort Name.lt
  let inventory := Json.mkObj [("names", toJson (names.map Name.toString))]
  liftIO <| IO.println s!"MEMBER_OWNED_NAMES {inventory.compress}"
  let mut counts : Array (Name × Nat) := modules.map (·, 0)
  for name in names do
    let some info := env.find? name | throwError "Missing inventoried declaration {name}"
    let some owner := env.getModuleIdxFor? name | throwError "Missing declaration owner {name}"
    let moduleName := moduleNames[owner.toNat]!
    unless modules.contains moduleName do
      throwError "Inventoried declaration owner changed: {name}"
    if info.isUnsafe then
      throwError "Unsafe declaration in the audited roots: {name}"
    if info.isAxiom then
      throwError "Unproved axiom declaration in the audited roots: {name}"
    let axioms ← collectAxioms name
    for ax in axioms do
      unless allowed.contains ax do
        throwError "Forbidden transitive axiom {ax} in {name}"
    let type ← liftTermElabM do
      return (← Meta.ppExpr info.type).pretty
    let kind := match info with
      | .thmInfo _ => "theorem"
      | .defnInfo _ => "definition"
      | .opaqueInfo _ => "opaque"
      | .quotInfo _ => "quotient"
      | .axiomInfo _ => "axiom"
      | .inductInfo _ => "inductive"
      | .ctorInfo _ => "constructor"
      | .recInfo _ => "recursor"
    let record := Json.mkObj [
      ("name", toJson name.toString),
      ("module", toJson moduleName.toString),
      ("kind", toJson kind),
      ("is_private", toJson (isPrivateName name)),
      ("type", toJson type),
      ("type_expression", toJson (reprStr info.type)),
      ("universe_parameters", toJson (info.levelParams.map Name.toString)),
      ("axioms", toJson (axioms.map Name.toString))]
    liftIO <| IO.println s!"MEMBER_OWNED_DECL {record.compress}"
    counts := counts.map fun (m, count) => (m, if m == moduleName then count + 1 else count)
  for (m, count) in counts do
    unless count > 0 do
      throwError "Audited root module has no owned declarations: {m}"
    let record := Json.mkObj [("module", toJson m.toString), ("count", toJson count)]
    liftIO <| IO.println s!"MEMBER_OWNED_MODULE {record.compress}"
  liftIO <| IO.println s!"MEMBER_OWNED_COUNT {names.size}"
'''


def run(command, directory, label, stdin=None):
    record = {'command': command, 'cwd': str(PROJECT),
              'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    if stdin is not None:
        record['stdin_sha256'] = hashlib.sha256(stdin).hexdigest()
    save(directory / (label + '-process.json'), record)
    started = time.monotonic()
    with (directory / (label + '.log')).open('xb') as output:
        result = subprocess.run(command, cwd=PROJECT, input=stdin,
                                stdout=output, stderr=subprocess.STDOUT)
    record.update(exit_code=result.returncode, elapsed_seconds=time.monotonic() - started,
                  finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  log_sha256=digest(directory / (label + '.log'))['sha256'])
    save(directory / (label + '-process.json'), record)
    print(json.dumps(record), flush=True)
    return record


def check_kernel(record, directory, modules):
    assert record['exit_code'] == 0
    assert record['command'] == GUARD + ['lake', 'env', 'leanchecker', '--verbose', *modules]
    assert record['cwd'] == str(PROJECT)
    assert digest(directory / 'kernel.log')['sha256'] == record['log_sha256']
    actual = [line.removeprefix('replaying ') for line in (directory / 'kernel.log').read_text().splitlines()
              if line.startswith('replaying ')]
    assert len(actual) == len(set(actual)) == len(modules) and set(actual) == set(modules)


def read_audit(raw, modules, actual_exit):
    def records(prefix):
        return [json.loads(line.removeprefix(prefix)) for line in raw.splitlines() if line.startswith(prefix)]
    inventories = records('MEMBER_OWNED_NAMES ')
    assert len(inventories) == 1
    names = inventories[0]['names']
    assert len(names) == len(set(names))
    declarations = records('MEMBER_OWNED_DECL ')
    counts = records('MEMBER_OWNED_MODULE ')
    totals = [int(line.removeprefix('MEMBER_OWNED_COUNT ')) for line in raw.splitlines()
              if line.startswith('MEMBER_OWNED_COUNT ')]
    assert len(totals) == 1 and totals[0] == len(names) == len(declarations)
    assert sorted(row['name'] for row in declarations) == sorted(names)
    observed = collections.Counter(row['module'] for row in declarations)
    assert set(observed) == set(modules) and len(counts) == len(modules)
    assert {row['module'] for row in counts} == set(modules)
    assert all(observed[row['module']] == row['count'] > 0 for row in counts)
    for row in declarations:
        assert isinstance(row['type'], str) and row['type']
        assert isinstance(row['type_expression'], str) and row['type_expression'].startswith('Lean.Expr.')
        assert isinstance(row['universe_parameters'], list)
        assert all(isinstance(x, str) for x in row['universe_parameters'])
        assert isinstance(row['is_private'], bool)
        for text in [row['type'], row['type_expression']]:
            assert '⋯' not in text and '...' not in text
        assert set(row['axioms']) <= {'propext', 'Classical.choice', 'Quot.sound'}
    axioms = sorted({ax for row in declarations for ax in row['axioms']})
    inventory = {'schema': 'member_ten_roots_complete_owned_inventory_v1',
                 'method': 'Full env.constants.fold plus exact getModuleIdxFor? owner; moduleNames computed once. No private/generated exclusion.',
                 'count': len(names), 'names': names,
                 'names_sha256': hashlib.sha256(('\n'.join(names) + '\n').encode()).hexdigest(),
                 'private_name_count': sum(row['is_private'] for row in declarations),
                 'module_counts': dict(observed), 'actual_audit_exit_code': actual_exit}
    return declarations, inventory, axioms


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, default=DEFAULT_OUT)
    parser.add_argument('--resume-audit', action='store_true',
                        help='Reuse an already successful exact kernel and unchanged context/snapshot after audit tooling failure; retain every failed attempt')
    parser.add_argument('modules', nargs='*', help='Optional exact same ten-root set; canonical file order is used')
    args = parser.parse_args()
    modules = [line.strip() for line in ROOT_LIST.read_text().splitlines() if line.strip()]
    assert tuple(modules) == FIXED_ROOTS and len(modules) == len(set(modules)) == 10
    assert all(re.fullmatch(r'ImbalancedChen\.[A-Za-z0-9_.]+', name) for name in modules)
    if args.modules:
        assert len(args.modules) == len(set(args.modules)) == 10 and set(args.modules) == set(modules)
    lock = CONTROLLER_LOCK.open('a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    if args.resume_audit:
        assert args.out.is_dir() and not (args.out / 'VALIDATION_RESULTS.json').exists()
    else:
        args.out.mkdir(parents=True, exist_ok=False)
    paths = source_output_paths(modules)
    before = {str(path): digest(path) for path in paths}
    before_context = context(modules)
    if args.resume_audit:
        assert before == json.loads((args.out / 'SOURCE_AND_OUTPUTS_BEFORE.json').read_text())
        assert before_context == json.loads((args.out / 'CONTEXT_BEFORE.json').read_text())
        kernel = json.loads((args.out / 'kernel-process.json').read_text())
    else:
        save(args.out / 'SOURCE_AND_OUTPUTS_BEFORE.json', before)
        save(args.out / 'CONTEXT_BEFORE.json', before_context)
        kernel = run(GUARD + ['lake', 'env', 'leanchecker', '--verbose', *modules], args.out, 'kernel')
    check_kernel(kernel, args.out, modules)
    code = make_audit_code(modules).encode()
    audit_command = GUARD + ['lake', 'env', 'lean', '-DmaxRecDepth=100000', '-DmaxHeartbeats=4000000', '--stdin']
    latest_path = args.out / 'types-axioms-process.json'
    latest = json.loads(latest_path.read_text()) if latest_path.exists() else None
    reused_successful_audit_raw = False
    if latest is not None and latest.get('exit_code') == 0:
        # A parser-only failure must not repeat a successful Lean audit.
        assert latest['command'] == audit_command and latest['cwd'] == str(PROJECT)
        assert latest['stdin_sha256'] == hashlib.sha256(code).hexdigest(), 'Previously successful audit used different code; do not repeat it'
        assert latest['log_sha256'] == digest(args.out / 'types-axioms.log')['sha256']
        audit = latest
        reused_successful_audit_raw = True
    else:
        attempts = args.out / 'audit-attempts'
        attempts.mkdir(exist_ok=True)
        number = 1
        while (attempts / f'attempt-{number}').exists():
            number += 1
        attempt = attempts / f'attempt-{number}'
        attempt.mkdir()
        (attempt / 'ModuleAudit.lean').write_bytes(code)
        (attempt / 'audit-driver.py').write_bytes(Path(__file__).read_bytes())
        (args.out / 'ModuleAudit.lean').write_bytes(code)
        audit = run(audit_command, attempt, 'types-axioms', code)
        (args.out / 'types-axioms.log').write_bytes((attempt / 'types-axioms.log').read_bytes())
        save(latest_path, audit)
        if audit['exit_code']:
            print((attempt / 'types-axioms.log').read_text()[-18000:])
            raise SystemExit(audit['exit_code'])
    declarations, inventory, axioms = read_audit((args.out / 'types-axioms.log').read_text(), modules, audit['exit_code'])
    after = {str(path): digest(path) for path in paths}
    after_context = context(modules)
    assert before == after and before_context == after_context
    save(args.out / 'SOURCE_AND_OUTPUTS_AFTER.json', after)
    save(args.out / 'CONTEXT_AFTER.json', after_context)
    save(args.out / 'INVENTORY_NAME_SET_CHECK.json', inventory)
    save(args.out / 'DECLARATION_TYPES_AXIOMS.json', declarations)
    result = {'schema': 'member_ten_roots_kernel_complete_owned_types_axioms_v1',
              'result': 'PASS_EXACT_TEN_NAMED_MODULE_KERNEL_COMPLETE_OWNED_TYPES_AST_UNIVERSES_AND_STANDARD_AXIOMS',
              'modules': modules, 'kernel': kernel, 'types_and_axioms': audit,
              'declaration_counts': inventory['module_counts'], 'total_owned_declarations': len(declarations),
              'private_declaration_count': inventory['private_name_count'], 'observed_axioms': axioms,
              'declarations': declarations, 'inventory': inventory,
              'source_and_five_outputs_per_module': after,
              'sources_outputs_and_configuration_unchanged': True,
              'pp_all_and_universes_true': True, 'full_pretty_types_and_raw_AST_and_universe_parameters': True,
              'audit_driver': {'path': str(Path(__file__)), **digest(Path(__file__))},
              'audit_source_sha256': hashlib.sha256(code).hexdigest(),
              'controller_lock': str(CONTROLLER_LOCK), 'explicit_guard_state': str(GUARD_STATE),
              'reused_successful_audit_raw_after_parser_only_failure': reused_successful_audit_raw,
              'replay_scope': 'Exact ten named project roots relative to their existing imports; no fresh/all-import kernel replay or dependency-proof credit.'}
    save(args.out / 'VALIDATION_RESULTS.json', result)
    print(json.dumps({key: result[key] for key in ['result', 'declaration_counts', 'total_owned_declarations', 'observed_axioms']}))


if __name__ == '__main__':
    main()
