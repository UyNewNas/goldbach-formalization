#!/usr/bin/env python3
"""Run a local command with the repository's pinned compiler guard."""
import argparse
import json
import os
from pathlib import Path
import subprocess

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--state', type=Path,
                    default=Path('/workspace/blue-build-tools/runtime-evidence/state.json'))
parser.add_argument('command', nargs=argparse.REMAINDER)
arguments = parser.parse_args()
if not arguments.command:
    parser.error('a command is required')
state = json.loads(arguments.state.read_text())
environment = os.environ.copy()
environment.update(state['environment'])
environment['ELAN_HOME'] = '/workspace/.elan'
environment['MATHLIB_CACHE_DIR'] = '/workspace/cache/mathlib'
environment['PATH'] = state['shadow'] + '/bin:' + environment['PATH']
raise SystemExit(subprocess.call(arguments.command, env=environment))
