#!/usr/bin/env python3
"""Exact nine-target graph and original-source/object group bindings."""
from pathlib import PurePosixPath
import re

GROUP_COUNTS = {'baseline15': 15, 'fields73': 73, 'rows15': 15, 'prefix13': 13, 'shape1': 1}
MODULE = re.compile(r'ImbalancedChen(?:\.[A-Za-z_][A-Za-z0-9_]*)+')


def require(value, message):
    if not value:
        raise ValueError(message)


def identity(value):
    require(isinstance(value, dict) and type(value.get('bytes')) is int and value['bytes'] > 0 and
            isinstance(value.get('sha256'), str) and re.fullmatch('[0-9a-f]{64}', value['sha256']),
            'Missing or invalid exact byte identity')
    return {'bytes': value['bytes'], 'sha256': value['sha256']}


def module_rows(rows):
    result = {}
    for row in rows:
        name = row.get('module')
        require(isinstance(name, str) and MODULE.fullmatch(name) and name not in result,
                'Unsafe or duplicate project module')
        identity(row['source'])
        imports = row['project_imports']
        require(isinstance(imports, list) and len(imports) == len(set(imports)) and
                all(isinstance(x, str) and MODULE.fullmatch(x) for x in imports),
                'Invalid project import inventory')
        result[name] = row
    return result


def validate_scope(targets, suppliers, boundary):
    require(len(targets) == 9 and len(suppliers) == 117, 'Remaining9 requires exactly 9 targets and 117 suppliers')
    target_rows, supplier_rows = module_rows(targets), module_rows(suppliers)
    require([row['module'] for row in targets] == boundary['target_modules'] and
            targets == boundary['target_contracts'], 'Target order, source/audit or dependency contract changed')
    require(sorted(supplier_rows) == boundary['supplier_modules'] and
            not set(target_rows) & set(supplier_rows), 'Supplier missing, extra or shadowing a new target')
    for group, count in GROUP_COUNTS.items():
        modules = sorted(row['module'] for row in suppliers if row.get('reuse_group') == group)
        require(len(modules) == count and modules == boundary['supplier_groups'][group],
                'Exact original supplier group differs: ' + group)
    for row in suppliers:
        identity(row['object'])
        require(row.get('must_not_recompile') is True, 'Supplier is not explicitly protected from recompilation')
    nodes = {**supplier_rows, **target_rows}
    cache = {}

    def closure(module, active):
        require(module not in active, 'Project import cycle')
        if module in cache:
            return cache[module]
        result = set()
        for child in nodes[module]['project_imports']:
            require(child in nodes, 'Unregistered project dependency: ' + child)
            result.add(child)
            result.update(closure(child, active | {module}))
        cache[module] = result
        return result

    external, seen, counts = set(), set(), []
    for row in targets:
        deps = closure(row['module'], set())
        declared = row['transitive_dependencies']
        require(len(declared) == len(set(declared)) and set(declared) == deps,
                'Declared project closure differs from exact source import graph')
        require(deps & set(target_rows) <= seen, 'New owner depends on a later or unaccepted owner')
        seen.add(row['module'])
        external.update(deps & set(supplier_rows))
        counts.append(len(deps) + 1)
    require(external == set(supplier_rows), 'The selected targets do not use the exact 117 suppliers')
    return {'target_count': 9, 'supplier_count': 117, 'expected_steps': 27,
            'external_union_count': 117, 'owned_project_closure_counts': counts}


def validate_origin_groups(registry, original103, prefix, shape):
    expected = module_rows(registry)
    require(len(expected) == 117, 'Wrong supplier registry size')
    seen = set()
    for rows, count, groups in [(original103, 103, {'baseline15', 'fields73', 'rows15'}),
                                (prefix, 13, {'prefix13'}), (shape, 1, {'shape1'})]:
        actual = module_rows(rows)
        wanted = {m for m, row in expected.items() if row.get('reuse_group') in groups}
        require(len(actual) == count and set(actual) == wanted and not seen & set(actual),
                'Validated original supplier groups overlap or omit modules')
        for module, row in actual.items():
            reference = expected[module]
            require(identity(row['source']) == identity(reference['source']) and
                    identity(row['object']) == identity(reference['object']) and
                    row['project_imports'] == reference['project_imports'],
                    'Original raw-chain source/object/import binding differs: ' + module)
        seen.update(actual)
    require(seen == set(expected), 'Original chain groups do not cover all 117 suppliers')


def validate_origin_paths(rows, stage):
    root = PurePosixPath(stage)
    require(root.is_absolute() and '..' not in root.parts and str(root) == stage,
            'Original stage is not an exact absolute path')
    for module, row in module_rows(rows).items():
        relative = module.replace('.', '/')
        require(row['source_path'] == str(root / 'project' / (relative + '.lean')) and
                row['object_path'] == str(root / 'objects' / (relative + '.olean')),
                'Unapproved original source/object path binding')

