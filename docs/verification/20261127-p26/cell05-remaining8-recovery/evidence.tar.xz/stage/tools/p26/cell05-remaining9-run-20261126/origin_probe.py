#!/usr/bin/env python3
"""Read original prefix/Shape raw chains in isolated Python interpreters; no Lean."""
from pathlib import Path
import argparse
import hashlib
import importlib
import importlib.util
import json
import stat
import sys

sys.dont_write_bytecode = True
if sys.flags.optimize:
    raise RuntimeError('Original raw validators require assertions enabled')


def require(value, message):
    if not value:
        raise ValueError(message)


def canonical(value):
    path = Path(value)
    require(path.is_absolute() and '..' not in path.parts and str(path) == str(value), 'Noncanonical origin path')
    for ancestor in [*reversed(path.parents), path]:
        mode = ancestor.lstat().st_mode
        require(not stat.S_ISLNK(mode), 'Symlink in original evidence path')
        if ancestor != path:
            require(stat.S_ISDIR(mode), 'Non-directory origin ancestor')
    require(path.resolve() == path, 'Relocated origin path')
    return path


def fp(value):
    path = canonical(value)
    require(stat.S_ISREG(path.lstat().st_mode), 'Nonregular original evidence file')
    body = path.read_bytes()
    return {'path': str(path), 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}


def checked_refs(rows):
    result = {}
    for row in rows:
        require(fp(row['path']) == row, 'Fixed original evidence bytes changed: ' + row['path'])
        prior = result.setdefault(row['path'], row)
        require(prior == row, 'Conflicting original evidence identities')
    return [result[key] for key in sorted(result)]


def bootstrap_shape(spec):
    here = canonical(str(Path(spec['stage']) / spec['tool_relative_path']))
    config = json.loads(Path(spec['verifier']['path']).read_bytes())
    for row in config['workflow_files']:
        path = canonical(str(here / row['relative_path']))
        require(path.is_relative_to(here), 'Workflow escapes original Shape tool root')
        require({key: fp(str(path))[key] for key in ('bytes', 'sha256')} ==
                {key: row[key] for key in ('bytes', 'sha256')}, 'Original Shape workflow changed')
    sys.path.insert(0, str(here))
    R = importlib.import_module('receipt_checks')
    V = importlib.import_module('verify_shape')
    for name in ('receipt_checks', 'verify_shape', 'origin_join', 'boundary', 'fields_only_join',
                 'receipt_support', 'runtime_compat', 'runtime_probe', 'evidence_io',
                 'supplier_capsule', 'portable_receipts', 'supplier_join', 'baseline_checks'):
        require(Path(sys.modules[name].__file__).absolute() == here / (name + '.py'),
                'Mixed original helper families: ' + name)
    return R, V, here


def run_probe(kind, boundary):
    spec = boundary['origins'][kind]
    before = checked_refs([spec['verifier'], *spec['anchors']])
    if kind == 'prefix13':
        source = Path(__file__).absolute().with_name('prefix_validator.py')
        module_spec = importlib.util.spec_from_file_location('remaining9_original_prefix_validator', source)
        original = importlib.util.module_from_spec(module_spec)
        module_spec.loader.exec_module(original)
        require(str(original.STAGE) == spec['stage'] and str(original.TOOL) == spec['tool_relative_path'],
                'Prefix validator fixed original location changed')
        R, V, _, here = original.bootstrap(Path(spec['stage']))
        state = original.validate_prefix(R, V, here)
        require(state['pilot_index'] == spec['pilot_index'] and state['failed_index'] == spec['failed_index']
                and state['records'] == spec['records'] and state['objects'] == spec['object_pins'],
                'Raw prefix chain differs from fixed accepted original evidence')
        context, joined, objects, records = state['context'], state['joined'], state['objects'], state['records']
        targets = state['config']['targets'][:13]
        require(len(state['steps']) == 39 and len(objects) == 13, 'Incomplete original prefix raw chains')
        expected_steps = 39
    else:
        R, V, here = bootstrap_shape(spec)
        config, _, joined = V.load_configuration(here)
        context, steps = R.validate_success(Path(spec['success']['path']))
        V.bind_context_to_package(context, here, config, joined['registry'], joined)
        success = R.read(spec['success']['path'])
        require(R.fp(spec['success']['path']) == spec['success'] and success['run'] == spec['run']
                and success['records'] == spec['records'], 'Raw Shape acceptance differs from fixed original evidence')
        require(len(steps) == 3 and success['accepted_targets'] == 1 and
                success['accepted_steps'] == 3, 'Incomplete original Shape raw chains')
        objects = {}
        for item in steps:
            result = item['result']
            previous = objects.setdefault(result['module'], result['object'])
            require(previous == result['object'], 'Shape modes disagree on the accepted object')
        require(len(objects) == 1, 'Shape original scope differs')
        targets, records, expected_steps = config['targets'], success['records'], 3
    require(targets == spec['target_contracts'], 'Origin source/dependency contracts changed')
    require(context['runtime_guard'] == joined['runtime_guard'] == boundary['runtime_guard'],
            'Original runtime guard replaced or recaptured')
    require(context['stage'] == spec['stage'], 'Original stage changed')
    suppliers = []
    for row in targets:
        source = str(Path(context['cwd']) / (row['module'].replace('.', '/') + '.lean'))
        source_pin = fp(source)
        require({key: source_pin[key] for key in ('bytes', 'sha256')} == row['source'],
                'Original accepted source changed')
        require(fp(objects[row['module']]['path']) == objects[row['module']], 'Original accepted object changed')
        suppliers.append({'module': row['module'], 'source': row['source'],
                          'object': {key: objects[row['module']][key] for key in ('bytes', 'sha256')},
                          'project_imports': row['project_imports'], 'source_path': source,
                          'object_path': objects[row['module']]['path']})
    frozen = checked_refs([*before, *context['frozen_inputs'], *joined['frozen_evidence']])
    checked_refs(before)
    return {'schema': 'cell05_remaining9_original_raw_probe_v1', 'status': 'PASS_ORIGINAL_RAW_CHAINS',
            'kind': kind, 'stage': spec['stage'], 'supplier_count': len(suppliers),
            'accepted_steps_rechecked': expected_steps, 'suppliers': suppliers,
            'records': records, 'runtime_guard': boundary['runtime_guard'],
            'fields_context': joined['fields_context'], 'frozen_evidence': frozen,
            'old_Lean_commands_executed': 0, 'original_evidence_rewritten': False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--kind', choices=('prefix13', 'shape1'), required=True)
    args = parser.parse_args()
    boundary_path = Path(__file__).absolute().with_name('BOUNDARY.json')
    boundary = json.loads(canonical(str(boundary_path)).read_bytes())
    require(boundary['schema'] == 'cell05_remaining9_boundary_v1', 'Unknown fixed origin boundary')
    print(json.dumps(run_probe(args.kind, boundary), separators=(',', ':')))


if __name__ == '__main__':
    main()
