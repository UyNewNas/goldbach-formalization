#!/usr/bin/env python3
"""Join 117 exact accepted suppliers from original raw chains; never run Lean."""
from pathlib import Path
import argparse
import fcntl
import json
import os
import subprocess
import sys

sys.dont_write_bytecode = True
if sys.flags.optimize:
    raise RuntimeError('Historical evidence validators require assertions enabled')

from evidence_io import canonical, fp, pin, read, require, same
from provider_install import install_provider
from runtime_compat import check_runtime_guard, logical_roots
from scope_contract import validate_origin_groups, validate_origin_paths, validate_scope
from supplier_capsule import metadata
from supplier_join import joined_inputs, resolved_paths, supplier_path

TOOL_REL = Path('tools/p26/cell05-remaining9-run-20261126')
STAGE = Path('/workspace/p26-cell05-remaining9-stage-v2-557a12f3bcd7')
PROVIDER = Path('/workspace/p26-cell05-remaining9-provider-v2-557a12f3bcd7')


def disjoint(a, b):
    a, b = canonical(a), canonical(b)
    require(not a.is_relative_to(b) and not b.is_relative_to(a), 'Overlapping new/original roots')


def checked_refs(rows):
    merged = {}
    for row in rows:
        require(fp(row['path']) == row, 'Frozen original input changed: ' + row['path'])
        old = merged.setdefault(row['path'], row)
        require(old == row, 'Conflicting frozen input reference')
    return [merged[key] for key in sorted(merged)]


def load_boundary(here):
    here = canonical(here, True)
    boundary = read(here / 'BOUNDARY.json')
    require(boundary['schema'] == 'cell05_remaining9_boundary_v1' and
            boundary['old_Lean_commands_permitted'] == 0 and boundary['old_stages_may_be_modified'] is False,
            'Wrong remaining-nine scope')
    targets = read(here / 'CONNECTION_TARGETS.json')
    registry = read(here / 'SUPPLIER_REGISTRY.json')
    require(targets['schema'] == 'cell05_remaining9_targets_v1' and targets['target_count'] == 9 and
            targets['expected_steps'] == 27 and registry['schema'] == 'cell05_remaining9_supplier_registry_v1'
            and registry['supplier_count'] == 117, 'Wrong target/supplier contract')
    validate_scope(targets['targets'], registry['suppliers'], boundary)
    return boundary, registry


def readonly_probe(here, kind, boundary):
    command = [sys.executable, '-I', '-B', str(here / 'origin_probe.py'), '--kind', kind]
    result = subprocess.run(command, check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=600)
    require(result.returncode == 0, 'Original raw-chain validation failed (' + kind + '): ' +
            result.stderr.decode(errors='replace')[-16000:])
    require(len(result.stdout) <= 8 * 1024**2 and not result.stderr, 'Unexpected origin probe output')
    probe = json.loads(result.stdout)
    expected_count, expected_steps = (13, 39) if kind == 'prefix13' else (1, 3)
    require(probe['schema'] == 'cell05_remaining9_original_raw_probe_v1' and
            probe['status'] == 'PASS_ORIGINAL_RAW_CHAINS' and probe['kind'] == kind and
            probe['stage'] == boundary['origins'][kind]['stage'] and
            probe['supplier_count'] == len(probe['suppliers']) == expected_count and
            probe['accepted_steps_rechecked'] == expected_steps and
            probe['records'] == boundary['origins'][kind]['records'] and
            probe['old_Lean_commands_executed'] == 0 and probe['original_evidence_rewritten'] is False and
            probe['runtime_guard'] == boundary['runtime_guard'], 'Wrong original raw-chain result scope')
    validate_origin_paths(probe['suppliers'], probe['stage'])
    checked_refs(probe['frozen_evidence'])
    return probe


def check_received(boundary, row_files):
    spec = boundary['rows_receive']
    root = canonical(spec['root'], True)
    require(spec['capsule']['path'] == str(root / 'rows15-provider-v1.tar.xz') and
            fp(spec['capsule']['path']) == spec['capsule'], 'Fixed received capsule changed')
    controls = checked_refs(spec['controls'])
    require(read(root / 'control/SOURCE_MANIFEST.json') == spec['source_manifest'] and
            read(root / 'control/RECEIVE_MANIFEST.json') == spec['request'], 'Receiver source/request changed')
    request = spec['request']
    require(request['schema'] == 'cell05_rows15_receive_request_v2' and request['remote_root'] == str(root)
            and request['chunk_bytes_max'] == 32000 and len(request['chunks']) == 75,
            'Different receiver partition or scope')
    chunks = []
    offset = 0
    for index, row in enumerate(request['chunks']):
        require(row['index'] == index and row['offset'] == offset and
                row['bytes'] == min(32000, spec['capsule']['bytes'] - offset), 'Incomplete chunk layout')
        path = root / 'parts' / ('part-%03d' % index)
        actual = fp(path)
        require(same(actual, row), 'Received chunk changed')
        chunks.append(actual)
        offset += row['bytes']
    require(offset == spec['capsule']['bytes'], 'Incomplete capsule transfer coverage')
    member_path = root / 'MEMBER_PINS.json'
    inventory = read(member_path)
    members = [{'member': name, **pin(body)} for name, body in sorted(row_files.items())]
    require(len(members) == 267 and inventory == {'schema': 'cell05_rows15_received_member_inventory_v1',
            'archive': spec['capsule'], 'members': members}, 'Receive inventory differs from actual validated capsule')
    manifest = json.loads(row_files['CAPSULE_MANIFEST.json'])
    require(pin(row_files['CAPSULE_MANIFEST.json']) == request['capsule_manifest'] and
            sum(len(body) for body in row_files.values()) == request['archive_expanded_bytes'],
            'Received manifest/expanded size differs')
    encoded = (json.dumps(manifest['mappings'], sort_keys=True, separators=(',', ':')) + '\n').encode()
    require(len(manifest['mappings']) == 496 and pin(encoded) == request['canonical_mappings'] and
            all(manifest[key] == value for key, value in request['source_anchors'].items()),
            'Receiver original source anchors or path mappings changed')
    receipt_path = root / 'RECEIVED.json'
    expected = {'schema': 'cell05_rows15_received_capsule_v1', 'status': 'PASS_RECEIVED_CAPSULE_ONLY',
        'archive': spec['capsule'], 'source_controls': {r['path']: r for r in controls},
        'chunk_pins': chunks, 'member_inventory': fp(member_path), 'regular_members': 267,
        'payload_members_checked': 266, 'source_anchors_checked': 4, 'original_mappings_checked': 496,
        'archive_extracted': False, 'provider_installed': False, 'Lean_commands': 0,
        'old_proof_steps_replayed': 0, 'new_Lean_acceptance': 0,
        'original_P1_capsule_removal_performed': False, 'complete_join_acceptance': False}
    require(read(receipt_path) == expected, 'Receiver is incomplete or receipt scope differs')
    return checked_refs([fp(receipt_path), fp(member_path), spec['capsule'], *controls, *chunks])


def origins(here, boundary, registry):
    original_here = here / 'original103'
    old_root = canonical(boundary['supplier88_root'], True)
    old_project, old_objects = old_root / 'project', old_root / 'objects'
    capsule = boundary['rows_receive']['capsule']
    data = joined_inputs(original_here, Path(capsule['path']), old_project, old_objects, capsule)
    received = check_received(boundary, data['row_files'])
    prefix = readonly_probe(here, 'prefix13', boundary)
    shape = readonly_probe(here, 'shape1', boundary)
    require(prefix['fields_context'] == shape['fields_context'] == data['fields_context'],
            'Independent original chains disagree on the accepted P2 fields runtime/context')
    validate_origin_groups(registry['suppliers'], data['registry']['suppliers'], prefix['suppliers'], shape['suppliers'])
    guard = boundary['runtime_guard']
    check_runtime_guard(guard)
    guard_body = read(guard['path'])
    require(guard_body['snapshot'] == data['runtime_summaries']['P2']['output'] and
            guard_body['logical_roots'] == logical_roots(data['runtime_summaries']['P2']),
            'Existing guard is not bound to the original equal-runtime evidence')
    metadata_refs = [fp(original_here / name) for name in
                     ('SUPPLIER_PLAN.json', 'SUPPLIER_REGISTRY.json', 'RUNTIME_COMPATIBILITY_PINS.json')]
    metadata_refs += [fp(original_here / row['relative_path']) for row in data['plan']['metadata_files']]
    metadata_refs += [fp(original_here / row['relative_path']) for row in
                      read(original_here / 'RUNTIME_COMPATIBILITY_PINS.json')['files']]
    frozen = checked_refs([*received, *data['baseline_files'], data['fields_spec']['archive'], guard,
                           data['runtime_summaries']['P2']['output'], *metadata_refs,
                           *prefix['frozen_evidence'], *shape['frozen_evidence']])
    return data, prefix, shape, received, frozen


def selected_entries(here, boundary, registry, data, prefix, shape):
    row_context = metadata(here / 'original103', data['plan'], 'rows15')[1]['context']
    live = {row['module']: row for probe in (prefix, shape) for row in probe['suppliers']}
    entries = []
    for row in registry['suppliers']:
        for kind in ('source', 'object'):
            entry = {'module': row['module'], 'kind': kind, 'identity': row[kind]}
            if row['reuse_group'] == 'rows15':
                root = row_context['cwd'] if kind == 'source' else row_context['objects']
                original = str(supplier_path(root, row['module'], kind))
                entry['body'] = data['row_view'].raw(original)
                require(same(pin(entry['body']), row[kind]), 'Selected original row bytes differ')
            else:
                source = (live[row['module']][kind + '_path'] if row['module'] in live else
                          str(supplier_path(Path(boundary['supplier88_root']) /
                              ('project' if kind == 'source' else 'objects'), row['module'], kind)))
                require(same(fp(source), row[kind]), 'Original supplier source/object changed')
                if kind == 'object':
                    require(not list(Path(source).parent.glob(Path(source).name + '.*')), 'Unexpected original object sidecars')
                entry['source_path'] = source
            entries.append(entry)
    require(len(entries) == 234 and sum('body' in row for row in entries) == 30,
            'Install only 102 hardlink pairs and 15 original row pairs')
    return entries


def protected_roots(boundary, data):
    return [STAGE, Path(boundary['supplier88_root']), Path(data['fields_context']['stage']),
            Path(boundary['rows_receive']['root']),
            *[Path(row['stage']) for row in boundary['origins'].values()],
            *[Path(row['path']).parent for row in data['fields_context']['runtime'].values()
              if isinstance(row, dict) and 'path' in row]]


def validate_locations(here, provider, boundary):
    require(canonical(here, True) == STAGE / TOOL_REL and canonical(provider) == PROVIDER,
            'Remaining-nine stage/provider must use their fixed independent roots')
    disjoint(STAGE, PROVIDER)
    for root in [boundary['supplier88_root'], boundary['rows_receive']['root'],
                 *[row['stage'] for row in boundary['origins'].values()]]:
        disjoint(STAGE, root)
        disjoint(PROVIDER, root)


def documents(here, provider, boundary, registry, data, prefix, shape, received):
    old = Path(boundary['supplier88_root'])
    capsule, archive = boundary['rows_receive']['capsule'], data['fields_spec']['archive']
    rows_map = resolved_paths(data['row_view'], capsule['path'], archive['path'],
                              old / 'project', old / 'objects', data['fields_context'])
    fields_map = resolved_paths(data['field_view'], capsule['path'], archive['path'],
                                old / 'project', old / 'objects', data['fields_context'])
    provenance = {'schema': 'cell05_remaining9_original_chains_v1',
        'original103': {'rows_run': data['plan']['batches']['rows15']['run'],
                       'rows_success': data['plan']['batches']['rows15']['success'], 'rows_steps': 45,
                       'fields_run': data['plan']['batches']['fields73']['run'],
                       'fields_success': data['plan']['batches']['fields73']['success'], 'fields_steps': 219,
                       'old_baseline': data['baseline']},
        'prefix13': {key: prefix[key] for key in ('stage', 'supplier_count', 'accepted_steps_rechecked', 'suppliers', 'records')},
        'shape1': {key: shape[key] for key in ('stage', 'supplier_count', 'accepted_steps_rechecked', 'suppliers', 'records')},
        'runtime_guard': boundary['runtime_guard'], 'old_Lean_commands_executed': 0,
        'original_receipt_bytes_rewritten': False}
    values = {
        'ROWS15_PATH_MAP.json': {'schema': 'cell05_original_path_to_current_evidence_v1',
                               'mappings': rows_map, 'historical_bytes_rewritten': False},
        'FIELDS73_PATH_MAP.json': {'schema': 'cell05_original_path_to_current_evidence_v1',
                                 'mappings': fields_map, 'historical_bytes_rewritten': False},
        'ORIGINAL_CHAINS.json': provenance,
    }
    result = []
    for name, value in values.items():
        path = canonical(provider / 'evidence' / name)
        body = (json.dumps(value, indent=2) + '\n').encode()
        result.append((path, body, {'path': str(path), **pin(body)}))
    join = {'schema': 'cell05_remaining9_supplier_join_v1', 'new_stage': str(STAGE),
        'supplier_project': str(provider / 'project'), 'supplier_objects': str(provider / 'objects'),
        'supplier_count': 117, 'supplier_registry': fp(here / 'SUPPLIER_REGISTRY.json'),
        'boundary': fp(here / 'BOUNDARY.json'), 'row_capsule': capsule, 'fields_archive': archive,
        'receiver_evidence': received, 'runtime_guard': boundary['runtime_guard'],
        'evidence_documents': [row[2] for row in result], 'old_baseline': data['baseline'],
        'baseline_files': data['baseline_files'], 'historical_rows15_steps': 45,
        'historical_fields73_steps': 219, 'historical_prefix13_steps': 39, 'historical_shape1_steps': 3,
        'supplier_groups': {key: len(value) for key, value in boundary['supplier_groups'].items()},
        'full_supplier_kernel_closed_in_combined_evidence': True, 'old_Lean_commands_executed': 0,
        'compatibility_kernel_replays': 0, 'original_receipt_bytes_rewritten': False,
        'historical_loaded_runtime_inventory_claimed': False}
    return result, join


def preflight_documents(provider, docs, completed):
    if provider.exists():
        for path in provider.iterdir():
            canonical(path, True)
            require(path.is_dir() and path.name in ('project', 'objects', 'evidence'),
                    'Unknown new provider root entry')
    expected = {str(path.relative_to(provider)) for path, _, _ in docs}
    if (provider / 'evidence').exists():
        actual = set()
        for path in (provider / 'evidence').rglob('*'):
            canonical(path, True)
            require(path.is_file(), 'Unexpected evidence directory or special file')
            actual.add(str(path.relative_to(provider)))
        require(actual <= expected, 'Unknown new provider evidence file')
    for path, _, identity in docs:
        if path.exists():
            require(fp(path) == identity, 'Conflicting partial provider evidence document')
        else:
            require(not completed, 'Completed provider evidence is missing; never reconstruct acceptance')


def report(here, boundary, registry, data, frozen, docs):
    return {'status': 'PASS_EXACT_117_SUPPLIER_JOIN', 'supplier_count': 117,
        'old_supplier_count': 15, 'field_supplier_count': 73, 'row_supplier_count': 15,
        'prefix_supplier_count': 13, 'shape_supplier_count': 1, 'actual_selected_supplier_union': 117,
        'historical_row_steps_rechecked': 45, 'historical_field_steps_rechecked': 219,
        'historical_prefix_steps_rechecked': 39, 'historical_shape_steps_rechecked': 3,
        'old_baseline': data['baseline'], 'fields_context': data['fields_context'],
        'runtime_guard': boundary['runtime_guard'], 'supplier_project': str(PROVIDER / 'project'),
        'supplier_objects': str(PROVIDER / 'objects'),
        'frozen_evidence': checked_refs([fp(here / 'SUPPLIER_JOIN.json'), fp(here / 'BOUNDARY.json'),
            fp(here / 'SUPPLIER_REGISTRY.json'), *frozen, *[r[2] for r in docs]]),
        'full_supplier_kernel_closed_in_combined_evidence': True,
        'old_Lean_commands_executed': 0, 'compatibility_kernel_replays': 0,
        'current_stock_roots_byte_identical': 10, 'historical_loaded_runtime_inventory_claimed': False}


def validate_join(here):
    here = canonical(here, True)
    boundary, registry = load_boundary(here)
    validate_locations(here, PROVIDER, boundary)
    actual = read(here / 'SUPPLIER_JOIN.json')
    data, prefix, shape, received, frozen = origins(here, boundary, registry)
    entries = selected_entries(here, boundary, registry, data, prefix, shape)
    docs, expected = documents(here, PROVIDER, boundary, registry, data, prefix, shape, received)
    require(actual == expected, 'Immutable remaining-nine join differs from actual original chains')
    preflight_documents(PROVIDER, docs, True)
    install_provider(PROVIDER, entries, protected_roots(boundary, data), completed=True)
    checked_refs(frozen)
    return report(here, boundary, registry, data, frozen, docs)


def install_join(here, provider):
    here, provider = canonical(here, True), canonical(provider)
    boundary, registry = load_boundary(here)
    validate_locations(here, provider, boundary)
    lock_path = canonical(STAGE / 'JOIN.lock')
    with lock_path.open('a') as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        if (here / 'SUPPLIER_JOIN.json').exists():
            return validate_join(here)
        require(not (STAGE / 'verification').exists(), 'Proof attempts exist but immutable join is missing')
        data, prefix, shape, received, frozen = origins(here, boundary, registry)
        entries = selected_entries(here, boundary, registry, data, prefix, shape)
        docs, join = documents(here, provider, boundary, registry, data, prefix, shape, received)
        preflight_documents(provider, docs, False)
        missing_body_bytes = sum(len(row['body']) for row in entries if 'body' in row and not
            supplier_path(provider / ('project' if row['kind'] == 'source' else 'objects'),
                          row['module'], row['kind']).exists())
        missing_body_bytes += sum(len(body) for path, body, _ in docs if not path.exists())
        disk = os.statvfs(STAGE)
        require(disk.f_bavail * disk.f_frsize >= missing_body_bytes + 32 * 1024**2,
                'Insufficient disk for selected row bytes, metadata, and 32 MiB headroom')
        # Existing successful outputs are never reconstructed. Only a new/partial
        # selected provider reaches this write phase, after every input was checked.
        install_provider(provider, entries, protected_roots(boundary, data), completed=False)
        for path, body, identity in docs:
            if not path.exists():
                path.parent.mkdir(parents=True, exist_ok=True)
                canonical(path.parent, True)
                with path.open('xb') as stream:
                    stream.write(body)
                    stream.flush()
                    os.fsync(stream.fileno())
            require(fp(path) == identity, 'Installed provenance readback differs')
        checked_refs(frozen)
        body = (json.dumps(join, indent=2) + '\n').encode()
        with (here / 'SUPPLIER_JOIN.json').open('xb') as stream:
            stream.write(body)
            stream.flush()
            os.fsync(stream.fileno())
        return report(here, boundary, registry, data, frozen, docs)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--provider', type=Path, required=True)
    args = parser.parse_args()
    here = Path(__file__).absolute().parent
    value = install_join(here, args.provider)
    print(json.dumps({key: val for key, val in value.items() if key not in ('fields_context', 'frozen_evidence')}))


if __name__ == '__main__':
    main()
