#!/usr/bin/env python3
"""Install only selected exact source/object bytes, preserving old files and partials."""
from pathlib import Path
import hashlib
import os
import re
import stat


def require(value, message):
    if not value:
        raise ValueError(message)


def canonical(path):
    path = Path(path)
    require(path.is_absolute() and '..' not in path.parts, 'Absolute canonical path required')
    for ancestor in [*reversed(path.parents), path]:
        try:
            mode = ancestor.lstat().st_mode
        except FileNotFoundError:
            continue
        require(not stat.S_ISLNK(mode), 'Symlink path rejected')
        if ancestor != path:
            require(stat.S_ISDIR(mode), 'Non-directory ancestor rejected')
    require(path.resolve() == path, 'Path alias rejected')
    return path


def pin(body):
    return {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}


def file_pin(path):
    path = canonical(path)
    require(path.is_file(), 'Missing regular source/object file')
    return pin(path.read_bytes())


def install_provider(provider, entries, forbidden_roots, completed=False):
    provider = canonical(provider)
    require(type(completed) is bool, 'Explicit completed-state boolean required')
    for root in forbidden_roots:
        root = canonical(root)
        require(not provider.is_relative_to(root) and not root.is_relative_to(provider),
                'New provider overlaps a protected original root')
    planned = {}
    for entry in entries:
        module, kind = entry['module'], entry['kind']
        require(isinstance(module, str) and re.fullmatch(r'ImbalancedChen(?:\.[A-Za-z_][A-Za-z0-9_]*)+', module)
                and kind in ('source', 'object'), 'Invalid selected supplier module/kind')
        folder, suffix = ('project', '.lean') if kind == 'source' else ('objects', '.olean')
        destination = canonical(provider / folder / (module.replace('.', '/') + suffix))
        require(destination not in planned, 'Duplicate selected supplier destination')
        expected = {key: entry['identity'][key] for key in ('bytes', 'sha256')}
        require(type(expected['bytes']) is int and expected['bytes'] > 0 and
                re.fullmatch('[0-9a-f]{64}', expected['sha256']), 'Invalid selected byte identity')
        require(('body' in entry) != ('source_path' in entry), 'Exactly one selected body source required')
        source = None
        if 'body' in entry:
            require(isinstance(entry['body'], bytes) and pin(entry['body']) == expected,
                    'Selected capsule body pin differs')
        else:
            source = canonical(entry['source_path'])
            require(file_pin(source) == expected, 'Original hardlink source pin differs')
        if destination.exists():
            require(file_pin(destination) == expected, 'Conflicting partial provider file; preserve it')
        else:
            require(not completed, 'Completed provider file is missing; refuse reconstruction')
        planned[destination] = (entry, expected, source)
    require(planned, 'Empty supplier installation is not permitted')
    for folder in ('project', 'objects'):
        namespace = canonical(provider / folder)
        if namespace.exists():
            require(namespace.is_dir(), 'Supplier namespace is not a directory')
            for path in namespace.rglob('*'):
                canonical(path)
                require(path.is_dir() or path.is_file() and path in planned,
                        'Unexpected supplier file, sidecar or inode type')
    # All sources, bodies and existing destinations are checked before the first write.
    result = []
    for destination, (entry, expected, source) in planned.items():
        method = 'existing_identical'
        if not destination.exists():
            require(not completed, 'Completed provider file disappeared; refuse reconstruction')
            destination.parent.mkdir(parents=True, exist_ok=True)
            canonical(destination.parent)
            if source is not None:
                os.link(source, destination, follow_symlinks=False)
                method = 'hardlink'
            else:
                with destination.open('xb') as stream:
                    stream.write(entry['body'])
                    stream.flush()
                    os.fsync(stream.fileno())
                method = 'selected_capsule_bytes'
        require(file_pin(destination) == expected, 'Installed supplier bytes changed')
        if source is not None:
            require(file_pin(source) == expected, 'Original supplier changed while linking')
        result.append({'module': entry['module'], 'kind': entry['kind'], 'path': str(destination),
                       **expected, 'method': method})
    return result
