"""Regression proofs on byte-identical v1, then R2; HOST fixtures only."""
import hashlib,inspect,json,tempfile,unittest
from pathlib import Path
import package_core as api
from fixture_host import Fixture,install_control,snapshot
ROOT=Path(__file__).resolve().parent
ACTUAL_LOG=ROOT/'regression-evidence/ACTUAL_FAILED_SHAPEARRAYS.log'
def verified(f):
 v=api.inspect_completed_qualification(f.inputs,policy=f.policy);v['execution_control']=f.execution_control;return v
def archive(f,out):
 kwargs={'policy':f.policy}
 if 'execution_control' in inspect.signature(api.package).parameters:kwargs['execution_control']=f.execution_control
 return api.package(f.inputs,out,**kwargs)
class FixRound1(unittest.TestCase):
 def setUp(self):self.tmp=tempfile.TemporaryDirectory(dir=ROOT/'host-tmp');self.root=Path(self.tmp.name)
 def tearDown(self):self.tmp.cleanup()
 def test_exact_real_failed_error_stub_is_retained_with_zero_credit(self):
  log=ACTUAL_LOG.read_bytes();self.assertEqual(len(log),4998);self.assertEqual(hashlib.sha256(log).hexdigest(),'15c29e5c39ee24e67ced1c5c50f7b4f5325628effb65071ee20830c93c00bcf2');self.assertIn(b'sorryAx',log);f=Fixture(self.root,failed_log=log)
  try:v=verified(f);p=api.build_member_plan(v)
  except RuntimeError as e:self.fail('exact failed compiler-recovery evidence rejected: '+str(e))
  n=next(n for n in p['payloads'] if '/ImbalancedChen.Shape/normal/' in n and n.endswith('output.log'));self.assertEqual(p['payloads'][n],log);self.assertEqual(v['counts']['new_proof_modes'],0);self.assertEqual(v['counts']['canonical'],1)
 def test_successful_mode_still_forbids_recovery_sorryAx(self):
  f=Fixture(self.root,'successful_sorry')
  with self.assertRaisesRegex(RuntimeError,'sorryAx'):verified(f)
 def test_failed_error_stub_does_not_release_successful_or_unlocked_tuple(self):
  f=Fixture(self.root,'failed_success',failed_log=ACTUAL_LOG.read_bytes())
  with self.assertRaisesRegex(RuntimeError,'failed'):verified(f)
 def rejection(self,kind):
  f=Fixture(self.root);f.execution_control=install_control(f,kind);v=verified(f)
  with self.assertRaises(RuntimeError,msg='unrelated execution-control evidence was accepted: '+kind):api.build_member_plan(v)
 def test_wrong_delivery_rejected(self):self.rejection('wrong_delivery')
 def test_wrong_delivery_controller_rejected(self):self.rejection('controller')
 def test_wrong_delivery_lock_rejected(self):self.rejection('lock')
 def test_lock_wrong_core_rejected(self):self.rejection('core')
 def test_lock_wrong_python_rejected(self):self.rejection('python')
 def test_host_wrong_execution_control_rejected(self):self.rejection('host')
 def test_host_wrong_tested_source_rejected(self):self.rejection('host_source')
 def test_host_wrong_runtime_rejected(self):self.rejection('host_runtime')
 def test_host_wrong_source_lock_rejected(self):self.rejection('host_lock')
 def test_valid_control_pins_persist_in_manifest_and_capsule(self):
  f=Fixture(self.root);before=snapshot(f.stage);result=archive(f,self.root/'output');capsule=json.loads(Path(result['capsule']['path']).read_bytes());manifest=json.loads(Path(result['manifest']['path']).read_bytes());expected=json.loads(f.execution_control)
  self.assertEqual(capsule.get('actual_execution_control'),expected,'capsule loses actual executed SELF/LOCK/core/runtime');self.assertEqual(manifest.get('actual_execution_control'),expected,'manifest loses actual executed SELF/LOCK/core/runtime');self.assertEqual(snapshot(f.stage),before)
 def test_input_json_cannot_supply_execution_pins(self):
  f=Fixture(self.root);f.inputs['execution_control']=json.loads(f.execution_control)
  with self.assertRaisesRegex(RuntimeError,'schema'):verified(f)
if __name__=='__main__':unittest.main(verbosity=2)
