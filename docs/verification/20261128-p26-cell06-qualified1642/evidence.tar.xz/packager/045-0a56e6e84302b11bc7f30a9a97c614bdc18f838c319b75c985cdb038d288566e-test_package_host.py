import importlib.util,json,tempfile,unittest,hashlib,subprocess,sys,tarfile
from pathlib import Path
from fixture_host import Fixture,snapshot,write
ROOT=Path(__file__).resolve().parent
try:import package_core as api
except ImportError:api=None
def host_inspect(f):
 v=api.inspect_completed_qualification(f.inputs,policy=f.policy);v['execution_control']=f.execution_control;return v
class ReaderHost(unittest.TestCase):
 def setUp(self):self.tmp=tempfile.TemporaryDirectory(dir=ROOT/'host-tmp');self.root=Path(self.tmp.name)
 def tearDown(self):self.tmp.cleanup()
 def inspect(self,fault=None):
  self.assertIsNotNone(api,'completed-qualification reader is not implemented');f=Fixture(self.root,fault);return f,host_inspect(f)
 def test_complete_qualification_preserves_original_modes_without_writes(self):
  self.assertIsNotNone(api,'completed-qualification reader is not implemented');f=Fixture(self.root);before=snapshot(f.stage);v=host_inspect(f);self.assertEqual(v['counts'],{'accepted':3,'increment':1,'original_modes':3,'new_proof_modes':0,'canonical':1,'shared':0});self.assertEqual(snapshot(f.stage),before);self.assertNotIn(f.bulk['path'],v['reader'].verified)
 def test_unaccepted_context_rejected(self):
  self.assertIsNotNone(api,'reader missing');f=Fixture(self.root,'context_unaccepted')
  with self.assertRaisesRegex(RuntimeError,'accept'):host_inspect(f)
 def test_review_pending_rejected(self):
  self.assertIsNotNone(api,'reader missing');f=Fixture(self.root,'review_pending')
  with self.assertRaisesRegex(RuntimeError,'review'):host_inspect(f)
 def test_outputs_copy_inventory_mismatch_rejected(self):
  self.assertIsNotNone(api,'reader missing');f=Fixture(self.root,'outputs')
  with self.assertRaisesRegex(RuntimeError,'copy'):host_inspect(f)
 def test_original_old_post_cannot_be_relabelled(self):
  self.assertIsNotNone(api,'reader missing');f=Fixture(self.root,'old_post')
  with self.assertRaisesRegex(RuntimeError,'old.*POST|old.*post'):host_inspect(f)
 def test_missing_pending_barrier_rejected(self):
  self.assertIsNotNone(api,'reader missing');f=Fixture(self.root,'barriers')
  with self.assertRaisesRegex(RuntimeError,'barrier'):host_inspect(f)
 def test_failed_tuple_cannot_claim_success(self):
  self.assertIsNotNone(api,'reader missing');f=Fixture(self.root,'failed_success')
  with self.assertRaisesRegex(RuntimeError,'failed'):host_inspect(f)
 def test_full_type_elision_rejected(self):
  self.assertIsNotNone(api,'reader missing');f=Fixture(self.root,'truncated_type')
  with self.assertRaisesRegex(RuntimeError,'type|axiom'):host_inspect(f)
 def test_original_mode_identity_transplant_rejected(self):
  self.assertIsNotNone(api,'reader missing');f=Fixture(self.root,'identity')
  with self.assertRaisesRegex(RuntimeError,'identity'):host_inspect(f)
 def test_sensitive_job_field_rejected(self):
  self.assertIsNotNone(api,'reader missing');f=Fixture(self.root,'job_secret')
  with self.assertRaisesRegex(RuntimeError,'job|safe'):host_inspect(f)
 def test_directory_symlink_rejected(self):
  self.assertIsNotNone(api,'reader missing');f=Fixture(self.root);(f.stage/'unexpected').symlink_to(f.root/'old',target_is_directory=True)
  with self.assertRaisesRegex(RuntimeError,'namespace|symlink'):host_inspect(f)
 def test_unknown_empty_directory_rejected(self):
  self.assertIsNotNone(api,'reader missing');f=Fixture(self.root);(f.stage/'extra').mkdir()
  with self.assertRaisesRegex(RuntimeError,'namespace|directory'):host_inspect(f)
 def test_missing_final_seal_rejected(self):
  self.assertIsNotNone(api,'reader missing');f=Fixture(self.root);Path(f.inputs['qualification']['seal']['path']).unlink()
  with self.assertRaises((RuntimeError,OSError)):host_inspect(f)
 def test_mutated_selected_source_rejected(self):
  self.assertIsNotNone(api,'reader missing');f=Fixture(self.root);Path(f.stage/'project/ImbalancedChen/Pending.lean').write_text('changed')
  with self.assertRaisesRegex(RuntimeError,'bytes|pin'):host_inspect(f)
class PlanHost(unittest.TestCase):
 def setUp(self):self.tmp=tempfile.TemporaryDirectory(dir=ROOT/'host-tmp');self.root=Path(self.tmp.name)
 def tearDown(self):self.tmp.cleanup()
 def test_approved_role_inventory_and_reference_partition(self):
  self.assertTrue(callable(getattr(api,'build_member_plan',None)),'member planner missing');f=Fixture(self.root);v=host_inspect(f);p=api.build_member_plan(v)
  self.assertEqual(sum('original8p' in a['roles'] for a in p['members'].values()),37);self.assertEqual(sum('qualification' in a['roles'] for a in p['members'].values()),12);self.assertEqual(len(p['copy_references']),len(f.copy_map));self.assertEqual(len({a['physical']['path'] for a in p['copy_references']}),len(f.copy_map));self.assertEqual(sum(a['name'].endswith('normal.olean') for a in p['members'].values()),1);self.assertNotIn(f.bulk['path'],v['reader'].verified)
 def test_full_typed_log_is_not_truncated(self):
  self.assertTrue(callable(getattr(api,'build_member_plan',None)),'member planner missing');f=Fixture(self.root);v=host_inspect(f);p=api.build_member_plan(v);target=next(n for n in p['members'] if '/full-owned/' in n and n.endswith('output.log'));self.assertEqual(p['payloads'][target],Path(v['collected']['pending']['records'][2]['log']['path']).read_bytes())
 def test_equal_control_basenames_are_preserved_distinctly(self):
  self.assertTrue(callable(getattr(api,'build_member_plan',None)),'member planner missing');f=Fixture(self.root,'basenames');p=api.build_member_plan(host_inspect(f));selected=[p['payloads'][n] for n,v in p['members'].items() if any(Path(x['path']).name=='same.txt' for x in v['original_pins'])];self.assertCountEqual(selected,[b'A',b'B'])
 def test_raw_input_references_name_prior_archive_members(self):
  f=Fixture(self.root);p=api.build_member_plan(host_inspect(f));refs=p['references'].get('raw_input_backreferences',[]);self.assertEqual([v['member'] for v in refs],['original-json/a.json','original-json/b.json']);self.assertTrue(all(v['archive']==f.inputs['previous']['archive'] for v in refs))
 def test_omitted_qualifier_delivery_cannot_be_substituted(self):
  f=Fixture(self.root);f.inputs['qualification']['delivery']=write(self.root/'partial-delivery.json',{'members':[],'source_lock':f.inputs['qualification']['source_lock']})
  with self.assertRaisesRegex(RuntimeError,'authority'):host_inspect(f)
 def test_previous_repository_path_cannot_be_transplanted(self):
  f=Fixture(self.root);f.inputs['previous']['repository_path']='docs/unrelated'
  with self.assertRaisesRegex(RuntimeError,'Previous'):host_inspect(f)
 def test_missing_original_sidefile_blocks_role_plan(self):
  self.assertTrue(callable(getattr(api,'build_member_plan',None)),'member planner missing');f=Fixture(self.root);v=host_inspect(f);target=next(row['physical']['path'] for row in f.copy_map if row['logical']==v['collected']['pending']['records'][2]['log']);Path(target).unlink()
  with self.assertRaises((RuntimeError,OSError)):api.build_member_plan(v)
 def test_review_with_critical_finding_is_not_authority(self):
  f=Fixture(self.root,'review_bad')
  with self.assertRaisesRegex(RuntimeError,'review'):host_inspect(f)
 def test_coherent_wrong_environment_identity_is_rejected(self):
  f=Fixture(self.root,'environment')
  with self.assertRaisesRegex(RuntimeError,'environment'):host_inspect(f)
 def test_catalog_physical_path_must_be_the_qualified_copy(self):
  f=Fixture(self.root,'catalog_path')
  with self.assertRaisesRegex(RuntimeError,'catalog|copy'):host_inspect(f)
class ActualAbiHost(unittest.TestCase):
 def setUp(self):self.tmp=tempfile.TemporaryDirectory(dir=ROOT/'host-tmp');self.root=Path(self.tmp.name)
 def tearDown(self):self.tmp.cleanup()
 def test_actual_safe_task_output_mcp_record_is_accepted_without_rewrite(self):
  f=Fixture(self.root,'task_jobs');before=Path(f.inputs['jobs']['qualify']['path']).read_bytes()
  try:v=host_inspect(f)
  except RuntimeError as e:self.fail('actual safe task/output ABI rejected: '+str(e))
  self.assertEqual(v['counts']['new_proof_modes'],0);self.assertEqual(Path(f.inputs['jobs']['qualify']['path']).read_bytes(),before)
 def test_actual_revision_old_graph_field_is_used(self):
  f=Fixture(self.root,'actual_report')
  try:v=host_inspect(f)
  except KeyError as e:self.fail('actual old_graph ABI not implemented: '+str(e))
  self.assertEqual(v['counts']['increment'],1)
class WriterHost(unittest.TestCase):
 def setUp(self):self.tmp=tempfile.TemporaryDirectory(dir=ROOT/'host-tmp');self.root=Path(self.tmp.name)
 def tearDown(self):self.tmp.cleanup()
 def test_archive_readback_and_outer_manifest_match(self):
  self.assertTrue(callable(getattr(api,'package',None)),'archive writer missing');f=Fixture(self.root);before=snapshot(f.stage);result=api.package(f.inputs,self.root/'output',policy=f.policy,execution_control=f.execution_control);c=json.loads(Path(result['capsule']['path']).read_bytes());m=Path(result['manifest']['path']).read_bytes()
  with tarfile.open(result['archive']['path'],'r:xz') as t:
   rows=t.getmembers();self.assertEqual(t.extractfile('MANIFEST.json').read(),m);self.assertEqual(len(rows),c['archive_members']);self.assertEqual(sum(v.size for v in rows),c['expanded_member_bytes']);self.assertTrue(all(v.isfile() for v in rows))
  self.assertEqual(c['new_proof_modes_executed'],0);self.assertFalse(c['formal_acceptance']);self.assertEqual(c['archive_canonical'],1);self.assertEqual(snapshot(f.stage),before)
 def test_existing_output_is_never_overwritten(self):
  self.assertTrue(callable(getattr(api,'package',None)),'archive writer missing');f=Fixture(self.root);out=self.root/'output';out.mkdir();(out/'keep').write_bytes(b'preserve')
  with self.assertRaises(RuntimeError):api.package(f.inputs,out,policy=f.policy,execution_control=f.execution_control)
  self.assertEqual((out/'keep').read_bytes(),b'preserve')
 def test_output_symlink_escape_is_rejected(self):
  self.assertTrue(callable(getattr(api,'package',None)),'archive writer missing');f=Fixture(self.root);(self.root/'escape').symlink_to(f.stage,target_is_directory=True)
  with self.assertRaises(RuntimeError):api.package(f.inputs,self.root/'escape/output',policy=f.policy,execution_control=f.execution_control)
  self.assertFalse((f.stage/'output').exists())
 def test_archive_size_failure_retains_failed_bytes_without_capsule(self):
  self.assertTrue(callable(getattr(api,'package',None)),'archive writer missing');f=Fixture(self.root)
  with self.assertRaisesRegex(RuntimeError,'size'):api.package(f.inputs,self.root/'output',policy=f.policy,max_archive_bytes=1,execution_control=f.execution_control)
  self.assertTrue((self.root/'output/evidence.tar.xz').exists());self.assertFalse((self.root/'output/CAPSULE.json').exists())
 def test_signed_url_in_selected_control_blocks_archive(self):
  self.assertTrue(callable(getattr(api,'package',None)),'archive writer missing');f=Fixture(self.root);bad=write(self.root/'signed.txt',('https://example.invalid/?si'+'g=credential').encode());decl=json.loads(Path(f.inputs['packager_delivery']['path']).read_bytes());decl['members'].append(bad);delivery=write(self.root/'packager.json',decl);f.inputs['packager_delivery']=delivery
  with self.assertRaisesRegex(RuntimeError,'Sensitive'):api.package(f.inputs,self.root/'output',policy=f.policy,execution_control=f.execution_control)
  self.assertFalse((self.root/'output/CAPSULE.json').exists())
 def test_selected_input_mutation_after_plan_is_rejected(self):
  self.assertTrue(callable(getattr(api,'write_member_plan',None)),'readback writer missing');f=Fixture(self.root);v=host_inspect(f);plan=api.build_member_plan(v);Path(f.stage/'project/ImbalancedChen/Pending.lean').write_bytes(b'changed')
  with self.assertRaisesRegex(RuntimeError,'bytes|changed'):api.write_member_plan(plan,self.root/'output')
  self.assertFalse((self.root/'output/CAPSULE.json').exists())
 def test_duplicate_json_key_rejected(self):
  with self.assertRaisesRegex(RuntimeError,'Duplicate'):api.strict_json(b'{"a":1,"a":2}')
 def test_json_nonfinite_rejected(self):
  with self.assertRaisesRegex(RuntimeError,'Nonfinite'):api.strict_json(b'{"a":NaN}')
class BootstrapHost(unittest.TestCase):
 def setUp(self):self.tmp=tempfile.TemporaryDirectory(dir=ROOT/'host-tmp');self.root=Path(self.tmp.name)
 def tearDown(self):self.tmp.cleanup()
 def command(self,action='check-code',wrong_self=False,wrong_lock=False,extra=()):
  cli=ROOT/'package_qualified1642.py';self.assertTrue(cli.exists(),'source-only CLI missing');from fixture_host import pin
  lock=write(self.root/'LOCK.json',{'schema':'p26_qualified1642_packager_source_lock_v1','controller':pin(cli),'modules':{'package_core':pin(ROOT/'package_core.py')},'python':pin(Path(sys.executable).resolve())});return [sys.executable,'-I','-B',str(cli),action,'--packager-sha256','0'*64 if wrong_self else pin(cli)['sha256'],'--source-lock-file',lock['path'],'--source-lock-sha256','0'*64 if wrong_lock else lock['sha256'],*extra]
 def test_locked_bootstrap_is_source_only(self):
  result=subprocess.run(self.command(),capture_output=True,text=True);self.assertEqual(result.returncode,0,result.stderr);j=json.loads(result.stdout);self.assertTrue(j['runtime_source_only']);self.assertEqual(j['Lean_commands'],0);self.assertEqual(j['G_runs'],0);self.assertFalse(j['formal_acceptance'])
 def test_wrong_self_cannot_execute_core(self):
  result=subprocess.run(self.command(wrong_self=True),capture_output=True,text=True);self.assertNotEqual(result.returncode,0);self.assertIn('SELF',result.stderr)
 def test_wrong_source_lock_rejected(self):
  result=subprocess.run(self.command(wrong_lock=True),capture_output=True,text=True);self.assertNotEqual(result.returncode,0);self.assertIn('LOCK',result.stderr)
 def test_host_fixture_cannot_be_cli_authority(self):
  f=Fixture(self.root);result=subprocess.run(self.command('package',extra=('--input-contract',f.inputpin['path'],'--input-contract-sha256',f.inputpin['sha256'],'--output-directory',str(self.root/'output'))),capture_output=True,text=True);self.assertNotEqual(result.returncode,0);self.assertFalse((self.root/'output/CAPSULE.json').exists())
if __name__=='__main__':unittest.main(verbosity=2)


