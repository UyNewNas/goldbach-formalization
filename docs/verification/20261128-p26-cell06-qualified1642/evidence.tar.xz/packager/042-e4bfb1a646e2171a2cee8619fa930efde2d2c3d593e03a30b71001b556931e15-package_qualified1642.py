#!/usr/bin/env python3
"""Externally pinned source-only completed1642 evidence packager."""
import sys
if not sys.flags.isolated or not sys.dont_write_bytecode:raise SystemExit('Use isolated python -I -B')
import builtins,hashlib,json,types
from pathlib import Path
ROOT=Path(__file__).absolute().parent

def fail(s):raise SystemExit(s)
def strict(raw):
 def pairs(rows):
  d={}
  for k,v in rows:
   if k in d:fail('Duplicate JSON key')
   d[k]=v
  return d
 return json.loads(raw,object_pairs_hook=pairs,parse_constant=lambda x:fail('Nonfinite JSON'))
def exact(item,path):
 p=Path(path).absolute()
 if '..' in p.parts:fail('Dotdot source path')
 for parent in (p,*p.parents):
  if parent.is_symlink():fail('Symlink source/LOCK path')
 raw=p.read_bytes();v={'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
 if v!=item:fail('Pinned source/runtime bytes mismatch')
 return raw

def main():
 args=sys.argv[1:]
 if args==['--help']:print('check-code | package --packager-sha256 SHA --source-lock-file PATH --source-lock-sha256 SHA [--input-contract PATH --input-contract-sha256 SHA --output-directory NEW_PATH]');return
 if not args or args[0] not in ('check-code','package'):fail('Explicit check-code or package action required')
 action=args.pop(0);opts={}
 if len(args)%2:fail('Expected flag/value pairs')
 for k,v in zip(args[::2],args[1::2]):
  if k in opts or not k.startswith('--'):fail('Duplicate/invalid option')
  opts[k]=v
 common={'--packager-sha256','--source-lock-file','--source-lock-sha256'};allowed=common if action=='check-code' else common|{'--input-contract','--input-contract-sha256','--output-directory'}
 if set(opts)!=allowed:fail('Missing/unknown command option')
 ownraw=Path(__file__).read_bytes();own={'path':str(Path(__file__).absolute()),'bytes':len(ownraw),'sha256':hashlib.sha256(ownraw).hexdigest()}
 if own['sha256']!=opts['--packager-sha256']:fail('External SELF SHA mismatch')
 lockpath=Path(opts['--source-lock-file']).absolute();lockraw=lockpath.read_bytes();lockpin={'path':str(lockpath),'bytes':len(lockraw),'sha256':hashlib.sha256(lockraw).hexdigest()}
 if lockpin['sha256']!=opts['--source-lock-sha256']:fail('External LOCK SHA mismatch')
 exact(lockpin,lockpath);lock=strict(lockraw)
 if set(lock)!={'schema','controller','modules','python'} or lock['schema']!='p26_qualified1642_packager_source_lock_v1' or lock['controller']!=own or set(lock['modules'])!={'package_core'}:fail('Wrong source LOCK identity/schema')
 exact(own,Path(__file__));python=Path(sys.executable).resolve()
 if lock['python']['path']!=str(python):fail('Python runtime path mismatch')
 exact(lock['python'],python);corepin=lock['modules']['package_core']
 if corepin['path']!=str(ROOT/'package_core.py'):fail('Core source path transplant')
 raw=exact(corepin,ROOT/'package_core.py');control={'controller':own,'source_lock':lockpin,'core':corepin,'python':lock['python']};control_bytes=json.dumps(control,sort_keys=True,separators=(',',':')).encode()
 def importer(name,globals=None,locals=None,fromlist=(),level=0):
  if level or name.split('.')[0] not in sys.stdlib_module_names:fail('Unlocked local import')
  return builtins.__import__(name,globals,locals,fromlist,level)
 module=types.ModuleType('package_core');module.__file__=corepin['path'];module.__cached__=None;module.__dict__['__builtins__']={**vars(builtins),'__import__':importer};exec(compile(raw,corepin['path'],'exec',dont_inherit=True),module.__dict__)
 if action=='check-code':print(json.dumps({'status':'LOCKED_SOURCE_BOOTSTRAP_OK','controller':own,'source_lock':lockpin,'runtime_source_only':True,'actual_execution_control':control,'Lean_commands':0,'G_runs':0,'collector_calls':0,'production_package_calls':0,'formal_acceptance':False}));return
 p=Path(opts['--input-contract']).absolute();b=p.read_bytes();ip={'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
 if ip['sha256']!=opts['--input-contract-sha256']:fail('External input contract SHA mismatch')
 exact(ip,p);result=module.package(module.strict_json(b),Path(opts['--output-directory']),input_contract_pin=ip,execution_control=control_bytes);print(json.dumps(result))
if __name__=='__main__':main()
