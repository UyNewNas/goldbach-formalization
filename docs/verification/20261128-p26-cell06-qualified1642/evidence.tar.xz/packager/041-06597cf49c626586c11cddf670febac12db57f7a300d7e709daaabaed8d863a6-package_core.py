"""Completed qualification evidence only. No executor, collector or G API."""
import hashlib,io,json,math,os,re,tarfile,time
from pathlib import Path,PurePosixPath
ROOT=Path(__file__).resolve().parent
PROTOCOL='source_revision4_transport_verified_pending_prefix_v1'
OLD='source_revision3_family_batch_global_boundary_v1'
MODES=['normal','stock-leanchecker','full-owned']
ALLOWED={'propext','Classical.choice','Quot.sound'}
STAGE_NAMES=['COLLECTED.json','QUALIFICATION_STARTED.json','D_PRE.json','COPY_MAP.json','FRESH_ORIGINAL_G_CURRENT.json','D_AND_COPY_POST.json','ALL_MODE_BARRIERS.json','EXACT_FAILED_RELEASE.json','QUALIFIER_INPUTS.json','OUTPUTS_POST.json','VERIFIED_PENDING_PREFIX_CERTIFICATE.json','CURRENT_ACCEPTED_CONTEXT.json']
POLICY={'parent_count':1641,'transport_count':1642,'native_count':555,'old_data_count':2,'graph_count':334,'pending_owner':'ImbalancedChen.P2OriginalSaving19Geometry06ScalableRowsNode000To014','shape_owner':'ImbalancedChen.P2OriginalSaving19Geometry06ScalableShapeArrays','protocol':PROTOCOL,'old_protocol':OLD,'previous_repository_path':'docs/verification/20261128-p26-cell06-through1641','previous_commit':'e4c7fd9205bd4a31655b8e8a101b4496e29a4d4f','authority_shas':{'previous_capsule':'9b1459c697f25dc5e281a179dc405967c174333782a8711e2ca4e96e0485570e','contract':'5be7e13f99e24dd9c350e38712da8e0371c3d0eaa08a96f0798db0eeaffc5d65','source_lock':'ef736daf3aaaeadb8164ca9d5608fcad833cbcfc55c63a5d6a48375ad487f24d','collected':'ca960d68605bc3c4efec305dcfc3ebe1361dfc7ae74bfdb7572a54c853208748','graph':'ecd1c7e2156e69acd099b7e08f9b47f448c8ac2bf75d7f531a3cb7785e99895b','qualifier_delivery':'7abdcc3fdd71f11d7e33372a8bf2bdbde78773b99e51d05e8b692247749ab887','review':'1848cf3375265a1571468bdc870eba221950c315e46c6a0f39649c4f03d038f7'},'stage':'/workspace/p26-cell06-family-revision4-r2-20261128/qualifications/attempt-001','source_bytes':19599,'source_sha256':'c5bd66975121ec9c7cf89337f35e2c1ad855c43537e354979efccf05c001a8b4','previous_canonical':18168,'pending_canonical':10}
class IntegrityError(RuntimeError):pass
def require(ok,msg):
 if not ok:raise IntegrityError(msg)
def valid_pin(v):
 require(isinstance(v,dict) and set(v)=={'path','bytes','sha256'} and isinstance(v['path'],str) and Path(v['path']).is_absolute() and '..' not in Path(v['path']).parts and type(v['bytes']) is int and v['bytes']>=0 and isinstance(v['sha256'],str) and re.fullmatch('[0-9a-f]{64}',v['sha256']) is not None,'Malformed pin');return v
def no_links(p):
 p=Path(p).absolute();require('..' not in p.parts,'Dotdot path')
 for q in (p,*p.parents):require(not q.is_symlink(),'Symlink input/output path')
 return p
def pin(p):
 p=no_links(p);h=hashlib.sha256();n=0
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b);n+=len(b)
 return {'path':str(p),'bytes':n,'sha256':h.hexdigest()}
def raw_pin(p,b):return {'path':str(Path(p).absolute()),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def strict_json(b):
 def pairs(rows):
  d={}
  for k,v in rows:require(k not in d,'Duplicate JSON key');d[k]=v
  return d
 return json.loads(b,object_pairs_hook=pairs,parse_constant=lambda v:(_ for _ in ()).throw(IntegrityError('Nonfinite JSON')))
def unique(rows):
 by={}
 for v in rows:valid_pin(v);require(by.setdefault(v['path'],v)==v,'Conflicting pin union')
 return [by[k] for k in sorted(by)]
def digest(rows):return hashlib.sha256(b''.join(json.dumps(v,sort_keys=True,separators=(',',':')).encode()+b'\n' for v in unique(rows))).hexdigest()
def same(a,b):return all(a[k]==b[k] for k in ('bytes','sha256'))
def safe_name(n):
 p=PurePosixPath(n);require(isinstance(n,str) and n not in ('','.') and not p.is_absolute() and '..' not in p.parts and '.' not in p.parts and '\\' not in n and '\x00' not in n,'Unsafe archive name');return n

def safe_material(b):
 patterns=[rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----\s+[A-Za-z0-9+/=]{32,}',rb'\bsk-[A-Za-z0-9_-]{24,}\b',rb'\bgh[pousr]_[A-Za-z0-9]{24,}\b',rb'\bAKIA[A-Z0-9]{16}\b',rb'https?://[^\s"<>]*[?&](?:X-Amz-[A-Za-z-]+|X-Goog-[A-Za-z-]+|Signature|AWSAccessKeyId|sig|access_token|token|se|sv)=']
 require(not any(re.search(p,b,re.I) for p in patterns),'Sensitive credential/signed URL material')
class Reader:
 def __init__(self):self.expected={};self.verified={};self.cache={};self.aliases={};self.references={}
 def expect(self,v):valid_pin(v);require(self.expected.setdefault(v['path'],v)==v,'Conflicting expected pin');return v
 def alias(self,logical,physical):
  self.expect(logical);self.expect(physical);require(same(logical,physical),'copy alias bytes differ');old=self.aliases.setdefault(logical['path'],physical);require(same(old,physical),'copy alias conflict')
 def resolve(self,v):self.expect(v);return self.aliases.get(v['path'],v)
 def raw(self,v):
  physical=self.resolve(v);p=no_links(physical['path']);b=p.read_bytes();require(raw_pin(p,b)==physical,'Pinned bytes mismatch');self.verified[str(p)]=physical;return b
 def read(self,v):
  self.expect(v)
  if v['path'] not in self.cache:self.cache[v['path']]=strict_json(self.raw(v))
  return self.cache[v['path']]
 def check(self,v):self.raw(v);return v
 def reference(self,v):self.expect(v);self.references[v['path']]=v
 def post_selected(self):
  for v in self.verified.values():require(pin(v['path'])==v,'Selected input bytes changed after read')

def parse_audit(text,owner,projects,externals):
 """Port of reviewed evidence.validate_audit; no code execution/replay."""
 rows={}
 for line in text.splitlines():
  if line.startswith('P26_CELL06_AUDIT_'):
   k,b=line.split(' ',1);rows.setdefault(k[len('P26_CELL06_AUDIT_'):],[]).append(strict_json(b))
 require(len(rows.get('IMPORTS',[]))==1,'audit imports incomplete');imports=rows['IMPORTS'][0];require(len(imports)==len(set(imports)) and set(imports)==set(projects)|set(externals),'audit import inventory differs')
 inventories={a['module']:a for a in rows.get('INVENTORY',[])};done={a['module']:a for a in rows.get('COMPLETE',[])}
 require(len(rows.get('INVENTORY',[]))==len(rows.get('COMPLETE',[]))==1 and set(inventories)==set(done)=={owner},'audit inventory/completion differs')
 decl=rows.get('DECL',[]);shared=rows.get('SHARED',[]);require(not shared,'Unexpected shared audit occurrence');names=[]
 for a in decl:
  require(a['module']==owner and not any(a[k] for k in ('unsafe','partial','axiom')) and a['type'] and '⋯' not in a['type'] and set(a['axioms'])<=ALLOWED,'type/axiom audit rejected');names.append(a['name'])
 inv=inventories[owner];require(len(names)==len(set(names)) and sorted(names)==sorted(inv['environment'])==sorted(inv['serialized']) and inv['shared']==[],'audit serialized/environment inventory differs')
 require(done[owner]=={'module':owner,'count':len(names),'shared_count':0,'serialized_count':len(names)},'audit completion count differs')
 return {'canonical_count':len(names),'shared_occurrences':0,'modules':1,'inventories':inventories,'canonical':{owner:decl} if decl else {},'shared':{},'external_modules':sorted(externals)}

def process_schema(v):
 keys={'exit_code','stop_reason','seconds','sampled_peak_tree_rss_bytes'};require(keys<=set(v) and type(v['exit_code']) is int and v['stop_reason'] is None and type(v['seconds']) in (int,float) and math.isfinite(v['seconds']) and v['seconds']>=0 and type(v['sampled_peak_tree_rss_bytes']) is int and v['sampled_peak_tree_rss_bytes']>=0,'Invalid process status');return {k:v[k] for k in keys}
def mode_record(r,row,owner,mode,c,family,batch,pre,history,policy,success=True):
 ep=Path(c['original_batch']['path']).parent;command=r.read(row['command']);result=r.read(row['result']);returned=r.read(row['process_return']);local=r.read(row['local_inputs']);source=family['project_sources'][owner];helper=next(v for v in batch['helpers'] if Path(v['path']).name==owner+'.Owned.lean')
 flags=['--trust=0','-DwarningAsError=true','-j1',f'-M{family["rss_gib"]*1024}','-DmaxRecDepth=1000000','-DmaxHeartbeats=0'];lean=family['runtime']['lean']['path'];argv=[lean,*flags,'-o','__NORMAL_OUTPUT__',source['path']] if mode=='normal' else [family['runtime']['leanchecker']['path'],'--verbose',owner] if mode=='stock-leanchecker' else [lean,*flags,helper['path']]
 ident={'protocol':policy['old_protocol'],'family':c['original_family'],'batch':c['original_batch'],'key':owner,'mode':mode,'global_validation_scope':'batch_boundary','batch_pre':pre,'environment_sha256':batch['environment_sha256'],'argv':argv,'cwd':str(Path(family['family_root'])/'project'),'timeout':family['wall_seconds'],'rss_bytes':family['rss_gib']*1024**3}
 require(command['identity']==returned['identity']==ident and row.get('identity',ident)==ident,'Original mode identity transplant');attempt=Path(row['command']['path']).parent
 require(attempt.parent==ep/'steps'/owner/mode and row['local_inputs']['path']==str(attempt/'LOCAL_INPUTS.json'),'Original attempt path transplant');require(command['actual_argv']==[str(attempt/'normal.olean') if a=='__NORMAL_OUTPUT__' else a for a in argv] and command['local_inputs']==row['local_inputs'],'Original actual argv/local identity differs')
 base=[source,helper,*family['code_pins'],*family['runtime'].values()]
 for h in history:
  base.extend(h[k] for k in ('marker','result','command','log','local_inputs','process_return'));base.extend([h['object']] if h['object'] else [])
 if history:base.extend([c['pending']['permanent_normal'],c['pending']['canonical_object']])
 require(isinstance(local,list) and local==unique(base),'Original local D selector differs')
 for v in local:r.check(v)
 require(result['protocol']==returned['protocol']==policy['old_protocol'] and result['formal_acceptance'] is returned['formal_acceptance'] is False and 'postcheck' not in result and result['global_validation_scope']=='batch_boundary','Original result scope differs')
 require(result['command']==returned['command']==row['command'] and result['process_return']==row['process_return'] and result['log']==returned['log']==row['log'] and result.get('object')==returned.get('object')==row.get('object'),'Original durable chain differs')
 require(row['result']['path']==str(attempt/'RESULT.json') and row['process_return']['path']==str(attempt/'PROCESS_RETURN.json') and row['log']['path']==str(attempt/'output.log'),'Original sidefile path differs')
 require(returned['status']=='PROCESS_RETURNED_PENDING_LOCAL_AND_GLOBAL_CHECKS' and process_schema(result)==process_schema(returned['process_result']),'Original return/process differs');require(result['local_post']=={'inputs':row['local_inputs'],'all_local_files_matched':True,'file_count':len(local)},'Original local D post differs')
 log=r.raw(row['log']).decode()
 if not success:
  release=c['failed_release'];require(owner==policy['shape_owner'] and mode=='normal' and all(row[k]==release[k] for k in ('command','result','process_return','log','local_inputs')) and command['identity']==release['old_identity'] and result['exit_code']==1 and result.get('object') is None and row.get('marker') is None,'Exact failed tuple differs');return None
 require('sorryAx' not in log,'Forbidden stored sorryAx')
 require(result['exit_code']==0 and result.get('mode_validation_error') is None,'Original success missing');marker=r.read(row['marker']);require(row['marker']['path']==str(attempt/'PENDING.json') and marker['identity']==ident and marker['result']==row['result'] and marker['process_return']==row['process_return'] and marker['formal_acceptance'] is False and marker['batch_post'] is None and marker['P2_6_complete'] is False,'Original pending marker identity differs')
 if mode=='normal':
  require(row['object'] is not None and row['object']['path']==str(attempt/'normal.olean'),'Original normal object missing');r.check(row['object']);axioms={a.strip() for group in re.findall(r'depends on axioms: \[([^\]]*)\]',log) for a in group.split(',') if a.strip()};require(axioms<=ALLOWED,'normal axiom rejected');parsed={'normal_object':row['object'],'printed_axioms':sorted(axioms)}
 elif mode=='stock-leanchecker':require(row['object'] is None,'Stock cannot create object');parsed={'stock_leanchecker_exit_zero':True}
 else:require(row['object'] is None,'Audit cannot create object');parsed=parse_audit(log,owner,set(c['parent_catalog'])|{owner},c['external_modules'])
 require(marker['validated']==row['validated']==parsed and marker['status']==('NORMAL_SUCCEEDED_PENDING_GLOBAL' if mode=='normal' else 'PROCESS_VALIDATED_PENDING_GLOBAL'),'Original parsed pending evidence differs');return parsed

def validate_job(r,v,kind,collected,context):
 job=r.read(v);require(set(job) in ({'status','output'},{'task','output'}),'Unsafe job record');s=job['task'] if 'task' in job else job['status'];allowed={'job_id','task_id','cwd','timeout_seconds','memory_mb','cpu_threads','status','submitted_at','started_at','ended_at','exit_code','elapsed_seconds','peak_memory_bytes','cpu_seconds','log_bytes','log_discarded_bytes','log_truncated','worker_pid','sandbox_pid'}
 require(set(s)<=allowed and s['status']=='succeeded' and type(s['exit_code']) is int and s['exit_code']==0 and s['ended_at'] is not None and s.get('log_truncated') is False and s.get('log_discarded_bytes')==0,'Unsafe/failed job status');require(isinstance(job['output'],str),'Unsafe job output');safe_material(job['output'].encode());out=strict_json(job['output']);key='collected' if kind=='collect' else 'accepted_context'
 require(set(out)<={key,'formal_acceptance','P2_6_complete','executor_calls','Lean_commands'} and out[key]==(collected if kind=='collect' else context) and out['formal_acceptance'] is (kind=='qualify') and out['executor_calls']==out['Lean_commands']==0 and out.get('P2_6_complete',False) is False,'Job output identity differs');return job

def stage_namespace(stage,copies):
 stage=no_links(stage);files={str(p) for p in stage.rglob('*') if p.is_file() or p.is_symlink()};expected={v['physical']['path'] for v in copies}|{str(stage/n) for n in STAGE_NAMES}
 require(files==expected,'Qualified namespace files differ');dirs={stage/'home',stage/'tmp'}
 for name in expected:
  for p in Path(name).parents:
   if p==stage:break
   dirs.add(p)
 require(all(p.is_dir() and not p.is_symlink() for p in dirs) and {p for p in stage.rglob('*') if p.is_dir()}==dirs,'Qualified directory namespace differs')
 require(all(not p.is_symlink() for p in stage.rglob('*')),'Qualified namespace symlink')

def inspect_completed_qualification(inputs,*,policy=None):
 policy=POLICY if policy is None else policy;r=Reader();require(set(inputs)=={'schema','previous','qualification','source_revision','jobs','packager_delivery'} and inputs['schema']=='p26_qualified1642_archive_input_v1','Wrong input contract schema');q=inputs['qualification'];previous=inputs['previous'];require(set(q)=={'contract','source_lock','delivery','collected','context','seal','outputs_post','review','review_completed'} and q['review_completed'] is True,'Independent review incomplete');require(set(previous)=={'commit','repository_path','capsule','archive','manifest'} and previous['commit']==policy['previous_commit'] and previous['repository_path']==policy['previous_repository_path'],'Previous publication differs')
 require(set(inputs['jobs'])=={'collect','qualify'},'Expected two job records');review=r.read(q['review']);require(review['context']==q['context'] and review['qualification']==q['seal'] and review['findings']=={'critical':0,'important':0,'minor':0} and review['qualified_parent_usable'] is True and review['accepted_project_union']==policy['transport_count'] and review['accepted_parent_union']==policy['parent_count'] and review['unique_added_owner']==policy['pending_owner'] and review['new_proof_mode_executions']==0 and review['original_pending_modes']==3 and review['original_pending_canonical']==policy['pending_canonical'] and review['original_pending_shared']==0 and review['P2_6_complete'] is review['Cell06_integral_complete'] is False,'Independent review not approved for this endpoint')
 for key,v in [('previous_capsule',previous['capsule']),('contract',q['contract']),('source_lock',q['source_lock']),('collected',q['collected']),('graph',inputs['source_revision']['new_graph']),('qualifier_delivery',q['delivery']),('review',q['review'])]:require(v['sha256']==policy['authority_shas'][key],'Unapproved authority pin: '+key)
 cap=r.read(previous['capsule']);require(cap['formal_acceptance'] is True and cap['accepted_project_union']==policy['parent_count'] and cap['P2_6_complete'] is False and cap['archive']==previous['archive'] and cap['manifest']==previous['manifest'],'Previous accepted capsule differs')
 c=r.read(q['collected']);contract=r.read(q['contract']);lock=r.read(q['source_lock']);context=r.read(q['context']);seal=r.read(q['seal']);stage=Path(policy['stage']);require(contract['stage']==str(stage),'Qualification stage transplant')
 for key,name in [('collected','COLLECTED.json'),('context','CURRENT_ACCEPTED_CONTEXT.json'),('seal','VERIFIED_PENDING_PREFIX_CERTIFICATE.json'),('outputs_post','OUTPUTS_POST.json')]:require(q[key]['path']==str(stage/name),'Final artifact path transplant')
 require(contract['source_lock']==q['source_lock'] and contract['roots']==inputs['source_revision']==c['roots'] and contract['expected_parent_count']==policy['parent_count'] and contract['expected_transport_count']==policy['transport_count'],'Qualification contract roots differ')
 require(c['contract']==context['contract']==seal['contract']==q['contract'] and c['source_lock']==context['source_lock']==seal['source_lock']==q['source_lock'] and c['accepted_parent']==context['accepted_parent']==seal['accepted_parent']==cap['current_context'],'Qualification authority identity differs')
 require(c['protocol']==context['protocol']==seal['protocol']==contract['protocol']==policy['protocol'] and context['schema']=='p26_revision4_transported1642_context_v1' and seal['schema']=='p26_revision4_verified_pending_prefix_v1','Qualification ABI differs')
 require(context['qualification']==q['seal'] and seal['outputs_post']==q['outputs_post'] and context['formal_acceptance'] is seal['formal_acceptance'] is True and context['P2_6_complete'] is seal['P2_6_complete'] is False and context['Cell06_integral_complete'] is False,'Final qualification not accepted')
 for obj in (context,seal):require(obj['proof_modes_repeated']==obj['executor_calls']==obj['Lean_commands']==0,'Qualification reran proof mode')
 require(c['formal_acceptance'] is False and c['fresh_global_readback_performed'] is False and c['executor_calls']==c['Lean_commands']==0,'COLLECTED scope differs')
 require(context['qualification_environment_sha256']==seal['qualification_environment_sha256']==c['qualification_environment_sha256'],'Qualification environment differs');require(seal['old_POST_exists'] is seal['old_seal_exists'] is False and c['pending']['old_post_exists'] is c['pending']['old_seal_exists'] is False and c['pending']['old_contexts']==0,'Original old POST/seal/context exists')
 copies=r.read(seal['copy_map']);require(isinstance(copies,list) and len({v['physical']['path'] for v in copies})==len(copies),'Invalid copy map');bylogical={}
 for row in copies:
  require(set(row)>={'logical','physical','role','original_identity_preserved','independent_inode'} and row['original_identity_preserved'] is row['independent_inode'] is True and same(row['logical'],row['physical']),'Invalid copy identity');require(Path(row['physical']['path']).is_relative_to(stage),'copy outside stage');r.alias(row['logical'],row['physical']);bylogical.setdefault(row['logical']['path'],[]).append(row)
 outputs=r.read(q['outputs_post']);require(outputs['all_actual_bytes_matched'] is True and outputs['formal_acceptance'] is False and outputs['physical_copies']==[v['physical'] for v in copies],'OUTPUTS copy inventory differs');stage_namespace(stage,copies)
 metadata=[q['collected'],seal['qualification_started'],seal['D_PRE'],seal['copy_map'],seal['fresh_original_G_current']]
 post=r.read(seal['D_and_copy_POST']);metadata.extend([post['qualifier_inputs'],seal['D_and_copy_POST'],seal['all_mode_barriers'],seal['exact_failed_release']]);require(outputs['metadata_pins']==metadata,'OUTPUTS metadata inventory differs')
 for v in metadata:require(Path(v['path']).parent==stage,'Qualification metadata path differs');r.read(v)
 started=r.read(seal['qualification_started']);require(started['collected']==q['collected'] and started['source_lock']==q['source_lock'] and started['contract']==q['contract'] and started['executor_calls']==0,'Qualification START differs')
 dpre=r.read(seal['D_PRE']);require(dpre['contract']==q['contract'] and dpre['pins']==unique(c['pending']['actual_local_pins']) and dpre['actual_matched'] is True and dpre['executor_calls']==0,'Qualification D_PRE differs')
 require(post['contract']==q['contract'] and post['actual_D_matched'] is post['metadata_input_post_matched'] is True and post['executor_calls']==0 and post['copy_readback']=={'files':len(copies),'source_and_copy_actual_bytes_matched':True,'independent_inodes':True} and post['external_namespace']['namespace_matches_lock'] is True,'Qualification copy/D POST differs')
 qi=r.read(post['qualifier_inputs']);require(qi['contract']==q['contract'],'Qualifier input roots differ')
 for v in qi['pins']:r.reference(v)
 parent=r.read(c['accepted_parent']);family=r.read(c['original_family']);batch=r.read(c['original_batch']);graph=r.read(c['new_graph']);pending=c['pending'];owner=policy['pending_owner'];shape=policy['shape_owner']
 require(parent['project_closure']==c['parent_catalog'] and len(c['parent_catalog'])==policy['parent_count'] and len(context['project_closure'])==policy['transport_count'] and seal['accepted_parent_count']==policy['parent_count'] and seal['transported_count']==policy['transport_count'],'Accepted catalog count differs')
 require(set(context['project_closure'])==set(c['parent_catalog'])|{owner} and owner not in c['parent_catalog'] and shape not in context['project_closure'],'Catalog membership differs')
 for m,v in c['parent_catalog'].items():
  new=context['project_closure'][m];require(new['source']['path']==str(stage/'project'/Path(m.replace('.','/')).with_suffix('.lean')) and new['selected_object']['path']==str(stage/'objects'/Path(m.replace('.','/')).with_suffix('.olean')) and any(row['logical']==v['source'] and row['physical']==new['source'] for row in copies) and any(row['logical']==v['selected_object'] and row['physical']==new['selected_object'] for row in copies),'Inherited catalog physical copy differs');require(new['original_accepted_entry']==v and same(v['source'],new['source']) and same(v['selected_object'],new['selected_object']),'Inherited catalog copy differs')
 require(len(c['native_artifacts'])==len(context['native_artifacts'])==policy['native_count'] and all(same(a,b) for a,b in zip(c['native_artifacts'],context['native_artifacts'])) and context['runtime']==c['runtime']==family['runtime']==parent['runtime'],'Native/runtime differs')
 require(context['lean_path']==str(stage/'objects')+':'+':'.join(c['lean_path'].split(':')[1:]) and c['lean_path']==family['lean_path']==parent['lean_path'],'LEAN_PATH differs')
 require(context['new_graph']==c['new_graph']==inputs['source_revision']['new_graph'] and len(graph['entries'])==len(graph['topological_order'])==policy['graph_count'] and len(set(graph['topological_order']))==policy['graph_count'],'Graph inventory differs')
 require(batch['owners'][0:2]==[owner,shape] and len(batch['owners'])==8 and pending['pending_barrier']['module']==owner,'Pending cohort differs');new=context['project_closure'][owner];require(new['source_mapping']==pending['source_mapping'] and new['original_mode_records']==pending['records']==seal['original_mode_records'] and new['original_permanent_normal']==pending['permanent_normal'] and same(new['source'],pending['source_mapping']['compiled_physical_source']) and same(new['selected_object'],pending['permanent_normal']),'Pending transported identity differs');r.alias(pending['canonical_object'],new['selected_object'])
 require(new['source']['path']==str(stage/'project'/Path(owner.replace('.','/')).with_suffix('.lean')) and new['selected_object']['path']==str(stage/'objects'/Path(owner.replace('.','/')).with_suffix('.olean')) and any(row['logical']==pending['source_mapping']['compiled_physical_source'] and row['physical']==new['source'] for row in copies) and any(row['logical']==pending['permanent_normal'] and row['physical']==new['selected_object'] for row in copies),'Pending catalog copy path differs')
 require(pending['source_mapping']['graph_logical_source']==graph['entries'][owner]['source'] and same(pending['source_mapping']['graph_logical_source'],pending['source_mapping']['compiled_physical_source']),'Pending graph/source mapping differs')
 barriers=r.read(seal['all_mode_barriers']);require(context['all_mode_barriers']==seal['all_mode_barriers'] and len(barriers)==policy['transport_count'] and {v['module'] for v in barriers}==set(context['project_closure']) and all(v['forbidden_modes']==MODES for v in barriers) and sum(v.get('old_data_forbidden',False) for v in barriers)==policy['old_data_count'],'All-mode barrier inventory differs');require(next(v for v in barriers if v['module']==owner)==pending['pending_barrier'],'Pending mode barrier changed')
 require(set(c['membership_barriers'][i]['module'] for i in range(len(c['membership_barriers'])))==set(c['parent_catalog']) and all(v in barriers for v in c['membership_barriers']),'Inherited membership barriers differ')
 sysroot=family['environment']['sysroot'];epoch=Path(c['original_batch']['path']).parent;env={'HOME':str(epoch/'home'),'TMPDIR':str(epoch/'tmp'),'LANG':'C.UTF-8','LC_ALL':'C.UTF-8','TZ':'UTC','LEAN_PATH':family['lean_path'],'LEAN_NUM_THREADS':'1','OMP_NUM_THREADS':'1','LEAN_SYSROOT':sysroot,'PATH':sysroot+'/bin:/usr/bin:/bin'};require(hashlib.sha256(json.dumps(env,sort_keys=True,separators=(',',':')).encode()).hexdigest()==batch['environment_sha256'],'Original final environment differs')
 hist=[];parsed=None
 for mode,row in zip(MODES,pending['records']):require(row['mode']==mode and row['owner']==owner,'Original mode order differs');parsed=mode_record(r,row,owner,mode,c,family,batch,c['old_global_pre'],hist,policy);hist.append(row)
 require(len(pending['records'])==3 and parsed==pending['typed_inventory'] and parsed['canonical_count']==policy['pending_canonical'] and parsed['shared_occurrences']==0,'Full typed original inventory differs')
 failed=r.read(seal['exact_failed_release']);require(context['failed_release']==seal['exact_failed_release'] and failed==c['failed_release'] and failed['module']==shape and failed['exit_code']==1 and failed['stop_reason'] is None and failed['object'] is None and failed['no_pending'] is True,'Exact failed release differs')
 fr=pending['failed_record'];require(all(fr[k]==failed[k] for k in ('command','result','process_return','log','local_inputs')) and r.read(fr['command'])['identity']==failed['old_identity'] and failed['old_source']==family['project_sources'][shape] and failed['new_graph']==c['new_graph'] and failed['new_source']==graph['entries'][shape]['source'],'Exact failed tuple identity differs');mode_record(r,fr,shape,'normal',c,family,batch,c['old_global_pre'],hist,policy,False)
 source=graph['entries'][shape]['source'];require(source['bytes']==policy['source_bytes'] and source['sha256']==policy['source_sha256'],'Shape candidate source differs');oldbytes=r.raw(failed['old_source']);newbytes=r.raw(source)
 for suffix in ('h.2.2','h.2.2.1'):
  needle=('  simpa only [h.1] using '+suffix+'\n').encode();replacement=('  intro i\n  exact '+suffix+' ⟨i.val, h.1 ▸ i.isLt⟩\n').encode();require(oldbytes.count(needle)==1,'Old proof patch differs');oldbytes=oldbytes.replace(needle,replacement,1)
 require(oldbytes==newbytes,'Not exact two proof patches');report=r.read(inputs['source_revision']['revision_report']);oldgraph=r.read(report['old_graph']);require(report['unchanged_source_count']==policy['graph_count']-1 and report['source_change']['replacement_count']==2 and oldgraph['topological_order']==graph['topological_order'],'Source revision scope differs')
 for m,v in graph['entries'].items():require(v==oldgraph['entries'][m] if m!=shape else {k:a for k,a in v.items() if k!='source'}=={k:a for k,a in oldgraph['entries'][m].items() if k!='source'},'Graph changed beyond Shape source')
 original_g=expand_original_g(r,c,family,batch);expected={'files':len(original_g),'bytes':sum(v['bytes'] for v in original_g),'map_sha256':digest(original_g)};require(expected==c['old_global_expected'],'Original G metadata expansion differs');fresh=r.read(seal['fresh_original_G_current']);require(fresh['purpose']=='PENDING_PREFIX_QUALIFICATION_OLD_G_CURRENT' and fresh['expected']==expected and fresh['matched'] is True and fresh['mismatches']==[] and fresh['files_attempted']==fresh['files_hashed']==expected['files'] and fresh['bytes_read']==expected['bytes'] and fresh['actual_map_sha256']==expected['map_sha256'] and fresh['old_POST_created'] is False,'Fresh original G report differs')
 require(fresh['identity']=={'contract':q['contract'],'old_family':c['original_family'],'old_batch':c['original_batch'],'old_pre':c['old_global_pre'],'original_selector':c['old_global_selector']},'Fresh G identity differs')
 for v in original_g:r.reference(v)
 for v in pending['actual_local_pins']:r.check(v)
 jobs={k:validate_job(r,v,k,q['collected'],q['context']) for k,v in inputs['jobs'].items()};delivery=r.read(q['delivery']);require(delivery['source_lock']==q['source_lock'],'R2 delivery lock differs')
 return {'reader':r,'inputs':inputs,'policy':policy,'collected':c,'context':context,'seal':seal,'contract':contract,'copy_map':copies,'metadata_pins':metadata+[q['outputs_post'],q['seal'],q['context']],'graph':graph,'failed':failed,'original_g':original_g,'jobs':jobs,'r2_delivery':delivery,'counts':{'accepted':policy['transport_count'],'increment':1,'original_modes':3,'new_proof_modes':0,'canonical':parsed['canonical_count'],'shared':0}}

def expand_original_g(r,c,family,batch):
 baseline=r.read(family['base_global_inputs']);spec=r.read(batch['global_inputs']);require(isinstance(baseline,list) and spec['family']==c['original_family'] and spec['parent_context']==batch['parent_context'] and spec['baseline']==family['base_global_inputs'],'Original G selector differs');return unique(baseline+spec['prefix_inputs']+spec['batch_static']+[batch['global_inputs'],family['base_global_inputs'],c['original_family'],c['original_batch']])

def json_bytes(v):return (json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
def validate_packager_control(v):
 """Bind archived evidence to the immutable CLI-verified execution snapshot."""
 r=v['reader'];raw=v.get('execution_control');require(isinstance(raw,bytes),'Missing immutable CLI execution control');control=strict_json(raw);require(set(control)=={'controller','source_lock','core','python'},'Execution control field set differs')
 for item in control.values():valid_pin(item);r.check(item)
 lock=r.read(control['source_lock']);require(set(lock)=={'schema','controller','modules','python'} and lock['schema']=='p26_qualified1642_packager_source_lock_v1' and lock['controller']==control['controller'] and lock['modules']=={'package_core':control['core']} and lock['python']==control['python'],'Execution control lock/core/runtime differs')
 delivery=r.read(v['inputs']['packager_delivery']);require(delivery.get('formal_acceptance') is False and delivery.get('controller')==control['controller'] and delivery.get('source_lock')==control['source_lock'] and isinstance(delivery.get('host_report'),dict),'Packager delivery is not the executed control')
 host=r.read(delivery['host_report']);require(host.get('formal_acceptance') is False and host.get('P2_6_complete') is False and type(host.get('tests')) is int and host['tests']>0 and host.get('failures')==host.get('errors')==0,'Packager host report not passed')
 require(host.get('source_lock')==control['source_lock'] and host.get('tested_execution_control')==control and host.get('tested_python')==control['python'],'Packager host tested lock/control/runtime differs')
 sources=unique(host.get('source_pins',[]));require(control['controller'] in sources and control['core'] in sources,'Packager host tested source differs')
 boot=host.get('frozen_bootstrap',{});require(boot.get('controller')==control['controller'] and boot.get('source_lock')==control['source_lock'] and boot.get('actual_execution_control')==control and boot.get('runtime_source_only') is True and boot.get('Lean_commands')==boot.get('G_runs')==boot.get('collector_calls')==boot.get('production_package_calls')==0 and boot.get('formal_acceptance') is False,'Packager host bootstrap/control differs')
 members=unique(delivery.get('members',[]));require(all(item in members for item in (control['controller'],control['core'],control['source_lock'],delivery['host_report'])),'Executed control evidence missing from delivery')
 return control

def build_member_plan(v):
 r=v['reader'];inputs=v['inputs'];c=v['collected'];q=inputs['qualification'];control=validate_packager_control(v);members={};payloads={};byoriginal={}
 def add(name,item,role):
  safe_name(name);valid_pin(item)
  if item['path'] in byoriginal:
   n=byoriginal[item['path']];require(item in members[n]['original_pins'],'Original member pin conflict')
   if role not in members[n]['roles']:members[n]['roles'].append(role)
   return n
  require(name not in members,'Duplicate archive name');b=r.raw(item);safe_material(b);physical=r.resolve(item);members[name]={'name':name,'roles':[role],'original_pins':[item],'physical_source':physical,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'generated':False};payloads[name]=b;byoriginal[item['path']]=name;return name
 def generated(name,data,role):
  safe_name(name);require(name not in members,'Duplicate generated member');b=json_bytes(data);safe_material(b);members[name]={'name':name,'roles':[role],'original_pins':[],'physical_source':None,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'generated':True};payloads[name]=b
 add('previous1641/CAPSULE.json',inputs['previous']['capsule'],'previous_publication')
 add('qualification/CONTRACT.json',q['contract'],'qualification_authority')
 for item in v['metadata_pins']:add('qualification/'+Path(item['path']).name,item,'qualification')
 require(sum('qualification' in a['roles'] for a in members.values())==12,'Qualification twelve metadata files missing')
 epoch=Path(c['original_batch']['path']).parent;exact=c['pending']['exact_epoch_pins'];require(len(exact)==37 and len({a['path'] for a in exact})==37,'Original37 sidefile inventory differs')
 for item in exact:
  path=Path(item['path']);require(path.is_relative_to(epoch),'Original sidefile outside epoch');add('original8p/'+str(path.relative_to(epoch)),item,'original8p')
 # All listed original proof/failed files must appear, not merely arbitrary37 files.
 required=[]
 for record in c['pending']['records']:
  required.extend(record[k] for k in ('marker','result','command','process_return','local_inputs','log'));required.extend([record['object']] if record['object'] else [])
 required.extend(v['failed'][k] for k in ('command','result','process_return','local_inputs','log'))
 exactmap={a['path']:a for a in exact};require(all(exactmap.get(a['path'])==a for a in required),'Original proof/failed sidefile missing')
 owner=v['policy']['pending_owner'];add('pending/'+owner.replace('.','/')+'.lean',c['pending']['source_mapping']['compiled_physical_source'],'accepted_pending_source')
 add('source-revision/ShapeArrays.before.lean',v['failed']['old_source'],'failed_source_before');add('source-revision/ShapeArrays.after.lean',v['failed']['new_source'],'candidate_source_after')
 for name,item in sorted(inputs['source_revision'].items()):add('source-revision/'+name+'.json',item,'source_revision_authority')
 source_delivery=r.read(inputs['source_revision']['source_delivery'])
 for i,item in enumerate(source_delivery['members']):add('source-revision/members/'+f'{i:03d}-'+item['sha256']+'-'+Path(item['path']).name,item,'source_revision_control')
 add('qualification/INDEPENDENT_REVIEW.json',q['review'],'qualification_review')
 add('controls/r2/DELIVERY.json',q['delivery'],'qualifier_control');add('controls/r2/SOURCE_LOCK.json',q['source_lock'],'qualifier_control')
 controls=list(v['r2_delivery']['members']);lock=r.read(q['source_lock']);controls.extend([lock['qualifier'],*lock['modules'].values()])
 for i,item in enumerate(unique(controls)):add('controls/r2/'+f'{i:03d}-'+item['sha256']+'-'+Path(item['path']).name,item,'qualifier_control')
 for kind,item in sorted(inputs['jobs'].items()):add('jobs/'+kind.upper()+'.json',item,'safe_actual_job')
 packer=r.read(inputs['packager_delivery']);require(packer.get('formal_acceptance') is False,'Packager source delivery cannot accept proofs');add('packager/DELIVERY.json',inputs['packager_delivery'],'packager_control')
 for i,item in enumerate(packer['members']):add('packager/'+f'{i:03d}-'+item['sha256']+'-'+Path(item['path']).name,item,'packager_control')
 allowed={'formal-parent-source','formal-parent-object','original-pending-compiled-source','qualified-pending-selected-object','frozen-graph-source-candidate','qualified-native','original-unsealed-epoch-evidence','original-JSON-copy'};copyrefs=[]
 for row in v['copy_map']:
  require(row['role'] in allowed,'Unknown qualification copy role');physical=row['physical'];direct=next((n for n,a in members.items() if a['physical_source']==physical),None);alias=direct or next((n for n,a in members.items() if same(a,physical)),None)
  copyrefs.append({**row,'archive_member':alias,'disposition':'archived' if direct else 'same_expected_bytes_payload_alias' if alias else 'reference_only','current_physical_body_rehashed':physical['path'] in r.verified,'qualification_copy_identity_preserved':True})
 require(len(copyrefs)==len(v['copy_map']) and len({a['physical']['path'] for a in copyrefs})==len(copyrefs),'Incomplete copy reference partition')
 references={'previous1641':inputs['previous'],'original_G':v['original_g'],'qualified_copies':copyrefs,'runtime':v['context']['runtime'],'native':v['context']['native_artifacts'],'raw_inputs':c['raw_inputs'],'raw_input_backreferences':[{'logical':a,'archive':inputs['previous']['archive'],'manifest':inputs['previous']['manifest'],'member':'original-json/'+Path(a['path']).name,'expected_bytes':a['bytes'],'expected_sha256':a['sha256'],'current_bulk_rehashed':False} for a in c['raw_inputs']],'current_bulk_rehashed':False,'scope':'Expected original physical references and qualification-time same-byte copies; no new G or complete provider claim.'}
 generated('references/ORIGINAL_G_EXPECTED.json',{'pins':v['original_g'],'expected':c['old_global_expected'],'current_bulk_rehashed':False},'reference_only_metadata')
 generated('references/QUALIFIED_COPY_REFERENCES.json',references,'reference_only_metadata')
 require(not any(n.endswith('.olean') and '/normal/' not in n for n in members),'Bulk/candidate objects must not be archived')
 return {'members':members,'payloads':payloads,'copy_references':copyrefs,'references':references,'actual_execution_control':control,'verified':v}

def output_path(path):
 p=no_links(Path(path).absolute());require(p!=ROOT and p.is_relative_to(ROOT),'Output outside new packager root');require(not p.exists(),'Exclusive new output required');return p

def write_exclusive(path,b):
 path=no_links(path);require(path.is_relative_to(ROOT),'Write outside new packager root')
 with path.open('xb') as f:f.write(b);f.flush();os.fsync(f.fileno())
 require(path.read_bytes()==b,'Output byte readback mismatch');return raw_pin(path,b)

def write_member_plan(plan,output,*,input_contract_pin=None,max_archive_bytes=90*1024**2):
 out=output_path(output);v=plan['verified'];r=v['reader'];members=plan['members'];payloads=plan['payloads'];policy=v['policy'];production=v.get('production_authority',False)
 r.post_selected();stage_namespace(Path(policy['stage']),v['copy_map']);out.parent.mkdir(parents=True,exist_ok=True);out.mkdir()
 manifest={'schema':'p26_qualified_pending_prefix_increment_v1_manifest','formal_acceptance':production,'accepted_project_union':policy['transport_count'],'previous_publication':v['inputs']['previous'],'qualification_context':v['inputs']['qualification']['context'],'qualification':v['inputs']['qualification']['seal'],'input_contract':input_contract_pin,'actual_execution_control':plan['actual_execution_control'],'members':members,'reference_catalog_members':['references/ORIGINAL_G_EXPECTED.json','references/QUALIFIED_COPY_REFERENCES.json'],'original_G_expected':v['collected']['old_global_expected'],'current_bulk_rehashed':False,'added_owners':[policy['pending_owner']],'ShapeArrays_accepted':False,'old8p_batch_accepted':False,'old_POST_created':False,'old_seal_created':False,'new_proof_modes_executed':0,'retained_original_successful_modes':3,'archive_canonical':v['counts']['canonical'],'archive_shared':0,'canonical_since1512':policy['previous_canonical']+v['counts']['canonical'],'Cell06_integral_complete':False,'P2_6_complete':False,'original_full_snapshot_verified':False,'scope':'Incremental evidence for already qualified pending prefix; selected metadata/payload readback only, inherited bulk reference-only.' if production else 'ISOLATED HOST FIXTURE archive; no production authority or proof credit.'}
 mraw=json_bytes(manifest);archive=out/'evidence.tar.xz'
 try:
  with archive.open('xb') as stream,tarfile.open(fileobj=stream,mode='w:xz') as tar:
   for name in sorted(members):
    row=members[name];b=payloads[name];require(len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256'],'Planned member bytes differ')
    if row['physical_source'] is not None:require(pin(row['physical_source']['path'])==row['physical_source'] and Path(row['physical_source']['path']).read_bytes()==b,'Member source bytes changed before archive')
    e=tarfile.TarInfo(safe_name(name));e.size=len(b);e.mode=0o644;tar.addfile(e,io.BytesIO(b))
   e=tarfile.TarInfo('MANIFEST.json');e.size=len(mraw);e.mode=0o644;tar.addfile(e,io.BytesIO(mraw))
  require(0<archive.stat().st_size<max_archive_bytes,'Archive compressed size limit exceeded; output retained, no automatic split')
  seen=set();expanded=0
  with tarfile.open(archive,'r|xz') as tar:
   for e in tar:
    require(e.isfile() and not e.issym() and not e.islnk() and safe_name(e.name) not in seen,'Unsafe/duplicate archive readback');seen.add(e.name);b=tar.extractfile(e).read();expanded+=len(b)
    if e.name=='MANIFEST.json':require(b==mraw,'Internal manifest byte mismatch')
    else:
     require(e.name in members and b==payloads[e.name],'Archive member byte readback mismatch');row=members[e.name]
     if row['physical_source'] is not None:require(Path(row['physical_source']['path']).read_bytes()==b,'Member source bytes changed after archive')
  require(seen==set(members)|{'MANIFEST.json'},'Archive readback omitted member');r.post_selected();stage_namespace(Path(policy['stage']),v['copy_map']);mp=write_exclusive(out/'MANIFEST.json',mraw);ap=pin(archive)
  capsule={'schema':'p26_qualified_pending_prefix_increment_v1_capsule','formal_acceptance':production,'production_authority':production,'accepted_project_union':policy['transport_count'],'current_context':v['inputs']['qualification']['context'],'qualification':v['inputs']['qualification']['seal'],'previous_publication':v['inputs']['previous'],'input_contract':input_contract_pin,'actual_execution_control':plan['actual_execution_control'],'archive':ap,'manifest':mp,'archive_members':len(seen),'expanded_member_bytes':expanded,'all_archive_members_byte_equal':True,'added_owners':[policy['pending_owner']],'new_proof_modes_executed':0,'retained_original_successful_modes':3,'archive_canonical':v['counts']['canonical'],'archive_shared':0,'canonical_since1512':policy['previous_canonical']+v['counts']['canonical'],'actual_selected_checksum':{'files':len(r.verified),'bytes':sum(a['bytes'] for a in r.verified.values()),'scope':'Selected metadata/local-D/payload only; not original-G or inherited bulk revalidation.'},'original_G_reference_count':len(v['original_g']),'unrehashed_original_G_reference_paths':sum(a['path'] not in r.verified for a in v['original_g']),'qualified_copy_reference_count':len(plan['copy_references']),'current_bulk_rehashed':False,'old8p_batch_accepted':False,'old_POST_created':False,'old_seal_created':False,'ShapeArrays_accepted':False,'proof_modes_repeated_by_packager':0,'collector_calls':0,'global_checks_repeated_by_packager':0,'provider_writes':0,'Cell06_integral_complete':False,'P2_6_complete':False,'original_full_snapshot_verified':False,'scope':manifest['scope']};cpp=write_exclusive(out/'CAPSULE.json',json_bytes(capsule));return {'capsule':cpp,'archive':ap,'manifest':mp,'accepted_project_union':policy['transport_count'],'formal_acceptance':production,'P2_6_complete':False}
 except Exception as exc:
  failure=out/'PACKAGE_FAILED.json'
  if not failure.exists():write_exclusive(failure,json_bytes({'status':'PACKAGE_FAILED','reason':str(exc),'formal_acceptance':False,'proof_processes':0,'G_runs':0,'collector_calls':0}))
  raise

def package(inputs,output,*,policy=None,input_contract_pin=None,max_archive_bytes=90*1024**2,execution_control=None):
 require(isinstance(execution_control,bytes),'Missing immutable CLI execution control');output_path(output);v=inspect_completed_qualification(inputs,policy=policy);v['production_authority']=policy is None;v['execution_control']=execution_control;plan=build_member_plan(v);return write_member_plan(plan,output,input_contract_pin=input_contract_pin,max_archive_bytes=max_archive_bytes)
