"""Synthetic host-only fixtures. Never invokes a production collector or proof."""
import unittest, tempfile, json, hashlib, sys, types, subprocess, os, shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def module(name):
    path=ROOT/(name+'.py')
    if not path.exists():raise AssertionError('Missing planned feature: '+name)
    obj=types.ModuleType(name);obj.__file__=str(path)
    exec(compile(path.read_bytes(),str(path),'exec',dont_inherit=True),obj.__dict__)
    return obj

def ref(p):
    raw=Path(p).read_bytes();return {'path':str(Path(p).absolute()),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}

class TempCase(unittest.TestCase):
    def setUp(self):self.temp=tempfile.TemporaryDirectory(dir=ROOT);self.root=Path(self.temp.name)
    def tearDown(self):self.temp.cleanup()
    def file(self,n,b):p=self.root/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return p
class CoreTests(TempCase):
    def test_external_sha_rejected(self):
        c=module('revision4_core');p=self.file('x',b'hello')
        with self.assertRaises(c.IntegrityError):c.external(p,'0'*64)
    def test_conflicting_expected_pin_rejected(self):
        c=module('revision4_core');p=self.file('x',b'hello');r=c.Reader();r.check(ref(p));bad={**ref(p),'sha256':'0'*64}
        with self.assertRaises(c.IntegrityError):r.expect(bad)
    def test_fresh_read_detects_equal_stat_change(self):
        c=module('revision4_core');p=self.file('x',b'hello');expected=ref(p);r=c.Reader();r.check(expected);p.write_bytes(b'world')
        with self.assertRaises(c.IntegrityError):r.check(expected,fresh=True)
    def test_exclusive_dump(self):
        c=module('revision4_core');p=self.root/'x';c.dump(p,{'a':1})
        with self.assertRaises(FileExistsError):c.dump(p,{'a':2})
    def test_source_loader_ignores_pyc_and_local_cache(self):
        loader=module('revision4_loader');leaf=self.file('leaf.py',b'value=41\n');node=self.file('node.py',b'from leaf import value\nvalue+=1\n')
        self.file('__pycache__/leaf.cpython-311.pyc',b'malicious cache')
        fake=types.ModuleType('leaf');fake.value=999;prior=sys.modules.get('leaf');sys.modules['leaf']=fake
        try:self.assertEqual(loader.SourceLoader({'leaf':ref(leaf),'node':ref(node)}).load('node').value,42)
        finally:
            if prior is None:sys.modules.pop('leaf',None)
            else:sys.modules['leaf']=prior
    def test_source_loader_wrong_sha(self):
        loader=module('revision4_loader');p=self.file('x.py',b'value=1\n');bad={**ref(p),'sha256':'0'*64}
        with self.assertRaises(RuntimeError):loader.SourceLoader({'x':bad}).load('x')
    def test_unlocked_local_import_refused(self):
        loader=module('revision4_loader');p=self.file('x.py',b'import unlocked_local_helper\n')
        with self.assertRaises(ImportError):loader.SourceLoader({'x':ref(p)}).load('x')
    def test_nested_compile_unlocked_source_refused(self):
        loader=module('revision4_loader');p=self.file('x.py',b'exec(compile(b"value=99", "/unlocked.py", "exec"))\n')
        with self.assertRaises(RuntimeError):loader.SourceLoader({'x':ref(p)}).load('x')
    def test_process_event_blocked_without_execution(self):
        c=module('revision4_core');g=c.ProcessGuard()
        with self.assertRaises(c.IntegrityError):
            with g:sys.audit('subprocess.Popen','fixture',[],None,{})
        self.assertEqual(g.attempts,1)
    def test_fork_audit_events_blocked_without_fork(self):
        c=module('revision4_core')
        for event in ['os.fork','os.forkpty']:
            with self.assertRaises(c.IntegrityError):
                with c.ProcessGuard():sys.audit(event)
    def test_stage_dotdot_rejected(self):
        c=module('revision4_core');base=self.root/'new';base.mkdir()
        with self.assertRaises(c.IntegrityError):c.safe_stage(base,base/'..'/'provider')
    def test_write_dotdot_rejected(self):
        c=module('revision4_core');base=self.root/'new';base.mkdir();target=base/'..'/'provider'
        with self.assertRaises(c.IntegrityError):
            with c.WriteGuard(base):target.write_bytes(b'bad')
        self.assertFalse((self.root/'provider').exists())
    def test_nested_process_guards_both_record_attempt(self):
        c=module('revision4_core');a=c.ProcessGuard();b=c.ProcessGuard()
        with self.assertRaises(RuntimeError):
            with a,b:sys.audit('subprocess.Popen','fixture',[],None,{})
        self.assertEqual((a.attempts,b.attempts),(1,1))
    def test_provider_write_blocked(self):
        c=module('revision4_core');allowed=self.root/'stage';forbidden=self.root/'provider'
        with self.assertRaises(c.IntegrityError):
            with c.WriteGuard(allowed):forbidden.write_bytes(b'changed')
        self.assertFalse(forbidden.exists())

def production(name):
    if not (ROOT/(name+'.py')).exists():raise AssertionError('Missing planned feature: '+name)
    loader=module('revision4_loader')
    paths={p.stem:ref(p) for p in ROOT.glob('revision4_*.py')}
    legacy=Path('/workspace/p26-cell06-source-candidate-20261128/runner')
    paths.update({n:ref(legacy/(n+'.py')) for n in ('evidence','templates','controller')})
    paths['checkpoint']=ref(Path('/workspace/p26-cell06-checkpoint-revision3-20261128/checkpoint.py'))
    l=loader.SourceLoader(paths);return l.load(name),l

class CollectorTests(TempCase):
    def fixture(self,bad=None):
        c,l=production('revision4_collect');f=module('fixture_revision4').build(self.root,l,bad);return c,l,f
    def test_membership_forbids_all_modes_without_inventing_success(self):
        c,l,f=self.fixture();barriers=c.membership_barriers(f.parent,2,f.family['normal_barriers'])
        self.assertEqual(len(barriers),2)
        self.assertTrue(all(b['forbidden_modes']==['normal','stock-leanchecker','full-owned'] for b in barriers))
        self.assertTrue(all(b['status']=='accepted_membership_forbidden' for b in barriers))
        self.assertTrue(all('normal_success' not in b for b in barriers))
        self.assertEqual(sum(b['old_data_forbidden'] for b in barriers),1)
    def test_code_lock_retains_cli_and_python_for_postcheck(self):
        c,l=production('revision4_collect');self.assertTrue(hasattr(c,'check_code_lock'),'Missing planned code/runtime postcheck');core=l.load('revision4_core');cli=self.file('cli',b'code');runtime=self.file('python',b'runtime');lock=self.root/'lock.json';lock.write_text(json.dumps({'qualifier':ref(cli),'python':ref(runtime),'modules':l.pins}));r=core.Reader();c.check_code_lock(r,ref(lock),l);cli.write_bytes(b'evil')
        with self.assertRaises(RuntimeError):r.post()
    def test_barrier_does_not_duplicate_full_typed_inventory(self):
        c,l,f=self.fixture();row={'owner':'ImbalancedChen.Accepted','mode':'full-owned','command':ref(self.file('command',b'{}')),'validated':{'large_types':'x'*1000}}
        b=c.membership_barriers(f.parent,2,f.family['normal_barriers'],[row]);v=next(x for x in b if x['module']==row['owner'])
        self.assertNotIn('validated',v['visible_original_mode_records'][0]);self.assertEqual(v['visible_original_mode_records'][0]['command'],row['command'])
    def test_pending_complete_and_original_identities(self):
        c,l,f=self.fixture();d=c.validate_pending(f.anchor,f.family,f.batch,f.parent,f.graph,l)
        self.assertEqual(len(d['records']),3);self.assertEqual(d['typed_inventory']['shared_occurrences'],1)
        self.assertNotEqual(d['source_mapping']['graph_logical_source']['path'],d['source_mapping']['compiled_physical_source']['path'])
        self.assertEqual(d['records'][0]['protocol'],f.family['protocol'])
    def test_wrong_physical_logical_mapping(self):
        c,l,f=self.fixture('source_mapping')
        with self.assertRaises(RuntimeError):c.validate_pending(f.anchor,f.family,f.batch,f.parent,f.graph,l)
    def test_wrong_mode_identity(self):
        c,l,f=self.fixture('identity')
        with self.assertRaises(RuntimeError):c.validate_pending(f.anchor,f.family,f.batch,f.parent,f.graph,l)
    def test_return_status_transplant(self):
        c,l,f=self.fixture('return_exit')
        with self.assertRaises(RuntimeError):c.validate_pending(f.anchor,f.family,f.batch,f.parent,f.graph,l)
    def test_shared_body_flag_rejected(self):
        c,l,f=self.fixture('shared_body')
        with self.assertRaises(RuntimeError):c.validate_pending(f.anchor,f.family,f.batch,f.parent,f.graph,l)
    def test_unknown_attempt_rejected(self):
        c,l,f=self.fixture('extra_attempt')
        with self.assertRaises(RuntimeError):c.validate_pending(f.anchor,f.family,f.batch,f.parent,f.graph,l)
    def test_old_post_never_reclassified(self):
        c,l,f=self.fixture('old_post')
        with self.assertRaises(RuntimeError):c.validate_pending(f.anchor,f.family,f.batch,f.parent,f.graph,l)

class TransportTests(TempCase):
    def api(self):return production('revision4_transport')
    def test_complete_fresh_snapshot_reads_each_path(self):
        t,l=self.api();a=self.file('a',b'same');b=self.file('b',b'same');rows=[ref(a),ref(b)];calls=[]
        def h(path):calls.append(str(path));return ref(path)
        expected={'files':2,'bytes':8,'map_sha256':t.digest(rows)}
        for _ in range(2):self.assertTrue(t.fresh_snapshot(rows,expected,{'contract':'fixture'},h)['matched'])
        self.assertEqual(calls,[str(a),str(b),str(a),str(b)])
    def test_snapshot_changed_bytes_fails(self):
        t,l=self.api();a=self.file('a',b'aaaa');rows=[ref(a)];expected={'files':1,'bytes':4,'map_sha256':t.digest(rows)};a.write_bytes(b'bbbb')
        self.assertFalse(t.fresh_snapshot(rows,expected,{})['matched'])
    def test_snapshot_cannot_omit_pin(self):
        t,l=self.api();a=self.file('a',b'a');b=self.file('b',b'b');rows=[ref(a),ref(b)];expected={'files':2,'bytes':2,'map_sha256':t.digest(rows)}
        with self.assertRaises(RuntimeError):t.fresh_snapshot(rows[:1],expected,{})
    def test_copy_independent_and_explicit_mapping(self):
        t,l=self.api();a=self.file('provider/a',b'object');row=t.copy_exact(ref(a),self.root/'new/a')
        self.assertEqual(row['logical'],ref(a));self.assertNotEqual(a.stat().st_ino,Path(row['physical']['path']).stat().st_ino)
        self.assertEqual(row['logical']['sha256'],row['physical']['sha256'])
    def test_guarded_rejects_output_outside_new_tool_root(self):
        t,l=self.api()
        stage=ROOT.parent/('out-of-scope-fixture-'+self.root.name);calls=[]
        with self.assertRaises(RuntimeError):t.guarded(stage,lambda:calls.append(1))
        self.assertEqual(calls,[]);self.assertFalse(stage.exists())
    def test_copy_does_not_overwrite(self):
        t,l=self.api();a=self.file('provider/a',b'object');t.copy_exact(ref(a),self.root/'new/a')
        with self.assertRaises(FileExistsError):t.copy_exact(ref(a),self.root/'new/a')
    def test_copy_post_tamper_rejected(self):
        t,l=self.api();a=self.file('provider/a',b'object');row=t.copy_exact(ref(a),self.root/'new/a');Path(row['physical']['path']).write_bytes(b'broken')
        with self.assertRaises(RuntimeError):t.verify_copies([row])
    def test_sticky_failure_never_green_after_restore(self):
        t,l=self.api();stage=self.root/'stage';stage.mkdir()
        def bad():raise RuntimeError('observed integrity mismatch')
        with self.assertRaises(RuntimeError):t.guarded(stage,bad)
        with self.assertRaises(RuntimeError):t.guarded(stage,lambda:'green')
        self.assertFalse((stage/'CURRENT_ACCEPTED_CONTEXT.json').exists())
    def test_failed_copy_produces_no_acceptance(self):
        t,l=self.api();stage=self.root/'stage';stage.mkdir();a=self.file('provider/a',b'x');bad={**ref(a),'sha256':'0'*64}
        with self.assertRaises(RuntimeError):t.guarded(stage,lambda:t.copy_exact(bad,stage/'objects/a'))
        self.assertTrue((stage/'INTEGRITY_FAILED.json').exists());self.assertFalse((stage/'CURRENT_ACCEPTED_CONTEXT.json').exists())
    def test_unregistered_codeobject_exec_refused(self):
        loader=module('revision4_loader');p=self.file('x.py',b'value=1\n');l=loader.SourceLoader({'x':ref(p)})
        code=compile('value=99',str(p),'exec')
        with self.assertRaises(RuntimeError):l.execute(code,{})
    def test_full_transport_files_preserves_original_mode_identity(self):
        t,l=self.api();f=module('fixture_revision4').build(self.root,l);c=l.load('revision4_collect');pending=c.validate_pending(f.anchor,f.family,f.batch,f.parent,f.graph,l)
        col={'parent_catalog':f.parent['project_closure'],'pending':pending,'native_artifacts':[],'lean_path':f.family['lean_path'],'original_batch':f.anchor['batch'],'raw_inputs':[]}
        catalog,native,copies=t.transport_files(col,f.graph,self.root/'new')
        self.assertEqual(len(catalog),3);self.assertEqual(native,[]);self.assertTrue(t.verify_copies(copies)['independent_inodes'])
        self.assertEqual(catalog['ImbalancedChen.Pending']['original_mode_records'][0]['protocol'],f.family['protocol'])
        self.assertFalse((self.root/'new/CURRENT_ACCEPTED_CONTEXT.json').exists())
    def test_synthetic_qualification_accepts_only_after_all_checks(self):
        t,l=self.api();q=module('fixture_revision4').qualification(self.root,l);calls=[]
        def collector(*args):calls.append(1);return q.value
        context=t.qualify(q.contract,q.collected,l,q.stage,collector);v=json.loads(Path(context['path']).read_bytes())
        self.assertEqual(len(calls),2);self.assertEqual(len(v['project_closure']),3);self.assertEqual(v['executor_calls'],0)
        self.assertTrue(v['formal_acceptance']);self.assertIn('qualification_environment_sha256',v);self.assertEqual(v['qualification_environment_sha256'],q.value['qualification_environment_sha256'])
        self.assertTrue((q.stage/'QUALIFIER_INPUTS.json').is_file());self.assertTrue((q.stage/'OUTPUTS_POST.json').is_file())
    def test_synthetic_control_manifest_tamper_no_acceptance(self):
        t,l=self.api();q=module('fixture_revision4').qualification(self.root,l);calls=[]
        def collector(*args):
            calls.append(1)
            if len(calls)==2:(q.stage/'COPY_MAP.json').write_bytes(b'[]')
            return q.value
        with self.assertRaises(RuntimeError):t.qualify(q.contract,q.collected,l,q.stage,collector)
        self.assertFalse((q.stage/'CURRENT_ACCEPTED_CONTEXT.json').exists())
    def test_synthetic_foreign_empty_directory_rejected(self):
        t,l=self.api();q=module('fixture_revision4').qualification(self.root,l);calls=[]
        def collector(*args):
            calls.append(1)
            if len(calls)==2:(q.stage/'foreign').mkdir()
            return q.value
        with self.assertRaises(RuntimeError):t.qualify(q.contract,q.collected,l,q.stage,collector)
        self.assertFalse((q.stage/'CURRENT_ACCEPTED_CONTEXT.json').exists())
    def test_synthetic_post_copy_tamper_no_acceptance(self):
        t,l=self.api();q=module('fixture_revision4').qualification(self.root,l);calls=[]
        def collector(*args):
            calls.append(1)
            if len(calls)==2:(q.stage/'objects/ImbalancedChen/Pending.olean').write_bytes(b'changed')
            return q.value
        with self.assertRaises(RuntimeError):t.qualify(q.contract,q.collected,l,q.stage,collector)
        self.assertFalse((q.stage/'CURRENT_ACCEPTED_CONTEXT.json').exists());self.assertTrue((q.stage/'INTEGRITY_FAILED.json').exists())
    def test_nested_raw_exec_not_source_only(self):
        loader=module('revision4_loader');p=self.file('x.py',b'exec("value=99", globals())\n')
        with self.assertRaises(RuntimeError):loader.SourceLoader({'x':ref(p)}).load('x')

class CLITests(TempCase):
    def setup_cli(self):
        cli=ROOT/'revision4_cli.py';self.assertTrue(cli.exists(),'Missing planned feature: revision4_cli')
        tool=self.root/'tools';tool.mkdir()
        for src in ROOT.glob('revision4_*.py'):shutil.copyfile(src,tool/src.name)
        names={p.stem:ref(p) for p in tool.glob('revision4_*.py') if p.name!='revision4_cli.py'}
        old=Path('/workspace/p26-cell06-source-candidate-20261128/runner')
        names.update({n:ref(old/(n+'.py')) for n in ('evidence','templates','controller')})
        names['checkpoint']=ref(Path('/workspace/p26-cell06-checkpoint-revision3-20261128/checkpoint.py'))
        cli=tool/'revision4_cli.py';lock={'schema':'p26_revision4_source_lock_v1','qualifier':ref(cli),'modules':names,'python':ref(Path(sys.executable).resolve())}
        lp=tool/'SOURCE_LOCK.json';lp.write_text(json.dumps(lock));return tool,cli,lp,lock
    def invoke(self,cli,lp,lock,extra=(),wrapper=False):
        args=['check-code','--qualifier-sha256',lock['qualifier']['sha256'],'--source-lock',str(lp),'--source-lock-sha256',ref(lp)['sha256']]
        for k,v in zip(extra[::2],extra[1::2]):
            if k in args:args[args.index(k)+1]=v
            else:args.extend([k,v])
        env={'PATH':str(Path(sys.executable).parent)+':/usr/bin:/bin','LANG':'C.UTF-8','LC_ALL':'C.UTF-8','TZ':'UTC'}
        if wrapper:
            code="import sys,types;from pathlib import Path;sys.modules['revision4_core']=types.SimpleNamespace(POISON=True);sys.argv="+repr([str(cli),*args])+";exec(compile(Path("+repr(str(cli))+").read_bytes(),"+repr(str(cli))+",'exec'),{'__file__':"+repr(str(cli))+",'__name__':'__main__'})"
            cmd=[sys.executable,'-I','-B','-c',code]
        else:cmd=[sys.executable,'-I','-B',str(cli),*args]
        return subprocess.run(cmd,cwd=self.root,env=env,text=True,capture_output=True)
    def test_cli_bootstrap_reaches_locked_legacy_source(self):
        tool,cli,lp,lock=self.setup_cli();p=self.invoke(cli,lp,lock)
        self.assertEqual(p.returncode,0,p.stderr);self.assertIn('LOCKED_SOURCE_BOOTSTRAP_OK',p.stdout)
        self.assertFalse((tool/'qualifications').exists())
    def test_cli_wrong_external_self_sha_first(self):
        tool,cli,lp,lock=self.setup_cli();lock['qualifier']['sha256']='0'*64;p=self.invoke(cli,lp,lock)
        self.assertNotEqual(p.returncode,0);self.assertIn('qualifier SHA',p.stderr);self.assertFalse((tool/'qualifications').exists())
    def test_cli_wrong_external_lock_sha(self):
        tool,cli,lp,lock=self.setup_cli();p=self.invoke(cli,lp,lock,['--source-lock-sha256','0'*64])
        self.assertNotEqual(p.returncode,0);self.assertIn('SOURCE_LOCK SHA mismatch',p.stderr);self.assertFalse((tool/'qualifications').exists())
    def test_cli_cached_module_and_cwd_poison_ignored(self):
        tool,cli,lp,lock=self.setup_cli();self.file('revision4_core.py',b'raise RuntimeError("CWD_POISON")\n')
        p=self.invoke(cli,lp,lock,wrapper=True);self.assertEqual(p.returncode,0,p.stderr)
    def test_cli_poisoned_valid_pyc_ignored(self):
        import py_compile,importlib.util
        tool,cli,lp,lock=self.setup_cli();target=tool/'revision4_core.py';stat=target.stat();poison=self.file('poison.py',b'raise RuntimeError("PYC_POISON")\n'+b' '* (stat.st_size-32))
        # Make the timestamp/size header match the real source, then install the hostile cache next to it.
        b=poison.read_bytes();poison.write_bytes(b[:stat.st_size].ljust(stat.st_size,b' '));os.utime(poison,ns=(stat.st_atime_ns,stat.st_mtime_ns))
        cache=Path(importlib.util.cache_from_source(str(target)));cache.parent.mkdir();py_compile.compile(str(poison),cfile=str(cache),dfile=str(target),doraise=True)
        p=self.invoke(cli,lp,lock);self.assertEqual(p.returncode,0,p.stderr)
    def test_cli_local_source_mutation_refused(self):
        tool,cli,lp,lock=self.setup_cli();(tool/'revision4_core.py').write_bytes(b'raise RuntimeError("ALTERED")\n');p=self.invoke(cli,lp,lock)
        self.assertNotEqual(p.returncode,0);self.assertFalse((tool/'qualifications').exists())
    def test_cli_bad_contract_sha_writes_no_stage(self):
        tool,cli,lp,lock=self.setup_cli();contract=tool/'INPUT.json';contract.write_text('{}');args=['collect','--qualifier-sha256',lock['qualifier']['sha256'],'--source-lock',str(lp),'--source-lock-sha256',ref(lp)['sha256'],'--contract',str(contract),'--contract-sha256','0'*64]
        p=subprocess.run([sys.executable,'-I','-B',str(cli),*args],env={'PATH':str(Path(sys.executable).parent)+':/usr/bin:/bin','LANG':'C.UTF-8','LC_ALL':'C.UTF-8','TZ':'UTC'},text=True,capture_output=True)
        self.assertNotEqual(p.returncode,0);self.assertIn('External SHA mismatch',p.stderr);self.assertFalse((tool/'qualifications').exists())
    def test_cli_dotdot_contract_stage_refused_before_marker(self):
        tool,cli,lp,lock=self.setup_cli();contract=tool/'INPUT.json';contract.write_text(json.dumps({'source_lock':ref(lp),'stage':str(tool/'qualifications/../escape'),'qualification_env':{}}));args=['collect','--qualifier-sha256',lock['qualifier']['sha256'],'--source-lock',str(lp),'--source-lock-sha256',ref(lp)['sha256'],'--contract',str(contract),'--contract-sha256',ref(contract)['sha256']]
        p=subprocess.run([sys.executable,'-I','-B',str(cli),*args],env={'PATH':str(Path(sys.executable).parent)+':/usr/bin:/bin','LANG':'C.UTF-8','LC_ALL':'C.UTF-8','TZ':'UTC'},text=True,capture_output=True)
        self.assertNotEqual(p.returncode,0);self.assertIn('Dotdot',p.stderr);self.assertFalse((tool/'qualifications').exists())
    def test_cli_no_isolation_refused(self):
        tool,cli,lp,lock=self.setup_cli();p=subprocess.run([sys.executable,'-B',str(cli),'--help'],text=True,capture_output=True)
        self.assertNotEqual(p.returncode,0);self.assertIn('isolated',p.stderr)

if __name__=='__main__':unittest.main(verbosity=2)
