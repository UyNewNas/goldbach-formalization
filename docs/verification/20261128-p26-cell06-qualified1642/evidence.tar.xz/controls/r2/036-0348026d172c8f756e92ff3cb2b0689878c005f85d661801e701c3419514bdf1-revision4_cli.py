#!/usr/bin/env python3
"""Externally anchored isolated source-only qualifier. No proof execution API."""
import sys
if not sys.flags.isolated or not sys.dont_write_bytecode:
    raise SystemExit('Use isolated python -I -B; no unlocked local/PYC bootstrap imports.')
import hashlib, json, os, types
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def fail(message):raise SystemExit(message)
def pairs(rows):
    d={}
    for k,v in rows:
        if k in d:fail('Duplicate source-lock/contract key')
        d[k]=v
    return d

def json_raw(raw):return json.loads(raw,object_pairs_hook=pairs,parse_constant=lambda x:fail('Nonfinite JSON'))
def raw_pin(path,raw):return {'path':str(Path(path).absolute()),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def pinned(item):
    raw=Path(item['path']).read_bytes()
    if raw_pin(item['path'],raw)!=item:fail('Source/runtime pin mismatch: '+item['path'])
    return raw

def main():
    if sys.argv[1:]==['--help']:
        print('check-code | collect | qualify --qualifier-sha256 SHA --source-lock PATH --source-lock-sha256 SHA [--contract PATH --contract-sha256 SHA] [--collected-sha256 SHA]');return
    args=sys.argv[1:]
    if not args or args[0] not in ('check-code','collect','qualify'):fail('Explicit qualifier command required')
    command=args.pop(0);options={}
    if len(args)%2:fail('Expected flag/value pairs')
    for k,v in zip(args[::2],args[1::2]):
        if not k.startswith('--') or k in options:fail('Duplicate/invalid flag')
        options[k]=v
    allowed={'--qualifier-sha256','--source-lock','--source-lock-sha256','--contract','--contract-sha256','--collected-sha256'}
    if set(options)-allowed:fail('Unknown qualifier flag')
    for k in ('--qualifier-sha256','--source-lock','--source-lock-sha256'):
        if k not in options:fail('Missing external SHA argument: '+k)
    # No local module has been imported or compiled before both external roots match.
    own_raw=Path(__file__).read_bytes();own=raw_pin(__file__,own_raw)
    if own['sha256']!=options['--qualifier-sha256']:fail('External qualifier SHA mismatch')
    lock_path=Path(options['--source-lock']).absolute();lock_raw=lock_path.read_bytes();lock_pin=raw_pin(lock_path,lock_raw)
    if lock_pin['sha256']!=options['--source-lock-sha256']:fail('External SOURCE_LOCK SHA mismatch')
    lock=json_raw(lock_raw)
    if lock['schema']!='p26_revision4_source_lock_v1' or lock['qualifier']!=own:fail('Source-lock qualifier identity mismatch')
    for item in lock['modules'].values():pinned(item)
    if lock['python']['path']!=str(Path(sys.executable).resolve()):fail('Python runtime path mismatch')
    pinned(lock['python'])
    allowed_env={'PATH','HOME','TMPDIR','LANG','LC_ALL','TZ'}
    if set(os.environ)-allowed_env:fail('Qualifier requires explicit allowlist environment; inherited extra keys refused')
    loader_pin=lock['modules']['revision4_loader'];bootstrap=types.ModuleType('revision4_bootstrap_loader');bootstrap.__file__=loader_pin['path'];bootstrap.__cached__=None
    exec(compile(pinned(loader_pin),loader_pin['path'],'exec',dont_inherit=True),bootstrap.__dict__)
    loader=bootstrap.SourceLoader(lock['modules']);core=loader.load('revision4_core')
    with core.ProcessGuard() as process:
        collector=loader.load('revision4_collect');transport=loader.load('revision4_transport')
        if command=='check-code':
            with core.WriteGuard(ROOT/'.no-bootstrap-writes'):
                p=loader.load('checkpoint');p.old_parsers(p.Readonly())
            print(json.dumps({'status':'LOCKED_SOURCE_BOOTSTRAP_OK','source_lock':lock_pin,'executed_source_pins':loader.executed,'executor_calls':process.attempts,'Lean_commands':0,'formal_acceptance':False}));return
        if '--contract' not in options or '--contract-sha256' not in options:fail('External contract path/SHA required')
        contract_pin=core.external(options['--contract'],options['--contract-sha256']);contract=core.strict_json(Path(contract_pin['path']).read_bytes());contract['_anchor']=contract_pin
        core.require(contract['source_lock']==lock_pin,'Contract source lock mismatch')
        stage=core.safe_stage(ROOT/'qualifications',contract['stage'])
        core.require(stage.parent==ROOT/'qualifications','One exclusive qualification stage required')
        expected_env=contract['qualification_env']
        core.require(set(expected_env)==allowed_env and dict(os.environ)==expected_env,'Final qualification environment differs from explicit allowlist')
        core.require(expected_env['HOME']==str(stage/'home') and expected_env['TMPDIR']==str(stage/'tmp') and expected_env['TZ']=='UTC'
                     and expected_env['LANG']==expected_env['LC_ALL']=='C.UTF-8' and expected_env['PATH']==str(Path(sys.executable).resolve().parent)+':/usr/bin:/bin','Noncanonical qualification environment')
        if command=='collect':
            core.require(not stage.exists(),'Exclusive fresh collect stage required')
            with core.WriteGuard(stage.parent):stage.parent.mkdir(exist_ok=True)
            with core.WriteGuard(stage):
                stage.mkdir();(stage/'home').mkdir();(stage/'tmp').mkdir()
                result=transport.guarded(stage,lambda:core.dump(stage/'COLLECTED.json',collector.collect(contract,loader)))
            print(json.dumps({'collected':result,'formal_acceptance':False,'executor_calls':process.attempts,'Lean_commands':0}));return
        if '--collected-sha256' not in options:fail('External collected SHA required')
        collected=core.external(stage/'COLLECTED.json',options['--collected-sha256'])
        with core.WriteGuard(stage):result=transport.qualify(contract,collected,loader,stage)
        core.require(process.attempts==0,'Process attempt invalidated qualification')
        print(json.dumps({'accepted_context':result,'formal_acceptance':True,'P2_6_complete':False,'executor_calls':0,'Lean_commands':0}))

if __name__=='__main__':main()
