"""Tiny actual on-disk metadata fixtures. No proof execution or production data."""
from pathlib import Path
from types import SimpleNamespace
import json,hashlib
ROOT=Path(__file__).resolve().parent
NODE='ImbalancedChen.Pending';SHAPE='ImbalancedChen.Shape'
def pin(p):b=Path(p).read_bytes();return {'path':str(Path(p).absolute()),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def write(p,value):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n');return pin(p)
def raw(p,b):p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return pin(p)
def build(root,loader,bad=None):
 p=loader.load('checkpoint');old=SimpleNamespace(evidence=loader.load('evidence'),controller=loader.load('controller'))
 root=Path(root);familyroot=root/'old';epoch=familyroot/'batches/tail'
 for name in ['helpers','state','steps','accepted-contexts','home','tmp']:(epoch/name).mkdir(parents=True,exist_ok=True)
 accepted='ImbalancedChen.Accepted';data='ImbalancedChen.Data';catalog={}
 for owner in [accepted,data]:
  source=raw(familyroot/'project'/Path(owner.replace('.','/')).with_suffix('.lean'),b'def x := 1\n');obj=raw(familyroot/'objects'/Path(owner.replace('.','/')).with_suffix('.olean'),owner.encode())
  catalog[owner]={'source':source,'selected_object':obj,'origin':'original_accepted_provenance_without_normal_receipt'}
 sources={};graph={'entries':{}}
 for owner in [NODE,SHAPE]:
  sources[owner]=raw(familyroot/'project'/Path(owner.replace('.','/')).with_suffix('.lean'),owner.encode())
  logical=raw(root/'logical'/Path(owner.replace('.','/')).with_suffix('.lean'),b'different' if bad=='source_mapping' and owner==NODE else owner.encode());graph['entries'][owner]={'source':logical}
 runtime={key:raw(root/key,key.encode()) for key in ['lean','leanchecker']}
 family={'protocol':p.NEW_PROTOCOL,'family_root':str(familyroot),'environment':{'sysroot':str(root/'sysroot')},'lean_path':str(familyroot/'objects'),'runtime':runtime,'rss_gib':12,'wall_seconds':2400,'external_modules':[],'code_pins':[],'project_sources':sources,'normal_barriers':[{'module':data,'status':'old_normal_forbidden','object':catalog[data]['selected_object']}],'native_artifacts':[]}
 family['base_global_inputs']=write(root/'BASE_GLOBAL.json',[*runtime.values(),*[v[k] for v in catalog.values() for k in ('source','selected_object')],*sources.values()])
 family['project_files']=[str(p) for p in (familyroot/'project').rglob('*') if p.is_file()]
 fp=write(familyroot/'FAMILY.json',family);pp=write(root/'PARENT.json',{'formal_acceptance':True,'project_closure':catalog,'native_artifacts':[],'runtime':runtime,'lean_path':family['lean_path']})
 helpers=[raw(epoch/'helpers'/(o+'.Owned.lean'),('helper '+o).encode()) for o in [NODE,SHAPE]]
 whitelist=write(epoch/'WHITELIST.json',[NODE,SHAPE]);selector=write(epoch/'GLOBAL_INPUTS.json',{'family':fp,'parent_context':pp,'baseline':family['base_global_inputs'],'prefix_inputs':[],'batch_static':helpers+[whitelist]})
 env=p.env_for(epoch,family);batch={'protocol':family['protocol'],'family':fp,'owners':[NODE,SHAPE],'parent_context':pp,'helpers':helpers,'global_inputs':selector,'environment_sha256':p.env_sha(env)}
 bp=write(epoch/'BATCH.json',batch);grows=p.unique(json.loads(Path(family['base_global_inputs']['path']).read_bytes())+helpers+[whitelist,selector,family['base_global_inputs'],fp,bp]);pre=write(epoch/'state/PRE.json',{'purpose':'PRE','matched':True,'family':fp,'batch':bp,'global_inputs':selector,'mismatches':[],'files_checked':len(grows),'bytes_read':sum(x['bytes'] for x in grows),'actual_map_sha256':p.digest_map(grows)});write(epoch/'state/GLOBAL_PRE.json',{'snapshot':pre,'formal_acceptance':False});batch['_pre']=pre
 history=[];pending={};modes=[]
 decl={'module':NODE,'name':NODE+'.lemma','type':'True','axioms':[],'unsafe':False,'partial':False,'axiom':False}
 shared={**decl,'name':'ImbalancedChen.Shared','canonical_module':accepted,'identical_metadata':True,'proof_body_kernel_checked':True}
 inventory={'module':NODE,'environment':[decl['name']],'shared':[shared['name']],'serialized':[decl['name'],shared['name']]}
 def audit_text(sharedflag=True):
  rows=[('IMPORTS',[*catalog,NODE]),('INVENTORY',inventory),('DECL',decl),('SHARED',{**shared,'proof_body_kernel_checked':sharedflag}),('COMPLETE',{'module':NODE,'count':1,'shared_count':1,'serialized_count':2})]
  return '\n'.join('P26_CELL06_AUDIT_'+k+' '+json.dumps(v) for k,v in rows)+'\n'
 for owner,mode in [(NODE,'normal'),(NODE,'stock-leanchecker'),(NODE,'full-owned'),(SHAPE,'normal')]:
  attempt=epoch/'steps'/owner/mode/'attempt';attempt.mkdir(parents=True)
  local=p.exact_local(family,batch,epoch,owner,history,pending);lp=write(attempt/'LOCAL_INPUTS.json',local)
  ident={'protocol':family['protocol'],'family':fp,'batch':bp,'key':owner,'mode':mode,'global_validation_scope':'batch_boundary','batch_pre':pre,'environment_sha256':batch['environment_sha256'],'argv':p.argv_for(epoch,family,owner,mode),'cwd':str(familyroot/'project'),'timeout':2400,'rss_bytes':12*1024**3}
  if bad=='identity' and owner==NODE and mode=='normal':ident['mode']='foreign'
  command=write(attempt/'COMMAND.json',{'identity':ident,'actual_argv':[str(attempt/'normal.olean') if x=='__NORMAL_OUTPUT__' else x for x in ident['argv']],'local_inputs':lp,'started_unix_ns':1})
  text=audit_text() if mode=='full-owned' else 'okay\n' if owner==NODE else 'Fin facet.size\nFin face.vertices.size\n'
  if bad=='shared_body' and mode=='full-owned':text=audit_text(False)
  log=raw(attempt/'output.log',text.encode());obj=raw(attempt/'normal.olean',b'exact object') if owner==NODE and mode=='normal' else None
  proc={'exit_code':0 if owner==NODE else 1,'stop_reason':None,'seconds':1.0,'sampled_peak_tree_rss_bytes':64}
  returned={**proc}
  if bad=='return_exit' and owner==NODE and mode=='normal':returned['exit_code']=1
  ret=write(attempt/'PROCESS_RETURN.json',{'protocol':family['protocol'],'identity':ident,'process_result':returned,'command':command,'log':log,'object':obj,'status':'PROCESS_RETURNED_PENDING_LOCAL_AND_GLOBAL_CHECKS','formal_acceptance':False})
  result=write(attempt/'RESULT.json',{**proc,'protocol':family['protocol'],'global_validation_scope':'batch_boundary','command':command,'process_return':ret,'log':log,'local_post':{'inputs':lp,'all_local_files_matched':True,'file_count':len(local)},'object':obj,'formal_acceptance':False,'mode_validation_error':None})
  if owner==NODE:
   validated=old.controller.normal_validator(text,{'object':obj}) if mode=='normal' else {'stock_leanchecker_exit_zero':True} if mode=='stock-leanchecker' else old.evidence.validate_audit(audit_text(),[NODE],set(catalog)|{NODE},[])
   marker=write(attempt/'PENDING.json',{'protocol':family['protocol'],'status':'NORMAL_SUCCEEDED_PENDING_GLOBAL' if mode=='normal' else 'PROCESS_VALIDATED_PENDING_GLOBAL','identity':ident,'result':result,'process_return':ret,'validated':validated,'formal_acceptance':False,'batch_post':None,'P2_6_complete':False})
   row={'owner':owner,'mode':mode,'marker':marker,'command':command,'result':result,'process_return':ret,'log':log,'local_inputs':lp,'object':obj,'identity':ident,'validated':validated}
   history.append(row);modes.append(row)
   if mode=='normal':pending[owner]=row;raw(familyroot/'objects'/Path(owner.replace('.','/')).with_suffix('.olean'),b'exact object')
  else:failed={'owner':owner,'mode':mode,'attempt':str(attempt),'identity':ident,'command':command,'result':result,'process_return':ret,'log':log,'local_inputs':lp,'source':sources[owner],'exit_code':1,'stop_reason':None,'object':None,'pending_receipt':None}
 if bad=='extra_attempt':raw(epoch/'steps'/SHAPE/'normal/unknown/COMMAND.json',b'{}')
 if bad=='old_post':raw(epoch/'state/POST-fake.json',b'{}')
 pins=[pin(x) for x in sorted(epoch.rglob('*')) if x.is_file()]
 anchor={'batch':bp,'family':fp,'accepted_parent':pp,'global_pre_report':pre,'environment_sha256':batch['environment_sha256'],'successful_pending_owner':{'owner':NODE,'source':sources[NODE],'normal_object':modes[0]['object'],'canonical_object':pin(familyroot/'objects'/Path(NODE.replace('.','/')).with_suffix('.olean')),'modes':modes},'failed_normal_tuple':failed,'unstarted_tail_owners':[],'namespace':{'exact_epoch_file_pins':pins}}
 return SimpleNamespace(anchor=anchor,family=family,batch=batch,parent=__import__('json').loads(Path(pp['path']).read_bytes()),graph=graph,epoch=epoch,old=old,parser=p)

def qualification(root,loader):
    from types import SimpleNamespace
    f=build(Path(root)/'provider-fixture',loader);c=loader.load('revision4_collect');core=loader.load('revision4_core')
    pending=c.validate_pending(f.anchor,f.family,f.batch,f.parent,f.graph,loader)
    base=Path(root);stage=base/'stage';stage.mkdir();(stage/'home').mkdir();(stage/'tmp').mkdir()
    mathlib=base/'mathlib';(mathlib/'.git').mkdir(parents=True);raw(mathlib/'.git/HEAD',b'a'*40+b'\n')
    lib=Path(f.family['environment']['sysroot'])/'lib';lib.mkdir(parents=True);runtime=raw(lib/'runtime',b'fixture runtime')
    envlock=write(base/'environment.json',{'mathlib_root':str(mathlib),'mathlib_commit':'a'*40,'lean_path_tail':[],'sysroot':f.family['environment']['sysroot'],'active_search_files':[runtime['path']]})
    graphpin=write(base/'graph.json',f.graph);source_lock=write(base/'source_lock.json',{'fixture':True})
    contract={'protocol':'fixture_transport_only','stage':str(stage),'source_lock':source_lock,'expected_parent_count':2,'expected_transport_count':3,'qualification_env':{}}
    contract['_anchor']=write(base/'contract.json',contract)
    reader=core.Reader();rows=c.original_global_items(reader,f.family,f.anchor['family'],f.batch,f.anchor['batch'])
    value={'contract':contract['_anchor'],'source_lock':source_lock,'parent_catalog':f.parent['project_closure'],'native_artifacts':[],
      'pending':pending,'lean_path':f.family['lean_path'],'runtime':f.family['runtime'],'external_modules':[],
      'original_family':f.anchor['family'],'original_batch':f.anchor['batch'],'new_graph':graphpin,'accepted_parent':f.anchor['accepted_parent'],
      'raw_inputs':[],'environment_lock':envlock,'old_global_expected':{'files':len(rows),'bytes':sum(x['bytes'] for x in rows),'map_sha256':core.digest(rows)},
      'old_global_pre':f.anchor['global_pre_report'],'old_global_selector':f.batch['global_inputs'],
      'membership_barriers':c.membership_barriers(f.parent,2,f.family['normal_barriers']),'failed_release':f.anchor['failed_normal_tuple'],
      'observed_metadata_pins':[contract['_anchor'],source_lock,envlock,graphpin], 'source_mappings':[pending['source_mapping']],
      'qualification_environment_sha256':hashlib.sha256(b'{}').hexdigest()}
    collected=write(stage/'COLLECTED.json',value)
    return SimpleNamespace(f=f,stage=stage,contract=contract,collected=collected,value=value)
