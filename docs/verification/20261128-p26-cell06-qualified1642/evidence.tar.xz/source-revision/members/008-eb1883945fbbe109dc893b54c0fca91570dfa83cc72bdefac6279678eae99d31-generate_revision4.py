"""Host-only source patch and closed-attempt diagnosis. Never executes Lean/G/MCP."""
from pathlib import Path
import ast, copy, difflib, hashlib, json, math, re, types

OUT=Path('/workspace/p26-cell06-source-revision-20261128/v4')
V3=Path('/workspace/p26-cell06-source-revision-20261128/v3')
FAMILY=Path('/workspace/p26-cell06-family-revision3-20261128/families/main')
EPOCH=FAMILY/'batches/geometry8p'
SHAPE='ImbalancedChen.P2OriginalSaving19Geometry06ScalableShapeArrays'
NODE='ImbalancedChen.P2OriginalSaving19Geometry06ScalableRowsNode000To014'
MODES=('normal','stock-leanchecker','full-owned')
EXPECTED_GRAPH='b072272b21689ae65097f2c14b553412c5650813a8a5fe3b7116b29363f10927'
EXPECTED_BATCH='59145573bf0b4ece807371f3ecd3658baf62fcdbc21e6822c83dd253a9e32542'
EXPECTED_PARENT='71cc6494427e0c01b48e9f33262667b00f9804aba444336fd3bf9d7db083c22e'
seen={}
def pin(path):
    path=Path(path);h=hashlib.sha256();size=0
    with path.open('rb') as f:
        while b:=f.read(1024*1024):h.update(b);size+=len(b)
    return {'path':str(path),'bytes':size,'sha256':h.hexdigest()}
def check(item):
    old=seen.setdefault(item['path'],item);assert old==item,('Pin conflict',item)
    if item['path'] not in checked:
        assert pin(item['path'])==item,('Actual bytes differ',item);checked.add(item['path'])
    return item
checked=set()
def read(path):return json.loads(Path(path).read_bytes())
def dump(name,value):
    path=OUT/name;path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x') as f:json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n')
    return pin(path)
def unique(rows):
    values={}
    for row in rows:assert values.setdefault(row['path'],row)==row
    return [values[k] for k in sorted(values)]
def capture_namespace():
    return {str(p):{'size':p.stat().st_size,'mtime_ns':p.stat().st_mtime_ns,'inode':p.stat().st_ino}
            for p in sorted(EPOCH.rglob('*')) if p.is_file()}
namespace_before=capture_namespace()
graph_pin=pin(V3/'CANDIDATE_GRAPH_v3.json');assert graph_pin['sha256']==EXPECTED_GRAPH
graph=read(graph_pin['path']);batch_pin=pin(EPOCH/'BATCH.json');assert batch_pin['sha256']==EXPECTED_BATCH
batch=read(batch_pin['path']);assert batch['parent_context']['sha256']==EXPECTED_PARENT
check(batch['parent_context']);parent=read(batch['parent_context']['path']);assert parent['formal_acceptance'] is True and len(parent['project_closure'])==1641
check(batch['family']);family=read(batch['family']['path']);assert batch['owners'][:2]==[NODE,SHAPE]
assert not (EPOCH/'state/BATCH_ACCEPTED.json').exists() and not list((EPOCH/'accepted-contexts').iterdir())
assert {p.name for p in (EPOCH/'state').iterdir()}=={'GLOBAL_PRE.json','PRE-1795850509797233596.json'}
pre_anchor=read(EPOCH/'state/GLOBAL_PRE.json');check(pre_anchor['snapshot']);pre=read(pre_anchor['snapshot']['path'])
assert pre['purpose']=='PRE' and pre['matched'] is True and pre['mismatches']==[] and pre['batch']==batch_pin
check(batch['global_inputs']);selector=read(batch['global_inputs']['path'])
assert selector['family']==batch['family'] and selector['parent_context']==batch['parent_context']
assert selector['baseline']==family['base_global_inputs']
# No expansion or checksum of the whole global baseline occurs here.
runner=Path('/workspace/p26-cell06-source-candidate-20261128/runner')
delivery_pin=pin(runner/'DELIVERY_MANIFEST.json');assert delivery_pin['sha256']=='d14f188c6e011a5576db429e79378bb3bf9b1d8d080ff37584cbbb699008b462'
known={row['path']:row for row in read(delivery_pin['path'])['members']}
ep=check(known[str(runner/'evidence.py')]);evidence=types.ModuleType('revision4_pure_audit_parser');evidence.__file__=ep['path'];evidence.__cached__=None
exec(compile(Path(ep['path']).read_bytes(),ep['path'],'exec',dont_inherit=True),evidence.__dict__)
cp=check(known[str(runner/'controller.py')]);tree=ast.parse(Path(cp['path']).read_bytes());fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='normal_validator')
normal_globals={'require':evidence.require,'re':re};exec(compile(ast.Module(body=[fn],type_ignores=[]),cp['path'],'exec'),normal_globals)
sysroot=family['environment']['sysroot'];env={'HOME':str(EPOCH/'home'),'TMPDIR':str(EPOCH/'tmp'),'LANG':'C.UTF-8','LC_ALL':'C.UTF-8','TZ':'UTC','LEAN_PATH':family['lean_path'],'LEAN_NUM_THREADS':'1','OMP_NUM_THREADS':'1','LEAN_SYSROOT':sysroot,'PATH':sysroot+'/bin:/usr/bin:/bin'}
env_sha=hashlib.sha256(json.dumps(env,sort_keys=True,separators=(',',':')).encode()).hexdigest();assert env_sha==batch['environment_sha256']
flags=['--trust=0','-DwarningAsError=true','-j1',f'-M{family["rss_gib"]*1024}','-DmaxRecDepth=1000000','-DmaxHeartbeats=0']
history=[];pending={};successful=[];failed=None
for owner in batch['owners']:
    for mode in MODES:
        base=EPOCH/'steps'/owner/mode
        attempts=list(base.iterdir()) if base.exists() else []
        if owner not in (NODE,SHAPE) or (owner==SHAPE and mode!='normal'):
            assert not attempts;continue
        assert len(attempts)==1;attempt=attempts[0]
        command=read(attempt/'COMMAND.json');result=read(attempt/'RESULT.json');returned=read(attempt/'PROCESS_RETURN.json')
        helper=next(p for p in batch['helpers'] if p['path']==str(EPOCH/'helpers'/(owner+'.Owned.lean')))
        argv=([family['runtime']['lean']['path'],*flags,'-o','__NORMAL_OUTPUT__',str(FAMILY/'project'/Path(owner.replace('.','/')).with_suffix('.lean'))] if mode=='normal' else [family['runtime']['leanchecker']['path'],'--verbose',owner] if mode=='stock-leanchecker' else [family['runtime']['lean']['path'],*flags,helper['path']])
        identity={'protocol':family['protocol'],'family':batch['family'],'batch':batch_pin,'key':owner,'mode':mode,'global_validation_scope':'batch_boundary','batch_pre':pre_anchor['snapshot'],'environment_sha256':env_sha,'argv':argv,'cwd':str(FAMILY/'project'),'timeout':family['wall_seconds'],'rss_bytes':family['rss_gib']*1024**3}
        assert command['identity']==identity and returned['identity']==identity
        assert command['actual_argv']==[str(attempt/'normal.olean') if v=='__NORMAL_OUTPUT__' else v for v in argv]
        local_pin=pin(attempt/'LOCAL_INPUTS.json');assert command['local_inputs']==local_pin;local=read(local_pin['path'])
        expected=[family['project_sources'][owner],helper,*family['code_pins'],*family['runtime'].values()]
        for row in history:
            expected += [row[k] for k in ('marker','result','command','log','local_inputs','process_return')]
            if row['object']:expected.append(row['object'])
        for module,row in pending.items():expected += [row['object'],{**row['object'],'path':str(FAMILY/'objects'/Path(module.replace('.','/')).with_suffix('.olean'))}]
        assert local==unique(expected)
        for row in local:check(row)
        for k,file in [('command','COMMAND.json'),('process_return','PROCESS_RETURN.json'),('log','output.log')]:assert result[k]==pin(attempt/file);check(result[k])
        assert result['protocol']==family['protocol'] and result['global_validation_scope']=='batch_boundary' and result['formal_acceptance'] is False and 'postcheck' not in result
        assert result['local_post']=={'inputs':local_pin,'all_local_files_matched':True,'file_count':len(local)}
        assert returned['protocol']==family['protocol'] and returned['command']==result['command'] and returned['log']==result['log'] and returned['object']==result.get('object') and returned['formal_acceptance'] is False
        assert returned['status']=='PROCESS_RETURNED_PENDING_LOCAL_AND_GLOBAL_CHECKS'
        fields={'exit_code','stop_reason','seconds','sampled_peak_tree_rss_bytes'};assert set(returned['process_result'])==fields
        assert returned['process_result']=={k:result[k] for k in fields}
        assert type(result['exit_code']) is int and result['stop_reason'] is None and math.isfinite(result['seconds']) and result['seconds']>=0 and type(result['sampled_peak_tree_rss_bytes']) is int
        record={'owner':owner,'mode':mode,'command':pin(attempt/'COMMAND.json'),'result':pin(attempt/'RESULT.json'),'process_return':pin(attempt/'PROCESS_RETURN.json'),'log':pin(attempt/'output.log'),'local_inputs':local_pin,'object':result.get('object'),'old_identity':identity,'process':returned['process_result']}
        if owner==NODE:
            assert result['exit_code']==0 and result['mode_validation_error'] is None
            assert (attempt/'PENDING.json').is_file();marker=read(attempt/'PENDING.json');record['marker']=pin(attempt/'PENDING.json')
            assert marker['identity']==identity and marker['result']==record['result'] and marker['process_return']==record['process_return'] and marker['formal_acceptance'] is False and marker['batch_post'] is None and marker['P2_6_complete'] is False
            assert marker['status']==('NORMAL_SUCCEEDED_PENDING_GLOBAL' if mode=='normal' else 'PROCESS_VALIDATED_PENDING_GLOBAL')
            text=Path(record['log']['path']).read_text();assert 'sorryAx' not in text
            if mode=='normal':
                assert record['object']==pin(attempt/'normal.olean');check(record['object']);parsed=normal_globals['normal_validator'](text,result)
            elif mode=='stock-leanchecker':assert record['object'] is None;parsed={'stock_leanchecker_exit_zero':True}
            else:
                assert record['object'] is None
                parsed=evidence.validate_audit(text,[NODE],set(parent['project_closure'])|{NODE},family['external_modules'])
            assert marker['validated']==parsed
            record['audit_summary']={k:parsed[k] for k in ('canonical_count','shared_occurrences','modules') if k in parsed}
            successful.append(record);history.append(record)
            if mode=='normal':pending[owner]=record
        else:
            assert attempt.name=='1795850553477374435-63a4ed6a' and result['exit_code']==1 and result.get('object') is None
            assert not (attempt/'normal.olean').exists() and not (attempt/'PENDING.json').exists()
            assert {p.name for p in attempt.iterdir()}=={'COMMAND.json','LOCAL_INPUTS.json','PROCESS_RETURN.json','RESULT.json','output.log'}
            assert 'Fin facet.size' in Path(record['log']['path']).read_text() and 'Fin face.vertices.size' in Path(record['log']['path']).read_text()
            failed=record
assert len(successful)==3 and failed is not None
normal=successful[0]['object'];canonical={**normal,'path':str(FAMILY/'objects'/Path(NODE.replace('.','/')).with_suffix('.olean'))};check(canonical)
expected_objects={v['selected_object']['path'] for v in parent['project_closure'].values()}|{v['path'] for v in parent['native_artifacts']}|{canonical['path']}
actual_objects={str(p) for p in (FAMILY/'objects').rglob('*') if p.is_file()};assert actual_objects==expected_objects
assert {str(p) for p in (FAMILY/'project').rglob('*') if p.is_file()}==set(family['project_files'])
assert {p.name for p in (EPOCH/'steps').iterdir()}=={NODE,SHAPE}
all_epoch_pins=[pin(p) for p in sorted(EPOCH.rglob('*')) if p.is_file()]
expected_files={batch_pin['path'],batch['global_inputs']['path'],str(EPOCH/'WHITELIST.json'),str(EPOCH/'state/GLOBAL_PRE.json'),pre_anchor['snapshot']['path']}|{p['path'] for p in batch['helpers']}
for row in successful:expected_files|={row[k]['path'] for k in ('command','result','process_return','log','local_inputs','marker')};expected_files|={row['object']['path']} if row['object'] else set()
expected_files|={failed[k]['path'] for k in ('command','result','process_return','log','local_inputs')};assert set(namespace_before)==expected_files
working=parent['project_closure']['ImbalancedChen.P2OriginalSaving19Geometry05ScalableShapeArrays']['source'];check(working)
old_source=graph['entries'][SHAPE]['source'];check(old_source);raw=Path(old_source['path']).read_bytes();assert pin(FAMILY/'project'/Path(SHAPE.replace('.','/')).with_suffix('.lean'))['sha256']==old_source['sha256']
changes=[(b'  simpa only [h.1] using h.2.2\n',b'  intro i\n  exact h.2.2 \xe2\x9f\xa8i.val, h.1 \xe2\x96\xb8 i.isLt\xe2\x9f\xa9\n'),(b'  simpa only [h.1] using h.2.2.1\n',b'  intro i\n  exact h.2.2.1 \xe2\x9f\xa8i.val, h.1 \xe2\x96\xb8 i.isLt\xe2\x9f\xa9\n')]
new=raw
for before,after in changes:assert new.count(before)==1;new=new.replace(before,after,1)
working_bytes=Path(working['path']).read_bytes()
for _,after in changes:assert after in working_bytes
newpath=OUT/'project'/Path(SHAPE.replace('.','/')).with_suffix('.lean');newpath.parent.mkdir(parents=True,exist_ok=True)
with newpath.open('xb') as f:f.write(new)
new_source=pin(newpath)
assert raw.count(b'\r')==new.count(b'\r')==0
assert re.findall(rb'^import (\S+)$',raw,re.M)==re.findall(rb'^import (\S+)$',new,re.M)
assert re.findall(rb'^(?:noncomputable )?(?:def|theorem|abbrev|structure) [^\n]*',raw,re.M)==re.findall(rb'^(?:noncomputable )?(?:def|theorem|abbrev|structure) [^\n]*',new,re.M)
assert not re.search(rb'\b(?:sorry|admit|native_decide)\b|^\s*(?:axiom|unsafe|partial)\b',new,re.M)
for before,after in reversed(changes):new=new.replace(after,before,1)
assert new==raw
for row in graph['entries'].values():check(row['source'])
change={'module':SHAPE,'old_source':old_source,'new_source':new_source,'proof_bodies_only':True,'declaration_types_imports_data_unchanged':True,'replacement_count':2,'working_accepted_reference':working,'replacement':'Explicitly intro Fin actual.size index and transport its bound by h.1, matching accepted Cell05 proof.'}
geom_pin=graph['candidate_manifests'][0];geom=read(geom_pin['path']);newgeom=copy.deepcopy(geom)
assert len(newgeom['owners'])==153
for row in newgeom['owners']:
    if row['module']==SHAPE:assert row['source']==old_source;row['source']=new_source
newgeom.update(source_revision=4,prior_source_manifest=geom_pin,revision_generator=pin(__file__),revision_scope=[change],inherited_revision_scope=geom.get('revision_scope',[]),scope='One unaccepted ShapeArrays source: two Fin dependent-index proof-body repairs; all other v3 source bytes unchanged; no Lean acceptance.',unverified=['The changed ShapeArrays candidate has not been run in Lean.','Historical prior source manifests/acceptances remain their original evidence; this manifest adds no formal credit.'])
newgeom_pin=dump('GEOMETRY_SOURCE_MANIFEST_v4.json',newgeom)
newgraph=copy.deepcopy(graph);newgraph['entries'][SHAPE]['source']=new_source
newgraph.update(candidate_revision=4,prior_candidate_graph=graph_pin,source_revision_changes=[change],revision_parent_accepted_context=batch['parent_context'],accepted_project_union_at_revision=1641,scope='Same334-module graph; one unaccepted ShapeArrays module has exactly two proof-body Fin index transports. No statement/import/data/row changes; no new acceptance.')
newgraph['candidate_manifests'][0]=newgeom_pin
assert len(newgraph['entries'])==334 and newgraph['topological_order']==graph['topological_order']
assert [k for k in graph['entries'] if graph['entries'][k]!=newgraph['entries'][k]]==[SHAPE]
available=set(parent['project_closure']);all_modules=available|set(newgraph['entries'])
for module in newgraph['topological_order']:
    row=newgraph['entries'][module];source=Path(row['source']['path']).read_bytes()
    imports=[v.decode() for v in re.findall(rb'^import ([A-Za-z0-9_.]+)\s*$',source,re.M)]
    assert imports==row['imports'],module
    assert {v for v in imports if v.startswith('ImbalancedChen.')}<=available,module
    available.add(module)
newgraph_pin=dump('CANDIDATE_GRAPH_v4.json',newgraph)
Path(OUT/'PROOF_BODY_DIFF.patch').open('x').write(''.join(difflib.unified_diff(raw.decode().splitlines(True),Path(new_source['path']).read_text().splitlines(True),fromfile=old_source['path'],tofile=new_source['path'])))
assert capture_namespace()==namespace_before
prefix={'schema':'p26_unsealed_verified_mode_prefix_anchor_v4_candidate','status':'OLD_PROTOCOL_PENDING_THREE_MODES_NO_OLD_GLOBAL_POST','old_family':batch['family'],'old_batch':batch_pin,'old_parent_context':batch['parent_context'],'old_graph':graph_pin,'old_global_selector':batch['global_inputs'],'old_global_pre':pre_anchor['snapshot'],'owner':NODE,'old_source':graph['entries'][NODE]['source'],'modes':successful,'permanent_normal':normal,'current_canonical':canonical,'old_batch_formal_acceptance':False,'old_post_exists':False,'old_seal_exists':False,'old_contexts':0,'required_new_qualification':'Fresh complete original oldG bytes readback plus complete exact localD/receipts/current object and formal1641 parent qualification; not performed here.','formal_acceptance':False,'P2_6_complete':False}
prefix_pin=dump('PENDING_PREFIX_ANCHOR.json',prefix)
failed_anchor={'schema':'p26_exact_failed_shapearrays_tuple_v4_candidate','status':'typed_failed_no_object_source_revision','module':SHAPE,'old_family':batch['family'],'old_batch':batch_pin,'old_graph':graph_pin,'old_source':family['project_sources'][SHAPE],'new_graph':newgraph_pin,'new_source':new_source,'command':failed['command'],'local_inputs':failed['local_inputs'],'process_return':failed['process_return'],'result':failed['result'],'log':failed['log'],'old_identity':failed['old_identity'],'exit_code':1,'stop_reason':None,'object':None,'no_pending':True,'attempt_directory_exact_files':5,'formal_acceptance':False,'P2_6_complete':False}
failed_pin=dump('FAILED_TAIL_ANCHOR.json',failed_anchor)
report={'schema':'p26_cell06_source_revision4_host_report_v1','status':'SOURCE_CANDIDATE_ONLY','old_graph':graph_pin,'new_graph':newgraph_pin,'old_geometry_manifest':geom_pin,'new_geometry_manifest':newgeom_pin,'generator':pin(__file__),'source_change':change,'unchanged_source_count':333,'unchanged_source_refs':[{'module':m,'source':r['source']} for m,r in graph['entries'].items() if m!=SHAPE],'pending_prefix_anchor':prefix_pin,'failed_tail_anchor':failed_pin,'actual_closed_epoch_files':all_epoch_pins,'namespace_before':namespace_before,'namespace_after_equal':True,'actual_object_namespace_files':len(actual_objects),'actual_project_namespace_files':len(family['project_files']),'bounded_actual_pin_checks':len(checked),'checked_pins':list(seen.values()),'success_modes':3,'success_mode_process_seconds':sum(r['process']['seconds'] for r in successful),'full_owned_summary':successful[2]['audit_summary'],'typed_failed_modes':1,'unknown_attempts':0,'not_started_owners':batch['owners'][2:],'original_global_pre_report_verified_as_record_only':True,'full_global_selector_expanded':False,'fresh_global_readback_performed':False,'actual_Lean_commands':0,'G_runs':0,'MCP_jobs':0,'source_statements_imports_definitions_data_unchanged':True,'all334_actual_source_hashes_matched':True,'all333_other_source_refs_exactly_v3':True,'all334_imports_and_topology_host_checked':True,'formal_acceptance':False,'P2_6_complete':False}
report_pin=dump('REVISION_REPORT.json',report)
print(json.dumps({'graph':newgraph_pin,'source':new_source,'report':report_pin,'pending_prefix':prefix_pin,'failed_tail':failed_pin,'successful_modes':3,'audit':successful[2]['audit_summary'],'epoch_files':len(all_epoch_pins),'formal_acceptance':False,'P2_6_complete':False},indent=2))
