import ImbalancedChen.P2OriginalSaving16PullingFaceInduction
import Lean.Util.CollectAxioms
open Lean Elab Command in
run_cmd do
  let env ← getEnv
  let modName := `ImbalancedChen.P2OriginalSaving16PullingFaceInduction
  let some idx := env.getModuleIdx? modName | throwError "Missing diagnostic target"
  let names := env.const2ModIdx.fold (init := (#[] : Array Name)) fun ns n i =>
    if i == idx && (env.find? n).isSome then ns.push n else ns
  for n in names.qsort Name.lt do
    let some info := env.find? n | throwError "Missing declaration"
    let ax ← collectAxioms n
    let record := Json.mkObj [("name",toJson n.toString),("unsafe",toJson info.isUnsafe),
      ("partial",toJson info.isPartial),("axiom",toJson info.isAxiom),("transitive_axioms",toJson (ax.map Name.toString))]
    liftIO <| IO.println s!"DIAGNOSTIC_OWNER_FLAG {record.compress}"
