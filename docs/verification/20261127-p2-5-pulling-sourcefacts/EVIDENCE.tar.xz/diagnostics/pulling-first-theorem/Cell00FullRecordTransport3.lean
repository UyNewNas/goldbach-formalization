import ImbalancedChen.P2Saving16Cell00OriginalFloors
import ImbalancedChen.P2Saving16Cell00TypedPulling

/-!
SOURCE ONLY / UNCOMPILED / ZERO FORMAL CREDIT.

Transport the four existing typed Cell00 face-ledger and pulling guards to
the unchanged original archive. The conclusions spell out the original
decoder, face lookup, omitted-pivot child filter, fuel-nine Shape, and
ordered pulling algorithm at archive index zero. No new algorithm or
record is defined, and no finite decision is repeated.

The original payload equality and the typed pulling owner must receive
their actual compilation, kernel replay, and complete owned audits before
this consumer receives proof credit. No Literal96 or global all-fourteen
archive guard is imported. These are finite incidence and row-binding
facts; geometric separation and the integral endpoint remain separate.
-/
namespace ImbalancedChen.P2Saving16Cell00OriginalPulling

open P2OriginalSaving16OriginalArchive (archive)
open P2OriginalSaving16PullingOwnership (FaceRecord decodeFace)
open P2OriginalSaving16PullingFaceInduction (Shape pull)
open P2Saving16Cell00OriginalFloors (cell00_original_payload)

private theorem cell00_face_incidence_shape_at_equal_record
    (target : P2OriginalSaving16OriginalArchive.CellRecord)
    (bound : P2Saving16Cell00TypedPayload.cell00Payload = target) :
    let c := target
    let decodedFaces : Array FaceRecord :=
      (c.faceLedger.mapM decodeFace).toOption.getD #[]
    let record := fun (face : List Nat) =>
      (decodedFaces.toList.find? (fun f => f.vertices.toList == face)).getD default
    let pvt := fun (face : List Nat) => (record face).pivot
    let child := fun (face : List Nat) =>
      (((record face).facetSets.toList.map Array.toList).filter
        (fun candidate => !(candidate.contains (pvt face))))
    let facets := fun (f : Fin c.facetOriginalIndices.size) =>
      (c.facetVertices.getD f.val #[]).toList
    Shape facets pvt child 9 (List.range c.vertices.size) := by
  have typed :
      let c := P2Saving16Cell00TypedPayload.cell00Payload
      let decodedFaces : Array FaceRecord :=
        (c.faceLedger.mapM decodeFace).toOption.getD #[]
      let record := fun (face : List Nat) =>
        (decodedFaces.toList.find? (fun f => f.vertices.toList == face)).getD default
      let pvt := fun (face : List Nat) => (record face).pivot
      let child := fun (face : List Nat) =>
        (((record face).facetSets.toList.map Array.toList).filter
          (fun candidate => !(candidate.contains (pvt face))))
      let facets := fun (f : Fin c.facetOriginalIndices.size) =>
        (c.facetVertices.getD f.val #[]).toList
      Shape facets pvt child 9 (List.range c.vertices.size) := by
    have h : Shape P2Saving16Cell00TypedPulling.facet P2Saving16Cell00TypedPulling.pivot P2Saving16Cell00TypedPulling.children 9 P2Saving16Cell00TypedPulling.whole := P2Saving16Cell00TypedPulling.cell00_face_incidence_shape
    delta P2Saving16Cell00TypedPulling.facet P2Saving16Cell00TypedPulling.pivot P2Saving16Cell00TypedPulling.children P2Saving16Cell00TypedPulling.faceRecord P2Saving16Cell00TypedPulling.faces P2Saving16Cell00TypedPulling.parsedFaces P2Saving16Cell00TypedPulling.whole at h
    exact h
  cases bound
  exact typed

/-- The complete original finite Shape predicate, without a coverage claim. -/
theorem cell00_original_face_incidence_shape :
    let c := archive (0 : Fin 14)
    let decodedFaces : Array FaceRecord :=
      (c.faceLedger.mapM decodeFace).toOption.getD #[]
    let record := fun (face : List Nat) =>
      (decodedFaces.toList.find? (fun f => f.vertices.toList == face)).getD default
    let pvt := fun (face : List Nat) => (record face).pivot
    let child := fun (face : List Nat) =>
      (((record face).facetSets.toList.map Array.toList).filter
        (fun candidate => !(candidate.contains (pvt face))))
    let facets := fun (f : Fin c.facetOriginalIndices.size) =>
      (c.facetVertices.getD f.val #[]).toList
    Shape facets pvt child 9 (List.range c.vertices.size) := by
  exact cell00_face_incidence_shape_at_equal_record (archive (0 : Fin 14)) cell00_original_payload.symm

end ImbalancedChen.P2Saving16Cell00OriginalPulling
