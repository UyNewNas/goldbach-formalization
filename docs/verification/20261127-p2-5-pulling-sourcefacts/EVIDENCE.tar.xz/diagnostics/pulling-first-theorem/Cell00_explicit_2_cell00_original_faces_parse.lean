import ImbalancedChen.P2Saving16Cell00OriginalFloors
import ImbalancedChen.P2Saving16Cell00TypedPulling

/-!
SOURCE ONLY / UNCOMPILED / ZERO FORMAL CREDIT.

Transport the four existing typed Cell00 face-ledger and pulling guards to
the unchanged original archive. The conclusions spell out the original
decoder, face lookup, omitted-pivot child filter, fuel-nine Shape, and
ordered pulling algorithm at archive index zero. No new algorithm or
record is defined, and no finite decision is repeated.

The original payload equality and the typed pulling owner must receive
their actual compilation, kernel replay, and complete owned audits before
this consumer receives proof credit. No Literal96 or global all-fourteen
archive guard is imported. These are finite incidence and row-binding
facts; geometric separation and the integral endpoint remain separate.
-/
namespace ImbalancedChen.P2Saving16Cell00OriginalPulling

open P2OriginalSaving16OriginalArchive (archive)
open P2OriginalSaving16PullingOwnership (FaceRecord decodeFace)
open P2OriginalSaving16PullingFaceInduction (Shape pull)
open P2Saving16Cell00OriginalFloors (cell00_original_payload)

theorem cell00_original_faces_parse :
    (archive (0 : Fin 14)).faceLedger.mapM decodeFace =
      .ok (((archive (0 : Fin 14)).faceLedger.mapM decodeFace).toOption.getD #[]) := by
  exact Eq.subst (α := P2OriginalSaving16OriginalArchive.CellRecord)
    (a := P2Saving16Cell00TypedPayload.cell00Payload) (b := archive (0 : Fin 14))
    (motive := fun cell : P2OriginalSaving16OriginalArchive.CellRecord =>
      (cell).faceLedger.mapM decodeFace =
        .ok (((cell).faceLedger.mapM decodeFace).toOption.getD #[]))
    cell00_original_payload.symm
    P2Saving16Cell00TypedPulling.cell00_faces_parse

end ImbalancedChen.P2Saving16Cell00OriginalPulling
