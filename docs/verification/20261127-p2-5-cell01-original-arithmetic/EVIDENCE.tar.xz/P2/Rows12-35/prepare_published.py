import concurrent.futures,hashlib,json,subprocess,sys
from pathlib import Path
w=Path.cwd();commit=sys.argv[1];assert len(commit)==40 and all(c in '0123456789abcdef' for c in commit)
url='https://raw.githubusercontent.com/UyNewNas/goldbach-formalization/'+commit+'/docs/verification/20261127-p2-5-cell01-decoder/accepted-row-dependencies/'
dl=w/'github-imports';dl.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def fetch(name):
 p=dl/name
 if not p.is_file():
  subprocess.run(['curl','-fsSL','--retry','3','--max-time','60',url+name,'-o',str(p)+'.tmp'],check=True);Path(str(p)+'.tmp').rename(p)
 return p
mf=json.loads(fetch('MANIFEST.json').read_bytes());assert mf['archive_sha256']=='061a8f959d2f1a921ce7eb00a7efcf6bc5a4075774e538d905fc83698cebbdf0' and mf['archive_bytes']==5724777 and mf['project_object_count']==22
mm=fetch(mf['member_manifest']);assert sha(mm)==mf['member_manifest_sha256']=='3fce52d59ddae69274989fda4bfc881a41faf81583df884016c83f7939e0fed4'
with concurrent.futures.ThreadPoolExecutor(3) as jobs:paths=list(jobs.map(fetch,mf['assembly_order']))
for p,r in zip(paths,mf['parts'],strict=True):assert p.name==r['file'] and p.stat().st_size==r['bytes'] and sha(p)==r['sha256']
archive=dl/'objects.ltar';archive.write_bytes(b''.join(p.read_bytes() for p in paths));assert sha(archive)==mf['archive_sha256']
leantar=Path('/workspace/toolchains/lean-4.33.0-rc1-linux/bin/leantar');assert sha(leantar)=='06d613dffd2a6fd996b095bfd835c2bb720886f9eb7e13ed2adddd7df4507bf3'
subprocess.run([str(leantar),'-C',str(w/'lib'),'-x','--jobs','1',str(archive)],check=True)
meta=json.loads(mm.read_bytes());assert len(meta['members'])==22
for r in meta['members']:
 p=w/'lib'/r['path'];assert p.stat().st_size==r['bytes'] and sha(p)==r['sha256']
(w/'exact-row-project-imports.json').write_bytes(mm.read_bytes())
(w/'evidence/PROJECT_IMPORTS_VERIFIED.json').write_text(json.dumps({'publication':commit,'sources_commit':mf['source_commit'],'archive_sha256':sha(archive),'member_manifest_sha256':sha(mm),'verified_project_objects':len(meta['members'])},indent=2)+'\n')
print('verified 22 transported project objects, archive',sha(archive))
