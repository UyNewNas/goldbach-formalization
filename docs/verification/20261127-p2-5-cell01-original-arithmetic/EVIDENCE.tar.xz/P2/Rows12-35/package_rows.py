from pathlib import Path
import hashlib,json,subprocess,tarfile,datetime
w=Path.cwd();ev=w/'evidence'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while s:=f.read(1<<20):h.update(s)
 return h.hexdigest()
def write(p,data):
 with p.open('x') as f:json.dump(data,f,indent=2);f.write('\n')
def verify_external():
 names=json.loads((w/'snapshot.json').read_text())['entries'];count=0
 for e in names:
  b=e['object']['path'];key=e['module'].replace('.','/')+'.olean'
  for x in [e['object'],*e['companions']]:
   p=w/'external-lib'/(key+x['path'][len(b):]) if b.startswith('/mathlib/') else Path(x['path'])
   assert p.stat().st_size==x['bytes'] and sha(p)==x['sha256'],p
   count+=1
 assert count==15936
 return {'modules':len(names),'verified_files':count,'snapshot_sha256':sha(w/'snapshot.json'),'ended_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'mismatches':[]}
out=w/'published-result';out.mkdir(exist_ok=True)
write(out/'EXT_AFTER.json',verify_external())
accepted=[];fails=[]
for i in range(12,36):
 m=f'P2Saving16Cell01Simplex{i:02d}Decode';r=ev/m/'RESULT.json'
 if not r.is_file():
  fails.append(m);continue
 d=json.loads(r.read_bytes());obj=w/'lib/ImbalancedChen'/(m+'.olean');assert d['object_sha256']==sha(obj)
 accepted.append({'module':d['module'],'path':'ImbalancedChen/'+obj.name,'bytes':obj.stat().st_size,'sha256':sha(obj),'owned':d['owned_count'],'axioms':d['transitive_axioms'],'source_sha256':d['source_sha256'],'stages':[{k:s[k] for k in ['stage','elapsed_seconds','exit_code','peak_child_rss_bytes','log_sha256']} for s in d['stages']]})
trace=out/'rows.trace';trace.write_text('{"schemaVersion":"2025-09-10","depHash":"0000000000000000","outputs":{}}\n')
stage=out/'stage';stage.mkdir();(stage/'rows.trace').symlink_to(trace);(stage/'ImbalancedChen').symlink_to(w/'lib/ImbalancedChen',target_is_directory=True)
fmt=out/'objects.ltar';leantar=Path('/workspace/toolchains/lean-4.33.0-rc1-linux/bin/leantar')
if accepted:
 subprocess.run([str(leantar),str(fmt),'rows.trace',*[r['path'] for r in accepted]],cwd=stage,check=True)
 unpack=out/'roundtrip';unpack.mkdir();subprocess.run([str(leantar),'-C',str(unpack),'-x','--jobs','1',str(fmt)],check=True)
 assert all((unpack/r['path']).stat().st_size==r['bytes'] and sha(unpack/r['path'])==r['sha256'] for r in accepted)
selections={'source_commit':'253cd549873b53118e3cd2d91c608b309a221dcd','range':[12,35],'accepted_count':len(accepted),'objects':accepted,'unaccepted_modules':fails,'P2_5_proved':False,'object_ltar_bytes':fmt.stat().st_size if accepted else 0,'object_ltar_sha256':sha(fmt) if accepted else None}
write(out/'ROWS.json',selections)
pack=out/'EXPORT.tar.xz';extras=[w/'run_row.py',w/'prepare_published.py',w/'package_rows.py',w/'exact-row-project-imports.json',w/'template.lean',out/'EXT_AFTER.json',out/'ROWS.json']
if accepted:extras.append(fmt)
with tarfile.open(pack,'x:xz',preset=3) as t:
 for p in extras:t.add(p,arcname=p.name,recursive=False)
 for p in sorted(ev.rglob('*')):
  if p.is_file():t.add(p,arcname='evidence/'+str(p.relative_to(ev)),recursive=False)
 for p in sorted((w/'audits').glob('*.lean')):t.add(p,arcname='audits/'+p.name,recursive=False)
print(json.dumps({'accepted':len(accepted),'unaccepted':fails,'size':pack.stat().st_size,'sha256':sha(pack),'ltar_sha256':selections['object_ltar_sha256']}))
