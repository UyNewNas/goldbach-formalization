import datetime,hashlib,json,os,resource,signal,subprocess,sys,time
from pathlib import Path
w=Path.cwd();n=int(sys.argv[1]);assert 12<=n<=35
name=f'P2Saving16Cell01Simplex{n:02d}Decode';module='ImbalancedChen.'+name
ev=w/'evidence'/name;ev.mkdir()
src=w/'src/ImbalancedChen'/(name+'.lean'); obj=w/'lib/ImbalancedChen'/(name+'.olean')
whole=json.loads((w/'evidence/FIELD_MANIFEST.json').read_bytes());spec,=[r for r in whole['outputs'] if r['module']==module]
lean=Path('/workspace/toolchains/lean-4.33.0-rc1-linux')
math=Path('/workspace/compile-deps/mathlib')
env=dict(os.environ,PATH=str(lean/'bin')+':'+os.environ['PATH'],LEAN_PATH=':'.join(str(p) for p in [w/'lib',w/'external-lib',math/'.lake/build/lib/lean',*[math/'.lake/packages'/s/'.lake/build/lib/lean' for s in ['plausible','LeanSearchClient','importGraph','proofwidgets','aesop','Qq','batteries','Cli']]]))
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(1024*1024):h.update(b)
 return h.hexdigest()
def write(p,out):
 with p.open('x') as f:json.dump(out,f,indent=2);f.write('\n')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
closure=json.loads((w/'exact-row-project-imports.json').read_bytes())
expected={str(w/'lib'/r['path']):r['sha256'] for r in closure['members']}|{str(src):spec['sha256'],str(lean/'bin/lean'):'e8baaa71855a616dc351028f3ad2200051b0671f423a1696a100e809302d5550',str(lean/'bin/leanchecker'):'ed46f21c763051c26f89481096cbaaf5db9665d674d602e3daf3391613ba0e6a',str(w/'template.lean'):'2975fe381dfc6de3b297a67bcc9db9dd064bcad37a0b45ee13bc1fcd957ee85b'}
def snap():
 assert all(sha(Path(p))==h for p,h in expected.items())
 return expected
assert json.loads((w/'evidence/EXT_BEFORE.json').read_text())['verified_files']==15936
assert not obj.exists() and len(closure['members'])==22
tmpl=(w/'template.lean').read_text(); assert tmpl.count('ImbalancedChen.P2Winner9FiniteMomentKernel')==2
audit=w/'audits'/(name+'.lean');audit.write_text(tmpl.replace('ImbalancedChen.P2Winner9FiniteMomentKernel',module));before=snap()
flags=['-t0','-j1','-M13107','-DwarningAsError=true','-DmaxRecDepth=1000000','-DmaxHeartbeats=80000000']
cmds=[('NORMAL',[str(lean/'bin/lean'),*flags,'--root='+str(w/'src'),'-o',str(obj),str(src)]),('REPLAY',[str(lean/'bin/leanchecker'),'-v',module]),('AUDIT',[str(lean/'bin/lean'),*flags,'--root='+str(w/'audits'),str(audit)])]
stages=[]
for phase,argv in cmds:
 log=ev/(phase+'.log'); usage=ev/(phase+'.rusage')
 rec={'stage':phase,'argv':argv,'cwd':str(w),'started_utc':now(),'LEAN_PATH':env['LEAN_PATH'],'time_limit_seconds':600,'strict_budget_mebibytes':13107}
 write(ev/(phase+'.start.json'),rec)
 beg=time.monotonic()
 with log.open('xb') as out:
  child=subprocess.Popen(argv,env=env,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
  timed_out=False
  while True:
   done,status,stat=os.wait4(child.pid,os.WNOHANG)
   if done:break
   if time.monotonic()-beg>=600 and not timed_out:
    os.killpg(child.pid,signal.SIGKILL);timed_out=True
   time.sleep(0.1)
  child.returncode=os.waitstatus_to_exitcode(status)
 rec.update(ended_utc=now(),elapsed_seconds=round(time.monotonic()-beg,3),exit_code=child.returncode,peak_child_rss_bytes=stat.ru_maxrss*1024,timed_out=timed_out,log_sha256=sha(log),log_bytes=log.stat().st_size)
 write(ev/(phase+'.json'),rec);stages.append(rec)
 print(name,phase,child.returncode,rec['elapsed_seconds'],rec['peak_child_rss_bytes'],flush=True)
 if child.returncode:sys.exit(1)
def markers(key):return [json.loads(l.split(' ',1)[1]) for l in (ev/'AUDIT.log').read_text().splitlines() if l.startswith(key+' ')]
inv,=markers('P0_QUEUE_INVENTORY');imports,=markers('P0_QUEUE_IMPORTS'); rows=markers('P0_QUEUE_DECL')
names=sorted(t['name'] for t in rows);assert inv['module']==module and names==sorted(inv['serialized'])==sorted(inv['environment']) and len(names)==len(set(names))
assert set('ImbalancedChen.P2Saving16Cell01FieldDecode.'+s for s in spec['public_theorems_in_source'])<=set(names) and len(spec['public_theorems_in_source'])==11
assert all(r['module']==module and not any(r[k] for k in ['unsafe','partial','axiom']) and not(set(r['axioms'])-{'propext','Classical.choice','Quot.sound'}) for r in rows)
external={e['module'] for e in json.loads((w/'snapshot.json').read_bytes())['entries']}
assert set(x for x in imports if not x.startswith('ImbalancedChen.'))<=external
assert set(x for x in imports if x.startswith('ImbalancedChen.'))==set(r['module'] for r in closure['members'])|{module}
write(ev/'RESULT.json',{'schema':'p25-p2-cell01-row-three-stage-v1','accepted':True,'new_formal_credit':'one closed simplex decoder equation plus its lookup facts','P2_5_proved':False,'module':module,'source_commit':'253cd549873b53118e3cd2d91c608b309a221dcd','source_sha256':sha(src),'object_sha256':sha(obj),'object_bytes':obj.stat().st_size,'audit_sha256':sha(audit),'verified_inputs_before':before,'verified_inputs_after':snap(),'owned_count':len(names),'owned':names,'imports_count':len(imports),'transitive_axioms':sorted({a for r in rows for a in r['axioms']}),'stages':stages})
