import hashlib, json, subprocess, sys, time
from pathlib import Path
P=Path(__file__).resolve().parent
repo=P.parent.parent
run=Path('/dev/shm/p21-authorized-20261126/retrieve-_av1f6nl')
raw=(run/'RETRIEVAL_RESULT.json').read_bytes()
retrieval=json.loads(raw)
assert retrieval['status']=='VERIFIED_GIT_RETRIEVAL' and retrieval['archive_bytes_verified'] is True
assert retrieval['exact_part_count']==409 and retrieval['verified_auxiliary_original_count']==7
assert retrieval['verified_auxiliary_original_plan_parts']==39 and retrieval['exact_metadata_count']==4
assert retrieval['local_archive_verified'] is False
for command in retrieval['git_commands']:
    assert command['exit_code']==0 and command['stdout_complete'] is True
with (P/'GIT_RETRIEVAL_RESULT.json').open('xb') as f:f.write(raw)
script=repo/'verification/part2/repack_winner9_private_evidence.py'
expected='bf20e2992d7f798b3bf5b00d054b56503796ff29822e1bb8ae03bff4b166cb5b'
assert hashlib.sha256(script.read_bytes()).hexdigest()==expected
argv=[sys.executable,'-I','-B',str(script),'verify',
 '/dev/shm/p21-authorized-20261126/p21.tar.xz','--repo',str(repo),
 '--git-tree','1de0453bee55bf1128be422787216937b8fda9c9',
 '--output',str(P/'LOCAL_ARCHIVE_VERIFICATION.json')]
request={'argv':argv,'cwd':str(repo),'original_verifier_sha256':expected,
         'archive_retrieval_result_sha256':hashlib.sha256(raw).hexdigest()}
with (P/'LOCAL_ARCHIVE_EXEC_REQUEST.json').open('x') as f:json.dump(request,f,indent=2);f.write('\n')
start=time.time(); mono=time.monotonic()
process=subprocess.run(argv,cwd=repo,capture_output=True)
record={**request,'started_unix':start,'finished_unix':time.time(),'elapsed_seconds':time.monotonic()-mono,
        'exit_code':process.returncode,'original_verifier_unchanged':hashlib.sha256(script.read_bytes()).hexdigest()==expected,
        'compile_credit':False,'kernel_credit':False,'new_lean_execution':False,'full_p2_complete':False}
for stream,blob in [('stdout',process.stdout),('stderr',process.stderr)]:
    name='LOCAL_ARCHIVE_VERIFIER_'+stream.upper()+'.bin'
    with (P/name).open('xb') as f:f.write(blob)
    record[stream]={'path':name,'bytes':len(blob),'sha256':hashlib.sha256(blob).hexdigest()}
result=P/'LOCAL_ARCHIVE_VERIFICATION.json'
if result.exists():
    b=result.read_bytes()
    record['report']={'path':result.name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
with (P/'LOCAL_ARCHIVE_EXECUTION.json').open('x') as f:json.dump(record,f,indent=2,sort_keys=True);f.write('\n')
print(json.dumps(record,sort_keys=True))
sys.stdout.buffer.write(process.stdout);sys.stdout.buffer.write(process.stderr);sys.stdout.buffer.flush()
raise SystemExit(process.returncode)

