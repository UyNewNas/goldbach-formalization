set -uo pipefail
umask 077
for p21_key in ${!GIT_TRACE@}; do unset "$p21_key"; done
unset GIT_CURL_VERBOSE GIT_DIR GIT_WORK_TREE GIT_COMMON_DIR GIT_INDEX_FILE GIT_OBJECT_DIRECTORY GIT_ALTERNATE_OBJECT_DIRECTORIES GIT_NAMESPACE GIT_PREFIX
export GIT_TERMINAL_PROMPT=0
p21_out='/workspace/p2-1-20261125/.lake/p2-private/exports/p21-completed-6c7864adfcbd4fc0ae850285c6f64e14/direct-git-prepare-20261126-b/plain-push-947a5dd8-20261126-a'
mkdir -- "$p21_out" || exit $?
python3 -I -B - >"$p21_out/guard.stdout" 2>"$p21_out/guard.stderr" <<'P21_GUARD'
import base64,hashlib,json,os,pathlib,re,stat,subprocess,sys,types
P=pathlib.Path
base='48b343279639cb3a289628d35cc23b2710eedd05'
commit='947a5dd8fb3c32c8a2688b767f559d7ab31d46d1'; tree='14b67d3e5a4435fb02046d7d541e0d5531aff719'
bare=P('/workspace/p2-1-20261125/.lake/p2-private/exports/p21-completed-6c7864adfcbd4fc0ae850285c6f64e14/direct-git-prepare-20261126-b/p21-direct-evidence-09b2i8ih/repository.git'); work=P('/workspace/p2-1-20261125/.lake/p2-private/exports/p21-completed-6c7864adfcbd4fc0ae850285c6f64e14/direct-git-prepare-20261126-b/p21-direct-evidence-09b2i8ih')
report_path=P('/workspace/p2-1-20261125/.lake/p2-private/exports/p21-completed-6c7864adfcbd4fc0ae850285c6f64e14/direct-git-prepare-20261126-b/p21-direct-evidence-09b2i8ih.json'); report_sha='aaf23fc49c3e287b95ee8db08529fa4fbb83a31010fd32506985b9811b106efd'; report_bytes=int('2877')
root=P('/workspace/p2-1-20261125')
helper_path=root/'verification/part2/transfer_p21_evidence.py'
helper_sha='5c0369eb49ce5aed7798d0b69e58e26d0805f7d3d3b680c480d45f9654982a4d'
assert helper_path.resolve(strict=True)==helper_path and stat.S_ISREG(helper_path.lstat().st_mode)
helper_raw=helper_path.read_bytes(); assert hashlib.sha256(helper_raw).hexdigest()==helper_sha
h=types.ModuleType('frozen_original_transfer_guard'); h.__file__=str(helper_path)
exec(compile(helper_raw,str(helper_path),'exec'),h.__dict__)
h.frozen_bytes(helper_path,helper_sha)
retained=root/'.lake/p2-private/exports/p21-completed-6c7864adfcbd4fc0ae850285c6f64e14'
plan_sha='ac1d24aaf71dbc1f5cf89f8ab205f25fd58d8689726c81337a2499666bae068b'
plan=h.load_plan(retained/'raw-transfer-20261126-a/PLAN.json',plan_sha)
runtime=retained/'direct-git-prepare-20261126-b/publish_p21_evidence_git.py'
runtime_raw=h.frozen_bytes(runtime,'438e766ff3c4652690d5f284787e796c91ce50a62d23d2f24f192ae72f57e08c')
raw=h.frozen_bytes(report_path,report_sha,report_bytes); r=json.loads(raw)
expected={'schema':'p21-direct-git-run/v1','status':'PREPARED_ONLY','expected_base':base,
 'evidence_commit':commit,'evidence_tree':tree,'evidence_ref':'refs/heads/evidence/p2-1-20261126-6c7864ad',
 'report_path':str(report_path),'work_directory':str(work),'bare_directory':str(bare),
 'archive_part_count':409,'archive_bytes':490564596,'archive_sha256':'066a46e41e34578a2adbf2a1120e8aba0470dfde44d6052bc8576d8fcb9aa212',
 'source_count':140,'plan_sha256':plan_sha,'producer_sha256':helper_sha,
 'publisher_sha256':'438e766ff3c4652690d5f284787e796c91ce50a62d23d2f24f192ae72f57e08c',
 'source_snapshot_commit':'00af18335dcebcc5e24571e33be7791ff718fbff',
 'accepted_git_commit':'1de0453bee55bf1128be422787216937b8fda9c9','accepted_git_tree':'af74f02d263c72b0bb8e003ce49d1134ac04c5d5',
 'push_attempted':False,'push_performed':False,'remote_verified':False,'synthetic_test_only':False,
 'local_archive_verified':False,'compile_credit':False,'kernel_credit':False,'full_p2_complete':False}
assert all(type(r[k]) is type(v) and r[k]==v for k,v in expected.items())
assert re.fullmatch('[0-9a-f]{40}',commit) and re.fullmatch('[0-9a-f]{40}',tree)
assert work.resolve(strict=True)==work and work.is_dir()
owned={'st_dev':int('27'),'st_ino':int('3316712')}
assert r['owned_work_directory']==owned
assert {k:getattr(work.lstat(),k) for k in owned}==owned
assert bare==work/'repository.git' and bare.resolve(strict=True)==bare and bare.is_dir()
out=P('/workspace/p2-1-20261125/.lake/p2-private/exports/p21-completed-6c7864adfcbd4fc0ae850285c6f64e14/direct-git-prepare-20261126-b/plain-push-947a5dd8-20261126-a'); assert out.resolve(strict=True)==out and out.parent==work.parent
def git(args):
 argv=['git','-c','gc.auto=0','-c','maintenance.auto=false','--git-dir',str(bare)]+args
 p=subprocess.run(argv,capture_output=True,timeout=300)
 if p.returncode:
  print(json.dumps({'guard_git_failure':{'argv':argv,'returncode':p.returncode,'stdout_base64':base64.b64encode(p.stdout).decode(),'stderr_base64':base64.b64encode(p.stderr).decode()}}),flush=True)
  raise SystemExit(p.returncode)
 return p.stdout
assert git(['rev-parse','--is-bare-repository']).strip()==b'true'
assert git(['rev-parse','HEAD']).decode().strip()==base
assert git(['rev-parse',commit+'^{commit}']).decode().strip()==commit
assert git(['rev-parse',commit+'^{tree}']).decode().strip()==tree
assert git(['rev-list','--parents','-n','1',commit]).decode().split()==[commit,base]
prefix='docs/verification/20261126-p2-1'
parts=json.loads(git(['cat-file','blob',commit+':'+prefix+'/ARCHIVE_PARTS.json']))
method=json.loads(git(['cat-file','blob',commit+':'+prefix+'/TRANSPORT_METHOD.json']))
assert parts['full_archive']=={'bytes':r['archive_bytes'],'sha256':r['archive_sha256']}
assert parts['part_count']==len(parts['parts'])==len(plan['assets']['archive']['parts'])==409
for row,piece in zip(parts['parts'],plan['assets']['archive']['parts']):
 assert all(type(row[k]) is type(v) and row[k]==v for k,v in piece.items())
 assert row['path']==f'{prefix}/archive-parts/part-{piece["index"]:05}.bin'
for manifest in [parts,method]:
 assert manifest['record_phase']=='prepared_before_push' and manifest['base_commit']==base
 assert manifest['plan_sha256']==plan_sha and manifest['producer_sha256']==helper_sha
 assert manifest['local_archive_verified'] is False and manifest['full_p2_complete'] is False
s=method['source_tree_check']
assert s['base_commit']==base and s['accepted_commit']==r['accepted_git_commit'] and s['accepted_tree']==r['accepted_git_tree']
assert s['source_count']==len(s['sources'])==len({x['path'] for x in s['sources']})==140
assert method['base_mcp_captures_verified']==r['base_mcp_captures_verified'] and method['new_mcp_jobs']==0
entries={}
for line in git(['ls-tree','-r','-z','--full-tree',commit,'--',prefix+'/archive-parts']).split(b'\0'):
 if line:
  header,name=line.split(b'\t',1); name=name.decode()
  if name.endswith('.bin'): entries[name]=tuple(header.decode().split())
assert entries=={f'{prefix}/archive-parts/part-{x["index"]:05}.bin':('100644','blob',x['git_blob_sha']) for x in plan['assets']['archive']['parts']}
assert git(['rev-parse',commit+':verification/part2/publish_p21_evidence_git.py']).decode().strip()==h.blob_sha(runtime_raw)
assert {k:getattr(work.lstat(),k) for k in owned}==owned
assert h.frozen_bytes(report_path,report_sha,report_bytes)==raw
sys.stdout.buffer.write(('P21_ORIGINAL_PREPARE_REPORT '+str(len(raw))+' '+report_sha+'\n').encode())
sys.stdout.buffer.write(raw)
sys.stdout.buffer.write(b'P21_ORIGINAL_PREPARE_REPORT_END\n')
sys.stdout.buffer.flush()
P21_GUARD
p21_guard_rc=$?
cat "$p21_out/guard.stdout"; p21_emit_rc=$?
cat "$p21_out/guard.stderr" >&2
p21_before_rc=-1; p21_push_rc=-1; p21_after_rc=-1
if [ "$p21_guard_rc" -eq 0 ] && [ "$p21_emit_rc" -eq 0 ]; then
  git ls-remote --refs https://github.com/UyNewNas/goldbach-formalization.git refs/heads/evidence/p2-1-20261126-6c7864ad >"$p21_out/before.stdout" 2>"$p21_out/before.stderr"
  p21_before_rc=$?
  if [ "$p21_before_rc" -eq 0 ] && [ ! -s "$p21_out/before.stdout" ]; then
    git -c gc.auto=0 -c maintenance.auto=false -c pack.window=0 -c pack.depth=0 -c pack.threads=1 --git-dir '/workspace/p2-1-20261125/.lake/p2-private/exports/p21-completed-6c7864adfcbd4fc0ae850285c6f64e14/direct-git-prepare-20261126-b/p21-direct-evidence-09b2i8ih/repository.git' push --porcelain --force-with-lease=refs/heads/evidence/p2-1-20261126-6c7864ad: https://github.com/UyNewNas/goldbach-formalization.git 947a5dd8fb3c32c8a2688b767f559d7ab31d46d1:refs/heads/evidence/p2-1-20261126-6c7864ad >"$p21_out/push.stdout" 2>"$p21_out/push.stderr"
    p21_push_rc=$?
    if [ "$p21_push_rc" -eq 0 ]; then
      git ls-remote --refs https://github.com/UyNewNas/goldbach-formalization.git refs/heads/evidence/p2-1-20261126-6c7864ad >"$p21_out/after.stdout" 2>"$p21_out/after.stderr"
      p21_after_rc=$?
    fi
  fi
fi
python3 -I -B - "$p21_guard_rc" "$p21_emit_rc" "$p21_before_rc" "$p21_push_rc" "$p21_after_rc" <<'P21_RESULT'
import base64,hashlib,json,os,pathlib,sys
out=pathlib.Path('/workspace/p2-1-20261125/.lake/p2-private/exports/p21-completed-6c7864adfcbd4fc0ae850285c6f64e14/direct-git-prepare-20261126-b/plain-push-947a5dd8-20261126-a')
codes=dict(zip(['guard','report_emit','before','push','after'],map(int,sys.argv[1:])))
records={}
for step,rc in codes.items():
 row={'returncode':None if rc<0 else rc,'executed':rc>=0}
 if step!='report_emit':
  for stream in ['stdout','stderr']:
   p=out/(step+'.'+stream)
   if p.exists():
    raw=p.read_bytes(); row[stream]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'base64':base64.b64encode(raw).decode()}
 records[step]=row
before=(out/'before.stdout').read_bytes() if codes['before']>=0 else None
after=(out/'after.stdout').read_bytes() if codes['after']>=0 else None
expected=b'947a5dd8fb3c32c8a2688b767f559d7ab31d46d1\trefs/heads/evidence/p2-1-20261126-6c7864ad\n'
ok=all(rc==0 for rc in codes.values()) and before==b'' and after==expected
rc=0 if ok else next((v for v in codes.values() if v>0),1)
report={'schema':'p21-plain-git-push-result/v1','status':'PUSHED_AND_REMOTE_VERIFIED' if ok else 'FAILED',
 'prepare_job_id':'5bb55459f0854475b46dd18a78c0aa7c','prepare_terminal_sha256':'49d2ce7977e12bd4c5f977fb6a642975938189d0d2ac339e5e5b6a0e07912944',
 'prepare_report':{'path':'/workspace/p2-1-20261125/.lake/p2-private/exports/p21-completed-6c7864adfcbd4fc0ae850285c6f64e14/direct-git-prepare-20261126-b/p21-direct-evidence-09b2i8ih.json','bytes':int('2877'),'sha256':'aaf23fc49c3e287b95ee8db08529fa4fbb83a31010fd32506985b9811b106efd'},
 'base':'48b343279639cb3a289628d35cc23b2710eedd05','commit':'947a5dd8fb3c32c8a2688b767f559d7ab31d46d1','tree':'14b67d3e5a4435fb02046d7d541e0d5531aff719',
 'bare_directory':'/workspace/p2-1-20261125/.lake/p2-private/exports/p21-completed-6c7864adfcbd4fc0ae850285c6f64e14/direct-git-prepare-20261126-b/p21-direct-evidence-09b2i8ih/repository.git','owned_work_directory':{'st_dev':int('27'),'st_ino':int('3316712')},
 'repository':'https://github.com/UyNewNas/goldbach-formalization.git','ref':'refs/heads/evidence/p2-1-20261126-6c7864ad',
 'steps':records,'process_exit_code':rc,'push_attempted':codes['push']>=0,'push_process_succeeded':codes['push']==0,
 'remote_verified':ok,'local_archive_verified':False,'compile_credit':False,'kernel_credit':False,'full_p2_complete':False}
raw=(json.dumps(report,sort_keys=True,separators=(',',':'))+'\n').encode()
path=out/'PUSH_RESULT.json'
with path.open('xb') as stream:
 stream.write(raw); stream.flush(); os.fsync(stream.fileno())
assert path.read_bytes()==raw
print(json.dumps({'phase':'push_result_binding','path':str(path),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}),flush=True)
sys.stdout.buffer.write(raw); sys.stdout.buffer.flush()
raise SystemExit(rc)
P21_RESULT
exit $?

