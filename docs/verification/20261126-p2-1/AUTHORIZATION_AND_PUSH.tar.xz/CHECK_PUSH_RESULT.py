import base64, hashlib, json
from pathlib import Path
P=Path(__file__).resolve().parent
def sha(raw): return hashlib.sha256(raw).hexdigest()
def rawfile(name):
    b=(P/name).read_bytes()
    return b, {'path':name,'bytes':len(b),'sha256':sha(b)}
def envelope(name):
    raw, binding=rawfile(name)
    return json.loads(raw), binding
terminal,tb=envelope('PUSH_TERMINAL_TOOL.json')
t=json.loads(terminal['content'][0]['text'])
assert t['status']=='succeeded' and t['exit_code']==0
assert t['log_bytes']==10286 and t['log_discarded_bytes']==0 and t['log_truncated'] is False
cap,cb=envelope('PUSH_OUTPUT_TOOL.json')
o=json.loads(cap['content'][0]['text'])
assert o['eof'] is True and o['next_offset']==10286 and o['discarded_bytes']==0 and o['log_truncated'] is False
raw=base64.b64decode(o['output_base64'],validate=True)
assert len(raw)==10286 and raw.decode()==o['output']
prefix=b'P21_ORIGINAL_PREPARE_REPORT 2877 aaf23fc49c3e287b95ee8db08529fa4fbb83a31010fd32506985b9811b106efd\n'
assert raw.startswith(prefix)
prepared=raw[len(prefix):len(prefix)+2877]
assert sha(prepared)=='aaf23fc49c3e287b95ee8db08529fa4fbb83a31010fd32506985b9811b106efd'
assert prepared==(P.parent.parent/'docs/verification/20261126-p2-1/PREPARED_EVIDENCE_REPORT.json').read_bytes()
suffix=raw[len(prefix)+2877:]
marker=b'P21_ORIGINAL_PREPARE_REPORT_END\n'
assert suffix.startswith(marker)
binding_line, report_raw=suffix[len(marker):].split(b'\n',1)
binding=json.loads(binding_line)
assert binding['phase']=='push_result_binding' and binding['bytes']==len(report_raw) and binding['sha256']==sha(report_raw)
r=json.loads(report_raw)
assert r['status']=='PUSHED_AND_REMOTE_VERIFIED' and r['process_exit_code']==0
assert r['push_attempted'] is True and r['push_process_succeeded'] is True and r['remote_verified'] is True
assert r['commit']=='947a5dd8fb3c32c8a2688b767f559d7ab31d46d1' and r['tree']=='14b67d3e5a4435fb02046d7d541e0d5531aff719'
assert r['base']=='48b343279639cb3a289628d35cc23b2710eedd05'
assert r['repository']=='https://github.com/UyNewNas/goldbach-formalization.git'
assert r['ref']=='refs/heads/evidence/p2-1-20261126-6c7864ad'
assert all(r[k] is False for k in ['local_archive_verified','compile_credit','kernel_credit','full_p2_complete'])
decoded={}
for name,s in r['steps'].items():
    assert s['executed'] is True and s['returncode']==0
    decoded[name]={}
    for stream in ['stdout','stderr']:
        if stream in s:
            b=base64.b64decode(s[stream]['base64'],validate=True)
            assert len(b)==s[stream]['bytes'] and sha(b)==s[stream]['sha256']
            decoded[name][stream]=b
assert decoded['before']['stdout']==b''
assert decoded['after']['stdout']==(r['commit']+'\t'+r['ref']+'\n').encode()
assert decoded['guard']['stdout']==prefix+prepared+marker
assert decoded['guard']['stderr']==b''
refenv,refbinding=envelope('PUSH_REMOTE_REF.json')
commit_env,commit_binding=envelope('PUSH_REMOTE_COMMIT.json')
ref=json.loads(refenv['structuredContent']['content'])
commit=json.loads(commit_env['structuredContent']['content'])
assert ref['ref']==r['ref'] and ref['object']['sha']==r['commit'] and ref['object']['type']=='commit'
assert commit['sha']==r['commit'] and commit['tree']['sha']==r['tree'] and [p['sha'] for p in commit['parents']]==[r['base']]
for name,b in [('PUSH_STDOUT.bin',raw),('PUSH_RESULT.json',report_raw)]:
    with (P/name).open('xb') as f: f.write(b)
summary={'schema':'p21-push-original-byte-and-independent-readback-check/v1',
 'status':'PASSED','task_id':t['task_id'],'task_status':t['status'],'exit_code':t['exit_code'],
 'elapsed_seconds':t['elapsed_seconds'],'peak_memory_bytes':t['peak_memory_bytes'],
 'terminal_envelope':tb,'output_envelope':cb,'github_ref_envelope':refbinding,'github_commit_envelope':commit_binding,
 'stdout':{'path':'PUSH_STDOUT.bin','bytes':len(raw),'sha256':sha(raw)},
 'push_result':{'path':'PUSH_RESULT.json','bytes':len(report_raw),'sha256':sha(report_raw)},
 'original_prepared_report_sha256':sha(prepared),'original_prepared_report_unchanged':True,
 'commit':r['commit'],'tree':r['tree'],'parent':r['base'],'remote_ref_exact':True,
 'all_five_command_steps_executed_exit_zero':True,
 'historical_prepare_terminal_capture_reference':'The prepare_terminal_sha256 in the original push result is a historical recorded binding; the lost original capture is not recreated by the fresh readback.',
 'local_archive_verified':False,'compile_credit':False,'kernel_credit':False,'full_p2_complete':False}
with (P/'PUSH_READBACK_VERIFICATION.json').open('x') as f: json.dump(summary,f,sort_keys=True,indent=2);f.write('\n')
print(json.dumps(summary,sort_keys=True))

