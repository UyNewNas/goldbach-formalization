import hashlib,io,json,lzma,os,tarfile,subprocess
from pathlib import Path
w=Path.cwd();e=w/'evidence'
sha=lambda b:hashlib.sha256(b).hexdigest()
def check(p,h): assert sha(p.read_bytes())==h,(p,h)
q=json.loads((w/'delta.json').read_text()); m=json.loads((w/'imports.json').read_text()); ref=q['references']
chunks=[w/'parts'/('d%04d'%i) for i in range(49)]
compressed=b''.join(p.read_bytes() for p in chunks);assert sha(compressed)==q['remaining_xz_sha256']
data=lzma.decompress(compressed);assert sha(data)==q['remaining_sha256']
tar=io.BytesIO();origin=0;off=0
for i,n,d,path in ref:
 tar.write(data[off:off+i-origin]);off+=i-origin
 b=Path(path).read_bytes();assert len(b)==n and sha(b)==d;tar.write(b);origin=i+n
tar.write(data[off:]);blob=tar.getvalue();assert len(blob)==q['length'] and sha(blob)==q['tar_sha256']
package=lzma.compress(blob,preset=3);assert len(package)==m['archive_bytes'] and sha(package)==q['original_sha256']==m['archive_sha256']
(w/m['archive_name']).write_bytes(package)
with tarfile.open(fileobj=io.BytesIO(blob)) as f:
 assert sorted(v.name for v in f.getmembers())==sorted(r['path'] for r in m['members'])
 for r in m['members']:
  b=f.extractfile(r['path']).read();assert sha(b)==r['sha256'] and len(b)==r['bytes']
  dest=w/'lib'/r['path'];dest.parent.mkdir(exist_ok=True)
  with dest.open('xb') as out:out.write(b)
template=(e/'template.lean').read_text();assert template.count('ImbalancedChen.P2Winner9FiniteMomentKernel')==2
(e/'Audit.lean').write_text(template.replace('ImbalancedChen.P2Winner9FiniteMomentKernel','ImbalancedChen.P2Saving16Cell01DirectParse'))
check(w/'src/ImbalancedChen/P2Saving16Cell01DirectParse.lean','bcd49a84496c676733fc39295159b27d472a72e47d7a619ea2d36dc212385928')
check(e/'template.lean','2975fe381dfc6de3b297a67bcc9db9dd064bcad37a0b45ee13bc1fcd957ee85b')
(e/'BUNDLE.json').write_text(json.dumps(m,indent=2)+'\n')
print('verified identical original archive and all five members')
