from pathlib import Path
import sys,os,time,json,hashlib,subprocess,datetime,resource,shutil,base64,lzma,re
w=Path.cwd();ev=w/'evidence';stage=sys.argv[1];module='ImbalancedChen.P2Saving16Cell01DirectParse'; short=module.split('.')[-1]
lean=Path('/workspace/toolchains/lean-4.33.0-rc1-linux');math=Path('/workspace/compile-deps/mathlib')
assert subprocess.check_output(['git','-C',math,'rev-parse','HEAD'],text=True).strip()=='e4c91783ca8e6a7c693ae624ade32fd22d4e43c1'
env=dict(os.environ,PATH=str(lean/'bin')+':'+os.environ['PATH'],LEAN_PATH=os.pathsep.join(str(x) for x in [w/'lib',w/'external-lib',math/'.lake/build/lib/lean',*[math/'.lake/packages'/p/'.lake/build/lib/lean' for p in ['plausible','LeanSearchClient','importGraph','proofwidgets','aesop','Qq','batteries','Cli']]]))
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def dump(p,obj):
 with p.open('x') as f:json.dump(obj,f,indent=2);f.write('\n')
def boundary():
 src=w/'src/ImbalancedChen'/(short+'.lean')
 m=json.loads((ev/'BUNDLE.json').read_text())
 files={str(w/'lib'/s['path']):s['sha256'] for s in m['members']}
 files.update({str(src):'bcd49a84496c676733fc39295159b27d472a72e47d7a619ea2d36dc212385928', '/workspace/goldbach-research/eighth-prefix-family-20261009-cell-01.witness.json':'d7215c408203fd149155ec34af91c0d3af45a49d4dc64e23b508917d176a5c2f'})
 assert all(sha(Path(p))==h for p,h in files.items())
 return files|{str(z):sha(z) for z in [lean/'bin/lean',lean/'bin/leanchecker',ev/'Audit.lean',ev/'ISOLATED_EXTERNAL.json']}
obj=w/'lib/ImbalancedChen'/(short+'.olean'); src=w/'src/ImbalancedChen'/(short+'.lean')
flags=['-t0','-j1','-M13107','-DwarningAsError=true','-DmaxRecDepth=1000000','-DmaxHeartbeats=80000000']
prior={'NORMAL':None,'REPLAY':'NORMAL','AUDIT':'REPLAY'}[stage]
if prior:assert json.loads((ev/(prior+'.json')).read_text())['exit_code']==0 and obj.is_file()
else:assert not obj.exists()
cmd={'NORMAL':[str(lean/'bin/lean'),*flags,'--root='+str(w/'src'),'-o',str(obj),str(src)],'REPLAY':[str(lean/'bin/leanchecker'),'-v',module],'AUDIT':[str(lean/'bin/lean'),*flags,'--root='+str(ev),str(ev/'Audit.lean')]}[stage]
before=boundary();start=datetime.datetime.now(datetime.timezone.utc).isoformat()
rec={'stage':stage,'started_utc':start,'argv':cmd,'LEAN_PATH':env['LEAN_PATH'],'toolchain_version':subprocess.check_output([str(lean/'bin/lean'),'--version'],text=True).strip(),'mathlib_commit':'e4c91783ca8e6a7c693ae624ade32fd22d4e43c1','inputs_before':before,'source_commit':'253cd549873b53118e3cd2d91c608b309a221dcd'}
dump(ev/(stage+'.start.json'),rec)
starttime=time.monotonic()
with (ev/(stage+'.log')).open('xb') as log:
 child=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
 try:code=child.wait(timeout=600)
 except subprocess.TimeoutExpired:child.kill();code=child.wait();rec['timed_out_after_s']=600
rec.update(ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsed_seconds=round(time.monotonic()-starttime,3),exit_code=code,child_rusage_peak_rss_bytes=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss*1024,inputs_after=boundary(),log_bytes=(ev/(stage+'.log')).stat().st_size,log_sha256=sha(ev/(stage+'.log')),target_object_present=obj.is_file(),target_object_sha256=sha(obj) if obj.is_file() else None)
assert rec['inputs_before']==rec['inputs_after']
dump(ev/(stage+'.json'),rec)
print(stage,code,rec['elapsed_seconds'],rec['child_rusage_peak_rss_bytes'],flush=True)
if code:sys.exit(1)
if stage=='AUDIT':
 ls=(ev/'AUDIT.log').read_text().splitlines()
 reads=lambda key:[json.loads(l.split(' ',1)[1]) for l in ls if l.startswith(key+' ')]
 inv,=reads('P0_QUEUE_INVENTORY');imports,=reads('P0_QUEUE_IMPORTS');items=reads('P0_QUEUE_DECL');names=sorted(x['name'] for x in items)
 assert inv['module']==module and names==sorted(inv['serialized'])==sorted(inv['environment']) and len(set(names))==len(names)
 assert {'ImbalancedChen.P2Saving16Cell01Segments.rootValue','ImbalancedChen.P2Saving16Cell01Segments.cell01_value532'}<=set(names)
 assert all(x['module']==module and not any(x[k] for k in ['unsafe','partial','axiom']) and not(set(x['axioms'])-{'propext','Classical.choice','Quot.sound'}) for x in items)
 need=set(json.loads(lzma.decompress((w/'needed.xz').read_bytes())))
 assert not [n for n in imports if not n.startswith('ImbalancedChen.') and n not in need]
 dump(ev/'COMPLETE_OWNED.json',{'module':module,'owned':names,'transitive_axioms':sorted({a for x in items for a in x['axioms']}),'actual_imports_count':len(imports),'external_subset_of_checked':True,'object_sha256':sha(obj),'p2_5_proved':False})
