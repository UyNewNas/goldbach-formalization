import os,pathlib,hashlib,base64,lzma,json,time,sys,subprocess,datetime
from collections import Counter
here=pathlib.Path(__file__).resolve().parent
ev=here/'evidence'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while chunk:=f.read(1024*1024):h.update(chunk)
 return h.hexdigest()
def write(name,obj):
 with (ev/name).open('x') as f:json.dump(obj,f,indent=2);f.write('\n')
label=sys.argv[1]
cap=ev/'P3-DICT64.json.xz'; assert sha(cap)=='97cb5d2829fef0ea1f318bae5ff1e8c439c38e1aaf54d80e2ea58940de7c7aab'
j=json.loads(lzma.decompress(cap.read_bytes()));key,=[k for k in j['files'] if k.endswith('/COMPLETE_EXTERNAL_BEFORE.json')]
b=base64.b64decode(j['files'][key]['base64']);expected=hashlib.sha256(b).hexdigest()
assert expected==j['files'][key]['sha256']=='c805cef41ceffefbf82ef6c7eb89d0ed4afc7cdc7264c251008b87a2216072b1'
rows=json.loads(b)['entries'];assert len(rows)==5312
needed=json.loads(lzma.decompress((here/'needed.xz').read_bytes()));need={n for n in needed if not n.startswith('ImbalancedChen.')}
cmp=Counter(); errors=[]; required_errors=[];seen=set()
beg=datetime.datetime.now(datetime.timezone.utc).isoformat()
for row in rows:
 for ent in [row['object'],*row['companions']]:
  path=pathlib.Path(ent['path'].replace('/mathlib/','/workspace/compile-deps/mathlib/',1))
  matched=path.is_file() and path.stat().st_size==ent['bytes'] and sha(path)==ent['sha256']
  cmp['match' if matched else 'mismatch']+=1
  if not matched:
   errors.append(str(path))
   if row['module'] in need:required_errors.append(str(path))
  if row['module'] in need:seen.add(row['module'])
missing=sorted(need-seen)
result={'started_utc':beg,'ended_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'p3_snapshot_sha256':expected,'total_modules':len(rows),'files':dict(cmp),'mismatches':errors,'required_mismatches':required_errors,'required_module_count':len(need),'required_absent_from_snapshot':missing,'selected_by':'existing complete-owned canonical cell01 binding import inventory, includes Lean as used by SourceJson/Fuel'}
write('EXTERNAL_'+label+'.json',result)
print({k:v for k,v in result.items() if k not in ['mismatches','required_mismatches','required_absent_from_snapshot']},'missing required',len(missing)+len(required_errors))
assert not (required_errors or missing)
