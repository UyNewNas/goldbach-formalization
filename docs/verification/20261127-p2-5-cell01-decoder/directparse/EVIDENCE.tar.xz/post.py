from pathlib import Path
import json,lzma,hashlib,base64,datetime,sys
w=Path.cwd();ev=w/'evidence'
snap=json.loads(lzma.decompress((ev/'P3-DICT64.json.xz').read_bytes()))['files'];r,=[v for k,v in snap.items() if k.endswith('/COMPLETE_EXTERNAL_BEFORE.json')]
need=set(json.loads(lzma.decompress((w/'needed.xz').read_bytes())))
checked=0;bads=[]
for e in json.loads(base64.b64decode(r['base64']))['entries']:
 if e['module'] not in need:continue
 for t in [e['object'],*e['companions']]:
  p=Path(t['path'])
  if str(p).startswith('/mathlib/'):p=w/'external-lib'/((e['module'].replace('.','/'))+'.olean'+t['path'][len(e['object']['path']):])
  if not p.is_file() or p.stat().st_size!=t['bytes'] or hashlib.sha256(p.read_bytes()).hexdigest()!=t['sha256']:bads.append(str(p))
  checked+=1
o={'ended_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'external_checkpoint_sha256':r['sha256'],'actual_context_files_checked':checked,'mismatches':bads}
name=ev/'EXTERNAL_AFTER.json'
with name.open('x') as f:json.dump(o,f,indent=2);f.write('\n')
print(o)
assert not bads and checked==8616
