from pathlib import Path
import base64,collections,concurrent.futures,hashlib,json,lzma,os,subprocess,sys,datetime
w=Path.cwd(); ev=w/'evidence'; iso=w/'cache-overlay'; iso.mkdir(exist_ok=True); dl=w/'cache-downloads';dl.mkdir(exist_ok=True)
snap=json.loads(lzma.decompress((ev/'P3-DICT64.json.xz').read_bytes()))['files'];row,=[v for k,v in snap.items() if k.endswith('/COMPLETE_EXTERNAL_BEFORE.json')]; entries=json.loads(base64.b64decode(row['base64']))['entries']
need=set(json.loads(lzma.decompress((w/'needed.xz').read_bytes())));needed={ent['module']:ent for ent in entries if ent['module'] in need}
assert len(needed)==2872
def h(p):
 hasher=hashlib.sha256()
 with p.open('rb') as f:
  while buf:=f.read(2**20): hasher.update(buf)
 return hasher.hexdigest()
def readpath(s):return Path(s.replace('/mathlib/','/workspace/compile-deps/mathlib/',1))
def check(p,r):return p.is_file() and p.stat().st_size==r['bytes'] and h(p)==r['sha256']
cachemap=json.loads(lzma.decompress((w/'cache-map.xz').read_bytes()))
old=json.loads((ev/'EXTERNAL_BEFORE.json').read_text())
misspaths=set(old['required_mismatches'])
missing={m for m,e in needed.items() if str(readpath(e['object']['path'])) in misspaths}
assert len(missing)==299 and missing<=cachemap.keys()
def get(m):
 n,expected,sz=cachemap[m]; dest=dl/n
 if not dest.is_file():
  subprocess.run(['curl','-fsSL','--retry','3','--max-time','65','http://lakecache.blob.core.windows.net/mathlib4-master/f/'+n,'-o',str(dest)],check=True)
 assert dest.stat().st_size==sz and h(dest)==expected
 return str(dest)
secondroot=Path("/workspace/goldbach-p2/.lake/packages/mathlib")
reuse={}
for m in sorted(missing):
 e=needed[m]
 if all(check(secondroot/t["path"].removeprefix("/mathlib/"), t) for t in [e["object"],*e["companions"]]):reuse[m]=secondroot/e["object"]["path"].removeprefix("/mathlib/")
count=0
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as ex:
 paths=list(ex.map(get,sorted(missing-set(reuse))))
if paths:subprocess.run(['/workspace/toolchains/lean-4.33.0-rc1-linux/bin/leantar','-C',str(iso),'-x','--jobs','2','-'],input='\n'.join(paths)+'\n',text=True,check=True)
physical=w/'external-lib'; physical.mkdir(exist_ok=True); total=0
for m,e in needed.items():
 base=e['object']['path']; src=readpath(base) if m not in missing else reuse[m] if m in reuse else iso/base.removeprefix('/mathlib/')
 for t in [e['object'],*e['companions']]:
  orig=t['path']; suffix=orig[len(base):]; p=Path(str(src)+suffix)
  assert check(p,t),p
  total+=1
 if not base.startswith('/mathlib/'):continue
 dest=physical/(m.replace('.','/')+'.olean');dest.parent.mkdir(parents=True,exist_ok=True)
 for p in src.parent.glob(src.stem+'.*'):
  if p.is_file():
   destfile=dest.parent/p.name
   if not destfile.exists():destfile.symlink_to(p)
assert total==2872*3
info={'external_checkpoint_sha256':row['sha256'],'required_module_count':len(needed),'required_files_verified':total,'shared_cache_matches_modules':len(needed)-len(missing),'secondary_existing_cache_exact_matches':len(reuse),'isolated_download_restored_modules':len(missing-set(reuse)),'unrelated_full_snapshot_mismatch_files_at_preflight':len(old['mismatches'])-len(old['required_mismatches']),'restored_modules':sorted(missing),'cache_map_sha256':h(w/'cache-map.xz'),'physical_lean_root':str(physical),'shared_writes':False}
(ev/'ISOLATED_EXTERNAL.json').write_text(json.dumps(info,indent=2)+'\n');print('checked',total,'restored',len(missing))
