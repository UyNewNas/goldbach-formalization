import ImbalancedChen.P2OriginalSaving19Cell05SourceAttachment
import ImbalancedChen.P2OriginalSaving19Cell00SourceAttachment
import ImbalancedChen.P2OriginalSaving19Cell05GroupedSeparationComplete
import ImbalancedChen.P2OriginalSaving19Cell01Row000OriginalFloorBridge
import ImbalancedChen.P2OriginalSaving19OriginalFloorTransport
import ImbalancedChen.P2OriginalSaving19Cell01OriginalFloorInterface
import ImbalancedChen.P2OriginalSaving19Cell01GroupedSeparationSigns
import ImbalancedChen.P2OriginalSaving19Cell01Row001Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row002Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row003Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row004Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row005Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row006Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row007Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row008Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row009Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row010Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row011Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row012Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row013Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row014Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row015Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row016Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row017Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row018Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row019Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row020Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row021Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row022Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row023Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row024Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row025Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row026Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row027Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row028Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row029Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row030Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row031Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row032Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row033Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row034Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row035Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row036Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row037Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row038Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row039Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row040Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row041Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row042Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row043Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row044Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row045Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row046Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row047Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row048Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row049Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row050Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row051Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row052Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row053Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row054Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row055Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row056Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row057Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row058Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row059Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row060Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row061Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row062Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row063Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row064Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row065Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row066Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row067Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row068Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row069Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row070Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row071Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row072Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row073Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row074Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row075Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row076Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row077Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row078Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row079Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row080Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row081Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row082Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row083Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row084Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row085Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row086Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row087Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row088Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row089Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row090Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row091Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row092Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row093Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row094Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row095Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row096Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row097Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row098Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row099Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row100Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row101Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row102Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row103Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row104Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row105Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row106Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row107Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row108Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row109Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row110Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row111Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row112Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row113Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row114Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row115Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row116Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row117Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row118Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row119Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row120Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row121Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row122Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row123Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row124Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row125Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row126Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row127Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row128Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row129Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row130Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row131Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row132Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row133Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row134Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row135Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row136Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row137Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row138Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row139Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row140Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row141Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row142Finite
import ImbalancedChen.P2OriginalSaving19Cell01Row143Finite
import Lean.Util.CollectAxioms

set_option pp.all true
set_option pp.proofs true
set_option pp.deepTerms true
set_option pp.universes true
set_option pp.explicit true
set_option pp.fullNames true
set_option pp.privateNames true
set_option pp.maxSteps 1000000

open Lean Elab Command in
run_cmd do
  let env ← getEnv
  let byModule := env.const2ModIdx.fold
    (init := Array.replicate env.header.moduleNames.size (#[] : Array Name)) fun found n i =>
      if (env.find? n).isSome then found.modify i.toNat (fun ns => ns.push n) else found
  liftIO <| IO.println s!"P26_CELL01_FINITE_AUDIT_IMPORTS {(toJson (env.header.moduleNames.map Name.toString)).compress}"
  for moduleName in #[
      `ImbalancedChen.P2OriginalSaving19Cell01Row001Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row002Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row003Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row004Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row005Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row006Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row007Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row008Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row009Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row010Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row011Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row012Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row013Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row014Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row015Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row016Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row017Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row018Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row019Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row020Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row021Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row022Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row023Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row024Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row025Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row026Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row027Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row028Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row029Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row030Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row031Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row032Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row033Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row034Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row035Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row036Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row037Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row038Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row039Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row040Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row041Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row042Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row043Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row044Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row045Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row046Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row047Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row048Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row049Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row050Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row051Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row052Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row053Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row054Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row055Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row056Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row057Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row058Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row059Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row060Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row061Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row062Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row063Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row064Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row065Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row066Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row067Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row068Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row069Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row070Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row071Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row072Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row073Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row074Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row075Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row076Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row077Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row078Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row079Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row080Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row081Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row082Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row083Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row084Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row085Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row086Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row087Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row088Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row089Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row090Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row091Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row092Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row093Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row094Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row095Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row096Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row097Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row098Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row099Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row100Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row101Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row102Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row103Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row104Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row105Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row106Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row107Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row108Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row109Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row110Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row111Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row112Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row113Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row114Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row115Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row116Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row117Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row118Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row119Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row120Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row121Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row122Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row123Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row124Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row125Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row126Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row127Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row128Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row129Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row130Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row131Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row132Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row133Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row134Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row135Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row136Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row137Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row138Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row139Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row140Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row141Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row142Finite,
      `ImbalancedChen.P2OriginalSaving19Cell01Row143Finite] do
    let some idx := env.getModuleIdx? moduleName | throwError "Missing target module"
    let names := byModule[idx.toNat]!
    let mut serialized : Array Name := #[]
    let mut serializedData : ModuleData := default
    let mut found := false
    for i in List.range env.header.modules.size do
      let imported := env.header.modules[i]!
      if imported.module == moduleName then
        if found then throwError "Duplicate module"
        found := true
        let data := env.header.moduleData[i]!
        if data.isModule || !imported.importAll || !imported.hasData then
          throwError "Incomplete imported legacy data"
        serialized := data.constNames
        serializedData := data
    unless found && serializedData.constants.map ConstantInfo.name == serialized do
      throwError "Incomplete serialized declaration data for {moduleName}"
    let shared := serialized.filter fun n => !names.contains n
    unless names.qsort Name.lt == (serialized.filter fun n => !shared.contains n).qsort Name.lt do
      throwError "Complete serialized/environment inventory mismatch for {moduleName}"
    for name in shared do
      let some raw := serializedData.constants.find? (fun ci => ci.name == name)
        | throwError "Missing serialized shared declaration {name}"
      let some actual := env.find? name | throwError "Missing canonical shared declaration {name}"
      let some ownerIdx := env.getModuleIdxFor? name | throwError "Missing canonical owner {name}"
      let owner := env.header.moduleNames[ownerIdx.toNat]!
      unless owner != moduleName && (`ImbalancedChen).isPrefixOf owner do
        throwError "Unexpected shared owner for {name}"
      let (.thmInfo original, .thmInfo canonical) := (raw, actual)
        | throwError "Only shared theorems are permitted: {name}"
      unless original.name == canonical.name && original.type == canonical.type &&
          original.levelParams == canonical.levelParams && original.all == canonical.all do
        throwError "Shared theorem metadata differs: {name}"
      let aliasName := Name.str `p26Cell01FiniteSharedProofBodyCheck (moduleName.toString ++ "::" ++ name.toString)
      unless (env.toKernelEnv.find? aliasName).isNone do throwError "Non-fresh check name"
      let declaration := Declaration.thmDecl { original with name := aliasName, all := [aliasName] }
      let checked ← match env.toKernelEnv.addDeclCore 0 0 declaration (cancelTk? := none) with
        | .ok checked => pure checked
        | .error ex => throwError "Shared proof kernel rejection: {← ex.toMessageData {} |>.toString}"
      unless (checked.find? aliasName).isSome do throwError "Missing checked shared proof"
      let axioms ← withEnv (Environment.ofKernelEnv checked) (collectAxioms aliasName)
      for ax in axioms do
        unless #[`propext, `Classical.choice, `Quot.sound].contains ax do
          throwError "Forbidden shared-proof axiom {ax}"
      let type ← liftTermElabM do return (← Meta.ppExpr raw.type).pretty
      if type.contains '⋯' then throwError "Truncated shared type"
      let record := Json.mkObj [("name", toJson name.toString), ("module", toJson moduleName.toString),
        ("canonical_module", toJson owner.toString), ("type", toJson type),
        ("identical_body", toJson (original.value == canonical.value)),
        ("identical_metadata", toJson true), ("proof_body_kernel_checked", toJson true),
        ("unsafe", toJson raw.isUnsafe), ("partial", toJson raw.isPartial),
        ("axiom", toJson raw.isAxiom), ("axioms", toJson (axioms.map Name.toString))]
      liftIO <| IO.println s!"P26_CELL01_FINITE_AUDIT_SHARED {record.compress}"
    liftIO <| IO.println s!"P26_CELL01_FINITE_AUDIT_INVENTORY {(Json.mkObj [("module", toJson moduleName.toString), ("serialized", toJson (serialized.map Name.toString)), ("environment", toJson (names.map Name.toString)), ("shared", toJson (shared.map Name.toString))]).compress}"
    for name in names.qsort Name.lt do
      let some info := env.find? name | throwError "Missing inventoried declaration"
      if info.isUnsafe || info.isPartial || info.isAxiom then
        throwError "Unsafe/partial/axiom target {name}"
      let axioms ← collectAxioms name
      for ax in axioms do
        unless #[`propext, `Classical.choice, `Quot.sound].contains ax do
          throwError "Forbidden transitive axiom {ax} in {name}"
      let type ← liftTermElabM do return (← Meta.ppExpr info.type).pretty
      if type.contains '⋯' then throwError "Truncated type"
      let record := Json.mkObj [("name", toJson name.toString),
        ("module", toJson moduleName.toString), ("type", toJson type),
        ("unsafe", toJson info.isUnsafe), ("partial", toJson info.isPartial),
        ("axiom", toJson info.isAxiom), ("axioms", toJson (axioms.map Name.toString))]
      liftIO <| IO.println s!"P26_CELL01_FINITE_AUDIT_DECL {record.compress}"
    liftIO <| IO.println s!"P26_CELL01_FINITE_AUDIT_COMPLETE {(Json.mkObj [("module", toJson moduleName.toString), ("count", toJson names.size), ("shared_count", toJson shared.size), ("serialized_count", toJson serialized.size)]).compress}"
