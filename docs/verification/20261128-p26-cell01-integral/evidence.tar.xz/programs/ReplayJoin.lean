import Lean.CoreM
import Lean.Replay

/-! Verification executable. The unmodified official replay API checks the
incoming declarations against the accepted parent. Shared ImportState keeps
both environments on the same mapped module data; no proof environment is
edited or synthesized by this driver. Full type/axiom auditing is separate. -/
open Lean

def literalNat (value : Expr) : IO Nat := do
  let e := value.consumeMData
  if let some n := e.rawNatLit? then return n
  let args := e.getAppArgs
  if e.getAppFn.constName? == some ``OfNat.ofNat && args.size == 3 then
    if let some n := args[1]!.rawNatLit? then return n
  throw <| IO.userError "Expected quoted natural literal"

def quotedCharacters (initial : Expr) : IO ByteArray := do
  let mut term := initial.consumeMData
  let mut bytes := ByteArray.empty
  while term.getAppFn.constName? != some ``List.nil do
    let args := term.getAppArgs
    unless term.getAppFn.constName? == some ``List.cons && args.size == 3 do
      throw <| IO.userError "Expected quoted List Char"
    let charArgs := args[1]!.getAppArgs
    unless args[1]!.getAppFn.constName? == some ``Char.ofNat && charArgs.size == 1 do
      throw <| IO.userError "Expected quoted Char"
    let n ← literalNat charArgs[0]!
    unless n < 128 do throw <| IO.userError "Unexpected non-ASCII original input"
    bytes := bytes.push n.toUInt8
    term := args[2]!.consumeMData
  return bytes

def quotedPackedCharacters (initial : Expr) : IO ByteArray := do
  let mut pending := #[initial]
  let mut bytes := ByteArray.empty
  while !pending.isEmpty do
    let term := pending.back!.consumeMData
    pending := pending.pop
    let args := term.getAppArgs
    match term.getAppFn.constName? with
    | some `ImbalancedChen.P2OriginalSaving19PackedChars.Tree.empty => pure ()
    | some `ImbalancedChen.P2OriginalSaving19PackedChars.Tree.branch =>
      unless args.size == 2 do throw <| IO.userError "Invalid quoted branch"
      pending := pending.push args[1]! |>.push args[0]!
    | some `ImbalancedChen.P2OriginalSaving19PackedChars.Tree.leaf =>
      unless args.size == 2 do throw <| IO.userError "Invalid quoted leaf"
      let n ← literalNat args[0]!
      let mut word ← literalNat args[1]!
      for _ in List.range n do
        let value := word % 4294967296
        unless value < 128 do throw <| IO.userError "Unexpected non-ASCII original input"
        bytes := bytes.push value.toUInt8
        word := word / 4294967296
      unless word == 0 do throw <| IO.userError "Unexpected high packed digits"
    | _ => throw <| IO.userError "Expected quoted packed tree"
  return bytes

def checkOriginalData (env : Environment) : IO Unit := do
  let some (.defnInfo geometry) := env.find?
      `ImbalancedChen.P2OriginalSaving19Archive.geometryPacked01
    | throw <| IO.userError "Missing original geometry character declaration"
  let geometryBytes ← quotedPackedCharacters geometry.value
  unless geometryBytes == (← IO.FS.readBinFile "/workspace/goldbach-research/eighth-third-minorant-extension-20261009-a23-s23_low-01-cell.witness.json") do
    throw <| IO.userError "Embedded original geometry bytes mismatch"
  let some (.defnInfo moment) := env.find? `ImbalancedChen.P2OriginalSaving19Archive.momentPacked01
    | throw <| IO.userError "Missing original moment packed declaration"
  let momentBytes ← quotedPackedCharacters moment.value
  unless momentBytes == (← IO.FS.readBinFile "/workspace/goldbach-research/eighth-third-moment-refinement-20261009-a23-low-01.witness.json") do
    throw <| IO.userError "Embedded original moment bytes mismatch"
  IO.println s!"P26_CELL01_FINITE_ORIGINAL_BYTES {(Json.mkObj [
    ("geometry_bytes", toJson geometryBytes.size), ("moment_bytes", toJson momentBytes.size),
    ("embedded_original_bytes_match", toJson true)]).compress}"
  (← IO.getStdout).flush

unsafe def main (args : List String) : IO UInt32 := do
  let [manifest] := args | throw <| IO.userError "Expected incoming module list"
  let .ok data := Json.parse (← IO.FS.readFile manifest)
    | throw <| IO.userError "Invalid module-list JSON"
  let .ok entries := data.getArr? | throw <| IO.userError "Expected module array"
  let mut wanted : NameSet := {}
  for entry in entries do
    let .ok name := entry.getStr? | throw <| IO.userError "Expected module name"
    wanted := wanted.insert name.toName
  unless wanted.size == 143 do throw <| IO.userError "Unexpected incoming module count"
  initSearchPath (← findSysroot)
  let baseImports : Array Import := #[
    { module := `ImbalancedChen.P2OriginalSaving19Cell05SourceAttachment },
    { module := `ImbalancedChen.P2OriginalSaving19Cell00SourceAttachment },
    { module := `ImbalancedChen.P2OriginalSaving19Cell05GroupedSeparationComplete },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row000OriginalFloorBridge },
    { module := `ImbalancedChen.P2OriginalSaving19OriginalFloorTransport },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01OriginalFloorInterface },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01GroupedSeparationSigns }]
  let (_, baseState) ← (importModulesCore baseImports).run
  let base ← finalizeImport baseState baseImports {} 0 false false
  let allImports := baseImports ++ #[
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row001Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row002Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row003Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row004Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row005Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row006Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row007Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row008Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row009Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row010Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row011Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row012Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row013Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row014Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row015Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row016Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row017Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row018Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row019Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row020Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row021Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row022Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row023Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row024Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row025Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row026Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row027Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row028Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row029Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row030Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row031Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row032Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row033Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row034Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row035Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row036Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row037Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row038Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row039Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row040Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row041Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row042Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row043Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row044Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row045Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row046Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row047Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row048Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row049Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row050Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row051Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row052Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row053Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row054Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row055Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row056Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row057Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row058Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row059Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row060Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row061Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row062Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row063Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row064Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row065Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row066Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row067Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row068Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row069Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row070Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row071Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row072Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row073Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row074Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row075Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row076Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row077Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row078Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row079Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row080Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row081Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row082Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row083Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row084Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row085Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row086Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row087Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row088Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row089Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row090Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row091Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row092Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row093Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row094Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row095Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row096Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row097Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row098Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row099Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row100Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row101Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row102Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row103Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row104Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row105Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row106Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row107Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row108Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row109Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row110Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row111Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row112Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row113Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row114Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row115Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row116Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row117Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row118Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row119Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row120Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row121Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row122Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row123Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row124Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row125Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row126Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row127Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row128Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row129Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row130Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row131Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row132Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row133Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row134Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row135Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row136Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row137Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row138Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row139Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row140Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row141Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row142Finite },
    { module := `ImbalancedChen.P2OriginalSaving19Cell01Row143Finite }]
  let (_, fullState) ← (importModulesCore allImports).run baseState
  let full ← finalizeImport fullState allImports {} 0 false false
  checkOriginalData full
  let mut newModules : NameSet := {}
  let mut external : Array String := #[]
  for name in full.header.moduleNames do
    if !base.header.moduleNames.contains name then
      newModules := newModules.insert name
      if !(`ImbalancedChen).isPrefixOf name then external := external.push name.toString
  for name in wanted do
    unless newModules.contains name do
      throw <| IO.userError s!"Missing new project module {name}"
  for name in newModules do
    if (`ImbalancedChen).isPrefixOf name && !wanted.contains name then
      throw <| IO.userError s!"Unexpected new project module {name}"
  let constants := full.const2ModIdx.fold (init := ({} : Std.HashMap Name ConstantInfo))
    fun found name idx =>
      if newModules.contains full.header.moduleNames[idx.toNat]! then
        match full.find? name with
        | some ci => found.insert name ci
        | none => found
      else found
  let mut safe : Std.HashMap Name ConstantInfo := {}
  let mut moduleMaps := Array.replicate full.header.moduleNames.size
    ({} : Std.HashMap Name ConstantInfo)
  let mut skippedExternal := 0
  for (name, ci) in constants do
    let some idx := full.getModuleIdxFor? name
      | throw <| IO.userError s!"Missing declaring module for {name}"
    let moduleName := full.header.moduleNames[idx.toNat]!
    if ci.isUnsafe || ci.isPartial then
      if wanted.contains moduleName then
        throw <| IO.userError s!"Unsafe or partial incoming project declaration {name}"
      skippedExternal := skippedExternal + 1
    else
      if ci.isAxiom && !#[`propext, `Classical.choice, `Quot.sound].contains name then
        throw <| IO.userError s!"Forbidden incoming axiom {name}"
      safe := safe.insert name ci
      moduleMaps := moduleMaps.modify idx.toNat (fun found => found.insert name ci)
  IO.println s!"P26_CELL01_FINITE_JOIN_BEGIN {(Json.mkObj [
    ("project_modules", toJson wanted.size), ("new_external_modules", toJson external),
    ("declarations", toJson safe.size), ("skipped_external_execution_helpers", toJson skippedExternal)]).compress}"
  (← IO.getStdout).flush
  let mut checked := base
  let mut processed : NameSet := {}
  for name in base.header.moduleNames do processed := processed.insert name
  let mut replayed := 0
  let mut modules := 0
  for moduleName in full.header.moduleNames do
    if newModules.contains moduleName then
      let some idx := full.getModuleIdx? moduleName
        | throw <| IO.userError s!"Missing module {moduleName}"
      for dependency in full.header.moduleData[idx.toNat]!.imports do
        unless processed.contains dependency.module do
          throw <| IO.userError s!"Non-topological module order: {moduleName} before {dependency.module}"
      let additions := moduleMaps[idx.toNat]!
      checked ← checked.replay additions
      for (name, _) in additions do
        unless (checked.toKernelEnv.find? name).isSome do
          throw <| IO.userError s!"Missing module kernel declaration {name}"
      replayed := replayed + additions.size
      modules := modules + 1
      processed := processed.insert moduleName
      IO.println s!"P26_CELL01_FINITE_JOIN_PROGRESS {(Json.mkObj [
        ("module", toJson moduleName.toString), ("completed_modules", toJson modules),
        ("checked_declarations", toJson replayed)]).compress}"
      (← IO.getStdout).flush
  unless replayed == safe.size do throw <| IO.userError "Incomplete replay count"
  for (name, _) in safe do
    unless (checked.toKernelEnv.find? name).isSome do
      throw <| IO.userError s!"Missing replayed declaration {name}"
  IO.println s!"P26_CELL01_FINITE_JOIN_COMPLETE {(Json.mkObj [
    ("project_modules", toJson wanted.size), ("checked_declarations", toJson safe.size),
    ("new_external_modules", toJson external), ("kernel_replay_succeeded", toJson true),
    ("P2_6_complete", toJson false)]).compress}"
  (← IO.getStdout).flush
  return 0
