#!/usr/bin/env python3
"""Meaningful synthetic state/evidence tests; never executes real processes."""
import hashlib
import json
import os
from pathlib import Path
import sys
import tempfile
import time
import unittest

sys.dont_write_bytecode=True
import batch_engine as b
import controller as c
from approved_helpers import OLD,OLD_STAGE_SHA,FOUNDATION_SHA,GRAPH_SHA,TARGETS,OLD_INPUT,OLD_DATA,pin

ROOT=Path(__file__).resolve().parent
RUN=ROOT/'host-tests'/str(time.time_ns())


def rewrite(path,value):
    Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')


class Fixture:
    def __init__(self):
        self.temp=tempfile.TemporaryDirectory(prefix='SYNTHETIC-',dir=RUN);self.stage=Path(self.temp.name)
        for name in ('project','objects','helpers','state','accepted-contexts','home','tmp','runtime'):(self.stage/name).mkdir()
        self.parent='ImbalancedChen.SyntheticParent';self.calls={};self.bad_shared=False
        psrc=self.stage/'project/ImbalancedChen/SyntheticParent.lean';psrc.parent.mkdir();psrc.write_text('-- synthetic only\n')
        pobj=self.stage/'objects/ImbalancedChen/SyntheticParent.olean';pobj.parent.mkdir();pobj.write_bytes(b'synthetic foundation object')
        self.lib=self.stage/'global-only.bin';self.lib.write_bytes(b'abcdef')
        lean=self.stage/'runtime/lean';checker=self.stage/'runtime/leanchecker';lean.write_bytes(b'not executable');checker.write_bytes(b'not executable either')
        old=self.stage/'OLD_STAGE_REFERENCE.json';old.write_text('{"synthetic_only":true}')
        foundation=self.stage/'FOUNDATION_REFERENCE.json';foundation.write_text('{"synthetic_only":true}')
        graph=self.stage/'GRAPH_REFERENCE.json';graph.write_text('{"synthetic_only":true}')
        files=[pin(psrc),pin(pobj),pin(self.lib),pin(lean),pin(checker),pin(old),pin(foundation),pin(graph)]
        project=[str(psrc)]
        for owner in TARGETS:
            source=self.stage/'project'/Path(owner.replace('.','/')).with_suffix('.lean');source.write_text('import ImbalancedChen.SyntheticParent\n')
            helper=self.stage/'helpers'/(owner+'.Owned.lean');helper.write_text('-- synthetic auditor only\n')
            files += [pin(source),pin(helper)];project.append(str(source))
        code=[pin(ROOT/n) for n in ('controller.py','batch_engine.py','approved_helpers.py')]
        global_ref=b.dump(self.stage/'GLOBAL_INPUTS.json',b.unique(files+code))
        self.ext={'protocol':b.PROTOCOL,'global_inputs':global_ref,'old_stage':pin(old),'foundation':pin(foundation),'graph':pin(graph),
                  'parent_catalog':{self.parent:{'source':pin(psrc),'selected_object':pin(pobj)}},'native_artifacts':[],
                  'runtime':{'lean':pin(lean),'leanchecker':pin(checker)},'environment':{'sysroot':str(self.stage/'runtime')},
                  'lean_path':str(self.stage/'objects'),'external_modules':['Init'],'code_pins':code,'project_files':sorted(project),
                  'rss_gib':1,'wall_seconds':10,'synthetic_fixture':True,'formal_acceptance':False}
        ep=b.dump(self.stage/'BATCH_EXTENSION.json',self.ext)
        self.batch={'protocol':b.PROTOCOL,'extension':ep,'owners':TARGETS,'global_inputs':global_ref,
                    'environment_sha256':b.env_hash(b.env_for(self.stage,self.ext)),'concurrency':1,'failure_policy':'atomic_two_owners','formal_acceptance':False}
        b.dump(self.stage/'BATCH.json',self.batch)

    def close(self):self.temp.cleanup()

    def fake(self,mode,owner,argv,cwd,env,log,timeout,rss):
        self.calls[(owner,mode)]=self.calls.get((owner,mode),0)+1
        if mode=='normal':
            Path(argv[argv.index('-o')+1]).write_bytes(('SYNTHETIC_OBJECT_'+owner).encode());text='synthetic normal output\n'
        elif mode=='stock-leanchecker':text='synthetic stock checker output\n'
        else:
            imports=[self.parent,*TARGETS[:TARGETS.index(owner)+1],'Init'];name=owner+'.syntheticFact'
            declaration={'module':owner,'name':name,'type':'Nat','unsafe':False,'partial':False,'axiom':False,'axioms':[]}
            serialized=[name];shared=[]
            rows=[('IMPORTS',imports),('DECL',declaration)]
            if self.bad_shared:
                shared=['synthetic.shared'];serialized+=shared
                rows.append(('SHARED',{**declaration,'name':shared[0],'canonical_module':self.parent,'identical_metadata':True,
                                       'identical_body':False,'proof_body_kernel_checked':False}))
            rows += [('INVENTORY',{'module':owner,'serialized':serialized,'environment':[name],'shared':shared}),
                     ('COMPLETE',{'module':owner,'count':1,'shared_count':len(shared),'serialized_count':len(serialized)})]
            text=''.join('P26_CELL06_AUDIT_'+tag+' '+json.dumps(value)+'\n' for tag,value in rows)
        Path(log).write_text(text)
        return {'exit_code':0,'stop_reason':None,'seconds':0.0,'sampled_peak_tree_rss_bytes':0}

    def pre(self):return b.pre_anchor(self.stage,self.ext,self.batch)

    def normal_only(self):
        pre=self.pre();record=b.run_mode(self.stage,self.ext,self.batch,TARGETS[0],'normal',pre,[],{},self.fake)
        return pre,record

    def all_pending(self):
        pre=self.pre();history,pending=b.execute_pending(self.stage,self.ext,self.batch,pre,self.fake)
        return pre,history,pending


class ProtocolTests(unittest.TestCase):
    def setUp(self):self.f=Fixture()
    def tearDown(self):self.f.close()

    def test_complete_atomic_batch_pending_then_sealed_and_contexts_recover(self):
        f=self.f;pre,history,pending=f.all_pending()
        self.assertEqual(len(history),6);self.assertFalse((f.stage/'state/BATCH_ACCEPTED.json').exists())
        for item in history:
            self.assertFalse(b.read(item['marker']['path'])['formal_acceptance'])
            self.assertEqual(b.read(item['result']['path'])['global_validation_scope'],'batch_boundary')
            self.assertNotIn('postcheck',b.read(item['result']['path']))
        seal=b.finish(f.stage,f.ext,f.batch,pre,history,pending)
        self.assertTrue(b.read(seal['path'])['formal_acceptance']);self.assertEqual(sum(f.calls.values()),6)
        second=f.stage/'accepted-contexts'/(TARGETS[1]+'.json');second.unlink()
        self.assertEqual(b.run_batch(f.stage,f.ext,f.batch,f.fake),seal);self.assertTrue(second.exists());self.assertEqual(sum(f.calls.values()),6)

    def test_missing_POST_runs_only_POST_and_no_executor(self):
        f=self.f;f.all_pending();before=dict(f.calls);purposes=[];original=b.snapshot
        def measured(*args,**kwargs):purposes.append(args[3]);return original(*args,**kwargs)
        b.snapshot=measured
        try:b.run_batch(f.stage,f.ext,f.batch,f.fake)
        finally:b.snapshot=original
        self.assertEqual(purposes,['POST']);self.assertEqual(f.calls,before)

    def test_normal_success_resume_does_not_reexecute_and_restores_canonical(self):
        f=self.f;pre,normal=f.normal_only();b.catalog_objects(f.stage,f.ext,{TARGETS[0]:normal})
        canonical=f.stage/'objects'/Path(TARGETS[0].replace('.','/')).with_suffix('.olean');canonical.unlink()
        b.run_batch(f.stage,f.ext,f.batch,f.fake)
        self.assertEqual(f.calls[(TARGETS[0],'normal')],1);self.assertTrue(canonical.exists())

    def test_fresh_stage_cannot_bypass_a_successful_normal(self):
        f=self.f;f.normal_only();other=Fixture()
        try:
            with self.assertRaisesRegex(RuntimeError,'Other-stage successful normal'):
                b.run_batch(other.stage,other.ext,other.batch,other.fake)
            self.assertEqual(sum(other.calls.values()),0);self.assertEqual(f.calls[(TARGETS[0],'normal')],1)
        finally:other.close()

    def test_transport_copy_has_independent_inode_and_rejects_hardlink(self):
        f=self.f;target=f.stage/'independent-copy.bin';actual=b.copy_exact(f.lib,target,pin(f.lib))
        self.assertEqual(actual['sha256'],pin(f.lib)['sha256']);self.assertNotEqual(target.stat().st_ino,f.lib.stat().st_ino)
        alias=f.stage/'hardlink-copy.bin';os.link(f.lib,alias)
        with self.assertRaisesRegex(RuntimeError,'independent inodes'):b.copy_exact(f.lib,alias,pin(f.lib))

    def test_all_canonical_outputs_restore_before_later_LOCAL_INPUTS(self):
        f=self.f;f.all_pending();before=dict(f.calls)
        for owner in TARGETS:(f.stage/'objects'/Path(owner.replace('.','/')).with_suffix('.olean')).unlink()
        b.run_batch(f.stage,f.ext,f.batch,f.fake)
        self.assertEqual(f.calls,before)
        self.assertTrue(all((f.stage/'objects'/Path(owner.replace('.','/')).with_suffix('.olean')).exists() for owner in TARGETS))

    def test_missing_pending_marker_is_recovered_from_exact_success_result(self):
        f=self.f;pre,normal=f.normal_only();Path(normal['marker']['path']).unlink()
        b.run_batch(f.stage,f.ext,f.batch,f.fake);self.assertEqual(f.calls[(TARGETS[0],'normal')],1)

    def test_POST_integrity_failure_stays_failed_after_bytes_are_restored(self):
        f=self.f;pre,history,pending=f.all_pending();raw=f.lib.read_bytes();stat=f.lib.stat();f.lib.write_bytes(b'ABCDEF');os.utime(f.lib,ns=(stat.st_atime_ns,stat.st_mtime_ns))
        with self.assertRaises(RuntimeError):b.finish(f.stage,f.ext,f.batch,pre,history,pending)
        self.assertTrue((f.stage/'state/INTEGRITY_FAILED.json').exists());f.lib.write_bytes(raw)
        with self.assertRaises(RuntimeError):b.run_batch(f.stage,f.ext,f.batch,f.fake)
        self.assertEqual(sum(f.calls.values()),6);self.assertFalse((f.stage/'state/BATCH_ACCEPTED.json').exists())

    def test_global_POST_does_not_use_old_cached_check(self):
        f=self.f;pre,history,pending=f.all_pending();original=OLD.evidence.check;OLD.evidence.check=lambda item:None
        f.lib.write_bytes(b'ABCDEF')
        try:
            with self.assertRaises(RuntimeError):b.finish(f.stage,f.ext,f.batch,pre,history,pending)
        finally:OLD.evidence.check=original
        self.assertTrue((f.stage/'state/INTEGRITY_FAILED.json').exists())

    def test_observed_log_D_mismatch_cannot_turn_green_after_restore(self):
        f=self.f;pre,normal=f.normal_only();log=Path(normal['log']['path']);raw=log.read_bytes();log.write_bytes(b'tampered log')
        with self.assertRaises(RuntimeError):b.run_batch(f.stage,f.ext,f.batch,f.fake)
        self.assertTrue((f.stage/'state/INTEGRITY_FAILED.json').exists());log.write_bytes(raw)
        with self.assertRaises(RuntimeError):b.run_batch(f.stage,f.ext,f.batch,f.fake)
        self.assertEqual(f.calls[(TARGETS[0],'normal')],1)

    def test_anchored_global_selector_graph_oldstage_and_foundation_mismatch_stick(self):
        for key in ('global_inputs','graph','old_stage','foundation'):
            fixture=Fixture()
            try:
                es=pin(fixture.stage/'BATCH_EXTENSION.json')['sha256'];bs=pin(fixture.stage/'BATCH.json')['sha256'];cs=pin(ROOT/'controller.py')['sha256']
                path=Path(fixture.ext[key]['path']);raw=path.read_bytes();path.write_bytes(b'changed anchored content')
                with self.assertRaises(RuntimeError):b.load_contract(fixture.stage,es,bs,cs)
                self.assertTrue((fixture.stage/'state/INTEGRITY_FAILED.json').exists());path.write_bytes(raw)
                with self.assertRaises(RuntimeError):b.load_contract(fixture.stage,es,bs,cs)
                self.assertEqual(sum(fixture.calls.values()),0)
            finally:fixture.close()

    def test_unknown_COMMAND_interruption_never_guesses_or_reruns_normal(self):
        f=self.f;pre,normal=f.normal_only();Path(normal['result']['path']).unlink();Path(normal['marker']['path']).unlink()
        with self.assertRaisesRegex(RuntimeError,'Unknown COMMAND'):b.run_batch(f.stage,f.ext,f.batch,f.fake)
        self.assertEqual(f.calls[(TARGETS[0],'normal')],1)

    def test_provisional_object_mismatch_is_sticky(self):
        f=self.f;pre,normal=f.normal_only();b.catalog_objects(f.stage,f.ext,{TARGETS[0]:normal})
        target=f.stage/'objects'/Path(TARGETS[0].replace('.','/')).with_suffix('.olean');target.write_bytes(b'wrong provisional object')
        with self.assertRaises(RuntimeError):b.run_batch(f.stage,f.ext,f.batch,f.fake)
        self.assertTrue((f.stage/'state/INTEGRITY_FAILED.json').exists());self.assertEqual(f.calls[(TARGETS[0],'normal')],1)

    def test_D_construction_tamper_sticks_before_next_mode_even_after_restore(self):
        f=self.f;pre,normal=f.normal_only();pending={TARGETS[0]:normal};b.catalog_objects(f.stage,f.ext,pending)
        canonical=f.stage/'objects'/Path(TARGETS[0].replace('.','/')).with_suffix('.olean');raw=canonical.read_bytes();canonical.write_bytes(b'altered during pending phase')
        with self.assertRaises(RuntimeError):b.run_mode(f.stage,f.ext,f.batch,TARGETS[0],'stock-leanchecker',pre,[normal],pending,f.fake)
        self.assertTrue((f.stage/'state/INTEGRITY_FAILED.json').exists());canonical.write_bytes(raw)
        with self.assertRaises(RuntimeError):b.run_mode(f.stage,f.ext,f.batch,TARGETS[0],'stock-leanchecker',pre,[normal],pending,f.fake)
        self.assertEqual(f.calls.get((TARGETS[0],'stock-leanchecker'),0),0);self.assertEqual(f.calls[(TARGETS[0],'normal')],1)

    def test_shared_original_body_without_kernel_check_is_rejected(self):
        f=self.f;f.bad_shared=True
        with self.assertRaises(RuntimeError):b.run_batch(f.stage,f.ext,f.batch,f.fake)
        self.assertFalse((f.stage/'state/BATCH_ACCEPTED.json').exists());self.assertEqual(f.calls[(TARGETS[0],'normal')],1)

    def test_mode_cannot_claim_old_per_command_global_success(self):
        f=self.f;pre,normal=f.normal_only();path=Path(normal['result']['path']);value=b.read(path);value['postcheck']={'all_files_matched':True,'file_count':999};rewrite(path,value)
        with self.assertRaisesRegex(RuntimeError,'falsely reports'):b.run_batch(f.stage,f.ext,f.batch,f.fake)
        self.assertEqual(f.calls[(TARGETS[0],'normal')],1)

    def test_source_change_is_rejected_and_no_green_after_restore(self):
        f=self.f;f.pre();source=f.stage/'project'/Path(TARGETS[0].replace('.','/')).with_suffix('.lean');raw=source.read_text();source.write_text(raw+'-- changed source\n')
        with self.assertRaises(RuntimeError):b.run_batch(f.stage,f.ext,f.batch,f.fake)
        source.write_text(raw)
        with self.assertRaises(RuntimeError):b.run_batch(f.stage,f.ext,f.batch,f.fake)
        self.assertTrue((f.stage/'state/INTEGRITY_FAILED.json').exists())

    def test_contract_SHA_and_environment_identity_gates(self):
        f=self.f;controller_sha=pin(ROOT/'controller.py')['sha256'];es=pin(f.stage/'BATCH_EXTENSION.json')['sha256'];bs=pin(f.stage/'BATCH.json')['sha256']
        for args in [('0'*64,bs,controller_sha),(es,'0'*64,controller_sha),(es,bs,'0'*64)]:
            with self.assertRaises(RuntimeError):b.load_contract(f.stage,*args)
            self.assertFalse((f.stage/'state/INTEGRITY_FAILED.json').exists())
        value=b.read(f.stage/'BATCH.json');value['environment_sha256']='0'*64;rewrite(f.stage/'BATCH.json',value)
        with self.assertRaisesRegex(RuntimeError,'environment'):b.load_contract(f.stage,es,pin(f.stage/'BATCH.json')['sha256'],controller_sha)

    def test_pending_receipt_environment_or_contract_transplant_rejected(self):
        f=self.f;pre,normal=f.normal_only();path=Path(normal['command']['path']);value=b.read(path);value['identity']['environment_sha256']='0'*64;rewrite(path,value)
        with self.assertRaisesRegex(RuntimeError,'receipt'):b.run_batch(f.stage,f.ext,f.batch,f.fake)
        self.assertEqual(f.calls[(TARGETS[0],'normal')],1)

    def test_result_reference_transplant_is_rejected(self):
        f=self.f;pre,normal=f.normal_only();path=Path(normal['result']['path']);value=b.read(path)
        value['command']=pin(f.stage/'FOUNDATION_REFERENCE.json');rewrite(path,value)
        with self.assertRaisesRegex(RuntimeError,'chain differs'):b.run_batch(f.stage,f.ext,f.batch,f.fake)
        self.assertEqual(f.calls[(TARGETS[0],'normal')],1)

    def test_other_attempt_log_or_LOCAL_INPUTS_path_is_rejected(self):
        f=self.f;pre,normal=f.normal_only();path=Path(normal['result']['path']);value=b.read(path)
        other=f.stage/'same-content-other-log';other.write_bytes(Path(value['log']['path']).read_bytes());value['log']=pin(other);rewrite(path,value)
        with self.assertRaisesRegex(RuntimeError,'Log must belong'):b.run_batch(f.stage,f.ext,f.batch,f.fake)
        self.assertEqual(f.calls[(TARGETS[0],'normal')],1)

    def test_PROCESS_RETURN_status_or_sidefile_transplant_is_rejected(self):
        f=self.f;pre,normal=f.normal_only();path=Path(normal['result']['path']);value=b.read(path);returned_path=Path(value['process_return']['path'])
        returned=b.read(returned_path);returned['process_result']['seconds']=123.0;rewrite(returned_path,returned)
        value['process_return']=pin(returned_path);rewrite(path,value)
        with self.assertRaisesRegex(RuntimeError,'process return fields'):b.run_batch(f.stage,f.ext,f.batch,f.fake)
        self.assertEqual(f.calls[(TARGETS[0],'normal')],1)

    def test_pending_batch_identity_transplant_is_rejected(self):
        f=self.f;pre,normal=f.normal_only();path=Path(normal['command']['path']);value=b.read(path)
        value['identity']['batch']={**value['identity']['batch'],'sha256':'0'*64};rewrite(path,value)
        with self.assertRaisesRegex(RuntimeError,'receipt'):b.run_batch(f.stage,f.ext,f.batch,f.fake)
        self.assertEqual(f.calls[(TARGETS[0],'normal')],1)

    def test_unknown_namespace_and_final_D_sidecar_are_rejected(self):
        f=self.f;pre,history,pending=f.all_pending();(f.stage/'steps/UNAUTHORIZED').mkdir();(f.stage/'steps/UNAUTHORIZED/output.log').write_text('unknown')
        with self.assertRaises(RuntimeError):b.finish(f.stage,f.ext,f.batch,pre,history,pending)
        self.assertTrue((f.stage/'state/INTEGRITY_FAILED.json').exists())

    def test_strict_flags_and_environment_do_not_inherit_injection(self):
        f=self.f;previous=os.environ.get('LD_PRELOAD');os.environ['LD_PRELOAD']='SYNTHETIC_INJECTION'
        try:
            env=b.env_for(f.stage,f.ext);self.assertNotIn('LD_PRELOAD',env);self.assertNotIn('PYTHONPATH',env)
            self.assertEqual(set(env),{'HOME','TMPDIR','LANG','LC_ALL','TZ','LEAN_PATH','LEAN_NUM_THREADS','OMP_NUM_THREADS','LEAN_SYSROOT','PATH'})
            for mode in b.MODES:
                argv=b.argv_for(f.stage,f.ext,TARGETS[0],mode)
                if mode!='stock-leanchecker':self.assertIn('--trust=0',argv);self.assertIn('-DwarningAsError=true',argv)
                else:self.assertIn('--verbose',argv)
        finally:
            if previous is None:os.environ.pop('LD_PRELOAD',None)
            else:os.environ['LD_PRELOAD']=previous


class MetadataOnlyTests(unittest.TestCase):
    def test_readonly_helper_import_does_not_shadow_new_controller(self):
        self.assertEqual(Path(c.__file__).resolve(),ROOT/'controller.py');self.assertTrue(callable(c.validate_foundation))
        self.assertNotEqual(c,OLD.controller)
    def test_real_graph_next_two_and_old_foundation_pins_metadata_only(self):
        old=Path('/workspace/p26-cell06-source-candidate-20261128/runner/stages/cell06-parent1499-v1')
        context=old/'accepted-contexts'/(OLD_INPUT+'.json');graph=Path('/workspace/p26-cell06-source-candidate-20261128/CANDIDATE_GRAPH_v2.json')
        self.assertEqual(pin(old/'STAGE.json')['sha256'],OLD_STAGE_SHA);self.assertEqual(pin(context)['sha256'],FOUNDATION_SHA);self.assertEqual(pin(graph)['sha256'],GRAPH_SHA)
        foundation=b.read(context);g=b.read(graph);self.assertTrue(foundation['formal_acceptance']);self.assertEqual(len(foundation['project_closure']),1502)
        self.assertEqual([m for m in g['topological_order'] if m not in foundation['project_closure']][:2],TARGETS)

    def test_wrong_old_stage_or_changed_graph_is_rejected_before_transport(self):
        with self.assertRaises(RuntimeError):c.validate_foundation('/not-opened','0'*64,'/not-opened',FOUNDATION_SHA,'/not-opened',GRAPH_SHA)
        with self.assertRaises(RuntimeError):c.validate_foundation('/not-opened',OLD_STAGE_SHA,'/not-opened',FOUNDATION_SHA,'/not-opened','0'*64)


if __name__=='__main__':
    RUN.mkdir(parents=True,exist_ok=False)
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(sys.modules[__name__]))
    report={'schema':'p26_batch_boundary_fake_host_tests_v1','tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
            'synthetic_executor_only':True,'real_prepare_executed':False,'Lean_commands':0,'MCP_jobs':0,'formal_acceptance':False,'P2_6_complete':False,
            'code_pins':[pin(ROOT/n) for n in ('controller.py','batch_engine.py','approved_helpers.py','test_host.py')]}
    b.dump(RUN/'HOST_TEST_RESULTS.json',report);print(json.dumps({'report':pin(RUN/'HOST_TEST_RESULTS.json'),**{k:v for k,v in report.items() if k!='code_pins'}}))
    raise SystemExit(0 if result.wasSuccessful() else 1)
