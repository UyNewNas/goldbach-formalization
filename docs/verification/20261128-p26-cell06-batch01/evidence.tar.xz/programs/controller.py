#!/usr/bin/env python3
"""Explicitly anchored two-owner batch controller candidate. Never runs old step."""
import argparse
import fcntl
import json
from pathlib import Path
import shutil
import sys
import time

sys.dont_write_bytecode=True
from approved_helpers import (OLD,OLD_ROOT,OLD_DELIVERY_SHA,OLD_STAGE_SHA,FOUNDATION_SHA,GRAPH_SHA,
                              OLD_INPUT,OLD_DATA,TARGETS,pin,require)
import batch_engine as engine

ROOT=Path(__file__).resolve().parent


def checked(item):
    engine.check(item);return engine.read(item['path'])


def receipt_inputs(receipt):
    seal=checked(receipt);result=checked(seal['result']);command=checked(result['command'])
    spec=checked(command['inputs'])
    return engine.unique([receipt,seal['result'],result['command'],command['inputs'],result['log'],
                          *OLD.evidence.expand_inputs(spec),*([result['object']] if result.get('object') else [])])


def validate_foundation(old_stage,old_stage_sha,foundation,foundation_sha,graph,graph_sha):
    require(old_stage_sha==OLD_STAGE_SHA and foundation_sha==FOUNDATION_SHA and graph_sha==GRAPH_SHA,'Only the reviewed same-source1502 foundation is supported')
    old_stage=Path(old_stage).absolute();foundation=Path(foundation).absolute();graph=Path(graph).absolute()
    require(pin(old_stage/'STAGE.json')['sha256']==old_stage_sha,'Old stage root differs')
    require(pin(foundation)['sha256']==foundation_sha and pin(graph)['sha256']==graph_sha,'Foundation/graph external SHA differs')
    with OLD.evidence.verification_transaction():
        old_context,old_graph,old_env,_=OLD.controller.load_stage(old_stage,old_stage_sha)
        data,data_path=OLD.controller.qualified(old_stage)
        current=engine.read(foundation)
        require(current['formal_acceptance'] is True and current['P2_6_complete'] is False,'Foundation is not formally accepted')
        require(current['stage_contract']==pin(old_stage/'STAGE.json') and current['accepted_parent']==pin(data_path),'Foundation ancestry differs')
        require(current['accepted_new_modules']==[OLD_INPUT] and len(current['project_closure'])==1502,'Wrong accepted prefix')
        require(current['runtime']==data['runtime'] and current['native_artifacts']==data['native_artifacts'] and current['lean_path']==data['lean_path'],'Foundation runtime/native/search changed')
        require(len(current['receipts'])==3,'Old Input needs all three real receipts')
        old_env_hash=OLD.evidence.environment_sha256(old_env)
        for receipt,mode in zip(current['receipts'],engine.MODES):
            OLD.evidence.check_receipt_chain(receipt,pin(old_stage/'STAGE.json'),OLD_INPUT,mode,old_env_hash,
                                            OLD.controller.expected_argv(old_stage,old_context,OLD_INPUT,mode))
        OLD.controller.validate_catalog(old_stage,old_context,old_graph,current['project_closure'],[OLD_INPUT])
        for module,info in data['project_closure'].items():require(current['project_closure'][module]==info,'Accepted Data2/parent catalog changed')
        normal=checked(current['receipts'][0]);normal_result=checked(normal['result'])
        require(all(normal_result['object'][k]==current['project_closure'][OLD_INPUT]['selected_object'][k] for k in ('bytes','sha256')),'Old normal artifact differs from accepted object')
        audit_seal=checked(current['receipts'][2]);audit_result=checked(audit_seal['result'])
        audited=OLD.evidence.validate_audit(Path(audit_result['log']['path']).read_text(),[OLD_INPUT],set(current['project_closure']),data['external_modules'])
        require(audit_seal['validated']==audited,'Old full-owned evidence differs')
        supplied=engine.read(graph)
        require(supplied==old_graph,'Same frozen source graph required')
        require(set(supplied['entries'])&set(current['project_closure'])==set(OLD_DATA+[OLD_INPUT]),'Unexpected graph/accepted overlap')
        remaining=[m for m in supplied['topological_order'] if m not in current['project_closure']]
        require(remaining[:2]==TARGETS,'The next two real graph owners differ')
        require(len(remaining)==331,'Expected331 remaining normal targets')
        for owner in TARGETS:
            dependencies={n for n in supplied['entries'][owner]['imports'] if n.startswith('ImbalancedChen.')}
            require(dependencies<=set(current['project_closure'])|set(TARGETS[:TARGETS.index(owner)]),'First batch has unaccepted dependencies')
        watched=OLD.evidence.expand_inputs(current['pins'])+[pin(foundation),pin(data_path),pin(graph),OLD.delivery,*OLD.code]
        watched += OLD.evidence.expand_inputs(data['pins'])
        for receipt in data['receipts']+current['receipts']:watched += receipt_inputs(receipt)
        for row in OLD.evidence.read(old_context['baseline_inputs']['path']):watched.append(row)
        watched += [old_context['baseline_inputs'],old_context['environment_lock']]
        for row in OLD.evidence.read(OLD.delivery['path'])['members']:watched.append(row)
        for row in supplied['entries'].values():
            watched.append(row['source'])
            if 'object' in row:watched.append(row['object'])
        watched += supplied['candidate_manifests']+[supplied['restoration_report']]
        for item in engine.unique(watched):OLD.evidence.check(item)
    return current,old_context,supplied,data,engine.unique(watched)


def prepare(args):
    started=time.monotonic()
    require(pin(ROOT/'controller.py')['sha256']==args.controller_sha256,'Externally supplied new controller SHA differs')
    stage=engine.writable(args.stage);require(not stage.exists(),'Exclusive fresh extension stage required')
    require(args.rss_gib>0 and args.wall_seconds>0,'Positive resource limits required')
    current,old_context,graph,data,watched=validate_foundation(args.old_stage,args.old_stage_sha256,args.parent_context,args.parent_sha256,args.graph,args.graph_sha256)
    validated_seconds=time.monotonic()-started
    source_pins=[i['source'] for i in current['project_closure'].values()]+[i['source'] for i in graph['entries'].values()]
    object_pins=[i['selected_object'] for i in current['project_closure'].values()]+current['native_artifacts']
    need=sum(i['bytes'] for i in engine.unique(source_pins+object_pins+OLD.controller.RAWS))
    require(shutil.disk_usage(ROOT).free>need+2*1024**3,'Not enough disk for independent copies plus2GiB reserve')
    stage.mkdir(parents=True)
    for name in ('project','objects','helpers','home','tmp','state','accepted-contexts'):(stage/name).mkdir()
    catalog={};native=[];new_pins=[];transport=[]
    for module,info in current['project_closure'].items():
        relative=Path(module.replace('.','/'))
        source=engine.copy_exact(info['source']['path'],stage/'project'/relative.with_suffix('.lean'),info['source'])
        obj=engine.copy_exact(info['selected_object']['path'],stage/'objects'/relative.with_suffix('.olean'),info['selected_object'])
        catalog[module]={'source':source,'selected_object':obj,'origin':'same_bytes_readonly1502_transport'}
        new_pins += [source,obj];transport.append({'module':module,'old_source':info['source'],'old_object':info['selected_object'],'new_source':source,'new_object':obj})
    old_root=Path(current['lean_path'].split(':')[0])
    for item in current['native_artifacts']:
        target=engine.copy_exact(item['path'],stage/'objects'/Path(item['path']).relative_to(old_root),item)
        native.append(target);new_pins.append(target)
    for module,row in graph['entries'].items():
        target=engine.copy_exact(row['source']['path'],stage/'project'/Path(module.replace('.','/')).with_suffix('.lean'),row['source'])
        new_pins.append(target)
    raw_copies=[]
    for item in OLD.controller.RAWS:
        raw_copies.append(engine.copy_exact(item['path'],stage/'goldbach-research'/Path(item['path']).name,item));new_pins.append(raw_copies[-1])
    helpers=[]
    for index,owner in enumerate(TARGETS):
        text=OLD.templates.audit(sorted(catalog)+TARGETS[:index+1],[owner])
        path=stage/'helpers'/(owner+'.Owned.lean')
        with path.open('x') as f:f.write(text)
        helpers.append(pin(path))
    whitelist=engine.dump(stage/'WHITELIST.json',TARGETS)
    transported=engine.dump(stage/'FOUNDATION_TRANSPORT.json',{'old_stage':pin(Path(args.old_stage)/'STAGE.json'),'foundation':pin(args.parent_context),
                           'graph':pin(args.graph),'same_source_only':True,'old_receipts':current['receipts']+data['receipts'],
                           'modules':transport,'native_files':native,'independent_inode_copies':True,'old_normal_recompilations':0,
                           'formal_acceptance':False,'scope':'Exact byte transport inherits only the pinned old accepted prefix; no new mathematical owner accepted.'})
    code=[pin(ROOT/n) for n in ('controller.py','batch_engine.py','approved_helpers.py','IMPLEMENTATION_PLAN.md','README.md')]
    references=[pin(OLD.templates.REFERENCES/'OwnedSuppliersAudit.lean'),pin(OLD.templates.REFERENCES/'ReplayJoin.lean')]
    global_map=engine.unique(watched+new_pins+helpers+[whitelist,transported,*code,*references])
    for item in global_map:engine.check(item)
    global_manifest=engine.dump(stage/'GLOBAL_INPUTS.json',global_map)
    extension={'schema':'p26_cell06_same_source_batch_extension_v1','protocol':engine.PROTOCOL,'formal_acceptance':False,'P2_6_complete':False,
               'old_stage':pin(Path(args.old_stage)/'STAGE.json'),'old_delivery':OLD.delivery,'foundation':pin(args.parent_context),'graph':pin(args.graph),
               'parent_catalog':catalog,'native_artifacts':native,'runtime':current['runtime'],'environment':old_context['environment'],
               'lean_path':str(stage/'objects')+':'+current['lean_path'].split(':',1)[1],
               'external_modules':data['external_modules'],'global_inputs':global_manifest,'code_pins':code,
               'project_files':sorted({p['path'] for p in new_pins if p['path'].endswith('.lean')}),
               'transport':transported,'rss_gib':args.rss_gib,'wall_seconds':args.wall_seconds,
               'old_normal_excluded':OLD_DATA+[OLD_INPUT],'allowed_new_owners':TARGETS,'raw_copies':raw_copies,
               'same_source_graph_required':True,'source_repair_transport_implemented':False,
               'preparation_seconds':time.monotonic()-started,'foundation_validation_seconds':validated_seconds,
               'copy_bytes_upper_bound':need,'scope':'Two-owner batch with global PRE/POST; old accepted proofs retain their old contract identity.'}
    extension_pin=engine.dump(stage/'BATCH_EXTENSION.json',extension)
    batch={'schema':'p26_cell06_atomic_two_owner_batch_v1','protocol':engine.PROTOCOL,'extension':extension_pin,'owners':TARGETS,
           'global_inputs':global_manifest,'environment_sha256':engine.env_hash(engine.env_for(stage,extension)),
           'concurrency':1,'failure_policy':'atomic_two_owners','whitelist':whitelist,'formal_acceptance':False,'P2_6_complete':False,
           'global_validation_scope':'batch_boundary','normal_success_recompile_allowed':False}
    batch_pin=engine.dump(stage/'BATCH.json',batch)
    print(json.dumps({'extension':extension_pin,'batch':batch_pin,'prepared_not_executed':True,'Lean_commands':0,'formal_acceptance':False,
                      'foundation_validation_seconds':validated_seconds,'total_prepare_seconds':time.monotonic()-started}))


def run(args):
    extension,batch=engine.load_contract(args.stage,args.extension_sha256,args.batch_sha256,args.controller_sha256)
    require(extension.get('synthetic_fixture') is not True,'CLI forbids synthetic fixtures')
    require(extension['old_stage']['sha256']==OLD_STAGE_SHA and extension['foundation']['sha256']==FOUNDATION_SHA and extension['graph']['sha256']==GRAPH_SHA,'Wrong fixed foundation')
    require(batch['owners']==TARGETS and extension['old_normal_excluded']==OLD_DATA+[OLD_INPUT],'Wrong whitelist/normal exclusions')
    seal=engine.run_batch(args.stage,extension,batch)
    print(json.dumps({'batch_accepted':seal,'formal_acceptance':True,'P2_6_complete':False,'scope':'Only the exact two-owner batch and inherited prefix.'}))


def main():
    p=argparse.ArgumentParser(description=__doc__);s=p.add_subparsers(dest='action',required=True)
    q=s.add_parser('prepare');q.add_argument('--controller-sha256',required=True);q.add_argument('--old-stage',type=Path,required=True);q.add_argument('--old-stage-sha256',required=True)
    q.add_argument('--parent-context',type=Path,required=True);q.add_argument('--parent-sha256',required=True);q.add_argument('--graph',type=Path,required=True);q.add_argument('--graph-sha256',required=True)
    q.add_argument('--stage',type=Path,required=True);q.add_argument('--rss-gib',type=int,default=12);q.add_argument('--wall-seconds',type=int,default=2400);q.set_defaults(handler=prepare)
    q=s.add_parser('run');q.add_argument('--controller-sha256',required=True);q.add_argument('--stage',type=Path,required=True);q.add_argument('--extension-sha256',required=True);q.add_argument('--batch-sha256',required=True);q.set_defaults(handler=run)
    args=p.parse_args()
    # Lock lives only in the new controller root, never the old stage/provider.
    with (ROOT/'EXECUTION.lock').open('a+') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);args.handler(args)


if __name__=='__main__':main()
