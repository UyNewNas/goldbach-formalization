# Cell06 batch-boundary implementation plan

**Approved design:** `/workspace/p26-cell06-source-candidate-20261128/batch-performance-plan/DESIGN.md`; root selected `batch_global_boundary_v1`, exactly two sequential owners, with a new batch-level global validation window.

**Writable root:** `/workspace/p26-cell06-batch-boundary-20261128/` only. Old runner, old STAGE83affec..., all accepted receipts/objects, original sources/JSON and graph remain read-only. No real prepare, Lean/lake/MCP execution, Git mutation or agent delegation during implementation.

**Files:** `approved_helpers.py` loads pinned read-only streamhash/process/audit helpers; `batch_engine.py` implements new evidence/state semantics; `controller.py` validates and transports the exact1502 foundation into independent copies and freezes extension/batch roots; `test_host.py` exercises synthetic fake processes and negative cases; `README.md` documents CLI and gaps.

- [x] Implement candidate exact oldStage/1502/old-delivery/graph validation, old Data2+Input receipt inheritance, and same-source transport with independent inode copies and complete first object root. No real transport/prepare has run.
- [x] Implement new extension and batch SHA roots, helpers/whitelist/global inputs frozen before PRE, strict flags/allowlist environment, exact next two graph owners and resource limits.
- [x] Implement uncached global PRE/POST byte scans and namespace checks, per-mode D byte checks, pending process records and permanent normal barriers; no old per-step global-success fields.
- [x] Implement sticky integrity failure, unknown-intent rejection, same-byte missing-mode/POST recovery, and atomic batch/prefix acceptance only after final global and D checks.
- [x] Run fake host tests for interruption/transplant/source/shared/provisional/scope/cache negatives; prepare final pins and document unmeasured resources and unsupported source-repair migration.

All code remains a review candidate until root reviews it and arranges real execution. No larger batches, parallel workers, source repair or generic cross-stage migration are in scope.
