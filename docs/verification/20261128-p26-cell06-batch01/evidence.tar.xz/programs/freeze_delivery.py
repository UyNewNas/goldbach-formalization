#!/usr/bin/env python3
"""Freeze host evidence and code pins only; no real prepare or proof execution."""
import ast
import json
from pathlib import Path
import sys

sys.dont_write_bytecode=True
from approved_helpers import OLD,OLD_ROOT,OLD_STAGE_SHA,FOUNDATION_SHA,GRAPH_SHA,OLD_INPUT,TARGETS,pin,require
import batch_engine as b

ROOT=Path(__file__).resolve().parent
CODE=('controller.py','batch_engine.py','approved_helpers.py','test_host.py')


def main():
    code=[pin(ROOT/n) for n in CODE];reports=[]
    for path in (ROOT/'host-tests').glob('*/HOST_TEST_RESULTS.json'):
        report=b.read(path)
        if report['failures']==report['errors']==0 and report['code_pins']==code:reports.append((path,report))
    require(reports,'No successful host test report matches all four final code pins')
    report_path,report=sorted(reports)[-1];require(report['tests_run']>=28,'Missing final review regression')
    require(not (ROOT/'stages').exists(),'No real preparation is permitted during implementation')
    require(not any(p.name=='__pycache__' for p in ROOT.rglob('*')),'Unexpected pycache')
    require(not list(ROOT.rglob('*.olean')),'Synthetic normal objects must be cleaned; no real objects allowed')
    for path in ROOT.glob('*.py'):
        tree=ast.parse(path.read_text(),filename=str(path))
        if path.name in ('controller.py','batch_engine.py'):
            require(not any(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='step' for n in ast.walk(tree)),
                    'New protocol must not call old step')
    old_stage=OLD_ROOT/'stages/cell06-parent1499-v1';foundation=old_stage/'accepted-contexts'/(OLD_INPUT+'.json')
    graph=OLD_ROOT.parent/'CANDIDATE_GRAPH_v2.json'
    require(pin(old_stage/'STAGE.json')['sha256']==OLD_STAGE_SHA and pin(foundation)['sha256']==FOUNDATION_SHA and pin(graph)['sha256']==GRAPH_SHA,
            'Real metadata root changed before delivery')
    metadata=b.read(foundation);require(metadata['formal_acceptance'] is True and len(metadata['project_closure'])==1502,'Wrong observed foundation')
    real_graph=b.read(graph);require([m for m in real_graph['topological_order'] if m not in metadata['project_closure']][:2]==TARGETS,'Wrong real next two owners')
    readback={'schema':'p26_batch_boundary_final_host_readback_v1','status':'PASS_HOST_READBACK_ONLY','four_code_pins':code,
              'host_report':pin(report_path),'old_stage_metadata':pin(old_stage/'STAGE.json'),'foundation_metadata':pin(foundation),'graph_metadata':pin(graph),
              'tests_run':report['tests_run'],'old_step_calls':0,'real_prepare_executed':False,'Lean_commands':0,'MCP_jobs':0,
              'formal_acceptance':False,'P2_6_complete':False}
    b.dump(ROOT/'FINAL_HOST_READBACK.json',readback)
    members=[]
    for path in sorted(ROOT.rglob('*')):
        require(not path.is_symlink(),'Unexpected package symlink')
        if path.is_file():members.append(pin(path))
    delivery={'schema':'p26_cell06_batch_boundary_reviewable_delivery_v1','status':'UNEXECUTED_BATCH_CONTROLLER_CANDIDATE',
              'protocol':b.PROTOCOL,'exact_owners':TARGETS,'concurrency':1,'four_code_pins':code,
              'controller_sha256':code[0]['sha256'],'plan':pin(ROOT/'IMPLEMENTATION_PLAN.md'),'CLI_and_limits':pin(ROOT/'README.md'),
              'review_findings':pin(ROOT/'REVIEW_FINDINGS.md'),'host_report':pin(report_path),'final_readback':pin(ROOT/'FINAL_HOST_READBACK.json'),
              'old_reviewed_helpers':{'delivery':OLD.delivery,'code':OLD.code},
              'old_stage_metadata':pin(old_stage/'STAGE.json'),'accepted1502_metadata':pin(foundation),'same_source_graph':pin(graph),
              'members':members,'members_count':len(members),'real_prepare_executed':False,'Lean_commands':0,'lake_commands':0,'MCP_jobs':0,
              'formal_acceptance':False,'P2_6_complete':False,
              'unverified':['Real1502 transport and independent copies have not been executed.',
                            'No new global PRE/POST, Lean normal, stock checker or full-owned process has run.',
                            'New helper elaboration/import compatibility, disk footprint, hashing time and peak RAM are unmeasured.',
                            'Larger bulk, parallel execution and changed-source transport are intentionally unimplemented.',
                            'Global window is explicitly batch-boundary, not old per-command global checking.']}
    path=ROOT/'DELIVERY_MANIFEST.json';b.dump(path,delivery);require(b.read(path)==delivery,'Delivery JSON readback differs')
    for item in members:b.check(item)
    print(json.dumps({'delivery_manifest':pin(path),'four_code_pins':code,'host_report':pin(report_path),'tests_run':report['tests_run'],
                      'formal_acceptance':False,'real_prepare_executed':False,'Lean_commands':0}))


if __name__=='__main__':main()
