Implementation review disposition

| Finding | Resolution |
|---|---|
| Read-only helper import shadowed new controller | Old modules are imported under temporary aliases and prior Python module bindings are restored. Host test checks new and old controller identities differ. |
| RESULT log/LOCAL_INPUTS could point elsewhere | Exact attempt paths are required for COMMAND, LOCAL_INPUTS, output.log, PROCESS_RETURN, RESULT/PENDING and permanent normal output. Cross-log and sidefile tests reject. |
| PROCESS_RETURN was not part of execution chain | RESULT and PENDING pin it. Recovery compares its exact identity, command/log/object and all exit/status/time/RSS fields to RESULT; it cannot merely be present in final D. |
| Observed subordinate-pin tampering could recover green after restoration | After external root identity gates match, code/global manifest/graph/oldStage/foundation and D receipt/content/namespace mismatches persist sticky failure. Restoring bytes remains rejected. Wrong outer CLI SHA is distinguished and does not poison state. |
| D construction ran before sticky protection | The entire delta construction, including pending-artifact/canonical exact-copy checks, now runs inside the same sticky guard as D PRE verification. The pending-normal→next-mode construction-tamper test restores original bytes and still observes rejection with zero next-mode executions. |
| Later mode D includes earlier canonical output | Recovery validates each normal prefix and restores its missing exact canonical copy before checking subsequent LOCAL_INPUTS. The two-canonical-loss test confirms no executor call repeats. |
| Missing POST should not replay proof work | Completed six-mode history skips RESUME and performs only POST/final D/sealing. A fake test counts the sole snapshot purpose and unchanged executor counts. |
| Old per-command global claim could leak into new mode receipts | Mode records explicitly use batch-boundary scope, stay formalfalse, and reject old postcheck/global-success fields. Formal acceptance occurs only at BATCH_ACCEPTED and derived contexts. |

All resolutions are implementation/host evidence only. Root and an independent reviewer must review the final pinned delivery before any real preparation/execution. Existing old stage, sources, objects and successful receipts were never modified.
