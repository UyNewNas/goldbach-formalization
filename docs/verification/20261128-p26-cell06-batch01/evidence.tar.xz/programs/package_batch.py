"""Package the accepted exact-two batch. Never execute proof processes."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import sys
import tarfile

sys.dont_write_bytecode = True
ROOT = Path('/workspace/p26-cell06-batch-boundary-20261128')
STAGE = ROOT / 'stages/batch01'
OUT = Path(__file__).resolve().parent
DELIVERY_SHA = '484a28bb2a39836d86120e04b699bda12b8e9c5af33fef0c84699ab6bd7e9a24'
CONTROLLER_SHA = 'c70ce84362cf92ac2adab22bb429eb66c20e77d511cb3299ff92d5823e9861c8'
EXTENSION_SHA = '94ef902b323ff2b041045c08d315b4b89e86ee769c5797ea8b7f2a01aeb4b376'
BATCH_SHA = '32536b97ddaa017be6872d73efbdc8fb837a33763f55f98e50be7c27b1c67209'


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--seal-sha256', required=True)
    args = parser.parse_args()
    assert not (OUT / 'CAPSULE.json').exists()
    assert digest(ROOT / 'DELIVERY_MANIFEST.json') == DELIVERY_SHA
    delivery = json.loads((ROOT / 'DELIVERY_MANIFEST.json').read_text())
    for item in delivery['four_code_pins']:
        assert digest(item['path']) == item['sha256']
        assert Path(item['path']).stat().st_size == item['bytes']
    sys.path.insert(0, str(ROOT))
    import batch_engine as engine
    extension, batch = engine.load_contract(STAGE, EXTENSION_SHA, BATCH_SHA, CONTROLLER_SHA)
    seal_path = STAGE / 'state/BATCH_ACCEPTED.json'
    assert digest(seal_path) == args.seal_sha256
    # This verifies existing receipts/bytes only; it cannot execute any mode.
    seal_pin = engine.verify_accepted(STAGE, extension, batch)
    assert seal_pin['sha256'] == args.seal_sha256
    seal = engine.read(seal_path)
    assert len(seal['pending_mode_receipts']) == 6
    assert seal['formal_acceptance'] and not seal['P2_6_complete']
    assert not (STAGE / 'state/INTEGRITY_FAILED.json').exists()
    owners = batch['owners']
    contexts = [STAGE / 'accepted-contexts' / (owner + '.json') for owner in owners]
    current = engine.read(contexts[-1])
    assert len(current['project_closure']) == 1504
    assert current['accepted_new_modules'] == owners
    assert current['batch_seal'] == seal_pin

    members = {}

    def add(name, path, expected=None):
        path = Path(path)
        if expected is not None:
            engine.check(expected)
            assert str(path) == expected['path']
        assert name not in members
        members[name] = path

    for name in ['BATCH_EXTENSION.json', 'BATCH.json', 'GLOBAL_INPUTS.json',
                 'FOUNDATION_TRANSPORT.json', 'WHITELIST.json']:
        add(name, STAGE / name)
    add('CURRENT_ACCEPTED_CONTEXT.json', contexts[-1])
    add('FIRST_PREFIX_ACCEPTED_CONTEXT.json', contexts[0])
    add('PARENT_ACCEPTED_CONTEXT.json', extension['foundation']['path'], extension['foundation'])
    add('SOURCE_GRAPH.json', extension['graph']['path'], extension['graph'])
    for dirname in ['steps', 'state', 'helpers', 'goldbach-research']:
        for path in sorted((STAGE / dirname).rglob('*')):
            if path.is_file():
                add(str(path.relative_to(STAGE)), path)
    for owner in owners:
        info = current['project_closure'][owner]
        rel = owner.replace('.', '/')
        add('sources/' + rel + '.lean', info['source']['path'], info['source'])
        add('objects/' + rel + '.olean', info['selected_object']['path'], info['selected_object'])
    add('programs/DELIVERY_MANIFEST.json', ROOT / 'DELIVERY_MANIFEST.json')
    for item in delivery['members']:
        add('programs/' + str(Path(item['path']).relative_to(ROOT)), item['path'], item)
    add('programs/old/DELIVERY_MANIFEST.json', delivery['old_reviewed_helpers']['delivery']['path'], delivery['old_reviewed_helpers']['delivery'])
    for item in delivery['old_reviewed_helpers']['code']:
        add('programs/old/' + Path(item['path']).name, item['path'], item)
    add('programs/package_batch.py', Path(__file__))
    prior = Path('/workspace/p26-cell06-foundation-20261128')
    for name in ['CAPSULE.json', 'MANIFEST.json']:
        add('prior-foundation/' + name, prior / name)
    for name in ['MCP_PREPARE.json', 'MCP_RUN.json']:
        add(name, OUT / name)
    mode_metrics = []
    canonical = shared = 0
    for marker_pin in seal['pending_mode_receipts']:
        engine.check(marker_pin)
        marker = engine.read(marker_pin['path'])
        result = engine.read(marker['result']['path'])
        mode_metrics.append({'owner': marker['identity']['key'], 'mode': marker['identity']['mode'],
                             'seconds': result['seconds'], 'timings': result['timings']})
        if marker['identity']['mode'] == 'full-owned':
            canonical += marker['validated']['canonical_count']
            shared += marker['validated']['shared_occurrences']
    scope = ('Exactly Moment06Input and Geometry06ScalableActive8EnumerationBlock000 added to the '
             '1502 prefix. Other parser/decoder/row modules, Cell06 integral and global P2.6 remain open.')
    pins = {name: engine.pin(path) for name, path in members.items()}
    manifest = {'schema': 'p26_cell06_accepted_batch01_materials_v1', 'accepted_project_union': 1504,
                'protocol': engine.PROTOCOL, 'global_validation_scope': 'batch_boundary',
                'formal_acceptance': True, 'Cell06_integral_complete': False, 'P2_6_complete': False,
                'original_full_snapshot_verified': False, 'members': pins, 'scope': scope}
    raw_manifest = (json.dumps(manifest, indent=2) + '\n').encode()
    archive = OUT / 'evidence.tar.xz'
    with tarfile.open(archive, 'w:xz') as tar:
        for name, path in sorted(members.items()):
            raw = path.read_bytes()
            assert engine.pin(path) == pins[name]
            entry = tarfile.TarInfo(name)
            entry.size, entry.mode = len(raw), 0o644
            tar.addfile(entry, io.BytesIO(raw))
        entry = tarfile.TarInfo('MANIFEST.json')
        entry.size, entry.mode = len(raw_manifest), 0o644
        tar.addfile(entry, io.BytesIO(raw_manifest))
    assert archive.stat().st_size < 90 * 1024**2
    with tarfile.open(archive) as tar:
        assert len(tar.getmembers()) == len(members) + 1
        for entry in tar:
            raw = tar.extractfile(entry).read()
            if entry.name == 'MANIFEST.json':
                assert raw == raw_manifest
            else:
                assert raw == members[entry.name].read_bytes()
    for name, path in members.items():
        assert engine.pin(path) == pins[name]
    (OUT / 'MANIFEST.json').write_bytes(raw_manifest)
    capsule = {'schema': 'p26_cell06_accepted_batch01_capsule_v1', 'accepted_project_union': 1504,
               'formal_acceptance': True, 'Cell06_integral_complete': False, 'P2_6_complete': False,
               'original_full_snapshot_verified': False, 'old_normal_recompilations': 0,
               'accepted_owners': owners, 'new_canonical_declarations': canonical,
               'new_shared_occurrences': shared, 'current_context': engine.pin(contexts[-1]),
               'batch_seal': seal_pin, 'extension': engine.pin(STAGE / 'BATCH_EXTENSION.json'),
               'batch': engine.pin(STAGE / 'BATCH.json'), 'global_pre': engine.read(seal['global_pre']['path']),
               'global_post': engine.read(seal['global_post']['path']), 'mode_metrics': mode_metrics,
               'archive': engine.pin(archive), 'archive_readback_members': len(members) + 1,
               'prior_foundation_commit': 'ed57da0020d437d4eaacaaff3deed73944c41113',
               'source_artifact_commit': '9779a018863ddfc674f34228beffbf7c34f4867c',
               'packager_source': engine.pin(Path(__file__)), 'scope': scope}
    (OUT / 'CAPSULE.json').write_text(json.dumps(capsule, indent=2) + '\n')
    print(json.dumps(capsule), flush=True)


if __name__ == '__main__':
    main()
