"""New batch-global-boundary protocol; never calls or monkeypatches old step."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import time
import uuid

from approved_helpers import OLD,pin,require

ROOT=Path(__file__).resolve().parent
require(ROOT==Path('/workspace/p26-cell06-batch-boundary-20261128'),'Controller must run from its approved writable root')
PROTOCOL='batch_global_boundary_v1'
MODES=('normal','stock-leanchecker','full-owned')


def read(path):return json.loads(Path(path).read_text())


def writable(path):
    path=Path(path).absolute();require(path.resolve().is_relative_to(ROOT),'Write outside new batch root')
    for p in [path,*path.parents]:
        if p==ROOT.parent:break
        require(not p.is_symlink(),'Symlink in writable output path')
    return path


def dump(path,value):
    path=writable(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x') as f:
        json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
    return pin(path)


def check(item):
    # Direct streaming hash: deliberately no stat or old transaction cache.
    require(pin(item['path'])==item,'Exact byte pin differs: '+item['path'])


def unique(items):
    result={}
    for item in items:
        require(result.setdefault(item['path'],item)==item,'Conflicting exact pin: '+item['path'])
    return [result[k] for k in sorted(result)]


def copy_exact(source,target,expected):
    check(expected);target=writable(target);target.parent.mkdir(parents=True,exist_ok=True)
    if target.exists():
        require(all(pin(target)[k]==expected[k] for k in ('bytes','sha256')),'Existing exact-copy destination differs')
    else:
        with Path(source).open('rb') as incoming,target.open('xb') as out:
            shutil.copyfileobj(incoming,out);out.flush();os.fsync(out.fileno())
    a,b=Path(source).stat(),target.stat()
    require((a.st_dev,a.st_ino)!=(b.st_dev,b.st_ino),'Transport must use independent inodes')
    result=pin(target);require(all(result[k]==expected[k] for k in ('bytes','sha256')),'Copy readback differs')
    return result


def env_for(stage,extension):
    stage=Path(stage);sysroot=extension['environment']['sysroot']
    return {'HOME':str(stage/'home'),'TMPDIR':str(stage/'tmp'),'LANG':'C.UTF-8','LC_ALL':'C.UTF-8','TZ':'UTC',
            'LEAN_PATH':extension['lean_path'],'LEAN_NUM_THREADS':'1','OMP_NUM_THREADS':'1','LEAN_SYSROOT':sysroot,
            'PATH':sysroot+'/bin:/usr/bin:/bin'}


def env_hash(env):return hashlib.sha256(json.dumps(env,sort_keys=True,separators=(',',':')).encode()).hexdigest()


def flags(extension):return ['--trust=0','-DwarningAsError=true','-j1',f'-M{extension["rss_gib"]*1024}','-DmaxRecDepth=1000000','-DmaxHeartbeats=0']


def argv_for(stage,extension,owner,mode):
    stage=Path(stage);lean=extension['runtime']['lean']['path']
    if mode=='normal':value=[lean,*flags(extension),'-o','__NORMAL_OUTPUT__',stage/'project'/Path(owner.replace('.','/')).with_suffix('.lean')]
    elif mode=='stock-leanchecker':value=[extension['runtime']['leanchecker']['path'],'--verbose',owner]
    elif mode=='full-owned':value=[lean,*flags(extension),stage/'helpers'/(owner+'.Owned.lean')]
    else:raise RuntimeError('Unknown mode')
    return list(map(str,value))


def load_contract(stage,extension_sha,batch_sha,controller_sha):
    stage=writable(stage)
    require(pin(ROOT/'controller.py')['sha256']==controller_sha,'Externally supplied controller SHA differs')
    require(pin(stage/'BATCH_EXTENSION.json')['sha256']==extension_sha,'Externally supplied extension SHA differs')
    require(pin(stage/'BATCH.json')['sha256']==batch_sha,'Externally supplied batch SHA differs')
    ensure_clean(stage)
    extension,batch=read(stage/'BATCH_EXTENSION.json'),read(stage/'BATCH.json')
    require(extension['protocol']==batch['protocol']==PROTOCOL,'Wrong protocol')
    require(batch['extension']==pin(stage/'BATCH_EXTENSION.json'),'Batch/extension identity differs')
    require(batch['global_inputs']==extension['global_inputs'],'Global manifest selector differs')
    require(len(batch['owners'])==2 and len(set(batch['owners']))==2,'Exactly two sequential owners required')
    require(batch['failure_policy']=='atomic_two_owners' and batch['concurrency']==1,'Unsupported batch policy')
    extension['_anchor']=pin(stage/'BATCH_EXTENSION.json');batch['_anchor']=pin(stage/'BATCH.json')
    # Above: an outer CLI identity typo is a rejection with no state mutation.
    # Below: exact expected content under matched roots has been observed wrong.
    try:
        for row in extension['code_pins']:check(row)
        check(extension['global_inputs']);check(extension['graph']);check(extension['old_stage']);check(extension['foundation'])
        require(env_hash(env_for(stage,extension))==batch['environment_sha256'],'Final allowlist environment differs')
    except Exception as exc:sticky(stage,'Anchored contract content mismatch',str(exc))
    return extension,batch


def anchors(stage,extension,batch):
    extension.setdefault('_anchor',pin(Path(stage)/'BATCH_EXTENSION.json'))
    batch.setdefault('_anchor',pin(Path(stage)/'BATCH.json'))
    try:check(extension['_anchor']);check(batch['_anchor'])
    except Exception as exc:sticky(stage,'Anchored extension/batch content changed',str(exc))
    return extension['_anchor'],batch['_anchor']


def sticky(stage,reason,details=None):
    path=Path(stage)/'state/INTEGRITY_FAILED.json'
    if not path.exists():dump(path,{'protocol':PROTOCOL,'reason':reason,'details':details,'formal_acceptance':False,'P2_6_complete':False})
    suffix=(': '+details[:500]) if isinstance(details,str) else ''
    raise RuntimeError('Sticky INTEGRITY_FAILED: '+reason+suffix)


def ensure_clean(stage):
    require(not (Path(stage)/'state/INTEGRITY_FAILED.json').exists(),'Sticky integrity failure; automatic recovery forbidden')


def global_items(stage,extension,batch):
    try:check(extension['global_inputs']);items=read(extension['global_inputs']['path'])
    except Exception as exc:sticky(stage,'Anchored global manifest content changed',str(exc))
    extension_pin,batch_pin=anchors(stage,extension,batch)
    return unique(items+[extension['global_inputs'],extension_pin,batch_pin])


def catalog_objects(stage,extension,pending):
    selected=[i['selected_object'] for i in extension['parent_catalog'].values()]+extension['native_artifacts']
    for owner,normal in pending.items():
        target=Path(stage)/'objects'/Path(owner.replace('.','/')).with_suffix('.olean')
        expected={**normal['object'],'path':str(target)}
        # Restoring an exact namespace copy never invokes normal again.
        copy_exact(normal['object']['path'],target,normal['object']);selected.append(expected)
    return unique(selected)


def namespace_check(stage,extension,pending):
    stage=Path(stage);objects=catalog_objects(stage,extension,pending)
    expected={i['path'] for i in objects}
    actual={str(p.absolute()) for p in (stage/'objects').rglob('*') if p.is_file()}
    require(actual==expected,'Unknown/missing object/native namespace file')
    project={str(p.absolute()) for p in (stage/'project').rglob('*') if p.is_file()}
    require(project==set(extension['project_files']),'Unknown/missing mathematical source file')
    if not extension.get('synthetic_fixture',False):
        OLD.controller.environment_inventory(read(extension['old_stage']['path']))


def snapshot(stage,extension,batch,purpose,pending):
    ensure_clean(stage);started=time.monotonic()
    try:items=global_items(stage,extension,batch)
    except Exception as exc:sticky(stage,'Global contract/input-selector mismatch before '+purpose,str(exc))
    selector_seconds=time.monotonic()-started;namespace_started=time.monotonic()
    mismatches=[];total=0;digest=hashlib.sha256()
    try:namespace_check(stage,extension,pending)
    except Exception as exc:sticky(stage,'namespace mismatch before '+purpose,str(exc))
    namespace_pre_seconds=time.monotonic()-namespace_started;hash_started=time.monotonic()
    for expected in items:
        try:actual=pin(expected['path'])
        except (FileNotFoundError,OSError) as exc:
            mismatches.append({'expected':expected,'error':str(exc)});continue
        total+=actual['bytes'];digest.update(json.dumps(actual,sort_keys=True,separators=(',',':')).encode()+b'\n')
        if actual!=expected:mismatches.append({'expected':expected,'actual':actual})
    hash_seconds=time.monotonic()-hash_started;namespace_started=time.monotonic()
    try:namespace_check(stage,extension,pending)
    except Exception as exc:mismatches.append({'namespace':str(exc)})
    namespace_post_seconds=time.monotonic()-namespace_started
    report={'protocol':PROTOCOL,'purpose':purpose,'global_validation_scope':'batch_boundary',
            'extension':pin(Path(stage)/'BATCH_EXTENSION.json'),'batch':pin(Path(stage)/'BATCH.json'),
            'global_inputs':extension['global_inputs'],'files_checked':len(items),'bytes_read':total,
            'actual_map_sha256':digest.hexdigest(),'seconds':time.monotonic()-started,'matched':not mismatches,
            'timings':{'selector_seconds':selector_seconds,'global_byte_hash_seconds':hash_seconds,
                       'namespace_pre_seconds':namespace_pre_seconds,'namespace_post_seconds':namespace_post_seconds},
            'mismatches':mismatches,'checked_unix_ns':time.time_ns(),'formal_acceptance':False}
    path=Path(stage)/'state'/f'{purpose}-{time.time_ns()}.json';report_pin=dump(path,report)
    if mismatches:sticky(stage,'Observed global '+purpose+' mismatch',report_pin)
    return report_pin


def _validate_snapshot(snapshot_pin,stage,extension,batch,purpose=None):
    check(snapshot_pin);value=read(snapshot_pin['path'])
    require(value['protocol']==PROTOCOL and value['global_validation_scope']=='batch_boundary' and value['matched'] is True,'Invalid global snapshot')
    require(value['extension']==pin(Path(stage)/'BATCH_EXTENSION.json') and value['batch']==pin(Path(stage)/'BATCH.json'),'Snapshot contract transplant')
    require(value['global_inputs']==extension['global_inputs'] and value['files_checked']==len(global_items(stage,extension,batch)),'Snapshot input selector differs')
    if purpose is not None:require(value['purpose']==purpose,'Wrong snapshot purpose')
    return value


def validate_snapshot(snapshot_pin,stage,extension,batch,purpose=None):
    try:return _validate_snapshot(snapshot_pin,stage,extension,batch,purpose)
    except Exception as exc:sticky(stage,'Anchored global snapshot/reference mismatch',str(exc))


def pre_anchor(stage,extension,batch):
    path=Path(stage)/'state/GLOBAL_PRE.json'
    if path.exists():
        anchor=read(path);validate_snapshot(anchor['snapshot'],stage,extension,batch,'PRE');return anchor['snapshot']
    value=snapshot(stage,extension,batch,'PRE',{})
    dump(path,{'snapshot':value,'formal_acceptance':False});return value


def identity(stage,extension,batch,owner,mode,pre):
    extension_pin,batch_pin=anchors(stage,extension,batch)
    return {'protocol':PROTOCOL,'extension':extension_pin,'batch':batch_pin,
            'key':owner,'mode':mode,'global_validation_scope':'batch_boundary','batch_pre':pre,
            'environment_sha256':env_hash(env_for(stage,extension)),'argv':argv_for(stage,extension,owner,mode),
            'cwd':str(Path(stage)/'project'),'timeout':extension['wall_seconds'],'rss_bytes':extension['rss_gib']*1024**3}


def parse_mode(stage,extension,batch,owner,mode,text,result):
    require('sorryAx' not in text,'Forbidden sorryAx')
    if mode=='normal':return OLD.controller.normal_validator(text,result)
    if mode=='stock-leanchecker':return {'stock_leanchecker_exit_zero':True}
    prefix=batch['owners'][:batch['owners'].index(owner)+1]
    return OLD.evidence.validate_audit(text,[owner],set(extension['parent_catalog'])|set(prefix),extension['external_modules'])


def delta_items(stage,extension,batch,owner,mode,history,pending):
    stage=Path(stage);items=[pin(stage/'project'/Path(owner.replace('.','/')).with_suffix('.lean')),
                           pin(stage/'helpers'/(owner+'.Owned.lean')),*extension['code_pins'],*extension['runtime'].values()]
    for record in history:
        items += [record['marker'],record['result'],record['command'],record['log'],record['local_inputs']]
        if record['object']:items.append(record['object'])
    for name,record in pending.items():
        target=stage/'objects'/Path(name.replace('.','/')).with_suffix('.olean')
        copy_exact(record['object']['path'],target,record['object']);items += [record['object'],pin(target)]
    return unique(items)


def _verify_record(stage,extension,batch,owner,mode,pre,attempt):
    command_path,result_path,marker_path=(attempt/n for n in ('COMMAND.json','RESULT.json','PENDING.json'))
    require(command_path.is_file(),'Unknown attempt directory')
    command=read(command_path);expected=identity(stage,extension,batch,owner,mode,pre)
    require(command['identity']==expected,'Wrong extension/batch/key/mode/environment/argv receipt')
    require(command['local_inputs']['path']==str(attempt/'LOCAL_INPUTS.json'),'LOCAL_INPUTS must belong to this exact attempt')
    check(command['local_inputs']);local=read(command['local_inputs']['path'])
    try:
        for item in local:check(item)
    except Exception as exc:sticky(stage,'Stored local D byte mismatch',{'attempt':str(attempt),'error':str(exc)})
    actual=[str(attempt/'normal.olean') if a=='__NORMAL_OUTPUT__' else a for a in expected['argv']]
    require(command['actual_argv']==actual,'Actual argv transplant')
    require(result_path.exists(),'Unknown COMMAND interruption: recover evidence, never guess/re-normal')
    result=read(result_path)
    require(result['command']==pin(command_path),'Result/command chain differs')
    require(result['log']['path']==str(attempt/'output.log'),'Log must belong to this exact attempt')
    require(result['process_return']['path']==str(attempt/'PROCESS_RETURN.json'),'PROCESS_RETURN must belong to this exact attempt')
    check(result['process_return']);returned=read(result['process_return']['path'])
    require(returned['protocol']==PROTOCOL and returned['identity']==expected and returned['formal_acceptance'] is False
            and returned['status']=='PROCESS_RETURNED_PENDING_LOCAL_AND_GLOBAL_CHECKS','Wrong durable process return identity/status')
    require(returned['command']==pin(command_path) and returned['log']==result['log'] and returned['object']==result.get('object'),
            'Durable process return command/log/object differs')
    process_fields={'exit_code','stop_reason','seconds','sampled_peak_tree_rss_bytes'}
    require(set(returned['process_result'])==process_fields,'Unexpected process-return field set')
    require(type(returned['process_result']['exit_code']) is int and isinstance(returned['process_result']['seconds'],(int,float))
            and returned['process_result']['seconds']>=0 and type(returned['process_result']['sampled_peak_tree_rss_bytes']) is int
            and returned['process_result']['sampled_peak_tree_rss_bytes']>=0,'Invalid process timing/status values')
    require(all(result[k]==returned['process_result'][k] for k in process_fields),'Durable process return fields differ from RESULT')
    require(result['protocol']==PROTOCOL and result['global_validation_scope']=='batch_boundary' and 'postcheck' not in result
            and result['formal_acceptance'] is False,'Mode falsely reports per-step global/formal validation')
    require(result['local_post']=={'inputs':command['local_inputs'],'all_local_files_matched':True,'file_count':len(local)},'Wrong local D postcheck')
    check(result['log'])
    if result.get('object'):check(result['object'])
    if mode=='normal':
        if result.get('object'):require(result['object']['path']==str(attempt/'normal.olean'),'Wrong exact normal artifact path')
    else:require(result.get('object') is None,'Non-normal mode cannot claim a new object')
    if result['exit_code']!=0 or result.get('stop_reason'):
        require(not marker_path.exists(),'Failed process has pending-success marker');return None
    if mode=='normal':require(result['object']['path']==str(attempt/'normal.olean'),'Wrong permanent normal artifact')
    parsed=parse_mode(stage,extension,batch,owner,mode,Path(result['log']['path']).read_text(),result)
    marker={'protocol':PROTOCOL,'status':'NORMAL_SUCCEEDED_PENDING_GLOBAL' if mode=='normal' else 'PROCESS_VALIDATED_PENDING_GLOBAL',
            'identity':expected,'result':pin(result_path),'process_return':result['process_return'],
            'validated':parsed,'formal_acceptance':False,'batch_post':None,'P2_6_complete':False}
    if marker_path.exists():require(read(marker_path)==marker,'Pending marker differs or makes a false formal/global claim')
    else:dump(marker_path,marker) # Recover a durable successful result without execution.
    return {'owner':owner,'mode':mode,'marker':pin(marker_path),'result':pin(result_path),'command':pin(command_path),
            'log':result['log'],'local_inputs':command['local_inputs'],'object':result.get('object'),'validated':parsed}


def verify_record(stage,extension,batch,owner,mode,pre,attempt):
    try:return _verify_record(stage,extension,batch,owner,mode,pre,attempt)
    except RuntimeError as exc:
        if 'Unknown COMMAND interruption' in str(exc):raise
        sticky(stage,'Anchored mode D receipt/content mismatch',str(exc))
    except Exception as exc:sticky(stage,'Anchored mode D receipt/content mismatch',str(exc))


def find_record(stage,extension,batch,owner,mode,pre):
    base=Path(stage)/'steps'/owner/mode
    successes=[]
    for attempt in sorted(base.iterdir()) if base.exists() else []:
        record=verify_record(stage,extension,batch,owner,mode,pre,attempt)
        if record:successes.append(record)
    require(len(successes)<=1,'Multiple successful executions for one frozen owner/mode')
    return successes[0] if successes else None


def real_executor(mode,owner,argv,cwd,env,log,timeout,rss):
    return OLD.evidence.real_process(argv,cwd,env,log,timeout,rss)


def refuse_other_stage_normal(stage,owner):
    # Source repair/partial-batch migration is not implemented. A fresh stage
    # must never be used to bypass an existing successful or ambiguous normal.
    stage=Path(stage)
    for command_path in ROOT.glob('**/steps/'+owner+'/normal/*/COMMAND.json'):
        if command_path.is_relative_to(stage):continue
        command=read(command_path)
        if command.get('identity',{}).get('key')!=owner:continue
        result_path=command_path.parent/'RESULT.json'
        require(result_path.exists(),'Other-stage ambiguous normal blocks recompilation; explicit transport required')
        result=read(result_path)
        require(result.get('exit_code')!=0 or result.get('stop_reason'),
                'Other-stage successful normal blocks recompilation; explicit transport required')


def run_mode(stage,extension,batch,owner,mode,pre,history,pending,executor=real_executor):
    ensure_clean(stage);validate_snapshot(pre,stage,extension,batch,'PRE')
    previous=find_record(stage,extension,batch,owner,mode,pre)
    if previous:return previous
    if mode=='normal':refuse_other_stage_normal(stage,owner)
    require(shutil.disk_usage(stage).free>1024**3,'Leave1GiB reserve before a new mode')
    local_started=time.monotonic()
    try:
        local=delta_items(stage,extension,batch,owner,mode,history,pending)
        namespace_check(stage,extension,pending)
        for item in local:check(item)
    except Exception as exc:sticky(stage,'Observed local D mismatch before mode',str(exc))
    local_pre_seconds=time.monotonic()-local_started
    attempt=Path(stage)/'steps'/owner/mode/(str(time.time_ns())+'-'+uuid.uuid4().hex[:8]);attempt.mkdir(parents=True)
    local_pin=dump(attempt/'LOCAL_INPUTS.json',local);ident=identity(stage,extension,batch,owner,mode,pre)
    actual=[str(attempt/'normal.olean') if a=='__NORMAL_OUTPUT__' else a for a in ident['argv']]
    dump(attempt/'COMMAND.json',{'identity':ident,'actual_argv':actual,'local_inputs':local_pin,'started_unix_ns':time.time_ns()})
    log=attempt/'output.log';result=executor(mode,owner,actual,ident['cwd'],env_for(stage,extension),log,ident['timeout'],ident['rss_bytes'])
    returned={'protocol':PROTOCOL,'identity':ident,'process_result':result,'command':pin(attempt/'COMMAND.json'),
              'log':pin(log),'object':pin(attempt/'normal.olean') if mode=='normal' and (attempt/'normal.olean').is_file() else None,
              'status':'PROCESS_RETURNED_PENDING_LOCAL_AND_GLOBAL_CHECKS','formal_acceptance':False}
    return_pin=dump(attempt/'PROCESS_RETURN.json',returned)
    local_started=time.monotonic()
    try:
        for item in local:check(item)
    except Exception as exc:sticky(stage,'Observed local D mismatch after mode',{'attempt':str(attempt),'error':str(exc)})
    local_post_seconds=time.monotonic()-local_started
    obj=attempt/'normal.olean'
    result={**result,'protocol':PROTOCOL,'global_validation_scope':'batch_boundary','command':pin(attempt/'COMMAND.json'),
            'process_return':return_pin,
            'log':pin(log),'local_post':{'inputs':local_pin,'all_local_files_matched':True,'file_count':len(local)},
            'object':pin(obj) if mode=='normal' and obj.is_file() else None,'formal_acceptance':False,
            'timings':{'local_D_pre_seconds':local_pre_seconds,'local_D_post_seconds':local_post_seconds,
                       'local_D_expected_bytes':sum(i['bytes'] for i in local),'process_seconds':result.get('seconds')}}
    validation_error=None;validation_started=time.monotonic()
    if result['exit_code']==0 and not result.get('stop_reason'):
        try:parse_mode(stage,extension,batch,owner,mode,log.read_text(),result)
        except Exception as exc:validation_error=str(exc)
    result['timings']['mode_validation_seconds']=time.monotonic()-validation_started
    result['mode_validation_error']=validation_error
    dump(attempt/'RESULT.json',result)
    require(result['exit_code']==0 and not result.get('stop_reason'),'Mode failed; evidence/output retained')
    require(validation_error is None,'Mode validation failed; successful process artifact retained: '+str(validation_error))
    return verify_record(stage,extension,batch,owner,mode,pre,attempt)


def recover_history(stage,extension,batch,pre):
    history=[];pending={};gap=False
    for owner in batch['owners']:
        for mode in MODES:
            record=find_record(stage,extension,batch,owner,mode,pre)
            if record is None:gap=True;continue
            require(not gap,'Non-prefix provisional mode history')
            history.append(record)
            if mode=='normal':
                pending[owner]=record
                try:catalog_objects(stage,extension,pending)
                except Exception as exc:sticky(stage,'Provisional canonical object mismatch',str(exc))
    try:namespace_check(stage,extension,pending)
    except Exception as exc:sticky(stage,'Recovered provisional namespace mismatch',str(exc))
    return history,pending


def validate_all_delta(history):
    items=[]
    for record in history:
        for key in ('marker','result','command','log','local_inputs'):items.append(record[key])
        items += read(record['local_inputs']['path'])
        if record['object']:items.append(record['object'])
    items=unique(items)
    for item in items:check(item)
    return items


def complete_delta_inventory(stage,history):
    expected=validate_all_delta(history)
    allowed={'COMMAND.json','RESULT.json','PENDING.json','LOCAL_INPUTS.json','PROCESS_RETURN.json','output.log','normal.olean'}
    owners={r['owner'] for r in history}
    for path in (Path(stage)/'steps').rglob('*') if (Path(stage)/'steps').exists() else []:
        if path.is_file():
            parts=path.relative_to(Path(stage)/'steps').parts
            require(len(parts)==4 and parts[0] in owners and parts[1] in MODES and path.name in allowed,'Unknown file in mode D namespace')
            expected.append(pin(path))
    # All prior global boundary/resume reports are retained and bound, too.
    for path in (Path(stage)/'state').glob('*.json'):
        if path.name=='GLOBAL_PRE.json' or path.name.startswith(('PRE-','RESUME-','POST-')):expected.append(pin(path))
        else:require(path.name in ('BATCH_ACCEPTED.json','INTEGRITY_FAILED.json'),'Unknown batch state file')
    return unique(expected)


def materialize_contexts(stage,extension,batch,seal,history,pending):
    catalog=dict(extension['parent_catalog']);parent=extension['foundation']
    for owner in batch['owners']:
        normal=pending[owner];target=Path(stage)/'objects'/Path(owner.replace('.','/')).with_suffix('.olean')
        catalog[owner]={'source':pin(Path(stage)/'project'/Path(owner.replace('.','/')).with_suffix('.lean')),'selected_object':pin(target),
                        'origin':'accepted_batch_global_boundary_v1','normal_success_artifact':normal['object']}
        value={'protocol':PROTOCOL,'formal_acceptance':True,'P2_6_complete':False,
               'extension':extension['_anchor'],'batch':batch['_anchor'],'batch_seal':seal,'accepted_parent':parent,
               'project_closure':dict(catalog),'native_artifacts':extension['native_artifacts'],'runtime':extension['runtime'],
               'lean_path':extension['lean_path'],'accepted_new_modules':batch['owners'][:batch['owners'].index(owner)+1],
               'global_validation_scope':'batch_boundary','scope':'Exact completed two-owner batch; no global P2.6 claim.'}
        path=Path(stage)/'accepted-contexts'/(owner+'.json')
        if path.exists():require(read(path)==value,'Existing accepted prefix context differs')
        else:dump(path,value)
        parent=pin(path)


def execute_pending(stage,extension,batch,pre,executor=real_executor):
    history,pending=recover_history(stage,extension,batch,pre)
    completed={(r['owner'],r['mode']) for r in history}
    for owner in batch['owners']:
        for mode in MODES:
            if (owner,mode) in completed:continue
            record=run_mode(stage,extension,batch,owner,mode,pre,history,pending,executor)
            history.append(record);completed.add((owner,mode))
            if mode=='normal':pending[owner]=record
    return history,pending


def finish(stage,extension,batch,pre,history,pending):
    ensure_clean(stage);require(len(history)==6 and set(pending)==set(batch['owners']),'Both owners require all three modes')
    try:delta=complete_delta_inventory(stage,history);namespace_check(stage,extension,pending)
    except Exception as exc:sticky(stage,'Final D mismatch',str(exc))
    post=snapshot(stage,extension,batch,'POST',pending)
    if validate_snapshot(post,stage,extension,batch,'POST')['actual_map_sha256']!=validate_snapshot(pre,stage,extension,batch,'PRE')['actual_map_sha256']:
        sticky(stage,'PRE/POST actual maps differ',{'pre':pre,'post':post})
    try:
        for item in delta:check(item)
        validate_all_delta(history);namespace_check(stage,extension,pending)
        delta=complete_delta_inventory(stage,history)
        for item in delta:check(item)
    except Exception as exc:sticky(stage,'Final D changed around global POST',str(exc))
    accepted={'protocol':PROTOCOL,'status':'BATCH_ACCEPTED','extension':pin(Path(stage)/'BATCH_EXTENSION.json'),'batch':pin(Path(stage)/'BATCH.json'),
              'global_validation_scope':'batch_boundary','global_pre':pre,'global_post':post,'owners':batch['owners'],
              'pending_mode_receipts':[r['marker'] for r in history],'delta_inputs':delta,'formal_acceptance':True,'P2_6_complete':False}
    seal=dump(Path(stage)/'state/BATCH_ACCEPTED.json',accepted)
    materialize_contexts(stage,extension,batch,seal,history,pending)
    return seal


def _verify_accepted(stage,extension,batch):
    ensure_clean(stage);path=Path(stage)/'state/BATCH_ACCEPTED.json';value=read(path)
    require(value['protocol']==PROTOCOL and value['status']=='BATCH_ACCEPTED' and value['formal_acceptance'] is True,'Wrong accepted batch seal')
    require(value['extension']==pin(Path(stage)/'BATCH_EXTENSION.json') and value['batch']==pin(Path(stage)/'BATCH.json'),'Accepted seal transplant')
    validate_snapshot(value['global_pre'],stage,extension,batch,'PRE');validate_snapshot(value['global_post'],stage,extension,batch,'POST')
    history,pending=recover_history(stage,extension,batch,value['global_pre'])
    require([r['marker'] for r in history]==value['pending_mode_receipts'] and len(history)==6,'Accepted mode set differs')
    for item in value['delta_inputs']:check(item)
    require(value['delta_inputs']==complete_delta_inventory(stage,history),'Accepted final D inventory differs')
    for item in global_items(stage,extension,batch):check(item)
    namespace_check(stage,extension,pending)
    materialize_contexts(stage,extension,batch,pin(path),history,pending)
    return pin(path)


def verify_accepted(stage,extension,batch):
    try:return _verify_accepted(stage,extension,batch)
    except Exception as exc:sticky(stage,'Accepted batch referenced content mismatch',str(exc))


def run_batch(stage,extension,batch,executor=real_executor):
    ensure_clean(stage)
    if (Path(stage)/'state/BATCH_ACCEPTED.json').exists():return verify_accepted(stage,extension,batch)
    pre=pre_anchor(stage,extension,batch)
    history,pending=recover_history(stage,extension,batch,pre)
    if history and len(history)<6:
        # A resumed unfinished batch gets a fresh complete real-byte recheck.
        snapshot(stage,extension,batch,'RESUME',pending)
    history,pending=execute_pending(stage,extension,batch,pre,executor)
    return finish(stage,extension,batch,pre,history,pending)
