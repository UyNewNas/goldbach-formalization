Cell06 two-owner batch-boundary controller candidate

This is a new `batch_global_boundary_v1` implementation for exactly two sequential owners. It has not prepared a real stage, run Lean/lake/MCP, modified an old provider, submitted Git changes or accepted a new mathematical module. It is ready for code review and fake-host evidence review; root arranges any later real execution.

The first batch is fixed by the real frozen graph after the accepted1502 prefix:

1. `ImbalancedChen.P2OriginalSaving19Moment06Input`
2. `ImbalancedChen.P2OriginalSaving19Geometry06ScalableActive8EnumerationBlock000`

Old `Geometry06ScalableInput` and both Data06 modules are excluded from normal compilation. No larger batch or parallel mode is implemented.

The external roots are fixed:

| Root | SHA256 |
|---|---|
| Old runner delivery | `d14f188c6e011a5576db429e79378bb3bf9b1d8d080ff37584cbbb699008b462` |
| Old STAGE | `83affec77d951a27ec2b7a172fea4e8c43c1d64579f173e275521b45689ccb41` |
| Accepted1502 context | `d528a2f388f10c22b89c218e675b534a76de129de50054fd1dc4a68e66398ad1` |
| Same source graphv2 | `0c0930dc27e9ee532ac4a8c78afb2dfb5c9cf40a364076e50cddae7f4cf8dd02` |

`approved_helpers.py` verifies the old delivery and old Python helper source pins, imports those read-only modules without invoking old main/prepare/step, and restores Python module aliases so the new controller is never shadowed. Reused pieces are stream hashing/process limits, complete audit rendering/validation, old same-byte receipt validation and read-only foundation checks. The new batch identities, global snapshots, pending records and acceptance state machine are implemented separately in `batch_engine.py`.

Future CLI for review (these commands have **not** run):

```bash
python3 -B /workspace/p26-cell06-batch-boundary-20261128/controller.py prepare \
  --controller-sha256 CONTROLLER_SHA_FROM_DELIVERY \
  --old-stage /workspace/p26-cell06-source-candidate-20261128/runner/stages/cell06-parent1499-v1 \
  --old-stage-sha256 83affec77d951a27ec2b7a172fea4e8c43c1d64579f173e275521b45689ccb41 \
  --parent-context /workspace/p26-cell06-source-candidate-20261128/runner/stages/cell06-parent1499-v1/accepted-contexts/ImbalancedChen.P2OriginalSaving19Geometry06ScalableInput.json \
  --parent-sha256 d528a2f388f10c22b89c218e675b534a76de129de50054fd1dc4a68e66398ad1 \
  --graph /workspace/p26-cell06-source-candidate-20261128/CANDIDATE_GRAPH_v2.json \
  --graph-sha256 0c0930dc27e9ee532ac4a8c78afb2dfb5c9cf40a364076e50cddae7f4cf8dd02 \
  --stage /workspace/p26-cell06-batch-boundary-20261128/stages/batch01 \
  --rss-gib 12 --wall-seconds 2400
```

Preparation validates the original1499 parent, Data2 trust0 replay/full-owned/quoted-byte qualification, the old Input normal/stock/full-owned receipts, all selected source/object/native/runtime bytes, and the unchanged graph. Old receipts retain their exact old contract, argv and environment identity. Preparation then makes independent-inode copies of all1502 accepted project modules, all555 native files, the unchanged334 candidate sources and two original JSON inputs into a new complete first namespace. It generates both auditors and the whitelist before freezing `GLOBAL_INPUTS.json`, `BATCH_EXTENSION.json` and `BATCH.json`, and returns the latter two SHA roots. It leaves the old stage untouched. This path is implemented but unexecuted on the real foundation.

```bash
python3 -B /workspace/p26-cell06-batch-boundary-20261128/controller.py run \
  --controller-sha256 CONTROLLER_SHA_FROM_DELIVERY \
  --stage /workspace/p26-cell06-batch-boundary-20261128/stages/batch01 \
  --extension-sha256 SHA_RETURNED_BY_PREPARE \
  --batch-sha256 SHA_RETURNED_BY_PREPARE
```

Every execution matches the externally supplied controller/extension/batch SHA roots before trusting their fields. A fixed stage-local HOME/TMPDIR, PATH/LEAN_PATH/sysroot, locale/timezone and single-thread environment are built from an allowlist, never inherited injection/proxy/API environment. The entire final environment hash is bound in the batch and every mode identity. All Lean compiler/audit calls use trust0, warningAsError, one thread, fixed recursion/heartbeat settings and recorded limits; the stock checker is the separately pinned official binary.

Protocol and actual checking scope:

- One complete global PRE and one complete global POST stream-read every file in G, including the full inherited baseline, original/provider/staged source and objects, runtime/external/shared-library files,555native, original JSON/copies, helpers, controller code, manifests and fixed parent namespace. Each scan also validates the namespace. No stat/mtime or old transaction cache substitutes for byte reads.
- Every mode separately checks D before and after use: its exact source/helper/control/runtime selectors, earlier pending modes/logs/receipts, permanent normal outputs and canonical provisional dependencies. Final D inventory includes every allowed attempt artifact and pre/resume/post boundary report. Unknown namespaces/sidefiles stop acceptance.
- A zero-exit normal with exact output and local checks gets an immutable `NORMAL_SUCCEEDED_PENDING_GLOBAL` marker and permanent `normal.olean`. It remains `formal_acceptance:false`; kernel and full-owned successes are similarly pending. Actual local/raw process results remain recorded even if later checks fail.
- Both owners must finish all three modes, and complete global POST plus final D checks must succeed, before `BATCH_ACCEPTED` and prefix contexts can be written. Prefix publication can be recovered after a seal-time interruption without executing modes again.

This deliberately uses a **new batch-level verification window**, not the old per-command global PRE/POST semantics. Mode records use `global_validation_scope="batch_boundary"`, refer to the batch PRE, and retain `batch_post:null` while pending. They never claim old `postcheck.all_files_matched` global fields. Accepted owner contexts reference the batch seal and its real POST. As with any endpoint scheme, files changed and restored entirely inside the larger window are not detected solely by endpoint hashes; the protocol requires single-writer control and read-only input use, not a claim of OS-enforced immutability.

Recovery and integrity rules:

- A successful normal is never recompiled. Prefix normal artifacts are validated/restored before later modes' LOCAL_INPUTS are checked; simultaneous loss of both canonical output copies is covered by fake tests. Missing pending markers recover from fully validated durable success records.
- If all six modes are done but POST is missing, resume executes only the complete real POST and final sealing, not a mode or a redundant RESUME scan. An unfinished partial batch first gets a fresh full global RESUME check, then only missing modes, then POST.
- An observed mismatch under matched external roots—global/code/graph/oldStage/foundation, known D selector/log/object/PROCESS_RETURN content or namespace—writes immutable `INTEGRITY_FAILED`. Restoring original bytes does not turn it green. A CLI SHA typo **before** the roots match is a plain identity rejection and does not poison a valid batch.
- Every COMMAND/LOCAL_INPUTS/output.log/PROCESS_RETURN/RESULT/PENDING/normal.olean belongs to the exact same attempt. PROCESS_RETURN is pinned by RESULT and PENDING, and its identity, command, log, object, exit/status/time/memory fields must agree exactly. Wrong-stage/log/sidefile transplantation is rejected.
- An interrupted COMMAND without a durable RESULT is unknown, even if an object exists. Automatic execution stops; no guess or re-normal is permitted. Same-source failed process attempts retain evidence and use a fresh output path if retried. Other-stage successful or ambiguous normals under this controller root block fresh normal execution; no fresh-stage bypass is provided.

Full-owned validation retains exact serialized/environment inventories, types and axioms. Shared serialized theorem bodies are checked from their original raw body with a fresh alias using `addDeclCore 0 0`, independently of the canonical shared proof. No292-per-owner count is used. Allowed inherited axioms are only `propext`, `Classical.choice`, `Quot.sound`; unsafe/partial/axiom mathematical owners, truncated types, incomplete imports and unvalidated shared bodies are rejected.

The latest fake-host report is selected by the final delivery manifest only when all four current code pins match it. Tests use synthetic fake processes and remove their synthetic objects/contexts afterwards. The real1502 context and334 graph are checked only as metadata pins/order during host tests; no real transport/global scan/prepare or proof process has run.

Performance fields distinguish foundation-validation/total-prepare time, global selector/hash/namespace/total time and bytes/files read, local D PRE/POST time/bytes, process time/RSS and mode-validation time. No real new-protocol timing, inode-copy disk footprint, global I/O cost, auditor elaboration, actual external import compatibility or process resource fit is established by these tests. A single-owner old pilot's small compute time is not used as a promise for the parser leaf.

Limits intentionally retained: exactly two owners, one batch, serial execution, same source graph and same1502 foundation only. Larger bulk, parallelism, arbitrary parents, source fixes and transport of repaired-source/pending work into a changed contract are unimplemented. Do not edit a frozen source or rebuild successful normals in a new stage to bypass that gap. No global P2.6 success label or further mathematical semantics are granted.
