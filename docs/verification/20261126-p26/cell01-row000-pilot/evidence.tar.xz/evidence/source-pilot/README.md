# Cell01 row000 source pilot

Status: generated source candidates. No Lean compilation, independent kernel replay,
or cloud task was run by the generator or the authoring agent.

The source pilot contains 23 new owners, ordered in `cloud_order.txt`. The original
Cell00 owners and all generic arithmetic, determinant, prefix, higher-moment,
parser and decoder suppliers are unchanged.

## Exact scope

- `Geometry01BoundedAccess` transports the existing complete Cell01 shape facts
  to bounded lookups. It supplies the same original row → vertex ID → coordinate
  access equality for `r : Fin 144`, without a geometric or numerical claim.
- `Cell01Row000Input` selects only original row 0 and its original ordered IDs
  `[39, 35, 29, 28, 25, 13, 3, 1, 0]`. The typed literals are taken from
  `Geometry01DirectDecoding`; their equality with the bounded decoded accesses
  is a Lean obligation in this owner.
- The six arithmetic owners and their aggregator retain the original ten
  `RowDataChecksFor` clauses. `OldFloor` binds the actual decoded Moment01 row 0.
- `MomentEncoding` supplies the actual gap/deviation integer encodings.
  `MomentFactor00` through `MomentFactor09` each prove degrees 1–6, the original
  Q80 integer, and both floor inequalities using the existing prefix evaluator.
- `PrefixFloorChecks` closes the original five finite floor clauses using the
  literal `max(old,new)` operation. `OriginalFloorBridge` transports that result
  through the existing `HigherMomentsPrefix` and Q96 namespace bridges.

No other Cell01 row arithmetic, all-13 aggregate, ownership, or integral estimate
is asserted by the new owners.

## Original fixture identities

| Input | Bytes | SHA256 |
|---|---:|---|
| `eighth-third-minorant-extension-20261009-a23-s23_low-01-cell.witness.json` | 470901 | `e19eee9d7e282cd3a618a71f12e93bcce28319485c9d0fd31bbeaf9f81a995a4` |
| `eighth-third-moment-refinement-20261009-a23-low-01.witness.json` | 75094 | `03e9360189414e240818a191e5b53102aa5e8c3a1e7c18fbd8553ba020078d8c` |

The generator reads these exact inputs and records their identities in both
manifests. Host calculations supply candidate rational literals only. The ten
original finite arithmetic clauses, moment old-floor consistency, Q80 candidates,
and saved new-Q96 candidate were checked for host consistency; this gives no
Lean or kernel acceptance credit. Each mathematical equality and inequality
remains explicit in the generated Lean source.

## Supplier and compilation boundary

The existing supplier roots needed by the pilot are:

1. `P2OriginalSaving19Geometry01Shape`, including its actual decoded input;
2. `P2OriginalSaving19Moment01Shape`, including whole original parse and decode;
3. `P2OriginalSaving19RowNumericsPure`;
4. `P2Winner9FastDetPure`;
5. `P2OriginalSaving19PrefixMoments`;
6. `P2OriginalSaving19HigherMomentsPrefix`;
7. `P2OriginalLogMomentQ96ArithmeticBridge`.

For the initial P3 finite phase, use `cloud_order_finite.txt`: it contains the
first 22 new owners. `Cell01Row000OriginalFloorBridge` remains a source candidate
for P1, pending the existing HigherMomentsPrefix analytical suppliers. The P3
driver never imports or compiles that bridge. The recursive project-source graph
and source hashes for the complete source pilot are recorded in
`SOURCE_CLOSURE.json`; external Lean, Mathlib and MathlibNt imports remain a
separate pinned environment boundary.

The finite P3 phase has 420 project modules: 22 targets and 398 existing suppliers.
Its frozen supplier manifest is `Cell01Row000_SUPPLIERS.json`; the driver reads
suppliers from `../cell00`, `../geometry01`, and `../moment01`. Every same-name
source and object must have the same SHA256 across those roots. Before Lean
starts, the driver installs those already verified bytes into the stage's own
`project/` and `objects/`, using hardlinks or an exclusive byte copy across
filesystems. It checks every installed identity and never overwrites a conflict.
The project part of `LEAN_PATH` contains only this complete `objects/` tree.

This installation fixes failed job `09da80e59b7f4b828b851df45f033d4c`: the prior
driver verified separate partial object trees but placed the new target tree
first. The import then selected that tree's `ImbalancedChen` directory, where
the existing `Geometry01Shape.olean` had not been installed. The 22 Lean sources,
22 audit sources, accepted supplier objects and proof obligations are unchanged.
Each new attempt records `SUPPLIER_INSTALLATION.json`; old verification attempts
and the v2 package are preserved.

The frozen supplier manifest still records `P2Winner9HomogeneousRecurrence` as
normal-only. Root reports its independent kernel replay in P1 job
`job_cb696e722e044d6a8e95470d4290c441` has passed; the exact receipt export remains
to be attached to the same object SHA. The P3 driver preserves the manifest's
observed boundary in each receipt, and does not rerun the generic owner.

The independent Moment01 supplier package supplied by the geometry agent is
`/dev/shm/p26-59264dd64286/moment01-suppliers.tar.xz`, SHA256
`e5008887d1a13751396644280bd89c796052c2f3339d38f56c1143e5ae006181`.
It contains the 88-module matching source/object/receipt closure. This pilot
does not rebuild that package or its accepted owners.

## Reproduction

`tools/p26/generate_cell01_row000_pilot.py` reads the current, unchanged Cell00
row000 source owners as structural donors, and the established
`setup_and_generate.py` / `generate_final.py` workflow as the numerical-template
reference. It records all donor hashes and refuses to replace an existing output.
It has no Lean subprocess or cloud-tool invocation.

The generated source remains pending exact-environment normal compilation,
independent kernel replay, and owned theorem export verification.
