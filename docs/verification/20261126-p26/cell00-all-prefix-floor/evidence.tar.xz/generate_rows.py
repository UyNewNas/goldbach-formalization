"""Generate candidates by substituting data into the passed row0 proof bodies.

The host only proposes exact literals. Every original-data encoding, moment,
floor, and bound is a closed Lean obligation in the generated owner.
"""
from pathlib import Path
from fractions import Fraction
import hashlib, json, math, re, sys

ROOT = Path(__file__).resolve().parent
TEMPLATE_ROOT = Path('/workspace/p26-recovery-candidates/cell00-row000-moment-floor')
TEMPLATES = TEMPLATE_ROOT / 'project/ImbalancedChen'
PROJECT = ROOT / 'project/ImbalancedChen'
BOOT = json.loads((ROOT / 'BOOTSTRAP.json').read_text())

def fp(p):
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}

def write(p, content):
    p.parent.mkdir(parents=True, exist_ok=True)
    assert not p.exists(), p
    p.write_text(content)

def jwrite(p, content):
    write(p, json.dumps(content, indent=2, ensure_ascii=False) + '\n')

raw = {}
for f in BOOT['original_fixtures']:
    p = Path(f['path'])
    assert fp(p) == f
    raw['geometry' if 'minorant-extension' in p.name else 'moments'] = json.loads(p.read_bytes())
geometry, moments = raw['geometry'], raw['moments']
assert len(geometry['simplices']) == len(moments['records']) == 56

template_manifest = json.loads((TEMPLATE_ROOT / 'PUBLICATION_SOURCES.json').read_text())
for item in template_manifest['owners']:
    assert fp(Path(item['source']['path'])) == item['source']

old_ns = 'ImbalancedChen.P2OriginalSaving19Cell00Row000MomentFloor'

def body(filename, start):
    text = (TEMPLATES / filename).read_text()
    assert text.count('end ' + old_ns) == 1
    return text[text.index(start):text.index('end ' + old_ns)].rstrip() + '\n\n'

encoding_body = body('P2OriginalSaving19Cell00Row000MomentEncoding.lean', 'def gapScale')
factor_bodies = [body(f'P2OriginalSaving19Cell00Row000MomentFactor{j:02d}.lean', 'run_cmd do')
                 for j in range(10)]
assembly_body = body('P2OriginalSaving19Cell00Row000PrefixFloorChecks.lean', 'run_cmd do')

def qr(q):
    return {'numerator': str(q.numerator), 'denominator': str(q.denominator)}

def rat(q):
    return f'({q.numerator} : ℚ) / {q.denominator}'

def vec(xs):
    return '![' + ', '.join(str(x) for x in xs) + ']'

def replace_once(pattern, replacement, text, flags=0):
    result, count = re.subn(pattern, replacement, text, flags=flags)
    assert count == 1, (pattern, count)
    return result

def comparison(t):
    return (1 + t[0] + t[3]) / 2

def new(t):
    return (1 + t[1] + t[3] + t[7]) / 2 - Fraction(1, 1000000)

def factors(t):
    return [comparison(t) - sum(t), new(t) - sum(t)] + t

def host_prefix(z):
    table = [1] + [0] * 6
    for a in reversed(z):
        carry = 0
        next_table = []
        for x in table:
            carry = x + a * carry
            next_table.append(carry)
        table = next_table
    return table

def generate(index):
    assert 1 <= index < 56
    row, moment_row = geometry['simplices'][index], moments['records'][index]
    assert row['simplex_id'] == moment_row['simplex_id'] == index
    vertices = [[Fraction(q) for q in geometry['vertices'][i]] for i in row['vertex_ids']]
    assert len(vertices) == 9 and all(len(t) == 8 for t in vertices)
    gaps = [new(t) - comparison(t) for t in vertices]
    tops = [Fraction(x) for x in row['factor_maxima']]
    deviations = [[1 - factors(v)[j] / tops[j] for v in vertices] for j in range(10)]
    gap_scale = math.lcm(*(q.denominator for q in gaps))
    gap_nats = [int(q * gap_scale) for q in gaps]
    denominators = [math.lcm(*(q.denominator for q in ds)) for ds in deviations]
    deviation_nats = [[int(q * d) for q in ds] for ds, d in zip(deviations, denominators)]
    assert gap_scale > 0 and all(d > 0 for d in denominators)
    assert all(x >= 0 for x in gap_nats)
    assert all(x >= 0 for ds in deviation_nats for x in ds)
    assert sum(gap_nats) > 0

    def host_moment(z, d, k):
        table = host_prefix(z)
        numerator = sum(table[k-j] * sum(g * y**j for g, y in zip(gap_nats, z))
                        for j in range(k+1))
        return Fraction(numerator, sum(gap_nats) * math.comb(9+k, k) * d**k)

    moment_values = [[host_moment(z, d, k) for k in range(1, 7)]
                     for z, d in zip(deviation_nats, denominators)]
    gap_values = [sum((ms[k-1] - ms[0]**k) / k for k in range(2, 7)) for ms in moment_values]
    total = sum(map(int, moment_row['log_gap_factor_floors_Q80']))
    t = Fraction(total, 2**80)
    new_q96 = math.floor(Fraction(row['jensen_bound']) * (1 + t + t*t/2 + t*t*t/6) * 2**96)

    suffix = f'{index:03d}'
    namespace = f'ImbalancedChen.P2OriginalSaving19Cell00Row{suffix}MomentFloor'
    module = f'P2OriginalSaving19Cell00Row{suffix}PrefixFloorChecks'
    witness = {
        'schema': 'saving19_cell00_row_prefix_floor_candidate_literals_v1',
        'cell': 0, 'row': index,
        'host_role': 'candidate generation only; all equalities and bounds require Lean proof',
        'original_fixtures': BOOT['original_fixtures'], 'original_vertex_ids': row['vertex_ids'],
        'gap_scale': str(gap_scale), 'gap_nats': [str(x) for x in gap_nats],
        'deviation_denominators': [str(x) for x in denominators],
        'deviation_nats': [[str(x) for x in ds] for ds in deviation_nats],
        'moment_degree1_through6_candidates': [[qr(q) for q in ms] for ms in moment_values],
        'log_gap_candidates': [qr(q) for q in gap_values],
        'original_saved_Q80': moment_row['log_gap_factor_floors_Q80'],
        'original_old_Q96': moment_row['old_floor_Q96'],
        'original_saved_new_Q96': moment_row['new_floor_Q96'],
        'new_Q96_evaluator_candidate': str(new_q96),
        'sum_original_saved_Q80': str(total), 'mathematical_PASS_from_host': False,
    }
    jwrite(ROOT / 'witnesses' / f'row{suffix}.json', witness)

    encoded = replace_once(r'def gapScale : Nat := [0-9]+', f'def gapScale : Nat := {gap_scale}', encoding_body)
    encoded = replace_once(r'def gapNats : Fin 9 → Nat := !\[[^\n]+\]',
                           'def gapNats : Fin 9 → Nat := ' + vec(gap_nats), encoded)
    encoded = replace_once(r'def deviationDenominators : Fin 10 → Nat := !\[[^\n]+\]',
                           'def deviationDenominators : Fin 10 → Nat := ' + vec(denominators), encoded)
    encoded = replace_once(r'def deviationNats : Fin 10 → Fin 9 → Nat :=\n.*?(?=\n\ndef prefixMoment)',
                           'def deviationNats : Fin 10 → Fin 9 → Nat :=\n  ![' +
                           ',\n    '.join(vec(ds) for ds in deviation_nats) + ']', encoded, re.S)

    factor_texts = []
    for j in range(10):
        text = factor_bodies[j]
        for k, q in enumerate(moment_values[j], 1):
            text = replace_once(
                rf'(theorem factor{j:02d}_moment{k} : prefixMoment \({j} : Fin 10\) {k} = ).*?( := by)',
                lambda m: m[1] + rat(q) + m[2], text)
        text = replace_once(
            rf'(theorem factor{j:02d}_gap_value :\n    gapEvaluator \(prefixMoment \({j} : Fin 10\)\) = ).*?( := by)',
            lambda m: m[1] + rat(gap_values[j]) + m[2], text)
        factor_texts.append(text)

    assembled = replace_once(r'(theorem total_Q80_value :\n    totalLowerQ80 prefixMoment = \()[0-9]+( : ℚ\))',
                             lambda m: m[1] + str(total) + m[2], assembly_body)
    assembled = replace_once(r'(have h : \(∑ j : Fin 10, momentRow.factorFloorsQ80\[j.val\]! : ℤ\) = )[0-9]+',
                             lambda m: m[1] + str(total), assembled)
    assembled = replace_once(r'(newFloorQ96 \(massOf row\) \(meansOf row\) prefixMoment = )[0-9]+( := by)',
                             lambda m: m[1] + str(new_q96) + m[2], assembled)

    text = f'''import ImbalancedChen.P2OriginalSaving19Cell00Row{suffix}Arithmetic
import ImbalancedChen.P2OriginalSaving19PrefixMoments
import Mathlib.Tactic.FinCases
import Mathlib.Algebra.BigOperators.Field

/-! Cell00 row{suffix}: the passed row0 finite-prefix proof bodies with exact
row-specific integer literals. All ten factors retain degrees one through
six, original saved Q80 fields and both inequalities; all five original
floor clauses are retained in this prefix representation. Existing actual
row bindings and both old-Q96 equalities are imported, never recompiled.
The original rationalMoment semantic bridge remains separately pending. -/
namespace {namespace}

set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false

open scoped BigOperators
open P2OriginalSaving19Cell00Row{suffix}
open P2OriginalSaving19RowNumericsPure
open P2OriginalLogMomentQ96ArithmeticPure
open P2OriginalSaving19PrefixMoments

'''
    text += encoded + ''.join(factor_texts) + assembled
    text += 'end ' + namespace + '\n'
    text = text.replace('P26_ROW000_', f'P26_ROW{suffix}_')
    assert len(re.findall(r'^#print axioms ', text, re.M)) == 122
    assert not re.search(r'\b(sorry|admit|native_decide|unsafe)\b|^\s*axiom\b', text, re.M)
    target = PROJECT / (module + '.lean')
    write(target, text)
    generation = {
        'module': 'ImbalancedChen.' + module, 'cell': 0, 'row': index,
        'source': fp(target), 'candidate_witnesses': fp(ROOT / 'witnesses' / f'row{suffix}.json'),
        'original_template_manifest': fp(TEMPLATE_ROOT / 'PUBLICATION_SOURCES.json'),
        'encoding_and_factor_and_assembly_bodies_reused': True,
        'proof_body_changes': 'None; namespace, progress labels, row-specific exact literal RHS only',
        'namespace': namespace, 'printed_theorems': 122,
        'stage': 'source_candidate_requires_normal_and_independent_kernel',
        'original_rationalMoment_bridge_compiled': False,
    }
    jwrite(ROOT / 'generation' / f'row{suffix}.json', generation)
    print(json.dumps({'row': index, 'source': generation['source'],
                      'generated_new_Q96_candidate': str(new_q96),
                      'host_mathematical_PASS': False}), flush=True)

indices = [int(s) for s in sys.argv[1:]]
assert indices and len(indices) == len(set(indices))
for index in indices:
    generate(index)
