"""Continue only previously unbuilt cell00 rows; freeze every successful pair."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
TAG = 'combined-v1'
ALLOWED_AXIOMS = {'propext', 'Classical.choice', 'Quot.sound'}


def fp(p):
    data = p.read_bytes()
    return {'path': str(p), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def check_pair(index):
    module = f'P2OriginalSaving19Cell00Row{index:03d}PrefixFloorChecks'
    folder = ROOT / 'logs' / module
    np = folder / f'normal-{TAG}-result.json'
    kp = folder / f'kernel-{TAG}-result.json'
    n, k = (json.loads(p.read_text()) for p in (np, kp))
    for record in (n, k):
        assert record['status'] == 'succeeded' and record['exit_code'] == 0
        for key in ('source', 'object', 'log'):
            assert fp(Path(record[key]['path'])) == record[key]
        assert record['peak_rss_bytes'] <= 4 * 1024**3
    assert n['dependencies'] == k['dependencies']
    assert n['input_before'] == n['input_after'] == k['input_before'] == k['input_after']
    raw = Path(n['log']['path']).read_text()
    clean = re.sub(r'P26_ROW\d+_[^\n]*\n', '', raw)
    audits = re.findall(
        r"'([^']+)'\s+(?:depends on axioms:\s*\[([^]]*)\]|does not depend on any axioms)",
        clean, re.S)
    targets = re.findall(r'^#print axioms (.+)$', Path(n['source']['path']).read_text(), re.M)
    assert len(targets) == len(audits) == 122, (index, len(targets), len(audits))
    assert all(any(name.endswith('.' + target) for name, _ in audits) for target in targets)
    axioms = {x.strip() for _, values in audits for x in values.split(',') if x.strip()}
    assert axioms <= ALLOWED_AXIOMS
    assert f'replaying ImbalancedChen.{module}' in Path(k['log']['path']).read_text()
    return {'row': index, 'module': 'ImbalancedChen.' + module,
            'source': n['source'], 'object': n['object'],
            'normal_receipt': fp(np), 'kernel_receipt': fp(kp),
            'normal_seconds': n['elapsed_seconds'], 'kernel_seconds': k['elapsed_seconds'],
            'peak_rss_bytes': max(n['peak_rss_bytes'], k['peak_rss_bytes']),
            'axiom_audit_count': len(audits), 'axiom_union': sorted(axioms)}


def main():
    indices = [int(s) for s in sys.argv[1:]]
    assert indices and len(indices) == len(set(indices))
    assert all(5 <= i < 56 for i in indices)
    receipts = ROOT / 'continuation-receipts'
    receipts.mkdir(exist_ok=True)
    for index in indices:
        module = f'P2OriginalSaving19Cell00Row{index:03d}PrefixFloorChecks'
        target = ROOT / 'project/ImbalancedChen' / (module + '.lean')
        if not target.exists():
            subprocess.run([sys.executable, str(ROOT / 'generate_rows.py'), str(index)], check=True)
        for mode in ('normal', 'kernel'):
            folder = ROOT / 'logs' / module
            result = folder / f'{mode}-{TAG}-result.json'
            if result.exists():
                accepted = json.loads(result.read_text())
                assert accepted['status'] == 'succeeded' and accepted['exit_code'] == 0
                continue
            driver = folder / f'{mode}-{TAG}-driver-output.log'
            folder.mkdir(parents=True, exist_ok=True)
            assert not driver.exists()
            with driver.open('w') as output:
                process = subprocess.run(
                    [sys.executable, str(ROOT / 'run_local.py'), mode,
                     'ImbalancedChen.' + module, TAG],
                    stdout=output, stderr=subprocess.STDOUT)
            if process.returncode:
                print(json.dumps({'row': index, 'mode': mode, 'status': 'failed',
                                  'driver_log': str(driver)}), flush=True)
                sys.exit(process.returncode)
        pair = check_pair(index)
        summary = receipts / f'row{index:03d}.json'
        if summary.exists():
            assert json.loads(summary.read_text()) == pair
        else:
            summary.write_text(json.dumps(pair, indent=2) + '\n')
        print(json.dumps({'row': index, 'status': 'normal_kernel_audit_passed',
                          'seconds': pair['normal_seconds'] + pair['kernel_seconds'],
                          'peak_rss_bytes': pair['peak_rss_bytes'],
                          'receipt': str(summary)}), flush=True)


if __name__ == '__main__':
    main()
