"""Sequential new-owner normal/kernel calls to the unchanged local runner."""
from pathlib import Path
import hashlib, json, subprocess, sys

ROOT = Path(__file__).resolve().parent

def fp(p):
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}

indices = [int(x) for x in sys.argv[1:]]
assert indices and len(indices) == len(set(indices))
for index in indices:
    assert 1 <= index < 56
    module = f'ImbalancedChen.P2OriginalSaving19Cell00Row{index:03d}PrefixFloorChecks'
    generated = json.loads((ROOT / 'generation' / f'row{index:03d}.json').read_text())
    assert fp(Path(generated['source']['path'])) == generated['source']
    folder = ROOT / 'logs' / module.split('.')[-1]
    for mode in ['normal', 'kernel']:
        target = folder / f'{mode}-combined-v1-result.json'
        if target.exists():
            r = json.loads(target.read_text())
            assert r['status'] == 'succeeded' and r['exit_code'] == 0
            assert r['source'] == generated['source']
            assert fp(Path(r['object']['path'])) == r['object']
            print(json.dumps({'row': index, 'mode': mode, 'reused_existing_success': True}), flush=True)
            continue
        folder.mkdir(parents=True, exist_ok=True)
        invoke = folder / f'{mode}-combined-v1-driver-output.log'
        assert not invoke.exists()
        with invoke.open('w') as log:
            p = subprocess.run([sys.executable, str(ROOT / 'run_local.py'), mode, module, 'combined-v1'],
                               cwd='/', stdout=log, stderr=subprocess.STDOUT)
        assert target.exists(), (index, mode, 'runner did not produce a result', p.returncode)
        r = json.loads(target.read_text())
        print(json.dumps({k: r[k] for k in ['module', 'mode', 'status', 'exit_code',
                                           'elapsed_seconds', 'peak_rss_bytes', 'source', 'object']}),
              flush=True)
        if p.returncode != 0 or r['status'] != 'succeeded' or r['exit_code'] != 0:
            raise SystemExit(1)
