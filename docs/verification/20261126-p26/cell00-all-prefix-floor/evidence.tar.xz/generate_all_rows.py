"""Assemble the 56 opaque row certificates, preserving all five clauses."""
from pathlib import Path
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT / 'project/ImbalancedChen'
MODULE = 'P2OriginalSaving19Cell00AllPrefixFloorChecks'
NS = 'ImbalancedChen.' + MODULE


def fp(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def row_ns(index):
    return f'P2OriginalSaving19Cell00Row{index:03d}'


def floor_ns(index):
    return row_ns(index) + 'MomentFloor'


def selector(name, typ, field):
    values = ',\n    '.join(floor_ns(i) + '.' + field for i in range(56))
    return f'def {name} : Fin 56 → {typ} :=\n  ![{values}]\n\n'


def cases(body):
    return '  fin_cases r\n' + ''.join('  · ' + body(i) + '\n' for i in range(56)) + '\n'


bootstrap = json.loads((ROOT / 'BOOTSTRAP.json').read_text())
fixture = next(item for item in bootstrap['original_fixtures'] if 'minorant-extension' not in Path(item['path']).name)
assert fp(Path(fixture['path'])) == fixture
records = json.loads(Path(fixture['path']).read_text())['records']
assert len(records) == 56
old_total = sum(int(row['old_floor_Q96']) for row in records)
new_total = sum(int(row['new_floor_Q96']) for row in records)

text = ''.join(f'import ImbalancedChen.P2OriginalSaving19Cell00Row{i:03d}PrefixFloorChecks\n'
               for i in range(56))
text += '''
/-! Finite assembly of every cell00 row's exact degree-six prefix and floor
certificates. No original row or factor is omitted. The five original floor
clauses and both Q80 bounds are retained. All concrete row certificates are
reused; the connection to rationalMoment remains a separate semantic owner. -/
'''
text += f'namespace {NS}\n\n'
text += '''set_option maxRecDepth 1000000
set_option Elab.async false

open scoped BigOperators
open P2OriginalSaving19Archive
open P2OriginalSaving19Geometry00Decoding
open P2OriginalSaving19Geometry00BoundedAccess
open P2OriginalSaving19Moment00Decoding
open P2OriginalSaving19RowNumericsPure
open P2OriginalLogMomentQ96ArithmeticPure
open P2OriginalSaving19PrefixMoments

'''
text += selector('prefixMoments', 'Fin 10 → Nat → ℚ', 'prefixMoment')
text += selector('gapScales', 'Nat', 'gapScale')
text += selector('gapNumerators', 'Fin 9 → Nat', 'gapNats')
text += selector('deviationDenominators', 'Fin 10 → Nat', 'deviationDenominators')
text += selector('deviationNumerators', 'Fin 10 → Fin 9 → Nat', 'deviationNats')
text += '''theorem prefixMoments_eq_normalized (r : Fin 56) (j : Fin 10) (k : Nat) :
    prefixMoments r j k = normalizedMoment (gapNumerators r)
      (deviationNumerators r j) (deviationDenominators r j) k := by
  fin_cases r <;> rfl

theorem all_gapScales_ne (r : Fin 56) : gapScales r ≠ 0 := by
'''
text += cases(lambda i: f'exact {floor_ns(i)}.gapScale_ne')
text += '''theorem all_deviationDenominators_ne (r : Fin 56) (j : Fin 10) :
    deviationDenominators r j ≠ 0 := by
'''
text += cases(lambda i: f'exact {floor_ns(i)}.deviationDenominators_ne j')
text += '''theorem all_gap_encoding (r : Fin 56) : ∀ i : Fin 9,
    gapQ (boundedRowVertex r i) = (gapNumerators r i : ℚ) / (gapScales r : ℚ) := by
'''
text += cases(lambda i: f'rw [{row_ns(i)}.boundedRowVertex_eq]\n    exact {floor_ns(i)}.gap_encoding')
text += '''theorem all_deviation_encoding (r : Fin 56) : ∀ (j : Fin 10) (i : Fin 9),
    1 - factorsQ (boundedRowVertex r i) j / topsOf (boundedRow r) j =
      (deviationNumerators r j i : ℚ) / (deviationDenominators r j : ℚ) := by
'''
text += cases(lambda i: f'rw [{row_ns(i)}.boundedRowVertex_eq, {row_ns(i)}.boundedRow_eq]\n    exact {floor_ns(i)}.deviation_encoding')
text += '''def PrefixFloorChecksFor (row : GeometryRow) (momentRow : MomentRecord)
    (moments : Fin 10 → Nat → ℚ) : Prop :=
  (∀ j : Fin 10, moments j 1 = 1 - meansOf row j / topsOf row j) ∧
  (∀ j : Fin 10, momentRow.factorFloorsQ80[j.val]! = factorFloorQ80 (moments j)) ∧
  momentRow.oldFloorQ96 = row.jensenFloorQ96 ∧
  momentRow.oldFloorQ96 = oldFloorQ96 (massOf row) (meansOf row) ∧
  momentRow.newFloorQ96 =
    max (oldFloorQ96 (massOf row) (meansOf row))
      (newFloorQ96 (massOf row) (meansOf row) moments)

theorem all_bounded_prefix_floor_checks (r : Fin 56) :
    PrefixFloorChecksFor (boundedRow r) (momentConcrete00.rows[r.val]!)
      (prefixMoments r) := by
'''
text += cases(lambda i: f'rw [{row_ns(i)}.boundedRow_eq, {row_ns(i)}.raw_moment_row_eq]\n    exact {floor_ns(i)}.prefix_floor_checks')
text += '''theorem all_raw_prefix_floor_checks (r : Fin 56) :
    PrefixFloorChecksFor (concreteGeometry00.rows[r.val]!)
      (momentConcrete00.rows[r.val]!) (prefixMoments r) := by
  rw [row_lookup_no_fallback]
  exact all_bounded_prefix_floor_checks r

theorem all_first_moments (r : Fin 56) (j : Fin 10) :
    prefixMoments r j 1 = 1 - meansOf (boundedRow r) j / topsOf (boundedRow r) j :=
  (all_bounded_prefix_floor_checks r).1 j

theorem all_saved_Q80 (r : Fin 56) (j : Fin 10) :
    (momentConcrete00.rows[r.val]!).factorFloorsQ80[j.val]! =
      factorFloorQ80 (prefixMoments r j) :=
  (all_bounded_prefix_floor_checks r).2.1 j

theorem all_Q80_bounds (r : Fin 56) (j : Fin 10) :
    (((momentConcrete00.rows[r.val]!).factorFloorsQ80[j.val]! : ℤ) : ℚ) ≤
        gapEvaluator (prefixMoments r j) * (2 : ℚ)^80 ∧
      gapEvaluator (prefixMoments r j) * (2 : ℚ)^80 <
        (((momentConcrete00.rows[r.val]!).factorFloorsQ80[j.val]! : ℤ) : ℚ) + 1 := by
'''
text += cases(lambda i: f'rw [{row_ns(i)}.raw_moment_row_eq]\n    exact {floor_ns(i)}.all_Q80_bounds j')
text += '''theorem all_saved_new_Q96_max (r : Fin 56) :
    (momentConcrete00.rows[r.val]!).newFloorQ96 =
      max (oldFloorQ96 (massOf (boundedRow r)) (meansOf (boundedRow r)))
        (newFloorQ96 (massOf (boundedRow r)) (meansOf (boundedRow r)) (prefixMoments r)) :=
  (all_bounded_prefix_floor_checks r).2.2.2.2

'''
text += f'''theorem saved_old_Q96_total :
    (∑ r : Fin 56, (momentConcrete00.rows[r.val]!).oldFloorQ96) = {old_total} := by
  decide +kernel

theorem saved_new_Q96_total :
    (∑ r : Fin 56, (momentConcrete00.rows[r.val]!).newFloorQ96) = {new_total} := by
  decide +kernel

theorem saved_replacement_increment :
    (∑ r : Fin 56, ((momentConcrete00.rows[r.val]!).newFloorQ96 -
      (momentConcrete00.rows[r.val]!).oldFloorQ96)) = {new_total - old_total} := by
  rw [Finset.sum_sub_distrib, saved_new_Q96_total, saved_old_Q96_total]
  norm_num

'''
theorems = re.findall(r'^theorem ([A-Za-z0-9_]+)', text, re.M)
text += ''.join(f'#print axioms {name}\n' for name in theorems)
text += '\nend ' + NS + '\n'
assert not re.search(r'\b(sorry|admit|native_decide|unsafe)\b|^\s*axiom\b', text, re.M)
target = PROJECT / (MODULE + '.lean')
assert not target.exists()
target.write_text(text)
receipt = {'schema': 'saving19_cell00_all_prefix_assembly_candidate_v1',
           'source': fp(target), 'original_moment_fixture': fixture,
           'rows': 56, 'factors_per_row': 10, 'moment_degrees': [1, 2, 3, 4, 5, 6],
           'theorems': theorems, 'saved_old_Q96_total_candidate': str(old_total),
           'saved_new_Q96_total_candidate': str(new_total),
           'saved_replacement_increment_candidate': str(new_total - old_total),
           'host_mathematical_PASS': False, 'original_rationalMoment_bridge_compiled': False}
(ROOT / 'generation/all_rows.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
