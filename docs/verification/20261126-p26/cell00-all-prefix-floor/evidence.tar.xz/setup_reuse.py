from pathlib import Path
import hashlib, json, os

ROOT = Path(__file__).resolve().parent
ROW0 = Path('/workspace/p26-recovery-candidates/cell00-row000-moment-floor')
ARITH = Path('/workspace/p26-recovery-candidates/cell00-rows-rest')

def fp(p):
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}

def write(p, value):
    p.parent.mkdir(parents=True, exist_ok=True)
    assert not p.exists(), p
    p.write_bytes(value if isinstance(value, bytes) else value.encode())

def jwrite(p, value):
    write(p, json.dumps(value, indent=2, ensure_ascii=False) + '\n')

manifests = [(ROW0 / 'FULL_SOURCE_CLOSURE.json',
              '06fb0d9f17de18e44e524ea331c90c3c691a288effbdebe343d2b531380c646f'),
             (ARITH / 'FULL_SOURCE_CLOSURE.json',
              'd016c95e3482b92961140c0f83b5723daebaf0847af9b1ff38758c9a64bc677a')]
rows = {}
for path, expected in manifests:
    assert fp(path)['sha256'] == expected
    data = json.loads(path.read_text())
    for item in data['sources_objects_and_receipts']:
        module = item['module']
        for kind in ['source', 'object']:
            assert fp(Path(item[kind]['path'])) == item[kind]
        if module in rows:
            assert all(rows[module][kind]['sha256'] == item[kind]['sha256']
                       and rows[module][kind]['bytes'] == item[kind]['bytes']
                       for kind in ['source', 'object']), module
        else:
            rows[module] = item
assert len(rows) == 424

reused = []
for module, item in sorted(rows.items()):
    s, o = Path(item['source']['path']), Path(item['object']['path'])
    sc = ROOT / 'project' / (module.replace('.', '/') + '.lean')
    oc = ROOT / 'objects' / (module.replace('.', '/') + '.olean')
    write(sc, s.read_bytes())
    oc.parent.mkdir(parents=True, exist_ok=True)
    assert not oc.exists()
    os.link(o, oc)
    extras = []
    for suffix in ['.olean.private', '.olean.server', '.ir']:
        old = o.with_name(o.stem + suffix)
        if old.exists():
            target = oc.with_name(oc.stem + suffix)
            assert not target.exists()
            os.link(old, target)
            extras.append({'original': fp(old), 'copy': fp(target)})
    reused.append({'module': module,
                   'source': {'original': fp(s), 'copy': fp(sc)},
                   'object': {'original': fp(o), 'copy': fp(oc)},
                   'extra_object_siblings': extras,
                   'object_reuse': 'immutable hardlink', 'recompiled': False,
                   'acceptance_provenance': item})

old = json.loads((ROW0 / 'BOOTSTRAP.json').read_text())
jwrite(ROOT / 'BOOTSTRAP.json', {
    'schema': 'saving19_cell00_remaining55_prefix_floors_bootstrap_v1',
    'reused_helpers': reused, 'reused_count': len(reused),
    'accepted_source_closure_manifests': [fp(p) for p, _ in manifests],
    'external_LEAN_PATH_roots': old['external_LEAN_PATH_roots'],
    'original_fixtures': old['original_fixtures'], 'runtime': old['runtime'],
    'production_modified': False, 'remote_jobs_submitted': False,
    'accepted_suppliers_recompiled': False, 'row0_recompiled': False,
    'old_analytic_checker_imported': False,
    'original_rationalMoment_bridge_object_present': False,
})
write(ROOT / 'run_local.py', (ROW0 / 'run_local.py').read_bytes())
jwrite(ROOT / 'RUNNER_PROVENANCE.json', {
    'source_driver': fp(ROW0 / 'run_local.py'), 'copied_driver': fp(ROOT / 'run_local.py'),
    'byte_identical': True, 'rss_limit_bytes': 4 * 1024**3, 'wall_limit_seconds': 180,
    'new_owner_only': True, 'accepted_suppliers_recompiled': False,
})
print(json.dumps({'reused_accepted_sources_and_objects': len(reused),
                  'bootstrap': fp(ROOT / 'BOOTSTRAP.json'),
                  'new_Lean_owners_compiled': 0}))
