"""Replace only assembly rewrite tactics with explicit equality transport."""
from pathlib import Path
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parent
NAME = 'P2OriginalSaving19Cell00AllPrefixFloorChecks'
source = ROOT / 'project/ImbalancedChen' / (NAME + '.lean')
snapshot = ROOT / 'attempts' / NAME / 'assemble-v1' / source.name
assert source.read_bytes() == snapshot.read_bytes()
assert not (ROOT / 'objects/ImbalancedChen' / (NAME + '.olean')).exists()
text = source.read_text()
original = text


def ns(i):
    return f'P2OriginalSaving19Cell00Row{i:03d}'


def mf(i):
    return ns(i) + 'MomentFloor'


def replace_proof(name, proof):
    global text
    pattern = rf'(^theorem {name}\b.*? := by\n).*?(?=\n(?:theorem|def) )'
    text, count = re.subn(pattern, lambda match: match.group(1) + proof.rstrip() + '\n',
                          text, count=1, flags=re.S | re.M)
    assert count == 1, name


replace_proof('all_gap_encoding', '  intro i\n  fin_cases r\n' + ''.join(
    f'  · exact (congrArg gapQ (congrFun {ns(i)}.boundedRowVertex_eq i)).trans\n'
    f'      ({mf(i)}.gap_encoding i)\n' for i in range(56)))

replace_proof('all_deviation_encoding', '  intro j i\n  fin_cases r\n' + ''.join(
    '  · exact (congrArg₂ (fun vertex row => 1 - factorsQ vertex j / topsOf row j)\n'
    f'      (congrFun {ns(i)}.boundedRowVertex_eq i) {ns(i)}.boundedRow_eq).trans\n'
    f'      ({mf(i)}.deviation_encoding j i)\n' for i in range(56)))

replace_proof('all_bounded_prefix_floor_checks', '  fin_cases r\n' + ''.join(
    '  · exact Eq.mpr\n'
    '      (congrArg₂ (fun row momentRow =>\n'
    f'        PrefixFloorChecksFor row momentRow {mf(i)}.prefixMoment)\n'
    f'        {ns(i)}.boundedRow_eq {ns(i)}.raw_moment_row_eq)\n'
    f'      {mf(i)}.prefix_floor_checks\n' for i in range(56)))

replace_proof('all_Q80_bounds', '  fin_cases r\n' + ''.join(
    '  · exact Eq.mpr\n'
    '      (congrArg (fun momentRow : MomentRecord =>\n'
    '        ((momentRow.factorFloorsQ80[j.val]! : ℤ) : ℚ) ≤\n'
    f'            gapEvaluator ({mf(i)}.prefixMoment j) * (2 : ℚ)^80 ∧\n'
    f'          gapEvaluator ({mf(i)}.prefixMoment j) * (2 : ℚ)^80 <\n'
    '            ((momentRow.factorFloorsQ80[j.val]! : ℤ) : ℚ) + 1)\n'
    f'        {ns(i)}.raw_moment_row_eq)\n'
    f'      ({mf(i)}.all_Q80_bounds j)\n' for i in range(56)))

assert text != original
headers = lambda value: re.findall(r'^theorem .*?(?= :=| :\n)', value, re.M | re.S)
assert re.findall(r'^theorem (\w+)', original, re.M) == re.findall(r'^theorem (\w+)', text, re.M)
source.write_text(text)
receipt = {'schema': 'saving19_cell00_prefix_assembly_equality_transport_repair_v1',
           'source_before': {'path': str(snapshot), 'bytes': len(snapshot.read_bytes()),
                             'sha256': hashlib.sha256(snapshot.read_bytes()).hexdigest()},
           'source_after': {'path': str(source), 'bytes': len(source.read_bytes()),
                            'sha256': hashlib.sha256(source.read_bytes()).hexdigest()},
           'changed_proofs': ['all_gap_encoding', 'all_deviation_encoding',
                              'all_bounded_prefix_floor_checks', 'all_Q80_bounds'],
           'changes': 'Use congrArg/congrArg₂/Eq.mpr on the same original row equalities; statements and literals unchanged.',
           'accepted_row_owners_modified_or_recompiled': False,
           'failed_attempt_object_present': False}
out = ROOT / 'generation/all_rows_transport_repair.json'
assert not out.exists()
out.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
