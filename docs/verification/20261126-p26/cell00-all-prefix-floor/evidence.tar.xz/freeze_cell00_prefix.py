"""Freeze the complete cell00 prefix layer without replaying accepted owners."""
from pathlib import Path
import hashlib
import json
import re
import sys

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT / 'project'
OBJECTS = ROOT / 'objects'
BOOT = json.loads((ROOT / 'BOOTSTRAP.json').read_text())
TERMINAL = 'ImbalancedChen.P2OriginalSaving19Cell00AllPrefixFloorChecks'
ALLOWED_AXIOMS = {'propext', 'Classical.choice', 'Quot.sound'}


def fp(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def save(name, value):
    path = ROOT / name
    assert not path.exists(), path
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')
    return fp(path)


assembly_tag, = sys.argv[1:]
tags = {f'ImbalancedChen.P2OriginalSaving19Cell00Row{i:03d}PrefixFloorChecks': 'combined-v1'
        for i in range(1, 56)}
tags[TERMINAL] = assembly_tag
reused = {item['module']: item for item in BOOT['reused_helpers']}
assert len(reused) == BOOT['reused_count'] == 424
assert all(fp(Path(item['path'])) == item for item in BOOT['original_fixtures'])
owners = []
for module, tag in sorted(tags.items()):
    source = PROJECT / (module.replace('.', '/') + '.lean')
    obj = OBJECTS / (module.replace('.', '/') + '.olean')
    folder = ROOT / 'logs' / module.split('.')[-1]
    normal_path = folder / f'normal-{tag}-result.json'
    kernel_path = folder / f'kernel-{tag}-result.json'
    normal, kernel = [json.loads(path.read_text()) for path in (normal_path, kernel_path)]
    for result in (normal, kernel):
        assert result['status'] == 'succeeded' and result['exit_code'] == 0
        assert result['source'] == fp(source) and result['object'] == fp(obj)
        assert result['rss_limit_bytes'] == 4 * 1024**3
        assert result['peak_rss_bytes'] <= result['rss_limit_bytes']
        assert result['wall_limit_seconds'] == 180 and result['threads'] == 1
        assert result['input_before'] == result['input_after'] == BOOT['original_fixtures']
        assert fp(Path(result['log']['path'])) == result['log']
        for dependency in result['dependencies']:
            assert fp(Path(dependency['source']['path'])) == dependency['source']
            assert fp(Path(dependency['object']['path'])) == dependency['object']
    assert normal['dependencies'] == kernel['dependencies']
    content = source.read_text()
    assert not re.search(r'\b(sorry|admit|native_decide|unsafe)\b|^\s*axiom\b', content, re.M)
    source_snapshot = ROOT / 'attempts' / module.split('.')[-1] / tag / source.name
    assert source_snapshot.read_bytes() == source.read_bytes()
    raw_log = Path(normal['log']['path']).read_text()
    assert 'sorryAx' not in raw_log
    clean_log = re.sub(r'P26_ROW\d+_[^\n]*\n', '', raw_log)
    messages = re.findall(
        r"'([^']+)'\s+(?:depends on axioms:\s*\[([^]]*)\]|does not depend on any axioms)",
        clean_log, re.S)
    targets = re.findall(r'^#print axioms (.+)$', content, re.M)
    assert len(messages) == len(targets)
    assert all(any(name.endswith('.' + target) for name, _ in messages) for target in targets)
    audits = []
    for name, axiom_text in messages:
        axioms = sorted(x.strip() for x in axiom_text.split(',') if x.strip())
        assert set(axioms) <= ALLOWED_AXIOMS
        audits.append({'declaration': name, 'axioms': axioms})
    if module != TERMINAL:
        assert len(audits) == 122
        index = int(re.search(r'Row(\d{3})', module).group(1))
        generation = json.loads((ROOT / 'generation' / f'row{index:03d}.json').read_text())
        assert generation['source'] == fp(source)
        assert fp(Path(generation['candidate_witnesses']['path'])) == generation['candidate_witnesses']
    else:
        index = None
    assert f'replaying {module}' in Path(kernel['log']['path']).read_text()
    owners.append({'module': module, 'row': index, 'source': fp(source), 'object': fp(obj),
                   'normal_receipt': fp(normal_path), 'kernel_receipt': fp(kernel_path),
                   'normal_log': normal['log'], 'kernel_log': kernel['log'],
                   'normal_seconds': normal['elapsed_seconds'],
                   'kernel_seconds': kernel['elapsed_seconds'],
                   'normal_peak_rss_bytes': normal['peak_rss_bytes'],
                   'kernel_peak_rss_bytes': kernel['peak_rss_bytes'],
                   'reused_existing_candidate_without_recompile': index in range(1, 5) if index else False,
                   'printed_theorems_and_axioms': audits})

by_module = {row['module']: row for row in owners}
closure = {}


def visit(module):
    if module in closure:
        return
    source = PROJECT / (module.replace('.', '/') + '.lean')
    obj = OBJECTS / (module.replace('.', '/') + '.olean')
    assert source.is_file() and obj.is_file()
    imports = re.findall(r'^import\s+([^\s]+)', source.read_text(), re.M)
    row = {'module': module, 'source': fp(source), 'object': fp(obj), 'imports': imports,
           'new_owner_for_publication': module in tags}
    if module in tags:
        row['acceptance'] = by_module[module]
    else:
        assert module in reused, module
        supplier = reused[module]
        assert row['source'] == supplier['source']['copy']
        assert row['object'] == supplier['object']['copy']
        for category in ('source', 'object'):
            for side in ('original', 'copy'):
                assert fp(Path(supplier[category][side]['path'])) == supplier[category][side]
        row['reused_acceptance_provenance'] = supplier['acceptance_provenance']
    closure[module] = row
    for dependency in imports:
        if dependency.startswith('ImbalancedChen.'):
            visit(dependency)


visit(TERMINAL)
assert set(tags) <= set(closure)
assert not any(module.endswith(name) for module in closure for name in (
    'P2OriginalLogMomentQ96Checker', 'P2DegreeSixLogGapSoundness',
    'P2OriginalSaving19HigherMoments', 'P2OriginalSaving19HigherMomentsPrefix',
    'P2OriginalSaving19ArchiveCore', 'P2OriginalSaving19Archive'))
canonical = [{'module': module, 'source_bytes': row['source']['bytes'],
              'source_sha256': row['source']['sha256'], 'imports': row['imports']}
             for module, row in sorted(closure.items())]
canonical_sha = hashlib.sha256(json.dumps(canonical, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
closure_fp = save('FULL_SOURCE_CLOSURE.json', {
    'schema': 'saving19_cell00_all_prefix_complete_local_closure_v1',
    'project_modules': len(closure), 'publication_owner_count': len(tags),
    'reused_bootstrap_owner_count': len(reused),
    'source_closure_canonical_sha256': canonical_sha,
    'canonical_source_rows': canonical, 'sources_objects_and_receipts': list(closure.values()),
    'reused_owners_recompiled': False, 'P1_strict_claimed': False})

failures = []
for path in sorted((ROOT / 'logs').rglob('*-result.json')):
    result = json.loads(path.read_text())
    if result['status'] != 'succeeded' or result['exit_code'] != 0:
        failures.append({'receipt': fp(path), 'status': result['status'],
                         'exit_code': result['exit_code'], 'source': result['source'],
                         'object': result.get('object'), 'log': result['log']})
printed = [audit for owner in owners for audit in owner['printed_theorems_and_axioms']]
validation_fp = save('VALIDATION.json', {
    'schema': 'saving19_cell00_all_prefix_local_normal_kernel_v1', 'owners': owners,
    'publication_owner_count': len(owners), 'new_owner_count_this_continuation': 52,
    'existing_candidate_owner_count_reused': 4,
    'printed_theorem_count': len(printed),
    'axiom_union': sorted({axiom for audit in printed for axiom in audit['axioms']}),
    'normal_seconds_total': sum(owner['normal_seconds'] for owner in owners),
    'kernel_seconds_total': sum(owner['kernel_seconds'] for owner in owners),
    'peak_rss_bytes': max(max(owner['normal_peak_rss_bytes'], owner['kernel_peak_rss_bytes']) for owner in owners),
    'normal_and_kernel_passed': True, 'original_fixtures': BOOT['original_fixtures'],
    'raw_log_progress_interleaving_normalized_for_audit_parser': True,
    'budgets': {'rss_bytes': 4 * 1024**3, 'wall_seconds': 180, 'threads': 1},
    'driver': fp(ROOT / 'run_local.py'), 'orchestration': fp(ROOT / 'continue_rows.py'),
    'failed_attempts_preserved': failures, 'P1_strict_all_owned_audit_claimed': False})

bridge = ROOT / 'bridge-candidate/ImbalancedChen/P2OriginalSaving19Cell00AllOriginalFloorBridge.lean'
manifest_fp = save('SOURCE_MANIFEST.json', {
    'schema': 'saving19_cell00_all_prefix_verified_source_manifest_v1',
    'owners': [{key: owner[key] for key in ('module', 'source', 'object', 'normal_receipt', 'kernel_receipt')}
               for owner in owners],
    'full_source_closure': closure_fp, 'validation': validation_fp,
    'uncompiled_original_semantics_bridge': fp(bridge),
    'original_rationalMoment_bridge_not_in_this_verified_closure': True})
save('PUBLICATION_SOURCES.json', {
    'schema': 'saving19_cell00_all_prefix_publication_sources_v1',
    'owners': [{'module': owner['module'], 'repository_path': owner['module'].replace('.', '/') + '.lean',
                'source': owner['source']} for owner in owners],
    'row000_and_all_preexisting_suppliers_reused_unchanged': True,
    'source_only_bridge_excluded': fp(bridge)})

paper = Path('/workspace/scratch/32a3e5d7265b/audit/sources/new/paper/release-20261106/en/numerical-appendix.tex')
generation = json.loads((ROOT / 'generation/all_rows.json').read_text())
summary = {
    'schema': 'saving19_cell00_all_prefix_numeric_checkpoint_v1',
    'status': 'PASS_LOCAL_NORMAL_AND_INDEPENDENT_KERNEL_FOR_ALL_56_PREFIX_NUMERIC_ROWS',
    'cell': 0, 'rows': 56, 'row000_reused_from_previous_accepted_package': True,
    'publication_new_owners': 56, 'owners_first_accepted_this_continuation': 52,
    'previous_rows001_through004_reused_without_recompilation': True,
    'remaining_rows005_through055_completed': 51,
    'project_closure': len(closure), 'moment_value_equalities_total_cell00': 3360,
    'first_moment_encodings_total_cell00': 560,
    'saved_Q80_bindings_total_cell00': 560,
    'Q80_lower_and_strict_upper_bound_pairs_total_cell00': 560,
    'all_original_five_floor_clauses_in_prefix_representation': True,
    'saved_old_Q96_total': generation['saved_old_Q96_total_candidate'],
    'saved_new_Q96_total': generation['saved_new_Q96_total_candidate'],
    'saved_replacement_increment': generation['saved_replacement_increment_candidate'],
    'original_max_old_new_retained': True,
    'actual_original_vertex_order_and_no_fallback_bindings_reused': True,
    'original_rationalMoment_bridge_compiled_in_this_package': False,
    'integral_semantics_claimed_complete': False,
    'all13_Archive_guards_proved': False, 'P2_6_complete': False,
    'P1_strict_claimed': False, 'production_modified_by_this_agent': False,
    'remote_jobs_submitted_by_this_agent': False,
    'manuscript': {'repository': 'chen-imbalanced-semiprimes',
                   'commit': 'a988cba584d803ae2856a0de50efb582f4f3dd6a',
                   'source': fp(paper), 'label': 'num:simplex-moment', 'lines': [177, 196]},
    'source_manifest': manifest_fp, 'validation': validation_fp,
    'terminal_source': by_module[TERMINAL]['source'], 'terminal_object': by_module[TERMINAL]['object']}
save('FINAL_RESULT.json', summary)
print(json.dumps(summary, indent=2, ensure_ascii=False))
