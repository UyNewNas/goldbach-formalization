# Direct packed cell01: full parser generation extension

This document describes the implementation and its reuse boundary. Compilation
status is recorded by each owner receipt and by the frozen checkpoints. A final
`SOURCE_MANIFEST.json`, when present, records the complete parser result. This
document itself is not an acceptance receipt.

## Layers and source ownership

The eleven files of the parent `geometry-direct-packed` source-only baseline
and the four accepted `cell01-pilot-v1` owners remain unchanged. The full attempt
reuses the pilot's ten-module source/object closure; it does not import or
recompile the old flat-character cell00 parser or its packed transport.

`generate_full.py` extends the parameterized baseline `Engine` with root-field
headers, whole-array composition and parent-object continuations. Its active8
block zero is the original accepted pilot block. The other groups contain at
most eight reader chunks and at most 4096 original bytes. Each ordinary reader
chunk contains at most two elements and 768 bytes; larger self-delimiting child
values use the existing structured array/object templates within the group.

`generate_remainder.py` adds scalar/final-field composition and the original
whole-value/whole-parse endpoints. Its special 64-chunk minima grouping caused
the preserved timeout described below. `generate_remainder_v3.py` removes that
special grouping by delegating to the already used eight-chunk plan. It does
not alter any accepted Lean source, parser definition, raw input or budget.
`advance_remainder_v3.py` reuses every matching accepted source/object and
checks only new owners, stopping on the first actual failure.

`external_fragments.py` provides separately owned child certificates when a
child object or array exceeds the 4096-byte binding limit. Its interfaces are
parameterized by the configured cell, node span and engine; its actual cell01
instances are checked in the same normal/kernel sequence as ordinary blocks.

## Original-reader interfaces

For a self-delimiting child, the generic certificate is an equation of the
unchanged `SourceJson.value` on `fragmentChars ++ tail`, for arbitrary `tail`
and sufficient symbolic fuel. For an intermediate array block, the certificate
retains arbitrary `tail` and prior `acc` and returns the unchanged original
`SourceJson.array` continuation with the exact smaller fuel offset and updated
reverse accumulator. A final block returns `.arr ((blockPush acc).reverse)`;
it does not discard a generic prior accumulator.

The root-field header is an equation to the original value reader followed by
the real object continuation. The field-specific prior accumulator remains in
the theorem, so duplicate-key checks and all separator/error branches are
evaluated from the actual preceding original fields. After a proved value and
the exact original separator, the next root-object state is derived by
transitivity. Whole-array owners compose these opaque equations instead of
normalizing a concatenated large array.

Numbers are proved inside their actual separator frames; no certificate treats
an arbitrary numeric suffix as an independent token boundary. Returned tails
remain untrimmed until the original parent reader applies `white`. The exact
CRLF after the root closing brace is handled separately at the final endpoint.

## Packed-input binding

The production input definition is `Archive.geometryPacked01`. The input owner
uses `sourceRest n := (geometryPacked01.drop n).toList`; accepted tree/list
lemmas relate this to the original character list. Each small binding proves
`(sourceRest start).take count = literalChars`, then derives
`sourceRest start = literalChars ++ sourceRest end` with `take_append_drop` and
the existing drop-composition theorem.

For an oversized child, only its small opening/header/suffix intervals receive
new direct bindings. Already proved child/block split equations are assembled
with `congrArg` and append associativity to bind the entire large node. The
caller then applies the same arbitrary-tail reader certificate. No host parse,
SHA comparison or old-input span is substituted for this Lean equation.

The two actual oversized face-ledger children occupy [157281,162912) and
[162919,167229), respectively 5631 and 4310 bytes. The first includes a 4993-byte
array with its own two block suppliers. Both object proofs, all their child
suppliers and their parent-array transitions passed normal and independent
kernel checking; the corresponding sources/receipts are listed in the frozen
`checkpoints/face-ledger-complete/CHECKPOINT.json`.

## Preserved failed grouping and local repair

The first minima plan placed all 97 entries / 49 chunks in a single owner.
All 49 chunk-reader proofs completed, but their single large composition timed
out at 180.070 seconds (1,686,953,984-byte peak RSS). The source, owner manifest,
generator copies, log and receipt are preserved under
`revisions/minima-block000-timeout-v1/`; no successful object existed.

Restoring the existing eight-chunk grouping produced seven owner blocks. The
first replacement passed normal in 2.628 seconds and independent kernel in
1.363 seconds; the complete minima array and root continuation subsequently
passed. The original source and proof semantics were not changed. This is
evidence for limiting composition size as well as raw byte size, and it does
not establish a universal performance bound for other inputs.

## Reuse for further original cells

The baseline engine and fragment templates are parameterized by cell ID, raw
bytes and private workspace. The planner, numeric-token framing, structural
fuel offsets, chunk composition, external-child hierarchy and compact span
binding patterns are reusable implementation components.

This full attempt still has explicit cell01 specialization in `FullEngine`'s
input/bootstrap selection, frozen pilot supplier selection, final endpoint
names in `generate_remainder.py`, and the final evidence collector's expected
source/hash/length. A new cell must receive a new private attempt and those
bindings must be supplied from its original manifest, without editing these
frozen sources or relabeling receipts. The single-process fragment-template
configuration must not mix two cells in the same generation process.

Every new original input must independently establish its exact DataNN owner,
count/rest interface, metadata accumulator, all actual spans, original fuel
equations and final tail. The current implementation explicitly stops on an
oversized scalar child rather than silently treating it as an accepted large
object. No other-cell, typed-decoding, shape, numerical-floor or all13 result
follows from cell01 parsing.

All local checks retain 4 GiB process-tree RSS, 180 seconds per owner and one
thread. Normal compilation must succeed before independent kernel replay.
Accepted suppliers are reused, failed attempts are retained, and this attempt
does not modify production or submit P1/cloud compiler tasks.
