# Complete original SourceJson parsing: cell01

The closed theorem `geometryPacked01_original_parse` proves that the unchanged
original parser returns the explicitly defined `originalGeometryJson01` from
`String.ofList Archive.geometryPacked01.toList`. The preceding whole-value
theorem uses the original fuel 470902 and returns the exact untouched remaining
CRLF at offset 470899; original `white` is separately proved to remove that tail.

The original member is 470901 bytes, SHA256
`e19eee9d7e282cd3a618a71f12e93bcce28319485c9d0fd31bbeaf9f81a995a4`.
The production-compatible Data01 object is reused from the accepted v1 private
mirror. No full public-ZIP SHA verification or P1 original-path acceptance is
claimed by this local proof package.

All 14 original fields remain in order, with the original strings, numbers,
metadata, duplicate-key checks, separators, reverse accumulators and CRLF.
Large child values are proved through bounded original array/object transitions
and opaque child certificates. Actual compact-input spans are separately bound;
large spans are assembled from smaller binding equations. No whole-file decide,
replacement reader, or assumed parser-success premise is used.

The project closure contains 180 modules: 10 frozen suppliers
and 170 new owners. Every new owner passed normal compilation and
independent kernel replay with 4 GiB process-tree RSS, 180 seconds and one thread.
The maximum observed RSS was 2,095,222,784 bytes. The 3388 new theorem
declarations all have printed axiom reports; their union is
Classical.choice, Quot.sound, propext. Preserved failed attempt receipts, if any,
are separately listed in SOURCE_MANIFEST.json.

This package proves pure parsing of cell01 only. Typed geometry decoding, shape
checks, numerical floors, the other cells and complete Saving19 remain separate.
The v1 four-owner proof and eleven generator baseline files were not changed or
recompiled; no cell00 parser was rerun and no remote compiler task was submitted.

SOURCE_MANIFEST.json records the exact statements' owners, source/object hashes,
normal/kernel receipts, resource measurements and scope. SOURCE_INPUTS.json
records the complete project import closure and accepted supplier identities.
