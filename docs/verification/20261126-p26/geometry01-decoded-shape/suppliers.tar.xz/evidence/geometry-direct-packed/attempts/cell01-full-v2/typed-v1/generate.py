#!/usr/bin/env python3
"""Typed cell01 certificates over the already accepted original parser AST.

Host code only quotes original scalar tokens and selects original block items.
The unchanged Lean decoders prove every getter, rational and list equation.
"""
from pathlib import Path
import argparse
import hashlib
import json
import re
import raw_planner as base
from quotation import nat, int_, rat, arr, record_value

ROOT = Path(__file__).resolve().parent
PARSER = ROOT.parent
PROJECT = ROOT / 'project'
NS = 'ImbalancedChen.P2OriginalSaving19Geometry01DirectDecoding'
BOOTSTRAP = json.loads((ROOT / 'BOOTSTRAP.json').read_text())
RAW_PATH = Path(BOOTSTRAP['original_fixture']['path'])
RAW = RAW_PATH.read_bytes()
assert len(RAW) == 470901 and hashlib.sha256(RAW).hexdigest() == 'e19eee9d7e282cd3a618a71f12e93bcce28319485c9d0fd31bbeaf9f81a995a4'
PLAN = base.RawPlanner(RAW).value(0)
FIELDS = {f.key.scalar: f.value for f in PLAN.fields}
CONFIG = {
    'vertices': ('Vertices', 'vertices', 'Array ℚ', 'rationalArray'),
    'vertex_values': ('VertexValues', 'vertexValues', 'VertexValues', 'decodeVertexValues'),
    'facet_vertices': ('FacetVertices', 'facetVertices', 'Array Nat', '(SourceJson.Decode.read (α := Array Nat))'),
    'face_ledger': ('Faces', 'faceLedger', 'FaceRecord', 'decodeFace'),
    'simplices': ('Rows', 'simplices', 'GeometryRow', 'decodeGeometryRow'),
}
ORIGINAL_TAG = {'vertices': 'Vertices', 'vertex_values': 'VertexValues',
                'facet_vertices': 'FacetVertices', 'face_ledger': 'FaceLedger', 'simplices': 'Simplices'}


def fp(path):
    path = Path(path)
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def write_new(path, data):
    path = Path(path)
    data = data.encode() if isinstance(data, str) else data
    if path.exists():
        assert path.read_bytes() == data, ('Frozen typed owner drift', str(path))
    else:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)


def registry():
    rows = {r['module']: r for r in BOOTSTRAP['accepted_suppliers']}
    for path in (ROOT / 'owners').glob('*.json'):
        row = json.loads(path.read_text())
        rows[row['module']] = {**row, 'object': {'path': str(ROOT / 'objects' / (row['module'].replace('.', '/') + '.olean'))}}
    return rows


def head(imports, description):
    return ''.join('import ImbalancedChen.' + x + '\n' for x in imports) + f'''
/-! {description}
The original cell01 JSON, original ArchiveSchema and original rational guards
are preserved. Host quotations do not establish decoding or geometry validity. -/
namespace {NS}
set_option maxRecDepth 1000000
set_option Elab.async false
set_option stderrAsMessages false
open ImbalancedChen.P2OriginalSaving19Archive
open ImbalancedChen.P2OriginalSaving19Geometry01DirectParsing
open ImbalancedChen.P2OriginalSaving19Geometry00Decoding

'''


def foot(names):
    assert len(names) == len(set(names))
    return '\n'.join('#print axioms ' + name for name in names) + '\n\nend ' + NS + '\n'


def mark(label):
    return 'run_cmd do\n  let err ← IO.getStderr\n  err.putStrLn "P26_GEOMETRY01_TYPED ' + label + '"\n  err.flush\n\n'


def save(short, source, obligations):
    source = source.replace('\ndef ', '\nnoncomputable def ')
    assert not re.search(r'\b(?:sorry|admit|native_decide|unsafe)\b|(?m:^\s*axiom\b)', source)
    path = PROJECT / 'ImbalancedChen' / (short + '.lean')
    write_new(path, source)
    imports = re.findall(r'(?m)^import\s+(ImbalancedChen\.\S+)', source)
    known = registry()
    visited, closure = set(), []

    def visit(module):
        if module in visited:
            return
        visited.add(module)
        row = known[module]
        assert fp(row['source']['path']) == row['source']
        for dependency in row['project_imports']:
            visit(dependency)
        closure.append({k: row[k] for k in ['module', 'source', 'object', 'project_imports']})

    for module in imports:
        visit(module)
    row = {
        'module': 'ImbalancedChen.' + short, 'source': fp(path),
        'scope': 'Actual original cell01 typed decoder equality',
        'project_imports': imports, 'dependency_closure': closure,
        'fixture': fp(RAW_PATH), 'planned_obligations': obligations,
        'bootstrap': fp(ROOT / 'BOOTSTRAP.json'), 'generator': fp(Path(__file__)),
        'production_input_FQN': 'ImbalancedChen.P2OriginalSaving19Archive.geometryPacked01',
        'original_decoder_unchanged': True, 'host_typed_quotations_are_proof': False,
        'all13_pass_claimed': False, 'geometric_correctness_claimed': False,
        'accepted_dependencies_recompiled': False, 'production_modified': False,
        'remote_jobs_submitted': False,
    }
    write_new(ROOT / 'owners' / (short + '.json'), json.dumps(row, indent=2) + '\n')
    return row


def chunks_for(node):
    key = next(k for k in CONFIG if FIELDS[k] is node)
    tag = ORIGINAL_TAG[key]
    result = []
    paths = sorted((PARSER / 'owners').glob('P2OriginalSaving19Geometry01Direct' + tag + 'Block[0-9][0-9][0-9].json'))
    for index, path in enumerate(paths):
        owner = json.loads(path.read_text())
        assert owner['module'].endswith(f'{tag}Block{index:03d}')
        selected = owner['planned_obligations']['selected_chunks']
        result.append({'index': index, 'first': selected[0]['first'], 'after': selected[-1]['after'],
                       'start': selected[0]['start'], 'end': selected[-1]['end'],
                       'original_owner': owner['module'], 'original_owner_manifest': fp(path)})
    assert result and result[0]['first'] == 0 and result[-1]['after'] == len(node.children)
    assert all(a['after'] == b['first'] for a, b in zip(result, result[1:]))
    return result


def short(key, index):
    return f'P2OriginalSaving19Geometry01DirectDecoded{CONFIG[key][0]}{index:03d}'


def item_name(tag, index):
    return f'geometry{tag}Json{index:03d}'


def typed_name(tag, index):
    return f'geometry{tag}Typed{index:03d}'


def decode_name(tag, index):
    return f'decode_geometry_{tag}_{index:03d}'


def orig_push(prefix, index):
    key = next(k for k, v in CONFIG.items() if v[1] == prefix)
    return f'{ORIGINAL_TAG[key]}Block{index:03d}.blockPush'


def block(key, index):
    tag, prefix, typ, decoder = CONFIG[key]
    node = FIELDS[key]
    group = chunks_for(node)[index]
    ids = list(range(group['first'], group['after']))
    original = ORIGINAL_TAG[key]
    imports = ['P2OriginalSaving19ArchiveRationalChars', f'P2OriginalSaving19Geometry01Direct{original}Value']
    if index:
        imports.append(short(key, index - 1))
    source = head(imports, f'Original {key} typed block {index}, keeping exact original record order.')
    names, row_plans = [], []
    if key == 'simplices':
        from render_rows import render_row
        for item in ids:
            body, declarations, plan = render_row(item)
            source += body
            names.extend(declarations)
            row_plans.append(plan)
    else:
        for item in ids:
            raw, typed = item_name(tag, item), typed_name(tag, item)
            source += f'''def {raw} : SourceJson :=
  ({orig_push(prefix, index)} []).get ⟨{group['after'] - 1 - item}, by decide +kernel⟩

def {typed} : {typ} :=
  {record_value(key, node.children[item])}

'''
            source += mark(f'{tag}_{item:03d}_before_decode')
            source += f'''theorem {decode_name(tag, item)} :
    {decoder} {raw} = .ok {typed} := by decide +kernel

'''
            source += mark(f'{tag}_{item:03d}_decoded')
            names.append(decode_name(tag, item))
    raw_block = f'geometry{tag}JsonBlock{index:03d}'
    typed_block = f'geometry{tag}TypedBlock{index:03d}'
    total = f'geometry{tag}TypedThroughBlock{index:03d}'
    source += f'def {raw_block} : List SourceJson := [' + ', '.join(item_name(tag, j) for j in ids) + ']\n'
    source += f'def {typed_block} : List ({typ}) := [' + ', '.join(typed_name(tag, j) for j in ids) + ']\n'
    total_expr = typed_block if index == 0 else f'geometry{tag}TypedThroughBlock{index - 1:03d} ++ {typed_block}'
    source += f'def {total} : List ({typ}) := {total_expr}\n\n'
    reversed_records = '[' + ', '.join(item_name(tag, j) for j in reversed(ids)) + ']'
    push = orig_push(prefix, index)
    source += f'''theorem geometry_{tag}_block_{index:03d}_push_eq (acc : List SourceJson) :
    {push} acc = {reversed_records} ++ acc := by rfl

theorem geometry_{tag}_block_{index:03d}_reverse (acc : List SourceJson) :
    ({push} acc).reverse = acc.reverse ++ {raw_block} := by
  rw [geometry_{tag}_block_{index:03d}_push_eq, List.reverse_append]
  rfl

theorem decode_geometry_{tag}_block_{index:03d} :
    {raw_block}.mapM {decoder} = .ok {typed_block} := by
  simp only [{raw_block}, {typed_block}, List.mapM_cons, List.mapM_nil,
    {', '.join(decode_name(tag, j) for j in ids)}]
  rfl

theorem decode_geometry_{tag}_through_block_{index:03d} :
    {original}Value.arrayAcc{index + 1:03d}.reverse.mapM {decoder} = .ok {total} := by
  change ({push} {original}Value.arrayAcc{index:03d}).reverse.mapM {decoder} = _
  rw [geometry_{tag}_block_{index:03d}_reverse]
'''
    if index == 0:
        source += f'  exact decode_geometry_{tag}_block_{index:03d}\n\n'
    else:
        source += f'  rw [List.mapM_append, decode_geometry_{tag}_through_block_{index - 1:03d}, decode_geometry_{tag}_block_{index:03d}]\n  rfl\n\n'
    names.extend([f'geometry_{tag}_block_{index:03d}_push_eq', f'geometry_{tag}_block_{index:03d}_reverse',
                  f'decode_geometry_{tag}_block_{index:03d}', f'decode_geometry_{tag}_through_block_{index:03d}'])
    source += mark(f'{tag}_block_{index:03d}_complete') + foot(names)
    return save(short(key, index), source, {
        'original_key': key, 'block': index, 'source_block': group, 'record_indices': ids,
        'row_field_plans': row_plans, 'all_original_schema_fields_preserved': True,
        'original_order_preserved': True, 'original_JSON_access': 'List.get with kernel-checked bound',
        'full_decodeGeometry_claimed': False,
    })


def fields():
    params = '(vertexJson valueJson rowJson facetJson faceJson : List SourceJson)'
    args = 'vertexJson valueJson rowJson facetJson faceJson'
    source_args = ' '.join(f'{ORIGINAL_TAG[key]}Value.arrayAcc{len(chunks_for(FIELDS[key])):03d}.reverse'
                          for key in ['vertices', 'vertex_values', 'simplices', 'facet_vertices', 'face_ledger'])
    source = head(['P2OriginalSaving19ArchiveRationalChars', 'P2OriginalSaving19Geometry01DirectWholeValue'],
                  'Original metadata and abstract original decoder composition for cell01.')
    source += f'''def geometryObjectWithArrays {params} : SourceJson :=
  .obj (Metadata05.metadataAcc.reverse ++ [
    (Active8EnumerationField.fieldKey, Active8EnumerationValue.arrayValue),
    (VerticesField.fieldKey, .arr vertexJson),
    (VertexValuesField.fieldKey, .arr valueJson),
    (AllOriginalConstraintMinimaField.fieldKey, AllOriginalConstraintMinimaValue.arrayValue),
    (FacetVerticesField.fieldKey, .arr facetJson),
    (FaceLedgerField.fieldKey, .arr faceJson),
    (SimplicesField.fieldKey, .arr rowJson),
    (PhysicalVolumeField.fieldKey, PhysicalVolumeField.fieldValue),
    (finalFieldKey, finalFieldValue)])

theorem originalGeometryJson01_eq_object :
    originalGeometryJson01 = geometryObjectWithArrays {source_args} := by rfl

def geometryDecodedDimension : Nat := {nat(FIELDS['dimension'])}
def geometryDecodedPhysicalJacobian : Nat := {nat(FIELDS['physical_jacobian'])}
def geometryDecodedFacetOriginalIndices : Array Nat := {arr(FIELDS['facet_original_indices'], nat)}

'''
    names = ['originalGeometryJson01_eq_object']
    for key, typ, value in [('dimension', 'Nat', 'geometryDecodedDimension'),
                             ('physical_jacobian', 'Nat', 'geometryDecodedPhysicalJacobian'),
                             ('facet_original_indices', 'Array Nat', 'geometryDecodedFacetOriginalIndices')]:
        name = 'geometry_get_' + key
        source += f'''theorem {name} {params} :
    (geometryObjectWithArrays {args}).getObjValAs? ({typ}) "{key}" = .ok {value} := by
  change SourceJson.Decode.read (α := {typ}) ({base.lean_node(FIELDS[key])}) = .ok {value}
  decide +kernel

'''
        names.append(name)
    for key, param in [('vertices', 'vertexJson'), ('vertex_values', 'valueJson'),
                       ('simplices', 'rowJson'), ('face_ledger', 'faceJson')]:
        name = 'geometry_get_' + key
        source += f'''theorem {name} {params} :
    (geometryObjectWithArrays {args}).getObjVal? "{key}" = .ok (.arr {param}) := by rfl

'''
        names.append(name)
    source += f'''theorem geometry_get_facet_vertices {params} :
    (geometryObjectWithArrays {args}).getObjValAs? (Array (Array Nat)) "facet_vertices" =
      facetJson.toArray.mapM (SourceJson.Decode.read (α := Array Nat)) := by rfl

def geometryWithDecodedArrays
    (vertices : Array (Array ℚ)) (vertexValues : Array VertexValues)
    (rows : Array GeometryRow) (facetVertices : Array (Array Nat))
    (faces : Array FaceRecord) : Geometry := {{
  dimension := geometryDecodedDimension
  physicalJacobian := geometryDecodedPhysicalJacobian
  vertices := vertices
  vertexValues := vertexValues
  rows := rows
  facetOriginalIndices := geometryDecodedFacetOriginalIndices
  facetVertices := facetVertices
  faces := faces }}

theorem mapM_array_of_list_ok {{α β : Type}}
    (read : α → Except String β) (source : List α) (target : List β)
    (h : source.mapM read = .ok target) :
    source.toArray.mapM read = .ok target.toArray := by
  rw [List.mapM_toArray, h]
  rfl

theorem decodeGeometry_of_array_decodes
    {params}
    (vertices : Array (Array ℚ)) (vertexValues : Array VertexValues)
    (rows : Array GeometryRow) (facetVertices : Array (Array Nat)) (faces : Array FaceRecord)
    (hvertices : vertexJson.toArray.mapM rationalArray = .ok vertices)
    (hvalues : valueJson.toArray.mapM decodeVertexValues = .ok vertexValues)
    (hrows : rowJson.toArray.mapM decodeGeometryRow = .ok rows)
    (hfacets : facetJson.toArray.mapM (SourceJson.Decode.read (α := Array Nat)) = .ok facetVertices)
    (hfaces : faceJson.toArray.mapM decodeFace = .ok faces) :
    decodeGeometry (geometryObjectWithArrays {args}) =
      .ok (geometryWithDecodedArrays vertices vertexValues rows facetVertices faces) := by
  simp only [decodeGeometry, geometry_get_dimension, geometry_get_physical_jacobian,
    geometry_get_vertices, geometry_get_vertex_values, geometry_get_simplices,
    geometry_get_facet_original_indices, geometry_get_facet_vertices, geometry_get_face_ledger,
    SourceJson.getArr?, hvertices, hvalues, hrows, hfacets, hfaces, bind, Except.bind]
  rfl

theorem geometry_parse_decode_of_equalities
    (text : String) (parsed : SourceJson) (decoded : Geometry)
    (hparse : SourceJson.parse text = .ok parsed)
    (hdecode : decodeGeometry parsed = .ok decoded) :
    (SourceJson.parse text >>= decodeGeometry) = .ok decoded := by
  rw [hparse]
  exact hdecode

'''
    names.extend(['geometry_get_facet_vertices', 'mapM_array_of_list_ok',
                  'decodeGeometry_of_array_decodes', 'geometry_parse_decode_of_equalities'])
    source += foot(names)
    return save('P2OriginalSaving19Geometry01DirectDecodeFields', source, {
        'original_root_fields': 14, 'all_original_Geometry_schema_fields': 8,
        'five_JSON_array_lists_remain_abstract': True,
        'original_parsed_JSON_identity_closed': True, 'full_decodeGeometry_claimed': False})


def complete():
    order = ['vertices', 'vertex_values', 'simplices', 'facet_vertices', 'face_ledger']
    final = {key: len(chunks_for(FIELDS[key])) - 1 for key in order}
    imports = ['P2OriginalSaving19Geometry01DirectDecodeFields', 'P2OriginalSaving19Geometry01DirectWholeParse']
    imports.extend(short(key, final[key]) for key in order)
    source = head(imports, 'Complete original packed cell01 parsing and actual original Geometry decoding.')
    source_args = ' '.join(f'{ORIGINAL_TAG[key]}Value.arrayAcc{final[key] + 1:03d}.reverse' for key in order)
    target_args = ' '.join(f'geometry{CONFIG[key][0]}TypedThroughBlock{final[key]:03d}.toArray' for key in order)
    source += f'''def concreteGeometry01 : Geometry :=
  geometryWithDecodedArrays {target_args}

theorem decode_originalGeometryJson01 :
    decodeGeometry originalGeometryJson01 = .ok concreteGeometry01 :=
  (congrArg decodeGeometry originalGeometryJson01_eq_object).trans
    (decodeGeometry_of_array_decodes {source_args}
      {target_args}
'''
    for index, key in enumerate(order):
        tag, _, _, decoder = CONFIG[key]
        source += f'''      (mapM_array_of_list_ok {decoder} {ORIGINAL_TAG[key]}Value.arrayAcc{final[key] + 1:03d}.reverse
        geometry{tag}TypedThroughBlock{final[key]:03d} decode_geometry_{tag}_through_block_{final[key]:03d})'''
        source += ')\n\n' if index == len(order) - 1 else '\n'
    source += '''theorem geometryPacked01_parse_decode :
    (SourceJson.parse (String.ofList geometryPacked01.toList) >>= decodeGeometry) =
      .ok concreteGeometry01 :=
  geometry_parse_decode_of_equalities (String.ofList geometryPacked01.toList)
    originalGeometryJson01 concreteGeometry01 geometryPacked01_original_parse decode_originalGeometryJson01

'''
    source += foot(['decode_originalGeometryJson01', 'geometryPacked01_parse_decode'])
    return save('P2OriginalSaving19Geometry01DirectPackedDecoded', source, {
        'complete_original_parser_and_decodeGeometry_to_concrete_value': True,
        'all_eight_schema_fields': True, 'original_root_fields_retained': 14,
        'original_row_count': len(FIELDS['simplices'].children),
        'success_tag_only': False, 'getD_or_fallback_used': False,
        'geometric_certificate_correctness_claimed': False, 'all13_pass_claimed': False})


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('key', choices=list(CONFIG) + ['fields', 'complete'])
    parser.add_argument('--block', type=int, default=0)
    args = parser.parse_args()
    result = fields() if args.key == 'fields' else complete() if args.key == 'complete' else block(args.key, args.block)
    print(json.dumps({'module': result['module'], 'source': result['source']}, indent=2))
