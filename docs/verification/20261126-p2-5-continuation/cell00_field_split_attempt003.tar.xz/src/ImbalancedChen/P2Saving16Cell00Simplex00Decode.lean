import ImbalancedChen.P2Saving16Cell00FieldSimp

/-!
SOURCE ONLY / UNCOMPILED / ZERO NEW FORMAL CREDIT.
Mechanical owner split of the frozen cell00 field certificate.
Original theorem commands, statements and proof bodies remain byte-identical.
-/
namespace ImbalancedChen.P2Saving16Cell00FieldDecode
open P2OriginalSaving19Archive (SourceJson)
open P2OriginalSaving16OriginalArchive
open P2Saving16Cell00TypedPayload
open P2Saving16Cell00ScalarDecode
open scoped ImbalancedChen.P2Saving16Cell00FieldDecode

theorem simplex00_lookup_simplex_id :
    rawSimplex00.getObjVal? "simplex_id" = .ok (.number (String.ofList ['0'])) := by
  rfl

attribute [local simp] simplex00_lookup_simplex_id

theorem simplex00_lookup_vertex_ids :
    rawSimplex00.getObjVal? "vertex_ids" = .ok (.arr [.number (String.ofList ['1', '5']), .number (String.ofList ['1', '4']), .number (String.ofList ['1', '3']), .number (String.ofList ['9']), .number (String.ofList ['7']), .number (String.ofList ['6']), .number (String.ofList ['3']), .number (String.ofList ['1']), .number (String.ofList ['0'])]) := by
  rfl

attribute [local simp] simplex00_lookup_vertex_ids

theorem simplex00_lookup_physical_volume :
    rawSimplex00.getObjVal? "physical_volume" = .ok (.str (String.ofList ['3', '8', '7', '7', '3', '5', '6', '8', '0', '8', '5', '7', '7', '9', '4', '6', '8', '9', '1', '0', '1', '7', '4', '0', '8', '3', '2', '1', '9', '1', '1', '/', '1', '6', '8', '3', '1', '0', '3', '2', '2', '9', '1', '6', '5', '0', '3', '9', '0', '6', '2', '5', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0'])) := by
  rfl

attribute [local simp] simplex00_lookup_physical_volume

theorem simplex00_lookup_mean_gap :
    rawSimplex00.getObjVal? "mean_gap" = .ok (.str (String.ofList ['2', '3', '4', '3', '1', '/', '6', '8', '6', '2', '5', '0', '0', '0'])) := by
  rfl

attribute [local simp] simplex00_lookup_mean_gap

theorem simplex00_lookup_factor_maxima :
    rawSimplex00.getObjVal? "factor_maxima" = .ok (.arr [.str (String.ofList ['2', '4', '8', '4', '3', '2', '3', '/', '2', '8', '0', '0', '0', '0', '0', '0']), .str (String.ofList ['2', '4', '8', '4', '3', '2', '3', '/', '2', '8', '0', '0', '0', '0', '0', '0']), .str (String.ofList ['1', '8', '3', '2', '8', '0', '7', '3', '/', '1', '0', '8', '0', '0', '0', '0', '0', '0']), .str (String.ofList ['5', '9', '6', '8', '6', '3', '/', '5', '6', '0', '0', '0', '0', '0']), .str (String.ofList ['2', '4', '0', '7', '8', '1', '3', '7', '/', '2', '4', '4', '0', '0', '0', '0', '0', '0']), .str (String.ofList ['5', '1', '5', '5', '8', '1', '/', '1', '2', '0', '0', '0', '0', '0', '0']), .str (String.ofList ['1', '4', '0', '6', '1', '9', '/', '4', '0', '0', '0', '0', '0', '0']), .str (String.ofList ['1', '1', '7', '1', '8', '4', '7', '/', '3', '6', '0', '0', '0', '0', '0', '0']), .str (String.ofList ['1', '1', '7', '1', '8', '4', '7', '/', '3', '6', '0', '0', '0', '0', '0', '0']), .str (String.ofList ['1', '1', '7', '1', '8', '2', '3', '/', '3', '6', '0', '0', '0', '0', '0', '0'])]) := by
  rfl

attribute [local simp] simplex00_lookup_factor_maxima

theorem simplex00_lookup_gap_weighted_means :
    rawSimplex00.getObjVal? "gap_weighted_means" = .ok (.arr [.str (String.ofList ['6', '9', '7', '3', '2', '9', '5', '8', '7', '/', '8', '5', '4', '0', '0', '0', '0', '0', '0', '0']), .str (String.ofList ['7', '0', '2', '5', '7', '8', '1', '3', '1', '/', '8', '5', '4', '0', '0', '0', '0', '0', '0', '0']), .str (String.ofList ['1', '1', '8', '7', '9', '8', '4', '6', '1', '9', '3', '4', '9', '/', '7', '1', '4', '7', '9', '8', '0', '0', '0', '0', '0', '0', '0']), .str (String.ofList ['2', '6', '1', '5', '7', '4', '8', '8', '3', '2', '1', '/', '2', '6', '4', '7', '4', '0', '0', '0', '0', '0', '0', '0']), .str (String.ofList ['7', '7', '0', '5', '4', '6', '0', '8', '2', '9', '1', '/', '7', '9', '4', '2', '2', '0', '0', '0', '0', '0', '0', '0']), .str (String.ofList ['2', '5', '9', '4', '1', '1', '0', '7', '8', '0', '3', '/', '7', '9', '4', '2', '2', '0', '0', '0', '0', '0', '0', '0']), .str (String.ofList ['1', '6', '4', '6', '6', '9', '8', '8', '8', '1', '/', '5', '2', '9', '4', '8', '0', '0', '0', '0', '0', '0']), .str (String.ofList ['2', '4', '0', '8', '0', '1', '7', '0', '9', '2', '1', '/', '7', '9', '4', '2', '2', '0', '0', '0', '0', '0', '0', '0']), .str (String.ofList ['8', '0', '2', '6', '7', '0', '5', '9', '9', '1', '/', '2', '6', '4', '7', '4', '0', '0', '0', '0', '0', '0', '0']), .str (String.ofList ['6', '6', '4', '3', '3', '5', '9', '2', '3', '9', '/', '2', '3', '0', '5', '8', '0', '0', '0', '0', '0', '0', '0'])]) := by
  rfl

attribute [local simp] simplex00_lookup_gap_weighted_means

theorem simplex00_lookup_max_bound :
    rawSimplex00.getObjVal? "max_bound" = .ok (.str (String.ofList ['1', '2', '4', '8', '6', '3', '7', '6', '6', '6', '6', '7', '2', '0', '8', '5', '5', '4', '5', '8', '2', '6', '2', '4', '2', '4', '7', '9', '5', '8', '2', '3', '3', '5', '7', '4', '3', '2', '0', '6', '5', '6', '8', '7', '5', '5', '2', '0', '0', '0', '0', '/', '2', '9', '0', '5', '0', '3', '7', '6', '4', '9', '1', '0', '1', '5', '8', '8', '6', '8', '5', '5', '9', '3', '5', '3', '5', '2', '3', '6', '0', '4', '9', '9', '2', '5', '0', '0', '1', '7', '9', '5', '4', '1', '6', '2', '6', '4', '9', '1', '2', '1', '3', '4', '6', '5', '7', '1', '1', '5', '2', '0', '8', '6', '9', '8', '0', '3', '4', '1'])) := by
  rfl

attribute [local simp] simplex00_lookup_max_bound

theorem simplex00_lookup_jensen_bound :
    rawSimplex00.getObjVal? "jensen_bound" = .ok (.str (String.ofList ['1', '7', '0', '8', '5', '6', '5', '3', '6', '5', '0', '1', '2', '6', '8', '5', '4', '6', '8', '9', '8', '0', '1', '8', '8', '8', '4', '5', '5', '8', '7', '5', '5', '8', '3', '2', '3', '4', '1', '2', '6', '0', '6', '5', '7', '0', '4', '8', '8', '4', '1', '1', '7', '6', '8', '7', '8', '0', '1', '7', '6', '9', '4', '8', '8', '3', '2', '7', '6', '3', '9', '0', '4', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '/', '1', '5', '6', '3', '6', '2', '2', '2', '2', '7', '8', '5', '9', '8', '5', '7', '1', '8', '2', '7', '1', '6', '7', '0', '7', '5', '7', '6', '2', '0', '8', '6', '2', '8', '1', '1', '7', '8', '0', '3', '0', '3', '1', '1', '9', '3', '8', '0', '8', '2', '5', '0', '2', '9', '6', '2', '3', '8', '1', '9', '7', '5', '6', '9', '7', '9', '2', '3', '8', '1', '3', '8', '7', '3', '1', '3', '0', '9', '5', '2', '5', '2', '6', '8', '8', '0', '3', '9', '5', '3', '0', '2', '8', '0', '9', '0', '4', '3', '6', '7', '4', '1', '4', '3'])) := by
  rfl

attribute [local simp] simplex00_lookup_jensen_bound

theorem simplex00_lookup_max_floor_Q96 :
    rawSimplex00.getObjVal? "max_floor_Q96" = .ok (.str (String.ofList ['3', '4', '0', '5', '3', '6', '9', '5', '6', '5', '7', '6'])) := by
  rfl

attribute [local simp] simplex00_lookup_max_floor_Q96

theorem simplex00_lookup_jensen_floor_Q96 :
    rawSimplex00.getObjVal? "jensen_floor_Q96" = .ok (.str (String.ofList ['8', '6', '5', '7', '2', '3', '7', '7', '9', '0', '1', '4'])) := by
  rfl

attribute [local simp] simplex00_lookup_jensen_floor_Q96

theorem simplex00_decoded : decodeSimplex rawSimplex00 = .ok simplex00 := by
  unfold decodeSimplex simplex00
  simp [rationalField, rationalArrayField]

attribute [local simp] simplex00_decoded


end ImbalancedChen.P2Saving16Cell00FieldDecode
