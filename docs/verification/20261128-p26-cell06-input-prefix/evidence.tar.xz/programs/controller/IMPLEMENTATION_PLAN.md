# Cell06 isolated verification controller implementation plan

**Goal:** Prepare a reviewable controller for exact old Data06 qualification followed by a whitelist of new owners. No proof command, installation or stage preparation is performed during implementation.

**Architecture:** `controller.py` owns explicit accepted-parent/environment/graph contracts and exclusive fresh-stage materialization. `templates.py` derives new helpers from pinned original replay/audit sources without invoking their mains. `evidence.py` owns immutable per-attempt receipts and full canonical/shared audit validation. `test_host.py` uses synthetic files and fake command executors only.

**Writable root:** `/workspace/p26-cell06-source-candidate-20261128/runner/` only. Frozen geometry/moment/finite candidates, original JSON, repository, objects and services remain read-only. No Git commit, Lean, lake, MCP or subagent.

**Explicit parent:** A caller must supply a real `formal_acceptance:true` context, its exact SHA256 and expected project closure count. The newly observed Cell01 source context has1499 modules and SHA256 `bb39c8d439c401e527fcce1e3e02be367bae6aa54017aacd98c170e108277ab3`; the controller must verify it rather than infer acceptance from the expected number. All later commands bind the immutable stage contract.

- [x] Implement candidate parent/graph/runtime/external-lock validation, exclusive fresh-stage preparation, full first-root parent objects plus555native files, source/raw copies, helper generation and pre/post pins. No real stage has been prepared.
- [x] Implement candidate trust0 official replay plus full serialized/environment owned audit and quoted packed-byte readback for exactly two old modules, with no old normal compilation. These helpers remain uncompiled.
- [x] Implement candidate whitelist normal→stock leanchecker→full-owned steps, dependencies, immutable attempt receipts, same-byte success recovery and no-recompile barriers.
- [x] Run host/static/negative tests only; record CLI, resource measurement and limitations. Deliver code as an unexecuted verification-controller candidate.

Post-review design: preserve v1 replicated-input implementation under `revisions/v1-replicated-inputs/`. The current v2 stage stores one shared baseline pin array; per-mode and prefix records reference that immutable baseline and explicit deltas. A preflight/recovery transaction deduplicates identical pins and baseline JSON parsing; every actual proof command bypasses that cache for complete real pre/post byte checks. An allowlisted environment and externally supplied stage SHA bind resume. Failed-source migration into a new contract/stage is intentionally unimplemented; do not rebuild passed normals to work around that boundary.

Review focus: stale/false parent, graph revisions or missing imports, unexpected objects/imports/external modules, missing successful normal objects/receipts, shared serialized theorem bodies, mutable external inputs, partial failed attempts, moduleDoc-before-import, and fabricated success counts. No per-owner292 declaration assumption is permitted.
