"""Archive the actually checked Data06/Input prefix; never compile proofs."""
from pathlib import Path
import hashlib
import io
import json
import sys
import tarfile

sys.dont_write_bytecode = True
RUNNER = Path('/workspace/p26-cell06-source-candidate-20261128/runner')
sys.path.insert(0, str(RUNNER))
import controller
import evidence

STAGE = RUNNER / 'stages/cell06-parent1499-v1'
STAGE_SHA = '83affec77d951a27ec2b7a172fea4e8c43c1d64579f173e275521b45689ccb41'
MODULE = 'ImbalancedChen.P2OriginalSaving19Geometry06ScalableInput'
OUT = Path(__file__).resolve().parent


def main():
    assert not (OUT / 'CAPSULE.json').exists()
    with evidence.verification_transaction():
        context, graph, env, flags = controller.load_stage(STAGE, STAGE_SHA)
        base, base_path = controller.qualified(STAGE)
        final_path = STAGE / 'accepted-contexts' / (MODULE + '.json')
        final_pin = evidence.pin(final_path)
        final = evidence.read(final_path)
        assert final['formal_acceptance'] and not final['P2_6_complete']
        assert len(base['project_closure']) == 1501 and len(final['project_closure']) == 1502
        assert final['accepted_new_modules'] == [MODULE]
        assert final['accepted_parent'] == evidence.pin(base_path)
        assert base['old_normal_recompilations'] == final['old_normal_recompilations'] == 0
        stage_pin = evidence.pin(STAGE / 'STAGE.json')
        modes = ['normal', 'stock-leanchecker', 'full-owned']
        for mode, receipt in zip(modes, final['receipts']):
            evidence.check_receipt_chain(receipt, stage_pin, MODULE, mode,
                evidence.environment_sha256(env), controller.expected_argv(STAGE, context, MODULE, mode))
        assert len(final['receipts']) == 3
        audit_seal = evidence.read(final['receipts'][-1]['path'])
        audit_result = evidence.read(audit_seal['result']['path'])
        audited = evidence.validate_audit(Path(audit_result['log']['path']).read_text(),
            [MODULE], set(final['project_closure']), base['external_modules'])
        assert audited == audit_seal['validated']
        assert audited['canonical_count'] == 9 and audited['shared_occurrences'] == 0
        controller.validate_catalog(STAGE, context, graph, final['project_closure'], [MODULE])
        controller.namespace_check(STAGE, final['project_closure'], context['native_artifacts'])
        evidence.check_inputs(final['pins'])

        members = {}

        def add(name, path, expected=None):
            path = Path(path)
            if expected is not None:
                evidence.check(expected)
                assert str(path) == expected['path']
            assert name not in members
            members[name] = path

        add('CURRENT_ACCEPTED_CONTEXT.json', final_path, final_pin)
        add('DATA2_ACCEPTED_CONTEXT.json', base_path)
        add('STAGE.json', STAGE / 'STAGE.json', stage_pin)
        add('BASELINE_INPUTS.json', context['baseline_inputs']['path'], context['baseline_inputs'])
        add('ENVIRONMENT_LOCK.json', context['environment_lock']['path'], context['environment_lock'])
        add('CANDIDATE_GRAPH.json', context['graph']['path'], context['graph'])
        add('PARENT_ACCEPTED_CONTEXT.json', context['accepted_parent']['path'], context['accepted_parent'])
        add('DATA2_MODULES.json', STAGE / 'DATA2_MODULES.json')
        add('PARENT_MODULES.json', STAGE / 'PARENT_MODULES.json')
        for name in ['Data2Replay.lean', 'Data2Owned.lean', MODULE + '.Owned.lean']:
            add('programs/' + name, STAGE / 'helpers' / name)
        for receipt in base['receipts'] + final['receipts']:
            for path in sorted(Path(receipt['path']).parent.iterdir()):
                if path.is_file():
                    add('steps/' + str(path.relative_to(STAGE / 'steps')), path)
        for module in controller.OLD + [MODULE]:
            info = final['project_closure'][module]
            relative = module.replace('.', '/')
            add('sources/' + relative + '.lean', info['source']['path'], info['source'])
            add('objects/' + relative + '.olean', info['selected_object']['path'], info['selected_object'])
        for row in context['raw_copies']:
            add('goldbach-research/' + Path(row['path']).name, row['path'], row)
        for row in context['controller_sources']:
            add('programs/controller/' + Path(row['path']).name, row['path'], row)
        for row in context['reference_sources']:
            add('programs/references/' + Path(row['path']).name, row['path'], row)
        add('programs/DELIVERY_MANIFEST.json', RUNNER / 'DELIVERY_MANIFEST.json')
        add('programs/package_foundation.py', Path(__file__))
        pins = {name: evidence.pin(path) for name, path in members.items()}
        manifest = {'schema': 'p26_cell06_checked_input_prefix_materials_v1',
            'accepted_project_union': 1502, 'Data06_qualified': True,
            'Geometry06ScalableInput_accepted': True, 'Cell06_integral_complete': False,
            'P2_6_complete': False, 'original_full_snapshot_verified': False,
            'members': pins,
            'scope': 'Exactly two original packed data declarations and nine input-interface declarations. Parser, decoder, row arithmetic, source packing and Cell06 integral remain open.'}
        manifest_raw = (json.dumps(manifest, indent=2) + '\n').encode()
        archive = OUT / 'evidence.tar.xz'
        with tarfile.open(archive, 'w:xz') as tar:
            for name, path in sorted(members.items()):
                raw = path.read_bytes()
                assert evidence.pin(path) == pins[name]
                entry = tarfile.TarInfo(name)
                entry.size, entry.mode = len(raw), 0o644
                tar.addfile(entry, io.BytesIO(raw))
            entry = tarfile.TarInfo('MANIFEST.json')
            entry.size, entry.mode = len(manifest_raw), 0o644
            tar.addfile(entry, io.BytesIO(manifest_raw))
        assert archive.stat().st_size < 90 * 1024**2
        with tarfile.open(archive) as tar:
            assert len(tar.getmembers()) == len(members) + 1
            for entry in tar:
                raw = tar.extractfile(entry).read()
                if entry.name == 'MANIFEST.json': assert raw == manifest_raw
                else: assert raw == members[entry.name].read_bytes()
        for name, path in members.items(): assert evidence.pin(path) == pins[name]
        assert evidence.pin(final_path) == final_pin
        (OUT / 'MANIFEST.json').write_bytes(manifest_raw)
        capsule = {'schema': 'p26_cell06_checked_input_prefix_capsule_v1',
            'Data06_qualified': True, 'Geometry06ScalableInput_accepted': True,
            'Cell06_integral_complete': False, 'P2_6_complete': False,
            'original_full_snapshot_verified': False, 'accepted_project_union': 1502,
            'accepted_parent_commit': 'c985c5965c3ca64a30570829713b25d5ebdcc243',
            'candidate_source_artifact_commit': '9779a018863ddfc674f34228beffbf7c34f4867c',
            'old_normal_recompilations': 0, 'restored_data_canonical': 2,
            'new_input_owner_canonical': 9, 'shared_occurrences': 0,
            'current_context': final_pin, 'stage_contract': stage_pin,
            'receipts': {'Data2': base['receipts'], 'Input': final['receipts']},
            'archive': evidence.pin(archive), 'archive_readback_members': len(members) + 1,
            'packager_source': evidence.pin(Path(__file__)), 'scope': manifest['scope']}
        (OUT / 'CAPSULE.json').write_text(json.dumps(capsule, indent=2) + '\n')
        print(json.dumps(capsule), flush=True)


if __name__ == '__main__':
    main()
